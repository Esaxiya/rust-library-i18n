//! Mga pagpapatupad ng Trait para sa `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Nagpapatupad ng pag-order ng mga string.
///
/// Ang mga string ay iniutos ng [lexicographically](Ord#lexicographical-comparison) ng kanilang mga halaga ng byte.
/// Iniuutos nito ang mga puntos ng code ng Unicode batay sa kanilang mga posisyon sa mga chart ng code.
/// Hindi ito kinakailangan na kapareho ng pagkakasunud-sunod ng "alphabetical", na nag-iiba ayon sa wika at lokal.
/// Pag-aayos string ayon sa kultura-tinatanggap na mga pamantayan ay nangangailangan na tukoy sa lokal na data na nasa labas ng saklaw ng ang uri `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Nagpapatupad ng mga pagpapatakbo ng paghahambing sa mga string.
///
/// String ay inihambing [lexicographically](Ord#lexicographical-comparison) sa pamamagitan ng kanilang mga halaga byte.
/// Ito pinagkukumpara Unicode puntos code batay sa kanilang mga posisyon sa mga tsart code.
/// Hindi ito kinakailangan na kapareho ng pagkakasunud-sunod ng "alphabetical", na nag-iiba ayon sa wika at lokal.
/// Ang paghahambing ng mga string ayon sa kultura-tinatanggap na mga pamantayan ay nangangailangan na tukoy sa lokal na data na nasa labas ng saklaw ng ang uri `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implements substring pagpipiraso na may syntax `&self[..]` o `&mut self[..]`.
///
/// Ibinabalik ng isang slice ng buong string, ibig sabihin, babalik `&self` o `&mut self`.Katumbas ng `&sarili [0 ..
/// len] `o`&mut sarili [0 ..
/// len]`.
/// Hindi tulad ng iba pang mga pagpapatakbo sa pag-index, hindi ito kailanman maaaring panic.
///
/// Ang operasyon na ito ay *O*(1).
///
/// Bago ang 1.20.0, ang mga pagpapatakbo sa pag-index na ito ay suportado pa rin ng direktang pagpapatupad ng `Index` at `IndexMut`.
///
/// Katumbas ng `&self[0 .. len]` o `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Nagpapatupad ng pagpipiraso ng substring sa syntax `&self[begin .. end]` o `&mut self[begin .. end]`.
///
/// Nagbabalik ng isang hiwa ng ibinigay na string mula sa saklaw ng byte [`umpisa`, `end`).
///
/// Ang operasyon na ito ay *O*(1).
///
/// Bago ang 1.20.0, ang mga pagpapatakbo sa pag-index na ito ay suportado pa rin ng direktang pagpapatupad ng `Index` at `IndexMut`.
///
/// # Panics
///
/// Ang Panics kung `begin` o `end` ay hindi tumuturo sa panimulang byte offset ng isang character (tulad ng tinukoy ng `is_char_boundary`), kung `begin > end`, o kung `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // mga kalooban panic:
/// // byte 2 mga kasinungalingan sa loob `ö`:
/// // &s [2 ..3];
///
/// // byte 8 namamalagi sa loob ng `老`&s [1 ..
/// // 8];
///
/// // byte 100 ay nasa labas ng string&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // KALIGTASAN: naka-check lamang na ang `start` at `end` ay nasa isang char hangganan,
            // at dumadaan kami sa isang ligtas na sanggunian, kaya't ang halaga ng pagbabalik ay magiging isa din.
            // din kami naka-check char hangganan, kaya ito ay may-bisa UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // KALIGTASAN: naka-check lamang na ang `start` at `end` ay nasa isang char border.
            // Alam namin na ang pointer ay natatangi dahil nakuha namin ito mula sa `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // KALIGTASAN: tumatawag garantiya na `self` ay nasa hangganan ng `slice`
        // kung saan satisfies ang lahat ng mga kondisyon para sa `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // KALIGTASAN: tingnan ang mga komento para sa `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary mga tseke na ang index ay nasa [0, .len()] ay hindi maaaring magamit muli ang `get` tulad ng nasa itaas, dahil sa problema sa NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // KALIGTASAN: naka-check lamang na ang `start` at `end` ay nasa isang char hangganan,
            // at dumadaan kami sa isang ligtas na sanggunian, kaya't ang halaga ng pagbabalik ay magiging isa din.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Nagpapatupad ng pagpipiraso ng substring sa syntax `&self[.. end]` o `&mut self[.. end]`.
///
/// Nagbabalik ng isang slice ng ibinigay na string mula sa byte range na [`0`, `end`).
/// Katumbas ng `&self[0 .. end]` o `&mut self[0 .. end]`.
///
/// Ang operasyon na ito ay *O*(1).
///
/// Bago ang 1.20.0, ang mga pagpapatakbo sa pag-index na ito ay suportado pa rin ng direktang pagpapatupad ng `Index` at `IndexMut`.
///
/// # Panics
///
/// Panics kung ang `end` ay hindi tumuturo sa panimulang byte offset ng isang character (tulad ng tinukoy ng `is_char_boundary`), o kung `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // KALIGTASAN: lamang naka-check na `end` ay sa isang char hangganan,
            // at dumadaan kami sa isang ligtas na sanggunian, kaya't ang halaga ng pagbabalik ay magiging isa din.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // KALIGTASAN: lamang naka-check na `end` ay sa isang char hangganan,
            // at dumadaan kami sa isang ligtas na sanggunian, kaya't ang halaga ng pagbabalik ay magiging isa din.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // KALIGTASAN: lamang naka-check na `end` ay sa isang char hangganan,
            // at dumadaan kami sa isang ligtas na sanggunian, kaya't ang halaga ng pagbabalik ay magiging isa din.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Nagpapatupad ng pagpipiraso ng substring sa syntax `&self[begin ..]` o `&mut self[begin ..]`.
///
/// Nagbabalik ng isang hiwa ng ibinigay na string mula sa saklaw ng byte [`umpisa`, `len`).Katumbas ng `at sarili [magsimula ..
/// len] `o`&mut self [magsimula ..
/// len]`.
///
/// Ang operasyon na ito ay *O*(1).
///
/// Bago ang 1.20.0, ang mga pagpapatakbo sa pag-index na ito ay suportado pa rin ng direktang pagpapatupad ng `Index` at `IndexMut`.
///
/// # Panics
///
/// Panics kung `begin` ay hindi point sa ang panimulang byte offset ng isang character (tulad ng tinukoy sa pamamagitan `is_char_boundary`), o kung `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // KALIGTASAN: naka-check lamang na ang `start` ay nasa isang char hangganan,
            // at dumadaan kami sa isang ligtas na sanggunian, kaya't ang halaga ng pagbabalik ay magiging isa din.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // KALIGTASAN: naka-check lamang na ang `start` ay nasa isang char hangganan,
            // at dumadaan kami sa isang ligtas na sanggunian, kaya't ang halaga ng pagbabalik ay magiging isa din.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // KALIGTASAN: tumatawag garantiya na `self` ay nasa hangganan ng `slice`
        // kung saan satisfies ang lahat ng mga kondisyon para sa `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // KALIGTASAN: magkapareho sa `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // KALIGTASAN: naka-check lamang na ang `start` ay nasa isang char hangganan,
            // at dumadaan kami sa isang ligtas na sanggunian, kaya't ang halaga ng pagbabalik ay magiging isa din.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Nagpapatupad ng pagpipiraso ng substring sa syntax `&self[begin ..= end]` o `&mut self[begin ..= end]`.
///
/// Nagbabalik ng isang hiwa ng ibinigay na string mula sa byte range na [`begin`, `end`].Katumbas ng `&self [begin .. end + 1]` o `&mut self[begin .. end + 1]`, maliban kung ang `end` ay may maximum na halaga para sa `usize`.
///
/// Ang operasyon na ito ay *O*(1).
///
/// # Panics
///
/// Panics kung `begin` ay hindi point sa ang panimulang byte offset ng isang character (tulad ng tinukoy sa pamamagitan `is_char_boundary`), kung `end` ay hindi tumuturo sa pagtatapos byte offset ng isang character (`end + 1` ay alinman sa isang panimulang byte offset o kasing-halaga sa `len`), kung `begin > end`, o kung `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Nagpapatupad ng pagpipiraso ng substring sa syntax `&self[..= end]` o `&mut self[..= end]`.
///
/// Nagbabalik ng isang hiwa ng ibinigay na string mula sa byte range na [0, `end`].
/// Katumbas ng `&self [0 .. end + 1]`, maliban kung ang `end` ay may maximum na halaga para sa `usize`.
///
/// Ang operasyon na ito ay *O*(1).
///
/// # Panics
///
/// Panics kung `end` ay hindi point sa pagtatapos byte offset ng isang character (`end + 1` ay alinman sa isang panimulang byte offset tulad ng natukoy ng `is_char_boundary`, o kasing-halaga sa `len`), o kung `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// I-parse ang isang halaga mula sa isang string
///
/// Ang pamamaraang [`from_str`] ng FromStr`ay madalas na ginagamit nang implicit, sa pamamagitan ng pamamaraang [`parse`] ni [`str`].
/// Tingnan ang dokumentasyon ni [`parse`] para sa mga halimbawa.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` walang isang habang-buhay na parameter, at sa gayon maaari mo lamang i-parse ang mga uri na hindi naglalaman ng isang parameter ng habang buhay mismo.
///
/// Sa madaling salita, maaari mong mai-parse ang isang `i32` sa `FromStr`, ngunit hindi isang `&i32`.
/// Maaari mong mai-parse ang isang struct na naglalaman ng isang `i32`, ngunit hindi isa na naglalaman ng isang `&i32`.
///
/// # Examples
///
/// Basic pagpapatupad ng `FromStr` sa isang halimbawa `Point` uri:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Ang kakambal itong kamalian na maaaring bumalik mula sa pag-parse.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Pina-parse ang isang string `s` upang bumalik ang halaga ng ganitong uri.
    ///
    /// Kung pag-parse magtagumpay, bumalik ang halaga sa loob [`Ok`], kung hindi man kapag ang string ay may sakit na-format na return ng isang error na tukoy sa loob [`Err`].
    /// Ang uri ng error ay partikular sa implementasyon ng trait.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit sa [`i32`], isang uri na nagpapatupad ng `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Pag-parse ng `bool` mula sa isang string.
    ///
    /// Nagbubunga ng isang `Result<bool, ParseBoolError>`, dahil ang `s` ay maaaring o hindi maaaring talagang ma-parseable.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Tandaan, sa maraming mga kaso, ang paraan ng `.parse()` sa `str` ay mas maayos.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}