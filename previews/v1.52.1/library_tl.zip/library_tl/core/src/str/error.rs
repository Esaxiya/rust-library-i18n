//! Tinutukoy ang uri ng error ng utf8.

use crate::fmt;

/// Mga error na maaaring mangyari kapag sa pagtatangka upang bigyang-kahulugan ang isang pagkakasunod-sunod ng mga [`u8`] bilang isang string.
///
/// Tulad ng naturan, ang `from_utf8` pamilya ng mga pag-andar at pamamaraan para sa parehong [`String`] s at [`&str`] s na gumagamit ng error na ito, halimbawa.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// pamamaraan Ang uri ng error na maaaring magamit upang lumikha ng pag-andar na katulad ng `String::from_utf8_lossy` nang walang paglaan ng heap memory:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Ibinabalik ang index sa ibinigay na string hanggang sa kung aling wastong UTF-8 ang na-verify.
    ///
    /// Ito ay ang pinakamataas na index tulad na `from_utf8(&input[..index])` ay magbabalik `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// use std::str;
    ///
    /// // ilang mga hindi wastong byte, sa isang vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 nagbabalik ng isang Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // ang pangalawang byte ay hindi wasto dito
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Nagbibigay ng karagdagang impormasyon tungkol sa kabiguan:
    ///
    /// * `None`: ang pagtatapos ng input ay naabot nang hindi inaasahan.
    ///   `self.valid_up_to()` ay 1 hanggang 3 bytes mula sa dulo ng input.
    ///   Kung ang isang byte stream (gaya ng isang file o isang network socket) ay decoded nang paunti-unti, ito ay maaaring maging isang wastong `char` na UTF-8 byte sequence ay sumasaklaw sa maramihang mga chunks.
    ///
    ///
    /// * `Some(len)`: isang hindi inaasahang byte ay nakatagpo.
    ///   Ang haba na ibinigay ay ang hindi wastong pagkakasunud-sunod ng byte na nagsisimula sa index na ibinigay ng `valid_up_to()`.
    ///   Dapat na ipagpatuloy ang pag-decode pagkatapos ng pagkakasunud-sunod na iyon (pagkatapos ng pagpasok ng isang [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) sa kaso ng lossy decoding.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Bumalik ang isang error kapag nabigo ang pag-parse ng `bool` gamit ang [`from_str`]
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}