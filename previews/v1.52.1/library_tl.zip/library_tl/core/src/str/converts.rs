//! Mga paraan upang lumikha ng isang `str` mula sa bytes slice.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Nagko-convert ng isang slice ng bytes sa isang string slice.
///
/// Ang isang string slice ([`&str`]) ay gawa sa bytes ([`u8`]), at isang byte slice ([`&[u8]`][byteslice]) ay gawa sa bytes, kaya ang function na ito nagpalit sa pagitan ng dalawa.
/// Hindi lahat ng mga byte slice ay wastong mga hiwa ng string, subalit: kinakailangan ng [`&str`] na ito ay wastong UTF-8.
/// `from_utf8()` mga tseke upang matiyak na ang mga byte ay wastong UTF-8, at pagkatapos ay ang pag-convert.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Kung nakatiyak ka na ang byte slice ay wastong UTF-8, at hindi mo nais na maabot ang overhead ng validity check, mayroong isang hindi ligtas na bersyon ng pagpapaandar na ito, [`from_utf8_unchecked`], na may parehong pag-uugali ngunit nilaktawan ang tseke.
///
///
/// Kung kailangan mo ng isang `String` sa halip na isang `&str`, isaalang-alang ang [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Dahil maaari mong stack-maglaan ng isang `[u8; N]`, at maaari kang kumuha ng isang [`&[u8]`][byteslice] nito, ang pagpapaandar na ito ay isang paraan upang magkaroon ng isang naka-allocate na string.Mayroong isang halimbawa nito sa seksyon ng mga halimbawa sa ibaba.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Ibinabalik ang `Err` kung ang slice ay hindi UTF-8 na may isang paglalarawan kung bakit ang ibinigay na hiwa ay hindi UTF-8.
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// use std::str;
///
/// // ilang mga byte, sa isang vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Alam naming may bisa ang mga byte na ito, kaya `unwrap()` lang ang gamitin.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Maling mga byte:
///
/// ```
/// use std::str;
///
/// // ilang mga hindi wastong byte, sa isang vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Tingnan ang docs para [`Utf8Error`] para sa karagdagang detalye sa mga uri ng mga error na maaaring ibalik.
///
/// Isang "stack allocated string":
///
/// ```
/// use std::str;
///
/// // ilang mga byte, sa isang hanay na inilaan ng stack
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Alam naming may bisa ang mga byte na ito, kaya `unwrap()` lang ang gamitin.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // KALIGTASAN: Nagpapatakbo lamang ng pagpapatunay.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Binabago ang isang nababagabag na hiwa ng mga byte sa isang nababagabag na hiwa ng string.
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" bilang isang nababagabag na vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Tulad ng alam naming wasto ang mga byte na ito, maaari naming gamitin ang `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Maling mga byte:
///
/// ```
/// use std::str;
///
/// // Ang ilang mga hindi wastong byte sa isang nababagabag na vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Tingnan ang docs para [`Utf8Error`] para sa karagdagang detalye sa mga uri ng mga error na maaaring ibalik.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // KALIGTASAN: Nagpapatakbo lamang ng pagpapatunay.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Kino-convert ng isang hiwa ng bytes sa isang string slice nang walang check na ang string ay naglalaman ng valid UTF-8.
///
/// Tingnan ang ligtas na bersyon, [`from_utf8`], para sa karagdagang impormasyon.
///
/// # Safety
///
/// Ang pag-andar na ito ay hindi ligtas dahil hindi nito sinusuri kung ang mga byte na naipasa dito ay wastong UTF-8.
/// Kung ang hadlang na ito ay nilabag, hindi natukoy na mga resulta ng pag-uugali, dahil ang natitirang Rust ay ipinapalagay na ang [`&str`] ay wastong UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// use std::str;
///
/// // ilang mga byte, sa isang vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // KALIGTASAN: dapat magagarantiya ng tumatawag na ang bytes `v` ay wastong UTF-8.
    // Nakasalalay din sa `&str` at `&[u8]` pagkakaroon ng parehong layout.
    unsafe { mem::transmute(v) }
}

/// Nagko-convert ng isang slice ng bytes sa isang string slice nang hindi sinusuri na ang string ay naglalaman ng wastong UTF-8;nababagong bersyon.
///
///
/// Tingnan ang hindi nababago na bersyon, [`from_utf8_unchecked()`] para sa karagdagang impormasyon.
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // KALIGTASAN: dapat garantiya ng tumatawag na ang bytes `v`
    // ay wastong UTF-8, sa gayon ang cast sa `*mut str` ay ligtas.
    // Gayundin, ligtas ang pagkakatanggal ng pointer dahil ang pointer na iyon ay nagmula sa isang sanggunian na ginagarantiyahan na wasto para sa mga pagsusulat.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}