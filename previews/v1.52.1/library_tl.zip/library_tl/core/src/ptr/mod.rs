//! Mano-manong pamahalaan ang memorya sa pamamagitan ng mga raw point.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Maraming mga pag-andar sa modyul na ito ang kumukuha ng mga hilaw na payo bilang mga argumento at binasa mula o sumulat sa kanila.Para maging ligtas ito, ang mga pahiwatig na ito ay dapat na *wasto*.
//! Kung ang isang pointer ay may-bisa ay depende sa ang operasyon na ito ay ginagamit para sa (basahin o isulat), at ang lawak ng memorya na ay na-access (ibig sabihin, kung ilang bytes ay read/written).
//! Karamihan sa mga pagpapaandar ay gumagamit ng `*mut T` at `* const T` upang ma-access lamang ang isang solong halaga, kung saan ang dokumentasyon ay tinatanggal ang laki at implicit na ipinapalagay na ito ay `size_of::<T>()` bytes.
//!
//! Ang tumpak na mga patakaran para sa bisa ay hindi pa natutukoy.Ang mga garantiyang ibibigay sa puntong ito ay napakaliit:
//!
//! * Ang isang [null] pointer ay *hindi kailanman* wasto, hindi kahit para sa mga pag-access ng [size zero][zst].
//! * Para sa isang pointer na maging wasto, kinakailangan, ngunit hindi palaging sapat, na ang pointer ay *hindi kanais-nais*: ang saklaw ng memorya ng ibinigay na laki na nagsisimula sa pointer ay dapat lahat sa loob ng mga hangganan ng isang solong inilalaan na bagay.
//!
//! Tandaan na sa Rust, bawat variable na (stack-allocated) ay itinuturing na isang hiwalay na inilalaan na bagay.
//! * Kahit na para sa mga pagpapatakbo ng [size zero][zst], ang pointer ay hindi dapat na tumuturo sa deallocated memory, ibig sabihin, ang translocation ay ginagawang hindi wasto ang mga pointers kahit para sa mga zero-size na operasyon.
//! Gayunman, ang paghahagis ng anumang non-zero integer *literal* sa isang pointer ay may-bisa para sa zero-sized accesses, kahit na ang ilang mga memory mangyayari na umiiral sa address na iyon at makakakuha deallocated.
//! Ito ay tumutugon sa pagsusulat ng iyong sariling allocator: paglaan ng zero-sized na mga bagay ay hindi masyadong mahirap.
//! Ang canonical na paraan upang makakuha ng isang pointer na wasto para sa mga zero-size na pag-access ay [`NonNull::dangling`].
//! * Ang lahat ng mga pag-access na isinagawa ng mga pag-andar sa modyul na ito ay *hindi atomic* sa kahulugan ng [atomic operations] na ginamit upang pagsabayin sa pagitan ng mga thread.
//! Nangangahulugan ito na hindi natukoy na pag-uugali upang magsagawa ng dalawang kasabay na mga pag-access sa parehong lokasyon mula sa iba't ibang mga thread maliban kung ang parehong pag-access ay binabasa lamang mula sa memorya.
//! Pansinin na malinaw na may kasamang [`read_volatile`] at [`write_volatile`] na ito: hindi maaaring gamitin ang mga pabagu-bago na pag-access para sa inter-thread na pagsabay.
//! * Ang resulta ng paghahagis ng isang sanggunian sa isang pointer ay may bisa para sa hangga't ang pinagbabatayan na bagay ay live at walang sanggunian (mga raw pointer lamang) ang ginamit upang ma-access ang parehong memorya.
//!
//! Ang mga axiom na ito, kasama ang maingat na paggamit ng [`offset`] para sa pointer arithmetic, ay sapat na upang maipatupad nang tama ang maraming mga kapaki-pakinabang na bagay sa hindi ligtas na code.
//! Ang mga mas malalakas na garantiya ay ibibigay sa paglaon, dahil ang mga patakaran ng [aliasing] ay natutukoy.
//! Para sa karagdagang impormasyon, tingnan ang [book] pati na rin ang seksyon sa sanggunian na nakatuon sa [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Ang mga wastong hilaw na pahiwatig na tinukoy sa itaas ay hindi kinakailangang maayos na nakahanay (kung saan ang pag-align ng "proper" ay tinukoy ng uri ng pointee, ibig sabihin, ang `*const T` ay dapat na nakahanay sa `mem::align_of::<T>()`).
//! Gayunpaman, ang karamihan sa mga pagpapaandar ay nangangailangan ng kanilang mga argumento upang maayos na nakahanay, at malinaw na isasaad ang kinakailangang ito sa kanilang dokumentasyon.
//! Kapansin-pansin na mga pagbubukod dito ay ang [`read_unaligned`] at [`write_unaligned`].
//!
//! Kapag ang isang pagpapaandar ay nangangailangan ng wastong pagkakahanay, ginagawa ito kahit na ang pag-access ay may sukat na 0, ibig sabihin, kahit na ang memorya ay hindi talaga hinawakan.Isaalang-alang ang paggamit ng [`NonNull::dangling`] sa mga ganitong kaso.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Isinasagawa ang mapanirang (kung mayroon man) ng itinuro na halaga.
///
/// Ito ay katumbas na semantiko sa pagtawag sa [`ptr::read`] at pagtatapon ng resulta, ngunit may mga sumusunod na kalamangan:
///
/// * Kinakailangan * na gumamit ng `drop_in_place` upang i-drop ang mga hindi naka-unsize na uri tulad ng mga bagay na trait, sapagkat hindi ito mabasa sa stack at bumagsak nang normal.
///
/// * Ito ay friendlier sa optimizer na gawin ito sa paglipas ng [`ptr::read`] kapag bumababa nang manu-mano inilalaan memory (eg, sa pagpapatupad ng `Box`/`Rc`/`Vec`), pati na ang tagatala ay hindi na kailangan upang patunayan na ito ay tunog upang pigilin ang kopya.
///
///
/// * Maaari itong magamit upang i-drop ang [pinned] data kapag ang `T` ay hindi `repr(packed)` (ang naka-pin na data ay hindi dapat ilipat bago ito ay bumaba).
///
/// Ang mga hindi naka-align na halaga ay hindi maaaring mailagay sa lugar, dapat silang makopya sa isang nakahanay na lokasyon muna gamit ang [`ptr::read_unaligned`].Para sa naka-pack na struct, ang paglipat na ito ay awtomatikong ginagawa ng tagatala.
/// Nangangahulugan ito na ang mga patlang ng naka-pack na struct ay hindi nahuhulog sa lugar.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Pag-uugali ay hindi maliwanag kung ang alinman sa mga sumusunod na kondisyon ay nilabag:
///
/// * `to_drop` dapat [valid] para sa parehong nagbabasa at nagsusulat.
///
/// * `to_drop` ay dapat na maayos na hile-hilera.
///
/// * Ang halagang `to_drop` point na dapat ay wasto para sa pag-drop, na maaaring mangahulugan na dapat itong panatilihin ang mga karagdagang invariant, ito ay umaasa sa uri.
///
/// Bilang karagdagan, kung ang `T` ay hindi [`Copy`], ang paggamit ng itinuro na halaga pagkatapos tumawag sa `drop_in_place` ay maaaring maging sanhi ng hindi natukoy na pag-uugali.Tandaan na ang `*to_drop = foo` ay binibilang bilang isang paggamit dahil ito ay magiging sanhi ng pagbaba muli ng halaga.
/// [`write()`] ay maaaring magamit upang mai-overlap ang data nang hindi ito sanhi ng pagbagsak nito.
///
/// Tandaan na kahit na ang `T` ay may sukat `0`, ang pointer ay dapat na hindi NUL at maayos na nakahanay.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Mano-manong alisin ang huling item mula sa isang vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Kumuha ng isang hilaw na pointer sa huling elemento sa `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Paikliin ang `v` upang maiwasan ang pagkahulog ng huling item.
///     // Ginagawa muna namin iyon, upang maiwasan ang mga isyu kung ang `drop_in_place` sa ibaba panics.
///     v.set_len(1);
///     // Nang walang isang tawag na `drop_in_place`, ang huling item ay hindi mahuhulog, at ang memorya na pinamamahalaan nito ay maipalabas.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Tiyaking naibagsak ang huling item.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Pansinin na awtomatikong isinasagawa ng tagatala ang kopya na ito kapag bumabagsak sa mga naka-pack na struct, ibig sabihin, hindi mo karaniwang kailangang magalala tungkol sa mga naturang isyu maliban kung manu-mano kang tumawag sa `drop_in_place`.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Ang code dito ay hindi mahalaga, papalitan ito ng tunay na drop glue ng compiler.
    //

    // KALIGTASAN: tingnan ang komento sa itaas
    unsafe { drop_in_place(to_drop) }
}

/// Lumilikha ng isang null raw pointer.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Lumilikha ng isang null mutable raw pointer.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Kailangan ng manu-manong impl upang maiwasan ang `T: Clone` na nakagapos.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Kailangan ng manu-manong impl upang maiwasan ang `T: Copy` na nakagapos.
impl<T> Copy for FatPtr<T> {}

/// Bumubuo ng isang hilaw na hiwa mula sa isang pointer at isang haba.
///
/// Ang `len` argument ay ang bilang ng mga **elemento**, hindi ang bilang ng mga byte.
///
/// Ang pagpapaandar na ito ay ligtas, ngunit ang tunay na paggamit ng halaga ng pagbabalik ay hindi ligtas.
/// Tingnan ang dokumentasyon ng [`slice::from_raw_parts`] para sa mga kinakailangan sa kaligtasan ng hiwa.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // lumikha ng isang slice pointer kapag nagsisimula sa isang pointer sa unang elemento
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // KALIGTASAN: Ang pag-access sa halaga mula sa unyon ng `Repr` ay ligtas mula noong * const [T]
        //
        // at ang FatPtr ay may parehong mga layout ng memorya.Ang std lamang ang makakagawa ng garantiyang ito.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Nagsasagawa ng parehong pag-andar tulad ng [`slice_from_raw_parts`], maliban sa isang raw na nabago na hiwa ay naibalik, taliwas sa isang hilaw na hiwa na hindi nababago.
///
///
/// Tingnan ang dokumentasyon ng [`slice_from_raw_parts`] para sa higit pang mga detalye.
///
/// Ang pagpapaandar na ito ay ligtas, ngunit ang tunay na paggamit ng halaga ng pagbabalik ay hindi ligtas.
/// Tingnan ang dokumentasyon ng [`slice::from_raw_parts_mut`] para sa mga kinakailangan sa kaligtasan ng hiwa.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // magtalaga ng isang halaga sa isang index sa hiwa
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // KALIGTASAN: Ang pag-access sa halaga mula sa unyon ng `Repr` ay ligtas mula noong * mut [T]
        // at ang FatPtr ay may parehong mga layout ng memorya
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Ipinagpalit ang mga halaga sa dalawang lokasyon na maaaring baguhin ng parehong uri, nang hindi rin nililimitahan ang alinman.
///
/// Ngunit para sa sumusunod na dalawang pagbubukod, ang pagpapaandar na ito ay katumbas ng semantikal sa [`mem::swap`]:
///
///
/// * Ito ay nagpapatakbo sa mga hilaw na payo sa halip na mga sanggunian.
/// Kapag magagamit ang mga sanggunian, dapat na mas gusto ang [`mem::swap`].
///
/// * Ang dalawang itinuturo na mga halaga ay maaaring mag-overlap.
/// Kung nag-o-overlap ang mga halaga, gagamitin ang magkakapatong na rehiyon ng memorya mula sa `x`.
/// Ito ay ipinakita sa pangalawang halimbawa sa ibaba.
///
/// # Safety
///
/// Pag-uugali ay hindi maliwanag kung ang alinman sa mga sumusunod na kondisyon ay nilabag:
///
/// * Ang parehong `x` at `y` ay dapat na [valid] para sa parehong nagbasa at sumusulat.
///
/// * Ang parehong `x` at `y` ay dapat na maayos na nakahanay.
///
/// Tandaan na kahit na ang `T` ay may sukat `0`, ang mga pahiwatig ay dapat na hindi NUL at maayos na nakahanay.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Pagpalit ng dalawang di-magkakapatong na rehiyon:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // ito ay `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // ito ay `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Pagpalit ng dalawang magkakapatong na rehiyon:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // ito ay `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // ito ay `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Ang mga indeks na `1..3` ng hiwa ay nagsasapawan sa pagitan ng `x` at `y`.
///     // Ang mga makatuwirang resulta ay para sa kanila na maging `[2, 3]`, upang ang mga indeks na `0..3` ay `[1, 2, 3]` (tumutugma sa `y` bago ang `swap`);o para sa kanila na maging `[0, 1]` upang ang mga indeks na `1..4` ay `[0, 1, 2]` (tumutugma sa `x` bago ang `swap`).
/////
///     // Ang pagpapatupad na ito ay tinukoy upang gawin ang huling pagpipilian.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Bigyan ang ating sarili ng kaunting puwang upang makapagtrabaho.
    // Hindi namin kailangang mag-alala tungkol sa mga patak: Walang ginagawa ang `MaybeUninit` kapag nahulog.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Gawin ang kaligtasan ng pagpapalit: dapat magagarantiya ng tumatawag na ang `x` at `y` ay wasto para sa mga pagsusulat at maayos na nakahanay.
    // `tmp` ay hindi maaaring maging overlap ng alinman sa `x` o `y` dahil ang `tmp` ay inilalaan lamang sa stack bilang isang hiwalay na inilalaan na bagay.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` at `y` ay maaaring mag-overlap
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Ipinagpalit ang `count * size_of::<T>()` bytes sa pagitan ng dalawang rehiyon ng memorya na nagsisimula sa `x` at `y`.
/// Ang dalawang rehiyon ay dapat *hindi* nagsasapawan.
///
/// # Safety
///
/// Pag-uugali ay hindi maliwanag kung ang alinman sa mga sumusunod na kondisyon ay nilabag:
///
/// * Ang parehong `x` at `y` ay dapat na [valid] para sa parehong nagbasa at nagsusulat ng bilang *
///   sukat ng: :<T>() `byte.
///
/// * Ang parehong `x` at `y` ay dapat na maayos na nakahanay.
///
/// * Ang rehiyon ng memorya na nagsisimula sa `x` na may sukat ng `bilang *
///   sukat ng: :<T>() `bytes dapat *hindi* nagsasapawan sa rehiyon ng memorya simula sa `y` na may parehong laki.
///
/// Tandaan na kahit na ang mabisang kinopyang laki (`count * size_of: :<T>Ang ()`) ay `0`, ang mga pahiwatig ay dapat na hindi NUL at maayos na nakahanay.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // KALIGTASAN: dapat magagarantiyahan ng tumatawag na `x` at `y` ay
    // wasto para sa pagsusulat at maayos na nakahanay.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Para sa mga uri na mas maliit kaysa sa block optimization sa ibaba, magpalit lang nang direkta upang maiwasan ang pessimizing codegen.
    //
    if mem::size_of::<T>() < 32 {
        // KALIGTASAN: dapat magagarantiya ng tumatawag na ang `x` at `y` ay wasto
        // para sa mga pagsusulat, maayos na nakahanay, at hindi nag-o-overlap.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Ang diskarte dito ay upang magamit ang simd upang ipagpalit ang x&y nang mahusay.
    // Isiniwalat ng pagsubok na ang pagpapalit ng alinman sa 32 bytes o 64 bytes nang paisa-isa ay pinaka mahusay para sa mga prosesor ng Intel Haswell E.
    // Mas magagawa ng LLVM na ma-optimize kung magbigay kami ng isang #[repr(simd)], kahit na hindi namin talaga ginagamit nang direkta ang istrukturang ito.
    //
    //
    // FIXME repr(simd) nasira sa emscripten at redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Mag-loop sa pamamagitan ng x&y, pagkopya sa kanila `Block` nang paisa-isang Dapat i-unroll ng optimizer ang loop para sa karamihan sa mga uri ng NB
    // Hindi namin ay maaaring gumamit ng isang para sa loop bilang ang `range` impl tawag `mem::swap` recursively
    //
    let mut i = 0;
    while i + block_size <= len {
        // Lumikha ng ilang uninitialized na memorya bilang puwang ng simula na Pagdeklara ng `t` dito na iniiwasan ang pag-align ng stack kapag ang loop na ito ay hindi nagamit
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // KALIGTASAN: Bilang `i < len`, at bilang tumatawag ay dapat na ginagarantiyahan na ang `x` at `y` ay wasto
        // para sa `len` bytes, ang `x + i` at `y + i` ay dapat na wastong mga address, na tumutupad sa kontrata sa kaligtasan para sa `add`.
        //
        // Gayundin, dapat na garantiya ng tumatawag na ang `x` at `y` ay wasto para sa mga pagsusulat, maayos na nakahanay, at hindi nag-o-overlap, na natutupad ang kontrata sa kaligtasan para sa `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Ipagpalit ang isang bloke ng bytes ng x&y, gamit ang t bilang isang pansamantalang buffer Dapat itong ma-optimize sa mahusay na mga pagpapatakbo ng SIMD kung saan magagamit
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Ipagpalit ang anumang natitirang byte
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // KALIGTASAN: tingnan ang nakaraang komento sa kaligtasan.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Inililipat ang `src` sa itinuro `dst`, na ibinabalik ang dating halaga ng `dst`.
///
/// Ni ang halaga ay hindi nahulog.
///
/// Ang pagpapaandar na ito ay semantically katumbas ng [`mem::replace`] maliban na ito ay nagpapatakbo sa mga hilaw na payo sa halip na mga sanggunian.
/// Kapag magagamit ang mga sanggunian, dapat na mas gusto ang [`mem::replace`].
///
/// # Safety
///
/// Pag-uugali ay hindi maliwanag kung ang alinman sa mga sumusunod na kondisyon ay nilabag:
///
/// * `dst` dapat [valid] para sa parehong nagbabasa at nagsusulat.
///
/// * `dst` ay dapat na maayos na hile-hilera.
///
/// * `dst` dapat ituro sa isang maayos na naisimulang halaga ng uri `T`.
///
/// Tandaan na kahit na ang `T` ay may sukat `0`, ang pointer ay dapat na hindi NUL at maayos na nakahanay.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` ay magkakaroon ng parehong epekto nang hindi nangangailangan ng mga hindi ligtas na block.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // KALIGTASAN: dapat magagarantiya ng tumatawag na ang `dst` ay wasto upang maging
    // i-cast sa isang nababagong sanggunian (wasto para sa mga pagsusulat, nakahanay, pinasimuno), at hindi maaaring mag-overlap `src` dahil ang `dst` ay dapat na magturo sa isang natatanging inilalaan na bagay.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // hindi maaaring mag-overlap
    }
    src
}

/// Binabasa ang halaga mula sa `src` nang hindi ito inililipat.Iiwan nito ang memorya sa `src` na hindi nagbago.
///
/// # Safety
///
/// Pag-uugali ay hindi maliwanag kung ang alinman sa mga sumusunod na kondisyon ay nilabag:
///
/// * `src` dapat [valid] para mabasa.
///
/// * `src` dapat ay maayos na nakahanay.Gumamit ng [`read_unaligned`] kung hindi ito ang kaso.
///
/// * `src` dapat ituro sa isang maayos na naisimulang halaga ng uri `T`.
///
/// Tandaan na kahit na ang `T` ay may sukat `0`, ang pointer ay dapat na hindi NUL at maayos na nakahanay.
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Mano-manong ipatupad ang [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Lumikha ng isang maliit na kopya ng halaga sa `a` sa `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ang paglabas sa puntong ito (alinman sa malinaw na pagbabalik o sa pamamagitan ng pagtawag sa isang pagpapaandar na kung saan ang panics) ay magiging sanhi ng pagbaba ng halaga sa `tmp` habang ang parehong halaga ay isinangguni pa rin ng `a`.
///         // Maaari itong mag-trigger ng hindi natukoy na pag-uugali kung ang `T` ay hindi `Copy`.
/////
/////
///
///         // Lumikha ng isang maliit na kopya ng halaga sa `b` sa `a`.
///         // Ito ay ligtas dahil ang mga nababagong sanggunian ay hindi maaaring alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Tulad ng nasa itaas, ang paglabas dito ay maaaring magpalitaw ng hindi natukoy na pag-uugali dahil ang parehong halaga ay isinangguni ng `a` at `b`.
/////
///
///         // Ilipat ang `tmp` sa `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` ay inilipat (`write` tumatagal ng pagmamay-ari ng pangalawang argumento), kaya walang nahulog na implicit dito.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Pagmamay-ari ng naibalik na Halaga
///
/// `read` lumilikha ng isang maliit na kopya ng `T`, hindi alintana kung ang `T` ay [`Copy`].
/// Kung ang `T` ay hindi [`Copy`], ang paggamit ng parehong ibinalik na halaga at ang halaga sa `*src` ay maaaring lumabag sa kaligtasan ng memorya.
/// Tandaan na ang pagtatalaga sa `*src` ay binibilang bilang isang paggamit dahil susubukan nitong i-drop ang halaga sa `* src`.
///
/// [`write()`] ay maaaring magamit upang mai-overlap ang data nang hindi ito sanhi ng pagbagsak nito.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` tumuturo ngayon sa parehong napapailalim na memorya ng `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Ang pagtatalaga sa `s2` ay sanhi ng pagbaba ng orihinal na halaga.
///     // Higit pa sa puntong ito, ang `s` ay hindi na dapat gamitin, dahil ang napapailalim na memorya ay napalaya.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Ang pagtatalaga sa `s` ay magiging sanhi ng pagbaba ng dating halaga, na magreresulta sa hindi natukoy na pag-uugali.
/////
///     // s= String::from("bar");//ERROR
///
///     // `ptr::write` ay maaaring magamit upang patungan ang isang halaga nang hindi nahuhulog ito.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // KALIGTASAN: dapat magagarantiya ng tumatawag na ang `src` ay wasto para sa mga nagbabasa.
    // `src` hindi maaaring mag-overlap `tmp` dahil ang `tmp` ay inilalaan lamang sa stack bilang isang hiwalay na inilalaan na object.
    //
    //
    // Gayundin, dahil nagsulat lamang kami ng wastong halaga sa `tmp`, ginagarantiyahan itong maayos na maisasagawa.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Binabasa ang halaga mula sa `src` nang hindi ito inililipat.Iiwan nito ang memorya sa `src` na hindi nagbago.
///
/// Hindi tulad ng [`read`], ang `read_unaligned` ay gumagana sa mga hindi nakaayos na mga payo.
///
/// # Safety
///
/// Pag-uugali ay hindi maliwanag kung ang alinman sa mga sumusunod na kondisyon ay nilabag:
///
/// * `src` dapat [valid] para mabasa.
///
/// * `src` dapat ituro sa isang maayos na naisimulang halaga ng uri `T`.
///
/// Tulad ng [`read`], ang `read_unaligned` ay lumilikha ng isang maliit na kopya ng `T`, hindi alintana kung ang `T` ay [`Copy`].
/// Kung ang `T` ay hindi [`Copy`], ang paggamit ng parehong ibinalik na halaga at ang halaga sa `*src` ay maaaring [violate memory safety][read-ownership].
///
/// Tandaan na kahit na ang `T` ay may sukat `0`, ang pointer ay dapat na hindi NUL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Sa `packed` struct
///
/// Sa kasalukuyan imposibleng lumikha ng mga hilaw na pahiwatig sa hindi nakaayos na mga patlang ng isang naka-pack na istr.
///
/// Sinusubukang lumikha ng isang hilaw na pointer sa isang `unaligned` na patlang ng istruktura na may isang expression tulad ng `&packed.unaligned as *const FieldType` ay lumilikha ng isang intermedyang hindi nakaayos na sanggunian bago i-convert iyon sa isang raw pointer.
///
/// Ang sanggunian na ito ay pansamantala at kaagad na cast ay hindi mahalaga dahil palaging inaasahan ng tagatala na maayos na nakahanay.
/// Bilang isang resulta, ang paggamit ng `&packed.unaligned as *const FieldType` ay sanhi ng agarang* hindi natukoy na pag-uugali * sa iyong programa.
///
/// Ang isang halimbawa ng hindi dapat gawin at kung paano ito nauugnay sa `read_unaligned` ay:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Dito tinatangka naming kunin ang address ng isang 32-bit na integer na hindi nakahanay.
///     let unaligned =
///         // Ang isang pansamantalang hindi nakahanay na sanggunian ay nilikha dito na nagreresulta sa hindi natukoy na pag-uugali anuman ang ginamit na sanggunian o hindi.
/////
///         &packed.unaligned
///         // Ang pag-cast sa isang raw pointer ay hindi makakatulong;nangyari na ang pagkakamali.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Ang pag-access ng mga hindi nakaayos na patlang nang direkta sa hal. `packed.unaligned` ay ligtas subalit.
///
///
///
///
///
///
// FIXME: I-update ang mga doc batay sa kinalabasan ng RFC #2582 at mga kaibigan.
/// # Examples
///
/// Basahin ang isang halaga ng usize mula sa isang byte buffer:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // KALIGTASAN: dapat magagarantiya ng tumatawag na ang `src` ay wasto para sa mga nagbabasa.
    // `src` hindi maaaring mag-overlap `tmp` dahil ang `tmp` ay inilalaan lamang sa stack bilang isang hiwalay na inilalaan na object.
    //
    //
    // Gayundin, dahil nagsulat lamang kami ng wastong halaga sa `tmp`, ginagarantiyahan itong maayos na maisasagawa.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Nag-o-overwrite ng isang lokasyon ng memorya na may ibinigay na halaga nang hindi binabasa o nahuhulog ang dating halaga.
///
/// `write` ay hindi nahuhulog ang mga nilalaman ng `dst`.
/// Ito ay ligtas, ngunit maaari itong tumagas ng mga paglalaan o mapagkukunan, kaya't dapat mag-ingat na huwag ma-overlap ang isang bagay na dapat na mahulog.
///
///
/// Bukod pa rito, ito ay hindi drop `src`.Magkakahulugang, `src` ay inilipat sa lokasyon nakatutok sa pamamagitan `dst`.
///
/// Angkop ito para sa pagsisimula ng uninitialized memory, o pag-o-overtake ng memorya na dating naging [`read`] mula.
///
/// # Safety
///
/// Pag-uugali ay hindi maliwanag kung ang alinman sa mga sumusunod na kondisyon ay nilabag:
///
/// * `dst` dapat [valid] para sa magsusulat.
///
/// * `dst` dapat ay maayos na nakahanay.Gumamit ng [`write_unaligned`] kung hindi ito ang kaso.
///
/// Tandaan na kahit na ang `T` ay may sukat `0`, ang pointer ay dapat na hindi NUL at maayos na nakahanay.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Mano-manong ipatupad ang [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Lumikha ng isang maliit na kopya ng halaga sa `a` sa `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ang paglabas sa puntong ito (alinman sa malinaw na pagbabalik o sa pamamagitan ng pagtawag sa isang pagpapaandar na kung saan ang panics) ay magiging sanhi ng pagbaba ng halaga sa `tmp` habang ang parehong halaga ay isinangguni pa rin ng `a`.
///         // Maaari itong mag-trigger ng hindi natukoy na pag-uugali kung ang `T` ay hindi `Copy`.
/////
/////
///
///         // Lumikha ng isang maliit na kopya ng halaga sa `b` sa `a`.
///         // Ito ay ligtas dahil ang mga nababagong sanggunian ay hindi maaaring alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Tulad ng nasa itaas, ang paglabas dito ay maaaring magpalitaw ng hindi natukoy na pag-uugali dahil ang parehong halaga ay isinangguni ng `a` at `b`.
/////
///
///         // Ilipat ang `tmp` sa `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` ay inilipat (`write` tumatagal ng pagmamay-ari ng pangalawang argumento), kaya walang nahulog na implicit dito.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Tumatawag kami ng mga intrinsik nang direkta upang maiwasan ang mga tawag sa pag-andar sa nabuong code dahil ang `intrinsics::copy_nonoverlapping` ay isang pag-andar ng pambalot.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // KALIGTASAN: dapat igagarantiya ng tumatawag na ang `dst` ay wasto para sa pagsusulat.
    // `dst` hindi maaaring mag-overlap `src` dahil ang tumatawag ay may nababagong pag-access sa `dst` habang ang `src` ay pagmamay-ari ng pagpapaandar na ito.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Nag-o-overwrite ng isang lokasyon ng memorya na may ibinigay na halaga nang hindi binabasa o nahuhulog ang dating halaga.
///
/// Hindi tulad ng [`write()`], ang pointer ay maaaring hindi nakahanay.
///
/// `write_unaligned` ay hindi nahuhulog ang mga nilalaman ng `dst`.Ito ay ligtas, ngunit maaari itong mahayag alokasyon o mga mapagkukunan, kaya pag-aalaga ay dapat madala na hindi patungan ang isang bagay na dapat na ilagay.
///
/// Bukod pa rito, ito ay hindi drop `src`.Magkakahulugang, `src` ay inilipat sa lokasyon nakatutok sa pamamagitan `dst`.
///
/// Angkop ito para sa pagsisimula ng uninitialized memory, o pag-o-overtake ng memorya na dati nang nabasa ng [`read_unaligned`].
///
/// # Safety
///
/// Pag-uugali ay hindi maliwanag kung ang alinman sa mga sumusunod na kondisyon ay nilabag:
///
/// * `dst` dapat [valid] para sa magsusulat.
///
/// Tandaan na kahit na ang `T` ay may sukat `0`, ang pointer ay dapat na hindi NUL.
///
/// [valid]: self#safety
///
/// ## Sa `packed` struct
///
/// Sa kasalukuyan imposibleng lumikha ng mga hilaw na pahiwatig sa hindi nakaayos na mga patlang ng isang naka-pack na istr.
///
/// Sinusubukang lumikha ng isang hilaw na pointer sa isang `unaligned` na patlang ng istruktura na may isang expression tulad ng `&packed.unaligned as *const FieldType` ay lumilikha ng isang intermedyang hindi nakaayos na sanggunian bago i-convert iyon sa isang raw pointer.
///
/// Ang sanggunian na ito ay pansamantala at kaagad na cast ay hindi mahalaga dahil palaging inaasahan ng tagatala na maayos na nakahanay.
/// Bilang isang resulta, ang paggamit ng `&packed.unaligned as *const FieldType` ay sanhi ng agarang* hindi natukoy na pag-uugali * sa iyong programa.
///
/// Ang isang halimbawa ng hindi dapat gawin at kung paano ito nauugnay sa `write_unaligned` ay:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Dito tinatangka naming kunin ang address ng isang 32-bit na integer na hindi nakahanay.
///     let unaligned =
///         // Ang isang pansamantalang hindi nakahanay na sanggunian ay nilikha dito na nagreresulta sa hindi natukoy na pag-uugali anuman ang ginamit na sanggunian o hindi.
/////
///         &mut packed.unaligned
///         // Ang pag-cast sa isang raw pointer ay hindi makakatulong;nangyari na ang pagkakamali.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Ang pag-access ng mga hindi nakaayos na patlang nang direkta sa hal. `packed.unaligned` ay ligtas subalit.
///
///
///
///
///
///
///
///
///
// FIXME: I-update ang mga doc batay sa kinalabasan ng RFC #2582 at mga kaibigan.
/// # Examples
///
/// Sumulat ng isang halaga ng usize sa isang byte buffer:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // KALIGTASAN: dapat igagarantiya ng tumatawag na ang `dst` ay wasto para sa pagsusulat.
    // `dst` hindi maaaring mag-overlap `src` dahil ang tumatawag ay may nababagong pag-access sa `dst` habang ang `src` ay pagmamay-ari ng pagpapaandar na ito.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Tumatawag kami nang direkta sa intrinsik upang maiwasan ang mga tawag sa pag-andar sa nabuong code.
        intrinsics::forget(src);
    }
}

/// Nagsasagawa ng isang pabagu-bago ng isip na basahin ang halaga mula sa `src` nang hindi ito nililipat.Iiwan nito ang memorya sa `src` na hindi nagbago.
///
/// Ang mga pabagu-bago na pagpapatakbo ay inilaan upang kumilos sa memorya ng I/O, at garantisadong hindi mai-elided o muling ayusin ng tagatala sa iba pang mga pabagu-bago na operasyon.
///
/// # Notes
///
/// Ang Rust ay kasalukuyang walang isang mahigpit at pormal na tinukoy na modelo ng memorya, kaya ang tumpak na semantiko ng kung ano ang ibig sabihin ng "volatile" dito ay maaaring magbago sa paglipas ng panahon.
/// Sinabi na, ang mga semantika ay halos palaging magtatapos medyo katulad sa [C11's definition of volatile][c11].
///
/// Hindi dapat baguhin ng tagatala ang kamag-anak na pagkakasunud-sunod o bilang ng mga pabagu-bago ng isip na pagpapatakbo ng memorya.
/// Gayunpaman, ang pabagu-bago ng isip na pagpapatakbo ng memorya sa mga uri na walang sukat (hal., Kung ang isang uri ng zero na laki ay naipasa sa `read_volatile`) ay mga noops at maaaring balewalain.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Pag-uugali ay hindi maliwanag kung ang alinman sa mga sumusunod na kondisyon ay nilabag:
///
/// * `src` dapat [valid] para mabasa.
///
/// * `src` ay dapat na maayos na hile-hilera.
///
/// * `src` dapat ituro sa isang maayos na naisimulang halaga ng uri `T`.
///
/// Tulad ng [`read`], ang `read_volatile` ay lumilikha ng isang maliit na kopya ng `T`, hindi alintana kung ang `T` ay [`Copy`].
/// Kung ang `T` ay hindi [`Copy`], ang paggamit ng parehong ibinalik na halaga at ang halaga sa `*src` ay maaaring [violate memory safety][read-ownership].
/// Gayunpaman, ang pagtatago ng mga hindi-[Kopya`] na mga uri sa pabagu-bago ng memorya ay halos tiyak na hindi tama.
///
/// Tandaan na kahit na ang `T` ay may sukat `0`, ang pointer ay dapat na hindi NUL at maayos na nakahanay.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Tulad ng sa C, kung ang isang operasyon ay pabagu-bago ay walang kinalaman sa anumang mga katanungan na may kinalaman sa kasabay na pag-access mula sa maraming mga thread.Ang mga pabagu-bago na pag-access ay kumilos nang eksakto tulad ng mga hindi pang-atom na pag-access sa bagay na iyon.
///
/// Sa partikular, ang isang lahi sa pagitan ng isang `read_volatile` at anumang operasyon ng pagsusulat sa parehong lokasyon ay hindi natukoy na pag-uugali.
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Hindi panic upang mapanatili ang maliit na epekto ng codegen.
        abort();
    }
    // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Nagsasagawa ng isang pabagu-bago na pagsulat ng isang lokasyon ng memorya na may ibinigay na halaga nang hindi binabasa o nahuhulog ang dating halaga.
///
/// Ang mga pabagu-bago na pagpapatakbo ay inilaan upang kumilos sa memorya ng I/O, at garantisadong hindi mai-elided o muling ayusin ng tagatala sa iba pang mga pabagu-bago na operasyon.
///
/// `write_volatile` ay hindi nahuhulog ang mga nilalaman ng `dst`.Ito ay ligtas, ngunit maaari itong mahayag alokasyon o mga mapagkukunan, kaya pag-aalaga ay dapat madala na hindi patungan ang isang bagay na dapat na ilagay.
///
/// Bukod pa rito, ito ay hindi drop `src`.Magkakahulugang, `src` ay inilipat sa lokasyon nakatutok sa pamamagitan `dst`.
///
/// # Notes
///
/// Ang Rust ay kasalukuyang walang isang mahigpit at pormal na tinukoy na modelo ng memorya, kaya ang tumpak na semantiko ng kung ano ang ibig sabihin ng "volatile" dito ay maaaring magbago sa paglipas ng panahon.
/// Sinabi na, ang mga semantika ay halos palaging magtatapos medyo katulad sa [C11's definition of volatile][c11].
///
/// Hindi dapat baguhin ng tagatala ang kamag-anak na pagkakasunud-sunod o bilang ng mga pabagu-bago ng isip na pagpapatakbo ng memorya.
/// Gayunpaman, ang pabagu-bago ng isip na pagpapatakbo ng memorya sa mga uri na walang sukat (hal., Kung ang isang uri ng zero na laki ay naipasa sa `write_volatile`) ay mga noops at maaaring balewalain.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Pag-uugali ay hindi maliwanag kung ang alinman sa mga sumusunod na kondisyon ay nilabag:
///
/// * `dst` dapat [valid] para sa magsusulat.
///
/// * `dst` ay dapat na maayos na hile-hilera.
///
/// Tandaan na kahit na ang `T` ay may sukat `0`, ang pointer ay dapat na hindi NUL at maayos na nakahanay.
///
/// [valid]: self#safety
///
/// Tulad ng sa C, kung ang isang operasyon ay pabagu-bago ay walang kinalaman sa anumang mga katanungan na may kinalaman sa kasabay na pag-access mula sa maraming mga thread.Ang mga pabagu-bago na pag-access ay kumilos nang eksakto tulad ng mga hindi pang-atom na pag-access sa bagay na iyon.
///
/// Sa partikular, ang isang lahi sa pagitan ng isang `write_volatile` at anumang iba pang operasyon (pagbabasa o pagsulat) sa parehong lokasyon ay hindi natukoy na pag-uugali.
///
/// # Examples
///
/// Pangunahing paggamit:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Hindi panic upang mapanatili ang maliit na epekto ng codegen.
        abort();
    }
    // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Ihanay ang pointer `p`.
///
/// Kalkulahin ang offset (sa mga tuntunin ng mga elemento ng `stride` stride) na kailangang mailapat sa pointer `p` upang ang pointer `p` ay makahanay sa `a`.
///
/// Note: Ang pagpapatupad na ito ay maingat na pinasadya upang hindi panic.Ito ay UB para sa ito sa panic.
/// Ang tanging tunay na pagbabago na magagawa dito ay ang pagbabago ng `INV_TABLE_MOD_16` at mga nauugnay na pare-pareho.
///
/// Kung magpasya man tayo na gawing posible na tawagan ang intrinsic sa `a` na hindi isang kapangyarihan-ng-dalawa, marahil ay mas maingat na baguhin lamang sa isang walang muwang na pagpapatupad sa halip na subukang iakma ito upang mapaunlakan ang pagbabago na iyon.
///
///
/// Anumang mga katanungan ay pumunta sa@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Ang direktang paggamit ng mga intrinsik na ito ay nagpapabuti sa codegen nang malaki sa antas ng opt <=
    // 1, kung saan ang mga bersyon ng pamamaraan ng mga pagpapatakbo na ito ay hindi naka-linya.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Kalkulahin ang multiplicative modular kabaligtaran ng `x` modulo `m`.
    ///
    /// Ang pagpapatupad na ito ay pinasadya para sa `align_offset` at may mga sumusunod na preconditions:
    ///
    /// * `m` ay isang kapangyarihan-ng-dalawa;
    /// * `x < m`; (kung `x ≥ m`, ipasa ang `x % m` sa halip)
    ///
    /// Ang pagpapatupad ng pagpapaandar na ito ay hindi dapat panic.Kailanman
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplicative modular inverse table modulo 2⁴=16.
        ///
        /// Tandaan, na ang talahanayan na ito ay hindi naglalaman ng mga halaga kung saan walang kabaligtaran (ibig sabihin, para sa `0⁻¹ mod 16`, `2⁻¹ mod 16`, atbp.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo kung saan inilaan ang `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // KALIGTASAN: Ang `m` ay kinakailangan upang maging isang power-of-two, kaya't non-zero.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Inuulit namin ang "up" gamit ang sumusunod na formula:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // hanggang 2²ⁿ ≥ m.Pagkatapos ay maaari nating bawasan ang aming ninanais na `m` sa pamamagitan ng pagkuha ng resulta na `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Tandaan, na sinasadya naming ginagamit ang mga pagpapatakbo ng pambalot dito-ang orihinal na pormula ay gumagamit ng hal, pagbabawas `mod n`.
                // Ito ay ganap na pagmultahin na gawin ang mga ito `mod usize::MAX` sa halip, dahil kinukuha namin ang resulta `mod n` sa dulo pa rin.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // KALIGTASAN: Ang `a` ay isang power-of-two, samakatuwid non-zero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` Ang kaso ay maaaring makalkula nang mas simple sa pamamagitan ng `-p (mod a)`, ngunit ang paggawa nito ay pumipigil sa kakayahan ng LLVM na pumili ng mga tagubilin tulad ng `lea`.Sa halip ay makalkula namin
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // na kung saan namamahagi ng mga operasyon sa buong ng pagkarga-tindig, ngunit pessimizing `and` sapat na para sa LLVM upang magawang gamitin ang iba't-ibang mga pag-optimize ito alam tungkol sa.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Nakahanay na.Yay!
        return 0;
    } else if stride == 0 {
        // Kung ang pointer ay hindi nakahanay, at ang elemento ay zero-size, kung gayon walang dami ng mga elemento ang kailanman na magpapantay sa pointer.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // KALIGTASAN: ang isang ay kapangyarihan-ng-dalawa samakatuwid ay hindi-zero.stride==0 kaso ang hinawakan sa itaas.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // KALIGTASAN: ang gcdpow ay may pang-itaas na higit sa bilang ng mga piraso sa isang usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // KALIGTASAN: ang gcd ay palaging mas malaki o katumbas ng 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Nalulutas ng branch na ito ang sumusunod na equation ng linear na pagkakasama:
        //
        // ` p + so = 0 mod a `
        //
        // `p` narito ang halaga ng pointer, `s`, hakbang ng `T`, `o` offset sa `T`s, at `a`, ang hiniling na pagkakahanay.
        //
        // Sa `g = gcd(a, s)`, at ang itaas na kondisyon asserting na `p` ay mahahati sa pamamagitan `g` din, maaari naming tukuyin `a' = a/g`, `s' = s/g`, `p' = p/g`, pagkatapos ito ay magiging katumbas ng:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Ang unang termino ay "the relative alignment of `p` to `a`" (hinati ng `g`), ang pangalawang term ay "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (muling hinati ng `g`).
        //
        // Kinakailangan ang dibisyon ng `g` upang maisagawa ang kabaligtaran ng mabuti kung ang `a` at `s` ay hindi co-prime.
        //
        // Bukod dito, ang resulta na ginawa ng solusyon na ito ay hindi "minimal", kaya kinakailangan na gawin ang resulta na `o mod lcm(s, a)`.Maaari naming palitan ang `lcm(s, a)` sa isang `a'` lamang.
        //
        //
        //
        //
        //

        // KALIGTASAN: Ang `gcdpow` ay may pang-itaas na hindi mas malaki kaysa sa bilang ng mga sumusunod na 0-bits sa `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // KALIGTASAN: Ang `a2` ay hindi zero.Ang paglilipat ng `a` ng `gcdpow` ay hindi maaaring ilipat ang anuman sa mga itinakdang mga piraso
        // sa `a` (kung saan mayroon itong eksaktong isa).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // KALIGTASAN: Ang `gcdpow` ay may pang-itaas na hindi mas malaki kaysa sa bilang ng mga sumusunod na 0-bits sa `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // KALIGTASAN: Ang `gcdpow` ay may pang-itaas na hindi mas malaki kaysa sa bilang ng mga sumusunod na 0-bits sa
        // `a`.
        // Bukod dito, ang pagbabawas ay hindi maaaring mag-overflow, dahil ang `a2 = a >> gcdpow` ay palaging magiging mahigpit na mas malaki kaysa sa `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // KALIGTASAN: Ang `a2` ay isang power-of-two, tulad ng napatunayan sa itaas.Ang `s2` ay mahigpit na mas mababa sa `a2`
        // dahil ang `(s % a) >> gcdpow` ay mahigpit na mas mababa sa `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Hindi talaga nakahanay.
    usize::MAX
}

/// Naghahambing ng mga hilaw na payo para sa pagkakapantay-pantay.
///
/// Ito ay pareho sa paggamit ng `==` operator, ngunit mas mababa sa generic:
/// ang mga argumento ay dapat na `*const T` raw pointers, hindi anumang bagay na nagpapatupad ng `PartialEq`.
///
/// Ito ay maaaring gamitin upang ihambing `&T` sanggunian (na pumilit sa `*const T` nang kataon lamang) sa pamamagitan ng kanilang address sa halip ng paghahambing ng mga halaga point nila (na kung saan ay kung ano ang ginagawa ng `PartialEq for &T` pagpapatupad).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Ang mga hiwa ay inihambing din ng kanilang haba (fat pointers):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Ang Traits ay inihambing din sa pamamagitan ng kanilang pagpapatupad:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Ang mga pahiwatig ay may pantay na mga address.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Ang mga bagay ay may pantay na address, ngunit ang `Trait` ay may iba't ibang pagpapatupad.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Ang pag-convert ng sanggunian sa isang `*const u8` ay naghahambing sa pamamagitan ng address.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash isang raw pointer.
///
/// Maaari itong magamit upang ma-hash ang isang sanggunian na `&T` (na pinipilit ang `*const T` na implicit) ng address nito sa halip na ang halagang itinuturo nito (na kung saan ang ginagawa ng pagpapatupad ng `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Nagpapatupad para sa mga point point ng pag-andar
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Ang intermediate cast bilang usize ay kinakailangan para sa AVR
                // kaya na address space ng source function na pointer ay pananatilihin sa huling function na pointer.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Ang intermediate cast bilang usize ay kinakailangan para sa AVR
                // kaya na address space ng source function na pointer ay pananatilihin sa huling function na pointer.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Walang mga pag-andar na variadic na may 0 mga parameter
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Lumikha ng isang `const` raw pointer sa isang lugar, nang hindi lumilikha ng isang intermediate na sanggunian.
///
/// Ang paglikha ng isang sanggunian sa `&`/`&mut` ay pinapayagan lamang kung ang pointer ay maayos na nakahanay at tumuturo sa inisyal na data.
/// Para sa mga kaso kung saan hindi nagtataglay ng mga kinakailangang iyon, dapat gamitin sa halip ang mga raw point.
/// Gayunpaman, lumilikha ang `&expr as *const _` ng isang sanggunian bago ito ihatid sa isang hilaw na pointer, at ang sanggunian na iyon ay napapailalim sa parehong mga patakaran tulad ng lahat ng iba pang mga sanggunian.
///
/// macro na ito ay maaaring lumikha ng isang raw pointer *walang* ang paglikha ng isang reference muna.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` lilikha ng isang hindi nakaayos na sanggunian, at sa gayon ay hindi Natukoy na Pag-uugali!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Gumawa ng isang `mut` raw pointer sa isang lugar, nang walang paglikha ng isang intermediate reference.
///
/// Ang paglikha ng isang sanggunian sa `&`/`&mut` ay pinapayagan lamang kung ang pointer ay maayos na nakahanay at tumuturo sa inisyal na data.
/// Para sa mga kaso kung saan hindi nagtataglay ng mga kinakailangang iyon, dapat gamitin sa halip ang mga raw point.
/// Gayunpaman, lumilikha ang `&mut expr as *mut _` ng isang sanggunian bago ito ihatid sa isang hilaw na pointer, at ang sanggunian na iyon ay napapailalim sa parehong mga patakaran tulad ng lahat ng iba pang mga sanggunian.
///
/// macro na ito ay maaaring lumikha ng isang raw pointer *walang* ang paglikha ng isang reference muna.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` lilikha ng isang hindi nakaayos na sanggunian, at sa gayon ay hindi Natukoy na Pag-uugali!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` pinipilit ang pagkopya sa patlang sa halip na lumikha ng isang sanggunian.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}