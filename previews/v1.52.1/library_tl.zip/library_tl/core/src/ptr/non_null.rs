use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ngunit hindi-zero at covariant.
///
/// Kadalasan ito ang tamang bagay na gagamitin kapag nagtatayo ng mga istruktura ng data gamit ang mga hilaw na pahiwatig, ngunit sa huli ay mas mapanganib na gamitin dahil sa mga karagdagang katangian.Kung hindi ka sigurado kung dapat mong gumamit ng `NonNull<T>`, gumamit lamang ng `*mut T`!
///
/// Hindi tulad ng `*mut T`, ang pointer ay dapat palaging hindi null, kahit na ang pointer ay hindi kailanman na-disferferensya.Ito ay upang ang mga enum ay maaaring gumamit ng ipinagbabawal na halagang ito bilang isang diskriminasyon-ang `Option<NonNull<T>>` ay may parehong laki sa `* mut T`.
/// Subalit ang pointer ay maaari pa ring lumawit kung hindi ito na-disferferensya.
///
/// Hindi tulad ng `*mut T`, ang `NonNull<T>` ay napiling maging covariant sa `T`.Ginagawa nitong posible na gamitin ang `NonNull<T>` kapag nagtatayo ng mga uri ng covariant, ngunit ipinakikilala ang peligro ng kawalang-kabuluhan kung ginamit sa isang uri na hindi dapat talagang maging covariant.
/// (Ang kabaligtaran na pagpipilian ay ginawa para sa `*mut T` kahit na sa technically ang pagkabagabag ay maaaring sanhi lamang ng pagtawag sa mga hindi ligtas na pag-andar.)
///
/// Ang Covariance ay tama para sa pinaka-ligtas na mga abstraction, tulad ng `Box`, `Rc`, `Arc`, `Vec`, at `LinkedList`.Ito ang kaso dahil nagbibigay sila ng isang pampublikong API na sumusunod sa normal na ibinahaging XOR na nababagong mga patakaran ng Rust.
///
/// Kung ang iyong uri ay hindi ligtas na maging covariant, dapat mong tiyakin na naglalaman ito ng ilang karagdagang larangan upang magbigay ng invariance.Kadalasan ang patlang na ito ay magiging isang uri ng [`PhantomData`] tulad ng `PhantomData<Cell<T>>` o `PhantomData<&'a mut T>`.
///
/// Pansinin na ang `NonNull<T>` ay mayroong isang halimbawa ng `From` para sa `&T`.Gayunpaman, hindi nito binabago ang katotohanang ang pag-mutate sa pamamagitan ng isang (pointer na nagmula sa isang) nakabahaging sanggunian ay hindi natukoy na pag-uugali maliban kung ang pag-mutate ay nangyayari sa loob ng isang [`UnsafeCell<T>`].Ang parehong napupunta para sa paglikha ng isang nagbabago reference mula sa isang ibinahaging reference.
///
/// Kapag ginagamit ang halimbawa ng `From` nang walang `UnsafeCell<T>`, responsibilidad mong tiyakin na ang `as_mut` ay hindi kailanman tinawag, at ang `as_ptr` ay hindi kailanman ginamit para sa pag-mutate.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` ang mga payo ay hindi `Send` sapagkat ang data na kanilang tinukoy ay maaaring maging alias.
// NB, ang impl na ito ay hindi kinakailangan, ngunit dapat magbigay ng mas mahusay na mga mensahe ng error.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` ang mga payo ay hindi `Sync` sapagkat ang data na kanilang tinukoy ay maaaring maging alias.
// NB, ang impl na ito ay hindi kinakailangan, ngunit dapat magbigay ng mas mahusay na mga mensahe ng error.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Lumilikha ng isang bagong `NonNull` na nakabitin, ngunit maayos na nakahanay.
    ///
    /// Kapaki-pakinabang ito para sa pagsisimula ng mga uri na tinatamad na inilalaan, tulad ng ginagawa ng `Vec::new`.
    ///
    /// Tandaan na ang halaga ng pointer ay maaaring potensyal na kumatawan sa isang wastong pointer sa isang `T`, na nangangahulugang hindi ito dapat gamitin bilang isang "not yet initialized" halaga ng sentinel.
    /// Ang mga uri na tamad na naglalaan ay dapat subaybayan ang pagsisimula sa ilang iba pang mga paraan.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // KALIGTASAN: Ang mem::align_of() ay nagbabalik ng isang di-zero na usize na pagkatapos ay itinapon
        // sa isang * mut T.
        // Samakatuwid, ang `ptr` ay hindi null at ang mga kundisyon para sa pagtawag sa new_unchecked() ay iginagalang.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Nagbabalik ng isang nakabahaging sanggunian sa halaga.Sa kaibahan sa [`as_ref`], hindi ito nangangailangan na ang halaga ay dapat na gawing una.
    ///
    /// Para sa mutable counterpart makita [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Kapag tumatawag ang paraan na ito, mayroon kang upang matiyak na ang lahat ng ang mga sumusunod ay totoo:
    ///
    /// * Ang pointer ay dapat na maayos na nakahanay.
    ///
    /// * Dapat itong "dereferencable" sa kahulugan na tinukoy sa [the module documentation].
    ///
    /// * Dapat mong ipataw ang mga patakaran sa aliasing ng Rust, dahil ang ibinalik na buhay na `'a` ay arbitraryong napili at hindi kinakailangang sumasalamin sa aktwal na buhay ng data.
    ///
    ///   Sa partikular, para sa tagal ng buhay na ito, ang memorya na itinuro ng pointer na hindi dapat ma-mutate (maliban sa loob ng `UnsafeCell`).
    ///
    /// Nalalapat ito kahit na ang resulta ng pamamaraang ito ay hindi nagamit!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // KALIGTASAN: dapat magagarantiya ng tumatawag na natutugunan ng `self` ang lahat ng
        // mga kinakailangan para sa isang sanggunian.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Ibinabalik ng isang natatanging mga sanggunian sa ang halaga.Sa kaibahan sa [`as_mut`], ito ay hindi nangangailangan na ang halaga ay dapat na-initialize.
    ///
    /// Para sa ibinahaging katapat tingnan ang [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Kapag tumatawag ang paraan na ito, mayroon kang upang matiyak na ang lahat ng ang mga sumusunod ay totoo:
    ///
    /// * Ang pointer ay dapat na maayos na nakahanay.
    ///
    /// * Dapat itong "dereferencable" sa kahulugan na tinukoy sa [the module documentation].
    ///
    /// * Dapat mong ipataw ang mga patakaran sa aliasing ng Rust, dahil ang ibinalik na buhay na `'a` ay arbitraryong napili at hindi kinakailangang sumasalamin sa aktwal na buhay ng data.
    ///
    ///   Sa partikular, sa tagal ng buhay na ito, ang memorya na itinuro ng pointer na hindi dapat ma-access (basahin o isulat) sa pamamagitan ng anumang iba pang pointer.
    ///
    /// Nalalapat ito kahit na ang resulta ng pamamaraang ito ay hindi nagamit!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // KALIGTASAN: dapat magagarantiya ng tumatawag na natutugunan ng `self` ang lahat ng
        // mga kinakailangan para sa isang sanggunian.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Lumilikha ng isang bagong `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` dapat na non-null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // KALIGTASAN: dapat garantiya ng tumatawag na ang `ptr` ay hindi null.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Lumilikha ng isang bagong `NonNull` kung ang `ptr` ay hindi null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // KALIGTASAN: Ang pointer ay naka-check na at hindi null
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Nagsasagawa ng parehong pag-andar bilang [`std::ptr::from_raw_parts`], maliban sa isang `NonNull` pointer ay naibalik, taliwas sa isang hilaw na `*const` pointer.
    ///
    ///
    /// Tingnan ang dokumentasyon ng [`std::ptr::from_raw_parts`] para sa higit pang mga detalye.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // KALIGTASAN: Ang resulta ng `ptr::from::raw_parts_mut` ay hindi null dahil ang `data_address` ay.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Nabulok ang isang (posibleng malawak) na punter sa address at mga sangkap ng metadata.
    ///
    /// Ang pointer ay maaaring maitaguyod sa paglaon kasama ang [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Nakukuha ang napapailalim na `*mut` pointer.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Nagbabalik ng isang nakabahaging sanggunian sa halaga.Kung ang halaga ay maaaring uninitialized, dapat gamitin ang [`as_uninit_ref`] sa halip.
    ///
    /// Para sa mutable counterpart tingnan ang [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Kapag tumatawag ang paraan na ito, mayroon kang upang matiyak na ang lahat ng ang mga sumusunod ay totoo:
    ///
    /// * Ang pointer ay dapat na maayos na nakahanay.
    ///
    /// * Dapat itong "dereferencable" sa kahulugan na tinukoy sa [the module documentation].
    ///
    /// * Dapat ituro ng pointer ang isang inisyal na halimbawa ng `T`.
    ///
    /// * Dapat mong ipataw ang mga patakaran sa aliasing ng Rust, dahil ang ibinalik na buhay na `'a` ay arbitraryong napili at hindi kinakailangang sumasalamin sa aktwal na buhay ng data.
    ///
    ///   Sa partikular, para sa tagal ng buhay na ito, ang memorya na itinuro ng pointer na hindi dapat ma-mutate (maliban sa loob ng `UnsafeCell`).
    ///
    /// Nalalapat ito kahit na ang resulta ng pamamaraang ito ay hindi nagamit!
    /// (Ang bahagi tungkol sa pagiging napasimula ay hindi pa ganap na napagpasyahan, ngunit hanggang sa ito ay, ang ligtas na diskarte lamang ay upang matiyak na sila ay tunay na naisaulo.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // KALIGTASAN: dapat magagarantiya ng tumatawag na natutugunan ng `self` ang lahat ng
        // mga kinakailangan para sa isang sanggunian.
        unsafe { &*self.as_ptr() }
    }

    /// Nagbabalik ng isang natatanging sanggunian sa halaga.Kung ang halaga ay maaaring uninitialized, dapat gamitin ang [`as_uninit_mut`] sa halip.
    ///
    /// Para sa ibinahaging katapat tingnan ang [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Kapag tumatawag ang paraan na ito, mayroon kang upang matiyak na ang lahat ng ang mga sumusunod ay totoo:
    ///
    /// * Ang pointer ay dapat na maayos na nakahanay.
    ///
    /// * Dapat itong "dereferencable" sa kahulugan na tinukoy sa [the module documentation].
    ///
    /// * Dapat ituro ng pointer ang isang inisyal na halimbawa ng `T`.
    ///
    /// * Dapat mong ipataw ang mga patakaran sa aliasing ng Rust, dahil ang ibinalik na buhay na `'a` ay arbitraryong napili at hindi kinakailangang sumasalamin sa aktwal na buhay ng data.
    ///
    ///   Sa partikular, sa tagal ng buhay na ito, ang memorya na itinuro ng pointer na hindi dapat ma-access (basahin o isulat) sa pamamagitan ng anumang iba pang pointer.
    ///
    /// Nalalapat ito kahit na ang resulta ng pamamaraang ito ay hindi nagamit!
    /// (Ang bahagi tungkol sa pagiging napasimula ay hindi pa ganap na napagpasyahan, ngunit hanggang sa ito ay, ang ligtas na diskarte lamang ay upang matiyak na sila ay tunay na naisaulo.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // KALIGTASAN: dapat magagarantiya ng tumatawag na natutugunan ng `self` ang lahat ng
        // mga kinakailangan para sa isang nababagong sanggunian.
        unsafe { &mut *self.as_ptr() }
    }

    /// Casts sa isang pointer ng ibang uri.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // KALIGTASAN: Ang `self` ay isang `NonNull` pointer na kinakailangang hindi null
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Lumilikha ng isang di-null raw hiwa mula sa isang manipis na pointer at isang haba.
    ///
    /// Ang `len` argument ay ang bilang ng mga **elemento**, hindi ang bilang ng mga byte.
    ///
    /// Ang pagpapaandar na ito ay ligtas, ngunit ang pag-aalis ng sangguniang halaga ng pagbalik ay hindi ligtas.
    /// Tingnan ang dokumentasyon ng [`slice::from_raw_parts`] para sa mga kinakailangan sa kaligtasan ng hiwa.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // lumikha ng isang slice pointer kapag nagsisimula sa isang pointer sa unang elemento
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Tandaan na ang halimbawang ito ay artipisyal na nagpapakita ng paggamit ng pamamaraang ito, ngunit `hayaan ang hiwa= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // KALIGTASAN: Ang `data` ay isang `NonNull` pointer na kinakailangang hindi null
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Ibinabalik ang haba ng isang hindi null raw hiwa.
    ///
    /// Ang naibalik na halaga ay ang bilang ng mga **elemento**, hindi ang bilang ng mga byte.
    ///
    /// Ang function na ito ay ligtas, kahit na kapag ang mga di-null raw slice hindi maaaring dereferenced sa isang slice dahil ang pointer ay hindi magkaroon ng isang wastong address.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Ibinabalik ang isang hindi null na pointer sa buffer ng slice.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // KALIGTASAN: Alam namin na ang `self` ay hindi null.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Nagbabalik ng isang hilaw na pointer sa buffer ng hiwa.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Nagbabalik ng isang nakabahaging sanggunian sa isang hiwa ng posibleng hindi na-unalisadong mga halagang.Sa kaibahan sa [`as_ref`], ito ay hindi nangangailangan na ang halaga ay dapat na-initialize.
    ///
    /// Para sa mutable counterpart makita [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Kapag tumatawag ang paraan na ito, mayroon kang upang matiyak na ang lahat ng ang mga sumusunod ay totoo:
    ///
    /// * Ang pointer ay dapat na [valid] para mabasa para sa `ptr.len() * mem::size_of::<T>()` maraming byte, at dapat itong maayos na nakahanay.Partikular na nangangahulugan ito:
    ///
    ///     * Ang buong saklaw ng memorya ng hiwa na ito ay dapat na nakapaloob sa loob ng isang solong inilalaan na bagay!
    ///       Ang mga hiwa ay hindi kailanman maaaring sumaklaw sa maraming mga inilalaan na mga bagay.
    ///
    ///     * Ang pointer ay dapat na nakahanay kahit na para sa mga hiwa ng walang haba.
    ///     Ang isang dahilan para dito ay ang pag-optimize ng layout ng enum ay maaaring umasa sa mga sanggunian (kasama ang mga hiwa ng anumang haba) na nakahanay at hindi null upang makilala ang mga ito mula sa iba pang data.
    ///
    ///     Maaari kang makakuha ng isang pointer na ay kapaki-pakinabang bilang `data` para sa hiwa zero-length gamit [`NonNull::dangling()`].
    ///
    /// * Ang kabuuang sukat na `ptr.len() * mem::size_of::<T>()` ng hiwa ay dapat na hindi mas malaki sa `isize::MAX`.
    ///   Tingnan ang dokumentasyon sa kaligtasan ng [`pointer::offset`].
    ///
    /// * Dapat mong ipataw ang mga patakaran sa aliasing ng Rust, dahil ang ibinalik na buhay na `'a` ay arbitraryong napili at hindi kinakailangang sumasalamin sa aktwal na buhay ng data.
    ///   Sa partikular, para sa tagal ng buhay na ito, ang memorya na itinuro ng pointer na hindi dapat ma-mutate (maliban sa loob ng `UnsafeCell`).
    ///
    /// Nalalapat ito kahit na ang resulta ng pamamaraang ito ay hindi nagamit!
    ///
    /// Tingnan din ang [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Nagbabalik ng isang natatanging sanggunian sa isang hiwa ng posibleng hindi na-unalisadong mga halagang.Sa kaibahan sa [`as_mut`], ito ay hindi nangangailangan na ang halaga ay dapat na-initialize.
    ///
    /// Para sa ibinahaging katapat tingnan ang [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Kapag tumatawag ang paraan na ito, mayroon kang upang matiyak na ang lahat ng ang mga sumusunod ay totoo:
    ///
    /// * Ang pointer ay dapat na [valid] para mabasa at magsusulat para sa `ptr.len() * mem::size_of::<T>()` maraming byte, at dapat itong maayos na nakahanay.Partikular na nangangahulugan ito:
    ///
    ///     * Ang buong saklaw ng memorya ng hiwa na ito ay dapat na nakapaloob sa loob ng isang solong inilalaan na bagay!
    ///       Ang mga hiwa ay hindi kailanman maaaring sumaklaw sa maraming mga inilalaan na mga bagay.
    ///
    ///     * Ang pointer ay dapat na nakahanay kahit na para sa mga hiwa ng walang haba.
    ///     Ang isang dahilan para dito ay ang pag-optimize ng layout ng enum ay maaaring umasa sa mga sanggunian (kasama ang mga hiwa ng anumang haba) na nakahanay at hindi null upang makilala ang mga ito mula sa iba pang data.
    ///
    ///     Maaari kang makakuha ng isang pointer na ay kapaki-pakinabang bilang `data` para sa hiwa zero-length gamit [`NonNull::dangling()`].
    ///
    /// * Ang kabuuang sukat na `ptr.len() * mem::size_of::<T>()` ng hiwa ay dapat na hindi mas malaki sa `isize::MAX`.
    ///   Tingnan ang dokumentasyon sa kaligtasan ng [`pointer::offset`].
    ///
    /// * Dapat mong ipataw ang mga patakaran sa aliasing ng Rust, dahil ang ibinalik na buhay na `'a` ay arbitraryong napili at hindi kinakailangang sumasalamin sa aktwal na buhay ng data.
    ///   Sa partikular, sa tagal ng buhay na ito, ang memorya na itinuro ng pointer na hindi dapat ma-access (basahin o isulat) sa pamamagitan ng anumang iba pang pointer.
    ///
    /// Nalalapat ito kahit na ang resulta ng pamamaraang ito ay hindi nagamit!
    ///
    /// Tingnan din ang [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Ito ay ligtas dahil ang `memory` ay wasto para sa mga nagbabasa at nagsusulat para sa `memory.len()` maraming mga byte.
    /// // Tandaan na ang pagtawag sa `memory.as_mut()` ay hindi pinapayagan dito dahil ang nilalaman ay maaaring maging uninitialized.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Nagbabalik ng isang hilaw na pointer sa isang elemento o subslice, nang hindi nagsasagawa ng mga hangganan sa pagsusuri.
    ///
    /// Ang pagtawag sa pamamaraang ito na may isang out-of-bounds index o kung hindi maaalis ang `self` ay *[hindi natukoy na pag-uugali]* kahit na ang nagresultang pointer ay hindi ginamit.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // KALIGTASAN: tinitiyak ng tumatawag na ang `self` ay hindi maalis at ang `index` na mga in-bound.
        // Bilang kinahinatnan, ang nagreresultang pointer ay hindi maaaring maging NUL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // KALIGTASAN: Ang isang Natatanging pointer ay hindi maaaring maging null, kaya ang mga kundisyon para sa
        // new_unchecked() ay iginagalang.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // KALIGTASAN: Ang isang nababagabag na sanggunian ay hindi maaaring maging null.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // KALIGTASAN: Ang isang sanggunian ay hindi maaaring maging null, kaya ang mga kundisyon para sa
        // new_unchecked() ay iginagalang.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}