use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Ibinabalik `true` kung ang pointer ay null.
    ///
    /// Tandaan na ang mga hindi naka-sukat na uri ay may maraming mga posibleng null pointer, dahil ang raw data pointer lamang ang isinasaalang-alang, hindi ang kanilang haba, vtable, atbp.
    /// Samakatuwid, ang dalawang mga payo na null ay maaaring hindi pa rin ihambing ang pantay sa bawat isa.
    ///
    /// ## Pag-uugali sa panahon ng pagsusuri ng Const
    ///
    /// Kapag ang pagpapaandar na ito ay ginagamit sa panahon ng pagsusuri ng const, maaari itong ibalik ang `false` para sa mga payo na magiging null sa runtime.
    /// Sa partikular, kapag ang isang pointer sa ilang memorya ay na-offset na lampas sa mga hangganan nito sa isang paraan na ang nagresultang pointer ay null, ang function ay ibabalik pa rin ang `false`.
    ///
    /// Walang paraan upang malaman ng CTFE ang ganap na posisyon ng memorya na iyon, kaya hindi namin masasabi kung ang pointer ay null o hindi.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Paghambingin sa pamamagitan ng isang cast sa isang manipis na pointer, kaya ang mga taba ng payo ay isinasaalang-alang lamang ang kanilang bahagi na "data" para sa null-ness.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Casts sa isang pointer ng ibang uri.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Nabulok ang isang (posibleng malawak) na punter sa address at mga sangkap ng metadata.
    ///
    /// Ang pointer ay maaaring maitaguyod sa paglaon kasama ang [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Ibinabalik ang `None` kung ang pointer ay null, o kung hindi man ay nagbabalik ng isang nakabahaging sanggunian sa halagang nakabalot sa `Some`.Kung ang halaga ay maaaring uninitialized, dapat gamitin sa halip ang [`as_uninit_ref`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Kapag tinawag ang pamamaraang ito, dapat mong tiyakin na *alinman sa* ang pointer ay NULL *o* lahat ng mga sumusunod ay totoo:
    ///
    /// * Ang pointer ay dapat na maayos na nakahanay.
    ///
    /// * Dapat itong "dereferencable" sa kahulugan na tinukoy sa [the module documentation].
    ///
    /// * Dapat ituro ng pointer ang isang inisyal na halimbawa ng `T`.
    ///
    /// * Dapat mong ipataw ang mga patakaran sa aliasing ng Rust, dahil ang ibinalik na buhay na `'a` ay arbitraryong napili at hindi kinakailangang sumasalamin sa aktwal na buhay ng data.
    ///   Sa partikular, para sa tagal ng buhay na ito, ang memorya na itinuro ng pointer na hindi dapat ma-mutate (maliban sa loob ng `UnsafeCell`).
    ///
    /// Nalalapat ito kahit na ang resulta ng pamamaraang ito ay hindi nagamit!
    /// (Ang bahagi tungkol sa pagiging napasimula ay hindi pa ganap na napagpasyahan, ngunit hanggang sa ito ay, ang ligtas na diskarte lamang ay upang matiyak na sila ay tunay na naisaulo.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Null-uncheck na bersyon
    ///
    /// Kung natitiyak mo na ang pointer ay hindi maaaring maging null at naghahanap para sa isang uri ng `as_ref_unchecked` na ibabalik ang `&T` sa halip na `Option<&T>`, alamin na maaari mong direktang bigyang katwiran ang pointer.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // KALIGTASAN: dapat garantiya ng tumatawag na wasto ang `self`
        // para sa isang sanggunian kung hindi ito null.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Ibinabalik ang `None` kung ang pointer ay null, o kung hindi man ay nagbabalik ng isang nakabahaging sanggunian sa halagang nakabalot sa `Some`.
    /// Sa kaibahan sa [`as_ref`], hindi ito nangangailangan na ang halaga ay dapat na gawing una.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Kapag tinawag ang pamamaraang ito, dapat mong tiyakin na *alinman sa* ang pointer ay NULL *o* lahat ng mga sumusunod ay totoo:
    ///
    /// * Ang pointer ay dapat na maayos na nakahanay.
    ///
    /// * Dapat itong "dereferencable" sa kahulugan na tinukoy sa [the module documentation].
    ///
    /// * Dapat mong ipataw ang mga patakaran sa aliasing ng Rust, dahil ang ibinalik na buhay na `'a` ay arbitraryong napili at hindi kinakailangang sumasalamin sa aktwal na buhay ng data.
    ///
    ///   Sa partikular, para sa tagal ng buhay na ito, ang memorya na itinuro ng pointer na hindi dapat ma-mutate (maliban sa loob ng `UnsafeCell`).
    ///
    /// Nalalapat ito kahit na ang resulta ng pamamaraang ito ay hindi nagamit!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // KALIGTASAN: dapat magagarantiya ng tumatawag na natutugunan ng `self` ang lahat ng
        // mga kinakailangan para sa isang sanggunian.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Kinakalkula ang offset mula sa isang pointer.
    ///
    /// `count` ay nasa mga yunit ng T;hal, isang `count` ng 3 ay kumakatawan sa isang pointer offset ng `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Kung ang alinman sa mga sumusunod na kundisyon ay nilabag, ang resulta ay Hindi Natukoy na Pag-uugali:
    ///
    /// * Parehong ang panimulang at nagresultang pointer ay dapat na alinman sa mga hangganan o isang byte na nakaraan sa pagtatapos ng parehong inilalaan na bagay.
    /// Tandaan na sa Rust, bawat variable na (stack-allocated) ay itinuturing na isang hiwalay na inilalaan na bagay.
    ///
    /// * Ang nakalkulang offset,**sa bytes**, ay hindi maaaring mag-overflow ng isang `isize`.
    ///
    /// * Ang offset na nasa hangganan ay hindi maaaring umasa sa "wrapping around" ang address space.Iyon ay, ang walang hanggan-katumpakan na kabuuan,**sa mga byte** ay dapat magkasya sa isang usize.
    ///
    /// Ang tagatala at karaniwang pamantasan sa pangkalahatan ay sumusubok na matiyak na ang mga paglalaan ay hindi maabot ang isang sukat kung saan ang isang offset ay isang alalahanin.
    /// Halimbawa, tinitiyak ng `Vec` at `Box` na hindi sila maglaan ng higit sa `isize::MAX` bytes, kaya't ang `vec.as_ptr().add(vec.len())` ay laging ligtas.
    ///
    /// Karamihan sa mga platform sa panimula ay hindi maaaring makabuo ng gayong paglalaan.
    /// Halimbawa, walang kilalang platform na 64-bit ang maaaring maghatid ng isang kahilingan para sa 2 <sup>63</sup> bytes dahil sa mga limitasyon sa pahina ng talahanayan o paghahati sa puwang ng address.
    /// Gayunpaman, ang ilang mga 32-bit at 16-bit na mga platform ay maaaring matagumpay na maghatid ng isang kahilingan para sa higit sa `isize::MAX` byte na may mga bagay tulad ng Physical Address Extension.
    ///
    /// Tulad ng naturan, ang memorya na nakuha nang direkta mula sa mga tagapagtalaga o memo ng naka-map na mga file *ay maaaring* masyadong malaki upang hawakan sa pagpapaandar na ito.
    ///
    /// Isaalang-alang ang paggamit ng [`wrapping_offset`] sa halip kung ang mga hadlang na ito ay mahirap masiyahan.
    /// Ang tanging bentahe ng pamamaraang ito ay nagbibigay-daan ito sa mas agresibong mga pag-optimize ng compiler.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Kinakalkula ang offset mula sa isang pointer gamit ang pambalot na arithmetic.
    ///
    /// `count` ay nasa mga yunit ng T;hal, isang `count` ng 3 ay kumakatawan sa isang pointer offset ng `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Ang pagpapatakbo mismo ay laging ligtas, ngunit ang paggamit ng nagresultang pointer ay hindi.
    ///
    /// Ang nagreresultang pointer ay mananatiling naka-attach sa parehong inilalaan na bagay na `self` point sa.
    /// Maaari itong *hindi* magamit upang ma-access ang ibang inilalaan na object.Tandaan na sa Rust, bawat variable na (stack-allocated) ay itinuturing na isang hiwalay na inilalaan na bagay.
    ///
    /// Sa madaling salita, ang `let z = x.wrapping_offset((y as isize) - (x as isize))` ay hindi *gumagawa* ng `z` kapareho ng `y` kahit na ipinapalagay namin na ang `T` ay may sukat `1` at walang overflow: Ang `z` ay naka-attach pa rin sa bagay na `x` ay nakakabit, at dereferencing na ito ay Hindi Natukoy na Pag-uugali maliban kung `x` at `y` point sa parehong inilalaan na object.
    ///
    /// Kung ikukumpara sa [`offset`], ang pamamaraang ito ay karaniwang naantala ang kinakailangan ng pananatili sa loob ng parehong inilalaan na bagay: Ang [`offset`] ay agarang Hindi Natukoy na Pag-uugali kapag tumatawid sa mga hangganan ng bagay;Ang `wrapping_offset` ay gumagawa ng isang pointer ngunit humantong pa rin sa Undefined na Pag-uugali kung ang isang pointer ay na-disferferensya kapag ito ay nasa labas ng mga hangganan ng bagay na nakakabit nito.
    /// [`offset`] maaaring ma-optimize nang mas mahusay at sa gayon ay lalong kanais-nais sa code na sensitibo sa pagganap.
    ///
    /// Isinasaalang-alang lamang ng naantalang tseke ang halaga ng pointer na na-disferensyado, hindi ang mga panggitna halaga na ginamit sa pagkalkula ng huling resulta.
    /// Halimbawa, ang `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` ay palaging kapareho ng `x`.Sa madaling salita, pinapayagan ang pag-iwan ng inilaan na bagay at pagkatapos ay muling pagpasok nito sa paglaon.
    ///
    /// Kung kailangan mong lalagpas sa mga hangganan object, nagsumite ang pointer sa isang integer at gawin ang arithmetic doon.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// // Iterate gamit ang isang raw pointer sa mga pagtaas ng dalawang elemento
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Ang loop na ito ay nagpi-print ng "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // KALIGTASAN: ang `arith_offset` intrinsic ay walang mga paunang kinakailangan na tawagan.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Kinakalkula ang distansya sa pagitan ng dalawang mga payo.Ang naibalik na halaga ay nasa mga yunit ng T: ang distansya sa mga byte ay nahahati sa `mem::size_of::<T>()`.
    ///
    /// Ang pagpapaandar na ito ay ang kabaligtaran ng [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Kung ang alinman sa mga sumusunod na kundisyon ay nilabag, ang resulta ay Hindi Natukoy na Pag-uugali:
    ///
    /// * Parehong ang panimula at iba pang pointer ay dapat na alinman sa mga hangganan o isang byte na lampas sa pagtatapos ng parehong inilalaan na bagay.
    /// Tandaan na sa Rust, bawat variable na (stack-allocated) ay itinuturing na isang hiwalay na inilalaan na bagay.
    ///
    /// * Ang parehong mga payo ay dapat na *nagmula sa* isang pointer sa parehong bagay.
    ///   (Tingnan sa ibaba para sa isang halimbawa.)
    ///
    /// * Ang distansya sa pagitan ng mga payo, sa mga byte, ay dapat na isang eksaktong maramihang laki ng `T`.
    ///
    /// * Ang distansya sa pagitan ng mga pointer,**sa bytes**, ay hindi maaaring mag-overflow ng isang `isize`.
    ///
    /// * Ang distansya na nasa mga hangganan ay hindi maaaring umasa sa "wrapping around" ang address space.
    ///
    /// Ang mga uri ng Rust ay hindi kailanman mas malaki kaysa sa mga alokasyon ng `isize::MAX` at Rust na hindi kailanman balot sa puwang ng address, kaya't ang dalawang mga payo sa loob ng ilang halaga ng anumang uri ng Rust na `T` ay palaging masiyahan ang huling dalawang mga kondisyon.
    ///
    /// Karaniwan din na tinitiyak ng pamantayang aklatan na ang mga paglalaan ay hindi kailanman aabot sa isang laki kung saan ang isang offset ay isang alalahanin.
    /// Halimbawa, tinitiyak ng `Vec` at `Box` na hindi sila maglaan ng higit sa `isize::MAX` bytes, kaya't laging nasisiyahan ng `ptr_into_vec.offset_from(vec.as_ptr())` ang huling dalawang kundisyon.
    ///
    /// Karamihan sa mga platform sa panimula ay hindi maaaring bumuo ng tulad ng isang malaking paglalaan.
    /// Halimbawa, walang kilalang platform na 64-bit ang maaaring maghatid ng isang kahilingan para sa 2 <sup>63</sup> bytes dahil sa mga limitasyon sa pahina ng talahanayan o paghahati sa puwang ng address.
    /// Gayunpaman, ang ilang mga 32-bit at 16-bit na mga platform ay maaaring matagumpay na maghatid ng isang kahilingan para sa higit sa `isize::MAX` byte na may mga bagay tulad ng Physical Address Extension.
    /// Tulad ng naturan, ang memorya na nakuha nang direkta mula sa mga tagapagtalaga o memo ng naka-map na mga file *ay maaaring* masyadong malaki upang hawakan sa pagpapaandar na ito.
    /// (Tandaan na ang [`offset`] at [`add`] ay mayroon ding katulad na limitasyon at samakatuwid ay hindi maaaring gamitin sa gayong malalaking paglalaan.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Ang pagpapaandar na ito panics kung `T` ay isang Zero-Sized Type ("ZST").
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Maling* paggamit:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Gumawa ng ptr2_other isang "alias" ng ptr2, ngunit nagmula sa ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Dahil ang ptr2_other at ptr2 ay nagmula sa mga payo sa iba't ibang mga bagay, ang pagkalkula ng kanilang offset ay hindi natukoy na pag-uugali, kahit na tumuturo sila sa parehong address!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Hindi Natukoy na Pag-uugali
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Ibinabalik kung ang dalawang mga tagaturo ay garantisadong maging pantay.
    ///
    /// Sa runtime ang pagpapaandar na ito ay kumikilos tulad ng `self == other`.
    /// Gayunpaman, sa ilang mga konteksto (hal., Pagsuri ng oras ng pagtitipid), hindi laging posible na matukoy ang pagkakapantay-pantay ng dalawang mga payo, kaya't ang pagpapaandar na ito ay maaaring masigasig na ibalik ang `false` para sa mga payo na kalaunan ay magiging pantay.
    ///
    /// Ngunit kapag ibinalik nito ang `true`, ang mga pahiwatig ay garantisadong maging pantay.
    ///
    /// Ang function na ito ay ang mirror ng [`guaranteed_ne`], ngunit hindi kabaligtaran nito.Mayroong mga paghahambing ng pointer kung saan ibabalik ng parehong mga pagpapaandar ang `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Ang pagbabago ng halaga ay maaaring magbago depende sa bersyon ng tagatala at ang hindi ligtas na code ay maaaring hindi umaasa sa resulta ng pagpapaandar na ito para sa pagiging maayos.
    /// Iminumungkahi na gamitin lamang ang function na ito para sa mga pag-optimize ng pagganap kung saan ang mga maling halaga ng pagbalik ng `false` ng pagpapaandar na ito ay hindi nakakaapekto sa kinalabasan, ngunit sa pagganap lamang.
    /// Ang mga kahihinatnan ng paggamit ng pamamaraang ito upang gumawa ng runtime at compile-time na code na kumilos nang naiiba ay hindi pa nasisiyasat.
    /// Ang pamamaraang ito ay hindi dapat gamitin upang ipakilala ang mga naturang pagkakaiba, at hindi rin ito dapat patatagin bago kami magkaroon ng isang mas mahusay na pag-unawa sa isyung ito.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Ibinabalik kung ang dalawang mga payo ay ginagarantiyahan na hindi pantay.
    ///
    /// Sa runtime ang pagpapaandar na ito ay kumikilos tulad ng `self != other`.
    /// Gayunpaman, sa ilang mga konteksto (hal., Pagsasaayos ng oras sa pag-aralan), hindi laging posible na matukoy ang hindi pagkakapantay-pantay ng dalawang mga payo, kaya't ang pagpapaandar na ito ay maaaring masigasig na ibalik ang `false` para sa mga payo na sa paglaon ay talagang hindi pantay.
    ///
    /// Ngunit kapag ibinalik nito ang `true`, ang mga pahiwatig ay garantisadong maging hindi pantay.
    ///
    /// Ang pagpapaandar na ito ay ang salamin ng [`guaranteed_eq`], ngunit hindi nito kabaligtaran.Mayroong mga paghahambing ng pointer kung saan ibabalik ng parehong mga pagpapaandar ang `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Ang pagbabago ng halaga ay maaaring magbago depende sa bersyon ng tagatala at ang hindi ligtas na code ay maaaring hindi umaasa sa resulta ng pagpapaandar na ito para sa pagiging maayos.
    /// Iminumungkahi na gamitin lamang ang function na ito para sa mga pag-optimize ng pagganap kung saan ang mga maling halaga ng pagbalik ng `false` ng pagpapaandar na ito ay hindi nakakaapekto sa kinalabasan, ngunit sa pagganap lamang.
    /// Ang mga kahihinatnan ng paggamit ng pamamaraang ito upang gumawa ng runtime at compile-time na code na kumilos nang naiiba ay hindi pa nasisiyasat.
    /// Ang pamamaraang ito ay hindi dapat gamitin upang ipakilala ang mga naturang pagkakaiba, at hindi rin ito dapat patatagin bago kami magkaroon ng isang mas mahusay na pag-unawa sa isyung ito.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Kinakalkula ang offset mula sa isang pointer (kaginhawaan para sa `.offset(count as isize)`).
    ///
    /// `count` ay nasa mga yunit ng T;hal, isang `count` ng 3 ay kumakatawan sa isang pointer offset ng `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Kung ang alinman sa mga sumusunod na kundisyon ay nilabag, ang resulta ay Hindi Natukoy na Pag-uugali:
    ///
    /// * Parehong ang panimulang at nagresultang pointer ay dapat na alinman sa mga hangganan o isang byte na nakaraan sa pagtatapos ng parehong inilalaan na bagay.
    /// Tandaan na sa Rust, bawat variable na (stack-allocated) ay itinuturing na isang hiwalay na inilalaan na bagay.
    ///
    /// * Ang nakalkulang offset,**sa bytes**, ay hindi maaaring mag-overflow ng isang `isize`.
    ///
    /// * Ang offset na nasa hangganan ay hindi maaaring umasa sa "wrapping around" ang address space.Iyon ay, ang walang hanggan-katumpakan na kabuuan ay dapat magkasya sa isang `usize`.
    ///
    /// Ang tagatala at karaniwang pamantasan sa pangkalahatan ay sumusubok na matiyak na ang mga paglalaan ay hindi maabot ang isang sukat kung saan ang isang offset ay isang alalahanin.
    /// Halimbawa, tinitiyak ng `Vec` at `Box` na hindi sila maglaan ng higit sa `isize::MAX` bytes, kaya't ang `vec.as_ptr().add(vec.len())` ay laging ligtas.
    ///
    /// Karamihan sa mga platform sa panimula ay hindi maaaring makabuo ng gayong paglalaan.
    /// Halimbawa, walang kilalang platform na 64-bit ang maaaring maghatid ng isang kahilingan para sa 2 <sup>63</sup> bytes dahil sa mga limitasyon sa pahina ng talahanayan o paghahati sa puwang ng address.
    /// Gayunpaman, ang ilang mga 32-bit at 16-bit na mga platform ay maaaring matagumpay na maghatid ng isang kahilingan para sa higit sa `isize::MAX` byte na may mga bagay tulad ng Physical Address Extension.
    ///
    /// Tulad ng naturan, ang memorya na nakuha nang direkta mula sa mga tagapagtalaga o memo ng naka-map na mga file *ay maaaring* masyadong malaki upang hawakan sa pagpapaandar na ito.
    ///
    /// Isaalang-alang ang paggamit ng [`wrapping_add`] sa halip kung ang mga hadlang na ito ay mahirap masiyahan.
    /// Ang tanging bentahe ng pamamaraang ito ay nagbibigay-daan ito sa mas agresibong mga pag-optimize ng compiler.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Kinakalkula ang offset mula sa isang pointer (kaginhawaan para sa `.offset ((bilang isize).wrapping_neg())`).
    ///
    /// `count` ay nasa mga yunit ng T;hal, isang `count` ng 3 ay kumakatawan sa isang pointer offset ng `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Kung ang alinman sa mga sumusunod na kundisyon ay nilabag, ang resulta ay Hindi Natukoy na Pag-uugali:
    ///
    /// * Parehong ang panimulang at nagresultang pointer ay dapat na alinman sa mga hangganan o isang byte na nakaraan sa pagtatapos ng parehong inilalaan na bagay.
    /// Tandaan na sa Rust, bawat variable na (stack-allocated) ay itinuturing na isang hiwalay na inilalaan na bagay.
    ///
    /// * Ang computing offset ay hindi maaaring lumagpas sa `isize::MAX`**bytes**.
    ///
    /// * Ang offset na nasa hangganan ay hindi maaaring umasa sa "wrapping around" ang address space.Iyon ay, ang walang hanggan-katumpakan na kabuuan ay dapat magkasya sa isang paggamit.
    ///
    /// Ang tagatala at karaniwang pamantasan sa pangkalahatan ay sumusubok na matiyak na ang mga paglalaan ay hindi maabot ang isang sukat kung saan ang isang offset ay isang alalahanin.
    /// Halimbawa, tinitiyak ng `Vec` at `Box` na hindi sila maglaan ng higit sa `isize::MAX` bytes, kaya't ang `vec.as_ptr().add(vec.len()).sub(vec.len())` ay laging ligtas.
    ///
    /// Karamihan sa mga platform sa panimula ay hindi maaaring makabuo ng gayong paglalaan.
    /// Halimbawa, walang kilalang platform na 64-bit ang maaaring maghatid ng isang kahilingan para sa 2 <sup>63</sup> bytes dahil sa mga limitasyon sa pahina ng talahanayan o paghahati sa puwang ng address.
    /// Gayunpaman, ang ilang mga 32-bit at 16-bit na mga platform ay maaaring matagumpay na maghatid ng isang kahilingan para sa higit sa `isize::MAX` byte na may mga bagay tulad ng Physical Address Extension.
    ///
    /// Tulad ng naturan, ang memorya na nakuha nang direkta mula sa mga tagapagtalaga o memo ng naka-map na mga file *ay maaaring* masyadong malaki upang hawakan sa pagpapaandar na ito.
    ///
    /// Isaalang-alang ang paggamit ng [`wrapping_sub`] sa halip kung ang mga hadlang na ito ay mahirap masiyahan.
    /// Ang tanging bentahe ng pamamaraang ito ay nagbibigay-daan ito sa mas agresibong mga pag-optimize ng compiler.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Kinakalkula ang offset mula sa isang pointer gamit ang pambalot na arithmetic.
    /// (kaginhawaan para sa `.wrapping_offset(count as isize)`)
    ///
    /// `count` ay nasa mga yunit ng T;hal, isang `count` ng 3 ay kumakatawan sa isang pointer offset ng `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Ang pagpapatakbo mismo ay laging ligtas, ngunit ang paggamit ng nagresultang pointer ay hindi.
    ///
    /// Ang nagreresultang pointer ay mananatiling naka-attach sa parehong inilalaan na bagay na `self` point sa.
    /// Maaari itong *hindi* magamit upang ma-access ang ibang inilalaan na object.Tandaan na sa Rust, bawat variable na (stack-allocated) ay itinuturing na isang hiwalay na inilalaan na bagay.
    ///
    /// Sa madaling salita, ang `let z = x.wrapping_add((y as usize) - (x as usize))` ay hindi *gumagawa* ng `z` kapareho ng `y` kahit na ipinapalagay namin na ang `T` ay may sukat `1` at walang overflow: Ang `z` ay naka-attach pa rin sa bagay na `x` ay nakakabit, at dereferencing na ito ay Hindi Natukoy na Pag-uugali maliban kung `x` at `y` point sa parehong inilalaan na object.
    ///
    /// Kung ikukumpara sa [`add`], ang pamamaraang ito ay karaniwang naantala ang kinakailangan ng pananatili sa loob ng parehong inilalaan na bagay: Ang [`add`] ay agarang Hindi Natukoy na Pag-uugali kapag tumatawid sa mga hangganan ng bagay;Ang `wrapping_add` ay gumagawa ng isang pointer ngunit humantong pa rin sa Undefined na Pag-uugali kung ang isang pointer ay na-disferferensya kapag ito ay nasa labas ng mga hangganan ng bagay na nakakabit nito.
    /// [`add`] maaaring ma-optimize nang mas mahusay at sa gayon ay lalong kanais-nais sa code na sensitibo sa pagganap.
    ///
    /// Isinasaalang-alang lamang ng naantalang tseke ang halaga ng pointer na na-disferensyado, hindi ang mga panggitna halaga na ginamit sa pagkalkula ng huling resulta.
    /// Halimbawa, ang `x.wrapping_add(o).wrapping_sub(o)` ay palaging kapareho ng `x`.Sa madaling salita, pinapayagan ang pag-iwan ng inilaan na bagay at pagkatapos ay muling pagpasok nito sa paglaon.
    ///
    /// Kung kailangan mong lalagpas sa mga hangganan object, nagsumite ang pointer sa isang integer at gawin ang arithmetic doon.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// // Iterate gamit ang isang raw pointer sa mga pagtaas ng dalawang elemento
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Ang loop na ito ay nagpi-print ng "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Kinakalkula ang offset mula sa isang pointer gamit ang pambalot na arithmetic.
    /// (kaginhawaan para sa `.wrapping_offset ((bilang bilang isize).wrapping_neg())`)
    ///
    /// `count` ay nasa mga yunit ng T;hal, isang `count` ng 3 ay kumakatawan sa isang pointer offset ng `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Ang pagpapatakbo mismo ay laging ligtas, ngunit ang paggamit ng nagresultang pointer ay hindi.
    ///
    /// Ang nagreresultang pointer ay mananatiling naka-attach sa parehong inilalaan na bagay na `self` point sa.
    /// Maaari itong *hindi* magamit upang ma-access ang ibang inilalaan na object.Tandaan na sa Rust, bawat variable na (stack-allocated) ay itinuturing na isang hiwalay na inilalaan na bagay.
    ///
    /// Sa madaling salita, ang `let z = x.wrapping_sub((x as usize) - (y as usize))` ay hindi *gumagawa* ng `z` kapareho ng `y` kahit na ipinapalagay namin na ang `T` ay may sukat `1` at walang overflow: Ang `z` ay naka-attach pa rin sa bagay na `x` ay nakakabit, at dereferencing na ito ay Hindi Natukoy na Pag-uugali maliban kung `x` at `y` point sa parehong inilalaan na object.
    ///
    /// Kung ikukumpara sa [`sub`], ang pamamaraang ito ay karaniwang naantala ang kinakailangan ng pananatili sa loob ng parehong inilalaan na bagay: Ang [`sub`] ay agarang Hindi Natukoy na Pag-uugali kapag tumatawid sa mga hangganan ng bagay;Ang `wrapping_sub` ay gumagawa ng isang pointer ngunit humantong pa rin sa Undefined na Pag-uugali kung ang isang pointer ay na-disferferensya kapag ito ay nasa labas ng mga hangganan ng bagay na nakakabit nito.
    /// [`sub`] maaaring ma-optimize nang mas mahusay at sa gayon ay lalong kanais-nais sa code na sensitibo sa pagganap.
    ///
    /// Isinasaalang-alang lamang ng naantalang tseke ang halaga ng pointer na na-disferensyado, hindi ang mga panggitna halaga na ginamit sa pagkalkula ng huling resulta.
    /// Halimbawa, ang `x.wrapping_add(o).wrapping_sub(o)` ay palaging kapareho ng `x`.Sa madaling salita, pinapayagan ang pag-iwan ng inilaan na bagay at pagkatapos ay muling pagpasok nito sa paglaon.
    ///
    /// Kung kailangan mong lalagpas sa mga hangganan object, nagsumite ang pointer sa isang integer at gawin ang arithmetic doon.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// // Iterate gamit ang isang hilaw na pointer sa mga pagdagdag ng dalawang elemento (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Ang loop na ito ay nagpi-print ng "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Itinatakda ang halaga ng pointer sa `ptr`.
    ///
    /// Kung sakaling ang `self` ay isang (fat) pointer sa isang hindi sukat na uri, ang operasyon na ito ay makakaapekto lamang sa bahagi ng pointer, samantalang para sa (thin) na mga payo sa mga laki ng laki, mayroon itong parehong epekto bilang isang simpleng takdang-aralin.
    ///
    /// Ang nagreresultang pointer ay magkakaroon ng proofance ng `val`, ibig sabihin, para sa isang fat pointer, ang operasyon na ito ay semantically pareho sa paglikha ng isang bagong fat pointer na may data pointer na halaga ng `val` ngunit ang metadata ng `self`.
    ///
    ///
    /// # Examples
    ///
    /// Ang pagpapaandar na ito ay pangunahing kapaki-pakinabang para sa pagpapahintulot sa byte-wisdom pointer arithmetic sa mga potensyal na fat point:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // i-print ang "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // KALIGTASAN: Sa kaso ng isang manipis na pointer, magkatulad ang mga operasyon na ito
        // sa isang simpleng takdang-aralin.
        // Sa kaso ng isang fat pointer, na may kasalukuyang pagpapatupad ng layout ng fat pointer, ang unang larangan ng naturang pointer ay palaging ang data pointer, na nakatalaga rin.
        //
        unsafe { *thin = val };
        self
    }

    /// Binabasa ang halaga mula sa `self` nang hindi ito inililipat.
    /// Iiwan nito ang memorya sa `self` na hindi nagbago.
    ///
    /// Tingnan ang [`ptr::read`] para sa mga alalahanin sa kaligtasan at mga halimbawa.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `read`.
        unsafe { read(self) }
    }

    /// Nagsasagawa ng isang pabagu-bago ng isip na basahin ang halaga mula sa `self` nang hindi ito nililipat.Iiwan nito ang memorya sa `self` na hindi nagbago.
    ///
    /// Ang mga pabagu-bago na pagpapatakbo ay inilaan upang kumilos sa memorya ng I/O, at garantisadong hindi mai-elided o muling ayusin ng tagatala sa iba pang mga pabagu-bago na operasyon.
    ///
    ///
    /// Tingnan ang [`ptr::read_volatile`] para sa mga alalahanin sa kaligtasan at mga halimbawa.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Binabasa ang halaga mula sa `self` nang hindi ito inililipat.
    /// Iiwan nito ang memorya sa `self` na hindi nagbago.
    ///
    /// Hindi tulad ng `read`, ang pointer ay maaaring hindi nakahanay.
    ///
    /// Tingnan ang [`ptr::read_unaligned`] para sa mga alalahanin sa kaligtasan at mga halimbawa.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Kinokopya ang `count * size_of<T>` bytes mula `self` hanggang `dest`.
    /// Maaaring mag-overlap ang pinagmulan at patutunguhan.
    ///
    /// NOTE: mayroon itong *kapareho* order ng argumento bilang [`ptr::copy`].
    ///
    /// Tingnan ang [`ptr::copy`] para sa mga alalahanin sa kaligtasan at mga halimbawa.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Kinokopya ang `count * size_of<T>` bytes mula `self` hanggang `dest`.
    /// Ang pinagmulan at patutunguhan ay maaaring *hindi* nagsasapawan.
    ///
    /// NOTE: mayroon itong *kapareho* order ng argumento bilang [`ptr::copy_nonoverlapping`].
    ///
    /// Tingnan ang [`ptr::copy_nonoverlapping`] para sa mga alalahanin sa kaligtasan at mga halimbawa.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Kinukuwenta ang offset na kailangang ilapat sa pointer upang gawin itong nakahanay sa `align`.
    ///
    /// Kung hindi posible na ihanay ang pointer, ibabalik ng pagpapatupad ang `usize::MAX`.
    /// Pinapayagan para sa pagpapatupad na *palaging* ibalik ang `usize::MAX`.
    /// Ang pagganap ng iyong algorithm ay maaaring nakasalalay sa pagkuha ng isang magagamit na offset dito, hindi ang kawastuhan nito.
    ///
    /// Ang offset ay ipinahayag sa bilang ng mga elemento ng `T`, at hindi mga byte.Ang halagang ibinalik ay maaaring magamit sa pamamaraang `wrapping_add`.
    ///
    /// Walang mga garantiya na anupaman na ang pagpapalit ng pointer ay hindi umaapaw o lalampas sa paglalaan na itinuro ng pointer.
    ///
    /// Nasa sa tumatawag upang matiyak na ang naibalik na offset ay tama sa lahat ng mga term na iba sa pagkakahanay.
    ///
    /// # Panics
    ///
    /// Ang pagpapaandar panics kung `align` ay hindi isang kapangyarihan-ng-dalawa.
    ///
    /// # Examples
    ///
    /// Pag-access sa katabing `u8` bilang `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // habang ang pointer ay maaaring nakahanay sa pamamagitan ng `offset`, ituturo nito sa labas ng paglalaan
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // KALIGTASAN: Ang `align` ay nasuri upang maging isang lakas na 2 sa itaas
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Ibinabalik ang haba ng isang hilaw na hiwa.
    ///
    /// Ang naibalik na halaga ay ang bilang ng mga **elemento**, hindi ang bilang ng mga byte.
    ///
    /// Ang pagpapaandar na ito ay ligtas, kahit na ang hilaw na hiwa ay hindi maaaring ihulog sa isang sanggunian ng hiwa sapagkat ang pointer ay null o hindi nakahanay.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // KALIGTASAN: ligtas ito dahil ang `*const [T]` at `FatPtr<T>` ay may parehong layout.
            // Ang `std` lamang ang makakagawa ng garantiyang ito.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Nagbabalik ng isang hilaw na pointer sa buffer ng hiwa.
    ///
    /// Katumbas ito ng pag-cast ng `self` hanggang `*const T`, ngunit mas ligtas ang uri.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Nagbabalik ng isang hilaw na pointer sa isang elemento o subslice, nang hindi nagsasagawa ng mga hangganan sa pagsusuri.
    ///
    /// Ang pagtawag sa pamamaraang ito na may isang out-of-bounds index o kung hindi maaalis ang `self` ay *[hindi natukoy na pag-uugali]* kahit na ang nagresultang pointer ay hindi ginamit.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // KALIGTASAN: tinitiyak ng tumatawag na ang `self` ay hindi maalis at ang `index` na mga in-bound.
        unsafe { index.get_unchecked(self) }
    }

    /// Ibinabalik ang `None` kung ang pointer ay null, o kung hindi man ay nagbabalik ng isang ibinahaging hiwa sa halagang nakabalot sa `Some`.
    /// Sa kaibahan sa [`as_ref`], hindi ito nangangailangan na ang halaga ay dapat na gawing una.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Kapag tinawag ang pamamaraang ito, dapat mong tiyakin na *alinman sa* ang pointer ay NULL *o* lahat ng mga sumusunod ay totoo:
    ///
    /// * Ang pointer ay dapat na [valid] para mabasa para sa `ptr.len() * mem::size_of::<T>()` maraming byte, at dapat itong maayos na nakahanay.Partikular na nangangahulugan ito:
    ///
    ///     * Ang buong saklaw ng memorya ng hiwa na ito ay dapat na nakapaloob sa loob ng isang solong inilalaan na bagay!
    ///       Ang mga hiwa ay hindi kailanman maaaring sumaklaw sa maraming mga inilalaan na mga bagay.
    ///
    ///     * Ang pointer ay dapat na nakahanay kahit na para sa mga hiwa ng walang haba.
    ///     Ang isang dahilan para dito ay ang pag-optimize ng layout ng enum ay maaaring umasa sa mga sanggunian (kasama ang mga hiwa ng anumang haba) na nakahanay at hindi null upang makilala ang mga ito mula sa iba pang data.
    ///
    ///     Maaari kang makakuha ng isang pointer na ay kapaki-pakinabang bilang `data` para sa hiwa zero-length gamit [`NonNull::dangling()`].
    ///
    /// * Ang kabuuang sukat na `ptr.len() * mem::size_of::<T>()` ng hiwa ay dapat na hindi mas malaki sa `isize::MAX`.
    ///   Tingnan ang dokumentasyon sa kaligtasan ng [`pointer::offset`].
    ///
    /// * Dapat mong ipataw ang mga patakaran sa aliasing ng Rust, dahil ang ibinalik na buhay na `'a` ay arbitraryong napili at hindi kinakailangang sumasalamin sa aktwal na buhay ng data.
    ///   Sa partikular, para sa tagal ng buhay na ito, ang memorya na itinuro ng pointer na hindi dapat ma-mutate (maliban sa loob ng `UnsafeCell`).
    ///
    /// Nalalapat ito kahit na ang resulta ng pamamaraang ito ay hindi nagamit!
    ///
    /// Tingnan din ang [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Pagkakapantay-pantay para sa mga payo
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Paghahambing para sa mga payo
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}