use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Ang isang wrapper sa paligid ng isang raw non-null `*mut T` na nagpapahiwatig na ang may ari ng wrapper ito nagmamay-ari ng referent.
/// Kapaki-pakinabang para sa pagbuo ng mga abstraction tulad ng `Box<T>`, `Vec<T>`, `String`, at `HashMap<K, V>`.
///
/// Hindi tulad ng `*mut T`, ang `Unique<T>` ay kumilos "as if" ito ay isang halimbawa ng `T`.
/// Nagpapatupad ito ng `Send`/`Sync` kung `T` ay `Send`/`Sync`.
/// Ipinapahiwatig din nito ang uri ng malakas na pag-aliasing ng mga garantiya ng isang halimbawa ng `T` na maaaring asahan:
/// ang referent ng pointer ay hindi dapat baguhin nang walang natatanging landas sa pagmamay-ari nitong Natatanging.
///
/// Kung hindi ka sigurado kung tama kung gamitin ang `Unique` para sa iyong mga layunin, isaalang-alang ang paggamit ng `NonNull`, na may mas mahina na semantiko.
///
///
/// Hindi tulad ng `*mut T`, ang pointer ay dapat palaging hindi null, kahit na ang pointer ay hindi kailanman na-disferferensya.
/// Ito ay upang ang mga enum ay maaaring gumamit ng ipinagbabawal na halagang ito bilang isang diskriminasyon-ang `Option<Unique<T>>` ay may parehong laki sa `Unique<T>`.
/// Subalit ang pointer ay maaari pa ring lumawit kung hindi ito na-disferferensya.
///
/// Hindi tulad ng `*mut T`, ang `Unique<T>` ay covariant na higit sa `T`.
/// Ito ay dapat palaging tama para sa anumang uri na sumusuporta sa mga kinakailangan sa aliasing ni Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ang marker na ito ay walang kahihinatnan para sa pagkakaiba-iba, ngunit kinakailangan
    // para maunawaan ng dropck na lohikal na nagmamay-ari kami ng `T`.
    //
    // Para sa mga detalye, tingnan ang:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` ang mga pointers ay `Send` kung ang `T` ay `Send` sapagkat ang data na kanilang sanggunian ay hindi nabago.
/// Tandaan na ang invasiant ng aliasing na ito ay hindi ipinatutupad ng uri ng system;ang abstraction gamit ang `Unique` ay dapat na ipatupad ito.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` ang mga pointers ay `Sync` kung ang `T` ay `Sync` sapagkat ang data na kanilang sanggunian ay hindi nabago.
/// Tandaan na ang invasiant ng aliasing na ito ay hindi ipinatutupad ng uri ng system;ang abstraction gamit ang `Unique` ay dapat na ipatupad ito.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Lumilikha ng isang bagong `Unique` na nakabitin, ngunit maayos na nakahanay.
    ///
    /// Kapaki-pakinabang ito para sa pagsisimula ng mga uri na tinatamad na inilalaan, tulad ng ginagawa ng `Vec::new`.
    ///
    /// Tandaan na ang halaga ng pointer ay maaaring potensyal na kumatawan sa isang wastong pointer sa isang `T`, na nangangahulugang hindi ito dapat gamitin bilang isang "not yet initialized" halaga ng sentinel.
    /// Ang mga uri na tamad na naglalaan ay dapat subaybayan ang pagsisimula sa ilang iba pang mga paraan.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // KALIGTASAN: Nagbabalik ang mem::align_of() ng wastong, hindi null na pointer.Ang
        // ang mga kundisyon upang tawagan ang new_unchecked() ay ganoong respetado.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Lumilikha ng isang bagong `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` dapat na non-null.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // KALIGTASAN: dapat garantiya ng tumatawag na ang `ptr` ay hindi null.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Lumilikha ng isang bagong `Unique` kung ang `ptr` ay hindi null.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // KALIGTASAN: Ang pointer ay nasuri na at hindi null.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Nakukuha ang napapailalim na `*mut` pointer.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Mga Dereferensya sa nilalaman.
    ///
    /// Ang resultang buhay ay nakasalalay sa sarili kaya ito behaves "as if" ito ay talagang isang instance T na nagsisimula pa hiniram.
    /// Kung kailangan ng mas mahabang buhay na (unbound), gamitin ang `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // KALIGTASAN: dapat magagarantiya ng tumatawag na natutugunan ng `self` ang lahat ng
        // mga kinakailangan para sa isang sanggunian.
        unsafe { &*self.as_ptr() }
    }

    /// Maaaring baguhin ang pagkakasunud-sunod ng nilalaman.
    ///
    /// Ang resultang buhay ay nakasalalay sa sarili kaya ito behaves "as if" ito ay talagang isang instance T na nagsisimula pa hiniram.
    /// Kung kailangan ng mas mahabang buhay na (unbound), gamitin ang `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // KALIGTASAN: dapat magagarantiya ng tumatawag na natutugunan ng `self` ang lahat ng
        // mga kinakailangan para sa isang nababagong sanggunian.
        unsafe { &mut *self.as_ptr() }
    }

    /// Casts sa isang pointer ng ibang uri.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // KALIGTASAN: Lumilikha ang Unique::new_unchecked() ng isang bagong natatanging at mga pangangailangan
        // ang ibinigay na pointer upang hindi maging null.
        // Dahil ipinapasa namin ang sarili bilang isang pointer, hindi ito maaaring maging null.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // KALIGTASAN: Ang isang nababagabag na sanggunian ay hindi maaaring maging null
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}