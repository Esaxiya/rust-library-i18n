#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Nagbibigay ng uri ng pointer metadata ng anumang naka-type na uri.
///
/// # Metadata ng pointer
///
/// Ang mga hilaw na uri ng pointer at uri ng sanggunian sa Rust ay maaaring maiisip na gawa sa dalawang bahagi:
/// isang data pointer na naglalaman ng memorya ng halaga ng halaga, at ilang metadata.
///
/// Para sa mga uri ng statically-size (na nagpapatupad ng `Sized` traits) pati na rin para sa mga uri ng `extern`, sinasabing "manipis" ang mga pointers: ang metadata ay zero-size at ang uri nito ay `()`.
///
///
/// Ang mga pahiwatig sa [dynamically-sized types][dst] ay sinasabing "malawak" o "taba", mayroon silang non-zero-laki na metadata:
///
/// * Para sa mga struct na ang huling patlang ay isang DST, ang metadata ang metadata para sa huling patlang
/// * Para sa uri ng `str`, ang metadata ay ang haba sa mga byte bilang `usize`
/// * Para sa mga uri ng hiwa tulad ng `[T]`, ang metadata ang haba sa mga item bilang `usize`
/// * Para sa mga bagay na trait tulad ng `dyn SomeTrait`, ang metadata ay [`DynMetadata<Self>`][DynMetadata] (hal. `DynMetadata<dyn SomeTrait>`)
///
/// Sa future, ang wika ng Rust ay maaaring makakuha ng mga bagong uri ng uri na mayroong magkakaibang metadata ng pointer.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # Ang `Pointee` trait
///
/// Ang punto ng trait na ito ay ang kaugnay na uri ng `Metadata`, na kung saan ay `()` o `usize` o `DynMetadata<_>` tulad ng inilarawan sa itaas.
/// Awtomatiko itong ipinatupad para sa bawat uri.
/// Maaari itong ipalagay na ipinatupad sa isang pangkaraniwang konteksto, kahit na walang kaukulang hangganan.
///
/// # Usage
///
/// Ang mga Raw point ay maaaring mabulok sa address ng data at mga sangkap ng metadata sa kanilang pamamaraan na [`to_raw_parts`].
///
/// Bilang kahalili, ang metadata lamang ay maaaring makuha sa pagpapaandar ng [`metadata`].
/// Ang isang sanggunian ay maaaring maipasa sa [`metadata`] at implicitly coerced.
///
/// Ang isang (possibly-wide) pointer ay maaaring ibalik mula sa address nito at metadata na may [`from_raw_parts`] o [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Ang uri para sa metadata sa mga payo at sanggunian sa `Self`.
    #[lang = "metadata_type"]
    // NOTE: Panatilihin ang trait bounds sa `static_assert_expected_bounds_for_metadata`
    //
    // sa `library/core/src/ptr/metadata.rs` na naka-sync sa mga narito:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Ang mga pahiwatig sa mga uri na nagpapatupad ng trait alias na ito ay "payat".
///
/// Kasama rito ang mga statically-`Sized` na uri at `extern` na uri.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: huwag patatagin ito bago ang trait alias ay hindi matatag sa wika?
pub trait Thin = Pointee<Metadata = ()>;

/// I-extract ang metadata na bahagi ng isang pointer.
///
/// Ang mga halaga ng uri `*mut T`, `&T`, o `&mut T` ay maaaring maipasa nang direkta sa pagpapaandar na ito dahil sa implicit na pinilit nila ang `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // KALIGTASAN: Ang pag-access sa halaga mula sa unyon ng `PtrRepr` ay ligtas mula noong * const T
    // at PtrComponents<T>ay may parehong layout memorya.
    // Ang std lamang ang makakagawa ng garantiyang ito.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Bumubuo ng isang (possibly-wide) raw pointer mula sa isang data address at metadata.
///
/// Ang pagpapaandar na ito ay ligtas ngunit ang naibalik na pointer ay hindi kinakailangang ligtas sa pagkawasak.
/// Para sa mga hiwa, tingnan ang dokumentasyon ng [`slice::from_raw_parts`] para sa mga kinakailangan sa kaligtasan.
/// Para sa mga bagay na trait, ang metadata ay dapat na nagmula sa isang pointer sa parehong pinagbabatayan na hindi pa nahihintulutang uri.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // KALIGTASAN: Ang pag-access sa halaga mula sa unyon ng `PtrRepr` ay ligtas mula noong * const T
    // at PtrComponents<T>ay may parehong layout memorya.
    // Ang std lamang ang makakagawa ng garantiyang ito.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Nagsasagawa ng parehong pag-andar tulad ng [`from_raw_parts`], maliban sa isang raw `*mut` pointer ay naibalik, taliwas sa isang hilaw na `* const` pointer.
///
///
/// Tingnan ang dokumentasyon ng [`from_raw_parts`] para sa higit pang mga detalye.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // KALIGTASAN: Ang pag-access sa halaga mula sa unyon ng `PtrRepr` ay ligtas mula noong * const T
    // at PtrComponents<T>ay may parehong layout memorya.
    // Ang std lamang ang makakagawa ng garantiyang ito.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Kailangan ng manu-manong impl upang maiwasan ang `T: Copy` na nakagapos.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Kailangan ng manu-manong impl upang maiwasan ang `T: Clone` na nakagapos.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Ang metadata para sa isang uri ng bagay na `Dyn = dyn SomeTrait` trait.
///
/// Ito ay isang pointer sa isang vtable (virtual call table) na kumakatawan sa lahat ng kinakailangang impormasyon upang manipulahin ang konkretong uri na nakaimbak sa loob ng isang trait na bagay.
/// Kapansin-pansin ang vtable na naglalaman ito ng:
///
/// * laki ng uri
/// * pag-align ng uri
/// * isang pointer sa uri ng `drop_in_place` impl (maaaring maging isang no-op para sa payak-lumang-data)
/// * mga pahiwatig sa lahat ng mga pamamaraan para sa pagpapatupad ng uri ng trait
///
/// Tandaan na ang unang tatlo ay espesyal dahil kinakailangan upang maglaan, mag-drop, at makipag-deallocate ng anumang trait object.
///
/// Posibleng pangalanan ang istrakturang ito ng isang uri ng parameter na hindi isang `dyn` trait na bagay (halimbawa `DynMetadata<u64>`) ngunit hindi upang makakuha ng isang makabuluhang halaga ng istrukturang iyon.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Ang karaniwang unlapi ng lahat ng mga vtable.Sinusundan ito ng mga point point ng pag-andar para sa mga pamamaraan ng trait.
///
/// Detalye ng pribadong pagpapatupad ng `DynMetadata::size_of` atbp.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Ibinabalik ang laki ng uri na nauugnay sa vtable na ito.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Ibinabalik ang pagkakahanay ng uri na nauugnay sa vtable na ito.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Ibinabalik ang laki at pagkakahanay bilang isang `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // KALIGTASAN: inilabas ng tagatala ang vtable na ito para sa isang kongkretong uri ng Rust na
        // ay kilala na may wastong layout.Parehong katwiran tulad ng sa `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Kailangan ng mga manu-manong impls upang maiwasan ang mga hangganan ng `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}