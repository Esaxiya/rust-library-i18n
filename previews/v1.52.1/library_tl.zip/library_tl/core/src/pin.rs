//! Mga uri na pin ang data sa lokasyon nito sa memorya.
//!
//! Minsan kapaki-pakinabang ang pagkakaroon ng mga bagay na garantisadong hindi gagalaw, sa diwa na ang kanilang pagkakalagay sa memorya ay hindi nagbabago, at sa gayon ay maaasahan.
//! Ang isang pangunahing halimbawa ng naturang senaryo ay ang pagbuo ng mga strukturang sumasangguni sa sarili, dahil ang paglipat ng isang bagay na may mga pahiwatig sa sarili nito ay magpapawalang-bisa sa kanila, na maaaring maging sanhi ng hindi natukoy na pag-uugali.
//!
//! Sa isang mataas na antas, tinitiyak ng isang [`Pin<P>`] na ang pointee ng anumang uri ng pointer na `P` ay mayroong matatag na lokasyon sa memorya, nangangahulugang hindi ito maililipat sa ibang lugar at ang memorya nito ay hindi maaaring mapalitan hanggang sa mahulog ito.Sinasabi namin na ang pointee ay "pinned".Ang mga bagay ay nakakakuha ng mas banayad kapag tinatalakay ang mga uri na nagsasama ng naka-pin sa hindi naka-pin na data;[see below](#projections-and-structural-pinning) para sa karagdagang detalye.
//!
//! Bilang default, lahat ng uri sa Rust ay maililipat.
//! Pinapayagan ng Rust ang pagpasa sa lahat ng mga uri ng ayon sa halaga, at ang mga karaniwang uri ng smart-pointer tulad ng [`Box<T>`] at `&mut T` ay nagbibigay-daan sa pagpapalit at paglipat ng mga halagang naglalaman sila: maaari kang lumipat sa isang [`Box<T>`], o maaari mong gamitin ang [`mem::swap`].
//! [`Pin<P>`] balot ang isang uri ng pointer na `P`, kaya ang [`Pin`]`<`[`Box`] `<T>>`gumana tulad ng isang regular
//!
//! [`Box<T>`]: when isang [`Pin`]`<`[`Box`] `<T>>`Nahuhulog, kaya't ang mga nilalaman nito, at ang memorya ay nakakakuha
//!
//! nakipagpalitanKatulad nito, ang [`Pin`]`<&mut T>` ay katulad ng `&mut T`.Gayunpaman, hindi pinapayagan ng [`Pin<P>`] ang mga kliyente na talagang makakuha ng isang [`Box<T>`] o `&mut T` upang ma-pin ang data, na nagpapahiwatig na hindi mo maaaring gamitin ang mga operasyon tulad ng [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` nangangailangan ng `&mut T`, ngunit hindi namin ito makuha.
//!     // Kami ay natigil, hindi namin mapapalitan ang nilalaman ng mga sanggunian na ito.
//!     // Maaari naming gamitin ang `Pin::get_unchecked_mut`, ngunit hindi iyon ligtas sa isang kadahilanan:
//!     // hindi kami pinapayagan na gamitin ito para sa paglipat ng mga bagay sa `Pin`.
//! }
//! ```
//!
//! Ito ay nagkakahalaga ng muling pag-ulit na ang [`Pin<P>`] ay hindi *binabago ang katotohanang isinasaalang-alang ng isang tagatala ng Rust ang lahat ng mga uri na maililipat.Ang [`mem::swap`] ay mananatiling natatawag para sa anumang `T`.Sa halip, pinipigilan ng [`Pin<P>`] ang ilang mga* halagang * (itinuro ng mga payo na nakabalot sa [`Pin<P>`]) mula sa paglipat sa pamamagitan ng paggawa ng imposibleng tumawag sa mga pamamaraan na nangangailangan ng `&mut T` sa kanila (tulad ng [`mem::swap`]).
//!
//! [`Pin<P>`] maaaring magamit upang balutin ang anumang uri ng pointer na `P`, at dahil dito nakikipag-ugnay ito sa [`Deref`] at [`DerefMut`].Isang [`Pin<P>`] kung saan ang `P: Deref` ay dapat isaalang-alang bilang isang "`P`-style pointer" sa isang naka-pin na `P::Target`-kaya, isang [`Pin`]`<`[`Box`]`<T>>`ay pag-aari ng pointer sa isang naka-pin na `T`, at isang [`Pin`] `<` [`Rc`]`<T>>`ay isang pointer na binibilang ng sanggunian sa isang naka-pin na `T`.
//! Para sa kawastuhan, ang [`Pin<P>`] ay umaasa sa mga pagpapatupad ng [`Deref`] at [`DerefMut`] na hindi lumipat sa kanilang `self` parameter, at kailanman lamang na ibalik ang isang pointer sa naka-pin na data kapag tinawag sila sa isang naka-pin na pointer.
//!
//! # `Unpin`
//!
//! Maraming uri ang palaging malayang maililipat, kahit na naka-pin, dahil hindi sila umaasa sa pagkakaroon ng isang matatag na address.Kabilang dito ang lahat ng mga pangunahing uri (tulad ng [`bool`], [`i32`], at mga sanggunian) pati na rin ang mga uri na binubuo lamang ng mga ganitong uri.Ang mga uri na walang pakialam sa pag-pin ay nagpapatupad ng [`Unpin`] auto-trait, na nagkansela ng epekto ng [`Pin<P>`].
//! Para sa `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`at [`Box<T>`] gumana nang magkapareho, tulad ng ginagawa ng [`Pin`] `<&mut T>` at `&mut T`.
//!
//! Tandaan na ang pag-pin at [`Unpin`] ay nakakaapekto lamang sa matulis na uri na `P::Target`, hindi ang uri ng pointer na `P` mismo na nakabalot sa [`Pin<P>`].Halimbawa, kung ang [`Box<T>`] ay [`Unpin`] o walang epekto sa pag-uugali ng [`Pin`]`<`[`Box`] `<T>>`(dito, ang `T` ay ang itinuro-sa uri).
//!
//! # Halimbawa: self-referential str
//!
//! Bago kami magpunta sa higit pang mga detalye upang ipaliwanag ang mga garantiya at mga pagpipilian na nauugnay sa `Pin<T>`, tinatalakay namin ang ilang mga halimbawa kung paano ito magagamit.
//! Huwag mag-atubiling [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Ito ay isang self-referential struct dahil ang slice field ay tumuturo sa field ng data.
//! // Hindi namin maaaring ipaalam sa tagatala tungkol doon sa isang normal na sanggunian, dahil ang pattern na ito ay hindi mailalarawan sa karaniwang mga panuntunan sa paghiram.
//! //
//! // Sa halip ay gumagamit kami ng isang hilaw na pointer, kahit na ang isa na alam na hindi null, tulad ng alam namin na ito ay tumuturo sa string.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Upang matiyak na hindi gumagalaw ang data kapag bumalik ang pagpapaandar, inilalagay namin ito sa tambak kung saan ito mananatili sa habang buhay ng bagay, at ang tanging paraan upang ma-access ito ay sa pamamagitan ng isang pointer dito.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // nililikha lamang namin ang pointer sa sandaling ang data ay nasa lugar kung hindi man ay lumipat na ito bago pa kami magsimula
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // alam namin na ito ay ligtas dahil ang pagbabago ng isang patlang ay hindi ilipat ang buong struct
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Dapat ituro ng pointer ang tamang lokasyon, hangga't hindi pa gumagalaw ang struktura.
//! //
//! // Samantala, malaya tayong ilipat ang pointer sa paligid.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Dahil ang aming uri ay hindi nagpapatupad ng Unpin, mabibigo itong mag-ipon:
//! // hayaan mut bago_unmove= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Halimbawa: mapanghimasok na listahan ng dobleng naka-link
//!
//! Sa isang mapanghimasok na listahan na doble-link, ang koleksyon ay hindi aktwal na naglalaan ng memorya para sa mga elemento mismo.
//! Ang alokasyon ay kinokontrol ng mga kliyente, at ang mga elemento ay maaaring mabuhay sa isang stack frame na mas maikli ang buhay kaysa sa koleksyon.
//!
//! Upang magawa ang trabahong ito, ang bawat elemento ay may mga pahiwatig sa hinalinhan at kahalili nito sa listahan.Ang mga elemento ay maaari lamang maidagdag kapag naka-pin ang mga ito, dahil ang paglipat ng mga elemento sa paligid ay mawawalan ng bisa ang mga payo.Bukod dito, ang pagpapatupad ng [`Drop`] ng isang naka-link na elemento ng listahan ay mai-patch ang mga payo ng hinalinhan at kahalili nito upang alisin ang sarili mula sa listahan.
//!
//! Pangkahalagaan, kailangan nating umasa sa [`drop`] na tinawag.Kung ang isang elemento ay maaaring mapalitan o kung hindi man wasto na hindi tinawag nang [`drop`], ang mga pahiwatig dito mula sa mga kalapit na elemento ay magiging hindi wasto, na makakasira sa istraktura ng data.
//!
//! Samakatuwid, ang pag-pin ay may kasamang isang garantisadong kaugnay na [`drop`].
//!
//! # `Drop` guarantee
//!
//! Ang layunin ng pag-pin ay upang umasa sa paglalagay ng ilang data sa memorya.
//! Upang maisagawa ito, hindi lang paglipat ng data ang pinaghihigpitan;deallocating, repurposing, o kung hindi man pinawalang bisa ang memorya na ginamit upang mag-imbak ng data ay pinaghihigpitan din.
//! Sa kongkreto, para sa naka-pin data mayroon kang upang mapanatili ang invariant na *memorya nito ay hindi makapag-invalidated o repurposed mula sa sandaling ito ay makakakuha ng naka-pin hanggang kailan [`drop`] ay tinatawag na*.Minsan lamang bumalik ang [`drop`] o panics, maaaring magamit muli ang memorya.
//!
//! Ang memorya ay maaaring "invalidated" sa pamamagitan ng deallocation, ngunit din sa pamamagitan ng pagpapalit ng isang [`Some(v)`] ng [`None`], o pagtawag sa [`Vec::set_len`] sa "kill" ilang mga elemento ng isang vector.Maaari itong repurposed sa pamamagitan ng paggamit ng [`ptr::write`] upang mai-overlap ito nang hindi muna tinatawagan ang destructor.Wala sa mga ito ang pinapayagan para sa naka-pin na data nang hindi tumatawag sa [`drop`].
//!
//! Ito mismo ang uri ng garantiya na ang mapanghimasok na listahan na naka-link mula sa nakaraang seksyon ay kailangang gumana nang tama.
//!
//! Pansinin na ito garantiya ay *hindi* ay nangangahulugan na memory ay hindi mabunyag!Ito ay pa rin ganap na okay hindi kailanman upang tawagan ang [`drop`] sa isang naka-pin na elemento (hal, maaari mo pa ring tawagan ang [`mem::forget`] sa isang [`Pin`]`<`[Box`]` `<T>>`).Sa halimbawa ng listahan ng doble na naka-link, ang elementong iyon ay mananatili lamang sa listahan.Gayunpaman hindi mo maaaring libre o muling gamitin ang imbakan *nang walang pagtawag [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Kung ang iyong uri ay gumagamit ng pag-pin (tulad ng dalawang halimbawa sa itaas), dapat kang mag-ingat sa pagpapatupad ng [`Drop`].Ang pagpapaandar ng [`drop`] ay tumatagal ng `&mut self`, ngunit ito ay tinatawag na *kahit na ang iyong uri ay dating na-pin*!Ito ay tulad ng kung ang tagatala ay awtomatikong tinatawag na [`Pin::get_unchecked_mut`].
//!
//! Hindi ito maaaring maging sanhi ng isang problema sa ligtas na code dahil ang pagpapatupad ng isang uri na umaasa sa pag-pin ay nangangailangan ng hindi ligtas na code, ngunit magkaroon ng kamalayan na ang pagpapasya na gamitin ang pag-pin sa iyong uri (halimbawa sa pamamagitan ng pagpapatupad ng ilang operasyon sa [`Pin`]"<&Sarili>`o [`Pin`] `<&mut Self>`) ay may mga kahihinatnan para sa iyong pagpapatupad ng [`Drop`] din: kung ang isang elemento ng iyong uri ay maaaring na-pin, dapat mong tratuhin ang [`Drop`] bilang implicit na pagkuha ng [`Pin`]`<&mut Sarili>`.
//!
//!
//! Halimbawa, maaari mong ipatupad ang `Drop` tulad ng sumusunod:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` ay okay dahil alam namin na ang halagang ito ay hindi na ginagamit muli pagkatapos na mai-drop.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Pupunta dito ang aktwal na drop code.
//!         }
//!     }
//! }
//! ```
//!
//! Ang pagpapaandar `inner_drop` ay may uri na [`drop`]*dapat* mayroon, kaya tinitiyak nito na hindi mo sinasadyang gamitin ang `self`/`this` sa isang paraan na salungat sa pag-pin.
//!
//! Bukod dito, kung ang iyong uri ay `#[repr(packed)]`, awtomatikong ilipat ng tagatala ang mga patlang upang ma-drop ang mga ito.Ito ay maaaring kahit gawin iyon para sa mga patlang na nangyari mang may sapat na hile-hilera.Bilang kinahinatnan, hindi mo maaaring gamitin pinning na may isang uri `#[repr(packed)]`.
//!
//! # Mga Proyekto at Structural Pinning
//!
//! Kapag nagtatrabaho kasama ang mga naka-pin na struct, lumilitaw ang tanong kung paano mai-access ng isang tao ang mga patlang ng istrukturang iyon sa isang pamamaraan na tumatagal lamang ng [`Pin`]`<&mut Struct>`.
//! Ang karaniwang diskarte ay ang pagsusulat ng mga pamamaraan ng helper (tinatawag na *projision*) na ginagawang isang sanggunian sa patlang ang [`Pin`]`<&mut Struct>`, ngunit anong uri ang dapat magkaroon ng sanggunian na iyon?Ito ba ay [`Pin`]`<&mut Field>`o `&mut Field`?
//! Ang parehong tanong ay arises sa mga patlang ng isang `enum`, at din kapag isinasaalang-alang ang mga uri ng container/wrapper tulad ng [`Vec<T>`], [`Box<T>`], o [`RefCell<T>`].
//! (Nalalapat ang katanungang ito sa parehong nababagabag at nakabahaging mga sanggunian, ginagamit lamang namin ang mas karaniwang kaso ng mga nababagong sanggunian dito para sa ilustrasyon.)
//!
//! Ito ay talagang nasa sa may-akda ng istraktura ng data upang magpasya kung ang naka-pin na projection para sa isang partikular na patlang ay nagiging [`Pin`]"<&mut Struct>`into [`Pin`] `<&mut Field>` o `&mut Field`.Mayroong ilang mga hadlang, at ang pinakamahalagang pagpigil ay ang *pagkakapare-pareho*:
//! ang bawat patlang ay maaaring *alinman* inaasahang sa isang naka-pin na sanggunian,*o* inalis ang pag-pin bilang bahagi ng projection.
//! Kung ang pareho ay tapos na para sa parehong larangan, malamang na iyon ay maging unsound!
//!
//! Bilang may-akda ng isang istraktura ng data makakakuha ka upang magpasya para sa bawat larangan kung ang pag-pin ng "propagates" sa patlang na ito o hindi.
//! Ang pag-pin na nagpapalaganap ay tinatawag ding "structural", sapagkat sumusunod ito sa istraktura ng uri.
//! Sa sumusunod na mga subsection, ilarawan namin ang mga pagsasaalang-alang na ikaw ay may na isasagawa para sa alinman sa pagpipilian.
//!
//! ## Ang pag-pin *ay hindi* istruktura para sa `field`
//!
//! Maaaring mukhang counter-intuitive na ang patlang ng isang naka-pin na struct ay maaaring hindi ma-pin, ngunit iyon talaga ang pinakamadaling pagpipilian: kung ang isang [`Pin`]`<&mut Field>`ay hindi nilikha, walang maaaring magkamali!Kaya, kung magpasya ka na ang ilang mga patlang ay walang istruktura na pag-pin, ang kailangan mo lamang tiyakin na hindi ka makakalikha ng isang naka-pin na sanggunian sa patlang na iyon.
//!
//! Ang mga patlang na walang pag-pin sa istruktura ay maaaring magkaroon ng isang pamamaraan ng pag-proxy na magiging `&mut Field` ang [`Pin`]`<&mut Struct>`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Ito ay okay dahil ang `field` ay hindi kailanman itinuturing na naka-pin.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Maaari mo ring `impl Unpin for Struct`*kahit na* ang uri ng `field` ay hindi [`Unpin`].Kung ano ang iniisip ng uri na iyon tungkol sa pag-pin ay hindi nauugnay kapag walang [`Pin`]`<&mut Field>` na nilikha kailanman.
//!
//! ## Ang pinning *ay* istruktura para sa `field`
//!
//! Ang iba pang pagpipilian ay upang magpasya na ang pag-pin ay "structural" para sa `field`, nangangahulugan na kung ang istr ay nai-pin pagkatapos ay ang patlang.
//!
//! Pinapayagan ang pagsusulat ng isang projection na lumilikha ng isang [`Pin`]`<&mut Field>`, sa gayon nasasaksihan na ang patlang ay naka-pin:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Okay lang ito dahil ang `field` ay naka-pin kapag `self` ay.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Gayunpaman, ang pag-pin sa istruktura ay may ilang mga karagdagang mga kinakailangan:
//!
//! 1. Ang istruktura ay dapat na [`Unpin`] lamang kung ang lahat ng mga patlang ng istruktura ay [`Unpin`].Ito ang default, ngunit ang [`Unpin`] ay isang ligtas na trait, kaya bilang may-akda ng istr ay responsibilidad mo *hindi* upang magdagdag ng isang bagay tulad ng `impl<T> Unpin for Struct<T>`.
//! (Pansinin na ang pagdaragdag ng isang pagpapatakbo ng pagpapatakbo ay nangangailangan ng hindi ligtas na code, kaya't ang katotohanang ang [`Unpin`] ay isang ligtas na trait ay hindi masisira ang prinsipyo na mag-aalala ka lamang tungkol sa anuman dito kung gagamitin mo ang `hindi ligtas`.)
//! 2. Ang destructor ng struct ay hindi dapat ilipat ang mga struktural na patlang sa argumento nito.Ito ang eksaktong punto na itinaas sa [previous section][drop-impl]: Ang `drop` ay tumatagal ng `&mut self`, ngunit ang struct (at samakatuwid ang mga patlang nito) ay maaaring nai-pin bago.
//!     Mayroon kang garantiya na hindi mo ilipat ang isang patlang sa loob ng iyong pagpapatupad ng [`Drop`].
//!     Sa partikular, tulad ng ipinaliwanag dati, ito ay nangangahulugan na ang iyong struct dapat *hindi* maging `#[repr(packed)]`.
//!     Tingnan ang seksyong iyon para sa kung paano isulat ang [`drop`] sa isang paraan na makakatulong sa iyo ang tagatala na hindi aksidenteng masira ang pag-pin.
//! 3. Dapat mong tiyakin na itataguyod mo ang [`Drop` guarantee][drop-guarantee]:
//!     sa sandaling na-pin ang iyong istruktura, ang memorya na naglalaman ng nilalaman ay hindi na-o-overtake o deallocated nang hindi tumatawag sa mga destructor ng nilalaman.
//!     Ito ay maaaring maging nakakalito, na ipinakita ng [`VecDeque<T>`]: ang destructor ng [`VecDeque<T>`] maaaring mabigo upang tawagan [`drop`] sa lahat ng mga elemento kung ang isa sa destructors panics.Lumalabag ito sa garantiyang [`Drop`], sapagkat maaari itong humantong sa mga elemento na ma-deallocated nang hindi tinawag ang kanilang destructor.(Ang [`VecDeque<T>`] ay walang mga pag-i-project ng pag-pin, kaya't hindi ito nagiging sanhi ng pagkabagabag.)
//! 4. Hindi ka dapat mag-alok ng anumang iba pang mga pagpapaandar na maaaring humantong sa mga data inililipat sa labas ng structural mga patlang kapag ang iyong uri ay naka-pin.Halimbawa data
//!
//!     Para sa isang mas kumplikadong halimbawa ng paglipat ng data mula sa isang naka-pin na uri, isipin kung ang [`RefCell<T>`] ay may pamamaraan na `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Pagkatapos ay maaari naming gawin ang mga sumusunod:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Ito ay sakuna, nangangahulugan ito na maaari muna nating mai-pin ang nilalaman ng [`RefCell<T>`] (gamit ang `RefCell::get_pin_mut`) at pagkatapos ay ilipat ang nilalamang iyon gamit ang nababagong sanggunian na nakuha namin sa paglaon.
//!
//! ## Examples
//!
//! Para sa isang uri tulad ng [`Vec<T>`], ang parehong mga posibilidad (pag-pin sa istruktura o hindi) magkaroon ng kahulugan.
//! Ang isang [`Vec<T>`] na may istrukturang pag-pin ay maaaring magkaroon ng mga pamamaraan ng `get_pin`/`get_pin_mut` upang makakuha ng mga naka-pin na sanggunian sa mga elemento.Gayunpaman, hindi nito *maaaring* payagan ang pagtawag sa [`pop`][Vec::pop] sa isang naka-pin na [`Vec<T>`] sapagkat maililipat nito ang (nilalaman na nai-pin na) mga nilalaman!Hindi rin pinapayagan ang [`push`][Vec::push], na maaaring mag-reallocate at sa gayon ay ilipat din ang mga nilalaman.
//!
//! Ang [`Vec<T>`] nang walang istrukturang pag-pin ay maaaring `impl<T> Unpin for Vec<T>`, dahil ang mga nilalaman ay hindi na-pin at ang [`Vec<T>`] mismo ay mabuti sa paglipat din.
//! Sa puntong iyon ang pag-pin ay wala ring epekto sa vector sa lahat.
//!
//! Sa karaniwang silid-aklatan, ang mga uri ng pointer sa pangkalahatan ay walang pag-pin sa istruktura, at sa gayon ay hindi sila nag-aalok ng mga paglalagay ng pag-pin.Ito ang dahilan kung bakit humahawak ang `Box<T>: Unpin` para sa lahat ng `T`.
//! Ito ang akma na gawin ito para sa mga uri pointer, dahil sa paglipat ng `Box<T>` hindi aktwal na ilipat ang `T`: ang [`Box<T>`] ay maaaring maging malayang naigagalaw (aka `Unpin`) kahit na ang `T` ay hindi.Sa katunayan, kahit na [`Pin`]`<`[`Box`] `<T>>`at [`Pin`] `<&mut T>` ay palaging [`Unpin`] kanilang sarili, para sa parehong dahilan: ang kanilang mga nilalaman (ang `T`) ay naka-pin, ngunit ang mga payo mismo ay maaaring ilipat nang hindi ilipat ang naka-pin na data.
//! Para sa parehong [`Box<T>`] at [`Pin`]`<`[`Box`] `<T>>`, kung ang nilalaman ay naka-pin ay ganap na independiyente sa kung ang pointer ay naka-pin, nangangahulugang ang pag-pin ay *hindi* istruktura.
//!
//! Kapag nagpapatupad ng isang [`Future`] combinator, karaniwang kakailanganin mo ang istruktura na pag-pin para sa naka-pugad na futures, dahil kailangan mong makakuha ng mga naka-pin na sanggunian sa kanila upang tumawag sa [`poll`].
//! Ngunit kung ang iyong combinator ay naglalaman ng anumang iba pang data na hindi kailangang ma-pin, maaari mong gawing hindi istruktura ang mga patlang na iyon at kaya malayang i-access ang mga ito sa isang nababagabag na sanggunian kahit na mayroon ka lamang [`Pin`]`<&mut Self>`(tulad tulad ng sa iyong sariling pagpapatupad ng [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Isang naka-pin na pointer.
///
/// Ito ay isang pambalot sa paligid ng isang uri ng pointer na kung saan ay ginagawang halaga ang pointer na "pin" sa lugar, pinipigilan ang halaga na isinangguni ng pointer na mula sa paglipat maliban kung ipapatupad nito ang [`Unpin`].
///
///
/// *Tingnan ang dokumentasyon ng [`pin` module] para sa isang paliwanag ng pag-pin.*
///
/// [`pin` module]: self
///
// Note: ang `Clone` na nakuha mula sa ibaba ay nagdudulot ng pagkabagabag hangga't posible na ipatupad
// `Clone` para sa mga nababagong sanggunian.
// Tingnan ang <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> para sa higit pang mga detalye.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Ang mga sumusunod na pagpapatupad ay hindi nakuha upang maiwasan ang mga isyu sa pagiging maayos.
// `&self.pointer` hindi dapat ma-access sa mga hindi pinagkakatiwalaang pagpapatupad ng trait.
//
// Tingnan ang <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> para sa higit pang mga detalye.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Bumuo ng isang bagong `Pin<P>` sa paligid ng isang pointer sa ilang data ng isang uri na nagpapatupad ng [`Unpin`].
    ///
    /// Hindi tulad ng `Pin::new_unchecked`, ang pamamaraang ito ay ligtas dahil ang pointer `P` ay nag-aalis sa mga uri ng [`Unpin`], na kinakansela ang mga garantiya sa pag-pin.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // KALIGTASAN: ang halagang itinuro ay `Unpin`, at sa gayon ay walang mga kinakailangan
        // sa paligid ng pag-pin.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Inaalis ang `Pin<P>` na ito na ibinabalik ang pinagbabatayan na pointer.
    ///
    /// Kinakailangan nito na ang data sa loob ng `Pin` na ito ay [`Unpin`] upang maaari naming balewalain ang mga invariant ng pag-pin kapag ina-undap ito.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Bumuo ng isang bagong `Pin<P>` sa paligid ng isang sanggunian sa ilang data ng isang uri na maaaring o hindi maipatupad `Unpin`.
    ///
    /// Kung ang `pointer` dereferences sa isang uri ng `Unpin`, ang `Pin::new` ay dapat gamitin sa halip.
    ///
    /// # Safety
    ///
    /// Ang tagapagbuo na ito ay hindi ligtas dahil hindi namin magagarantiyahan na ang data na itinuro sa pamamagitan ng `pointer` ay naka-pin, nangangahulugang hindi maililipat ang data o hindi wasto ang imbakan nito hanggang sa mahulog ito.
    /// Kung ang itinayong `Pin<P>` ay hindi ginagarantiyahan na ang data na `P` na puntos na naka-pin, iyon ay isang paglabag sa kontrata ng API at maaaring humantong sa hindi natukoy na pag-uugali sa mga pagpapatakbo na (safe) sa paglaon.
    ///
    /// Sa pamamagitan ng paggamit ng pamamaraang ito, gumagawa ka ng isang promise tungkol sa pagpapatupad ng `P::Deref` at `P::DerefMut`, kung mayroon sila.
    /// Pinakamahalaga, hindi sila dapat kumawala sa kanilang mga argumentong `self`: Tatawagan ng `Pin::as_mut` at `Pin::as_ref` ang `DerefMut::deref_mut` at `Deref::deref`*sa naka-pin na pointer* at asahan ang mga pamamaraang ito na panatilihin ang mga invariant ng pag-pin.
    /// Bukod dito, sa pamamagitan ng pagtawag sa pamamaraang ito sa iyo promise na ang sanggunian na `P` dereferences upang hindi mailipat muli;sa partikular, hindi dapat posible upang makakuha ng isang `&mut P::Target` at pagkatapos ay lumipat sa sanggunian na iyon (gamit, halimbawa [`mem::swap`]).
    ///
    ///
    /// Halimbawa, ang pagtawag sa `Pin::new_unchecked` sa isang `&'a mut T` ay hindi ligtas dahil habang nagagawa mong i-pin ito para sa naibigay na habang buhay na `'a`, wala kang kontrol sa kung ito ay pinananatiling naka-pin sa sandaling matapos ang `'a`:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Nangangahulugan ito na ang pointee `a` ay hindi na makakagalaw muli.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Ang address ng `a` ay binago sa stack slot ng `b`, kaya't inilipat ang `a` kahit na na-pin natin ito dati!Lumabag kami sa pag-pin ng kontrata ng API.
    /////
    /// }
    /// ```
    ///
    /// Ang isang halaga, sa sandaling naka-pin, ay dapat manatiling naka-pin magpakailanman (maliban kung ang uri nito ay nagpapatupad ng `Unpin`).
    ///
    /// Katulad nito, ang pagtawag sa `Pin::new_unchecked` sa isang `Rc<T>` ay hindi ligtas dahil maaaring may mga alias sa parehong data na hindi napapailalim sa mga paghihigpit sa pag-pin:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Nangangahulugan ito na hindi na makakagalaw muli ang pointee.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Ngayon, kung ang `x` lamang ang sanggunian, mayroon kaming isang nababagong sanggunian sa data na na-pin namin sa itaas, na maaari naming magamit upang ilipat ito tulad ng nakita namin sa nakaraang halimbawa.
    ///     // Lumabag kami sa pag-pin ng kontrata ng API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Nakakakuha ng naka-pin na nakabahaging sanggunian mula sa naka-pin na pointer na ito.
    ///
    /// Ito ay isang pangkaraniwang pamamaraan upang pumunta mula sa `&Pin<Pointer<T>>` hanggang `Pin<&T>`.
    /// Ito ay ligtas sapagkat, bilang bahagi ng kontrata ng `Pin::new_unchecked`, hindi makagalaw ang pointee matapos malikha ang `Pin<Pointer<T>>`.
    ///
    /// "Malicious" Ang pagpapatupad ng `Pointer::Deref` ay pinipintasan din ng kontrata ng `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // KALIGTASAN: tingnan ang dokumentasyon sa pagpapaandar na ito
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Inaalis ang `Pin<P>` na ito na ibinabalik ang pinagbabatayan na pointer.
    ///
    /// # Safety
    ///
    /// Ang function na ito ay hindi ligtas.Dapat mong garantiya na ipagpapatuloy mong gamutin ang pointer `P` na naka-pin pagkatapos mong tawagan ang pagpapaandar na ito, upang ang mga invariant sa uri ng `Pin` ay maaaring mapanatili.
    /// Kung ang code na gumagamit ng nagresultang `P` ay hindi nagpapatuloy na panatilihin ang mga pag-pin ng invariant na isang paglabag sa kontrata ng API at maaaring humantong sa hindi natukoy na pag-uugali sa paglaon ng mga pagpapatakbo ng (safe).
    ///
    ///
    /// Kung ang pinagbabatayan ng data ay [`Unpin`], dapat gamitin sa halip ang [`Pin::into_inner`].
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Nakakakuha ng naka-pin na pabagu-bago na sanggunian mula sa naka-pin na pointer na ito.
    ///
    /// Ito ay isang pangkaraniwang pamamaraan upang pumunta mula sa `&mut Pin<Pointer<T>>` hanggang `Pin<&mut T>`.
    /// Ito ay ligtas sapagkat, bilang bahagi ng kontrata ng `Pin::new_unchecked`, hindi makagalaw ang pointee matapos malikha ang `Pin<Pointer<T>>`.
    ///
    /// "Malicious" Ang pagpapatupad ng `Pointer::DerefMut` ay pinipintasan din ng kontrata ng `Pin::new_unchecked`.
    ///
    /// Kapaki-pakinabang ang pamamaraang ito kapag gumagawa ng maraming mga tawag sa mga pagpapaandar na ubusin ang naka-pin na uri.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // gumawa ng paraan
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` kumonsumo ng `self`, kaya't muling pasukin ang `Pin<&mut Self>` sa pamamagitan ng `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // KALIGTASAN: tingnan ang dokumentasyon sa pagpapaandar na ito
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Nagtatalaga ng isang bagong halaga sa memorya sa likod ng naka-pin na sanggunian.
    ///
    /// Ang na-overtake na ito ay naka-pin na data, ngunit iyan ay okay: tatakbo ang destructor nito bago mai-o-overtake, kaya't walang ginagarantiyang pag-pin ang nalabag.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Bumubuo ng isang bagong pin sa pamamagitan ng pagmamapa ng panloob na halaga.
    ///
    /// Halimbawa, kung nais mong makakuha ng isang `Pin` ng isang patlang ng isang bagay, maaari mo itong gamitin upang makakuha ng pag-access sa patlang na iyon sa isang linya ng code.
    /// Gayunpaman, maraming mga gotchas sa mga "pinning projections" na ito;
    /// tingnan ang dokumentasyon ng [`pin` module] para sa karagdagang mga detalye sa paksang iyon.
    ///
    /// # Safety
    ///
    /// Ang function na ito ay hindi ligtas.
    /// Dapat mong garantiya na ang data na iyong ibabalik ay hindi gagalaw hangga't hindi lumilipat ang halaga ng argumento (halimbawa, dahil ito ay isa sa mga larangan ng halagang iyon), at hindi ka rin lilipat sa argumento na natanggap mo ang panloob na pagpapaandar.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // KALIGTASAN: ang kontrata sa kaligtasan para sa `new_unchecked` ay dapat
        // tinaguyod ng tumatawag.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Nakakakuha ng isang nakabahaging sanggunian mula sa isang pin.
    ///
    /// Ito ay ligtas dahil hindi posible na lumipat sa isang nakabahaging sanggunian.
    /// Maaaring mukhang may isang isyu dito na may interior mutability: sa katunayan, posible * na ilipat ang isang `T` mula sa isang `&RefCell<T>`.
    /// Gayunpaman, hindi ito isang problema hangga't wala ring pagkakaroon ng `Pin<&T>` na tumuturo sa parehong data, at hindi ka pinapayagan ng `RefCell<T>` na lumikha ng isang naka-pin na sanggunian sa mga nilalaman nito.
    ///
    /// Tingnan ang talakayan sa ["pinning projections"] para sa karagdagang mga detalye.
    ///
    /// Note: Ang `Pin` ay nagpapatupad din ng `Deref` sa target, na maaaring magamit upang ma-access ang panloob na halaga.
    /// Gayunpaman, ang `Deref` ay nagbibigay lamang ng isang sanggunian na nabubuhay habang hinihiram ang `Pin`, hindi habang buhay ng `Pin` mismo.
    /// Pinapayagan ng pamamaraang ito ang pag-on sa `Pin` sa isang sanggunian na may parehong habang buhay tulad ng orihinal na `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Binabago ang `Pin<&mut T>` na ito sa isang `Pin<&T>` na may parehong habang-buhay.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Nakakakuha ng isang nababagong sanggunian sa data sa loob ng `Pin` na ito.
    ///
    /// Kinakailangan nito na ang data sa loob ng `Pin` na ito ay `Unpin`.
    ///
    /// Note: Nagpapatupad din ang `Pin` ng `DerefMut` sa data, na maaaring magamit upang ma-access ang panloob na halaga.
    /// Gayunpaman, ang `DerefMut` ay nagbibigay lamang ng isang sanggunian na nabubuhay habang hinihiram ang `Pin`, hindi habang buhay ng `Pin` mismo.
    ///
    /// Pinapayagan ng pamamaraang ito ang pag-on sa `Pin` sa isang sanggunian na may parehong habang buhay tulad ng orihinal na `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Nakakakuha ng isang nababagong sanggunian sa data sa loob ng `Pin` na ito.
    ///
    /// # Safety
    ///
    /// Ang function na ito ay hindi ligtas.
    /// Dapat mong garantiya na hindi mo kailanman ilipat ang data mula sa nababagong sanggunian na natanggap mo kapag tinawag mo ang pagpapaandar na ito, upang ang mga invariant sa uri ng `Pin` ay maaaring panatilihin.
    ///
    ///
    /// Kung ang kalakip na data ay `Unpin`, `Pin::get_mut` dapat gamitin sa halip.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Bumuo ng isang bagong pin sa pamamagitan ng pagmamapa ng panloob na halaga.
    ///
    /// Halimbawa, kung nais mong makakuha ng isang `Pin` ng isang patlang ng isang bagay, maaari mo itong gamitin upang makakuha ng pag-access sa patlang na iyon sa isang linya ng code.
    /// Gayunpaman, maraming mga gotchas sa mga "pinning projections" na ito;
    /// tingnan ang dokumentasyon ng [`pin` module] para sa karagdagang mga detalye sa paksang iyon.
    ///
    /// # Safety
    ///
    /// Ang function na ito ay hindi ligtas.
    /// Dapat mong garantiya na ang data na iyong ibabalik ay hindi gagalaw hangga't hindi lumilipat ang halaga ng argumento (halimbawa, dahil ito ay isa sa mga larangan ng halagang iyon), at hindi ka rin lilipat sa argumento na natanggap mo ang panloob na pagpapaandar.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // KALIGTASAN: ang tumatawag ay responsable para sa hindi paglipat ng
        // halaga sa labas ng sanggunian na ito.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // KALIGTASAN: tulad ng halaga ng `this` ay garantisadong wala
        // inilipat, ang tawag na ito sa `new_unchecked` ay ligtas.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Kumuha ng isang naka-pin na sanggunian mula sa isang static na sanggunian.
    ///
    /// Ito ay ligtas, dahil ang `T` ay hiniram para sa `'static` habang buhay, na hindi nagtatapos.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // KALIGTASAN: Ang 'static loan garantiya ang data ay hindi
        // moved/invalidated hanggang sa mahulog ito (na hindi kailanman).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Kumuha ng isang naka-pin na pabagu-bago na sanggunian mula sa isang static na nababagong sanggunian.
    ///
    /// Ito ay ligtas, dahil ang `T` ay hiniram para sa `'static` habang buhay, na hindi nagtatapos.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // KALIGTASAN: Ang 'static loan garantiya ang data ay hindi
        // moved/invalidated hanggang sa mahulog ito (na hindi kailanman).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: nangangahulugan ito na ang anumang impl ng `CoerceUnsized` na nagpapahintulot sa pamimilit mula sa
// isang uri na nagpahiwatig ng `Deref<Target=impl !Unpin>` sa isang uri na nagpahiwatig ng `Deref<Target=Unpin>` ay hindi maayos.
// Anumang mga naturang impl ay maaaring maging unsound para sa iba pang mga kadahilanan, gayunpaman, kaya't kailangan lang naming mag-ingat na hindi payagan ang mga naturang impls na mapunta sa std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}