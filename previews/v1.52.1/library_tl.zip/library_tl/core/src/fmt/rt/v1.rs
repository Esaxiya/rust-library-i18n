//! Ito ay isang panloob na module na ginagamit ng ifmt!runtime.Ang mga istrukturang ito ay inilalabas sa mga static arrays upang paunang sundin ang mga string ng format nang maaga.
//!
//! Ang mga kahulugang ito ay katulad sa kanilang `ct` mga katumbas, ngunit naiiba sa na ang mga ito ay maaaring statically ipamahagi at ay bahagyang na-optimize para sa runtime
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Posibleng alignments na maaaring hiniling bilang bahagi ng isang pag-format directive.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Pahiwatig na ang mga nilalaman ay dapat na nakahanay sa kaliwa.
    Left,
    /// Indikasyon na nilalaman ay dapat na i-right-nakahanay.
    Right,
    /// Indikasyon na nilalaman ay dapat na center-hile-hilera.
    Center,
    /// Walang hiniling na pagkakahanay.
    Unknown,
}

/// Ginamit ng [width](https://doc.rust-lang.org/std/fmt/#width) at [precision](https://doc.rust-lang.org/std/fmt/#precision) specifiers.
#[derive(Copy, Clone)]
pub enum Count {
    /// Tinukoy sa isang literal na numero, iniimbak ang halaga
    Is(usize),
    /// Tinukoy na gamit `$` at `*` syntaxes, nag-iimbak ang index sa `args`
    Param(usize),
    /// Hindi tinukoy
    Implied,
}