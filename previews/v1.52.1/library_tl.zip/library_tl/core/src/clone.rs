//! Ang `Clone` trait para sa mga uri na hindi maaaring 'implicitly copied'.
//!
//! Sa Rust, ang ilang mga simpleng uri ay "implicitly copyable" at kapag itinalaga mo ang mga ito o ipasa ang mga ito bilang mga argumento, ang tatanggap ay makakakuha ng isang kopya, naiwan ang orihinal na halaga sa lugar.
//! Ang mga uri ay hindi nangangailangan ng paglalaan upang kopyahin at walang finalizers (ibig sabihin, hindi sila naglalaman ng pag-aari kahon o ipatupad [`Drop`]), kaya ang compiler ay isinasaalang-alang ang mga ito murang at ligtas na kopyahin.
//!
//! Para sa iba pang mga uri ng mga kopya ay dapat na ginawa malinaw na, sa pamamagitan ng convention pagpapatupad ng [`Clone`] trait at pagtawag ng [`clone`] paraan.
//!
//! [`clone`]: Clone::clone
//!
//! Pangunahing halimbawa ng paggamit:
//!
//! ```
//! let s = String::new(); // Ang uri ng string ay nagpapatupad ng Clone
//! let copy = s.clone(); // para ma-clone natin ito
//! ```
//!
//! Upang madaling ipatupad ang I-clone ang trait, maaari mo ring gamitin ang `#[derive(Clone)]`.Halimbawa:
//!
//! ```
//! #[derive(Clone)] // idinagdag namin ang Clone trait sa Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // at ngayon maaari na nating mai-clone ito!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Isang karaniwang trait para sa kakayahang malinaw na doblehin ang isang bagay.
///
/// Iba't ibang mula sa [`Copy`] sa [`Copy`] na iyon ay implicit at labis na mura, habang ang `Clone` ay laging tahasang at maaaring o hindi maaaring maging mahal.
/// Upang maipatupad ang mga katangiang ito, hindi ka pinapayagan ng Rust na muling ipatupad ang [`Copy`], ngunit maaari mong muling ipatupad ang `Clone` at magpatakbo ng di-makatwirang code.
///
/// Dahil ang `Clone` ay mas pangkalahatan kaysa sa [`Copy`], maaari kang awtomatikong gumawa ng anumang [`Copy`] na maging `Clone` din.
///
/// ## Derivable
///
/// Ang trait na ito ay maaaring magamit sa `#[derive]` kung ang lahat ng mga patlang ay `Clone`.Ang `derive`d pagpapatupad ng [`Clone`] ay tinatawag na [`clone`] sa bawat patlang.
///
/// [`clone`]: Clone::clone
///
/// Para sa isang generic na istruktura, nagpapatupad ang `#[derive]` ng `Clone` nang may kondisyon sa pamamagitan ng pagdaragdag ng nakagapos na `Clone` sa mga generic na parameter.
///
/// ```
/// // `derive` nagpapatupad I-clone ang para sa Pagbabasa<T>kapag T ay I-clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Paano ko maipapatupad ang `Clone`?
///
/// Ang mga uri na [`Copy`] ay dapat magkaroon ng isang walang halaga na pagpapatupad ng `Clone`.Mas pormal:
/// kung `T: Copy`, `x: T`, at `y: &T`, kung gayon ang `let x = y.clone();` ay katumbas ng `let x = *y;`.
/// Ang mga manu-manong pagpapatupad ay dapat maging maingat upang mapanatili ang invariant na ito;gayunpaman, ang hindi ligtas na code ay hindi dapat umasa dito upang matiyak ang kaligtasan ng memorya.
///
/// Ang isang halimbawa ay isang generic na istruktura na humahawak ng isang function pointer.Sa kasong ito, ang pagpapatupad ng `Clone` ay hindi maaaring `derive`d, ngunit maaaring ipatupad bilang:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## karagdagang implementors
///
/// Bilang karagdagan sa mga [implementors listed below][impls], ang mga sumusunod na mga uri ring ipatupad `Clone`:
///
/// * Mga uri ng function na item (ibig sabihin, ang mga natatanging uri na tinukoy para sa bawat pagpapaandar)
/// * Mga uri ng pagpapaandar ng pointer (hal. `fn() -> i32`)
/// * Mga uri ng Array, para sa lahat ng laki, kung ang uri ng item ay nagpapatupad din ng `Clone` (hal, `[i32; 123456]`)
/// * Mga uri ng Tuple, kung ang bawat bahagi ay nagpapatupad din ng `Clone` (hal., `()`, `(i32, bool)`)
/// * uri pagsasara, kung ang mga ito makuha ang walang halaga mula sa kapaligiran o kung lahat ng mga naturang nakunan halaga ipatupad `Clone` kanilang mga sarili.
///   Tandaan na ang mga variable nakunan ng shared reference laging ipatupad `Clone` (kahit na ang referent ay hindi), habang ang mga variable nakunan ng mutable reference kailanman ipatupad `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Nagbabalik ng isang kopya ng halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str nagpapatupad ng Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Nagsasagawa ng pagtatalaga ng kopya mula sa `source`.
    ///
    /// `a.clone_from(&b)` ay katumbas ng `a = b.clone()` sa pagpapaandar, ngunit maaaring ma-override upang magamit muli ang mga mapagkukunan ng `a` upang maiwasan ang mga hindi kinakailangang paglalaan.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Kunin sa macro pagbuo ng isang impl ng trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): ang mga struct na ito ay ginagamit lamang ng#[derive] upang igiit na ang bawat bahagi ng isang uri ay nagpapatupad ng Clone o Copy.
//
//
// Ang mga structs ay hindi kailanman dapat na lumitaw sa user code.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Pagpapatupad ng `Clone` para sa mga primitive na uri.
///
/// Ang mga pagpapatupad na hindi mailarawan sa Rust ay ipinatupad sa `traits::SelectionContext::copy_clone_conditions()` sa `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Ang mga nakabahaging sanggunian ay maaaring ma-clone, ngunit ang mga nababagong sanggunian *ay hindi maaaring*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Ang mga nakabahaging sanggunian ay maaaring ma-clone, ngunit ang mga nababagong sanggunian *ay hindi maaaring*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}