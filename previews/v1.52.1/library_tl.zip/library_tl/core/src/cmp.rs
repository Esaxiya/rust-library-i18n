//! Pag-andar para sa pag-order at paghahambing.
//!
//! Ang module na ito ay naglalaman ng iba't-ibang mga kasangkapan para sa pag-order at paghahambing halaga.Sa buod:
//!
//! * [`Eq`] at [`PartialEq`] ay traits na nagbibigay-daan sa iyo upang tukuyin ang kabuuan at bahagyang pagkakapantay-pantay sa pagitan ng mga halaga, ayon sa pagkakabanggit.
//! Ang pagpapatupad sa kanila ng labis na karga sa mga operator ng `==` at `!=`.
//! * [`Ord`] at [`PartialOrd`] ay traits na nagbibigay-daan sa iyo upang tukuyin kabuuang at bahagyang orderings pagitan ng mga halaga, ayon sa pagkakabanggit.
//!
//! Ang pagpapatupad sa kanila ng labis na karga sa mga operator ng `<`, `<=`, `>`, at `>=`.
//! * [`Ordering`] ay isang enum na ibinalik ng mga pangunahing pag-andar ng [`Ord`] at [`PartialOrd`], at naglalarawan ng isang pag-order.
//! * [`Reverse`] ay isang istruktura na nagbibigay-daan sa iyo upang madaling baligtarin ang isang pag-order.
//! * [`max`] at [`min`] mga function na build off ng [`Ord`] at daan sa iyo upang mahanap ang maximum o minimum na ng dalawang mga halaga.
//!
//! Para sa karagdagang detalye, tingnan ang kaukulang dokumentasyon ng bawat item sa listahan.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait para sa pagkakapantay-pantay ng mga paghahambing na [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// Ito trait nagbibigay-daan para bahagyang pagkakapantay-pantay, para sa mga uri na hindi magkaroon ng isang buong ugnayang pagkakatumbas.
/// Halimbawa, sa mga lumulutang point number `NaN != NaN`, kaya ang mga lumulutang point point ay nagpapatupad ng `PartialEq` ngunit hindi [`trait@Eq`].
///
/// Pormal, ang pagkakapantay-pantay ay dapat na (para sa lahat ng `a`, `b`, `c` ng uri `A`, `B`, `C`):
///
/// - **Symmetric**: kung `A: PartialEq<B>` at `B: PartialEq<A>`, kung gayon ang **`a==b` ay nagpapahiwatig ng`b==a`**;at
///
/// - **palipat**: kung `A: PartialEq<B>` at `B: PartialEq<C>` at `A:
///   BahagyangEq<C>`, pagkatapos ay **` a==b`at `b == c` ay nagpapahiwatig ng`a==c`**.
///
/// Tandaan na ang `B: PartialEq<A>` (symmetric) at `A: PartialEq<C>` (transitive) impls ay hindi pinilit na umiiral, ngunit nalalapat ang mga kinakailangang ito sa tuwing ginagawa nila exist.
///
/// ## Derivable
///
/// Ang trait na ito ay maaaring magamit sa `#[derive]`.Kapag `nagmula` sa mga struct, dalawang mga pagkakataon ay pantay kung ang lahat ng mga patlang ay pantay, at hindi pantay kung ang anumang mga patlang ay hindi pantay.Kapag `nagmula` sa mga enum, ang bawat variant ay katumbas ng sarili nito at hindi katumbas ng iba pang mga variant.
///
/// ## Paano ko maipapatupad ang `PartialEq`?
///
/// `PartialEq` nangangailangan lamang ng [`eq`] na paraan upang maipatupad;Ang [`ne`] ay tinukoy sa mga tuntunin nito bilang default.Ang anumang manu-manong pagpapatupad ng [`ne`]*dapat* respetuhin ang mga panuntunan na [`eq`] ay isang mahigpit na kabaligtaran ng [`ne`];iyon ay, `!(a == b)` kung at kung `a != b` lamang.
///
/// Ang mga pagpapatupad ng `PartialEq`, [`PartialOrd`], at [`Ord`]*ay dapat* sumasang-ayon sa bawat isa.Madaling aksidenteng gawin silang hindi sumasang-ayon sa pamamagitan ng pagkuha ng ilan sa traits at manu-manong pagpapatupad ng iba.
///
/// Isang halimbawang pagpapatupad para sa isang domain kung saan ang dalawang libro ay itinuturing na parehong libro kung tumutugma ang kanilang ISBN, kahit na magkakaiba ang mga format:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Paano ko paghambingin ang dalawang magkaibang mga uri?
///
/// Ang uri maaari mong ihambing sa ay kinokontrol ng `uri ng parameter ni PartialEq`.
/// Halimbawa, i-tweak natin nang kaunti ang dati nating code:
///
/// ```
/// // Nagpapatupad ng derive<BookFormat>==<BookFormat>paghahambing
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Ipatupad<Book>==<BookFormat>paghahambing
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Ipatupad<BookFormat>==<Book>paghahambing
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Sa pamamagitan ng pagbabago ng `impl PartialEq for Book` sa `impl PartialEq<BookFormat> for Book`, pinapayagan naming maikumpara ang `BookFormat` sa`Book`s.
///
/// Ang isang paghahambing tulad ng nasa itaas, na hindi pinapansin ang ilang mga patlang ng istruktura, ay maaaring mapanganib.Ito ay maaaring madaling humantong sa isang unintended paglabag ng mga kinakailangan para sa isang bahagyang ugnayang pagkakatumbas.
/// Halimbawa, kung nag-iingat kami sa itaas pagpapatupad ng `PartialEq<Book>` para `BookFormat` at nagdagdag ng isang pagpapatupad ng `PartialEq<Book>` para `Book` (alinman sa pamamagitan ng isang `#[derive]` o sa pamamagitan ng manu-manong pagpapatupad mula sa unang halimbawa) at pagkatapos ay ang resulta ay lalabag transitivity:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Ang pamamaraan na ito pagsusulit para `self` at `other` halaga na maging pantay-pantay, at ay ginagamit ng `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Ang pamamaraang ito ay sumusubok para sa `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Nakuha ang macro na bumubuo ng isang impl ng trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait para sa mga paghahambing ng pagkakapantay-pantay na kung saan ay [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Ito ay nangangahulugan na, na bilang karagdagan sa `a == b` at `a != b` pagiging mahigpit inverses, pagkakapantay-pantay ay dapat na (para sa lahat ng `a`, `b` at `c`):
///
/// - reflexive: `a == a`;
/// - symmetric: `a == b` nagpapahiwatig `b == a`;at
/// - palipat: `a == b` at `b == c` nagpapahiwatig `a == c`.
///
/// Ang property na ito ay hindi maaaring naka-check sa pamamagitan ng compiler, at samakatuwid `Eq` nagpapahiwatig [`PartialEq`], at may walang dagdag na mga pamamaraan.
///
/// ## Derivable
///
/// Ang trait na ito ay maaaring magamit sa `#[derive]`.
/// Kapag `derive`d, dahil ang `Eq` ay walang labis na pamamaraan, ipinapaalam lamang sa tagatala na ito ay isang kaugnay na pagkapareho kaysa sa isang bahagyang pagkakaugnay sa pagkapareho.
///
/// Tandaan na ang diskarte sa `derive` ay nangangailangan ng lahat ng mga patlang ay `Eq`, na hindi palaging nais.
///
/// ## Paano ko maipapatupad ang `Eq`?
///
/// Kung hindi mo magagamit ang diskarte sa `derive`, tukuyin na ang iyong uri ay nagpapatupad ng `Eq`, na walang mga pamamaraan:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // ang paraan na ito ay ginagamit lamang sa pamamagitan ng#[panggagaling] upang igiit na ang bawat bahagi ng isang i-type ang mga nagpapatupad#[panggagaling] mismo, ang kasalukuyang panggagaling imprastraktura paggawa nito paggigiit nang hindi gumagamit ng isang pamamaraan na ito trait ibig sabihin nito ay halos imposible.
    //
    //
    // Ito ay hindi kailanman dapat na ipinatupad sa pamamagitan ng kamay.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Kunin sa macro pagbuo ng isang impl ng trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: ang istrukturang ito ay ginagamit lamang ng#[derive] to
// igiit na ang bawat bahagi ng isang i-type ang mga nagpapatupad Eq.
//
// Ang strukturang ito ay hindi dapat lumitaw sa code ng gumagamit.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Ang isang `Ordering` ay ang resulta ng isang paghahambing sa pagitan ng dalawang mga halaga.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Isang pag-order kung saan ang isang inihambing na halaga ay mas mababa kaysa sa iba pa.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Isang pag-order kung saan ang isang inihambing na halaga ay katumbas ng iba pa.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Ang isang pag-order kung saan ang isang kumpara halaga ay mas malaki kaysa sa isa pa.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Ibinabalik ang `true` kung ang pag-order ay ang `Equal` variant.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Ibinabalik ang `true` kung ang pag-order ay hindi ang `Equal` variant.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Ibinabalik ang `true` kung ang pag-order ay ang `Less` variant.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Ibinabalik ang `true` kung ang pag-order ay ang `Greater` variant.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Ibinabalik ang `true` kung ang pag-order ay alinman sa `Less` o `Equal` variant.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Ibinabalik ang `true` kung ang pag-order ay alinman sa `Greater` o `Equal` variant.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Binabaliktad ang `Ordering`.
    ///
    /// * `Less` nagiging `Greater`.
    /// * `Greater` nagiging `Less`.
    /// * `Equal` nagiging `Equal`.
    ///
    /// # Examples
    ///
    /// Basic na pag-uugali:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Maaaring gamitin ang pamamaraang ito upang baligtarin ang isang paghahambing:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // pag-uri-uriin ang array mula sa pinakamalaki hanggang sa pinakamaliit.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Chains dalawang pag-order.
    ///
    /// Ibinabalik ang `self` kapag hindi ito `Equal`.Kung hindi man ay nagbabalik ng `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Chains ang pag-order gamit ang naibigay na pagpapaandar.
    ///
    /// Ibinabalik ang `self` kapag hindi ito `Equal`.
    /// Kung hindi man ay tumatawag sa `f` at ibabalik ang resulta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Ang isang helper struct para sa reverse order.
///
/// struct na ito ay isang helper upang magamit sa mga pag-andar tulad ng [`Vec::sort_by_key`] at maaaring magamit upang baliktarin pagkakasunod-sunod ng isang bahagi ng isang key.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait para sa mga uri na bumubuo ng isang [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// Ang isang order ay isang kabuuang pagkakasunud-sunod kung ito ay (para sa lahat ng `a`, `b` at `c`):
///
/// - kabuuan at walang simetrya: eksaktong isa sa `a < b`, `a == b` o `a > b` ay totoo;at
/// - palipat, `a < b` at `b < c` ay nagpapahiwatig ng `a < c`.Ang pareho ay dapat na hawakan para sa parehong `==` at `>`.
///
/// ## Derivable
///
/// Ang trait na ito ay maaaring magamit sa `#[derive]`.
/// Kapag `nagmula` sa mga struct, makagawa ito ng isang pag-order ng [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) batay sa tuktok na pababa na pagkakasunud-sunod ng deklarasyon ng mga kasapi ng istr.
///
/// Kapag `derive`d sa enums, variants ay inayos ayon sa kanilang top-sa-ilalim discriminant order.
///
/// ## Paghahambing sa leksikograpiko
///
/// Ang paghahambing ng Lexicograpical ay isang operasyon na may mga sumusunod na katangian:
///  - Dalawang mga pagkakasunud-sunod ay inihambing elemento sa pamamagitan ng elemento.
///  - Ang unang hindi pagtutugma na elemento ay tumutukoy sa aling pagkakasunud-sunod ang mas maliit o mas malaki sa lexicograpically kaysa sa isa pa.
///  - Kung ang isa sa pagkakasunod-sunod ay isang prefix ng isa pa, ang mas maikli pagkakasunod-sunod ay lexicographically mas mababa kaysa sa isa.
///  - Kung dalawa sequence ay may katumbas na mga elemento at ay ng parehong haba, pagkatapos ay ang mga pagkakasunud-sunod ay lexicographically pantay.
///  - Ang isang walang laman na pagkakasunud-sunod ay mas mababa sa lexicograpically kaysa sa anumang hindi walang laman na pagkakasunud-sunod.
///  - Dalawang walang laman na pagkakasunud-sunod ay pantay-pantay na lexicographically.
///
/// ## Paano ko maipapatupad ang `Ord`?
///
/// `Ord` Kinakailangan na ang uri ay maging [`PartialOrd`] at [`Eq`] (na nangangailangan ng [`PartialEq`]).
///
/// Pagkatapos ay kailangan mong tukuyin ang isang pagpapatupad para [`cmp`].Maaari mong makita na kapaki-pakinabang na gamitin ang [`cmp`] sa mga patlang ng iyong uri.
///
/// Ang mga pagpapatupad ng [`PartialEq`], [`PartialOrd`], at `Ord`*ay dapat* sumasang-ayon sa bawat isa.
/// Iyon ay, `a.cmp(b) == Ordering::Equal` kung at kung `a == b` at `Some(a.cmp(b)) == a.partial_cmp(b)` lamang para sa lahat ng `a` at `b`.
/// Madaling aksidenteng gawin silang hindi sumasang-ayon sa pamamagitan ng pagkuha ng ilan sa traits at manu-manong pagpapatupad ng iba.
///
/// Narito ang isang halimbawa kung saan mo nais upang pagbukud-bukurin ang mga tao sa pamamagitan ng taas lamang, bahala `id` at `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Ang pamamaraang ito ay nagbabalik ng isang [`Ordering`] sa pagitan ng `self` at `other`.
    ///
    /// Sa pamamagitan ng convention, `self.cmp(&other)` nagbabalik ang pag-order ng pagtutugma ng expression `self <operator> other` kung totoo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Naghahambing at nagbabalik ng maximum na dalawang halaga.
    ///
    /// Ibinabalik ang pangalawang argumento kung tinutukoy ng paghahambing na pantay ang mga ito.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Pinagkukumpara at nagbabalik ang minimum na ng dalawang mga halaga.
    ///
    /// Ibinabalik ang unang argumento kung tinutukoy ng paghahambing na pantay ang mga ito.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Limitahan ang halaga sa isang tiyak na pagitan.
    ///
    /// Ibinabalik `max` kung `self` ay mas malaki kaysa `max`, at `min` kung `self` ay mas mababa kaysa `min`.
    /// Kung hindi man ito ay nagbabalik `self`.
    ///
    /// # Panics
    ///
    /// Panics kung `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Nakuha ang macro na bumubuo ng isang impl ng trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait para sa mga halaga na maaaring maihambing sa isang uri-order.
///
/// Dapat na masiyahan ang paghahambing, para sa lahat ng `a`, `b` at `c`:
///
/// - asymmetry: kung `a < b` pagkatapos ay `!(a > b)`, pati na rin `a > b` nagpapahiwatig `!(a < b)`;at
/// - transitivity: Ang `a < b` at `b < c` ay nagpapahiwatig ng `a < c`.Ang pareho ay dapat na hawakan para sa parehong `==` at `>`.
///
/// Tandaan na ang mga kinakailangang ito ay nangangahulugan na ang trait mismo ay dapat na ipatupad nang simetriko at palipat: kung `T: PartialOrd<U>` at `U: PartialOrd<V>` pagkatapos ay `U: PartialOrd<T>` at `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Ang trait na ito ay maaaring magamit sa `#[derive]`.Kapag `derive`d sa structs, ito ay makabuo ng isang leksikograpiko pag-order batay sa mga top-sa-ilalim deklarasyon pagkakasunud-sunod ng mga miyembro ng struct ni.
/// Kapag `derive`d sa enums, variants ay inayos ayon sa kanilang top-sa-ilalim discriminant order.
///
/// ## Paano ko maipapatupad ang `PartialOrd`?
///
/// `PartialOrd` nangangailangan lamang ng pagpapatupad ng [`partial_cmp`] na pamamaraan, kasama ang iba pa na nabuo mula sa mga default na pagpapatupad.
///
/// Gayunpaman nananatiling posible na ipatupad ang iba nang magkahiwalay para sa mga uri na walang kabuuang order.
/// Halimbawa, para sa mga lumulutang na numero ng point, `NaN < 0 == false` at `NaN >= 0 == false` (cf.
/// IEEE 754-2008 seksyon 5.11).
///
/// `PartialOrd` nangangailangan ng iyong uri na maging [`PartialEq`].
///
/// Ang mga pagpapatupad ng [`PartialEq`], `PartialOrd`, at [`Ord`]*ay dapat* sumasang-ayon sa bawat isa.
/// Madaling aksidenteng gawin silang hindi sumasang-ayon sa pamamagitan ng pagkuha ng ilan sa traits at manu-manong pagpapatupad ng iba.
///
/// Kung ang iyong uri ay [`Ord`], maaari mong ipatupad ang [`partial_cmp`] sa pamamagitan ng paggamit ng [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Maaari mo rin mahanap ito kapaki-pakinabang upang gamitin [`partial_cmp`] sa mga patlang ang iyong mga uri ng.
/// Narito ang isang halimbawa ng `Person` uri na may isang lumulutang-point `height` patlang na iyon ay ang tanging patlang na gagamitin para sa pag-uuri:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Ibinabalik ng pamamaraang ito ang isang pag-order sa pagitan ng mga halagang `self` at `other` kung mayroon ang isa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Kapag imposible ang paghahambing:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Ang pamamaraang ito ay sumusubok nang mas mababa sa (para sa `self` at `other`) at ginagamit ng `<` operator.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Ang pamamaraan na ito pagsusulit mas mababa sa o katumbas ng (para sa `self` at `other`) at ito ay ginagamit ng mga `<=` operator.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Ang pamamaraang ito ay sumusubok ng mas malaki kaysa sa (para sa `self` at `other`) at ginagamit ng `>` operator.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Ang pamamaraang ito ay sumusubok ng mas malaki kaysa o katumbas ng (para sa `self` at `other`) at ginagamit ng `>=` operator.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Nakuha ang macro na bumubuo ng isang impl ng trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Pinagkukumpara at nagbabalik ang minimum na ng dalawang mga halaga.
///
/// Ibinabalik ang unang argumento kung tinutukoy ng paghahambing na pantay ang mga ito.
///
/// Panloob ay gumagamit ng isang alias sa [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Ibinabalik ang minimum sa dalawang halaga na may paggalang sa mga tinukoy na function na paghahambing.
///
/// Ibinabalik ang unang argumento kung tinutukoy ng paghahambing na pantay ang mga ito.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Ibinabalik ang elemento na nagbibigay ng minimum na halaga mula sa tinukoy na pagpapaandar.
///
/// Ibinabalik ang unang argumento kung tinutukoy ng paghahambing na pantay ang mga ito.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Naghahambing at nagbabalik ng maximum na dalawang halaga.
///
/// Ibinabalik ang pangalawang argumento kung tinutukoy ng paghahambing na pantay ang mga ito.
///
/// Panloob ay gumagamit ng isang alias sa [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Ibinabalik ang maximum ng dalawang mga halaga na may paggalang sa mga tinukoy na function na paghahambing.
///
/// Ibinabalik ang pangalawang argumento kung tinutukoy ng paghahambing na pantay ang mga ito.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Ibinabalik ang sangkap na nagbibigay ng maximum na halaga mula sa tinukoy na function.
///
/// Ibinabalik ang pangalawang argumento kung tinutukoy ng paghahambing na pantay ang mga ito.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Pagpapatupad ng PartialEq, Eq, PartialOrd at Ord para sa uri ng nauna
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Ang pagkakasunud-sunod dito ay mahalaga upang bumuo ng karagdagang optimal assembly.
                    // Tingnan ang <https://github.com/rust-lang/rust/issues/63758> para sa karagdagang impormasyon.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Casting sa i8 at nagko-convert ang mga pagkakaiba sa isang Pagkakasunud-sunod ay bumubuo ng mas pinakamainam assembly.
            //
            // Tingnan <https://github.com/rust-lang/rust/issues/66780> para sa karagdagang impormasyon.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // KALIGTASAN: bool bilang i8 nagbabalik 0 o 1, kaya ang pagkakaiba ay hindi maaaring maging anumang bagay
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // at mga payo

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}