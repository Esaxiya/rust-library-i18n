use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Habang ang pagpapaandar na ito ay ginagamit sa isang lugar at ang pagpapatupad nito ay maaaring na-inline, ang nakaraang mga pagtatangka na gawin ito ay naging mas mabagal ang rustc:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Layout ng isang bloke ng memorya.
///
/// Ang isang halimbawa ng `Layout` ay naglalarawan ng isang partikular na layout ng memorya.
/// Bumuo ka ng isang `Layout` up bilang isang input upang ibigay sa isang tagapaglaan.
///
/// Ang lahat ng mga layout ay may kaugnay na laki at isang pagkakahanay na dalawang-lakas.
///
/// (Tandaan na ang mga layout *hindi* kinakailangan na magkaroon ng non-zero na laki, kahit na `GlobalAlloc` ay nangangailangan na ang lahat ng mga kahilingan memory ay non-zero ang laki.
/// Ang isang tumatawag ay dapat na tiyakin na ang mga kundisyon tulad nito ay natutugunan, gumamit ng mga tukoy na tagapaglaan na may mga looser na kinakailangan, o gamitin ang mas mahinahon na interface ng `Allocator`.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // laki ng hiniling na bloke ng memorya, sinusukat sa mga byte.
    size_: usize,

    // pagkakahanay ng hiniling na bloke ng memorya, sinusukat sa mga byte.
    // tinitiyak namin na ito ay palaging isang power-of-two, dahil kinakailangan ng API na tulad ng `posix_memalign` at ito ay isang makatuwirang pagpilit na magpataw sa mga tagapagbuo ng Layout.
    //
    //
    // (Gayunpaman, hindi namin hinihingi ang analogically `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Bumubuo ng isang `Layout` mula sa isang naibigay na `size` at `align`, o ibabalik ang `LayoutError` kung ang alinman sa mga sumusunod na kundisyon ay hindi natutugunan:
    ///
    /// * `align` hindi dapat maging zero,
    ///
    /// * `align` dapat ay isang kapangyarihan ng dalawa,
    ///
    /// * `size`, kapag bilugan hanggang sa pinakamalapit na maramihang `align`, hindi dapat umapaw (ibig sabihin, ang bilugan na halaga ay dapat na mas mababa sa o katumbas ng `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (kapangyarihan-ng-dalawang nagpapahiwatig ng pagkakahanay!=0.)

        // Ang laki ng bilugan ay:
        //   size_rounds_up=(size + align, 1)&! (align, 1);
        //
        // Alam natin mula sa itaas na nakahanay!=0.
        // Kung ang pagdaragdag (ihanay, 1) ay hindi umaapaw, kung gayon ang pag-ikot ay magiging mabuti.
        //
        // Sa kabaligtaran,&-masking sa! (Ihanay, 1) ay ibabawas off lamang mababang-order-bits.
        // Kaya kung ang overflow ay nangyayari sa kabuuan, ang&-mask ay hindi maaaring ibawas nang sapat upang ma-undo ang overflow na iyon.
        //
        //
        // Sa itaas ay nagpapahiwatig na ang pagsuri para sa kabuuan overflow ay parehong kailangan at sapat na.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // KALIGTASAN: ang mga kundisyon para sa `from_size_align_unchecked` ay naging
        // naka-check sa itaas.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Lumilikha ng isang layout, bypassing lahat ng mga tseke.
    ///
    /// # Safety
    ///
    /// Ang pag-andar na ito ay hindi ligtas dahil hindi nito napatunayan ang mga precondition mula sa [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // KALIGTASAN: dapat tiyakin ng tumatawag na ang `align` ay mas malaki sa zero.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Ang minimum na laki sa mga byte para sa isang memory block ng layout na ito.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Ang minimum na pagkakahanay ng byte para sa isang memory block ng layout na ito.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Constructs isang `Layout` angkop para sa may hawak na isang halaga ng mga uri `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // KALIGTASAN: ang Ihanay ay garantisadong sa pamamagitan Rust na maging isang kapangyarihan ng dalawa at
        // ang laki + align combo ay garantisadong upang magkasya sa aming address space.
        // Bilang isang resulta gamitin ang hindi naka-check na tagapagbuo dito upang maiwasan ang pagpasok ng code na panics kung hindi ito na-optimize nang maayos.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Gumagawa ng layout na naglalarawan ng isang rekord na maaaring magamit upang maglaan ng istraktura ng pag-back para sa `T` (na maaaring isang trait o iba pang hindi pinagsama-samang uri tulad ng isang slice).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // KALIGTASAN: see rationale sa `new` kung bakit ito ay ang paggamit ng mga hindi ligtas na variant
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Gumagawa ng layout na naglalarawan ng isang rekord na maaaring magamit upang maglaan ng istraktura ng pag-back para sa `T` (na maaaring isang trait o iba pang hindi pinagsama-samang uri tulad ng isang slice).
    ///
    /// # Safety
    ///
    /// Ang pagpapaandar na ito ay ligtas lamang na tawagan kung ang mga sumusunod na kundisyon ay hawakan:
    ///
    /// - Kung ang `T` ay `Sized`, ang pagpapaandar na ito ay laging ligtas na tawagan.
    /// - Kung ang unsized tail ng `T` ay:
    ///     - isang [slice], pagkatapos ang haba ng hiwa ng hiwa ay dapat na isang intialized integer, at ang laki ng *buong halaga*(pabago-bagong haba ng buntot + statically laki ng unlapi) ay dapat magkasya sa `isize`.
    ///     - isang [trait object], pagkatapos ay ang vtable bahagi ng pointer ay dapat ituro sa isang wastong vtable para sa uri `T` nakuha sa pamamagitan ng isang unsizing coersion, at ang laki ng *buong halaga*(dynamic buntot haba + statically sized prefix) ay dapat na umakma sa `isize`.
    ///
    ///     - isang (unstable) [extern type], kung gayon ang pagpapaandar na ito ay laging ligtas na tawagan, ngunit maaaring ang panic o kung hindi man ay ibalik ang maling halaga, dahil hindi alam ang layout ng uri ng extern.
    ///     Ito ang parehong pag-uugali tulad ng [`Layout::for_value`] sa isang sanggunian sa isang buntot na uri ng panlabas.
    ///     - kung hindi man, pinapayagan itong tawagan ang pagpapaandar na ito.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // KALIGTASAN: ipinapasa namin ang mga paunang kinakailangan ng mga pagpapaandar na ito sa tumatawag
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // KALIGTASAN: see rationale sa `new` kung bakit ito ay ang paggamit ng mga hindi ligtas na variant
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Lumilikha ng isang `NonNull` na nakabitin, ngunit maayos na nakahanay para sa Layout na ito.
    ///
    /// Tandaan na ang halaga ng pointer ay maaaring potensyal na kumatawan sa isang wastong pointer, na nangangahulugang hindi ito dapat gamitin bilang isang "not yet initialized" halaga ng sentinel.
    /// Ang mga uri na tamad na naglalaan ay dapat subaybayan ang pagsisimula sa ilang iba pang mga paraan.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // KALIGTASAN: ang pag-align ay ginagarantiyahan na maging non-zero
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Lumilikha ng isang layout na naglalarawan sa rekord na maaaring humawak ang halaga ng parehong layout bilang `self`, ngunit na rin ay nakahanay sa alignment `align` (sinusukat sa bytes).
    ///
    ///
    /// Kung `self` na nakakatugon sa mga itinakdang pag-align, pagkatapos ay bumalik `self`.
    ///
    /// Tandaan na ang pamamaraang ito ay hindi nagdaragdag ng anumang padding sa pangkalahatang laki, hindi alintana kung ang ibinalik na layout ay may iba't ibang pagkakahanay.
    /// Sa madaling salita, kung ang `K` ay may sukat na 16, ang `K.align_to(32)` ay magkakaroon pa rin ng * sukat 16.
    ///
    /// Nagbabalik ng isang error kung ang kombinasyon ng `self.size()` at ang ibinigay na `align` ay lumalabag sa mga kundisyon na nakalista sa [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Ibinabalik ang dami ng padding na dapat nating ipasok pagkatapos ng `self` upang matiyak na ang sumusunod na address ay masisiyahan ang `align` (sinusukat sa mga byte).
    ///
    /// hal, kung ang `self.size()` ay 9, pagkatapos ang `self.padding_needed_for(4)` ay nagbabalik ng 3, sapagkat iyon ang minimum na bilang ng mga byte ng padding na kinakailangan upang makakuha ng isang 4 na nakahanay na address (ipinapalagay na ang kaukulang memorya ng bloke ay nagsisimula sa isang 4 na nakahanay na address).
    ///
    ///
    /// Ang halaga ng pagbabalik ng pagpapaandar na ito ay walang kahulugan kung ang `align` ay hindi isang kapangyarihan-ng-dalawa.
    ///
    /// Tandaan na ang utility ng naibalik na halaga ay nangangailangan ng `align` na mas mababa sa o katumbas ng pagkakahanay ng panimulang address para sa buong inilalaan na bloke ng memorya.Ang isang paraan upang masiyahan ang hadlang na ito ay upang matiyak ang `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Ang pinagsamang halaga ay:
        //   len_round_up=(len + align, 1)&! (align, 1);
        // at pagkatapos ay ibabalik namin ang pagkakaiba ng padding: `len_rounded_up - len`.
        //
        // Gumagamit kami ng modular arithmetic sa buong:
        //
        // 1. ang garantiya ay ginagarantiyahan na maging> 0, kaya ang pag-align, palaging may bisa ang 1.
        //
        // 2.
        // `len + align - 1` Maaari apaw sa pamamagitan ng hindi hihigit sa `align - 1`, kaya ang&-mask na may `!(align - 1)` ay tinitiyak na sa kaso ng overflow, `len_rounded_up` mismo ang magiging 0.
        //
        //    Kaya ibinalik padding, kapag idinagdag sa `len`, ay magbubunga ng 0, na kung saan trivially satisfies ang pagkakahanay `align`.
        //
        // (Siyempre, mga pagtatangka upang magtalaga ng mga bloke ng memorya na ang laki at padding overflow sa itaas paraan ay dapat maging sanhi ng allocator upang magbunga ng isang error pa rin.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Lumilikha ng isang layout sa pamamagitan ng pag-ikot ng laki ng layout na ito hanggang sa isang maramihang pagkakahanay ng layout.
    ///
    ///
    /// Ito ay katumbas ng pagdaragdag ng resulta ng `padding_needed_for` sa kasalukuyang laki ng layout.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Hindi ito maaaring mag-overflow.Pag-quote mula sa invariant ng Layout:
        // > `size`, kapag bilugan hanggang sa pinakamalapit na maramihang `align`,
        // > Dapat hindi overflow (ibig sabihin, ang mga bilugan halaga ay dapat na mas mababa sa
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Lumilikha ng isang layout na naglalarawan sa talaan para sa `n` na mga pagkakataon ng `self`, na may angkop na dami ng padding sa pagitan ng bawat isa upang matiyak na ang bawat halimbawa ay binibigyan ng hiniling na laki at pagkakahanay.
    /// Sa tagumpay, nagbalik `(k, offs)` kung saan `k` ay ang layout ng array at `offs` ay ang distansya sa pagitan ng simula ng bawat elemento sa array.
    ///
    /// Sa arithmetic overflow, ibinalik ang `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Hindi ito maaaring mag-overflow.Pag-quote mula sa invariant ng Layout:
        // > `size`, kapag bilugan hanggang sa pinakamalapit na maramihang `align`,
        // > Dapat hindi overflow (ibig sabihin, ang mga bilugan halaga ay dapat na mas mababa sa
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // KALIGTASAN: Ang self.align ay nalalaman na wasto at ang alloc_size ay naging
        // padded na.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Lumilikha ng isang layout na naglalarawan sa mga talaan para sa `self` sinusundan ng `next`, kabilang ang anumang mga kinakailangang padding upang matiyak na ang `next` ay maayos na nakahanay, ngunit *walang trailing padding*.
    ///
    /// Upang tumugma C representasyon layout `repr(C)`, dapat mong tawagan ang `pad_to_align` matapos ang pagpapalawak ng layout na may lahat ng mga patlang.
    /// (Walang paraan upang maitugma ang default na layout ng representasyon ng Rust `repr(Rust)`, as it is unspecified.)
    ///
    /// Tandaan na ang pagkakahanay ng nagresultang layout ay ang maximum ng mga `self` at `next`, upang matiyak ang pagkakahanay ng parehong mga bahagi.
    ///
    /// Ibinabalik `Ok((k, offset))`, kung saan `k` ay layout ng pinagdugtong-dugtong na record at `offset` ay ang kamag-anak na lokasyon, sa bytes, ng simula ng `next` naka-embed sa loob ng pinagdugtong-dugtong na rekord (ipagpalagay na sa rekord mismo ay nagsisimula sa offset 0).
    ///
    ///
    /// Sa arithmetic overflow, ibinalik ang `LayoutError`.
    ///
    /// # Examples
    ///
    /// Upang makalkula ang layout ng isang istrakturang `#[repr(C)]` at ang mga offset ng mga patlang mula sa mga layout ng mga patlang nito:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Alalahaning magtapos sa `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // subukan na ito ay gumagana
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Lumilikha ng isang layout na naglalarawan sa mga talaan para sa `n` pagkakataon ng `self`, na walang padding sa pagitan ng bawat halimbawa.
    ///
    /// Tandaan na, hindi katulad `repeat`, `repeat_packed` ay hindi ginagarantiya na ang paulit-ulit na mga pagkakataon ng `self` ay maayos na nakahanay, kahit na sa isang naibigay na halimbawa ng `self` ay maayos na hile-hilera.
    /// Sa madaling salita, kung ang layout na ibinalik ng `repeat_packed` ay ginagamit upang maglaan ng isang array, hindi garantisadong ang lahat ng mga elemento sa array ay maayos na nakahanay.
    ///
    /// Sa arithmetic overflow, ibinalik ang `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Lumilikha ng isang layout na naglalarawan sa mga talaan para sa `self` sinusundan ng `next` na walang karagdagang padding sa pagitan ng dalawa.
    /// Dahil walang padding na naipasok, ang pagkakahanay ng `next` ay walang kaugnayan, at hindi isinasama *sa lahat* sa nagresultang layout.
    ///
    ///
    /// Sa arithmetic overflow, ibinalik ang `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Lumilikha ng isang layout na naglalarawan sa mga talaan para sa isang `[T; n]`.
    ///
    /// Sa arithmetic overflow, ibinalik ang `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Ang mga parameter na ibinigay sa `Layout::from_size_align` o ilang iba pang `Layout` constructor huwag masiyahan ang kanyang dokumentado limitasyon.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (Kailangan namin ito para sa ibaba ng agos impl ng trait Error)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}