//! Mga API ng paglalaan ng memorya

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Ang error na `AllocError` ay nagpapahiwatig ng pagkabigo ng paglalaan na maaaring sanhi ng pagkapagod ng mapagkukunan o sa isang bagay na mali kapag pinagsasama ang ibinigay na mga argumento ng pag-input sa tagapaglaan na ito.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (Kailangan namin ito para sa ibaba ng agos impl ng trait Error)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Isang pagpapatupad ng `Allocator` maaaring magtalaga, paglaki, pag-urong, at deallocate arbitrary mga bloke ng data na inilarawan sa pamamagitan ng [`Layout`][].
///
/// `Allocator` ay idinisenyo upang maipatupad sa mga ZST, sanggunian, o matalinong mga payo dahil ang pagkakaroon ng isang tagapaglaan tulad ng `MyAlloc([u8; N])` ay hindi maaaring ilipat, nang hindi ina-update ang mga pahiwatig sa inilaang memorya.
///
/// Hindi tulad ng [`GlobalAlloc`][], pinapayagan ang X-X na paglalaan ng zero-laki.
/// Kung ang pinagbabatayan allocator ay hindi sumusuporta sa ito (tulad ng jemalloc) o bumalik sa isang null pointer (tulad ng `libc::malloc`), ito ay dapat na nahuli sa pamamagitan ng pagpapatupad.
///
/// ### Kasalukuyang inilalaan ang memorya
///
/// Ang ilan sa mga pamamaraan ay nangangailangan ng isang memory block na *kasalukuyang ilalaan* sa pamamagitan ng isang tagatalaga.Nangangahulugan ito na:
///
/// * ang panimulang address para sa memory block dati ibinalik ng [`allocate`], [`grow`], o [`shrink`], at
///
/// * ang bloke ng memorya ay hindi pa napagkakasabay na makipagpalitan, kung saan ang mga bloke ay alinman sa direktang nakipag-transaksyon sa pamamagitan ng naipasa sa [`deallocate`] o binago ng naipasa sa [`grow`] o [`shrink`] na nagbabalik ng `Ok`.
///
/// Kung ang `grow` o `shrink` ay nagbalik ng `Err`, ang naipasa na pointer ay mananatiling wasto.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Naaangkop sa memorya
///
/// Ang ilan sa mga pamamaraan ay nangangailangan ng isang layout *magkasya* isang memory block.
/// Ang ibig sabihin nito para sa isang layout sa "fit" isang memory block ay nangangahulugang (o magkapareho, para sa isang memory block sa "fit" isang layout) ay dapat na hawakan ng mga sumusunod na kundisyon:
///
/// * bloke ay dapat na inilalaan na may parehong pag-align ng [`layout.align()`], at
///
/// * Ang ibinigay na [`layout.size()`] ay dapat na mahulog sa saklaw na `min ..= max`, kung saan:
///   - `min` ay ang laki ng layout na pinakabagong ginamit upang maglaan ng bloke, at
///   - `max` ay ang pinakabagong aktwal na laki ibinalik mula [`allocate`], [`grow`], o [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Ang mga bloke ng memorya na bumalik mula sa isang tagapaglaan ay dapat magturo sa wastong memorya at panatilihin ang kanilang bisa hanggang sa ang halimbawa at lahat ng mga clone nito ay mahulog,
///
/// * ang pag-clone o paglipat ng tagapaglaan ay hindi dapat patunayan ang mga bloke ng memorya na ibinalik mula sa tagapaglaan na ito.Ang isang kopya allocator ay dapat kumilos na tulad ng parehong allocator, at
///
/// * ang anumang pointer sa isang memory block na kung saan ay [*currently allocated*] ay maaaring maipasa sa anumang iba pang pamamaraan ng tagapaglaan.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Pagtatangka upang maglaan ng isang bloke ng memorya.
    ///
    /// Sa tagumpay, ibabalik ang isang [`NonNull<[u8]>`][NonNull] na natutugunan ang laki at mga garantiya ng pagkakahanay ng `layout`.
    ///
    /// Ang naibalik na bloke ay maaaring magkaroon ng isang mas malaking sukat kaysa sa tinukoy ng `layout.size()`, at maaaring o hindi magkaroon ng nasimulan ang mga nilalaman nito.
    ///
    /// # Errors
    ///
    /// Bumabalik `Err` ay nagpapahiwatig na mag memory naubos o `layout` ay hindi nakamit laki o alignment hadlang ni allocator.
    ///
    /// Ang mga pagpapatupad ay hinihimok na ibalik ang `Err` sa pagkapagod ng memorya sa halip na panicking o pagpapalaglag, ngunit ito ay hindi isang mahigpit na kinakailangan.
    /// (Sa partikular: ito ay *legal* upang ipatupad ang trait nasa ibabaw ng isang nakapailalim na katutubong allocation library na aborts sa memorya pagkaubos.)
    ///
    /// Ang mga kliyente na nagnanais na i-abort ang pagkalkula bilang tugon sa isang error sa paglalaan ay hinihikayat na tawagan ang [`handle_alloc_error`] function, sa halip na direktang pag-uusap ng `panic!` o katulad.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Behaves tulad `allocate`, ngunit din nagsisiguro na ang ibinalik memory ay zero-initialize.
    ///
    /// # Errors
    ///
    /// Bumabalik `Err` ay nagpapahiwatig na mag memory naubos o `layout` ay hindi nakamit laki o alignment hadlang ni allocator.
    ///
    /// Ang mga pagpapatupad ay hinihimok na ibalik ang `Err` sa pagkapagod ng memorya sa halip na panicking o pagpapalaglag, ngunit ito ay hindi isang mahigpit na kinakailangan.
    /// (Sa partikular: ito ay *legal* upang ipatupad ang trait nasa ibabaw ng isang nakapailalim na katutubong allocation library na aborts sa memorya pagkaubos.)
    ///
    /// Ang mga kliyente na nagnanais na i-abort ang pagkalkula bilang tugon sa isang error sa paglalaan ay hinihikayat na tawagan ang [`handle_alloc_error`] function, sa halip na direktang pag-uusap ng `panic!` o katulad.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // KALIGTASAN: Nagbabalik ang `alloc` ng wastong memory block
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Deallocates ang memorya na isinangguni ng `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` dapat magpahiwatig ng isang bloke ng memorya [*currently allocated*] sa pamamagitan ng tagapaglaan na ito, at
    /// * `layout` dapat [*fit*] na block ng memorya.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Mga pagtatangka na pahabain ang memory block.
    ///
    /// Nagbabalik ng isang bagong [`NonNull<[u8]>`][NonNull] na naglalaman ng isang pointer at ang aktwal na laki ng inilaang memorya.Ang pointer ay angkop para sa paghawak ng data na inilarawan ng `new_layout`.
    /// Upang maisagawa ito, ang allocator ay maaaring pahabain ang allocation na isinangguni sa pamamagitan `ptr` upang magkasya sa bagong layout.
    ///
    /// Kung ibabalik nito ang `Ok`, kung gayon ang pagmamay-ari ng memory block na isinangguni ng `ptr` ay inilipat sa tagapaglaan na ito.
    /// Ang memorya ay maaaring o hindi maaaring napalaya, at dapat isaalang-alang na hindi magagamit maliban kung mailipat muli ito sa tumatawag sa pamamagitan ng halaga ng pagbabalik ng pamamaraang ito.
    ///
    /// Kung ang paraan na ito ay nagbabalik `Err`, at pagkatapos ay ang pagmamay-ari ng bloke ng memorya ay hindi pa nailipat sa allocator na ito, at ang mga nilalaman ng bloke ng memorya ay walang pagbabago.
    ///
    /// # Safety
    ///
    /// * `ptr` dapat magpahiwatig ng isang bloke ng memorya [*currently allocated*] sa pamamagitan ng tagapaglaan na ito.
    /// * `old_layout` dapat [*fit*] na bloke ng memorya (Ang `new_layout` argument hindi kailangang magkasya ito.).
    /// * `new_layout.size()` dapat mas malaki sa o katumbas ng `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Ibinabalik ang `Err` kung ang bagong layout ay hindi natutugunan ang laki at tagapagbigay ng pagkakahanay ng tagapaglaan ng tagapaglaan, o kung lumalaki kung hindi man ay nabigo.
    ///
    /// Ang mga pagpapatupad ay hinihimok na ibalik ang `Err` sa pagkapagod ng memorya sa halip na panicking o pagpapalaglag, ngunit ito ay hindi isang mahigpit na kinakailangan.
    /// (Sa partikular: ito ay *legal* upang ipatupad ang trait nasa ibabaw ng isang nakapailalim na katutubong allocation library na aborts sa memorya pagkaubos.)
    ///
    /// Ang mga kliyente na nagnanais na i-abort ang pagkalkula bilang tugon sa isang error sa paglalaan ay hinihikayat na tawagan ang [`handle_alloc_error`] function, sa halip na direktang pag-uusap ng `panic!` o katulad.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // KALIGTASAN: dahil `new_layout.size()` ay dapat mas malaki kaysa sa o katumbas
        // `old_layout.size()`, parehong luma at bagong memory allocation ay may-bisa para sa bumabasa at nagsusulat para sa `old_layout.size()` bytes.
        // Gayundin, dahil ang dating paglalaan ay hindi pa nakipag-deallocated, hindi nito maaaring mag-overlap ang `new_ptr`.
        // Kaya, ang tawag sa `copy_nonoverlapping` ay ligtas.
        // Ang kontrata sa kaligtasan para sa `dealloc` ay dapat na suportahan ng tumatawag.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Ang mga beta ay tulad ng `grow`, ngunit tinitiyak din na ang mga bagong nilalaman ay nakatakda sa zero bago ibalik.
    ///
    /// Maglalaman ang bloke ng memorya ng mga sumusunod na nilalaman pagkatapos ng matagumpay na tawag sa
    /// `grow_zeroed`:
    ///   * Ang Bytes `0..old_layout.size()` ay napanatili mula sa orihinal na paglalaan.
    ///   * Ang Bytes `old_layout.size()..old_size` ay mapapanatili o mai-zero, depende sa pagpapatupad ng tagapaglaan.
    ///   `old_size` ay tumutukoy sa sukat ng bloke ng memorya bago ang `grow_zeroed` call, na maaaring maging mas malaki kaysa sa laki na orihinal na hiniling kapag ito ay inilalaan.
    ///   * Bytes `old_size..new_size` ay zeroed.Ang `new_size` ay tumutukoy sa laki ng memory block na ibinalik ng tawag na `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` dapat magpahiwatig ng isang bloke ng memorya [*currently allocated*] sa pamamagitan ng tagapaglaan na ito.
    /// * `old_layout` dapat [*fit*] na bloke ng memorya (Ang `new_layout` argument hindi kailangang magkasya ito.).
    /// * `new_layout.size()` dapat mas malaki sa o katumbas ng `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Ibinabalik ang `Err` kung ang bagong layout ay hindi natutugunan ang laki at tagapagbigay ng pagkakahanay ng tagapaglaan ng tagapaglaan, o kung lumalaki kung hindi man ay nabigo.
    ///
    /// Ang mga pagpapatupad ay hinihimok na ibalik ang `Err` sa pagkapagod ng memorya sa halip na panicking o pagpapalaglag, ngunit ito ay hindi isang mahigpit na kinakailangan.
    /// (Sa partikular: ito ay *legal* upang ipatupad ang trait nasa ibabaw ng isang nakapailalim na katutubong allocation library na aborts sa memorya pagkaubos.)
    ///
    /// Ang mga kliyente na nagnanais na i-abort ang pagkalkula bilang tugon sa isang error sa paglalaan ay hinihikayat na tawagan ang [`handle_alloc_error`] function, sa halip na direktang pag-uusap ng `panic!` o katulad.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // KALIGTASAN: dahil `new_layout.size()` ay dapat mas malaki kaysa sa o katumbas
        // `old_layout.size()`, parehong luma at bagong memory allocation ay may-bisa para sa bumabasa at nagsusulat para sa `old_layout.size()` bytes.
        // Gayundin, dahil ang dating paglalaan ay hindi pa nakipag-deallocated, hindi nito maaaring mag-overlap ang `new_ptr`.
        // Kaya, ang tawag sa `copy_nonoverlapping` ay ligtas.
        // Ang kontrata sa kaligtasan para sa `dealloc` ay dapat na suportahan ng tumatawag.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Mga pagtatangkang bawasan ang memory block.
    ///
    /// Nagbabalik ng isang bagong [`NonNull<[u8]>`][NonNull] na naglalaman ng isang pointer at ang aktwal na laki ng inilaang memorya.Ang pointer ay angkop para sa paghawak ng data na inilarawan ng `new_layout`.
    /// Upang magawa ito, maaaring pag-urong ng tagapaglaan ang paglalaan na isinangguni ng `ptr` upang magkasya sa bagong layout.
    ///
    /// Kung ibabalik nito ang `Ok`, kung gayon ang pagmamay-ari ng memory block na isinangguni ng `ptr` ay inilipat sa tagapaglaan na ito.
    /// Ang memorya ay maaaring o hindi maaaring napalaya, at dapat isaalang-alang na hindi magagamit maliban kung mailipat muli ito sa tumatawag sa pamamagitan ng halaga ng pagbabalik ng pamamaraang ito.
    ///
    /// Kung ang paraan na ito ay nagbabalik `Err`, at pagkatapos ay ang pagmamay-ari ng bloke ng memorya ay hindi pa nailipat sa allocator na ito, at ang mga nilalaman ng bloke ng memorya ay walang pagbabago.
    ///
    /// # Safety
    ///
    /// * `ptr` dapat magpahiwatig ng isang bloke ng memorya [*currently allocated*] sa pamamagitan ng tagapaglaan na ito.
    /// * `old_layout` dapat [*fit*] na bloke ng memorya (Ang `new_layout` argument hindi kailangang magkasya ito.).
    /// * `new_layout.size()` dapat na mas maliit sa o katumbas ng `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Ibinabalik ang `Err` kung ang bagong layout ay hindi natutugunan ang laki at tagapagbigay ng pagkakahanay ng tagapagtalaga ng tagapaglaan, o kung ang pag-urong ay nabigo.
    ///
    /// Ang mga pagpapatupad ay hinihimok na ibalik ang `Err` sa pagkapagod ng memorya sa halip na panicking o pagpapalaglag, ngunit ito ay hindi isang mahigpit na kinakailangan.
    /// (Sa partikular: ito ay *legal* upang ipatupad ang trait nasa ibabaw ng isang nakapailalim na katutubong allocation library na aborts sa memorya pagkaubos.)
    ///
    /// Ang mga kliyente na nagnanais na i-abort ang pagkalkula bilang tugon sa isang error sa paglalaan ay hinihikayat na tawagan ang [`handle_alloc_error`] function, sa halip na direktang pag-uusap ng `panic!` o katulad.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // KALIGTASAN: dahil ang `new_layout.size()` ay dapat na mas mababa sa o katumbas ng
        // `old_layout.size()`, parehong luma at bagong memory allocation ay may-bisa para sa bumabasa at nagsusulat para sa `new_layout.size()` bytes.
        // Gayundin, dahil ang dating paglalaan ay hindi pa nakipag-deallocated, hindi nito maaaring mag-overlap ang `new_ptr`.
        // Kaya, ang tawag sa `copy_nonoverlapping` ay ligtas.
        // Ang kontrata sa kaligtasan para sa `dealloc` ay dapat na suportahan ng tumatawag.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Lumilikha ng isang "by reference" adapter para sa halimbawang ito ng `Allocator`.
    ///
    /// Ang naibalik na adapter ay nagpapatupad din ng `Allocator` at hihiramin lamang ito.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // KALIGTASAN: ang kontrata sa kaligtasan ay dapat na panatilihin ng tumatawag
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KALIGTASAN: ang kontrata sa kaligtasan ay dapat na panatilihin ng tumatawag
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KALIGTASAN: ang kontrata sa kaligtasan ay dapat na panatilihin ng tumatawag
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KALIGTASAN: ang kontrata sa kaligtasan ay dapat na panatilihin ng tumatawag
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}