// ignore-tidy-filelength

//! Slice pamamahala at pagmamanipula.
//!
//! Para sa karagdagang detalye tingnan ang [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Ang purong rust memchr na pagpapatupad, kinuha mula sa rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Ang pagpapaandar na ito ay pampubliko lamang dahil walang ibang paraan upang i-test ang heapsort.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Ibinabalik ang bilang ng mga elemento sa hiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // KALIGTASAN: tunog ng const sapagkat inilalabas namin ang haba ng haba bilang isang usize (kung saan ito dapat)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // KALIGTASAN: ligtas ito dahil ang `&[T]` at `FatPtr<T>` ay may parehong layout.
            // Ang `std` lamang ang makakagawa ng garantiyang ito.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Palitan ng `crate::ptr::metadata(self)` kapag iyon ay matatag.
            // Tulad ng pagsulat na ito ay nagdudulot ito ng "Const-stable functions can only call other const-stable functions" error.
            //

            // KALIGTASAN: Ang pag-access sa halaga mula sa unyon ng `PtrRepr` ay ligtas mula noong * const T
            // at PtrComponents<T>ay may parehong layout memorya.
            // Ang std lamang ang makakagawa ng garantiyang ito.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Ibinabalik ang `true` kung ang slice ay may haba na 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Ibinabalik ang unang elemento ng hiwa, o `None` kung ito ay walang laman.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Nagbabalik ng isang nababagabag na pointer sa unang elemento ng hiwa, o `None` kung ito ay walang laman.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Ibinabalik ang una at lahat ng natitirang mga elemento ng hiwa, o `None` kung ito ay walang laman.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Ibinabalik ang una at lahat ng natitirang mga elemento ng hiwa, o `None` kung ito ay walang laman.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Ibinabalik ang huli at lahat ng natitirang mga elemento ng hiwa, o `None` kung ito ay walang laman.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Ibinabalik ang huli at lahat ng natitirang mga elemento ng hiwa, o `None` kung ito ay walang laman.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Ibinabalik ang huling elemento ng hiwa, o `None` kung ito ay walang laman.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Ibinabalik ang isang nababagabag na pointer sa huling item sa hiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Nagbabalik ng isang sanggunian sa isang elemento o subslice depende sa uri ng index.
    ///
    /// - Kung bibigyan ng posisyon, ibabalik ang isang sanggunian sa elemento sa posisyon na iyon o `None` kung wala sa mga hangganan.
    ///
    /// - Kung binigyan ng isang saklaw, ibabalik ang subslice na naaayon sa saklaw na iyon, o `None` kung wala sa mga hangganan.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Ibinabalik maaaring mabago ng isang reference sa isang elemento o subslice depende sa uri ng index (tingnan [`get`]) o `None` kung ang index ay lumampas sa hangganan.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Nagbabalik ng isang sanggunian sa isang elemento o subslice, nang hindi nagsasagawa ng mga hangganan sa pag-check.
    ///
    /// Para sa isang ligtas na kahalili tingnan ang [`get`].
    ///
    /// # Safety
    ///
    /// Ang pagtawag sa pamamaraang ito na may isang out-of-bounds index ay *[hindi natukoy na pag-uugali]* kahit na ang nagresultang sanggunian ay hindi ginamit.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // KALIGTASAN: ang tumatawag ay dapat panindigan ang karamihan sa mga kinakailangan sa kaligtasan para sa `get_unchecked`;
        // ang hiwa ay hindi maaalis dahil ang `self` ay isang ligtas na sanggunian.
        // Ang naibalik na pointer ay ligtas dahil ang mga impls ng `SliceIndex` ay kailangang garantiya na ito ay.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Nagbabalik ng isang nababagong sanggunian sa isang elemento o subslice, nang hindi nagsasagawa ng mga hangganan sa pag-check.
    ///
    /// Para sa isang ligtas na kahalili tingnan ang [`get_mut`].
    ///
    /// # Safety
    ///
    /// Ang pagtawag sa pamamaraang ito na may isang out-of-bounds index ay *[hindi natukoy na pag-uugali]* kahit na ang nagresultang sanggunian ay hindi ginamit.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // KALIGTASAN: dapat tumaguyod ang tumatawag sa mga kinakailangan sa kaligtasan para sa `get_unchecked_mut`;
        // ang hiwa ay hindi maaalis dahil ang `self` ay isang ligtas na sanggunian.
        // Ang naibalik na pointer ay ligtas dahil ang mga impls ng `SliceIndex` ay kailangang garantiya na ito ay.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Nagbabalik ng isang hilaw na pointer sa buffer ng hiwa.
    ///
    /// Dapat tiyakin ng tumatawag na ang slice ay nabubuhay sa pointer na ibabalik ng pagpapaandar na ito, o kung hindi man ay magtatapos ito sa pagturo sa basura.
    ///
    /// Dapat ding tiyakin ng tumatawag na ang memorya na itinuro ng pointer (non-transitively) ay hindi kailanman nakasulat (maliban sa loob ng isang `UnsafeCell`) gamit ang pointer na ito o anumang pointer na nagmula rito.
    /// Kung kailangan mong i-mutate ang mga nilalaman ng hiwa, gamitin ang [`as_mut_ptr`].
    ///
    /// Ang pagbabago ng lalagyan na isinangguni ng hiwa na ito ay maaaring maging sanhi ng muling paglalaan ng buffer nito, na gagawing hindi wasto ang anumang mga pahiwatig dito.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Ibinabalik ang isang hindi ligtas na nababagabag na pointer sa buffer ng slice.
    ///
    /// Dapat tiyakin ng tumatawag na ang slice ay nabubuhay sa pointer na ibabalik ng pagpapaandar na ito, o kung hindi man ay magtatapos ito sa pagturo sa basura.
    ///
    /// Ang pagbabago ng lalagyan na isinangguni ng hiwa na ito ay maaaring maging sanhi ng muling paglalaan ng buffer nito, na gagawing hindi wasto ang anumang mga pahiwatig dito.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Ibinabalik ang dalawang hilaw na pahiwatig na sumasaklaw sa hiwa.
    ///
    /// Ang naibalik na saklaw ay kalahating bukas, na nangangahulugang ang mga puntos ng pagtatapos ng pointer *isang nakaraan* ang huling elemento ng hiwa.
    /// Sa ganitong paraan, ang isang walang laman na hiwa ay kinakatawan ng dalawang pantay na mga payo, at ang pagkakaiba sa pagitan ng dalawang mga payo ay kumakatawan sa laki ng hiwa.
    ///
    /// Tingnan ang [`as_ptr`] para sa mga babala sa paggamit ng mga pahiwatig na ito.Ang end pointer ay nangangailangan ng labis na pag-iingat, dahil hindi ito tumuturo sa isang wastong elemento sa hiwa.
    ///
    /// Ang pagpapaandar na ito ay kapaki-pakinabang para sa pakikipag-ugnay sa mga banyagang interface na gumagamit ng dalawang mga payo upang sumangguni sa isang hanay ng mga elemento sa memorya, tulad ng karaniwan sa C++ .
    ///
    ///
    /// Maaari ding maging kapaki-pakinabang upang suriin kung ang isang pointer sa isang elemento ay tumutukoy sa isang elemento ng hiwa na ito:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // KALIGTASAN: Ang `add` dito ay ligtas, sapagkat:
        //
        //   - Ang parehong mga payo ay bahagi ng parehong bagay, tulad ng pagturo nang direkta nakaraan ang bagay ay binibilang din.
        //
        //   - Ang laki ng hiwa ay hindi kailanman mas malaki kaysa sa isize::MAX bytes, tulad ng nabanggit dito:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Walang pambalot sa paligid na kasangkot, dahil ang mga hiwa ay hindi balot ng pagtatapos ng puwang ng address.
        //
        // Tingnan ang dokumentasyon ng pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Ibinabalik ang dalawang hindi ligtas na nababagabag na mga payo na sumasaklaw sa hiwa.
    ///
    /// Ang naibalik na saklaw ay kalahating bukas, na nangangahulugang ang mga puntos ng pagtatapos ng pointer *isang nakaraan* ang huling elemento ng hiwa.
    /// Sa ganitong paraan, ang isang walang laman na hiwa ay kinakatawan ng dalawang pantay na mga payo, at ang pagkakaiba sa pagitan ng dalawang mga payo ay kumakatawan sa laki ng hiwa.
    ///
    /// Tingnan ang [`as_mut_ptr`] para sa mga babala sa paggamit ng mga pahiwatig na ito.
    /// Ang end pointer ay nangangailangan ng labis na pag-iingat, dahil hindi ito tumuturo sa isang wastong elemento sa hiwa.
    ///
    /// Ang pagpapaandar na ito ay kapaki-pakinabang para sa pakikipag-ugnay sa mga banyagang interface na gumagamit ng dalawang mga payo upang sumangguni sa isang hanay ng mga elemento sa memorya, tulad ng karaniwan sa C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // KALIGTASAN: Tingnan ang as_ptr_range() sa itaas kung bakit ligtas ang `add` dito.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Ipagpalit ang dalawang elemento sa hiwa.
    ///
    /// # Arguments
    ///
    /// * a, Ang index ng unang elemento
    /// * b, Ang index ng pangalawang elemento
    ///
    /// # Panics
    ///
    /// Ang Panics kung ang `a` o `b` ay wala sa mga hangganan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Hindi makakuha ng dalawang nababagabag na pautang mula sa isang vector, kaya sa halip ay gumamit ng mga hilaw na payo.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // KALIGTASAN: Ang `pa` at `pb` ay nilikha mula sa ligtas na nababagong sanggunian at sanggunian
        // sa mga elemento sa hiwa at samakatuwid ay garantisadong maging wasto at nakahanay.
        // Tandaan na ang pag-access sa mga elemento sa likod ng `a` at `b` ay naka-check at panic kapag wala sa mga hangganan.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Baliktad sa pagkakasunud-sunod ng mga elemento sa hiwa, sa lugar.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Para sa napakaliit na uri, ang lahat ng indibidwal ay nagbabasa sa normal na landas na hindi gumanap.
        // Maaari kaming gumawa ng mas mahusay, na binigyan ng mahusay na hindi nakaayos na load/store, sa pamamagitan ng paglo-load ng isang mas malaking tipak at pag-reverse ng isang rehistro.
        //

        // May perpektong gagawin ito ng LLVM para sa amin, dahil mas alam nito kaysa sa ginagawa natin kung ang hindi nakahanay na pagbabasa ay mahusay (dahil ang mga pagbabago sa pagitan ng iba't ibang mga bersyon ng ARM, halimbawa) at kung ano ang pinakamahusay na laki ng tipak.
        // Sa kasamaang palad, tulad ng sa LLVM 4.0 (2017-05) inilalabas lamang nito ang loop, kaya kailangan nating gawin ito sa ating sarili.
        // (Hypothesis: nakakabago ay nakakaabala dahil ang mga panig ay maaaring nakahanay nang magkakaiba-magiging, kapag ang haba ay kakaiba-kaya't walang paraan ng paglabas ng pre-at postludes upang magamit ang ganap na nakahanay na SIMD sa gitna.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Gamitin ang llvm.bswap intrinsic upang i-reverse ang u8s sa isang usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // KALIGTASAN: Mayroong maraming mga bagay upang suriin dito:
                //
                // - Tandaan na ang `chunk` ay alinman sa 4 o 8 dahil sa pag-check sa itaas sa itaas.Kaya't ang `chunk - 1` ay positibo.
                // - Ang pag-index na may index `i` ay pagmultahin habang ginagarantiyahan ang loop check
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Ang pag-index na may index `ln - i - chunk = ln - (i + chunk)` ay mabuti:
                //   - `i + chunk > 0` ay walang katotohanan totoo.
                //   - Ginagarantiyahan ng loop check ang:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, sa gayon ang pagbabawas ay hindi underflow.
                // - Ang mga tawag na `read_unaligned` at `write_unaligned` ay mabuti:
                //   - `pa` tumuturo sa index `i` kung saan ang `i < ln / 2 - (chunk - 1)` (tingnan sa itaas) at `pb` ay tumuturo sa index `ln - i - chunk`, kaya pareho ang hindi bababa sa `chunk` maraming mga byte na malayo sa dulo ng `self`.
                //
                //   - Anumang inisyal na memorya ay may bisa `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Gumamit ng paikutin-by-16 upang baligtarin ang mga u16 sa isang u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // KALIGTASAN: Ang isang unaligned u32 maaaring basahin mula `i` kung `i + 1 < ln`
                // (at malinaw naman na `i < ln`), dahil ang bawat elemento ay 2 bytes at binabasa namin ang 4.
                //
                // `i + chunk - 1 < ln / 2` # habang kondisyon
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Dahil mas mababa ito sa haba na hinati ng 2, pagkatapos dapat itong nasa mga hangganan.
                //
                // Nangangahulugan din ito na ang kondisyong `0 < i + chunk <= ln` ay laging iginagalang, tinitiyak na ang `pb` pointer ay maaaring magamit nang ligtas.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // KALIGTASAN: `i` ay mababa sa kalahati ng haba ng slice kaya
            // ang pag-access sa `i` at `ln - i - 1` ay ligtas (ang `i` ay nagsisimula sa 0 at hindi lalayo sa `ln / 2 - 1`).
            // Ang mga nagresultang pahiwatig na `pa` at `pb` samakatuwid ay wasto at nakahanay, at maaaring mabasa mula at isulat sa.
            //
            //
            unsafe {
                // Hindi ligtas na swap upang maiwasan ang hangganan check in safe swap.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Nagbabalik ng isang umulit sa hiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Ay nagbabalik ng isang iterator na nagbibigay-daan sa pagbabago ng bawat halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Ay nagbabalik ng isang iterator sa lahat magkadikit windows haba `size`.
    /// Ang windows ay nagsasapawan.
    /// Kung ang hiwa ay mas maikli kaysa sa `size`, ang iterator ay hindi nagbabalik ng mga halaga.
    ///
    /// # Panics
    ///
    /// Panics kung ang `size` ay 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Kung ang hiwa ay mas maikli kaysa sa `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Nagbabalik ng isang umuulit sa paglipas ng mga elemento ng `chunk_size` ng hiwa nang paisa-isa, simula sa simula ng hiwa.
    ///
    /// Ang mga tipak ay hiwa at hindi nag-o-overlap.Kung ang `chunk_size` ay hindi hinati ang haba ng hiwa, kung gayon ang huling piraso ay hindi magkakaroon ng haba na `chunk_size`.
    ///
    /// Tingnan ang [`chunks_exact`] para sa isang variant ng iterator na ito na nagbabalik ng mga chunks na laging eksaktong `chunk_size` na mga elemento, at [`rchunks`] para sa parehong iterator ngunit nagsisimula sa dulo ng hiwa.
    ///
    ///
    /// # Panics
    ///
    /// Panics kung ang `chunk_size` ay 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Nagbabalik ng isang umuulit sa paglipas ng mga elemento ng `chunk_size` ng hiwa nang paisa-isa, simula sa simula ng hiwa.
    ///
    /// Ang mga chunks ay maaaring i-mutable hiwa, at huwag mag-overlap.Kung ang `chunk_size` ay hindi hinati ang haba ng hiwa, kung gayon ang huling piraso ay walang haba na `chunk_size`.
    ///
    /// Tingnan ang [`chunks_exact_mut`] para sa isang variant ng iterator na ito na nagbabalik ng mga chunks na laging eksaktong `chunk_size` na mga elemento, at [`rchunks_mut`] para sa parehong iterator ngunit nagsisimula sa dulo ng hiwa.
    ///
    ///
    /// # Panics
    ///
    /// Panics kung ang `chunk_size` ay 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Nagbabalik ng isang umuulit sa paglipas ng mga elemento ng `chunk_size` ng hiwa nang paisa-isa, simula sa simula ng hiwa.
    ///
    /// Ang mga tipak ay hiwa at hindi nag-o-overlap.
    /// Kung `chunk_size` ay hindi hatiin ang haba ng slice, at pagkatapos ay sa huling hanggang sa `chunk_size-1` elemento ay tinanggal na at maaaring makuha mula sa `remainder` pag-andar ng iterator.
    ///
    ///
    /// Dahil sa bawat tipak na may eksaktong mga elemento ng `chunk_size`, madalas na ma-optimize ng tagatala ang nagresultang code nang mas mahusay kaysa sa kaso ng [`chunks`].
    ///
    /// Tingnan ang [`chunks`] para sa isang variant ng iterator na ito na ibabalik din ang natitira bilang isang mas maliit na tipak, at [`rchunks_exact`] para sa parehong iterator ngunit nagsisimula sa dulo ng hiwa.
    ///
    /// # Panics
    ///
    /// Panics kung ang `chunk_size` ay 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Nagbabalik ng isang umuulit sa paglipas ng mga elemento ng `chunk_size` ng hiwa nang paisa-isa, simula sa simula ng hiwa.
    ///
    /// Ang mga chunks ay maaaring i-mutable hiwa, at huwag mag-overlap.
    /// Kung ang `chunk_size` ay hindi hinati ang haba ng hiwa, pagkatapos ang huling hanggang sa mga elemento ng `chunk_size-1` ay aalisin at maaaring makuha mula sa pagpapaandar ng `into_remainder` ng iterator.
    ///
    ///
    /// Dahil sa bawat tipak na may eksaktong mga elemento ng `chunk_size`, madalas na ma-optimize ng tagatala ang nagresultang code nang mas mahusay kaysa sa kaso ng [`chunks_mut`].
    ///
    /// Tingnan [`chunks_mut`] para sa isang variant ng ito iterator na din nagbabalik ang mga natitira bilang isang mas maliit na tipak, at [`rchunks_exact_mut`] para sa parehong iterator ngunit simula sa dulo ng slice.
    ///
    /// # Panics
    ///
    /// Panics kung ang `chunk_size` ay 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Hinahati ang hiwa sa isang slice ng mga 'N`-element arrays, sa pag-aakalang walang natitira.
    ///
    ///
    /// # Safety
    ///
    /// Maaari lamang itong tawagan kung kailan
    /// - Ang hiwa ay nahahati nang eksakto sa mga "N`-element chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // KALIGTASAN: 1-element chunks ay walang natitira
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // KALIGTASAN: Ang slice haba (6) ay isang maramihang ng 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Hindi magiging unsound ang mga ito:
    /// // hayaan ang mga chunks: &[[_;5]]= slice.as_chunks_unchecked()//Ang slice haba ay hindi isang multiple ng 5 let chunks:&[[_;0]]= slice.as_chunks_unchecked()//Zero-length chunks ay hindi kailanman pinapayagan
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // KALIGTASAN: Ang aming precondition ay eksakto kung ano ang kinakailangan upang tumawag ito
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // KALIGTASAN: cast kami ng isang slice ng `new_len * N` elemento sa
        // isang slice ng `new_len` maraming mga `N` elemento na chunks.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Hinahati ang hiwa sa isang slice ng mga 'N`-element arrays, simula sa simula ng hiwa, at isang natitirang hiwa na may haba na mahigpit na mas mababa sa `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics kung `N` ay 0. check na ito ay pinaka-malamang na makakuha ng nagbago sa isang oras itala error bago ang pamamaraan na ito ay makakakuha ng nagpapatatag.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // KALIGTASAN: Nag-panic na kami para sa zero, at tiniyak ng konstruksyon
        // na ang haba ng subslice ay isang maramihang ng N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Hinahati ang hiwa sa isang slice ng mga 'N`-element arrays, na nagsisimula sa dulo ng hiwa, at isang natitirang hiwa na may haba na mahigpit na mas mababa sa `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics kung `N` ay 0. check na ito ay pinaka-malamang na makakuha ng nagbago sa isang oras itala error bago ang pamamaraan na ito ay makakakuha ng nagpapatatag.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // KALIGTASAN: Nag-panic na kami para sa zero, at tiniyak ng konstruksyon
        // na ang haba ng subslice ay isang maramihang ng N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Nagbabalik ng isang umuulit sa paglipas ng mga elemento ng `N` ng hiwa nang paisa-isa, simula sa simula ng hiwa.
    ///
    /// Ang mga tipak ay mga sanggunian sa array at hindi nagsasapawan.
    /// Kung ang `N` ay hindi hinati ang haba ng hiwa, pagkatapos ang huling hanggang sa mga elemento ng `N-1` ay aalisin at maaaring makuha mula sa pagpapaandar ng `remainder` ng iterator.
    ///
    ///
    /// Ang pamamaraang ito ay ang katumbas na generic na katumbas ng [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics kung `N` ay 0. check na ito ay pinaka-malamang na makakuha ng nagbago sa isang oras itala error bago ang pamamaraan na ito ay makakakuha ng nagpapatatag.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Hinahati ang hiwa sa isang slice ng mga 'N`-element arrays, sa pag-aakalang walang natitira.
    ///
    ///
    /// # Safety
    ///
    /// Maaari lamang itong tawagan kung kailan
    /// - Ang hiwa ay nahahati nang eksakto sa mga "N`-element chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // KALIGTASAN: 1-element chunks ay walang natitira
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // KALIGTASAN: Ang slice haba (6) ay isang maramihang ng 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Hindi magiging unsound ang mga ito:
    /// // hayaan ang mga chunks: &[[_;5]]= slice.as_chunks_unchecked_mut()//Ang slice haba ay hindi isang multiple ng 5 let chunks:&[[_;0]]= slice.as_chunks_unchecked_mut()//Zero-length chunks ay hindi pinapayagan
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // KALIGTASAN: Ang aming precondition ay eksakto kung ano ang kinakailangan upang tumawag ito
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // KALIGTASAN: cast kami ng isang slice ng `new_len * N` elemento sa
        // isang slice ng `new_len` maraming mga `N` elemento na chunks.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Hinahati ang hiwa sa isang slice ng mga 'N`-element arrays, simula sa simula ng hiwa, at isang natitirang hiwa na may haba na mahigpit na mas mababa sa `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics kung `N` ay 0. check na ito ay pinaka-malamang na makakuha ng nagbago sa isang oras itala error bago ang pamamaraan na ito ay makakakuha ng nagpapatatag.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // KALIGTASAN: Nag-panic na kami para sa zero, at tiniyak ng konstruksyon
        // na ang haba ng subslice ay isang maramihang ng N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Hinahati ang hiwa sa isang slice ng mga 'N`-element arrays, na nagsisimula sa dulo ng hiwa, at isang natitirang hiwa na may haba na mahigpit na mas mababa sa `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics kung `N` ay 0. check na ito ay pinaka-malamang na makakuha ng nagbago sa isang oras itala error bago ang pamamaraan na ito ay makakakuha ng nagpapatatag.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // KALIGTASAN: Nag-panic na kami para sa zero, at tiniyak ng konstruksyon
        // na ang haba ng subslice ay isang maramihang ng N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Nagbabalik ng isang umuulit sa paglipas ng mga elemento ng `N` ng hiwa nang paisa-isa, simula sa simula ng hiwa.
    ///
    /// Ang mga tipak ay nababagabag na mga sanggunian sa array at hindi nagsasapawan.
    /// Kung ang `N` ay hindi hinati ang haba ng hiwa, pagkatapos ang huling hanggang sa mga elemento ng `N-1` ay aalisin at maaaring makuha mula sa pagpapaandar ng `into_remainder` ng iterator.
    ///
    ///
    /// Ang pamamaraang ito ay ang katumbas na generic na katumbas ng [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics kung `N` ay 0. check na ito ay pinaka-malamang na makakuha ng nagbago sa isang oras itala error bago ang pamamaraan na ito ay makakakuha ng nagpapatatag.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Nagbabalik ng isang iterator sa paglipas ng overlap na windows ng `N` na mga elemento ng isang slice, simula sa simula ng hiwa.
    ///
    ///
    /// Ito ang katumbas na generic ng [`windows`].
    ///
    /// Kung `N` ay mas malaki kaysa sa laki ng slice, ito ay babalik walang windows.
    ///
    /// # Panics
    ///
    /// Panics kung ang `N` ay 0.
    /// Ang tseke na ito ay malamang na mabago sa isang error sa pag-ipon ng oras bago maging matatag ang pamamaraang ito.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Nagbabalik ng isang umuulit sa paglipas ng mga elemento ng `chunk_size` ng hiwa nang paisa-isa, simula sa dulo ng hiwa.
    ///
    /// Ang mga tipak ay hiwa at hindi nag-o-overlap.Kung ang `chunk_size` ay hindi hinati ang haba ng hiwa, kung gayon ang huling piraso ay hindi magkakaroon ng haba na `chunk_size`.
    ///
    /// Tingnan ang [`rchunks_exact`] para sa isang variant ng iterator na ito na nagbabalik ng mga chunks na laging eksaktong `chunk_size` na mga elemento, at [`chunks`] para sa parehong iterator ngunit nagsisimula sa simula ng hiwa.
    ///
    ///
    /// # Panics
    ///
    /// Panics kung ang `chunk_size` ay 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Nagbabalik ng isang umuulit sa paglipas ng mga elemento ng `chunk_size` ng hiwa nang paisa-isa, simula sa dulo ng hiwa.
    ///
    /// Ang mga chunks ay maaaring i-mutable hiwa, at huwag mag-overlap.Kung ang `chunk_size` ay hindi hinati ang haba ng hiwa, kung gayon ang huling piraso ay walang haba na `chunk_size`.
    ///
    /// Tingnan ang [`rchunks_exact_mut`] para sa isang variant ng iterator na ito na nagbabalik ng mga chunks na laging eksaktong `chunk_size` na mga elemento, at [`chunks_mut`] para sa parehong iterator ngunit nagsisimula sa simula ng hiwa.
    ///
    ///
    /// # Panics
    ///
    /// Panics kung ang `chunk_size` ay 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Nagbabalik ng isang umuulit sa paglipas ng mga elemento ng `chunk_size` ng hiwa nang paisa-isa, simula sa dulo ng hiwa.
    ///
    /// Ang mga tipak ay hiwa at hindi nag-o-overlap.
    /// Kung `chunk_size` ay hindi hatiin ang haba ng slice, at pagkatapos ay sa huling hanggang sa `chunk_size-1` elemento ay tinanggal na at maaaring makuha mula sa `remainder` pag-andar ng iterator.
    ///
    /// Dahil sa bawat tipak na may eksaktong mga elemento ng `chunk_size`, madalas na ma-optimize ng tagatala ang nagresultang code nang mas mahusay kaysa sa kaso ng [`chunks`].
    ///
    /// Tingnan [`rchunks`] para sa isang variant ng iterator na ito na nagbabalik din ang mga natitira bilang isang mas maliit na tipak, at [`chunks_exact`] para sa parehong iterator ngunit simula sa simula ng slice.
    ///
    ///
    /// # Panics
    ///
    /// Panics kung ang `chunk_size` ay 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Nagbabalik ng isang umuulit sa paglipas ng mga elemento ng `chunk_size` ng hiwa nang paisa-isa, simula sa dulo ng hiwa.
    ///
    /// Ang mga chunks ay maaaring i-mutable hiwa, at huwag mag-overlap.
    /// Kung ang `chunk_size` ay hindi hinati ang haba ng hiwa, pagkatapos ang huling hanggang sa mga elemento ng `chunk_size-1` ay aalisin at maaaring makuha mula sa pagpapaandar ng `into_remainder` ng iterator.
    ///
    /// Dahil sa bawat tipak na may eksaktong mga elemento ng `chunk_size`, madalas na ma-optimize ng tagatala ang nagresultang code nang mas mahusay kaysa sa kaso ng [`chunks_mut`].
    ///
    /// Tingnan ang [`rchunks_mut`] para sa isang variant ng iterator na ito na ibabalik din ang natitira bilang isang mas maliit na tipak, at [`chunks_exact_mut`] para sa parehong iterator ngunit nagsisimula sa simula ng hiwa.
    ///
    ///
    /// # Panics
    ///
    /// Panics kung ang `chunk_size` ay 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Nagbabalik ng isang iterator sa hiwa na gumagawa ng mga di-overlap na mga pagpapatakbo ng mga elemento gamit ang panaguri upang paghiwalayin ang mga ito.
    ///
    /// Ang panaguri ay tinawag sa dalawang elemento na sumusunod sa kanilang sarili, nangangahulugan ito na ang panaguri ay tinatawag sa `slice[0]` at `slice[1]` pagkatapos ay sa `slice[1]` at `slice[2]` at iba pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ang pamamaraan na ito ay maaaring gamitin upang i-extract ang pinagsunod-sunod subslices:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Nagbabalik ng isang umuulit sa hiwa na gumagawa ng di-magkakapatong na nababagong mga elemento ng paggamit ng panaguri upang paghiwalayin ang mga ito.
    ///
    /// Ang panaguri ay tinawag sa dalawang elemento na sumusunod sa kanilang sarili, nangangahulugan ito na ang panaguri ay tinatawag sa `slice[0]` at `slice[1]` pagkatapos ay sa `slice[1]` at `slice[2]` at iba pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ang pamamaraan na ito ay maaaring gamitin upang i-extract ang pinagsunod-sunod subslices:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Hinahati ang isang hiwa sa dalawa sa isang index.
    ///
    /// Ang unang ay maglalaman ng lahat ng mga indeks mula `[0, mid)` (hindi kasama ang index `mid` mismo) at ang pangalawa ay maglalaman ng lahat ng mga indeks mula `[mid, len)` (hindi kasama ang index `len` mismo).
    ///
    ///
    /// # Panics
    ///
    /// Panics kung `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // KALIGTASAN: Ang `[ptr; mid]` at `[mid; len]` ay nasa loob ng `self`, kung saan
        // natutupad ang mga kinakailangan ng `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Naghahati sa isa mutable slice sa dalawang sa isang index.
    ///
    /// Ang unang ay maglalaman ng lahat ng mga indeks mula `[0, mid)` (hindi kasama ang index `mid` mismo) at ang pangalawa ay maglalaman ng lahat ng mga indeks mula `[mid, len)` (hindi kasama ang index `len` mismo).
    ///
    ///
    /// # Panics
    ///
    /// Panics kung `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // KALIGTASAN: Ang `[ptr; mid]` at `[mid; len]` ay nasa loob ng `self`, kung saan
        // natutupad ang mga kinakailangan ng `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Hinahati ang isang hiwa sa dalawa sa isang index, nang hindi nagsasagawa ng mga hangganan na pag-check.
    ///
    /// Ang unang ay maglalaman ng lahat ng mga indeks mula `[0, mid)` (hindi kasama ang index `mid` mismo) at ang pangalawa ay maglalaman ng lahat ng mga indeks mula `[mid, len)` (hindi kasama ang index `len` mismo).
    ///
    ///
    /// Para sa isang ligtas na kahalili tingnan ang [`split_at`].
    ///
    /// # Safety
    ///
    /// Ang pagtawag sa pamamaraang ito na may isang out-of-bounds index ay *[hindi natukoy na pag-uugali]* kahit na ang nagresultang sanggunian ay hindi ginamit.Ang tumatawag ay dapat na matiyak na `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // KALIGTASAN: Dapat suriin ng tumatawag ang `0 <= mid <= self.len()` na iyon
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Naghahati sa isa mutable slice sa dalawang sa isang index, nang hindi gumagawa ng hangganan checking.
    ///
    /// Ang unang ay maglalaman ng lahat ng mga indeks mula `[0, mid)` (hindi kasama ang index `mid` mismo) at ang pangalawa ay maglalaman ng lahat ng mga indeks mula `[mid, len)` (hindi kasama ang index `len` mismo).
    ///
    ///
    /// Para sa isang ligtas na kahalili tingnan ang [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Ang pagtawag sa pamamaraang ito na may isang out-of-bounds index ay *[hindi natukoy na pag-uugali]* kahit na ang nagresultang sanggunian ay hindi ginamit.Ang tumatawag ay dapat na matiyak na `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // KALIGTASAN: Dapat suriin ng tumatawag ang `0 <= mid <= self.len()` na iyon.
        //
        // `[ptr; mid]` at `[mid; len]` ay hindi nag-o-overlap, kaya't ang pagbabalik ng isang nababagong sanggunian ay mabuti.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Nagbabalik ng isang umuulit sa mga subslice na pinaghihiwalay ng mga elemento na tumutugma sa `pred`.
    /// Ang naitugmang elemento ay hindi nakapaloob sa mga subslice.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Kung ang unang elemento ay naitugma, isang walang laman na hiwa ang magiging unang item na ibinalik ng iterator.
    /// Katulad nito, kung ang huling elemento sa hiwa ay naitugma, isang walang laman na hiwa ang huling item na ibinalik ng iterator:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Kung ang dalawang naitugmang elemento ay direktang katabi, isang walang laman na hiwa ang makikita sa pagitan nila:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Ibinabalik ng isang iterator higit mutable subslices na pinaghihiwalay ng mga sangkap na tumutugma `pred`.
    /// Ang naitugmang elemento ay hindi nakapaloob sa mga subslice.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Nagbabalik ng isang umuulit sa mga subslice na pinaghihiwalay ng mga elemento na tumutugma sa `pred`.
    /// Ng tugmang elemento ay nakapaloob sa dulo ng nakaraang subslice bilang terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Kung ang huling elemento ng hiwa ay naitugma, ang elementong iyon ay isasaalang-alang na terminator ng naunang hiwa.
    ///
    /// Ang hiwa na iyon ang magiging huling item na ibinalik ng iterator.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Ibinabalik ng isang iterator higit mutable subslices na pinaghihiwalay ng mga sangkap na tumutugma `pred`.
    /// Ng tugmang elemento ay nakapaloob sa mga nakaraang subslice bilang terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Nagbabalik ng isang umuulit sa mga subslice na pinaghiwalay ng mga elemento na tumutugma sa `pred`, na nagsisimula sa dulo ng hiwa at gumagana nang paatras.
    /// Ang naitugmang elemento ay hindi nakapaloob sa mga subslice.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tulad ng sa `split()`, kung ang una o huling elemento ay naitugma, isang walang laman na hiwa ang magiging una (o huling) item na ibinalik ng iterator.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Nagbabalik ng isang umuulit sa mga nababagong mga subslice na pinaghihiwalay ng mga elemento na tumutugma sa `pred`, na nagsisimula sa dulo ng hiwa at gumagana nang paurong.
    /// Ang naitugmang elemento ay hindi nakapaloob sa mga subslice.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Ibinabalik ng isang iterator higit subslices na pinaghihiwalay ng mga sangkap na tumutugma `pred`, limitado sa mga bumabalik na sa karamihan `n` item.
    /// Ang naitugmang elemento ay hindi nakapaloob sa mga subslice.
    ///
    /// Ang huling elemento ay bumalik, kung mayroon, ay maglalaman ng mga natitira sa slice.
    ///
    /// # Examples
    ///
    /// I-print ang hiwa ng hati nang isang beses sa mga numerong mahahati sa 3 (ibig sabihin, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Ibinabalik ng isang iterator higit subslices na pinaghihiwalay ng mga sangkap na tumutugma `pred`, limitado sa mga bumabalik na sa karamihan `n` item.
    /// Ang naitugmang elemento ay hindi nakapaloob sa mga subslice.
    ///
    /// Ang huling elemento ay bumalik, kung mayroon, ay maglalaman ng mga natitira sa slice.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Ibinabalik ng isang iterator higit subslices na pinaghihiwalay ng mga sangkap na tumutugma `pred` limitado sa mga bumabalik na sa karamihan `n` item.
    /// Nagsisimula ito sa dulo ng hiwa at gumagana nang paurong.
    /// Ang naitugmang elemento ay hindi nakapaloob sa mga subslice.
    ///
    /// Ang huling elemento ay bumalik, kung mayroon, ay maglalaman ng mga natitira sa slice.
    ///
    /// # Examples
    ///
    /// I-print sa paghati hati isang beses, na nagsisimula mula sa dulo, sa pamamagitan ng numero mahahati sa pamamagitan ng 3 (ie, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Ibinabalik ng isang iterator higit subslices na pinaghihiwalay ng mga sangkap na tumutugma `pred` limitado sa mga bumabalik na sa karamihan `n` item.
    /// Nagsisimula ito sa dulo ng hiwa at gumagana nang paurong.
    /// Ang naitugmang elemento ay hindi nakapaloob sa mga subslice.
    ///
    /// Ang huling elemento ay bumalik, kung mayroon, ay maglalaman ng mga natitira sa slice.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Ibinabalik ang `true` kung ang slice ay naglalaman ng isang elemento na may ibinigay na halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Kung wala kang isang `&T`, ngunit isang `&U` lamang tulad ng `T: Borrow<U>` (hal
    /// `String: Pahiram<str>`), maaari mong gamitin ang `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // hiwa ng `String`
    /// assert!(v.iter().any(|e| e == "hello")); // maghanap gamit ang `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Ibinabalik ang `true` kung ang `needle` ay isang unlapi ng hiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Palaging ibabalik ang `true` kung ang `needle` ay isang walang laman na hiwa:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Ibinabalik ang `true` kung ang `needle` ay isang panlapi ng hiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Palaging ibabalik ang `true` kung ang `needle` ay isang walang laman na hiwa:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Nagbabalik ng isang subslice na tinanggal ang unlapi.
    ///
    /// Kung ang hiwa ay nagsisimula sa `prefix`, ibabalik ang subslice pagkatapos ng unlapi, nakabalot sa `Some`.
    /// Kung `prefix` ay walang laman, nagbabalik lamang ang orihinal na slice.
    ///
    /// Kung ang hiwa ay hindi nagsisimula sa `prefix`, ibabalik ang `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ang pagpapaandar na ito ay mangangailangan ng muling pagsulat kung at kailan magiging mas sopistikado ang SlicePattern.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Nagbabalik ng isang subslice na tinanggal ang panlapi.
    ///
    /// Kung ang slice ay nagtapos sa `suffix`, ibabalik ang subslice bago ang panlapi, balot sa `Some`.
    /// Kung ang `suffix` ay walang laman, ibalik lamang ang orihinal na hiwa.
    ///
    /// Kung ang hiwa ay hindi nagtatapos sa `suffix`, ibabalik ang `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ang pagpapaandar na ito ay mangangailangan ng muling pagsulat kung at kailan magiging mas sopistikado ang SlicePattern.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Hahanap ng binary ang pinagsunod-sunod na hiwa para sa isang naibigay na elemento.
    ///
    /// Kung ang halaga ay natagpuan pagkatapos ay bumalik ang [`Result::Ok`], na naglalaman ng index ng tumutugmang elemento.
    /// Kung maraming mga tugma, kung gayon ang anumang isa sa mga tugma ay maaaring ibalik.
    /// Kung ang halaga ay hindi natagpuan pagkatapos ay ibalik ang [`Result::Err`], naglalaman ng indeks kung saan maaaring ipasok ang isang tumutugma na elemento habang pinapanatili ang pinagsunod-sunod na pagkakasunud-sunod.
    ///
    ///
    /// Tingnan din ang [`binary_search_by`], [`binary_search_by_key`], at [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Naghahanap ng isang serye ng apat na mga elemento.
    /// Ang una ay matatagpuan, na may natatanging natukoy na posisyon;ang pangalawa at pangatlo ay hindi natagpuan;ang pang-apat ay maaaring tumugma sa anumang posisyon sa `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Kung nais mong magsingit ng isang item sa isang pinagsunod-sunod na vector, habang pinapanatili ang pagkakasunud-sunod ng pagkakasunud-sunod:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Hahanap ng binary ang pinagsunod-sunod na hiwa na may pagpapaandar na kumpare.
    ///
    /// Ang comparator function na ay dapat ipatupad ang isang order pare-pareho sa ang uri ng order ng nakapailalim na slice, mga bumabalik na ang isang order code na nagpapahiwatig kung ang kanyang mga argumento ay `Less`, `Equal` o `Greater` ang ninanais na target.
    ///
    ///
    /// Kung ang halaga ay natagpuan pagkatapos ay bumalik ang [`Result::Ok`], na naglalaman ng index ng tumutugmang elemento.Kung maraming mga tugma, kung gayon ang anumang isa sa mga tugma ay maaaring ibalik.
    /// Kung ang halaga ay hindi natagpuan pagkatapos ay ibalik ang [`Result::Err`], naglalaman ng indeks kung saan maaaring ipasok ang isang tumutugma na elemento habang pinapanatili ang pinagsunod-sunod na pagkakasunud-sunod.
    ///
    /// Tingnan din ang [`binary_search`], [`binary_search_by_key`], at [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Naghahanap ng isang serye ng apat na mga elemento.Ang una ay matatagpuan, na may natatanging natukoy na posisyon;ang pangalawa at pangatlo ay hindi natagpuan;ang pang-apat ay maaaring tumugma sa anumang posisyon sa `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // KALIGTASAN: ang tawag ay ligtas sa pamamagitan ng mga sumusunod na invariant:
            // - `mid >= 0`
            // - `mid < size`: Ang `mid` ay limitado ng `[left; right)` na nakagapos.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Ang dahilan kung bakit ginagamit namin ang daloy ng kontrol na if/else kaysa sa tugma ay dahil sa muling pag-ayos ng mga pagpapatakbo ng paghahambing ng tugma, na sensitibo sa perf.
            //
            // Ito ang x86 asm para sa u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Hahanap ng binary ang pinagsunod-sunod na hiwa na may isang pangunahing pag-andar ng pagkuha.
    ///
    /// Ipinapalagay na ang hiwa ay pinagsunod-sunod sa pamamagitan ng susi, halimbawa kasama ang [`sort_by_key`] gamit ang parehong key function na pagkuha.
    ///
    /// Kung ang halaga ay natagpuan pagkatapos ay bumalik ang [`Result::Ok`], na naglalaman ng index ng tumutugmang elemento.
    /// Kung maraming mga tugma, kung gayon ang anumang isa sa mga tugma ay maaaring ibalik.
    /// Kung ang halaga ay hindi natagpuan pagkatapos ay ibalik ang [`Result::Err`], naglalaman ng indeks kung saan maaaring ipasok ang isang tumutugma na elemento habang pinapanatili ang pinagsunod-sunod na pagkakasunud-sunod.
    ///
    ///
    /// Tingnan din ang [`binary_search`], [`binary_search_by`], at [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Naghahanap ng isang serye ng apat na elemento sa isang slice ng mga pares na pinagsunod-sunod ayon sa kanilang mga pangalawang elemento.
    /// Ang una ay matatagpuan, na may natatanging natukoy na posisyon;ang pangalawa at pangatlo ay hindi natagpuan;ang pang-apat ay maaaring tumugma sa anumang posisyon sa `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Pinapayagan ang Lint rustdoc::broken_intra_doc_links na ang `slice::sort_by_key` ay nasa crate `alloc`, at dahil dito ay hindi pa umiiral kapag nagtatayo ng `core`.
    //
    // mga link sa downstream crate: #74481.Dahil ang mga primitibo ay naitala lamang sa libstd (#73423), hindi ito humahantong sa mga sirang link sa kasanayan.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Inaayos ang hiwa, ngunit maaaring hindi mapangalagaan ang pagkakasunud-sunod ng pantay na mga elemento.
    ///
    /// uri na ito ay hindi matatag (ibig sabihin, maaaring muling isaayos ang pantay na mga elemento), in-lugar (ie, ay hindi magtalaga), at *O*(*n*\*log(* n*)) pinakamasama-case.
    ///
    /// # Kasalukuyang pagpapatupad
    ///
    /// Ang kasalukuyang algorithm ay batay sa [pattern-defeating quicksort][pdqsort] ni Orson Peters, na pinagsasama ang mabilis na average na kaso ng randomized quicksort na may pinakamabilis na pinakamasamang kaso ng heapsort, habang nakakamit ang linear time sa mga hiwa na may ilang mga pattern.
    /// Gumagamit ito ng ilang randomization upang maiwasan ang mga degenerate na kaso, ngunit may isang nakapirming seed upang palaging magbigay ng deterministic na pag-uugali.
    ///
    /// Karaniwan itong mas mabilis kaysa sa matatag na pag-uuri, maliban sa ilang mga espesyal na kaso, hal, kapag ang hiwa ay binubuo ng maraming mga concatenated na pinagsunod-sunod na pagkakasunod-sunod.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Inaayos ang hiwa na may pagpapaandar na kumpara, ngunit maaaring hindi mapangalagaan ang pagkakasunud-sunod ng pantay na mga elemento.
    ///
    /// uri na ito ay hindi matatag (ibig sabihin, maaaring muling isaayos ang pantay na mga elemento), in-lugar (ie, ay hindi magtalaga), at *O*(*n*\*log(* n*)) pinakamasama-case.
    ///
    /// Dapat na tukuyin ng pagpapaandar ng kumpare ang isang kabuuang pag-order para sa mga elemento sa hiwa.Kung ang pag-order ay hindi kabuuan, ang pagkakasunud-sunod ng mga elemento ay hindi tinukoy.Ang isang order ay isang kabuuang pagkakasunud-sunod kung ito ay (para sa lahat ng `a`, `b` at `c`):
    ///
    /// * kabuuan at antisymmetric: eksaktong isa sa `a < b`, `a == b` o `a > b` ay totoo, at
    /// * palipat, `a < b` at `b < c` ay nagpapahiwatig ng `a < c`.Ang pareho ay dapat na hawakan para sa parehong `==` at `>`.
    ///
    /// Halimbawa, habang ang [`f64`] ay hindi nagpapatupad ng [`Ord`] dahil `NaN != NaN`, maaari naming gamitin ang `partial_cmp` bilang aming pag-uuri ng pag-uuri kapag alam namin na ang slice ay hindi naglalaman ng isang `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Kasalukuyang pagpapatupad
    ///
    /// Ang kasalukuyang algorithm ay batay sa [pattern-defeating quicksort][pdqsort] ni Orson Peters, na pinagsasama ang mabilis na average na kaso ng randomized quicksort na may pinakamabilis na pinakamasamang kaso ng heapsort, habang nakakamit ang linear time sa mga hiwa na may ilang mga pattern.
    /// Gumagamit ito ng ilang randomization upang maiwasan ang mga degenerate na kaso, ngunit may isang nakapirming seed upang palaging magbigay ng deterministic na pag-uugali.
    ///
    /// Karaniwan itong mas mabilis kaysa sa matatag na pag-uuri, maliban sa ilang mga espesyal na kaso, hal, kapag ang hiwa ay binubuo ng maraming mga concatenated na pinagsunod-sunod na pagkakasunod-sunod.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // reverse sorting
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Inaayos ang hiwa gamit ang isang pangunahing function ng pagkuha, ngunit maaaring hindi mapangalagaan ang pagkakasunud-sunod ng pantay na mga elemento.
    ///
    /// Ang uri na ito ay hindi matatag (ibig sabihin, maaaring ayusin muli ang pantay na mga elemento), nasa lugar (ibig sabihin, hindi naglalaan), at *O*(m\* * n *\* log(*n*)) pinakamasamang kaso, kung saan ang pangunahing pagpapaandar ay *O*(*m*).
    ///
    /// # Kasalukuyang pagpapatupad
    ///
    /// Ang kasalukuyang algorithm ay batay sa [pattern-defeating quicksort][pdqsort] ni Orson Peters, na pinagsasama ang mabilis na average na kaso ng randomized quicksort na may pinakamabilis na pinakamasamang kaso ng heapsort, habang nakakamit ang linear time sa mga hiwa na may ilang mga pattern.
    /// Gumagamit ito ng ilang randomization upang maiwasan ang mga degenerate na kaso, ngunit may isang nakapirming seed upang palaging magbigay ng deterministic na pag-uugali.
    ///
    /// Dahil sa key diskarte sa pagtawag nito, ang [`sort_unstable_by_key`](#method.sort_unstable_by_key) ay malamang na mas mabagal kaysa sa [`sort_by_cached_key`](#method.sort_by_cached_key) sa mga kaso kung saan ang key function ay mahal.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Muling ayusin ang hiwa tulad ng ang elemento sa `index` ay nasa huling posisyon na pinagsunod-sunod.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Muling ayusin ang hiwa gamit ang isang pagpapaandar na kumpare tulad ng ang elemento sa `index` ay nasa huling posisyon na pinagsunod-sunod.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Muling ayusin ang hiwa gamit ang isang pangunahing pag-andar ng pagkuha na tulad ng elemento sa `index` ay nasa huling posisyon na pinagsunod-sunod.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Muling ayusin ang hiwa tulad ng ang elemento sa `index` ay nasa huling posisyon na pinagsunod-sunod.
    ///
    /// Ang muling pagkakasunud-sunod ay may karagdagang pag-aari na ang anumang halaga sa posisyon `i < index` ay mas mababa sa o katumbas ng anumang halaga sa isang posisyon `j > index`.
    /// Bilang karagdagan, ang muling pag-ayos na ito ay hindi matatag (ibig sabihin
    /// anumang bilang ng mga pantay na elemento ay maaaring magtapos sa posisyon `index`), sa lugar (hal
    /// ay hindi naglalaan), at *O*(*n*) pinakamasamang kaso.
    /// Ang pagpapaandar na ito ay/kilala rin bilang "kth element" sa iba pang mga aklatan.
    /// Nagbabalik ito ng isang triple ng mga sumusunod na halaga: lahat ng mga elemento na mas mababa sa isa sa ibinigay na index, ang halaga sa ibinigay na index, at lahat ng mga elemento na mas malaki sa isa sa ibinigay na index.
    ///
    ///
    /// # Kasalukuyang pagpapatupad
    ///
    /// Ang kasalukuyang algorithm ay batay sa bahagi ng quickselect ng parehong quicksort algorithm na ginamit para sa [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics kapag `index >= len()`, nangangahulugang palaging panics sa mga walang laman na hiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Hanapin ang median
    /// v.select_nth_unstable(2);
    ///
    /// // Garantisado lamang kami na ang hiwa ay magiging isa sa mga sumusunod, batay sa paraan ng pag-uuri-uri namin tungkol sa tinukoy na index.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Muling ayusin ang hiwa gamit ang isang pagpapaandar na kumpare tulad ng ang elemento sa `index` ay nasa huling posisyon na pinagsunod-sunod.
    ///
    /// Ang muling pag-aayos na ito ay may karagdagang pag-aari na ang anumang halaga sa posisyon `i < index` ay mas mababa sa o katumbas ng anumang halaga sa isang posisyon `j > index` gamit ang pagpapaandar na kumpare.
    /// Bilang karagdagan, ang muling pag-ayos na ito ay hindi matatag (ibig sabihin, ang anumang bilang ng mga pantay na elemento ay maaaring magtapos sa posisyon `index`), nasa lugar (ibig sabihin ay hindi naglalaan), at *O*(*n*) pinakamasamang kaso.
    /// Ang pagpapaandar na ito ay kilala rin bilang "kth element" sa iba pang mga aklatan.
    /// Ito ay nagbabalik ng isang tatlong magkakambal ng mga sumusunod na halaga: ang lahat ng mga sangkap na mas mababa kaysa sa isa sa ibinigay na index, ang halaga sa ibinigay na index, at ang lahat ng mga sangkap na mas malaki kaysa sa isa sa ibinigay na index, gamit ang ibinigay na comparator function.
    ///
    ///
    /// # Kasalukuyang pagpapatupad
    ///
    /// Ang kasalukuyang algorithm ay batay sa bahagi ng quickselect ng parehong quicksort algorithm na ginamit para sa [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics kapag `index >= len()`, nangangahulugang palaging panics sa mga walang laman na hiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Hanapin ang median na parang ang hiwa ay pinagsunod-sunod sa pababang pagkakasunud-sunod.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Garantisado lamang kami na ang hiwa ay magiging isa sa mga sumusunod, batay sa paraan ng pag-uuri-uri namin tungkol sa tinukoy na index.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Muling ayusin ang hiwa gamit ang isang pangunahing pag-andar ng pagkuha na tulad ng elemento sa `index` ay nasa huling posisyon na pinagsunod-sunod.
    ///
    /// Ang muling pag-aayos na ito ay may karagdagang pag-aari na ang anumang halaga sa posisyon `i < index` ay mas mababa sa o katumbas ng anumang halaga sa isang posisyon `j > index` gamit ang key function na pagkuha.
    /// Bilang karagdagan, ang muling pag-ayos na ito ay hindi matatag (ibig sabihin, ang anumang bilang ng mga pantay na elemento ay maaaring magtapos sa posisyon `index`), nasa lugar (ibig sabihin ay hindi naglalaan), at *O*(*n*) pinakamasamang kaso.
    /// Ang pagpapaandar na ito ay kilala rin bilang "kth element" sa iba pang mga aklatan.
    /// Nagbabalik ito ng isang triple ng mga sumusunod na halaga: lahat ng mga elemento na mas mababa sa isa sa ibinigay na index, ang halaga sa ibinigay na index, at lahat ng mga elemento na mas malaki kaysa sa isa sa ibinigay na index, gamit ang ibinigay na key function na pagkuha.
    ///
    ///
    /// # Kasalukuyang pagpapatupad
    ///
    /// Ang kasalukuyang algorithm ay batay sa bahagi ng quickselect ng parehong quicksort algorithm na ginamit para sa [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics kapag `index >= len()`, nangangahulugang palaging panics sa mga walang laman na hiwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Ibalik ang median na para bang ang array ay pinagsunod-sunod ayon sa ganap na halaga.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Garantisado lamang kami na ang hiwa ay magiging isa sa mga sumusunod, batay sa paraan ng pag-uuri-uri namin tungkol sa tinukoy na index.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Inililipat ang lahat ng mga magkakasunod na paulit-ulit na mga elemento upang ang katapusan ng slice ayon sa [`PartialEq`] trait pagpapatupad.
    ///
    ///
    /// Nagbabalik ng dalawang hiwa.Ang una ay hindi naglalaman ng magkakasunod na paulit-ulit na mga elemento.
    /// Naglalaman ang pangalawa ng lahat ng mga duplicate nang walang tinukoy na pagkakasunud-sunod.
    ///
    /// Kung ang uri ng hiwa ay pinagsunod-sunod, ang unang ibinalik na hiwa ay naglalaman ng walang mga duplicate.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Inililipat ang lahat maliban sa una sa magkakasunod na elemento sa pagtatapos ng hiwa na nagbibigay-kasiyahan sa isang ibinigay na pagkakaugnay sa pagkakapantay-pantay.
    ///
    /// Nagbabalik ng dalawang hiwa.Ang una ay hindi naglalaman ng magkakasunod na paulit-ulit na mga elemento.
    /// Naglalaman ang pangalawa ng lahat ng mga duplicate nang walang tinukoy na pagkakasunud-sunod.
    ///
    /// Ang pagpapaandar ng `same_bucket` ay ipinapasa mga sanggunian sa dalawang elemento mula sa hiwa at dapat matukoy kung magkakapantay ang mga elemento.
    /// Ang mga elemento ay ipinapasa sa kabaligtaran ng pagkakasunud-sunod mula sa kanilang pagkakasunud-sunod sa hiwa, kaya kung ang `same_bucket(a, b)` ay nagbabalik ng `true`, ang `a` ay inililipat sa dulo ng hiwa.
    ///
    ///
    /// Kung ang uri ng hiwa ay pinagsunod-sunod, ang unang ibinalik na hiwa ay naglalaman ng walang mga duplicate.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Kahit na kami ay may isang nagbabago reference sa `self`, hindi kami makakagawa ng *arbitrary* pagbabago.Ang mga tawag sa `same_bucket` ay maaaring panic, kaya dapat nating tiyakin na ang hiwa ay nasa wastong estado sa lahat ng oras.
        //
        // Ang paraan na hawakan namin ito ay sa pamamagitan ng paggamit ng mga swap;binabaliktad namin ang lahat ng mga elemento, nagpapalitan habang nagpupunta kami upang sa huli ang mga elemento na nais naming panatilihin ay nasa harap, at ang mga nais naming tanggihan ay nasa likuran.
        // Maaari na nating hatiin ang hiwa.
        // Ang operasyon na ito ay `O(n)` pa rin.
        //
        // Halimbawa: Nagsisimula kami sa estado na ito, kung saan ang `r` ay kumakatawan sa "susunod
        // basahin ang "at kumakatawan ang `w` sa" susunod_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Ang paghahambing ng self[r] laban sa sarili [w-1], ito ay hindi isang duplicate, para magpalit kami self[r] at self[w] (walang epekto bilang r==w) at pagkatapos ay dinagdagan parehong r at w, nag-iiwan sa amin sa:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Sa paghahambing ng self[r] laban sa sarili [w-1], ang halagang ito ay isang duplicate, kaya pinapataas namin ang `r` ngunit iniiwan ang lahat na hindi nagbago:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ang paghahambing ng self[r] laban sa sarili [w-1], hindi ito isang duplicate, kaya't palitan ang self[r] at self[w] at isulong ang r and w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Hindi isang duplicate, ulitin:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Doble, advance r. End ng hiwa.Hatiin sa w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // KALIGTASAN: ang kundisyon ng `while` ay ginagarantiyahan ang `next_read` at `next_write`
        // ay mas mababa sa `len`, sa gayon ay nasa loob ng `self`.
        // `prev_ptr_write` tumuturo sa isang elemento bago ang `ptr_write`, ngunit ang `next_write` ay nagsisimula sa 1, kaya ang `prev_ptr_write` ay hindi mas mababa sa 0 at nasa loob ng hiwa.
        // Natutupad nito ang mga kinakailangan para sa dereferencing na `ptr_read`, `prev_ptr_write` at `ptr_write`, at para sa paggamit ng `ptr.add(next_read)`, `ptr.add(next_write - 1)` at `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` ay nadagdagan din ng pinaka-isang beses bawat loop nang higit na nangangahulugang walang elemento na nilaktawan kapag maaaring kailanganin itong magpalitan.
        //
        // `ptr_read` at `prev_ptr_write` hindi kailanman tumuturo sa parehong elemento.Kinakailangan ito para sa `&mut *ptr_read`, `&mut* prev_ptr_write` upang maging ligtas.
        // Ang paliwanag ay simpleng `next_read >= next_write` ay laging totoo, sa gayon ang `next_read > next_write - 1` ay masyadong.
        //
        //
        //
        //
        //
        unsafe {
            // Iwasan ang mga hangganan ng tseke sa pamamagitan ng paggamit ng mga hilaw na pahiwatig.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Inililipat ang lahat maliban sa una ng magkakasunod na elemento sa dulo ng hiwa na nalulutas sa parehong key.
    ///
    ///
    /// Nagbabalik ng dalawang hiwa.Ang una ay hindi naglalaman ng magkakasunod na paulit-ulit na mga elemento.
    /// Naglalaman ang pangalawa ng lahat ng mga duplicate nang walang tinukoy na pagkakasunud-sunod.
    ///
    /// Kung ang uri ng hiwa ay pinagsunod-sunod, ang unang ibinalik na hiwa ay naglalaman ng walang mga duplicate.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Paikutin ang hiwa sa lugar na tulad ng ang unang mga elemento ng `mid` ng hiwa ay lumipat sa dulo habang ang huling mga elemento ng `self.len() - mid` ay lumipat sa harap.
    /// Matapos tumawag sa `rotate_left`, ang elemento na dati sa index `mid` ay magiging unang elemento sa hiwa.
    ///
    /// # Panics
    ///
    /// Ang pagpapaandar na ito ay panic kung ang `mid` ay mas malaki kaysa sa haba ng hiwa.Tandaan na `mid == self.len()` ginagawa _not_ panic at ito ay isang walang-op pag-ikot.
    ///
    /// # Complexity
    ///
    /// Tumatagal ng linear (sa oras na `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Paikutin ang isang subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // KALIGTASAN: Ang saklaw na `[p.add(mid) - mid, p.add(mid) + k)` ay walang halaga
        // wasto para sa pagbabasa at pagsusulat, tulad ng hinihiling ng `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Paikutin ang hiwa sa lugar na tulad ng ang unang mga elemento ng `self.len() - k` ng hiwa ay lumipat sa dulo habang ang huling mga elemento ng `k` ay lumipat sa harap.
    /// Matapos tumawag sa `rotate_right`, ang elemento na dati sa index `self.len() - k` ay magiging unang elemento sa hiwa.
    ///
    /// # Panics
    ///
    /// Ang pagpapaandar na ito ay panic kung ang `k` ay mas malaki kaysa sa haba ng hiwa.Tandaan na ang `k == self.len()` ay gumagawa ng _not_ panic at ito ay isang pag-ikot na no-op.
    ///
    /// # Complexity
    ///
    /// Tumatagal ng linear (sa oras na `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Paikutin ang isang subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // KALIGTASAN: Ang saklaw na `[p.add(mid) - mid, p.add(mid) + k)` ay walang halaga
        // wasto para sa pagbabasa at pagsusulat, tulad ng hinihiling ng `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Pinupunan ang `self` ng mga elemento sa pamamagitan ng pag-clone ng `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Pinunan ang `self` ng mga elemento na ibinalik sa pamamagitan ng pagtawag sa isang pagsasara nang paulit-ulit.
    ///
    /// Gumagamit ang pamamaraang ito ng pagsasara upang lumikha ng mga bagong halaga.Kung mas gugustuhin mong [`Clone`] ang isang naibigay na halaga, gamitin ang [`fill`].
    /// Kung nais mong gamitin ang [`Default`] trait upang makabuo ng mga halaga, maaari mong ipasa ang [`Default::default`] bilang argument.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Kinokopya ang mga elemento mula sa `src` patungong `self`.
    ///
    /// Ang haba ng `src` ay dapat na kapareho ng `self`.
    ///
    /// Kung ang `T` ay nagpapatupad ng `Copy`, maaari itong maging mas performant upang magamit ang [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Function na ito ay panic kung ang dalawang hiwa ay may iba't ibang mga haba.
    ///
    /// # Examples
    ///
    /// Pag-clone ng dalawang elemento mula sa isang hiwa patungo sa isa pa:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Dahil ang mga hiwa ay dapat na pareho ang haba, pinuputol namin ang pinagmulan ng hiwa mula sa apat na elemento hanggang dalawa.
    /// // Magiging panic kung hindi natin ito gagawin.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Ipinapatupad ng Rust na maaari lamang magkaroon ng isang nababagong sanggunian na walang nababago na mga sanggunian sa isang partikular na piraso ng data sa isang partikular na saklaw.
    /// Dahil dito, ang pagtatangka na gamitin ang `clone_from_slice` sa isang solong hiwa ay magreresulta sa isang pagkabigo sa pag-ipon.
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Upang magtrabaho sa paligid nito, maaari naming gamitin ang [`split_at_mut`] upang lumikha ng dalawang magkakaibang mga sub-slice mula sa isang slice:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Kinokopya ang lahat ng mga elemento mula sa `src` patungong `self`, gamit ang isang memcpy.
    ///
    /// Ang haba ng `src` ay dapat na kapareho ng `self`.
    ///
    /// Kung ang `T` ay hindi nagpatupad ng `Copy`, gamitin ang [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Function na ito ay panic kung ang dalawang hiwa ay may iba't ibang mga haba.
    ///
    /// # Examples
    ///
    /// Pagkopya ng dalawang elemento mula sa isang hiwa sa isa pa:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Dahil ang mga hiwa ay dapat na pareho ang haba, pinuputol namin ang pinagmulan ng hiwa mula sa apat na elemento hanggang dalawa.
    /// // Magiging panic kung hindi natin ito gagawin.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Ipinapatupad ng Rust na maaari lamang magkaroon ng isang nababagong sanggunian na walang nababago na mga sanggunian sa isang partikular na piraso ng data sa isang partikular na saklaw.
    /// Dahil dito, ang pagtatangka na gamitin ang `copy_from_slice` sa isang solong hiwa ay magreresulta sa isang pagkabigo sa pag-ipon.
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Upang magtrabaho sa paligid nito, maaari naming gamitin ang [`split_at_mut`] upang lumikha ng dalawang magkakaibang mga sub-slice mula sa isang slice:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Ang landas ng panic code ay inilagay sa isang malamig na pagpapaandar upang hindi ma-bloat ang call site.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // KALIGTASAN: `self` ay may-bisa para sa `self.len()` mga elemento sa pamamagitan ng kahulugan, at `src` ay
        // naka-check upang magkaroon ng parehong haba.
        // Hindi maaaring mag-overlap ang mga hiwa dahil ang mga nababagong sanggunian ay eksklusibo.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Ang mga kopya ng mga elemento mula sa isang bahagi ng slice sa ibang bahagi ng kanyang sarili, gamit ang isang memmove.
    ///
    /// `src` ay ang hanay loob `self` upang kopyahin mula sa.
    /// `dest` ay ang panimulang indeks ng saklaw sa loob ng `self` upang makopya, na magkakaroon ng parehong haba ng `src`.
    /// Ang dalawang saklaw ay maaaring mag-overlap.
    /// Ang mga dulo ng dalawang saklaw ay dapat na mas mababa sa o katumbas ng `self.len()`.
    ///
    /// # Panics
    ///
    /// Ang pagpapaandar na ito ay panic kung ang alinman sa saklaw ay lumampas sa dulo ng hiwa, o kung ang dulo ng `src` ay bago ang pagsisimula.
    ///
    ///
    /// # Examples
    ///
    /// Pagkopya ng apat na byte sa loob ng isang slice:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // KALIGTASAN: ang mga kundisyon para sa `ptr::copy` lahat ay nasuri sa itaas,
        // tulad ng may mga para `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Ipinapalitan ang lahat ng mga elemento sa `self` sa mga nasa `other`.
    ///
    /// Ang haba ng `other` ay dapat na kapareho ng `self`.
    ///
    /// # Panics
    ///
    /// Function na ito ay panic kung ang dalawang hiwa ay may iba't ibang mga haba.
    ///
    /// # Example
    ///
    /// Pagpalit ng dalawang elemento sa mga hiwa:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust nagpapatupad na lang isang mutable reference sa isang partikular na piraso ng data sa isang partikular na saklaw.
    ///
    /// Dahil dito, ang pagtatangka na gamitin ang `swap_with_slice` sa isang solong hiwa ay magreresulta sa isang pagkabigo sa pag-ipon.
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Upang magtrabaho sa paligid nito, maaari naming gamitin ang [`split_at_mut`] upang lumikha ng dalawang natatanging nababago na mga sub-hiwa mula sa isang hiwa:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // KALIGTASAN: `self` ay may-bisa para sa `self.len()` mga elemento sa pamamagitan ng kahulugan, at `src` ay
        // naka-check upang magkaroon ng parehong haba.
        // Hindi maaaring mag-overlap ang mga hiwa dahil ang mga nababagong sanggunian ay eksklusibo.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Pag-andar upang makalkula ang haba ng gitna at sumusunod na hiwa para sa `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Ang gagawin namin tungkol sa `rest` ay alamin kung anong maramihang mga `U ang maaari nating mailagay sa isang pinakamababang bilang ng` T`s.
        //
        // At kung gaano karaming `T ang kailangan namin para sa bawat naturang "multiple".
        //
        // Isaalang-alang ang halimbawa T=U8 U=U16.Pagkatapos ay mailalagay natin ang 1 U sa 2 Ts.Simple
        // Ngayon, isaalang-alang ang halimbawa ng isang kaso kung saan size_of: :<T>=16, laki_of::<U>=24.</u>
        // Maaari naming ilagay ang 2 Amin sa lugar ng bawat 3 Ts sa hiwa ng `rest`.
        // Medyo mas kumplikado.
        //
        // Ang pormula upang makalkula ito ay:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Pinalawak at pinadali:
        //
        // Sa amin=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Sa kabutihang-palad dahil ang lahat na ito ay tapat na sinusuri ... pagganap dito ang mahalaga hindi!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iterative stein's algorithm Dapat pa rin nating gawin ang `const fn` na ito (at ibalik sa recursive algorithm kung gagawin natin) sapagkat ang pag-asa sa llvm upang mapilit ang lahat ng ito ay…mabuti, ginagawa akong hindi komportable.
            //
            //

            // KALIGTASAN: Ang `a` at `b` ay nasuri upang maging mga halagang hindi zero.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // alisin ang lahat ng mga kadahilanan ng 2 mula sa b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // KALIGTASAN: Ang `b` ay naka-check upang maging non-zero.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Gamit ang kaalamang ito, mahahanap natin kung gaano karaming `U ang maaari nating magkasya!
        let us_len = self.len() / ts * us;
        // At kung gaano karaming `T 'ang makakasunod sa hiwa!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Magbago ang slice sa isang slice ng isa pang uri, na tinitiyak pagkakahanay ng mga uri ay pinananatili.
    ///
    /// Hinahati ng pamamaraang ito ang hiwa sa tatlong magkakaibang hiwa: unlapi, naayos nang tama ang gitnang hiwa ng isang bagong uri, at ang hiwa ng panlapi.
    /// Maaaring gawing pamamaraan ng gitnang hiwa ang pinakadakilang haba na posible para sa isang naibigay na uri at hiwa ng pag-input, ngunit ang pagganap lamang ng iyong algorithm ang dapat na nakasalalay doon, hindi ang kawastuhan nito.
    ///
    /// Pinahihintulutan para sa lahat ng data ng pag-input na ibalik bilang pang-unahan o hiwa ng panlapi.
    ///
    /// Ang pamamaraang ito ay walang layunin kung alinman sa elemento ng pag-input na `T` o output na elemento `U` ay zero-size at ibabalik ang orihinal na hiwa nang hindi nahahati sa anumang bagay.
    ///
    /// # Safety
    ///
    /// Ang pamamaraang ito ay mahalagang isang `transmute` na patungkol sa mga elemento sa ibinalik na gitnang hiwa, kaya't ang lahat ng karaniwang mga pag-uusap na nauugnay sa `transmute::<T, U>` ay nalalapat din dito.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Tandaan na ang karamihan sa pagpapaandar na ito ay patuloy na susuriin,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // espesyal na hawakan ang mga ZST, na kung saan-huwag hawakan ang mga ito sa lahat.
            return (self, &[], &[]);
        }

        // Una, hanapin sa anong oras tayo naghihiwalay sa pagitan ng una at ika-2 na hiwa.
        // Madali sa ptr.align_offset.
        let ptr = self.as_ptr();
        // KALIGTASAN: Tingnan ang paraan ng `align_to_mut` para sa detalyadong komento sa kaligtasan.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // KALIGTASAN: ngayon `rest` ay tiyak na nakahanay, para `from_raw_parts` sa ibaba ay okay,
            // dahil ginagarantiyahan ng tumatawag na maaari naming mai-transmute ang `T` sa `U` nang ligtas.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Magbago ang slice sa isang slice ng isa pang uri, na tinitiyak pagkakahanay ng mga uri ay pinananatili.
    ///
    /// Hinahati ng pamamaraang ito ang hiwa sa tatlong magkakaibang hiwa: unlapi, naayos nang tama ang gitnang hiwa ng isang bagong uri, at ang hiwa ng panlapi.
    /// Maaaring gawing pamamaraan ng gitnang hiwa ang pinakadakilang haba na posible para sa isang naibigay na uri at hiwa ng pag-input, ngunit ang pagganap lamang ng iyong algorithm ang dapat na nakasalalay doon, hindi ang kawastuhan nito.
    ///
    /// Pinahihintulutan para sa lahat ng data ng pag-input na ibalik bilang pang-unahan o hiwa ng panlapi.
    ///
    /// Ang pamamaraang ito ay walang layunin kung alinman sa elemento ng pag-input na `T` o output na elemento `U` ay zero-size at ibabalik ang orihinal na hiwa nang hindi nahahati sa anumang bagay.
    ///
    /// # Safety
    ///
    /// Ang pamamaraang ito ay mahalagang isang `transmute` na patungkol sa mga elemento sa ibinalik na gitnang hiwa, kaya't ang lahat ng karaniwang mga pag-uusap na nauugnay sa `transmute::<T, U>` ay nalalapat din dito.
    ///
    /// # Examples
    ///
    /// Pangunahing paggamit:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Tandaan na ang karamihan sa pagpapaandar na ito ay patuloy na susuriin,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // espesyal na hawakan ang mga ZST, na kung saan-huwag hawakan ang mga ito sa lahat.
            return (self, &mut [], &mut []);
        }

        // Una, hanapin sa anong oras tayo naghihiwalay sa pagitan ng una at ika-2 na hiwa.
        // Madali sa ptr.align_offset.
        let ptr = self.as_ptr();
        // KALIGTASAN: Narito tinitiyak namin na gagamitin namin ang mga nakahanay na payo para sa U para sa
        // natitirang paraan.Ginagawa ito sa pamamagitan ng pagpasa ng isang pointer sa&[T] na may isang pagkakahanay na naka-target para sa U.
        // `crate::ptr::align_offset` ay tinatawag na may tamang pagkakahanay at wastong pointer `ptr` (nagmula ito sa isang sanggunian sa `self`) at may sukat na isang lakas na dalawa (dahil nagmula ito sa pagkakahanay para sa U), na nagbibigay-kasiyahan sa mga hadlang sa kaligtasan.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Hindi namin magagamit muli ang `rest` pagkatapos nito, maaalis ang bisa nito sa alias `mut_ptr`!KALIGTASAN: tingnan ang mga komento para sa `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Sinusuri kung ang mga elemento ng hiwa na ito ay pinagsunod-sunod.
    ///
    /// Iyon ay, para sa bawat elemento `a` at ang sumusunod na elemento `b`, dapat hawakan ng `a <= b`.Kung ang hiwa ay magbubunga ng eksaktong zero o isang elemento, ibinalik ang `true`.
    ///
    /// Tandaan na kung ang `Self::Item` ay `PartialOrd` lamang, ngunit hindi `Ord`, ang kahulugan sa itaas ay nagpapahiwatig na ang pagpapaandar na ito ay nagbabalik ng `false` kung ang anumang dalawang magkakasunod na item ay hindi maihahambing.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Sinusuri kung ang mga elemento ng hiwa na ito ay pinagsunod-sunod gamit ang ibinigay na pagpapaandar na kumpare.
    ///
    /// Sa halip ng paggamit `PartialOrd::partial_cmp`, function na ito ay gumagamit ng mga ibinigay na `compare` function na upang matukoy ang pagkakasunud-sunod ng dalawang elemento.
    /// Bukod sa na, katumbas ng [`is_sorted`];makita ang mga papeles para sa karagdagang impormasyon.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Sinusuri kung ang mga elemento ng hiwa na ito ay pinagsunod-sunod gamit ang naibigay na key function na pagkuha.
    ///
    /// Sa halip na ihambing ang mga elemento ng hiwa nang direkta, ang pagpapaandar na ito ay inihambing ang mga susi ng mga elemento, tulad ng tinukoy ng `f`.
    /// Bukod sa na, katumbas ng [`is_sorted`];makita ang mga papeles para sa karagdagang impormasyon.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Ibinabalik ang index ng punto ng pagkahati ayon sa ibinigay na panaguri (ang index ng unang elemento ng ikalawang pagkahati).
    ///
    /// slice ay ipinapalagay na partitioned ayon sa nabanggit na tambalan.
    /// Nangangahulugan ito na ang lahat ng mga elemento kung saan ang predicate ay nagbabalik ng totoo ay sa simula ng hiwa at ang lahat ng mga elemento kung saan ang predicate ay nagbabalik ng maling nasa huli.
    ///
    /// Halimbawa, ang [7, 15, 3, 5, 4, 12, 6] ay isang partitioned sa ilalim ng predicate x% 2!=0 (lahat ng mga kakaibang numero ay nasa simula, lahat kahit sa dulo).
    ///
    /// Kung ito slice ay hindi partitioned, naibalik na resulta ay hindi natukoy na at walang ibig sabihin, tulad ng ang paraan na ito ay gumaganap ng isang uri ng binary paghahanap.
    ///
    /// Tingnan din ang [`binary_search`], [`binary_search_by`], at [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // KALIGTASAN: Kapag `left < right`, `left <= mid < right`.
            // Samakatuwid ang `left` ay laging nagdaragdag at ang `right` ay laging nababawasan, at alinman sa mga ito ang napili.Sa parehong mga kaso ang `left <= right` ay nasiyahan.Samakatuwid kung `left < right` sa isang hakbang, `left <= right` ay nasiyahan sa susunod na hakbang.
            //
            // Samakatuwid hangga't `left != right`, ang `0 <= left < right <= len` ay nasiyahan at kung ang kasong ito `0 <= mid < len` ay nasiyahan din.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Kailangan nating malinaw na hatiin ang mga ito sa parehong haba
        // upang gawing mas madali para sa optimizer na i-elide ang mga hangganan sa pagsuri.
        // Ngunit dahil hindi ito maaasahan mayroon din kaming isang malinaw na pagdadalubhasa para sa T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Lumilikha ng isang walang laman na hiwa.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Lumilikha ng isang nababago na walang laman na hiwa.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Ang mga pattern sa hiwa, kasalukuyan, ginagamit lamang ng `strip_prefix` at `strip_suffix`.
/// Sa isang punto ng future, inaasahan naming gawing pangkalahatan ang `core::str::Pattern` (na sa oras ng pagsulat ay limitado sa `str`) sa mga hiwa, at pagkatapos ay ang trait na ito ay papalitan o tatapusin.
///
pub trait SlicePattern {
    /// Ang uri ng elemento ng slice ini tumugma sa.
    type Item;

    /// Sa kasalukuyan, ang mga mamimili ng `SlicePattern` ay nangangailangan ng isang slice.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}