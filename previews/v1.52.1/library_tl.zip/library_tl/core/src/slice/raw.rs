//! Libreng pag-andar upang lumikha ng `&[T]` at `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Bumubuo ng isang hiwa mula sa isang pointer at isang haba.
///
/// Ang `len` argument ay ang bilang ng mga **elemento**, hindi ang bilang ng mga byte.
///
/// # Safety
///
/// Pag-uugali ay hindi maliwanag kung ang alinman sa mga sumusunod na kondisyon ay nilabag:
///
/// * `data` dapat ay [valid] para sa mga nagbabasa para sa `len * mem::size_of::<T>()` maraming byte, at dapat itong maayos na nakahanay.Partikular na nangangahulugan ito:
///
///     * Ang buong saklaw ng memorya ng hiwa na ito ay dapat na nakapaloob sa loob ng isang solong inilalaan na bagay!
///       Ang mga hiwa ay hindi kailanman maaaring sumaklaw sa maraming mga inilalaan na mga bagay.Tingnan [below](#incorrect-usage) para sa isang halimbawa ng hindi tama sa hindi pagsasagawa ng ito sa account.
///     * `data` dapat na non-null at nakahanay kahit na para sa mga hiwa ng haba na haba.
///     Ang isang dahilan para dito ay ang pag-optimize ng layout ng enum ay maaaring umasa sa mga sanggunian (kasama ang mga hiwa ng anumang haba) na nakahanay at hindi null upang makilala ang mga ito mula sa iba pang data.
///     Maaari kang makakuha ng isang pointer na ay kapaki-pakinabang bilang `data` para sa hiwa zero-length gamit [`NonNull::dangling()`].
///
/// * `data` dapat ituro sa `len` magkasunod na maayos na naisimulang halaga ng uri `T`.
///
/// * Ang memorya na isinangguni ng ibinalik na hiwa ay hindi dapat na na-mutate sa tagal ng buhay `'a`, maliban sa loob ng isang `UnsafeCell`.
///
/// * Ang kabuuang sukat na `len * mem::size_of::<T>()` ng hiwa ay dapat na hindi mas malaki sa `isize::MAX`.
///   Tingnan ang dokumentasyon sa kaligtasan ng [`pointer::offset`].
///
/// # Caveat
///
/// Ang habambuhay para sa naibalik na hiwa ay hinuha mula sa paggamit nito.
/// Upang maiwasan ang hindi sinasadyang maling paggamit, iminungkahi na itali ang buhay sa alinmang mapagkukunan ng buhay ay ligtas sa konteksto, tulad ng sa pamamagitan ng pagbibigay ng isang function ng helper na kumukuha ng habang buhay ng isang host na halaga para sa hiwa, o sa pamamagitan ng malinaw na anotasyon.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // magpakita ng isang hiwa para sa isang solong elemento
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Maling paggamit
///
/// Ang sumusunod na pagpapaandar ng `join_slices` ay **unsound** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Ang assertion sa itaas ay tinitiyak ang `fst` at `snd` ay magkadikit, ngunit maaari pa rin silang mapaloob sa loob ng _different allocated objects_, kung saan ang paglikha ng hiwa na ito ay hindi natukoy na pag-uugali.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` at `b` ay magkakaibang inilalaan na mga bagay ...
///     let a = 42;
///     let b = 27;
///     // ... na maaaring sa gayon ay mailatag contiguously sa memorya: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Nagsasagawa ang parehong pag-andar tulad [`from_raw_parts`], maliban na maaaring mabago ng isang slice ay ibinalik.
///
/// # Safety
///
/// Pag-uugali ay hindi maliwanag kung ang alinman sa mga sumusunod na kondisyon ay nilabag:
///
/// * `data` dapat [valid] para sa parehong nagbabasa at nagsusulat para sa `len * mem::size_of::<T>()` maraming byte, at dapat itong maayos na nakahanay.Partikular na nangangahulugan ito:
///
///     * Ang buong saklaw ng memorya ng hiwa na ito ay dapat na nakapaloob sa loob ng isang solong inilalaan na bagay!
///       Ang mga hiwa ay hindi kailanman maaaring sumaklaw sa maraming mga inilalaan na mga bagay.
///     * `data` dapat na non-null at nakahanay kahit na para sa mga hiwa ng haba na haba.
///     Ang isang dahilan para dito ay ang pag-optimize ng layout ng enum ay maaaring umasa sa mga sanggunian (kasama ang mga hiwa ng anumang haba) na nakahanay at hindi null upang makilala ang mga ito mula sa iba pang data.
///
///     Maaari kang makakuha ng isang pointer na ay kapaki-pakinabang bilang `data` para sa hiwa zero-length gamit [`NonNull::dangling()`].
///
/// * `data` dapat ituro sa `len` magkasunod na maayos na naisimulang halaga ng uri `T`.
///
/// * Ang memorya na isinangguni ng ibinalik na hiwa ay hindi dapat ma-access sa pamamagitan ng anumang iba pang pointer (hindi nagmula sa halaga ng pagbabalik) sa tagal ng buhay na `'a`.
///   Parehong ipinagbabawal ang mga pag-access sa pagbasa at pagsulat.
///
/// * Ang kabuuang sukat na `len * mem::size_of::<T>()` ng hiwa ay dapat na hindi mas malaki sa `isize::MAX`.
///   Tingnan ang dokumentasyon sa kaligtasan ng [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // KALIGTASAN: ang tumatawag ay dapat na itaguyod ang kaligtasan na kontrata para sa `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Nagko-convert ng sanggunian sa T sa isang hiwa ng haba 1 (nang walang pagkopya).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Nagko-convert ng sanggunian sa T sa isang hiwa ng haba 1 (nang walang pagkopya).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}