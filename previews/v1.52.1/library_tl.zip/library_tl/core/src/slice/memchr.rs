// Orihinal na pagpapatupad na kinuha mula sa rust-memchr.
// Copyright 2015 Andrew Gallant, bluss at Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Gumamit ng truncation.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Ibinabalik ang `true` kung ang `x` ay naglalaman ng anumang zero byte.
///
/// Mula sa *Mga Matinding Computational*, J. Arndt:
///
/// "Ang ideya ay upang bawasan ang isa mula sa bawat isa sa mga byte at pagkatapos ay maghanap ng mga byte kung saan ang utang ay kumalat hanggang sa pinakamahalaga
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Ibinabalik ang unang index na tumutugma sa byte `x` in `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Mabilis na landas para sa maliliit na hiwa
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // I-scan para sa isang solong halaga ng byte sa pamamagitan ng pagbabasa ng dalawang `usize` na salita nang paisa-isa.
    //
    // Hatiin ang `text` sa tatlong bahagi
    // - hindi nakaayos na paunang bahagi, bago ang unang salita na nakahanay sa address sa teksto
    // - katawan, i-scan ng 2 salita nang paisa-isa
    // - ang huling natitirang bahagi, <2 laki ng salita

    // maghanap hanggang sa isang nakahanay na hangganan
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // hanapin ang katawan ng teksto
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // KALIGTASAN: ang panaguri ng habang ay ginagarantiyahan ang distansya ng hindi bababa sa 2 * usize_bytes
        // sa pagitan ng offset at ang dulo ng hiwa.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // masira kung mayroong pagtutugma ng byte
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Hanapin ang byte pagkatapos ng puntong tumigil ang loop ng katawan.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Ibinabalik ang huling index na tumutugma sa byte `x` sa `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // I-scan para sa isang solong halaga ng byte sa pamamagitan ng pagbabasa ng dalawang `usize` na salita nang paisa-isa.
    //
    // Hatiin ang `text` sa tatlong bahagi:
    // - hindi nakaayos na buntot, pagkatapos ng huling salita na nakahanay sa address sa teksto,
    // - katawan, na-scan ng 2 salita nang paisa-isa,
    // - ang unang natitirang bytes, <2 salitang laki.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Tinatawag namin ito upang makuha lamang ang haba ng unlapi at panlapi.
        // Sa gitna palagi naming pinoproseso ang dalawang mga piraso nang sabay-sabay.
        // KALIGTASAN: ang paglilipat ng `[u8]` sa `[usize]` ay ligtas maliban sa mga pagkakaiba sa laki na hinahawakan ng `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Paghahanap sa katawan ng teksto, tiyaking hindi kami tumatawid sa min_aligned_offset.
    // offset ay palaging nakahanay, para lamang sa pagsubok `>` ay sapat at avoids posibleng overflow.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // KALIGTASAN: ang offset ay nagsisimula sa len, suffix.len(), basta't mas malaki ito kaysa sa
        // min_aligned_offset (prefix.len()) ang natitirang distansya ay hindi bababa sa 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Masira kung mayroong isang tumutugma na byte.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Hanapin ang byte bago ang punto na tumigil ang loop ng katawan.
    text[..offset].iter().rposition(|elt| *elt == x)
}