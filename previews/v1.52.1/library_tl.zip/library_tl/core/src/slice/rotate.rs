// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Paikutin ang saklaw na `[mid-left, mid+right)` tulad na ang elemento sa `mid` ay nagiging unang elemento.Katumbas, paikutin ang mga elemento ng saklaw na `left` sa kaliwa o `right` na mga elemento sa kanan.
///
/// # Safety
///
/// Ang tinukoy na saklaw ay dapat na wasto para sa pagbabasa at pagsusulat.
///
/// # Algorithm
///
/// Ang Algorithm 1 ay ginagamit para sa maliliit na halaga ng `left + right` o para sa malaking `T`.
/// Ang mga elemento ay inililipat sa kanilang pangwakas na posisyon nang paisa-isa simula sa `mid - left` at pagsulong ng `right` na mga hakbang na modulo `left + right`, tulad ng isang pansamantalang kinakailangan lamang.
/// Sa paglaon, nakarating kami pabalik sa `mid - left`.
/// Gayunpaman, kung ang `gcd(left + right, right)` ay hindi 1, ang mga hakbang sa itaas ay lumaktaw sa mga elemento.
/// Halimbawa:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Sa kasamaang palad, ang bilang ng mga nilaktaw na mga elemento sa pagitan ng mga na-finalize na elemento ay palaging pantay, kaya maaari lamang namin mabawi ang aming panimulang posisyon at gumawa ng higit pang mga pag-ikot (ang kabuuang bilang ng mga pag-ikot ay ang `gcd(left + right, right)` value).
///
/// Ang huling resulta ay ang lahat ng mga elemento ay natapos nang isang beses at isang beses lamang.
///
/// Algorithm 2 ay ginagamit kung `left + right` ay malaki ngunit `min(left, right)` ay maliit na sapat upang magkasya papunta sa isang stack buffer.
/// Ang `min(left, right)` elemento ay kinopya papunta sa buffer, `memmove` ay inilapat sa iba, at ang mga nasa buffer ay inilipat pabalik sa butas sa tapat ng gilid ng kung saan sila nagmula.
///
/// Ang mga algorithm na maaaring ma-vectorize ay lumalagpas sa itaas sa sandaling ang `left + right` ay nagiging sapat na malaki.
/// Ang algorithm 1 ay maaaring ma-vectorize sa pamamagitan ng pag-chunking at pagganap ng maraming mga pag-ikot nang sabay-sabay, ngunit mayroong masyadong kaunting mga pag-ikot sa average hanggang sa `left + right` ay napakalubha, at ang pinakapangit na kaso ng isang solong pag-ikot ay palaging naroon.
/// Sa halip, gumagamit ang algorithm 3 ng paulit-ulit na pagpapalit ng mga elemento ng `min(left, right)` hanggang sa natitira ang isang mas maliit na problema sa paikutin.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// kapag `left < right` ang pagpapalit ay nangyayari mula sa kaliwa sa halip.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. sa ibaba algorithm ay maaaring mabibigo kung mga kasong ito ay hindi naka-check
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorithm 1 Microbenchmarks ay nagpapahiwatig na ang average na pagganap para sa mga random na paglilipat ay mas mahusay sa lahat ng mga paraan hanggang sa tungkol sa `left + right == 32`, ngunit ang pinakapangit na kaso ng pagganap ay nasira kahit na sa paligid ng 16.
            // 24 ang napili bilang gitnang lupa.
            // Kung ang sukat ng `T` ay mas malaki kaysa sa 4 `usize`s, lumalampas din ang algorithm na ito sa iba pang mga algorithm.
            //
            //
            let x = unsafe { mid.sub(left) };
            // simula ng first round
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` ay maaaring matagpuan sa harap ng kamay sa pamamagitan ng pagkalkula ng `gcd(left + right, right)`, ngunit ito ay mas mabilis na gawin ang isang loop na kinakalkula ang gcd bilang isang epekto, pagkatapos gawin ang natitirang bahagi ng tipak
            //
            //
            let mut gcd = right;
            // Inihayag ng mga benchmark na mas mabilis na magpalitan ng pansamantalang lahat sa halip na magbasa ng isang pansamantalang isang beses, kumopya paatras, at pagkatapos ay isulat ang pansamantalang iyon sa pinakadulo.
            // Posibleng ito ay dahil sa ang katunayan na ang pagpapalit o pagpapalit ng mga pansamantalang gumagamit lamang ng isang memory address sa loop sa halip na nangangailangan upang pamahalaan ang dalawa.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // sa halip na dagdagan ang `i` at pagkatapos ay suriin kung ito ay nasa labas ng mga hangganan, suriin namin kung ang `i` ay lalabas sa mga hangganan sa susunod na pagtaas.
                // Pinipigilan nito ang anumang pambalot ng mga payo o `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // pagtatapos ng unang pag-ikot
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // ang kondisyon na ito ay dapat na narito kung `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // tapusin ang tipak na may higit pang mga pag-ikot
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ay hindi isang zero-size na uri, kaya't okay na hatiin ayon sa laki nito.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorithm 2 Ang `[T; 0]` dito ay upang matiyak na ito ay naaangkop na nakahanay para sa T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithm 3 May isang kahaliling paraan ng swapping na nagsasangkot ng paghahanap ng kung saan ang huling swap ng algorithm na ito ay magiging, at pagpapalit gamit na huling tipak sa halip ng pagpapalit katabing chunks tulad nito algorithm ginagawa, ngunit sa ganitong paraan pa rin ang mas mabilis.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorithm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}