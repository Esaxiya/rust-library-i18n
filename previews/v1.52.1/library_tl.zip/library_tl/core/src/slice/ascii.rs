//! Mga pagpapatakbo sa ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Sinusuri kung ang lahat ng mga byte sa hiwa na ito ay nasa loob ng saklaw ng ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Sinusuri na ang dalawang hiwa ay isang ASCII case-insensitive match.
    ///
    /// Kapareho ng `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ngunit nang walang paglalaan at pagkopya ng mga pansamantala.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Binabago ang hiwa na ito sa ASCII itaas na kaso na katumbas na lugar.
    ///
    /// Ang mga titik ng ASCII 'a' hanggang 'z' ay nai-map sa 'A' hanggang 'Z', ngunit ang mga hindi ASCII na titik ay hindi nagbabago.
    ///
    /// Upang ibalik ang isang bagong na-uppercased na halaga nang hindi binabago ang mayroon nang, gamitin ang [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Binabago ang hiwa na ito sa ASCII na mas mababang kaso na katumbas na lugar.
    ///
    /// ASCII titik 'A' na 'Z' ay nama-map sa 'a' na 'z', ngunit hindi ASCII mga titik ay hindi magbabago.
    ///
    /// Upang maibalik ang isang bagong nabayarang halaga nang hindi binabago ang mayroon nang, gamitin ang [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Ibinabalik ang `true` kung ang anumang byte sa salitang `v` ay nonascii (>=128).
/// Naka-snarf mula sa `../str/mod.rs`, na gumagawa ng katulad na bagay para sa pagpapatunay ng utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Na-optimize ang pagsubok na ASCII na gagamit ng mga pagpapatakbo ng usize-at-a-time sa halip na byte-at-a-time na operasyon (kapag posible).
///
/// Ang algorithm na ginagamit namin dito ay medyo simple.Kung `s` ay masyadong maikli, kami lang suriin ang bawat byte at gawin sa mga ito.Kung hindi man:
///
/// - Basahin ang unang salita na may isang hindi nakaayos na pagkarga.
/// - Ihanay ang pointer, basahin ang mga kasunod na salita hanggang sa magtapos sa mga nakahanay na mga karga.
/// - Basahin ang huling `usize` mula sa `s` na may isang hindi nakaayos na pagkarga.
///
/// Kung ang alinman sa mga paglo-load na ito ay gumagawa ng isang bagay kung saan ang `contains_nonascii` (above) ay nagbabalik ng totoo, alam namin na ang sagot ay hindi totoo.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Kung wala kaming makukuhang anumang mula sa pagpapatupad ng word-at-a-time, bumalik sa isang scalar loop.
    //
    // Ginagawa din namin ito para sa mga arkitektura kung saan ang `size_of::<usize>()` ay hindi sapat na pagkakahanay para sa `usize`, sapagkat ito ay isang kakatwang kaso ng edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Palagi naming binabasa ang unang salitang hindi nakahanay, na nangangahulugang `align_offset` ay
    // 0, babasahin namin muli ang parehong halaga para sa nakahanay na nabasa.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // KALIGTASAN: Pinatutunayan namin ang `len < USIZE_SIZE` sa itaas.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Sinuri namin ito sa itaas, medyo implicitly.
    // Tandaan na ang `offset_to_aligned` ay alinman sa `align_offset` o `USIZE_SIZE`, kapwa malinaw na naka-check sa itaas.
    //
    debug_assert!(offset_to_aligned <= len);

    // KALIGTASAN: ang word_ptr ay ang (maayos na nakahanay) na paggamit ng ptr na ginagamit namin upang mabasa ang
    // gitnang tipak ng hiwa.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` ay ang byte index ng `word_ptr`, ginagamit para sa mga loop end check.
    let mut byte_pos = offset_to_aligned;

    // Suriin ng Paranoia ang tungkol sa pagkakahanay, dahil magsasagawa kami ng isang bungkos ng mga hindi nakaayos na pag-load.
    // Sa pagsasanay na ito ay dapat na imposible maliban sa isang bug sa `align_offset` bagaman.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Basahin ang mga kasunod na salita hanggang sa huling nakahanay na salita, hindi kasama ang huling nakahanay na salita nang magawa nito upang gawin sa buntot na suriin sa paglaon, upang matiyak na ang buntot ay palaging isang `usize` ng higit pa sa labis na branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Suriin ng kalinisan na ang nabasa ay nasa hangganan
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // At iyon ang aming mga pagpapalagay tungkol sa `byte_pos` na humahawak.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // KALIGTASAN: Alam namin na ang `word_ptr` ay maayos na nakahanay (dahil sa
        // `align_offset`), at alam namin na mayroon kaming sapat na mga byte sa pagitan ng `word_ptr` at ang dulo
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // KALIGTASAN: Alam namin na `byte_pos <= len - USIZE_SIZE`, na nangangahulugang iyon
        // pagkatapos ng `add` na ito, ang `word_ptr` ay magiging pinaka-one-past-the-end.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Suriin ang katinuan upang matiyak na mayroon lamang isang natitirang `usize`.
    // Dapat itong garantisado ng aming kondisyon sa loop.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // KALIGTASAN: Nakasalalay ito sa `len >= USIZE_SIZE`, na sinusuri namin sa simula.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}