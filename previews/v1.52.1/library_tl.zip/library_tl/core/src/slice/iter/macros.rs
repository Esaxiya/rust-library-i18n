//! Ginamit ng mga macro ng mga iterator ng hiwa.

// Ang pagsasama ng is_empty at len ay gumagawa ng isang malaking pagkakaiba sa pagganap
macro_rules! is_empty {
    // Ang paraan ng pag-encode namin ng haba ng isang ZST iterator, gumagana ito pareho para sa ZST at non-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Upang mapupuksa ang ilang mga hangganan ng tseke (tingnan ang `position`), kinukuwenta namin ang haba sa isang medyo hindi inaasahang paraan.
// (Nasubukan ng `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // minsan kami ay ginagamit sa loob ng isang hindi ligtas na mga bloke

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Ang _cannot_ na ito ay gumagamit ng `unchecked_sub` dahil nakasalalay kami sa pambalot upang kumatawan sa haba ng mahabang ZST slice iterators.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Alam namin na `start <= end`, kaya maaaring gumawa ng mas mahusay kaysa sa `offset_from`, na kailangang makitungo sa naka-sign.
            // Sa pamamagitan ng pagtatakda ng mga naaangkop na watawat dito masasabi natin ito sa LLVM, na makakatulong sa pag-aalis ng mga pagsusuri sa hangganan.
            // KALIGTASAN: Sa pamamagitan ng uri ng invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Sa pamamagitan din ng pagsasabi sa LLVM na ang mga payo ay hiwalay ng isang eksaktong dami ng laki ng uri, maaari itong i-optimize ang `len() == 0` pababa sa `start == end` sa halip na `(end - start) < size`.
            //
            // KALIGTASAN: Sa pamamagitan ng uri ng invariant, ang mga pahiwatig ay nakahanay sa gayon ang
            //         ang distansya sa pagitan ng mga ito ay dapat na isang maramihang laki ng pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Ang ibinahaging kahulugan ng mga iterator ng `Iter` at `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Ibinabalik ang unang elemento at inililipat ang pagsisimula ng iterator pasulong ng 1.
        // Mas mahusay na nagpapabuti sa pagganap kumpara sa isang naka-linya na pagpapaandar.
        // Ang iterator ay hindi dapat walang laman.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Ibinabalik ang huling elemento at inililipat ang dulo ng iterator nang paatras ng 1.
        // Mas mahusay na nagpapabuti sa pagganap kumpara sa isang naka-linya na pagpapaandar.
        // Ang iterator ay hindi dapat walang laman.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Pinapaliit ang umuulit kapag ang T ay isang ZST, sa pamamagitan ng paglipat ng dulo ng iterator nang paatras ng `n`.
        // `n` hindi dapat lumagpas sa `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Pag-andar ng helper para sa paglikha ng isang hiwa mula sa iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // KALIGTASAN: ang iterator ay nilikha mula sa isang slice na may pointer
                // `self.ptr` at haba `len!(self)`.
                // Ginagarantiyahan nito na ang lahat ng mga kinakailangan sa `from_raw_parts` ay natupad.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Ang pagpapaandar ng helper para sa paglipat ng pagsisimula ng iterator pasulong ng mga elemento ng `offset`, na binabalik ang dating pagsisimula.
            //
            // Hindi ligtas dahil ang offset ay hindi dapat lumagpas sa `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // KALIGTASAN: tumatawag garantiya na `offset` ay hindi lalampas `self.len()`,
                    // kaya ito bagong pointer ay nasa loob `self` at sa gayon ay garantisadong na maging non-null.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Ang pagpapaandar ng helper para sa paglipat ng dulo ng iterator paatras ng mga elemento ng `offset`, na ibinabalik ang bagong dulo.
            //
            // Hindi ligtas dahil ang offset ay hindi dapat lumagpas sa `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // KALIGTASAN: tumatawag garantiya na `offset` ay hindi lalampas `self.len()`,
                    // na kung saan ay garantisadong hindi mag-overflow ng `isize`.
                    // Gayundin, ang nagresultang pointer ay nasa mga hangganan ng `slice`, na natutupad ang iba pang mga kinakailangan para sa `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // maaaring ipatupad sa mga hiwa, ngunit iniiwasan ang mga hangganan ng pagsusuri

                // KALIGTASAN: Ang mga tawag sa `assume` ay ligtas mula sa panimulang pointer ng isang slice
                // dapat na non-null, at ang mga hiwa sa mga hindi ZST ay dapat ding magkaroon ng isang non-null end pointer.
                // Ang tawag sa `next_unchecked!` ay ligtas dahil sinuri namin kung ang iterator ay walang laman muna.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Walang laman ang iterator na ito.
                    if mem::size_of::<T>() == 0 {
                        // Kailangan nating gawin ito sa ganitong paraan dahil ang `ptr` ay maaaring hindi kailanman magiging 0, ngunit ang `end` ay maaaring (dahil sa balot).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // KALIGTASAN: ang pagtatapos ay hindi maaaring 0 kung ang T ay hindi ZST sapagkat ang ptr ay hindi 0 at magtatapos>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // KALIGTASAN: Kami ay nasa hangganan.Tama ang ginagawa ng `post_inc_start` kahit para sa mga ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Ino-override namin ang default na pagpapatupad, na gumagamit ng `try_fold`, dahil ang simpleng pagpapatupad na ito ay bumubuo ng mas kaunting LLVM IR at mas mabilis na mag-ipon.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Ino-override namin ang default na pagpapatupad, na gumagamit ng `try_fold`, dahil ang simpleng pagpapatupad na ito ay bumubuo ng mas kaunting LLVM IR at mas mabilis na mag-ipon.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Ino-override namin ang default na pagpapatupad, na gumagamit ng `try_fold`, dahil ang simpleng pagpapatupad na ito ay bumubuo ng mas kaunting LLVM IR at mas mabilis na mag-ipon.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Ino-override namin ang default na pagpapatupad, na gumagamit ng `try_fold`, dahil ang simpleng pagpapatupad na ito ay bumubuo ng mas kaunting LLVM IR at mas mabilis na mag-ipon.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Ino-override namin ang default na pagpapatupad, na gumagamit ng `try_fold`, dahil ang simpleng pagpapatupad na ito ay bumubuo ng mas kaunting LLVM IR at mas mabilis na mag-ipon.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Ino-override namin ang default na pagpapatupad, na gumagamit ng `try_fold`, dahil ang simpleng pagpapatupad na ito ay bumubuo ng mas kaunting LLVM IR at mas mabilis na mag-ipon.
            // Gayundin, iniiwasan ng `assume` ang isang pagsusuri sa mga hangganan.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // KALIGTASAN: ginagarantiyahan kaming mapupunta sa mga hangganan ng loop invariant:
                        // kapag `i >= n`, `self.next()` nagbabalik `None` at ang loop break.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Ino-override namin ang default na pagpapatupad, na gumagamit ng `try_fold`, dahil ang simpleng pagpapatupad na ito ay bumubuo ng mas kaunting LLVM IR at mas mabilis na mag-ipon.
            // Gayundin, iniiwasan ng `assume` ang isang pagsusuri sa mga hangganan.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // KALIGTASAN: Ang `i` ay dapat na mas mababa sa `n` dahil nagsisimula ito sa `n`
                        // at bumababa lang.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // KALIGTASAN: dapat magagarantiya ng tumatawag na ang `i` ay nasa mga hangganan ng
                // ang pinagbabatayan na hiwa, kaya't ang `i` ay hindi maaaring umapaw sa isang `isize`, at ang mga ibinalik na sanggunian ay ginagarantiyahan na mag-refer sa isang elemento ng hiwa at sa gayon garantisadong maging wasto.
                //
                // Tandaan din na tinitiyak din ng tumatawag na hindi na kami tinawag na may parehong index muli, at na walang ibang mga pamamaraan na makaka-access sa subslice na ito ang tinawag, kaya't wasto para sa naibalik na sanggunian upang maipalabas sa kaso ng
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // maaaring ipatupad sa mga hiwa, ngunit iniiwasan ang mga hangganan ng pagsusuri

                // KALIGTASAN: Ang mga tawag sa `assume` ay ligtas dahil ang panimulang pointer ng isang hiwa ay dapat na hindi null,
                // at ang mga hiwa sa mga hindi ZST ay dapat ding magkaroon ng isang hindi null na dulo ng pointer.
                // Ang tawag sa `next_back_unchecked!` ay ligtas dahil sinuri namin kung ang iterator ay walang laman muna.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Walang laman ang iterator na ito.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // KALIGTASAN: Kami ay nasa hangganan.Tama ang ginagawa ng `pre_dec_end` kahit para sa mga ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}