use crate::iter::FromIterator;

/// Nagko-collapse lahat ng mga item unit mula sa isang iterator sa isa.
///
/// Mas kapaki-pakinabang ito kapag isinama sa mga abstraction na may mas mataas na antas, tulad ng pagkolekta sa isang `Result<(), E>` kung saan nagmamalasakit ka lang sa mga error:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}