//! Naibabahaging mutable container.
//!
//! Ang kaligtasan ng memorya ng Rust ay batay sa panuntunang ito: Dahil sa isang bagay na `T`, posible lamang na magkaroon ng isa sa mga sumusunod:
//!
//! - Ang pagkakaroon ng maraming hindi nababago na mga sanggunian (`&T`) sa bagay (kilala rin bilang **aliasing**).
//! - Ang pagkakaroon ng isang nababagong sanggunian (`&mut T`) sa bagay (na kilala rin bilang **mutability**).
//!
//! Ito ay ipinatutupad ng Rust compiler.Gayunpaman, may mga sitwasyon kung saan ang panuntunang ito ay hindi sapat na kakayahang umangkop.Minsan kinakailangan upang magkaroon ng maraming mga sanggunian sa isang bagay at paunahin ito.
//!
//! Ang mga maibabahaging nababago na lalagyan ay mayroon upang payagan ang kakayahang mabago sa isang kontroladong pamamaraan, kahit na sa pagkakaroon ng aliasing.Parehong [`Cell<T>`] at [`RefCell<T>`] payagang gawin ito bilang isang solong-sinulid na paraan.
//! Gayunpaman, ang `Cell<T>` o `RefCell<T>` ay ligtas sa thread (hindi nila ipinapatupad ang [`Sync`]).
//! Kung kailangan mong gawin ang aliasing at mutation sa pagitan ng maraming mga thread posible na gumamit ng mga uri ng [`Mutex<T>`], [`RwLock<T>`] o [`atomic`].
//!
//! Ang mga halaga ng mga uri ng `Cell<T>` at `RefCell<T>` ay maaaring mai-mutate sa pamamagitan ng mga nakabahaging sanggunian (ie
//! ang karaniwang uri `&T`), samantalang ang karamihan sa mga uri Rust maaari lamang mutated sa pamamagitan ng mga natatanging (`&mut T`) sanggunian.
//! Sinasabi namin na ang `Cell<T>` at `RefCell<T>` ay nagbibigay ng 'interior mutability', taliwas sa mga tipikal na uri ng Rust na nagpapakita ng 'namana ng pagkakabago'.
//!
//! Ang mga uri ng cell ay nagmula sa dalawang lasa: `Cell<T>` at `RefCell<T>`.`Cell<T>` nagpapatupad interior mutability sa pamamagitan ng paggalaw halaga sa at sa labas ng `Cell<T>`.
//! Upang magamit ang mga sanggunian sa halip na mga halaga, dapat gumamit ang isang uri ng `RefCell<T>`, pagkuha ng isang lock ng pagsulat bago magbago.Nagbibigay ang `Cell<T>` ng mga pamamaraan upang makuha at baguhin ang kasalukuyang panloob na halaga:
//!
//!  - Para sa mga uri na nagpapatupad ng [`Copy`], kinukuha ng pamamaraang [`get`](Cell::get) ang kasalukuyang panloob na halaga.
//!  - Para sa mga uri na nagpapatupad ng [`Default`], pinapalitan ng pamamaraang [`take`](Cell::take) ang kasalukuyang panloob na halaga ng [`Default::default()`] at ibabalik ang pinalitan na halaga.
//!  - Para sa lahat ng mga uri, ang [`replace`](Cell::replace) paraan ay pumapalit sa kasalukuyang interior halaga at nagbabalik ang papalitan halaga at ang paraan [`into_inner`](Cell::into_inner) nang-uubos ng `Cell<T>` at nagbabalik ang loob na halaga.
//!  Bilang karagdagan, pinapalitan ng pamamaraang [`set`](Cell::set) ang panloob na halaga, na ibinabagsak ang pinalitan na halaga.
//!
//! `RefCell<T>` gumagamit ng mga buhay ni Rust upang ipatupad ang 'pabagu-bagong paghiram', isang proseso kung saan maaaring mag-angkin ang isang pansamantala, eksklusibo, nababagabag na pag-access sa panloob na halaga.
//! Nanghihiram para sa `RefCell<T>`S ay sinusubaybayan 'sa runtime', hindi katulad katutubong uri ng sanggunian ni Rust na kung saan ay lubos na sinusubaybayan statically, sa itala oras.
//! Dahil `RefCell<T>` ay humihiram ay dynamic ito ay posible upang tangkain upang humiram ng isang halaga na ay naka-mutably hiniram;kapag nangyari ito nagreresulta sa thread panic.
//!
//! # Kailan pipiliin ang panloob na kakayahang magbago
//!
//! Ang mas karaniwang minana mutability, kung saan ang isa ay dapat magkaroon ng natatanging access sa mutate ang halaga, ay isa sa mga elemento key wika na nagbibigay-daan Rust na dahilan Matindi ang tungkol pointer aliasing, statically pumipigil sa pag-crash bug.
//! Dahil dito, mas ginustong pagmamana ng minana, at ang interior mutability ay isang bagay ng huling paraan.
//! Dahil ang mga uri ng cell ay pinapagana ang pag-mutate kung saan ay hindi ito tatanggapin kahit na, may mga pagkakataong maaaring naaangkop ang panloob na pagbabago, o kahit na *dapat* gamitin, hal.
//!
//! * Ipinapakilala mutability 'inside' ng isang bagay na hindi nababago
//! * Mga detalye ng pagpapatupad ng lohikal na hindi nababago na pamamaraan.
//! * Mutating pagpapatupad ng [`Clone`].
//!
//! ## Ipinapakilala mutability 'inside' ng isang bagay na hindi nababago
//!
//! Maraming nakabahaging mga uri ng matalinong pointer, kabilang ang [`Rc<T>`] at [`Arc<T>`], ay nagbibigay ng mga lalagyan na maaaring ma-clone at maibahagi sa pagitan ng maraming partido.
//! Dahil ang mga nilalaman na nilalaman ay maaaring multiply-alias, maaari lamang silang hiram ng `&`, hindi `&mut`.
//! Nang walang mga cell na ito ay imposible upang mutate data sa loob ng mga matalinong payo sa lahat.
//!
//! Ito ay napaka-pangkaraniwan pagkatapos upang maglagay ng `RefCell<T>` sa loob ng mga nakabahaging uri ng pointer upang maipakilala muli ang kakayahang umayos:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Lumikha ng isang bagong bloke upang limitahan ang saklaw ng mga dynamic na humiram
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Tandaan na kung hindi namin hinayaan ang nakaraang paghiram ng cache na mahulog sa saklaw pagkatapos ng kasunod na paghiram ay magdudulot ng isang pabagu-bagong thread na panic.
//!     //
//!     // Ito ang pangunahing peligro ng paggamit ng `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Tandaan na ang halimbawa na ito ay gumagamit ng `Rc<T>` at hindi `Arc<T>`.`RefCell<T>Ang`s ay para sa mga senaryo na solong may sinulid.Isaalang-alang ang paggamit ng [`RwLock<T>`] o [`Mutex<T>`] kung kailangan mo ng nakabahaging pagbabago sa isang sitwasyong multi-thread.
//!
//! ## Pagpapatupad detalye ng lohikal-nababago pamamaraan
//!
//! Paminsan-minsan maaari itong maging kanais-nais na hindi ilantad sa isang API na mayroong pagbago nangyayari "under the hood".
//! Maaaring ito ay dahil lohikal na operasyon ay hindi nababago, ngunit eg, cache pwersa sa pagpapatupad upang magsagawa ng mutation;o dahil kailangan mong gumamit ng mutation upang magpatupad ng isang pamamaraan na trait na orihinal na tinukoy upang kumuha ng `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Mamahaling pag-compute mapupunta dito
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Mutating pagpapatupad ng `Clone`
//!
//! Ito ay simpleng isang espesyal, ngunit karaniwan, na kaso ng nakaraang: pagtatago ng kakayahang umangkop para sa mga pagpapatakbo na lilitaw na hindi nababago.
//! Ang pamamaraang [`clone`](Clone::clone) ay inaasahang hindi mababago ang mapagkukunan ng mapagkukunan, at idineklara na kukuha ng `&self`, hindi `&mut self`.
//! Samakatuwid, ang anumang pagbago na ang mangyayari sa `clone` pamamaraan ay dapat gamitin ang mga uri ng cell.
//! Halimbawa, pinapanatili ng [`Rc<T>`] ang mga bilang ng sanggunian sa loob ng isang `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Isang nababagong lokasyon ng memorya.
///
/// # Examples
///
/// Sa halimbawang ito, maaari mong makita na `Cell<T>` nagbibigay-daan sa pagbago sa loob hindi nababago ang isang struct.
/// Sa madaling salita, nagbibigay-daan ito sa "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ERROR: Ang `my_struct` ay hindi nababago
/// // my_struct.regular_field =new_value;
///
/// // TRABAHO: bagaman ang `my_struct` ay hindi nababago, ang `special_field` ay isang `Cell`,
/// // na maaaring laging nai-mutate
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Tingnan ang [module-level documentation](self) para sa higit pa.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Lumilikha ng `Cell<T>`, na may `Default` halaga para sa T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Lumilikha ng isang bagong `Cell` naglalaman ng ibinigay na halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Itinatakda ang nakapaloob na halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Ipinagpapalit ang mga halaga ng dalawang Mga Cell.
    /// Ang pagkakaiba sa `std::mem::swap` ay ang pagpapaandar na ito ay hindi nangangailangan ng `&mut` na sanggunian.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // KALIGTASAN: Maaari itong mapanganib kung tinawag mula sa magkakahiwalay na mga thread, ngunit `Cell`
        // ay `!Sync` kaya ito ay hindi mangyayari.
        // Hindi rin nito papatawarin ang anumang mga payo dahil tinitiyak ng `Cell` na wala nang iba pa ang tumuturo sa alinman sa mga "Cell` na ito.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Pinapalitan ang nakapaloob halaga na may `val`, at nagbabalik ang lumang nakapaloob halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // KALIGTASAN: Ito ay maaaring maging sanhi ng karera data kung tinatawag na mula sa isang hiwalay na thread,
        // ngunit ang `Cell` ay `!Sync` kaya't hindi ito mangyayari.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Inaalis ang halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Ibinabalik ng isang kopya ng nilalaman na halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // KALIGTASAN: Ito ay maaaring maging sanhi ng karera data kung tinatawag na mula sa isang hiwalay na thread,
        // ngunit ang `Cell` ay `!Sync` kaya't hindi ito mangyayari.
        unsafe { *self.value.get() }
    }

    /// Ina-update ang nilalaman na nilalaman gamit ang isang pagpapaandar at ibabalik ang bagong halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Nagbabalik ng isang hilaw na pointer sa pinagbabatayan ng data sa cell na ito.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Ibinabalik maaaring mabago ng isang reference sa ang kalakip na data.
    ///
    /// Ang tawag na ito ay humihiram ng `Cell` na pabagu-bago (sa compile-time) na ginagarantiyahan na nagtataglay kami ng tanging sanggunian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Nagbabalik ng isang `&Cell<T>` mula sa isang `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // KALIGTASAN: Tinitiyak ng `&mut` ang natatanging pag-access.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Dadalhin ang halaga ng cell, nag-iiwan `Default::default()` sa lugar nito.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Ibinabalik ng `&[Cell<T>]` mula sa isang `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // KALIGTASAN: `Cell<T>` ay may parehong layout memory tulad ng `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Ang isang nababagabag na lokasyon ng memorya na may pabagu-bago na mga panuntunan sa paghiram
///
/// Tingnan ang [module-level documentation](self) para sa higit pa.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Isang error na ibinalik ng [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Isang error na ibinalik ng [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Ang mga positibong halaga ay kumakatawan sa bilang ng `Ref` na aktibo.Ang mga negatibong halaga ay kumakatawan sa bilang ng aktibong `RefMut`.
// Ang maramihang `RefMut` ay maaari lamang maging aktibo sa bawat oras kung tumutukoy sila sa mga natatanging, hindi tumutukoy na mga bahagi ng isang `RefCell` (hal, iba't ibang mga saklaw ng isang hiwa).
//
// `Ref` at `RefMut` ay parehong dalawang salita sa laki, at sa gayon ay malamang na hindi magkakaroon ng sapat na `Ref`s o`RefMut`s na mayroon upang umapaw kalahati ng saklaw ng `usize`.
// Kaya, ang isang `BorrowFlag` ay marahil ay hindi kailanman umaapaw o mag-underflow.
// Gayunpaman, ito ay hindi isang garantiya, bilang isang pathological programa ay maaaring paulit-ulit na lumikha at pagkatapos ay mem::forget `Ref`s o`RefMut`s.
// Kaya, ang lahat ng code ay dapat na malinaw na suriin para sa overflow at underflow upang maiwasan ang hindi ligtas, o hindi bababa sa kumilos nang tama sa kaganapan na maganap ang overflow o underflow (hal., Tingnan ang BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Lumilikha ng isang bagong `RefCell` naglalaman `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Naubos ang `RefCell`, na ibinabalik ang balot na halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Dahil ang pagpapaandar na ito ay tumatagal ng `self` (ang `RefCell`) ayon sa halaga, ang tagatala statically patunayan na ito ay hindi kasalukuyang hiniram.
        //
        self.value.into_inner()
    }

    /// Pinapalitan ang nakabalot na halaga na may isang bago, bumabalik sa lumang halaga, walang deinitializing mag-isa.
    ///
    ///
    /// Ang function na ito ay tumutugon sa [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics kung ang halaga ay kasalukuyang hiniram.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Pinapalitan ang balot na halaga ng bago na na-compute mula sa `f`, na ibinabalik ang dating halaga, nang hindi na-deinitialize ang alinman.
    ///
    ///
    /// # Panics
    ///
    /// Panics kung ang halaga ay kasalukuyang hiniram.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Ipinagpalit ang balot na halaga ng `self` gamit ang balot na halagang `other`, nang hindi deinitialize ang alinman.
    ///
    ///
    /// Ang pagpapaandar na ito ay tumutugma sa [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics kung ang halaga sa alinman sa `RefCell` ay kasalukuyang hiniram.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Hindi maiiwasan na humiram ng balot na halaga.
    ///
    /// Ang panghihiram ay tumatagal hanggang sa mabalik ang saklaw ng `Ref`.
    /// Ang maramihang hindi nababago na mga pag-utang ay maaaring mailabas nang sabay.
    ///
    /// # Panics
    ///
    /// Panics kung ang halaga ay kasalukuyang nababagabag na hiniram.
    /// Para sa isang variant na hindi nagpapanic, gumamit ng [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Isang halimbawa ng panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Immutably borrows ang nakabalot na halaga, sa pagbabalik ng isang error kung ang halaga ay kasalukuyang mutably hiniram.
    ///
    ///
    /// Ang panghihiram ay tumatagal hanggang sa mabalik ang saklaw ng `Ref`.
    /// Ang maramihang hindi nababago na mga pag-utang ay maaaring mailabas nang sabay.
    ///
    /// Ito ay ang mga di-panicking variant ng [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // KALIGTASAN: `BorrowRef` ay nagsisigurado na mayroon lamang hindi nababago access
            // sa halaga habang hiniram.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Malamang na hinihiram ang balot na halaga.
    ///
    /// Ang panghihiram ay tumatagal hanggang sa ibalik ang `RefMut` o lahat ng `RefMut` na nagmula dito sa saklaw ng exit.
    ///
    /// Ang halaga ay hindi maaaring hiramin habang ito ay humihiram ay aktibo.
    ///
    /// # Panics
    ///
    /// Panics kung ang halaga ay kasalukuyang hiniram.
    /// Para sa isang variant na hindi nagpapanic, gumamit ng [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Isang halimbawa ng panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Mapapagpahiram na borrows ang balot na halaga, na nagbabalik ng isang error kung ang halaga ay kasalukuyang hiniram.
    ///
    ///
    /// Ang panghihiram ay tumatagal hanggang sa ibalik ang `RefMut` o lahat ng `RefMut` na nagmula dito sa saklaw ng exit.
    /// Ang halaga ay hindi maaaring hiramin habang ito ay humihiram ay aktibo.
    ///
    /// Ito ang variant na hindi nagpapanic ng [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // KALIGTASAN: Ginagarantiyahan ng `BorrowRef` ang natatanging pag-access.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Nagbabalik ng isang hilaw na pointer sa pinagbabatayan ng data sa cell na ito.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Ibinabalik maaaring mabago ng isang reference sa ang kalakip na data.
    ///
    /// Ang tawag na ito ay nanghihiram ng `RefCell` na pabagu-bago (sa compile-time) kaya't hindi na kailangan para sa mga dinamikong pagsusuri.
    ///
    /// Gayunpaman maging maingat: Inaasahan ng pamamaraang ito na maibago ang `self`, na sa pangkalahatan ay hindi ito ang kaso kapag gumagamit ng isang `RefCell`.
    ///
    /// Tumingin sa [`borrow_mut`] na paraan sa halip kung ang `self` ay hindi nababagabag.
    ///
    /// Gayundin, mangyaring magkaroon ng kamalayan na ang pamamaraang ito ay para lamang sa mga espesyal na pangyayari at karaniwang hindi ito ang nais mo.
    /// Sa kaso ng mga pagdududa, gamitin [`borrow_mut`] sa halip.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// I-undo ang epekto ng mga leak na bantay sa estado ng paghiram ng `RefCell`.
    ///
    /// Ang tawag na ito ay katulad ng [`get_mut`] ngunit mas dalubhasa.
    /// Ito ay humihiram `RefCell` mutably upang matiyak na walang ay humihiram umiiral at pagkatapos ay nagre-reset ang estado sa pagsubaybay Nagbahagi humihiram.
    /// Ito ay nauugnay kung ang ilang `Ref` o `RefMut` na pag-utang ay na-leak.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Immutably borrows ang nakabalot na halaga, sa pagbabalik ng isang error kung ang halaga ay kasalukuyang mutably hiniram.
    ///
    /// # Safety
    ///
    /// Hindi tulad ng `RefCell::borrow`, ang paraan na ito ay hindi ligtas na ito sapagkat ito ay hindi nagbabalik ng isang `Ref`, kaya hindi umaalis sa humiram bandila nagalaw.
    /// Ang mutable na paghiram ng `RefCell` habang ang sanggunian na ibinalik ng pamamaraang ito ay buhay ay hindi natukoy na pag-uugali.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // KALIGTASAN: Sinusuri namin na walang sinuman ang aktibong sumusulat ngayon, ngunit ito talaga
            // responsibilidad ng tumatawag na tiyakin na walang nagsusulat hanggang sa mabalik ang sanggunian ay hindi na ginagamit.
            // Gayundin, `self.value.get()` ay tumutukoy sa ang halaga ng pag-aari ng `self` at sa gayon ay garantisadong na may-bisa para sa buhay ng `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Kinukuha ang balot na halaga, naiwan ang `Default::default()` sa lugar nito.
    ///
    /// # Panics
    ///
    /// Panics kung ang halaga ay kasalukuyang hiniram.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics kung ang halaga ay kasalukuyang nababagabag na hiniram.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Lumilikha ng isang `RefCell<T>`, na may halagang `Default` para sa T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics kung ang halaga sa alinman sa `RefCell` ay kasalukuyang hiniram.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics kung ang halaga sa alinman sa `RefCell` ay kasalukuyang hiniram.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics kung ang halaga sa alinman sa `RefCell` ay kasalukuyang hiniram.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics kung ang halaga sa alinman sa `RefCell` ay kasalukuyang hiniram.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics kung ang halaga sa alinman sa `RefCell` ay kasalukuyang hiniram.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics kung ang halaga sa alinman sa `RefCell` ay kasalukuyang hiniram.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics kung ang halaga sa alinman sa `RefCell` ay kasalukuyang hiniram.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Ang pagdaragdag ng paghiram ay maaaring magresulta sa isang hindi nabasang halaga (<=0) sa mga kasong ito:
            // 1. Ito ay <0, ibig sabihin, may isinusulat ay humihiram, kaya hindi namin maaaring payagan ang isang read humiram dahil sa reference aliasing patakaran ni Rust
            // 2.
            // Ito ay isize::MAX (ang max na halaga ng pagbabasa ay humihiram) at ito overflowed sa isize::MIN (ang max na halaga ng pagsulat ay humihiram) kaya hindi namin maaaring payagan ang isang karagdagang read humiram dahil hindi isize maaari kumakatawan napakaraming read humihiram (ito ay maaari lamang mangyari kung ikaw mem::forget higit pa sa isang maliit na pare-pareho na halaga ng `Ref`s, na kung saan ay hindi magandang kasanayan)
            //
            //
            //
            //
            None
        } else {
            // Ang pagdaragdag ng paghiram ay maaaring magresulta sa isang halaga ng pagbabasa (> 0) sa mga kasong ito:
            // 1. Ito ay=0, hindi ibig sabihin, ito ay hiniram, at kami ay paglalaan ng unang nabasa na humiram
            // 2. Ito ay> 0 at <isize::MAX, ibig sabihin
            // may mga nabasa ay humihiram, at isize ay malaki sapat na upang kumatawan sa pagkakaroon ng isa pang nabasa na humiram
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Dahil umiiral ang Ref na ito, alam namin na ang flag ng pag-utang ay isang pagbabayad na hiram.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Maiwasan ang humiram counter mula sa umaapaw sa writing humiram.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Balot ng isang hiniram na sanggunian sa isang halaga sa isang kahon na `RefCell`.
/// Ang isang i-type ang wrapper para sa isang immutably hiniram na halaga mula sa isang `RefCell<T>`.
///
/// Tingnan ang [module-level documentation](self) para sa higit pa.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kinokopya ang isang `Ref`.
    ///
    /// Ang `RefCell` ay hindi na nababago nanghiram, kaya't hindi ito mabibigo.
    ///
    /// Ito ay isang nauugnay na pag-andar na kailangang magamit bilang `Ref::clone(...)`.
    /// A `Clone` pagpapatupad o isang paraan ay makagambala sa ang lakit paggamit ng `r.borrow().clone()` upang mai-clone ang mga nilalaman ng isang `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Gagawa ng isang bagong `Ref` para sa isang bahagi ng hiniram na data.
    ///
    /// Ang `RefCell` ay hindi na nababago nanghiram, kaya't hindi ito mabibigo.
    ///
    /// Ito ay isang nauugnay na pag-andar na kailangang magamit bilang `Ref::map(...)`.
    /// Isang paraan ay makagambala sa mga paraan ng ang parehong pangalan sa mga nilalaman ng isang `RefCell` ginagamit sa pamamagitan `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Gumagawa ng isang bagong `Ref` para sa isang opsyonal na bahagi ng hiniram na data.
    /// Ang orihinal na bantay ay ibabalik bilang isang `Err(..)` kung ang pagsasara ay ibabalik `None`.
    ///
    /// Ang `RefCell` ay hindi na nababago nanghiram, kaya't hindi ito mabibigo.
    ///
    /// Ito ay isang nauugnay na pag-andar na kailangang magamit bilang `Ref::filter_map(...)`.
    /// Isang paraan ay makagambala sa mga paraan ng ang parehong pangalan sa mga nilalaman ng isang `RefCell` ginagamit sa pamamagitan `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Hinahati ang isang `Ref` sa maraming `Ref`s para sa iba't ibang mga bahagi ng hiniram na data.
    ///
    /// Ang `RefCell` ay hindi na nababago nanghiram, kaya't hindi ito mabibigo.
    ///
    /// Ito ay isang kaugnay na pag-andar na kailangan upang magamit bilang `Ref::map_split(...)`.
    /// Isang paraan ay makagambala sa mga paraan ng ang parehong pangalan sa mga nilalaman ng isang `RefCell` ginagamit sa pamamagitan `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Mag-convert sa isang sanggunian sa pinagbabatayan ng data.
    ///
    /// Ang pinagbabatayan ng `RefCell` ay hindi maaaring palitan ng utang muli at palaging lilitaw na hindi nabago ang paghiram.
    ///
    /// Hindi magandang ideya na tumagas nang higit pa sa isang pare-pareho na bilang ng mga sanggunian.
    /// Ang `RefCell` ay maaaring walang pagbabago na hiniram muli kung ang isang maliit na bilang ng mga paglabas lamang ang naganap sa kabuuan.
    ///
    /// Ito ay isang nauugnay na pag-andar na kailangang magamit bilang `Ref::leak(...)`.
    /// Isang paraan ay makagambala sa mga paraan ng ang parehong pangalan sa mga nilalaman ng isang `RefCell` ginagamit sa pamamagitan `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Sa pamamagitan ng forgetting ito Ref namin matiyak na ang humiram counter sa RefCell ay hindi maaaring bumalik sa UNUSED loob ng lifetime `'b`.
        // Ang pag-reset sa estado ng pagsubaybay sa sanggunian ay mangangailangan ng isang natatanging sanggunian sa hiniram na RefCell.
        // Walang karagdagang nabago na mga sanggunian ang maaaring malikha mula sa orihinal na cell.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Gagawa ng isang bagong `RefMut` para sa isang bahagi ng hiniram na data, halimbawa, ang isang enum variant.
    ///
    /// Ang `RefCell` ay maaaring nangutang nang utang, kaya't hindi ito mabibigo.
    ///
    /// Ito ay isang nauugnay na pag-andar na kailangang magamit bilang `RefMut::map(...)`.
    /// Isang paraan ay makagambala sa mga paraan ng ang parehong pangalan sa mga nilalaman ng isang `RefCell` ginagamit sa pamamagitan `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): ayusin ang utang-tseke
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Gumagawa ng isang bagong `RefMut` para sa isang opsyonal na bahagi ng hiniram na data.
    /// Ang orihinal na bantay ay ibabalik bilang isang `Err(..)` kung ang pagsasara ay ibabalik `None`.
    ///
    /// Ang `RefCell` ay maaaring nangutang nang utang, kaya't hindi ito mabibigo.
    ///
    /// Ito ay isang nauugnay na pag-andar na kailangang magamit bilang `RefMut::filter_map(...)`.
    /// Isang paraan ay makagambala sa mga paraan ng ang parehong pangalan sa mga nilalaman ng isang `RefCell` ginagamit sa pamamagitan `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): ayusin ang utang-tseke
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // KALIGTASAN: function na humahawak papunta sa isang eksklusibong reference para sa tagal
        // ng tawag nito sa pamamagitan ng `orig`, at ang pointer ay de-refer lamang sa loob ng function na tawag na hindi pinapayagan ang eksklusibong sanggunian na makatakas.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // KALIGTASAN: pareho sa itaas.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Hinahati ang isang `RefMut` sa maraming `RefMut`s para sa iba't ibang mga bahagi ng hiniram na data.
    ///
    /// Ang pinagbabatayan ng `RefCell` ay mananatiling nababagabag na hiniram hanggang sa parehong bumalik na 'RefMut`s mawalan ng saklaw.
    ///
    /// Ang `RefCell` ay maaaring nangutang nang utang, kaya't hindi ito mabibigo.
    ///
    /// Ito ay isang kaugnay na pag-andar na kailangan upang magamit bilang `RefMut::map_split(...)`.
    /// Isang paraan ay makagambala sa mga paraan ng ang parehong pangalan sa mga nilalaman ng isang `RefCell` ginagamit sa pamamagitan `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Mag-convert sa isang nababagong sanggunian sa pinagbabatayan ng data.
    ///
    /// Ang nakapailalim na `RefCell` ay hindi maaaring hiramin mula sa muli at ay palaging lilitaw na mutably hiniram, ginagawa ang ibinalik reference ang tanging sa interior.
    ///
    ///
    /// Ito ay isang nauugnay na pag-andar na kailangang magamit bilang `RefMut::leak(...)`.
    /// Isang paraan ay makagambala sa mga paraan ng ang parehong pangalan sa mga nilalaman ng isang `RefCell` ginagamit sa pamamagitan `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Sa pamamagitan ng forgetting ito BorrowRefMut namin matiyak na ang humiram counter sa RefCell ay hindi maaaring bumalik sa UNUSED loob ng lifetime `'b`.
        // Ang pag-reset sa estado ng pagsubaybay sa sanggunian ay mangangailangan ng isang natatanging sanggunian sa hiniram na RefCell.
        // Walang karagdagang mga sanggunian ang maaaring malikha mula sa orihinal na cell sa loob ng habang buhay na iyon, na ginagawa ang kasalukuyang paghiram lamang ng sanggunian para sa natitirang buong buhay.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Hindi tulad ng BorrowRefMut::clone, bago ang tinawag upang lumikha ng paunang
        // nababagabag na sanggunian, at sa gayon ay kasalukuyang walang umiiral na mga sanggunian.
        // Sa gayon, habang clone palugit ang mutable refcount, dito kami ay tahasang payagan lamang ang pagpunta mula sa UNUSED na UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // I-clone ang isang `BorrowRefMut`.
    //
    // Ito ay wasto lamang kung ang bawat `BorrowRefMut` ay ginagamit upang subaybayan ang isang nababagong sanggunian sa isang natatanging, saklaw na hindi nonoverlapping ng orihinal na bagay.
    //
    // Wala ito sa isang Clone impl upang ang code na iyon ay hindi tumawag nito nang implicit.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Pigilan ang loan counter mula sa pag-agos.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Isang uri ng pambalot para sa isang nababagabag na hiniram na halaga mula sa isang `RefCell<T>`.
///
/// Tingnan ang [module-level documentation](self) para sa higit pa.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Ang pangunahing primitive para sa panloob na kakayahang magbago sa Rust.
///
/// Kung mayroon kang isang sanggunian `&T`, pagkatapos ay normal sa Rust nagsasagawa ang tagatala ng mga pag-optimize batay sa kaalaman na ang `&T` ay tumuturo sa hindi mababago na data.Ang pag-mutate ng data na iyon, halimbawa sa pamamagitan ng isang alias o sa pamamagitan ng paglilipat ng isang `&T` sa isang `&mut T`, ay itinuturing na hindi natukoy na pag-uugali.
/// `UnsafeCell<T>` opt-out ng walang katiyakan na garantiya para sa `&T`: isang nakabahaging sanggunian na `&UnsafeCell<T>` ay maaaring magturo sa data na na-mutate.Tinawag itong "interior mutability".
///
/// Lahat ng iba pang mga uri na nagbibigay-daan panloob na mutability, tulad ng `Cell<T>` at `RefCell<T>`, panloob gamitin `UnsafeCell` balutin ang kanilang data.
///
/// Tandaan na ang walang katiyakan lamang na garantiya para sa mga nakabahaging sanggunian ay apektado ng `UnsafeCell`.Ang katangiang natatangi para sa mga nababagong sanggunian ay hindi naapektuhan.Walang *walang* ligal na paraan upang makakuha ng aliasing `&mut`, kahit na sa `UnsafeCell<T>`.
///
/// Ang `UnsafeCell` API mismo ay technically napaka-simple: binibigyan ka ng [`.get()`] ng isang hilaw na pointer `*mut T` sa mga nilalaman nito.Hanggang sa _you_ bilang ang taga-disenyo ng abstraction na magamit nang tama ang hilaw na pointer.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Ang tumpak na mga patakaran ng aliasing Rust ay medyo nasa pagkilos ng bagay, ngunit ang mga pangunahing punto ay hindi pagtatalo:
///
/// - Kung lumikha ka ng isang ligtas na reference na may lifetime `'a` (alinman sa isang `&T` o `&mut T` reference) na naa-access sa pamamagitan ng ligtas na code (halimbawa, dahil ibabalik mo ito), pagkatapos ay hindi ka dapat ma-access ang data sa anumang paraan na sumasalungat na reference para sa nalalabing ng `'a`.
/// Halimbawa, nangangahulugan ito na kung kukuha ka ng `*mut T` mula sa isang `UnsafeCell<T>` at itapon ito sa isang `&T`, kung gayon ang data sa `T` ay dapat manatiling hindi nababago (modulo ang anumang data na `UnsafeCell` na matatagpuan sa loob ng `T`, siyempre) hanggang sa mag-expire ang buhay ng sanggunian na iyon.
/// Katulad nito, kung lumikha ka ng isang `&mut T` reference na inilabas sa ligtas na code, at pagkatapos mo ay dapat hindi ma-access ang data sa loob ng `UnsafeCell` hanggang na reference mawalan ng bisa.
///
/// - Sa lahat ng oras, dapat mong iwasan ang mga lahi ng data.Kung ang maraming mga thread ay may pag-access sa parehong `UnsafeCell`, kung gayon ang anumang mga pagsusulat ay dapat magkaroon ng wastong pangyayari-bago ang kaugnayan sa lahat ng iba pang mga pag-access (o gumamit ng mga atomika).
///
/// Upang matulungan ang wastong disenyo, ang mga sumusunod na senaryo ay malinaw na idineklarang ligal para sa solong-thread na code:
///
/// 1. A `&T` reference ay maaaring pinakawalan sa ligtas na code at doon ito ay maaaring co-umiiral sa iba pang mga `&T` sanggunian, nguni't hindi ng `&mut T`
///
/// 2. Ang isang sanggunian na `&mut T` ay maaaring mailabas sa ligtas na code na ibinigay ng iba pang `&mut T` o `&T` na kasama dito.Ang isang `&mut T` ay dapat palaging magiging natatangi.
///
/// Tandaan na habang mutating ang nilalaman ng isang `&UnsafeCell<T>` (kahit na habang ang iba pang `&UnsafeCell<T>` sanggunian alias cell) ay ok (na ibinigay sa iyo na ipatupad ang itaas invariants sa ilang ibang mga paraan), ito ay pa rin hindi natukoy na pag-uugali na magkaroon ng maramihang `&mut UnsafeCell<T>` alias.
/// Iyon ay, ang `UnsafeCell` ay isang pambalot na idinisenyo upang magkaroon ng isang espesyal na pakikipag-ugnayan sa _shared_ accesses (_i.e._, sa pamamagitan ng isang sanggunian na `&UnsafeCell<_>`);walang magic kung ano pa man kapag pagharap sa _exclusive_ accesses (_e.g._, sa pamamagitan ng `&mut UnsafeCell<_>`): hindi ang cell o ang nakabalot na halaga ay maaaring naka-alyas para sa tagal ng na `&mut` humiram.
///
/// Ipinakita ito ng [`.get_mut()`] accessor, na isang _safe_ getter na magbubunga ng `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Narito ang isang halimbawa ng pagpapakita ng kung paano mahimbing mutate ang nilalaman ng isang `UnsafeCell<_>` kabila ng pagiging may maramihang mga sanggunian aliasing ang cell:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Kumuha ng maramihang/ibinahaging mga sanggunian sa parehong `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // KALIGTASAN: sa loob ng saklaw na ito walang ibang mga sanggunian sa mga nilalaman ng `x`,
///     // kaya't ang atin ay mabisang natatangi.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- Hiramin-+
///     *p1_exclusive += 27; // |
/// } // <---------- hindi maaaring lumampas sa puntong ito -------------------+
///
/// unsafe {
///     // KALIGTASAN: sa loob ng saklaw na ito ay walang inaasahan na magkaroon ng eksklusibong pag-access sa mga nilalaman ng `x`,
///     // upang maaari kaming magkaroon ng maraming mga nakabahaging pag-access nang sabay-sabay.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Ipinapakita ng sumusunod na halimbawa ang katotohanang ang eksklusibong pag-access sa isang `UnsafeCell<T>` ay nagpapahiwatig ng eksklusibong pag-access sa `T` nito:
///
/// ```rust
/// #![forbid(unsafe_code)] // may mga eksklusibong pag-access,
///                         // `UnsafeCell` ay isang transparent na no-op na pambalot, kaya hindi na kailangan para sa `unsafe` dito.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Kumuha ng isang sumulat ng libro-time-tsek natatanging pagtukoy sa `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Sa isang eksklusibong reference, maaari naming mutate ang mga nilalaman para sa libre.
/// *p_unique.get_mut() = 0;
/// // O, katumbas:
/// x = UnsafeCell::new(0);
///
/// // Kapag nagmamay-ari tayo ng halaga, maaari nating makuha ang mga nilalaman nang libre.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Bumubuo ng isang bagong halimbawa ng `UnsafeCell` na magbabalot ng tinukoy na halaga.
    ///
    ///
    /// Ang lahat ng pag-access sa panloob na halaga sa pamamagitan ng mga pamamaraan ay `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Inaalis ang halaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Nakakakuha ng isang mutable pointer sa balot na halaga.
    ///
    /// Maaari itong i-cast sa anumang uri ng pointer.
    /// Siguraduhin na ang pag-access ay natatangi (walang mga aktibong sanggunian, nababago o hindi) kapag naghahatid sa `&mut T`, at tiyakin na walang mga mutasyon o nababagabag na mga alias na nangyayari kapag naghahatid sa `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Maaari lamang naming i-cast ang pointer mula `UnsafeCell<T>` hanggang `T` dahil sa #[repr(transparent)].
        // Ito nananamantala espesyal na katayuan ni libstd, walang garantiya para sa user code na ito ay gagana sa future bersyon ng compiler!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Ibinabalik maaaring mabago ng isang reference sa ang kalakip na data.
    ///
    /// Ang tawag na ito ay nanghihiram ng `UnsafeCell` na pabagu-bago (sa compile-time) na ginagarantiyahan na nagtataglay kami ng tanging sanggunian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Nakakakuha ng isang mutable pointer sa balot na halaga.
    /// Ang pagkakaiba sa [`get`] ay ang pagpapaandar na ito ay tumatanggap ng isang hilaw na pointer, na kapaki-pakinabang upang maiwasan ang paglikha ng mga pansamantalang sanggunian.
    ///
    /// Ang resulta ay maaaring i-cast sa anumang uri ng pointer.
    /// Tiyaking natatangi ang pag-access (walang mga aktibong sanggunian, nababago o hindi) kapag naghahatid sa `&mut T`, at tiyakin na walang mga mutasyon o nababagabag na mga alias na nangyayari kapag naghahatid sa `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Ang unti-unting pagsisimula ng isang `UnsafeCell` ay nangangailangan ng `raw_get`, tulad ng pagtawag sa `get` ay mangangailangan ng paglikha ng isang sanggunian sa hindi naisinalisadong data:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Maaari lamang naming i-cast ang pointer mula `UnsafeCell<T>` hanggang `T` dahil sa #[repr(transparent)].
        // Ito nananamantala espesyal na katayuan ni libstd, walang garantiya para sa user code na ito ay gagana sa future bersyon ng compiler!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Lumilikha ng isang `UnsafeCell`, na may `Default` halaga para sa T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}