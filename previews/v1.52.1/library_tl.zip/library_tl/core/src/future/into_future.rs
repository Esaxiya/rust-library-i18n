use crate::future::Future;

/// Ang pagbabago sa isang `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Ang output na future ay makagawa sa pagkumpleto.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Kung anong uri ng future tayo ng pag-on ito sa?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Lumilikha ng future mula sa isang halaga.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}