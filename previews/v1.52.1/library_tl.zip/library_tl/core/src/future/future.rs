#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// A future ay kumakatawan sa isang asynchronous pag-compute.
///
/// Ang future ay isang halaga na maaaring hindi pa natatapos sa pag-compute.
/// Ang ganitong uri ng "asynchronous value" ginagawang posible para sa isang thread upang magpatuloy sa paggawa ng kapaki-pakinabang na mga gawa habang ito waits para sa halaga upang maging magagamit.
///
///
/// # Ang pamamaraan ng `poll`
///
/// Ang pangunahing pamamaraan ng future, `poll`,*pagtatangka* upang malutas ang future sa isang panghuling halaga.
/// Ang pamamaraang ito ay hindi hinaharangan kung ang halaga ay hindi handa.
/// Sa halip, ang kasalukuyang gawain ay naka-iskedyul na magising kung posible na gumawa ng karagdagang pag-unlad sa pamamagitan ng `botohan ulit.
/// Ang `context` na naipasa sa `poll` na pamamaraan ay maaaring magbigay ng isang [`Waker`], na kung saan ay isang hawakan para sa paggising sa kasalukuyang gawain.
///
/// Kapag gumagamit ng future, ikaw sa pangkalahatan ay hindi tumawag `poll` direkta, ngunit sa halip `.await` ang halaga.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Ang uri ng halagang ginawa sa pagkumpleto.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Tangkaing lutasin ang future sa isang pangwakas na halaga, hindi nagrerehistro ang kasalukuyang gawain para sa wakeup kung ang halaga ay hindi pa magagamit.
    ///
    /// # Halaga ng pagbabalik
    ///
    /// Ang pagpapaandar na nagbabalik:
    ///
    /// - [`Poll::Pending`] kung ang future Hindi pa handa
    /// - [`Poll::Ready(val)`] sa resulta `val` ng future na kung ito ay natapos na matagumpay.
    ///
    /// Kapag natapos na ang isang future, hindi dapat muling i-`poll` ng mga kliyente.
    ///
    /// Kapag ang isang future ay hindi pa handa, ang `poll` ay nagbabalik ng `Poll::Pending` at nag-iimbak ng isang clone ng [`Waker`] na kinopya mula sa kasalukuyang [`Context`].
    /// Ang [`Waker`] na ito ay gisingin sa sandaling ang future ay maaaring gumawa ng pag-unlad.
    /// Halimbawa, ang isang future na naghihintay para sa isang socket upang maging mabasa ay tatawag sa `.clone()` sa [`Waker`] at iimbak ito.
    /// Kapag dumating ang isang senyas sa ibang lugar na nagpapahiwatig na ang socket ay nababasa, ang [`Waker::wake`] ay tinawag at ang gawain ng socket future ay nagising.
    /// Sa sandaling ang isang gawain ay woken up, dapat itong tangkaing `poll` ang future muli, na maaaring o hindi maaaring makabuo ng isang pangwakas na halaga.
    ///
    /// Tandaan na sa maraming mga tawag sa `poll`, ang [`Waker`] lamang mula sa [`Context`] na naipasa sa pinakahuling tawag ay dapat na naka-iskedyul upang makatanggap ng isang paggising.
    ///
    /// # Mga katangian ng Runtime
    ///
    /// Ang Futures lamang ang *inert*;dapat silang *aktibo*`poll`ed upang sumulong, ibig sabihin na sa tuwing gigising ang kasalukuyang gawain, dapat itong aktibong muling` poll 'nakabinbin ang futures na mayroon pa itong interes.
    ///
    /// Ang `poll` function ay hindi na tinatawag na paulit-ulit sa isang masikip loop-sa halip, ito ay dapat lamang na tinatawag na kapag ang future ay nagpapahiwatig na ito ay handa na upang gumawa ng pag-unlad (sa pamamagitan ng pagtawag `wake()`).
    /// Kung ikaw ay pamilyar sa `poll(2)` o `select(2)` syscalls sa Unix ito ay nagkakahalaga ng noting na futures kadaladang *hindi* magdusa ang parehong mga problema ng "all wakeups must poll all events";mas katulad nila ang `epoll(4)`.
    ///
    /// Isang pagpapatupad ng `poll` dapat nagsusumikap upang bumalik mabilis, at hindi dapat i-block.Bumabalik na mabilis humahadlang nang hindi kinakailangan clogging up thread o loops kaganapan.
    /// Kung ito ay kilala nang mas maaga sa oras na iyon ng isang tawag sa `poll` ay maaaring end up ng pagkuha awhile, ang gawa ay dapat na offloaded sa isang thread pool (o isang bagay na katulad) upang matiyak na ang `poll` makakabalik mabilis.
    ///
    /// # Panics
    ///
    /// Sa sandaling ang isang future ay nakumpleto (ibinalik `Ready` mula `poll`), pagtawag sa kanyang `poll` method sa muli maaaring panic, i-block magpakailanman, o sanhi ng iba pang mga uri ng mga problema;ang `Future` trait ay hindi naglalagay ng mga kinakailangan sa mga epekto ng naturang tawag.
    /// Gayunpaman, dahil ang `poll` na pamamaraan ay hindi minarkahan ng `unsafe`, ang mga karaniwang tuntunin ng Rust ay nalalapat: ang mga tawag ay hindi dapat maging sanhi ng hindi natukoy na pag-uugali (memory katiwalian, maling paggamit ng mga pagpapaandar ng `unsafe`, o katulad nito), anuman ang estado ng future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}