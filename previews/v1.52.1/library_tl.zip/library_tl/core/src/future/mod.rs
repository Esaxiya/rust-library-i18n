#![stable(feature = "futures_api", since = "1.36.0")]

//! Mga walang halaga na halaga.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Ang uri na ito ay kailangan dahil:
///
/// a) Hindi maipapatupad ng mga Generator ang `for<'a, 'b> Generator<&'a mut Context<'b>>`, kaya kailangan nating pumasa sa isang hilaw na pointer (tingnan ang <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Raw mga payo at `NonNull` ay hindi `Send` o `Sync`, para na gagawing bawat solong future non-Send/Sync pati na rin, at hindi namin nais na.
///
/// Ito rin pinapasimple ang HIR pagbaba ng `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Balutin ang isang generator sa isang future.
///
/// Ang pagpapaandar na ito ay nagbabalik ng isang `GenFuture` sa ilalim, ngunit itinatago ito sa `impl Trait` upang magbigay ng mas mahusay na mga mensahe ng error (`impl Future` sa halip na `GenFuture<[closure.....]>`).
///
// Ito ay `const` upang maiwasan ang labis na mga pagkakamali pagkatapos naming makabawi mula sa `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Kami ay umaasa sa ang katunayan na async/await futures ay hindi magagalaw upang lumikha ng self-referential ay humihiram sa ang kalakip na generator.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // KALIGTASAN: Safe dahil kami !Unpin + !Drop, at ito ay lamang ng isang patlang na projection.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Ipagpatuloy ang generator, gawing `NonNull` raw pointer ang `&mut Context`.
            // Ang `.await` pagbaba ay ligtas cast na bumalik sa isang `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // KALIGTASAN: dapat igagarantiya ng tumatawag na ang `cx.0` ay isang wastong pointer
    // na tinutupad ang lahat ng mga kinakailangan para sa isang nababagong sanggunian.
    unsafe { &mut *cx.0.as_ptr().cast() }
}