use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Isang interface para sa pagharap sa asynchronous iterators.
///
/// Ito ang pangunahing stream na trait.
/// Para sa higit pa tungkol sa ang konsepto ng mga stream sa pangkalahatan, pakitingnan ang [module-level documentation].
/// Sa partikular, baka gusto mong malaman kung paano [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Ang uri ng mga item nailabas ng stream.
    type Item;

    /// Pagtatangka upang hilahin out sa susunod na halaga ng stream na ito, hindi nagrerehistro ang kasalukuyang gawain para sa wakeup kung ang halaga ay hindi pa magagamit, at bumabalik `None` kung ang stream ay ubos na.
    ///
    /// # Halaga ng pagbabalik
    ///
    /// Mayroong maraming mga posibleng halagang bumalik, bawat isa ay nagpapahiwatig ng isang natatanging estado ng stream:
    ///
    /// - `Poll::Pending` nangangahulugang ang susunod na halaga ng stream na ito ay hindi pa handa.Pagpapatupad ay tinitiyak na ang kasalukuyang gawain ay aabisuhan kapag ang susunod na halaga ay maaaring maging handa.
    ///
    /// - `Poll::Ready(Some(val))` nangangahulugan na ang stream ay matagumpay na nakagawa ng isang halaga, `val`, at maaaring makagawa ng karagdagang mga halaga sa kasunod na mga tawag sa `poll_next`.
    ///
    /// - `Poll::Ready(None)` nangangahulugang natapos na ang stream, at ang `poll_next` ay hindi na dapat tawagan muli.
    ///
    /// # Panics
    ///
    /// Kapag natapos na ang isang stream (ibinalik ang `Ready(None)` from `poll_next`), tinawag ulit ang `poll_next` na pamamaraan na maaaring panic, hadlangan magpakailanman, o maging sanhi ng iba pang mga uri ng problema; ang `Stream` trait ay hindi naglalagay ng mga kinakailangan sa mga epekto ng naturang tawag.
    ///
    /// Gayunpaman, tulad ng `poll_next` paraan ay hindi minarkahan `unsafe`, karaniwang panuntunan Rust apply: tawag ay hindi kailanman dapat maging sanhi ng hindi natukoy na pag-uugali (memory katiwalian, hindi tamang paggamit ng `unsafe` pag-andar, o mga katulad), hindi alintana ng estado stream.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Ibinabalik ang mga hangganan sa natitirang haba ng stream.
    ///
    /// Sa partikular, `size_hint()` nagbabalik ng isang tuple kung saan ang unang elemento ay ang mas mababang bound, at ang pangalawang elemento ay ang itaas na nakagapos.
    ///
    /// Ang pangalawang kalahati ng tuple na naibalik ay isang ['Pagpipilian`]`<`[`usize`]`> `.
    /// Ang isang [`None`] dito ay nangangahulugang alinman sa walang kilalang itaas na nakatali, o ang itaas na nakatali ay mas malaki kaysa sa [`usize`].
    ///
    /// # pagpapatupad ng mga tala
    ///
    /// Ito ay hindi ipapatupad na ang isang stream pagpapatupad ay magbubunga ng ipinahayag bilang ng mga elemento.Ang isang buggy stream ay maaaring magbunga ng mas mababa sa mas mababang gapos o higit pa sa itaas na hangganan ng mga elemento.
    ///
    /// `size_hint()` pangunahing inilaan upang magamit para sa mga pag-optimize tulad ng pagreserba ng puwang para sa mga elemento ng stream, ngunit hindi dapat pagkatiwalaan upang hal, alisin ang mga hangganan ng tseke sa hindi ligtas na code.
    /// Ang isang maling pagpapatupad ng `size_hint()` ay hindi dapat humantong sa mga paglabag sa kaligtasan ng memorya.
    ///
    /// Sinabi nito, ang pagpapatupad ay dapat magbigay ng isang tamang pagtatantya, sapagkat kung hindi man ito ay isang paglabag sa protocol ng trait.
    ///
    /// Ang default na pagpapatupad ay nagbabalik ng `(0,` [`Wala`]`)`na tama para sa anumang stream.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}