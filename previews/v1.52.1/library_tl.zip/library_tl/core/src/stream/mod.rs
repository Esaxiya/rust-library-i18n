//! Composable asynchronous iteration.
//!
//! Kung ang futures ay mga asynchronous na halaga, kung gayon ang mga stream ay asynchronous iterator.
//! Kung natagpuan mo ang iyong sarili na may isang hindi magkasabay na koleksyon ng ilang uri, at kinakailangan upang magsagawa ng isang operasyon sa mga elemento ng nasabing koleksyon, mabilis kang makatagpo sa 'streams'.
//! Ang mga stream ay labis na ginagamit sa idiomatikong asynchronous Rust code, kaya't nagkakahalaga ng pamilyar sa kanila.
//!
//! Bago na nagpapaliwanag higit pa, sabihin makipag-usap tungkol sa kung paano ang module na ito ay nakabalangkas:
//!
//! # Organization
//!
//! Ang module na ito ay higit sa lahat ay nakaayos ayon sa uri:
//!
//! * [Traits] ang pangunahing bahagi: ang mga traits na tumutukoy kung anong uri ng mga stream ang mayroon at kung ano ang maaari mong gawin sa kanila.Ang mga pamamaraan ng mga traits na ito ay nagkakahalaga ng paglagay ng dagdag na oras ng pag-aaral.
//! * Nagbibigay ang mga pagpapaandar ng ilang kapaki-pakinabang na paraan upang lumikha ng ilang pangunahing mga stream.
//! * Structs ay madalas na ang return uri ng iba't-ibang pamamaraan sa module na ito traits.Karaniwan mong gugustuhin na tingnan ang pamamaraan na lumilikha ng `struct`, sa halip na ang `struct` mismo.
//! Para sa karagdagang detalye tungkol sa kung bakit, tingnan ang '[Pagpapatupad ng Stream](#pagpapatupad-stream)'.
//!
//! [Traits]: #traits
//!
//! Ayan yun!Hukay tayo sa mga sapa.
//!
//! # Stream
//!
//! Ang puso at kaluluwa ng modyul na ito ay ang [`Stream`] trait.Ang core ng [`Stream`] ay ganito ang hitsura:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Hindi tulad ng `Iterator`, `Stream` gumagawa ng isang pagkakaiba sa pagitan ng mga [`poll_next`] paraan na kung saan ay ginagamit kapag ang pagpapatupad ng isang `Stream`, at isang (to-be-implemented) `next` paraan na kung saan ay ginagamit kapag ubos ng isang stream.
//!
//! Ang mga mamimili ng `Stream` ay kailangan lamang isaalang-alang ang `next`, na kung tawagin, ay nagbabalik ng isang future na magbubunga ng `Option<Stream::Item>`.
//!
//! Ang future ibinalik ng `next` magpapalabas `Some(Item)` hangga't mayroong mga elemento, at sa sandaling sila na ang lahat ay ubos na, magpapalabas `None` upang ipahiwatig na pag-ulit ay natapos na.
//! Kung naghihintay kami sa isang bagay na hindi magkasabay upang malutas, maghihintay ang future hanggang ang stream ay handa nang magbunga muli.
//!
//! Ang mga indibidwal na stream ay maaaring pumili upang ipagpatuloy ang pag-ulit, at sa gayon ang pagtawag muli sa `next` ay maaaring o hindi maaaring magtagal ay magbunga ng `Some(Item)` muli sa ilang mga punto.
//!
//! Ang buong kahulugan ng [`Stream`] ay nagsasama ng isang bilang ng iba pang mga pamamaraan pati na rin, ngunit ang mga ito ay mga default na pamamaraan, na itinayo sa tuktok ng [`poll_next`], at sa gayon makukuha mo sila nang libre.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Pagpapatupad ng Stream
//!
//! Ang paglikha ng isang stream ng iyong sarili ay nagsasangkot ng dalawang mga hakbang: paglikha ng isang `struct` upang i-hold ang estado ng stream, at pagkatapos ay ipatupad ang [`Stream`] para sa `struct` na iyon.
//!
//! Gumawa tayo ng isang stream na pinangalanang `Counter` na binibilang mula `1` hanggang `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Una, ang struct:
//!
//! /// Ang isang stream na nagbibilang mula isa hanggang limang
//! struct Counter {
//!     count: usize,
//! }
//!
//! // Gusto namin ang aming count na magsimula sa isa, kaya sabihin magdagdag ng isang new() paraan upang tulong.
//! // Ito ay hindi mahigpit na kinakailangan, ngunit ito ay maginhawa.
//! // Tandaan na sinisimulan namin ang `count` sa zero, makikita natin kung bakit sa `poll_next()`'s pagpapatupad sa ibaba.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Pagkatapos, ipinapatupad namin ang `Stream` para sa aming `Counter`:
//!
//! impl Stream for Counter {
//!     // kami ay pagbibilang sa usize
//!     type Item = usize;
//!
//!     // poll_next() ay ang tanging kinakailangang pamamaraan
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Dinagdagan aming count.Ito ay kung bakit namin nagsimula sa zero.
//!         self.count += 1;
//!
//!         // Suriin upang malaman kung natapos na namin ang pagbibilang o hindi.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! *Tamad* ang mga stream.Ito ay nangangahulugan na lamang ng paglikha ng isang stream ay hindi _do_ isang buong lot.Wala talagang nangyayari hanggang tumawag ka sa `next`.
//! Minsan ito ay isang mapagkukunan ng pagkalito kapag lumilikha lamang ng isang stream para sa mga epekto nito.
//! Babalaan tayo ng tagatala tungkol sa ganitong uri ng pag-uugali:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;