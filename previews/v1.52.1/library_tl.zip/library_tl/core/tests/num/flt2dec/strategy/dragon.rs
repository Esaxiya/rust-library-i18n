use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Masyadong mabagal si Miri
fn exact_sanity_test() {
    // Ang pagsusuring ito ay nagtatapos up sa pagtakbo kung ano ang maaari ko lamang ipagpalagay na ang ilang mga sulok-ish kaso ng pag-andar `exp2` library, na tinukoy sa kahit anong C runtime aming ginagamit.
    // Sa VS 2013 ang function na ito tila nagkaroon ng isang bug tulad ng nabigo sa pagsusulit na ito kapag naka-link, ngunit may VS 2015 ang bug ay lumilitaw maayos pati na ang mga pagsubok ay tumatakbo lamang fine.
    //
    // Ang bug ay tila isang pagkakaiba sa pagbalik ng halaga ng `exp2(-1057)`, kung saan sa VS 2013 ay nagbabalik ito ng isang dobleng may bit pattern na 0x2 at sa VS 2015 ay nagbabalik ng 0x20000.
    //
    //
    // Sa ngayon balewalain lang sa pagsusulit na ito ganap sa MSVC bilang ito ay nasubok sa ibang lugar pa rin at hindi kami ay sobrang interesado sa pagsubok ng exp2 pagpapatupad sa bawat platform.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}