use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Ito ay hindi matatag na ibabaw na lugar, ngunit tumutulong sa panatilihin `?` cheap pagitan ng mga ito, kahit na LLVM ay hindi maaaring palaging samantalahin ito ngayon.
    //
    // (Sadly Resulta at Pagpipilian ay hindi pantay-pantay, kaya ang ControlFlow ay hindi maaaring tumugma sa pareho.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}