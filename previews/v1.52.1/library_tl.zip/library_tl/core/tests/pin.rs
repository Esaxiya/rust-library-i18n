use core::pin::Pin;

#[test]
fn pin_const() {
    // subukan na ang mga pamamaraan ng `Pin` ay magagamit sa isang kont konteksto

    const POINTER: &'static usize = &2;

    const PINNED: Pin<&'static usize> = Pin::new(POINTER);
    const PINNED_UNCHECKED: Pin<&'static usize> = unsafe { Pin::new_unchecked(POINTER) };
    assert_eq!(PINNED_UNCHECKED, PINNED);

    const INNER: &'static usize = Pin::into_inner(PINNED);
    assert_eq!(INNER, POINTER);

    const INNER_UNCHECKED: &'static usize = unsafe { Pin::into_inner_unchecked(PINNED) };
    assert_eq!(INNER_UNCHECKED, POINTER);

    const REF: &'static usize = PINNED.get_ref();
    assert_eq!(REF, POINTER);

    // Note: Sinusubukan ng `pin_mut_const` na ang mga pamamaraan ng `Pin<&mut T>` ay magagamit sa isang kontekstong Const.
    // Ang isang const fn ay ginagamit dahil `&mut` ay hindi (yet) kapaki-pakinabang sa constants.
    const fn pin_mut_const() {
        let _ = Pin::new(&mut 2).into_ref();
        let _ = Pin::new(&mut 2).get_mut();
        let _ = unsafe { Pin::new(&mut 2).get_unchecked_mut() };
    }

    pin_mut_const();
}