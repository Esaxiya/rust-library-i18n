//! Isang library ng suporta para sa mga may-akda ng macro kapag tumutukoy sa mga bagong macros.
//!
//! Ang silid-aklatan na ito, na ibinigay ng pamantayan ng pamamahagi, ay nagbibigay ng mga uri na natupok sa mga interface ng napakahalagang pamaraan na tinukoy na mga kahulugan tulad ng macros na `#[proc_macro]` na tulad ng pagpapaandar, mga katangian ng macro na `#[proc_macro_attribute]` at mga katangian ng custom na derive`#[proc_macro_derive]`.
//!
//!
//! Tingnan ang [the book] para sa higit pa.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Natutukoy kung ang proc_macro ay ginawang ma-access sa kasalukuyang tumatakbo na programa.
///
/// Ang proc_macro crate ay inilaan lamang para magamit sa loob ng pagpapatupad ng mga macros na pamaraan.Ang lahat ng mga function sa ito crate panic kung tawagin mula sa labas ng isang pamamaraan macro, tulad ng mula sa isang build script o unit test o ordinaryong Rust binary.
///
/// Sa pagsasaalang-alang para sa mga library ng Rust na idinisenyo upang suportahan ang parehong mga kaso ng paggamit ng macro at hindi pang-macro, nagbibigay ang `proc_macro::is_available()` ng isang hindi panicong paraan upang makita kung ang imprastrakturang kinakailangan upang magamit ang API ng proc_macro ay kasalukuyang magagamit.
/// Ibinabalik totoo kung mahihingi mula sa loob ng isang pamamaraan macro, huwad na kung mahihingi mula sa anumang iba pang mga binary.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Ang pangunahing uri na ibinigay ng crate na ito, na kumakatawan sa isang abstract stream ng tokens, o, mas partikular, isang pagkakasunud-sunod ng mga puno ng token.
/// Ang uri ay nagbibigay ng mga interface para sa pag-ulit sa mga puno ng token at, sa kabaligtaran, pagkolekta ng bilang ng mga puno ng token sa isang stream.
///
///
/// Parehas itong pag-input at output ng mga kahulugan ng `#[proc_macro]`, `#[proc_macro_attribute]` at `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Bumalik ang error mula sa `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Ibinabalik ng isang walang laman `TokenStream` na naglalaman ng walang token puno.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Sinusuri kung ang `TokenStream` na ito ay walang laman.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Pagtatangka upang basagin ang string sa tokens at ma-parse ang mga tokens sa isang token stream.
/// Maaaring mabigo para sa isang bilang ng mga kadahilanan, halimbawa, kung ang string ay naglalaman ng hindi balanseng delimiter o character na hindi umiiral sa ang wika.
///
/// Ang lahat ng tokens sa na-parse stream ay nakakakuha ng `Span::call_site()` spans.
///
/// NOTE: ang ilang mga error ay maaaring maging sanhi panics sa halip ng mga bumabalik na `LexError`.Taglay namin ang karapatan upang baguhin ang mga error na ito sa `LexError`s mamaya.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, ang tulay ay nagbibigay lamang ng `to_string`, ipatupad ang `fmt::Display` batay dito (ang pabaliktad ng karaniwang ugnayan sa pagitan ng dalawa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Nai-print ang token stream bilang isang string na dapat ay lossless maiibabalik sa parehong token stream (modulo spans), maliban sa posibleng `TokenTree: : Group`s na may `Delimiter::None` delimiters at negatibong numeric literals.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Kopya token sa isang form na maginhawa para sa pag-debug.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Lumilikha ng isang token stream na naglalaman ng isang solong token na puno.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Nangongolekta ng isang bilang ng mga token mga puno sa isang solong stream.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Ang isang operasyon ng "flattening" sa mga stream ng token, kinokolekta ang mga puno ng token mula sa maraming mga token na stream sa isang solong stream.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Gumamit ng isang na-optimize na pagpapatupad if/when posible.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Mga detalye ng pagpapatupad ng publiko para sa uri ng `TokenStream`, tulad ng mga iterator.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Isang iterator sa `TokenTree`s ng`TokenStream`.
    /// pag-ulit ay "shallow", hal, ang iterator ay hindi recurse sa delimited group, at babalik buong grupo bilang token puno.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` tumatanggap ng di-makatwirang tokens at lumalawak sa isang `TokenStream` na naglalarawan ng input.
/// Halimbawa, `quote!(a + b)` gagawa ng pagpapahayag, na, kapag sinuri, constructs ang `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Ang pag-quote ay tapos na sa `$`, at gumagana sa pamamagitan ng pagkuha ng solong susunod na ident bilang hindi tinukoy na term.
/// Upang mai-quote ang `$` mismo, gamitin ang `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Isang rehiyon ng source code, kasama ang impormasyon ng paglawak ng macro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Lumilikha ng isang bagong `Diagnostic` na may ibinigay na `message` sa span `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Isang span na nalulutas sa site ng kahulugan ng macro.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Ang haba ng panawagan ng kasalukuyang pamaraan na makro.
    /// Tagapagpakilala nilikha na may span na ito ay dapat lutasin na kung sila ay nakasulat nang direkta sa macro lokasyon call (call-site kalinisan) at iba pang code na ito sa macro call site ay maaaring sumangguni sa mga ito pati na rin.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Ang isang span na kumakatawan `macro_rules` kalinisan, at kung minsan ay lumulutas sa macro kahulugan site (lokal na mga variable, mga label, `$crate`) at kung minsan ay sa macro call site (lahat ng iba pa).
    ///
    /// Ang lokasyon ng span ay kinuha mula sa call-site.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Ang orihinal na file ng pinagmulan kung saan tumuturo ang span na ito.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// Ang `Span` para sa tokens sa nakaraang paglawak ng macro mula sa kung saan ang `self` ay nabuo mula, kung mayroon man.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Ang span para sa pinagmulan ng source code kung saan nilikha ang `self`.
    /// Kung ang `Span` na ito ay hindi nabuo mula sa iba pang mga macro expansions pagkatapos ang halaga ng pagbabalik ay kapareho ng `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Nakukuha ang panimulang line/column sa pinagmulang file para sa span na ito.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Nakukuha ang nagtatapos na line/column sa pinagmulang file para sa span na ito.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Lumilikha ng isang bagong span na sumasaklaw sa `self` at `other`.
    ///
    /// Ibinabalik `None` kung `self` at `other` ay mula sa iba't ibang mga file.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Lumilikha ng isang bagong span na may parehong impormasyon line/column bilang `self` ngunit na lutasin ang mga simbolo na parang ito ay sa `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Lumilikha ng isang bagong span na may parehong pag-uugali name resolution bilang `self` ngunit may impormasyon na line/column ng `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Naghahambing sa mga sumasaklaw upang makita kung pantay ang mga ito.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Ibinabalik ang pinagmulang teksto sa likod ng isang span.
    /// Ito ay nagpapanatili ng orihinal na source code, kabilang ang mga espasyo at mga komento.
    /// Ito ay nagbabalik lamang ng isang resulta kung ang span ay tumutugon sa tunay na source code.
    ///
    /// Note: Ang kapansin-pansin na resulta ng isang macro dapat lamang umasa sa tokens at hindi sa source na ito ng teksto.
    ///
    /// Ang resulta ng pagpapaandar na ito ay isang pinakamahusay na pagsisikap na magagamit para sa mga diagnostic lamang.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Nagpi-print ng isang span sa isang form na maginhawa para sa pag-debug.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Isang line-hanay pares na kumakatawan sa simula o dulo ng isang `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Ang linya na 1-index sa pinagmulang file kung saan nagsisimula o nagtatapos ang span ng (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Ang 0-index na haligi (sa UTF-8 character) sa pinagmulang file kung saan nagsisimula o nagtatapos ang span ng (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Ang source file ng isang naibigay na `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Nakukuha ang landas sa pinagmulang file na ito.
    ///
    /// ### Note
    /// Kung ang span ng code na nauugnay sa `SourceFile` na ito ay nabuo ng isang panlabas na macro, ang macro na ito, maaaring hindi ito isang aktwal na landas sa filesystem.
    /// Gumamit ng [`is_real`] upang suriin.
    ///
    /// Gayundin tandaan na kahit na `is_real` nagbabalik `true`, kung `--remap-path-prefix` naipasa sa command line, ang landas na ibinigay ay maaaring hindi tunay na magiging balido.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Ibinabalik `true` kung ito source file ay isang tunay na source file, at hindi nabuo sa pamamagitan ng pagpapalawak ng isang panlabas na macro ni.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Ito ay isang hack hanggang intercrate tagal ay ipinapatupad at maaari naming magkaroon ng tunay na source file para sa tagal na nabuo sa panlabas na macros.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Ang nag-iisang token o isang delimited pagkakasunod-sunod ng token puno (eg, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Isang token stream na napapaligiran ng mga bracket delimiter.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Ang isang identifier.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Ang nag-iisang punctuation character (`+`, `,`, `$`, atbp).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Ang isang literal na character (`'a'`), string (`"hello"`), numero (`2.3`), etc.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Ibinabalik ang span ng punong ito, delegasyon sa `span` paraan ng nakapaloob token o isang delimited stream.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// I-configure ang span para sa *lamang sa token* na ito.
    ///
    /// Tandaan na kung ang token na ito ay isang `Group` kung gayon ang pamamaraang ito ay hindi mai-configure ang span ng bawat isa sa panloob na tokens, idedelegate lamang nito ang `set_span` na pamamaraan ng bawat variant.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Kopya token puno sa isang form na maginhawa para sa pag-debug.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ang bawat isa sa mga may pangalan sa uri struct sa nagmula debug, kaya huwag mag-abala na may extrang layer ng kawalang-tapat
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, ang tulay ay nagbibigay lamang ng `to_string`, ipatupad ang `fmt::Display` batay dito (ang pabaliktad ng karaniwang ugnayan sa pagitan ng dalawa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Nagpi-print ng puno ng token bilang isang string na dapat ay lossless na mapapalitan pabalik sa parehong puno ng token (modulo spans), maliban sa posibleng `TokenTree: : Group`s na may `Delimiter::None` delimiters at negatibong numeric literals.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Isang nilimitahan na stream ng token.
///
/// A `Group` panloob ay naglalaman ng isang `TokenStream` na napapalibutan ng `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Naglalarawan kung paano ang isang pagkakasunod-sunod ng token puno ay delimited.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Ang isang implicit delimiter, upang, halimbawa, lalabas sa paligid tokens nagmumula sa isang "macro variable" `$var`.
    /// Mahalaga na mapanatili ang mga prayoridad ng operator sa mga kaso tulad ng `$var * 3` kung saan `$var` ay `1 + 2`.
    /// Ang mga implicit na delimiter ay maaaring hindi makaligtas sa pag-ikot ng isang token stream sa pamamagitan ng isang string.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Lumilikha ng isang bagong `Group` na may ibinigay na delimiter at token stream.
    ///
    /// constructor na ito ay magse-set ang span para sa pangkat na ito sa `Span::call_site()`.
    /// Upang baguhin ang span maaari mong gamitin ang `set_span` na pamamaraan sa ibaba.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Ibinabalik ang delimiter ng `Group` na ito
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Ibinabalik ang `TokenStream` ng tokens na nalimitahan sa `Group` na ito.
    ///
    /// Tandaan na ang naibalik na token stream ay hindi kasama ang delimiter na ibinalik sa itaas.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Ibinabalik ang span para sa mga delimiter ng token stream na ito, na sumasaklaw sa buong `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ibinabalik ang span na tumuturo sa ang pagbubukas delimiter ng grupong ito.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Ibinabalik ang span tumuturo sa pagsasara delimiter ng grupong ito.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Kino-configure ang span para sa `ni Group` delimiter, ngunit hindi ang panloob na tokens.
    ///
    /// Ang pamamaraang ito ay hindi ** itatakda ang span ng lahat ng panloob na tokens na na-spaced ng pangkat na ito, ngunit sa halip ay itatakda lamang nito ang span ng delimiter tokens sa antas ng `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, ang tulay ay nagbibigay lamang ng `to_string`, ipatupad ang `fmt::Display` batay dito (ang pabaliktad ng karaniwang ugnayan sa pagitan ng dalawa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Kopya sa pangkat bilang isang string na dapat ay losslessly convertible pabalik sa parehong grupo (modulo tagal), maliban para sa posibleng `TokenTree: : Group`s na may `Delimiter::None` delimiter.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// Ang `Punct` ay isang solong character na bantas tulad ng `+`, `-` o `#`.
///
/// Multi-character operator tulad `+=` ay kinakatawan bilang dalawang mga pagkakataon ng `Punct` na may iba't ibang mga paraan ng `Spacing` ibinalik.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Kung ang isang `Punct` ay sinusundan kaagad ng isa pang `Punct` o sinusundan ng isa pang token o whitespace.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// hal, ang `+` ay `Alone` sa `+ =`, `+ident` o `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// eg, `+` ay `Joint` in `+=` o `'#`.
    /// Bilang karagdagan, ang solong quote na `'` ay maaaring sumali sa mga identifier upang mabuo ang mga habang buhay na `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Lumilikha ng isang bagong `Punct` mula sa ibinigay na character at spacing.
    /// Ang `ch` argument Dapat na wastong bantas karakter pinahintulutan ng wika, kung hindi man ang pag-andar ay panic.
    ///
    /// Ang ibinalik `Punct` ay magkakaroon ng default span ng `Span::call_site()` na kung saan ay maaaring karagdagang naka sa `set_span` pamamaraan sa ibaba.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Ibinabalik ang halaga ng character na bantas na ito bilang `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Ibinabalik ang spacing ng bantas karakter, nagpapahiwatig kung agad na ito ay sinundan sa pamamagitan ng isa pang `Punct` sa token stream, upang maaari nilang potensyal na pinagsama sa isang multi-character operator (`Joint`), o ito ay sinundan sa pamamagitan ng ilang mga iba pang mga token o whitespace (`Alone`) kaya ang operator ay may tiyak na natapos.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Ibinabalik ang span para sa punctuation character.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// I-configure ang span para sa character na bantas na ito.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ang tulay ay nagbibigay lamang ng `to_string`, ipatupad ang `fmt::Display` batay dito (ang pabaliktad ng karaniwang ugnayan sa pagitan ng dalawa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Pini-print ang bantas na character tulad ng isang string na dapat ay losslessly convertible pabalik sa parehong karakter.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Isang identifier (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Lumilikha ng isang bagong `Ident` na may ibinigay na `string` pati na rin ang tinukoy na `span`.
    /// Ang `string` argument Dapat na wastong identifier pinahihintulutan ng mga wika (kabilang ang mga keyword, hal `self` o `fn`).Sa kabilang banda, ang function ay panic.
    ///
    /// Tandaan na `span`, kasalukuyang nasa rustc, Kino-configure ang impormasyon na kalinisan para identifier na ito.
    ///
    /// Tulad ng oras na ito X malinaw na malinaw na nag-opt-in sa "call-site" na kalinisan na nangangahulugang ang mga tagakilala na nilikha gamit ang span na ito ay malulutas na parang nakasulat nang direkta sa lokasyon ng macro call, at ang iba pang code sa site ng macro call ay maaaring mag-refer. sila rin.
    ///
    ///
    /// Sa paglaon ang mga spans tulad ng `Span::def_site()` ay magpapahintulot na mag-opt-in sa "definition-site" hygiene na nangangahulugang ang mga identifier na nilikha gamit ang span na ito ay malulutas sa lokasyon ng kahulugan ng macro at ang iba pang code sa macro call site ay hindi makakapag-refer sa kanila.
    ///
    /// Dahil sa ang kasalukuyang kahalagahan ng kalinisan na ito constructor, hindi tulad ng iba pang mga tokens, ay nangangailangan ng isang `Span` na tinukoy sa construction.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Kapareho ng `Ident::new`, ngunit lumilikha ng isang raw identifier (`r#ident`).
    /// Ang `string` argument maging isang wastong identifier pinahihintulutan ng mga wika (kabilang ang mga keyword, hal `fn`).
    /// Mga keyword na magagamit sa mga segment ng path (hal
    /// `self`, `Super`) ay hindi suportado, at maging sanhi ng isang panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Ibinabalik ang span ng `Ident` na ito, na sumasaklaw sa buong string na ibinalik ng [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// I-configure ang span ng `Ident` na ito, posibleng baguhin ang konteksto ng kalinisan nito.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ang tulay ay nagbibigay lamang ng `to_string`, ipatupad ang `fmt::Display` batay dito (ang pabaliktad ng karaniwang ugnayan sa pagitan ng dalawa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Pini-print ang identifier bilang isang string na dapat ay losslessly convertible pabalik sa parehong identifier.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Isang literal na string (`"hello"`), byte string (`b"hello"`), character (`'a'`), byte character (`b'a'`), isang integer o lumulutang point number na mayroon o walang isang panlapi (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Boolean literals tulad `true` at `false` ay hindi nabibilang dito, ang mga ito `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Lumilikha ng isang bagong suffixed integer na literal na may tinukoy na halaga.
        ///
        /// Function na ito ay lumikha ng isang integer tulad `1u32` kung saan ang mga halaga ng integer na tinukoy ay ang unang bahagi ng token at ang integral ay suffixed din sa dulo.
        /// Ang mga literal na nilikha mula sa mga negatibong numero ay maaaring hindi makaligtas sa mga pag-ikot sa pamamagitan ng `TokenStream` o mga string at maaaring masira sa dalawang tokens (`-` at positibong literal).
        ///
        ///
        /// Literals nilikha sa pamamagitan ng ang paraan na ito ay may `Span::call_site()` span pamamagitan ng default, kung saan maaaring i-configure sa `set_span` pamamaraan sa ibaba.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Lumilikha ng isang bagong unsuffixed integer literal sa tinukoy na halaga.
        ///
        /// Ang pagpapaandar na ito ay lilikha ng isang integer tulad ng `1` kung saan ang tinukoy na halaga ng integer ay ang unang bahagi ng token.
        /// Walang suffix ay tinukoy na ito token, ibig sabihin na invocation tulad `Literal::i8_unsuffixed(1)` ay katumbas ng `Literal::u32_unsuffixed(1)`.
        /// Ang mga literal na nilikha mula sa mga negatibong numero ay maaaring hindi makaligtas sa mga rountrips sa pamamagitan ng `TokenStream` o mga string at maaaring masira sa dalawang tokens (`-` at positibong literal).
        ///
        ///
        /// Literals nilikha sa pamamagitan ng ang paraan na ito ay may `Span::call_site()` span pamamagitan ng default, kung saan maaaring i-configure sa `set_span` pamamaraan sa ibaba.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Lumilikha ng isang bagong unsuffixed lumulutang-point na literal.
    ///
    /// constructor na ito ay katulad ng sa mga tulad `Literal::i8_unsuffixed` kung saan ang halaga ng float ni ay ibinubuga nang direkta sa token ngunit walang suffix ay ginagamit, kaya maaari itong natukoy na maging isang `f64` mamaya sa compiler.
    ///
    /// Ang mga literal na nilikha mula sa mga negatibong numero ay maaaring hindi makaligtas sa mga rountrips sa pamamagitan ng `TokenStream` o mga string at maaaring masira sa dalawang tokens (`-` at positibong literal).
    ///
    /// # Panics
    ///
    /// function na ito ay nangangailangan na ang mga tinukoy na float ay may hangganan, halimbawa kung ito ay infinity o NaN function na ito ay panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Lumilikha ng isang bagong suffixed lumulutang-point na literal.
    ///
    /// constructor Lilikha ito ng isang literal na tulad `1.0f32` kung saan ang mga tinukoy na halaga ay ang naunang bahagi ng token at `f32` ay ang suffix ng token.
    /// Ito token ay palaging natukoy na maging isang `f32` sa compiler.
    /// Ang mga literal na nilikha mula sa mga negatibong numero ay maaaring hindi makaligtas sa mga rountrips sa pamamagitan ng `TokenStream` o mga string at maaaring masira sa dalawang tokens (`-` at positibong literal).
    ///
    ///
    /// # Panics
    ///
    /// function na ito ay nangangailangan na ang mga tinukoy na float ay may hangganan, halimbawa kung ito ay infinity o NaN function na ito ay panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Lumilikha ng isang bagong unsuffixed lumulutang-point na literal.
    ///
    /// constructor na ito ay katulad ng sa mga tulad `Literal::i8_unsuffixed` kung saan ang halaga ng float ni ay ibinubuga nang direkta sa token ngunit walang suffix ay ginagamit, kaya maaari itong natukoy na maging isang `f64` mamaya sa compiler.
    ///
    /// Ang mga literal na nilikha mula sa mga negatibong numero ay maaaring hindi makaligtas sa mga rountrips sa pamamagitan ng `TokenStream` o mga string at maaaring masira sa dalawang tokens (`-` at positibong literal).
    ///
    /// # Panics
    ///
    /// function na ito ay nangangailangan na ang mga tinukoy na float ay may hangganan, halimbawa kung ito ay infinity o NaN function na ito ay panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Lumilikha ng isang bagong suffixed lumulutang-point na literal.
    ///
    /// constructor Lilikha ito ng isang literal na tulad `1.0f64` kung saan ang mga tinukoy na halaga ay ang naunang bahagi ng token at `f64` ay ang suffix ng token.
    /// Ito token ay palaging natukoy na maging isang `f64` sa compiler.
    /// Ang mga literal na nilikha mula sa mga negatibong numero ay maaaring hindi makaligtas sa mga rountrips sa pamamagitan ng `TokenStream` o mga string at maaaring masira sa dalawang tokens (`-` at positibong literal).
    ///
    ///
    /// # Panics
    ///
    /// function na ito ay nangangailangan na ang mga tinukoy na float ay may hangganan, halimbawa kung ito ay infinity o NaN function na ito ay panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Literal na string.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Literal na character.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Literal na byte ng string.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Ibinabalik ang span encompassing ang literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// I-configure ang span na nauugnay para sa literal na ito.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Ibinabalik ng `Span` iyon ay isang subset ng `self.span()` na naglalaman lamang ang source bytes sa hanay `range`.
    /// Ibinabalik `None` kung ang gagawin-trim span ay nasa labas ng hangganan ng `self`.
    ///
    // FIXME(SergioBenitez): suriin na ang saklaw ng byte ay nagsisimula at nagtatapos sa isang UTF-8 na hangganan ng pinagmulan.
    // sa kabilang banda, ito ay malamang na ang isang panic ay magaganap sa ibang lugar kapag ang pinagmulang teksto ay ipi-print.
    // FIXME(SergioBenitez): walang paraan para sa gumagamit na malaman kung ano ang `self.span()` aktwal na mga mapa sa, kaya ang paraan na ito ay maaaring kasalukuyan lamang tatawaging walang taros.
    // Halimbawa, `to_string()` para sa mga karakter 'c' nagbabalik "'\u{63}'";walang paraan para sa gumagamit na malaman kung ang source text ay 'c' o kung ito ay '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) isang bagay na katulad sa `Option::cloned`, ngunit para sa `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, ang tulay ay nagbibigay lamang ng `to_string`, ipatupad ang `fmt::Display` batay dito (ang pabaliktad ng karaniwang ugnayan sa pagitan ng dalawa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// I-print ang literal bilang isang string na dapat na lossless maibabalik pabalik sa parehong literal (maliban sa posibleng pag-ikot para sa mga lumulutang point literals).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Sinusubaybayang pag-access sa mga variable ng kapaligiran.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Kunin ang isang variable ng kapaligiran at idagdag ito upang mabuo ang impormasyon sa pagtitiwala.
    /// Ang Build system na nagpapatupad ng tagatala ay malalaman na ang variable ay na-access sa panahon ng pagtitipon, at magagawang muli ang pagbuo kapag nagbago ang halaga ng variable na iyon.
    ///
    /// Bukod sa mga dependency sa pagsubaybay function na ito ay dapat na katumbas ng `env::var` mula sa standard library, maliban na ang argument ay dapat na UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}