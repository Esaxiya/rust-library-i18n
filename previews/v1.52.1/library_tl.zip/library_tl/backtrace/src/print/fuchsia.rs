use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // Ang dl_iterate_phdr ay tumatagal ng isang callback na makakatanggap ng isang dl_phdr_info pointer para sa bawat DSO na na-link sa proseso.
    // Tinitiyak din ng dl_iterate_phdr na ang Dynamic na linker ay naka-lock mula simula hanggang katapusan ng pag-ulit.
    // Kung ang callback ay nagbabalik ng isang hindi-zero na halaga ang pag-ulit ay natapos nang maaga.
    // 'data' ipapasa bilang pangatlong argument sa callback sa bawat tawag.
    // 'size' nagbibigay ng laki ng dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Kailangan naming i-parse ang build ID at ilang pangunahing data ng header ng programa na nangangahulugang kailangan namin ng kaunting bagay mula sa spec ng ELF din.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Ngayon kami ay may sa magtiklop, bit para sa bit, ang istraktura ng dl_phdr_info i-type ang ginagamit ng ni fuchsia kasalukuyang dynamic linker.
// Chromium ay mayroon ding ito ABI hangganan pati na rin crashpad.
// Sa kalaunan nais naming ilipat ang mga kasong ito upang magamit ang paghahanap sa duwende ngunit kailangan naming ibigay iyon sa SDK at hindi pa nagagawa iyon.
//
// Sa gayon kami (at sila) ay natigil na kinakailangang gamitin ang pamamaraang ito na nagkakaroon ng isang masikip na pagkabit sa fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Mayroon kaming walang paraan ng alam ng pagsusuri kung e_phoff at e_phnum ay may-bisa.
    // libc dapat tiyakin ito para sa amin subalit kaya't ligtas na bumuo ng isang hiwa dito.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Ang Elf_Phdr ay kumakatawan sa isang 64-bit na ELF na header ng programa sa endianness ng target na arkitektura.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Kinakatawan ng Phdr ang isang wastong header ng programa ng ELF at ang mga nilalaman nito.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Wala kaming paraan upang suriin kung ang p_addr o p_memsz ay wasto.
    // ni Fuchsia libc Pina-parse ang mga tala unang gayunpaman ito sa pamamagitan ng kabanalan ng pagiging dito ang mga header ay kailangang may bisa.
    //
    // Ang NoteIter ay hindi nangangailangan ng napapailalim na data upang maging wasto ngunit nangangailangan ito ng mga hangganan upang maging wasto.
    // Nagtitiwala kami na tinitiyak ng libc na ito ang kaso para sa amin dito.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Ang uri ng tala para sa mga build ID.
const NT_GNU_BUILD_ID: u32 = 3;

// Ang Elf_Nhdr ay kumakatawan sa isang header ng tala ng ELF sa pagtatapos ng target.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Kinakatawan ng tala ang isang tala ng ELF (header + mga nilalaman).
// Ang pangalan ay naiwan bilang isang u8 slice dahil hindi ito laging null natapos at ginagawang madali ng rust upang suriin na ang mga byte ay tumutugma alinman.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// Hinahayaan ka ng NoteIter na ligtas na umulit sa isang segment ng tala.
// Nagtatapos ito sa lalong madaling mangyari ang isang error o wala nang mga tala.
// Kung paulit-ulitin mo ang hindi wastong data ay gagana ito tulad ng walang mga tala na natagpuan.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Ito ay isang invariant ng pagpapaandar na ang pointer at laki na ibinigay ay nangangahulugang isang wastong saklaw ng mga byte na maaaring mabasa ang lahat.
    // Ang mga nilalaman ng mga byte na ito ay maaaring maging anupaman ngunit dapat saklaw ang saklaw upang ito ay ligtas.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to aligns 'x' sa 'to'-byte alignment ipagpalagay 'to' ay isang kapangyarihan ng 2.
// Sumusunod ito sa isang karaniwang pattern sa C/C ++ ELF parsing code kung saan ginagamit ang (x + to, 1) at -to.
// Hindi ka pinapayagan ng Rust na tanggihan ang usize kaya gumagamit ako
// Ang 2-komplementong conversion upang muling likhain iyon.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 nang-uubos num bytes mula sa slice (kung mayroon man) at Bukod pa rito ay nagsisigurado na ang huling slice ay properlly hile-hilera.
// Kung ang alinman sa bilang ng mga byte hiniling ay masyadong malaki o sa paghati hindi maaaring realigned pagkatapos dahil sa hindi sapat na natitirang bytes umiiral, Wala ay ibinalik at ang slice ay hindi nabago.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Ang pagpapaandar na ito ay walang tunay na mga invariant na dapat tumaguyod ang tumatawag maliban sa marahil na ang 'bytes' ay dapat na nakahanay para sa pagganap (at sa ilang mga pagkaayos ng arkitektura).
// Ang mga halaga sa mga patlang na Elf_Nhdr ay maaaring walang katuturan ngunit tinitiyak ng pagpapaandar na ito ang walang ganoong bagay.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Ito ay ligtas hangga't mayroong sapat na puwang at nakumpirma lamang namin na sa kung pahayag sa itaas kaya hindi ito dapat maging ligtas.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Tandaan na sice_of: :<Elf_Nhdr>Ang () ay laging nakahanay sa 4-byte.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Suriin kung naabot na natin ang dulo.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Nagpapadala kami ng isang nhdr ngunit maingat naming isinasaalang-alang ang nagresultang struct.
        // Hindi namin pinagkakatiwalaan ang namesz o descsz at hindi kami gumagawa ng hindi ligtas na mga desisyon batay sa uri.
        //
        // Kaya't kahit makalabas tayo ng kumpletong basura dapat pa rin tayong ligtas.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Ipinapahiwatig na ang isang segment ay maipapatupad.
const PERM_X: u32 = 0b00000001;
/// Ipinapahiwatig na ang isang segment ay nasusulat.
const PERM_W: u32 = 0b00000010;
/// Ipinapahiwatig na ang isang segment ay nababasa.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Kinakatawan ang isang segment ng ELF sa runtime.
struct Segment {
    /// Ibinibigay ang runtime virtual address ng mga nilalaman ng segment na ito.
    addr: usize,
    /// Binibigyan ang laki ng memorya ng mga nilalaman ng segment na ito.
    size: usize,
    /// Binibigyan ang module ng virtual address ng segment na ito gamit ang ELF file.
    mod_rel_addr: usize,
    /// Nagbibigay ng mga pahintulot na matatagpuan sa ELF file.
    /// Ang mga pahintulot na ito ay hindi kinakailangang mga pahintulot na naroroon sa runtime subalit.
    flags: Perm,
}

/// Nagbibigay-daan sa isa umulit sa paglipas ng Segment mula sa isang DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Kumakatawan sa isang ELF DSO (Dynamic Shared Object).
/// Ang uri na ito ay tumutukoy sa data na nakaimbak sa aktwal na DSO sa halip na gumawa ng sarili nitong kopya.
struct Dso<'a> {
    /// Laging binibigyan kami ng Dynamic na linker ng isang pangalan, kahit na walang laman ang pangalan.
    /// Sa kaso ng pangunahing maipapatupad ang pangalan na ito ay walang laman.
    /// Sa kaso ng isang nakabahaging bagay na ito ay magiging soname (tingnan ang DT_SONAME).
    name: &'a str,
    /// Sa Fuchsia halos lahat binaries may build ID ngunit ito ay hindi isang mahigpit na requierment.
    /// Walang paraan upang maitugma ang impormasyon ng DSO sa isang tunay na file ng ELF pagkatapos kung walang build_id kaya hinihiling namin na ang bawat DSO ay mayroong isa rito.
    ///
    /// Ang DSO na walang build_id ay hindi pinapansin.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Ay nagbabalik ng isang iterator sa paglipas ng Segment sa DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Ang mga error na i-encode ang mga isyu na lumabas dahil habang pina-parse impormasyon tungkol sa bawat DSO.
///
enum Error {
    /// NameError ay nangangahulugan na may naganap na error habang nagko-convert ng C style string sa isang rust string.
    ///
    NameError(core::str::Utf8Error),
    /// Ang ibig sabihin ng BuildIDError ay hindi kami nakakita ng isang build ID.
    /// Maaaring ito ay dahil sa walang build ID ang DSO o dahil ang segment na naglalaman ng build ID ay hindi maganda ang form.
    ///
    BuildIDError,
}

/// Ang mga tawag sa alinman sa 'dso' o 'error' para sa bawat DSO na naka-link sa proseso sa pamamagitan ng pabago-bagong linker.
///
///
/// # Arguments
///
/// * `visitor` - Ang isang DsoPrinter na magkakaroon ng isa sa mga pamamaraang kumakain na tinatawag na precach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // Tinitiyak ng dl_iterate_phdr na ang info.name ay magtuturo sa isang wastong lokasyon.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Ang pagpapaandar na ito ay naglilimbag ng marka ng simbolo ng Fuchsia para sa lahat ng impormasyon na nilalaman sa isang DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}