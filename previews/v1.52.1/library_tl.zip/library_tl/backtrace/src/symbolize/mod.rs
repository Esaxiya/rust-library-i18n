use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Lutasin ang isang address sa isang simbolo, ipapasa ang simbolo sa tinukoy na pagsasara.
///
/// Hahanapin ng pagpapaandar na ito ang ibinigay na address sa mga lugar tulad ng lokal na talahanayan ng simbolo, talahanayan ng pabagu-bago ng simbolo, o impormasyon sa pag-debug ng DWARF (depende sa pinapagana na pagpapatupad) upang makahanap ng mga simbolo na magbubunga.
///
///
/// Ang pagsasara ay maaaring hindi tawagan kung hindi maisagawa ang resolusyon, at maaari rin itong tawaging higit sa isang beses sa kaso ng mga naka-linya na pagpapaandar.
///
/// Ang mga simbolong ibinigay ay kumakatawan sa pagpapatupad sa tinukoy na `addr`, na binabalik ang mga pares ng file/line para sa address na iyon (kung magagamit).
///
/// Tandaan na kung mayroon kang isang `Frame` pagkatapos ito ay inirerekomenda na gamitin ang `resolve_frame` function sa halip ng isang ito.
///
/// # Mga kinakailangang tampok
///
/// Ang pagpapaandar na ito ay nangangailangan ng tampok na `std` ng `backtrace` crate upang paganahin, at ang tampok na `std` ay pinagana bilang default.
///
/// # Panics
///
/// Ang pagpapaandar na ito strives upang hindi panic, ngunit kung ang `cb` ibinigay panics pagkatapos ay ang ilang mga platform ay puwersahin ang isang double panic upang iurong ang proseso.
/// Ang ilang mga platform ay gumagamit ng isang C library na kung saan panloob ay gumagamit ng mga callback na hindi matatanggal, kaya't ang pag-panic mula sa `cb` ay maaaring magpalitaw ng proseso.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // tumingin lamang sa tuktok na frame
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Lutasin ang dati nang nakakuha ng frame sa isang simbolo, na ipinapasa ang simbolo sa tinukoy na pagsasara.
///
/// Gumagawa ang funcin na ito ng parehong pag-andar tulad ng `resolve` maliban sa tumatagal ng `Frame` bilang isang argument sa halip na isang address.
/// Maaari nitong payagan ang ilang pagpapatupad ng platform ng backtracing upang magbigay ng mas tumpak na impormasyon ng simbolo o impormasyon tungkol sa mga inline na frame halimbawa.
///
/// Ito ay inirerekumenda na gumamit ito kung maaari mong.
///
/// # Mga kinakailangang tampok
///
/// Ang pagpapaandar na ito ay nangangailangan ng tampok na `std` ng `backtrace` crate upang paganahin, at ang tampok na `std` ay pinagana bilang default.
///
/// # Panics
///
/// Ang pagpapaandar na ito strives upang hindi panic, ngunit kung ang `cb` ibinigay panics pagkatapos ay ang ilang mga platform ay puwersahin ang isang double panic upang iurong ang proseso.
/// Ang ilang mga platform ay gumagamit ng isang C library na kung saan panloob ay gumagamit ng mga callback na hindi matatanggal, kaya't ang pag-panic mula sa `cb` ay maaaring magpalitaw ng proseso.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // tumingin lamang sa tuktok na frame
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP halaga mula stack frame ay karaniwang (always?) ang pagtuturo *pagkatapos* ang tawag iyon ang aktwal na stack trace.
// Ang pagsisimbolo nito sa sanhi ng filename/line na numero upang maging isa sa unahan at marahil sa walang bisa kung malapit na ito sa pagtatapos ng pagpapaandar.
//
// Ito lumilitaw na isa lamang palagi ang kaso sa lahat ng platform, kaya lagi naming bawasan ng isa mula sa isang nalutas ip upang malutas ito sa naunang tawag pagtuturo sa halip na ang pagtuturo na ibabalik sa.
//
//
// Mainam na hindi namin ito gagawin.
// Perpektong kakailanganin namin ang mga tumatawag ng `resolve` API dito upang manu-manong gawin ang -1 at account na nais nila ang impormasyon ng lokasyon para sa *nakaraang* tagubilin, hindi ang kasalukuyang.
// Mainam na ilantad din namin ang `Frame` kung kami talaga ang address ng susunod na tagubilin o ang kasalukuyang.
//
// Sa ngayon kahit na ito ay isang magandang pag-aalala sa angkop na lugar kaya't panloob lamang kaming palaging nagbabawas ng isa.
// Ang mga mamimili ay dapat na patuloy na gumana at makakuha ng magagandang mga resulta, kaya dapat tayo ay sapat na mahusay.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Kapareho ng `resolve`, hindi ligtas lamang dahil hindi ito na-synchronize.
///
/// Ang pagpapaandar na ito ay walang mga garantiyang pagsabay ngunit magagamit kapag ang tampok na `std` ng crate na ito ay hindi naipon.
/// Tingnan ang `resolve` pag-andar para sa karagdagang babasahin at mga halimbawa.
///
/// # Panics
///
/// Tingnan ang impormasyon sa `resolve` para sa mga pag-uusap sa `cb` pagpapanic.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Kapareho ng `resolve_frame`, hindi ligtas lamang dahil hindi ito na-synchronize.
///
/// Ang pagpapaandar na ito ay walang mga garantiyang pagsabay ngunit magagamit kapag ang tampok na `std` ng crate na ito ay hindi naipon.
/// Tingnan ang pagpapaandar ng `resolve_frame` para sa mas maraming dokumentasyon at mga halimbawa.
///
/// # Panics
///
/// Tingnan ang impormasyon sa `resolve_frame` para sa mga pag-uusap sa `cb` pagpapanic.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Isang trait na kumakatawan sa resolusyon ng isang simbolo sa isang file.
///
/// Ang trait na ito ay ibinibigay bilang isang trait na bagay sa pagsara na ibinigay sa pagpapaandar ng `backtrace::resolve`, at ito ay halos naipadala dahil hindi alam kung aling pagpapatupad ang nasa likod nito.
///
///
/// Ang isang simbolo ay maaaring magbigay ng impormasyong pangkontekstwal tungkol sa isang pagpapaandar, halimbawa ang pangalan, filename, numero ng linya, tumpak na address, atbp.
/// Hindi lahat ng impormasyon ay palaging magagamit sa isang simbolo, gayunpaman, kaya't ang lahat ng mga pamamaraan ay nagbabalik ng isang `Option`.
///
///
pub struct Symbol {
    // TODO: ang panghabang buhay na ito ay kailangang mapilit sa kalaunan hanggang sa `Symbol`,
    // ngunit ito ay kasalukuyang isang nagbabagong pagbabago.
    // Sa ngayon ito ay ligtas dahil ang `Symbol` ay maiabot lamang sa pamamagitan ng sanggunian at hindi ma-clone.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Ibinabalik ang pangalan ng pagpapaandar na ito.
    ///
    /// Nagbalik ang istraktura ay maaaring gamitin upang i-query iba't-ibang mga katangian ng tungkol sa mga pangalan ng simbolo:
    ///
    ///
    /// * Ang pagpapatupad ng `Display` ay mai-print ang nawawalang simbolo.
    /// * Maaaring ma-access ang hilaw na halagang `str` ng simbolo (kung ito ay wastong utf-8).
    /// * Maaaring ma-access ang mga raw byte para sa pangalan ng simbolo.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Ibinabalik ang panimulang address ng pagpapaandar na ito.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Ibinabalik ang hilaw na filename bilang isang slice.
    /// Pangunahing kapaki-pakinabang ito para sa mga kapaligiran sa `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Ibinabalik ang numero ng haligi kung saan kasalukuyang nagsasagawa ang simbolong ito.
    ///
    /// Ang gimli lamang ang kasalukuyang nagbibigay ng isang halaga dito at kahit na pagkatapos lamang kung ibalik ng `filename` ang `Some`, at sa gayon ito ay dahil dito napapailalim sa mga katulad na pag-uusap.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Ibinabalik ang numero ng linya kung saan kasalukuyang nagsasagawa ang simbolong ito.
    ///
    /// Ang halagang pagbabalik na ito ay karaniwang `Some` kung ang `filename` ay nagbabalik ng `Some`, at dahil dito ay napapailalim sa mga katulad na pag-uusap.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Ibinabalik ang pangalan ng file kung saan tinukoy ang pagpapaandar na ito.
    ///
    /// Kasalukuyang magagamit lamang ito kapag ginagamit ang libbacktrace o gimli (hal
    /// unix iba pang mga platform) at kapag ang isang binary ay naipon sa debuginfo.
    /// Kung alinman sa mga kondisyong ito ay hindi natutugunan malamang na ibalik nito ang `None`.
    ///
    /// # Mga kinakailangang tampok
    ///
    /// Ang pagpapaandar na ito ay nangangailangan ng tampok na `std` ng `backtrace` crate upang paganahin, at ang tampok na `std` ay pinagana bilang default.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Siguro isang parse C++ simbolo, kung pag-parse ang luray na simbolo tulad ng Nabigo Rust.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Tiyaking panatilihin ang zero-size na ito, upang ang tampok na `cpp_demangle` ay walang gastos kapag hindi pinagana.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Ang isang wrapper sa paligid ng isang pangalan ng simbolo upang magbigay ng ergonomic accessors sa demangled pangalan, ang mga raw bytes, ang mga raw na string, at iba pa
///
// Payagan ang patay na code kung kailan hindi pinagana ang tampok na `cpp_demangle`.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Lumilikha ng isang bagong pangalan ng simbolo mula sa hilaw na pinagbabatayan ng mga byte.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Ibinabalik ang raw na simbolo ng (mangled) bilang isang `str` kung ang simbolo ay wastong utf-8.
    ///
    /// Gamitin ang mga `Display` pagpapatupad kung nais mo ang demangled bersyon.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Ibinabalik ang raw simbolong pangalan bilang isang listahan ng mga bytes
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Maaari itong mai-print kung ang simbolo ng nabagbag na kalagayan ay hindi wasto, kaya hawakan ang error dito nang kaaya-aya sa pamamagitan ng hindi pagpapalabas nito sa labas.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Tinangkang bawiin ang naka-cache na memorya na ginamit upang sumagisag sa mga address.
///
/// Susubukan ng pamamaraang ito na palabasin ang anumang mga istruktura ng pandaigdigang data na kung hindi man ay na-cache sa buong mundo o sa thread na karaniwang kumakatawan sa na-parse na impormasyon ng DWARF o katulad.
///
///
/// # Caveats
///
/// Habang ang pagpapaandar na ito ay palaging magagamit hindi talaga ito gumagawa ng anumang bagay sa karamihan ng mga pagpapatupad.
/// Ang mga aklatan tulad ng dbghelp o libbacktrace ay hindi nagbibigay ng mga pasilidad upang makitungo sa estado at pamahalaan ang inilaang memorya.
/// Sa ngayon ang tampok na `gimli-symbolize` ng crate na ito ay ang tanging tampok kung saan ang pagpapaandar na ito ay may anumang epekto.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}