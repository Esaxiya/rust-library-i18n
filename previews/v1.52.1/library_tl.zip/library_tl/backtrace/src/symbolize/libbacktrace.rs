//! Diskarte sa simbolo gamit ang DWARF-parsing code sa libbacktrace.
//!
//! Ang libbacktrace C library, karaniwang ipinamamahagi sa gcc, sumusuporta hindi lamang pagbuo ng isang backtrace (na kung saan hindi namin talagang gamitin) ngunit din symbolicating ang backtrace at paghawak ng dwarf debug impormasyon tungkol sa mga bagay tulad ng inlined frame at watnat.
//!
//!
//! Ito ay medyo kumplikado dahil sa maraming iba't ibang mga alalahanin dito, ngunit ang pangunahing ideya ay:
//!
//! * Tumawag muna kami sa `backtrace_syminfo`.Nakakakuha ito ng impormasyon ng simbolo mula sa talahanayan ng pabagu-bago ng simbolo kung maaari namin.
//! * Susunod na tawagan namin ang `backtrace_pcinfo`.Ito ay i-parse debuginfo mesa kung sila ay magagamit at daan sa amin upang mabawi ang impormasyon tungkol sa mga inline frames, filename, linya numero, at iba pa
//!
//! May maraming ng panlilinlang tungkol sa pagkuha ng dwarf talahanayan sa libbacktrace, ngunit inaasahan namin na ito ay hindi ang katapusan ng mundo at malinaw na sapat na kapag ang pagbabasa sa ibaba.
//!
//! Ito ang default na diskarte ng pagsasagisag para sa mga hindi MSVC at hindi OSX platform.Sa libstd bagaman ito ang default na diskarte para sa OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Kung maaari mas gusto ang `function` na pangalan na nagmula sa debuginfo at maaaring karaniwang mas tumpak para sa mga inline frame halimbawa.
                // Kung iyon wala kahit pagkahulog pabalik sa ang pangalan table ng simbolo na tinukoy sa `symname`.
                //
                // Tandaan na kung minsan ang `function` ay maaaring makaramdam ng medyo hindi gaanong tumpak, halimbawa nakalista bilang `try<i32,closure>` isntead ng `std::panicking::try::do_call`.
                //
                // Hindi talaga malinaw kung bakit, ngunit sa pangkalahatan ang pangalan ng `function` ay tila mas tumpak.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // huwag gumawa ng kahit ano sa ngayon
}

/// Ang uri ng `data` pointer na ipinasa sa `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Kapag ang callback na ito ay naimbitahan mula sa `backtrace_syminfo` kapag nagsimula kaming malutas ay lumalayo pa kami upang tumawag sa `backtrace_pcinfo`.
    // Ang pagpapaandar ng `backtrace_pcinfo` ay kumunsulta sa impormasyon ng pag-debug at susubukang gawin ang mga bagay tulad ng mabawi ang impormasyon ng file/line pati na rin ang mga naka-linya na mga frame.
    // Tandaan na ang `backtrace_pcinfo` ay maaaring mabigo o hindi magagawa nang malaki kung walang impormasyon sa pag-debug, kaya kung mangyari ito sigurado kaming tatawagin ang callback na may hindi bababa sa isang simbolo mula sa `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Ang uri ng `data` pointer na ipinasa sa `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Sinusuportahan ng libbacktrace API ang paglikha ng isang estado, ngunit hindi nito sinusuportahan ang pagsira sa isang estado.
// Personal kong tinukoy ito na nangangahulugang ang isang estado ay inilaan upang malikha at pagkatapos ay mabuhay magpakailanman.
//
// Gusto kong magrehistro ng isang at_exit() handler na linisin ang estado na ito, ngunit ang libbacktrace ay hindi nagbibigay ng paraan upang magawa ito.
//
// Sa mga hadlang na ito, ang pagpapaandar na ito ay may isang statically naka-cache na estado na kinakalkula sa unang pagkakataon na ito ay hiniling.
//
// Tandaan na ang pag-backtraced sa lahat ay nangyayari nang serally (isang pandaigdigang lock).
//
// Tandaan ang kakulangan ng pagsabay dito ay dahil sa kinakailangan na ang `resolve` ay panlabas na na-synchronize.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Huwag mag-ehersisyo ang mga kakayahan ng threadsafe ng libbacktrace dahil palagi namin itong tinatawagan sa isang naka-synchronize na paraan.
        //
        0,
        error_cb,
        ptr::null_mut(), // walang dagdag na data
    );

    return STATE;

    // Tandaan na para sa libbacktrace upang gumana sa lahat ng kailangan nito upang mahanap ang bulilit debug impormasyon para sa kasalukuyang executable.Karaniwan itong ginagawa nito sa pamamagitan ng isang bilang ng mga mekanismo kabilang ang, ngunit hindi limitado sa:
    //
    // * /proc/self/exe sa mga suportadong platform
    // * Malinaw na naipasa ang filename kapag lumilikha ng estado
    //
    // Ang libbacktrace library ay isang malaking wad ng C code.Ito ay natural na nangangahulugang mayroon itong mga kahinaan sa kaligtasan ng memorya, lalo na kapag paghawak ng hindi wastong debuginfo.
    // Ang Libstd ay napunta sa maraming mga makasaysayang ito.
    //
    // Kung ang /proc/self/exe ay ginamit sa gayon maaari naming karaniwang balewalain ang mga ito dahil ipinapalagay namin na ang libbacktrace ay "mostly correct" at kung hindi man ay hindi gumagawa ng mga kakatwang bagay sa "attempted to be correct" dwarf debug info.
    //
    //
    // Kung pumasa kami sa isang filename, gayunpaman, pagkatapos ito ay posible sa ilang mga platform (tulad ng BSDs) kung saan ang isang nakakahamak na aktor ay maaaring maging sanhi ng isang arbitrary file upang mailagay sa lokasyong iyon.
    // Nangangahulugan ito na kung sasabihin namin sa libbacktrace tungkol sa isang filename maaaring gumagamit ito ng isang di-makatwirang file, posibleng maging sanhi ng mga segfault.
    // Kung hindi namin sasabihin ang libbacktrace kahit ano hindi ito gagawa ng anumang bagay sa mga platform na hindi sumusuporta sa mga landas tulad ng /proc/self/exe!
    //
    // Given ang lahat na subukan namin bilang mahirap hangga't maaari sa *hindi* pass sa isang filename, ngunit kailangan naming sa mga platform na hindi sumusuporta sa /proc/self/exe sa lahat.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Tandaan na perpektong gagamitin namin ang `std::env::current_exe`, ngunit hindi namin maaaring mangailangan ng `std` dito.
            //
            // Gumamit ng `_NSGetExecutablePath` upang mai-load ang kasalukuyang maipapatupad na landas sa isang static na lugar (na kung ito ay napakaliit ay susuko lamang).
            //
            //
            // Tandaan na seryoso kaming nagtitiwala sa libbacktrace dito upang hindi mamatay sa mga tiwaling maipatupad, ngunit tiyak na ito ay ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ay may isang mode ng pagbubukas ng mga file kung saan pagkatapos mabuksan ay hindi ito matatanggal.
            // Na sa pangkalahatan kung ano ang gusto namin dito dahil gusto naming matiyak na ang aming mga maipapatupad na ay hindi nagbabago out mula sa ilalim ng sa amin pagkatapos naming ipasa ito off sa libbacktrace, sana nagpapagaan ng kakayahan upang pumasa sa di-makatwirang data sa libbacktrace (na kung saan ay maaaring mishandled).
            //
            //
            // Dahil sa ginagawa namin ang isang maliit na sayaw dito upang subukang makakuha ng isang uri ng lock sa aming sariling imahe:
            //
            // * Kumuha ng hawakan sa kasalukuyang proseso, i-load ang filename nito.
            // * Magbukas ng isang file sa filename na iyon gamit ang tamang mga watawat.
            // * Reload filename ang kasalukuyang proseso, nang nakakatiyak ito ay ang parehong
            //
            // Kung ang lahat ng mga pumasa namin sa teorya ay talagang binuksan ang file ng aming proseso at garantisado kaming hindi ito magbabago.Ang isang grupo ng FWIW na ito ay nakopya mula sa makasaysayang libstd, kaya't ito ang aking pinakamahusay na interpretasyon sa nangyayari.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Nakatira ito sa static memory upang maibalik natin ito ..
                static mut BUF: [i8; N] = [0; N];
                // ... at nakatira ito sa stack dahil pansamantala ito
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // sinadya na mahayag ang `handle` dito dahil ang pagkakaroon ng bukas na iyon ay dapat mapanatili ang aming lock sa pangalan ng file na ito.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Nais naming ibalik ang isang hiwa na natapos na sa nul, kaya kung ang lahat ay napunan at katumbas nito ng kabuuang haba pagkatapos ay ihambing ito sa kabiguan.
                //
                //
                // Kung hindi man sa pagbabalik ng tagumpay siguraduhin na ang nul byte ay kasama sa hiwa.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // backtrace mga error ay kasalukuyan swept sa ilalim ng alpombra
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Tumawag sa `backtrace_syminfo` API kung saan (mula sa pagbabasa ng code) dapat tawagan ang `syminfo_cb` nang eksakto isang beses (o mabibigo na may isang error na marahil).
    // Pagkatapos ay hinahawakan namin ang higit pa sa loob ng `syminfo_cb`.
    //
    // Tandaan na ginagawa namin ito dahil ang `syminfo` ay kumunsulta sa talahanayan ng simbolo, sa paghahanap ng mga pangalan ng simbolo kahit na walang impormasyon ng pag-debug sa binary.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}