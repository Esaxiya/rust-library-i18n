// ginamit lamang sa Linux ngayon, kaya payagan ang patay na code sa ibang lugar
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Isang simpleng tagapaglaan ng arena para sa mga byte buffer.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Naglalaan ng isang buffer ng tinukoy na laki at nagbabalik ng isang nababagabag na sanggunian dito.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // KALIGTASAN: ito lamang ang pag-andar na kailanman na bumubuo ng isang nababagabag
        // sumangguni sa `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // KALIGTASAN: hindi namin kailanman tinanggal ang mga elemento mula sa `self.buffers`, kaya isang sanggunian
        // sa data sa loob ng anumang buffer ay mabubuhay hangga't ginagawa ng `self`.
        &mut buffers[i]
    }
}