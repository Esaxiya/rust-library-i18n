use core::ffi::c_void;
use core::fmt;

/// Sinusuri ang kasalukuyang call-stack, na ipinapasa ang lahat ng mga aktibong frame sa pagsasara na ibinigay upang makalkula ang isang stack trace.
///
/// Ang pagpapaandar na ito ay ang workhorse ng library na ito sa pagkalkula ng mga bakas ng stack para sa isang programa.Ang ibinigay na pagsasara `cb` ay binibigyan ng mga pagkakataon ng isang `Frame` na kumakatawan sa impormasyon tungkol sa call frame na iyon sa stack.
/// Ang pagsasara ay ibinibigay na mga frame sa isang nangungunang pababang fashion (na pinakabagong tinawag na mga pag-andar muna).
///
/// Ang halaga ng pagbabalik ng pagsara ay isang pahiwatig kung dapat magpatuloy ang backtrace.Ang isang pagbalik na halaga ng `false` ay magwawakas ng backtrace at babalik kaagad.
///
/// Sa sandaling ang isang `Frame` ay nakuha ikaw ay malamang na nais na tumawag `backtrace::resolve` i-convert ang `ip` (pagtuturo pointer) o simbolo address sa isang `Symbol` kung saan ang pangalan at/o filename/numero ng linya ay maaaring natutunan.
///
///
/// Tandaan na ito ay isang relatibong mababang antas ng pag-andar at kung nais mong, halimbawa, makuha ang isang backtrace na siniyasat sa ibang pagkakataon, at pagkatapos ay ang uri `Backtrace` maaaring maging mas angkop.
///
/// # Mga kinakailangang tampok
///
/// Ang pagpapaandar na ito ay nangangailangan ng tampok na `std` ng `backtrace` crate upang paganahin, at ang tampok na `std` ay pinagana bilang default.
///
/// # Panics
///
/// Ang pagpapaandar na ito strives upang hindi panic, ngunit kung ang `cb` ibinigay panics pagkatapos ay ang ilang mga platform ay puwersahin ang isang double panic upang iurong ang proseso.
/// Ang ilang mga platform ay gumagamit ng isang C library na kung saan panloob ay gumagamit ng mga callback na hindi matatanggal, kaya't ang pag-panic mula sa `cb` ay maaaring magpalitaw ng proseso.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // ipagpatuloy ang backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Kapareho ng `trace`, hindi ligtas lamang dahil hindi ito na-synchronize.
///
/// Ang pagpapaandar na ito ay walang mga garantiyang pagsabay ngunit magagamit kapag ang tampok na `std` ng crate na ito ay hindi naipon.
/// Tingnan ang pagpapaandar ng `trace` para sa mas maraming dokumentasyon at mga halimbawa.
///
/// # Panics
///
/// Tingnan ang impormasyon sa `trace` para sa mga pag-uusap sa `cb` pagpapanic.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// A trait na kumakatawan sa isang frame ng isang backtrace, yielded sa `trace` pag-andar ng mga ito crate.
///
/// Ang pagsasara ng pag-andar ng pagsubaybay ay bibigyan ng mga frame, at ang frame ay halos naipadala dahil ang napapailalim na pagpapatupad ay hindi laging kilala hanggang sa runtime.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Ibinabalik ang kasalukuyang pointer ng tagubilin ng frame na ito.
    ///
    /// Karaniwan ito ang susunod na tagubilin upang maipatupad sa frame, ngunit hindi lahat ng pagpapatupad ay nakalista ito na may katumpakan na 100% (ngunit sa pangkalahatan ay medyo malapit ito).
    ///
    ///
    /// Inirerekumenda na ipasa ang halagang ito sa `backtrace::resolve` upang gawin itong isang pangalan ng simbolo.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Ibinabalik ang kasalukuyang stack pointer ng frame na ito.
    ///
    /// Sa kaso na ang isang backend ay hindi maaaring mabawi ang mga stack pointer para sa frame, ang isang null pointer ay ibinalik.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Ibinabalik ang panimulang simbolo ng address ng frame ng pagpapaandar na ito.
    ///
    /// Susubukan nitong mag-rewind ng pagtuturo puntero ibinalik ng `ip` sa simula ng pag-andar, mga bumabalik na halaga.
    ///
    /// Gayunpaman, sa ilang mga kaso, ibabalik lamang ng mga backend ang `ip` mula sa pagpapaandar na ito.
    ///
    /// Ang naibalik na halaga ay maaaring magamit minsan kung ang `backtrace::resolve` ay nabigo sa `ip` na ibinigay sa itaas.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Ibinabalik ang base address ng module na kinabibilangan ng frame.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Kailangan itong mauna, upang matiyak na mas inuuna ang Miri kaysa sa host platform
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // ginamit lamang sa simbolo ng dbghelp
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}