# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Isang silid-aklatan para sa pagkuha ng mga backtrace sa runtime para sa Rust.
Nilalayon ng silid-aklatan na mapahusay ang suporta ng karaniwang silid-aklatan sa pamamagitan ng pagbibigay ng isang programmatic na interface upang gumana, ngunit sinusuportahan din nito ang madaling pag-print ng kasalukuyang backtrace tulad ng libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Upang makunan lamang ang isang backtrace at ipagpaliban ang pagharap dito hanggang sa ibang oras, maaari mong gamitin ang pang-itaas na antas na `Backtrace`.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Kung, gayunpaman, nais mo ng karagdagang raw pag-access sa ang aktwal na pag-andar guhit sa sinag, maaari mong gamitin ang `trace` at `resolve` function direkta.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Lutasin ang tagubilin na ito sa isang pangalan ng simbolo
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // magpatuloy sa susunod na frame
    });
}
```

# License

Ang proyektong ito ay lisensyado sa ilalim ng alinman sa

 * Apache Lisensya, Bersyon 2.0, ([LICENSE-APACHE](LICENSE-APACHE) o http://www.apache.org/licenses/LICENSE-2.0)
 * Lisensya ng MIT ([LICENSE-MIT](LICENSE-MIT) o http://opensource.org/licenses/MIT)

sa pagpipilian mo.

### Contribution

Maliban kung malinaw mong sinabi kung hindi man, ang anumang kontribusyon na sadyang isinumite para sa pagsasama sa backtrace-rs mo, na tinukoy sa lisensya ng Apache-2.0, ay dapat na dalawahan na may lisensya sa itaas, nang walang anumang karagdagang mga tuntunin o kundisyon.







