use backtrace::Backtrace;

// Gumagawa lamang ang pagsubok na ito sa mga platform na mayroong gumaganang `symbol_address` function para sa mga frame na nag-uulat ng panimulang address ng isang simbolo.
// Bilang isang resulta ito ay pinagana lamang sa ilang mga platform.
//
const ENABLED: bool = cfg!(all(
    // Windows hindi pa talaga nasubukan, at hindi sinusuportahan ng OSX ang tunay na paghahanap ng isang nakapaloob na frame, kaya huwag paganahin ito
    //
    target_os = "linux",
    // Sa paghahanap ng ARM ng enclosing function ay ibabalik lamang ang ip mismo.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}