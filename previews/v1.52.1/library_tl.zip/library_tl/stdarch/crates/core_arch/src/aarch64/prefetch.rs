#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// Tingnan ang [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_READ: i32 = 0;

/// Tingnan ang [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_WRITE: i32 = 1;

/// Tingnan ang [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// Tingnan ang [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// Tingnan ang [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// Tingnan ang [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// Kunin ang linya ng cache na naglalaman ng address `p` gamit ang ibinigay na `rw` at `locality`.
///
/// Ang `rw` ay dapat na isa sa:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): ang prefetch ay naghahanda para sa isang nabasa.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): ang prefetch ay naghahanda para sa isang write.
///
/// Ang `locality` ay dapat na isa sa:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): Pag-streaming o di-temporal na prefetch, para sa data na ginagamit lamang nang isang beses.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): Fetch sa antas ng 3 cache.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): Fetch sa antas ng 2 cache.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): Fetch sa antas ng 1 cache.
///
/// Ang mga tagubilin sa prefetch memory signal sa sistema ng memorya na memory accesses mula sa isang tinukoy na address ay malamang na mangyari sa malapit na future.
/// Ang memory system ay maaaring tumugon sa pamamagitan ng pagkuha aksyon na ay inaasahang upang mapabilis ang memory access kapag ito ay mangyari, tulad ng preloading tinukoy na address sa isa o higit pang mga cache.
///
/// Dahil ang mga signal na ito ay pahiwatig lamang, wasto para sa isang partikular na CPU na gamutin ang anuman o lahat ng mga tagubiling prefetch bilang isang NOP.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // Ginagamit namin ang `llvm.prefetch` instrinsic na may `cache type` =1 (data cache).
    // `rw` at `strategy` ay batay sa mga parameter function.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}