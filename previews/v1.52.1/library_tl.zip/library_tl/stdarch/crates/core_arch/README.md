`core::arch` - Pangunahing intrinsikong tukoy sa arkitektura ng Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Ang `core::arch` module nagpapatupad architecture umaasa intrinsics (eg SIMD).

# Usage 

`core::arch` ay magagamit bilang bahagi ng `libcore` at ito ay muling inilabas sa pamamagitan `libstd`.Mas gusto ang paggamit nito sa pamamagitan ng `core::arch` o `std::arch` sa pamamagitan ng ito crate.
Ang mga hindi matatag na tampok ay madalas na magagamit sa gabi-gabi Rust sa pamamagitan ng `feature(stdsimd)`.

Ang paggamit ng `core::arch` sa pamamagitan ng crate na ito ay nangangailangan ng gabi-gabing Rust, at maaari itong (at hindi) masira nang madalas.Ang mga kaso lamang kung saan dapat mong isaalang-alang ang paggamit nito sa pamamagitan ng crate na ito ay:

* kung kailangan mo na muling pag-compile `core::arch` iyong sarili, halimbawa, na may partikular na target-pinaganang mga tampok na hindi pinagana para sa `libcore`/`libstd`.
Note: kung kailangan mo na muling pag-compile ito para sa isang hindi karaniwang target, mangyaring ginusto gamit `xargo` at muling kino-compile `libcore`/`libstd` bilang naaangkop sa halip na gamitin ito crate.
  
* gamit ang ilang mga katangian na maaaring hindi available kahit sa likod hindi matatag Rust Nagtatampok.Sinusubukan naming panatilihin ang mga ito sa isang minimum.
Kung kailangan mong gumamit ng ilan sa mga tampok na ito, mangyaring buksan ang isang isyu upang mailantad namin ang mga ito sa gabi-gabi Rust at maaari mo silang magamit mula doon.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` pangunahing ipinamamahagi sa ilalim ng mga tuntunin ng parehong lisensya ng MIT at Lisensya ng Apache (Bersyon 2.0), na may mga bahagi na sakop ng iba't ibang mga lisensya na tulad ng BSD.

Tingnan ang LICENSE-APACHE, at LICENSE-MIT para sa mga detalye.

# Contribution

Maliban kung malinaw mong sinabi kung hindi man, ang anumang kontribusyon na sadyang isinumite para sa pagsasama sa iyo ng `core_arch`, na tinukoy sa lisensya ng Apache-2.0, ay dapat na doble na lisensyado tulad ng nasa itaas, nang walang anumang karagdagang mga tuntunin o kundisyon.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












