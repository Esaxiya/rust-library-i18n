# Nag-aambag sa stdarch

Ang `stdarch` crate ay higit pa sa handang tumanggap ng mga kontribusyon!Una marahil ay nais mong suriin ang repository at tiyaking pumasa ang mga pagsubok para sa iyo:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Saan `<your-target-arch>` ay ang target na triple tulad ng ginagamit ng `rustup`, hal `x86_x64-unknown-linux-gnu` (nang walang anumang naunang `nightly-` o katulad).
Tandaan din na ang lalagyan na ito ay nangangailangan ng nightly channel ng Rust!
Sa katunayan ang mga pagsusulit sa itaas ay nangangailangan ng gabi-gabing rust upang maging default sa iyong system, upang maitakda ang paggamit ng `rustup default nightly` (at `rustup default stable` upang ibalik).

Kung alinman sa mga hakbang sa itaas ay hindi gumagana, [please let us know][new]!

Susunod maaari mong [find an issue][issues] upang matulungan out on, na pinili namin ang ilang sa mga [`help wanted`][help] at [`impl-period`][impl] tags na maaaring partikular na gumamit ng ilang tulong. 
Maaaring pinaka-interesado sa [#40][vendor], pagpapatupad ng lahat vendor intrinsics sa x86.Iyon isyu got ang ilang magandang payo tungkol sa kung saan upang makapagsimula!

Kung mayroon kang mga pangkalahatang katanungan huwag mag-atubiling [join us on gitter][gitter] at magtanong sa paligid!Huwag mag-atubiling mag-ping alinman sa@BurntSushi o@alexcrichton na may mga katanungan.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Paano sumulat ng mga halimbawa para sa stdarch intrinsics

Mayroong ilang mga tampok na dapat paganahin para sa naibigay na intrinsic upang gumana nang maayos at ang halimbawa ay dapat lamang patakbuhin ng `cargo test --doc` kapag ang tampok ay suportado ng CPU.

Bilang isang resulta, ang default `fn main` na nabuo ng `rustdoc` ay hindi gagana (sa karamihan ng mga kaso).
Isiping gamitin ang sumusunod na bilang isang gabay upang matiyak na ang iyong mga halimbawa gawa tulad ng inaasahan.

```rust
/// # // kailangan namin cfg_target_feature upang masiguro na ang halimbawa ay lamang
/// # // patakbuhin ng `cargo test --doc` kapag sinusuportahan ng CPU ang tampok
/// # #![feature(cfg_target_feature)]
/// # // Kailangan namin ng target_feature para gumana ang intrinsic
/// # #![feature(target_feature)]
/// #
/// # // rustdoc sa pamamagitan ng default ay gumagamit `extern crate stdarch`, ngunit kailangan namin ang
/// # // `#[macro_use]`
/// # # [Macro_use] extern crate stdarch;
/// #
/// # // Ang tunay na pangunahing pag-andar
/// # fn main() {
/// #     // Tatakbo lamang ito kung `<target feature>` ay suportado
/// #     kung cfg_feature_enified! ("<target feature>"){
/// #         // Lumikha ng isang function na `worker` na tatakbo lamang kung ang tampok na target
/// #         // ay sinusuportahan at matiyak na `target_feature` ay pinagana para sa iyong worker
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         hindi ligtas fn worker() {
/// // Isulat ang iyong halimbawa dito.Tampok na mga tiyak na intrinsics gagana dito!Pumunta ligaw!
///
/// #         }
///
/// #         hindi ligtas { worker(); }
/// #     }
/// # }
```

Kung ang ilan sa mga nasa itaas syntax ay hindi mukhang pamilyar, ang [Documentation as tests] seksyon ng [Rust Book] naglalarawan ng `rustdoc` syntax medyo na rin.
Gaya ng lagi, huwag mag-atubiling [join us on gitter][gitter] at hilingin sa amin kung ikaw pindutin ang anumang snags, at salamat sa pagtulong upang mapabuti ang dokumentasyon ng `stdarch`!

# Mga Tagubilin sa Alternatibong Pagsubok

Pangkalahatang inirerekumenda na gamitin mo ang `ci/run.sh` upang patakbuhin ang mga pagsubok.
Gayunpaman ito ay maaaring hindi gumana para sa iyo, eg kung ikaw ay nasa Windows.

Sa kasong iyon maaari mong umasa sa pagpapatakbo `cargo +nightly test` at `cargo +nightly test --release -p core_arch` para sa pagsubok ng code na henerasyon.
Tandaan na nangangailangan ang mga ito ng nightly toolchain na mai-install at para malaman ng `rustc` ang tungkol sa iyong target na triple at ang CPU nito.
Sa partikular na kailangan mong itakda ang `TARGET` environment variable tulad ng gagawin mo para sa `ci/run.sh`.
Bilang karagdagan kailangan mong itakda ang `RUSTCFLAGS` (kailangan ang `C`) upang ipahiwatig ang mga tampok na target, hal `RUSTCFLAGS="-C -target-features=+avx2"`.
Maaari mo ring itakda `-C -target-cpu=native` kung ikaw "just" pagbubuo laban sa iyong kasalukuyang CPU.

Babalaan na kapag ginamit mo ang mga kahaliling tagubiling ito, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], hal
pagtuturo henerasyon pagsusuri Maaaring mabigo dahil ang disassembler pinangalanan ang mga ito sa ibang paraan, hal
maaari itong makabuo ng `vaesenc` sa halip na mga panuto ng `aesenc` sa kabila ng paggawi ng pareho.
Gayundin ang mga tagubiling ito execute mas mababa pagsusulit kaysa sa normal gawin, kaya huwag magulat na kapag ikaw ay sa wakas pull-humiling ang ilang mga error ay maaaring magpakita up para sa mga pagsubok hindi sakop dito.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






