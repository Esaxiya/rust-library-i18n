#![feature(no_core)]
#![no_core]

// Tingnan rustc-std-workspace-core para sa kung bakit ito crate ay kinakailangan.

// Palitan ang pangalan ng crate upang maiwasan ang pagkakasalungatan sa module ng paglalaan sa liballoc.
extern crate alloc as foo;

pub use foo::*;