//! Pagpapatupad ng Rust panics sa pamamagitan ng pag-abort ng proseso
//!
//! Kapag inihambing sa ang pagpapatupad sa pamamagitan ng unwinding, ito crate ay *magkano* mas simple!Iyon pagiging sinabi, ito ay hindi lubos na bilang maraming nalalaman, ngunit dito napupunta!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" ang payload at shim sa nauugnay na pagpapalaglag sa platform na pinag-uusapan.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // tumawag sa std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Sa Windows, gamitin ang tukoy na mekanismo na __fastfail na mekanismo.Sa Windows 8 at mas bago, tatapusin nito kaagad ang proseso nang hindi nagpapatakbo ng anumang mga handler ng pagbubukod na in-proseso.
            // Sa naunang bersyon ng Windows, ito pagkakasunod-sunod ng mga tagubilin ay itinuturing bilang isang paglabag access, pagwawakas ng mga proseso ngunit walang kinakailangang pag-bypass ang lahat ng handler exception.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: ito ay ang parehong pagpapatupad tulad ng sa libstd's `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Ito ... ay isang kaunting kakatwa.Ang tl; dr;ito ay kinakailangan upang mai-link nang tama, ang mas mahabang paliwanag ay nasa ibaba.
//
// Sa ngayon ang mga binaries ng libcore/libstd na nagpapadala tayong lahat ay pinagsama-sama na may `-C panic=unwind`.Ginagawa ito upang matiyak na ang mga binary ay maximum na katugma sa maraming mga sitwasyon hangga't maaari.
// Ang tagatala, gayunpaman, ay nangangailangan ng isang "personality function" para sa lahat ng mga function pinagsama-sama na may `-C panic=unwind`.Ito pagkatao function ay hardcoded sa simbolo `rust_eh_personality` at ay natutukoy ng mga `eh_personality` lang item.
//
// So...
// bakit hindi lamang tukuyin na lang item dito?Magandang tanong!Ang paraan na panic runtimes ay naka-link sa ay talagang isang maliit na banayad sa na ang mga ito ay "sort of" in crate store sa compiler, ngunit lamang ang tunay na naka-link kung ang isa pang ay hindi aktwal na naka-link.
//
// Nagtatapos ito na nangangahulugang ang parehong crate at ang panic_unwind crate na ito ay maaaring lumitaw sa tindahan ng crate ng tagatala, at kung kapwa tukuyin ang item na `eh_personality` lang pagkatapos ay maabot ang isang error.
//
// Upang pangasiwaan ang mga compiler lamang ay nangangailangan ng `eh_personality` ay tinukoy kung ang panic runtime na naka-link sa ang unwinding runtime, at kung hindi man ito ay hindi kinakailangan na tinukoy (rightfully kaya).
// Sa kasong ito, gayunman, ang library lang tumutukoy sa simbolong ito kaya hindi bababa sa ilang personalidad sa isang lugar.
//
// Mahalaga ang simbolo na ito ay tinukoy lamang upang makakuha ng wired hanggang sa libcore/libstd binary, ngunit hindi ito dapat tawagan dahil hindi kami nagli-link sa isang hindi gumagaling na runtime.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Sa x86_64-pc-windows-gnu gamitin natin ang ating sariling pagkatao function na pangangailangan upang bumalik `ExceptionContinueSearch` pati kami ay pagpasa sa lahat ng aming mga frame.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Katulad ng sa itaas, ito ay tumutugon sa `eh_catch_typeinfo` lang item na ginagamit lamang sa Emscripten sa kasalukuyan.
    //
    // Dahil panics huwag bumuo ng mga pagbubukod at dayuhang mga pagbubukod ay kasalukuyang UB na may -C panic=abort (bagaman ito ay maaaring sumailalim sa pagbabago), ang anumang catch_unwind tawag ay hindi kailanman gamitin ito typeinfo.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Ang dalawang ito ay tinawag ng aming mga startup na bagay sa i686-pc-windows-gnu, ngunit hindi nila kailangang gumawa ng anupaman kaya ang mga katawan ay nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}