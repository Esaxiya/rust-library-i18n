// rsbegin.o agus rsend.o tha ainm "compiler runtime startup objects".
// Tha iad anns an còd a dhìth gus ceart tòiseachadh an compiler runtime.
//
// Nuair a executable no dylib ìomhaigh a tha e ceangailte, a h-uile neach-cleachdaidh code agus leabharlannan a tha "sandwiched" eadar an dà rud faidhlichean, mar sin còd no dàta bho rsbegin.o bhith an toiseach ann an earrannan fa leth an ìomhaigh, ach code agus dàta bho rsend.o bhith an fheadhainn mu dheireadh.
// Tha seo a 'bhuaidh a dh'fhaodas a bhith air a chleachdadh gus àite samhlaidhean aig toiseach no aig deireadh earrann, a thuilleadh air a chur a-steach sam bith a dhìth bannan-cinn no teachdaireachdan aig bonn.
//
// Cuimhnich gur modal na fìor thoiseach tòiseachaidh a tha suidhichte ann an C runtime tòiseachaidh rud (mar as trice canar `crtX.o`), a tha an uair sin a invokes initialization callbacks eile runtime phàirtean (via clàraichte fhathast sònraichte eile ìomhaigh earrann).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Comharran a `tòiseachadh air frèam fiosrachaidh cruachadh frèam cruachan
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Scratch rùm airson unwinder taobh a-staigh leabhar-cumail.
    // Tha seo air a mhìneachadh mar `struct object` ann $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Unwind info registration/deregistration cleachdaidhean.
    // Faic na docaichean de libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // clàraich fiosrachadh neo-fhiosrachail mu thòiseachadh modal
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // neo-chlàraichte air dùnadh
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Clàradh àbhaisteach MinGW-sònraichte init/uninit
    pub mod mingw_init {
        // MinGW aig tòiseachaidh rudan (crt0.o/dllcrt0.o) Thèid ath-thagradh cruinneil constructors ann an .ctors agus .dtors earrannan air tòiseachaidh agus fhosglaidh.
        // A thaobh DLLs, thèid seo a dhèanamh nuair a thèid an DLL a luchdachadh agus a luchdachadh.
        //
        // Bidh an ceangaliche a `rèiteach nan earrannan, a nì cinnteach gu bheil na fiosan fòn againn aig deireadh an liosta.
        // Leis gu bheil luchd-togail air an ruith ann an òrdugh cas, bidh seo a `dèanamh cinnteach gur e na glaodhan fòn againn a` chiad fheadhainn agus an fheadhainn mu dheireadh a chaidh a chur gu bàs.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C initialization callbacks
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C crìoch callbacks
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}