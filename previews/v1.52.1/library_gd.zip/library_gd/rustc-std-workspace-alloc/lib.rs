#![feature(no_core)]
#![no_core]

// Faic rustc-std-- no àite-obrach bunaiteach airson crate carson a tha seo a tha a dhìth.

// Ath-ainmich an crate gus nach bi thu a `strì ris a` mhodal riarachaidh ann an liballoc.
extern crate alloc as foo;

pub use foo::*;