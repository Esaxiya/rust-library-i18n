# Cur ri stdarch

Tha `stdarch` crate tha barrachd is deònach gabhail ri tabhartasan!A 'chiad thu' s dòcha airson sùil a-mach air an ionad-tasgaidh agus dèan cinnteach gu bheil thu airson deuchainnean seachad:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Far a bheil `<your-target-arch>` na triple targaid mar a chaidh a chleachdadh le `rustup`, me `x86_x64-unknown-linux-gnu` (às aonais `nightly-` no a leithid roimhe).
Cuideachd cuimhnich gu bheil seo repository feum na nightly sianal de Rust!
Tha gu h-àrd deuchainnean a dhèanamh ann an dearbh feum nightly rust a bhith bunaiteach air an t-siostam, gus a chur air cleachdadh `rustup default nightly` (agus `rustup default stable` a thilleas).

Ma tha gin de na ceumannan gu h-àrd nach eil ag obair, [please let us know][new]!

An ath suas urrainn dhut [find an issue][issues] gus cuideachadh a mach air, tha sinn air a thaghadh le beagan an [`help wanted`][help] agus [`impl-period`][impl] tags a dh'fhaodadh a bhith gu h-àraidh a 'cleachdadh beagan cuideachaidh. 
Faodaidh tu a bhith a 'chuid as motha a bheil ùidh ann [#40][vendor], a' buileachadh a h-uile reiceadair intrinsics air x86.Tha sin a 'cheist a fhuair cuid mhath Pointers mu dheidhinn far airson tòiseachadh!

Ma tha ceistean coitcheann agad cuir fios gu [join us on gitter][gitter] agus faighnich timcheall!Faodaidh tu ping an dàrna cuid@BurntSushi no@alexcrichton le ceistean.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Mar a sgrìobhas tu eisimpleirean airson stdarch intrinsics

Tha beagan fheartan a dh'fheumas a bhith an comas a thoirt seachad airson an ghnèitheach gu obair ceart agus feumaidh an t-eisimpleir a-mhàin a bhith air a ruith le `cargo test --doc` nuair a feart a 'faighinn taic le CPU.

Mar thoradh air an sin, cha obraich an `fn main` bunaiteach a thèid a chruthachadh le `rustdoc` (sa mhòr-chuid de chùisean).
Beachdaich air na leanas a chleachdadh mar stiùireadh gus dèanamh cinnteach gu bheil an eisimpleir agad ag obair mar a bha dùil.

```rust
/// # // Feumaidh sinn cfg_target_feature gus dèanamh cinnteach gu bheil an eisimpleir a-mhàin
/// # // air a ruith le `cargo test --doc` nuair a CPU 'cur taic ri feart
/// # #![feature(cfg_target_feature)]
/// # // Feumaidh sinn target_feature airson an gnèitheach obrachadh
/// # #![feature(target_feature)]
/// #
/// # // rustdoc bho thùs a 'cleachdadh `extern crate stdarch`, ach feumaidh sinn na
/// # // `#[macro_use]`
/// # # [Macro_use] extern crate stdarch;
/// #
/// # // Am prìomh ghnìomh fìor
/// # fn main() {
/// #     // Na ruith seo ach ma tha `<target feature>` a `faighinn taic
/// #     ma tha cfg_feature_enabled! ("<target feature>"){
/// #         // Cruthaich gnìomh `worker` nach tèid a ruith ach ma tha am feart targaid
/// #         // Tha taic agus dèanamh cinnteach gu bheil `target_feature` a chur an comas airson do neach-obrach
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         sàbhailte fn worker() {
/// // Sgrìobh do eisimpleir seo.Bidh feartan sònraichte feart ag obair an seo!Rach fiadhaich!
///
/// #         }
///
/// #         sàbhailte { worker(); }
/// #     }
/// # }
```

Ma tha cuid de na h-àrd sheantansan Chan eil a 'coimhead eòlach, an [Documentation as tests] earrann den [Rust Book] ag innse mu na `rustdoc` sheantansan gu math gu math.
Mar as àbhaist, a 'faireachdainn an-asgaidh do [join us on gitter][gitter] agus iarraidh thugainn ma tha sibh bhuail sam bith snags, agus tapadh leat airson a bhith a' cuideachadh a 'leasachadh na sgrìobhainnean de `stdarch`!

# Stiùireadh deuchainn eile

Mar as trice thathas a `moladh gun cleachd thu `ci/run.sh` gus na deuchainnean a ruith.
Ach seo dòcha nach eil ag obair dhut, me ma tha sibh air Windows.

Anns a 'chùis faodaidh tu tuiteam air ais gu a' ruith `cargo +nightly test` agus `cargo +nightly test --release -p core_arch` airson deuchainn nan còd ginealach.
Cuimhnich gur iad sin feum an nightly toolchain a stàladh agus airson `rustc` fios a bhith agaibh mu ur targaid a trì agus a CPU.
Gu sònraichte feumaidh tu caochladair àrainneachd `TARGET` a shuidheachadh mar a dhèanadh tu airson `ci/run.sh`.
A thuilleadh air sin feumaidh sibh a chur `RUSTCFLAGS` (feum an `C`) gus sealltainn targaid feartan, me `RUSTCFLAGS="-C -target-features=+avx2"`.
Faodaidh tu cuideachd a chur `-C -target-cpu=native` ma tha thu a 'leasachadh "just" aghaidh làithreach agad CPU.

Bi rabhadh gun nuair a bhios tu a 'cleachdadh stiùiridhean sin eile, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], me
teagasg ghinealach deuchainnean faodaidh gum fairtlich air sgàth an disassembler ainmeachadh iad eadar-dhealaichte, me
faodaidh e `vaesenc` a ghineadh an àite stiùireadh `aesenc` a dh `aindeoin gu bheil iad gan giùlan fhèin mar an ceudna.
Cuideachd an stiùireadh seo an gnìomh nas lugha na bhiodh deuchainnean, mar as trice air a dhèanamh, mar sin chan eil e na iongnadh nuair a tha thu a 'cheann thall an tarraingeadh-iarraidh an cuid mearachdan a dh'fhaodadh nochdadh airson deuchainnean nach eil còmhdaichte seo.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






