`core::arch` - Rust prìomh leabharlainn ailtireachd sònraichte intrinsics
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Bidh am modal `core::arch` a `buileachadh feartan bunaiteach a tha an urra ri ailtireachd (me SIMD).

# Usage 

`core::arch` Tha e ri fhaotainn mar phàirt de `libcore` agus tha e air ath-às-mhalairt le `libstd`.B 'fheàrr leam a bhith ga cleachdadh tron `core::arch` no `std::arch` na via seo crate.
Sheasmhach feartan a tha gu tric ri fhaighinn ann an nightly Rust tro `feature(stdsimd)`.

Cleachdadh `core::arch` via seo crate Feumaidh nightly Rust, agus faodaidh e (agus chan) bhriseadh gu tric.Tha a-mhàin ann an cùisean a bu chòir dhut beachdachadh air a bhith ga cleachdadh tron crate seo tha:

* ma dh'fheumas tu ath-thrusadh `core::arch` fhèin, me, le targaid-fheartan sònraichte an comas nach eil an comas `libcore`/`libstd`.
Note: ma dh'fheumas tu ath-thrusadh e airson neo-àbhaisteach targaid, cuiribh 'fheàrr leis a' cleachdadh `xargo` agus ath-`libcore`/`libstd` 'cur ri chèile mar a bhios iomchaidh an àite a bhith a' cleachdadh seo crate.
  
* a 'cleachdadh cuid de na feartan a dh'fhaodadh nach bi e ri fhaotainn fiù' s neo-sheasmhach air cùl Rust nochdadh.Bidh sinn a `feuchainn ri iad sin a chumail cho ìosal.
Ma dh'fheumas tu a 'cleachdadh cuid de na feartan seo, cuiribh Fosgail an cùis mar sin faodaidh sinn iad ann an ana-nightly Rust agus faodaidh tu gan cleachdadh bho an sin.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` motha a tha a 'sgaoileadh fo chumhachan an dà chuid an MIT cead agus an Apache ceadachas (Version 2.0), le pàirtean air a chòmhdach le diofar BSD coltach ceadan.

Faic CHEADACHAIS-APACHE, agus 'CHEADACHAIS-MIT airson mion-fhiosrachadh.

# Contribution

Mura h-eil thu ag innse a chaochladh, bidh tabhartas sam bith a chaidh a chuir a-steach a dh`aona ghnothach airson a thoirt a-steach ann an `core_arch` leat, mar a tha e air a mhìneachadh ann an cead Apache-2.0, air a cheadachadh gu dùbailte mar gu h-àrd, gun chumhachan no cumhaichean a bharrachd.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












