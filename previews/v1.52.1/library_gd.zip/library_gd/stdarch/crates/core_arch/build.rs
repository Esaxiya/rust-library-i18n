use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Air a chleachdadh gus innse do na notaichean `#[assert_instr]` againn gu bheil a h-uile inneal simd ri fhaighinn gus an codegen aca a dhearbhadh, leis gu bheil cuid dhiubh air an cùlaibh air `-Ctarget-feature=+unimplemented-simd128` a bharrachd nach eil co-ionann ann an `#[target_feature]` an-dràsta.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}