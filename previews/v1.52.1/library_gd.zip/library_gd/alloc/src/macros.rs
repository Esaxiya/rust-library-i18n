/// A `cruthachadh [`Vec`] anns a bheil na h-argamaidean.
///
/// `vec!` a `leigeil le` Vec`s a bhith air am mìneachadh leis an aon chiallachd ri abairtean eagar.
/// Tha dà sheòrsa den macro seo:
///
/// - Cruthaich [`Vec`] anns a bheil liosta de eileamaidean sònraichte:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Cruthaich [`Vec`] bho eileamaid agus meud sònraichte:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Thoir fa-near, aocoltach ri abairtean eagar tha an co-chòrdadh seo a `toirt taic do na h-eileamaidean uile a tha a` buileachadh [`Clone`] agus chan fheum an àireamh de eileamaidean a bhith seasmhach.
///
/// Cleachdaidh seo `clone` gus abairt a dhùblachadh, mar sin bu chòir a bhith faiceallach le bhith a `cleachdadh seo le seòrsachan le buileachadh neo-sheasmhach `Clone`.
/// Mar eisimpleir, `vec![Rc::new(1);5] cruthaichidh `vector de chòig iomraidhean air an aon luach integer bogsaichte, chan e còig iomraidhean a` comharrachadh integers ann am bogsa neo-eisimeileach.
///
///
/// Cuideachd, thoir fa-near gu bheil `vec![expr; 0]` ceadaichte, agus a `dèanamh vector falamh.
/// Bidh seo fhathast a `luachadh `expr`, ge-tà, agus a` leigeil sìos an luach a thig às, sa bhad, mar sin bi mothachail air fo-bhuaidhean.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): le cfg(test) chan eil an dòigh in-ghnèitheach `[T]::into_vec`, a tha riatanach airson a `mhìneachadh macro seo, ri fhaighinn.
// An àite sin cleachd an gnìomh `slice::into_vec` nach fhaighear ach le cfg(test) NB faic am modal slice::hack ann an slice.rs airson tuilleadh fiosrachaidh
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// A `cruthachadh `String` a` cleachdadh eadar-ghluasad de abairtean runtime.
///
/// Is e sreang cruth a `chiad argamaid a gheibh `format!`.Feumaidh seo a bhith litireil sreang.Tha cumhachd an t-sreang cruth anns na`{}` s a tha ann.
///
/// Bidh paramadairean a bharrachd a chaidh an toirt seachad gu `format!` a `dol an àite nan` {} `s taobh a-staigh sreang an cruth san òrdugh a chaidh a thoirt seachad mura cleachdar paramadairean ainmichte no suidheachadh;faic [`std::fmt`] airson tuilleadh fiosrachaidh.
///
///
/// Is e cleachdadh cumanta airson `format!` concatenation agus interpolation of strings.
/// Tha an aon cho-chruinneachadh air a chleachdadh le macros [`print!`] agus [`write!`], a rèir dè an ceann-uidhe a tha san amharc aig an t-sreang.
///
/// Gus aon luach a thionndadh gu sreang, cleachd am modh [`to_string`].Cleachdaidh seo an cruth [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics ma thilleas buileachadh cruth trait mearachd.
/// Tha seo a `comharrachadh buileachadh ceàrr leis nach till `fmt::Write for String` mearachd fhèin a-riamh.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Nòd AST feachd gu abairt gus breithneachadh a leasachadh ann an suidheachadh pàtran.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}