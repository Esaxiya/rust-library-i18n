#![stable(feature = "rust1", since = "1.0.0")]

//! Molaidhean cunntais snàthainn-sàbhailte.
//!
//! Faic na sgrìobhainnean [`Arc<T>`][Arc] airson tuilleadh fiosrachaidh.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Cuingealachadh bog air an ìre de dh `iomraidhean a dh` fhaodar a dhèanamh air `Arc`.
///
/// Ma thèid thu os cionn na crìche seo, fàsaidh e às do phrògram (ged nach eil sin riatanach) aig iomraidhean _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// Chan eil ThreadSanitizer a `toirt taic do fheansaichean cuimhne.
// Gus aithisgean dearbhach meallta a sheachnadh ann am buileachadh Arc/Weak cleachd luchdan atamach airson sioncronadh nan àite.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Puing-cunntais snàithlean-sàbhailte.Tha 'Arc' a `seasamh airson` Atomically Reference Counted `.
///
/// Tha an seòrsa `Arc<T>` a `toirt seachad seilbh co-roinnte air luach seòrsa `T`, air a riarachadh sa chàrn.Le bhith a`toirt ionnsaigh air [`clone`][clone] air `Arc` a`toirt a-mach eisimpleir `Arc` ùr, a tha a`comharrachadh an aon riarachadh air a`chàrn ris an stòr `Arc`, fhad`s a tha e a` meudachadh cunntas iomraidh.
/// Nuair a thèid am puing `Arc` mu dheireadh gu riarachadh sònraichte a sgrios, tha an luach a tha air a stòradh san riarachadh sin (ris an canar gu tric "inner value") air a leigeil sìos cuideachd.
///
/// Bidh iomraidhean co-roinnte ann an Rust a `dì-cheadachadh mùthadh gu bunaiteach, agus tha `Arc` mar eisgeachd: mar as trice chan urrainn dhut iomradh gluasadach fhaighinn air rudeigin taobh a-staigh `Arc`.Ma dh`fheumas tu a bhith a` dol tro `Arc`, cleachd [`Mutex`][mutex], [`RwLock`][rwlock], no aon de na seòrsaichean [`Atomic`][atomic].
///
/// ## Sàbhailteachd snàthainn
///
/// Eu-coltach ri [`Rc<T>`], bidh `Arc<T>` a `cleachdadh gnìomhachd atamach airson a bhith a` cunntadh iomraidh.Tha seo a `ciallachadh gu bheil e sàbhailte le snàithlean.Is e an ana-cothrom gu bheil gnìomhachd atamach nas daoire na ruigsinneachd cuimhne àbhaisteach.Ma tha thu a 'co-roinn eil iomradh chunntadh-riarachaidhean eadar-innealan, smaoinichibh air a cleachdadh airson [`Rc<T>`] ìsle os an cionn.
/// [`Rc<T>`] na roghainn sàbhailte, oir glacaidh an trusaiche oidhirp sam bith gus [`Rc<T>`] a chuir eadar snàithleanan.
/// Ach, dh `fhaodadh leabharlann `Arc<T>` a thaghadh gus barrachd sùbailteachd a thoirt do luchd-cleachdaidh leabharlann.
///
/// `Arc<T>` cuiridh e [`Send`] agus [`Sync`] an gnìomh fhad `s a bhios an `T` a` buileachadh [`Send`] agus [`Sync`].
/// Carson nach urrainn dhut seòrsa `T` nach eil sàbhailte le snàithlean a chuir ann an `Arc<T>` gus a dhèanamh sàbhailte le snàithlean?Dh `fhaodadh seo a bhith beagan mì-ghoireasach an toiseach: às deidh a h-uile càil, nach e puing sàbhailteachd snàithlean `Arc<T>` a th` ann?Is e seo an iuchair: tha `Arc<T>` ga dhèanamh sàbhailte gu snàithlean ioma-shealbh a bhith agad air an aon dàta, ach cha chuir e sàbhailteachd snàithlean ris an dàta aige.
///
/// Beachdaich air `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] chan e [`Sync`] a th `ann, agus nam biodh `Arc<T>` an-còmhnaidh [`Send`],` Arc <`[` RefCell<T>bhiodh `]`> `cuideachd.
/// Ach an uairsin bhiodh duilgheadas againn:
/// [`RefCell<T>`] nach eil snàithlean sàbhailte;bidh e a `cumail sùil air a` chunntas iasaid le bhith a `cleachdadh gnìomhachd neo-atamach.
///
/// Aig a `cheann thall, tha seo a` ciallachadh gur dòcha gum feum thu paidhir `Arc<T>` a chuir còmhla le seòrsa de sheòrsa [`std::sync`], mar as trice [`Mutex<T>`][mutex].
///
/// ## A `briseadh chearcallan le `Weak`
///
/// Faodar an dòigh [`downgrade`][downgrade] a chleachdadh gus stiùireadh [`Weak`] neo-seilbh a chruthachadh.Faodaidh puing [`Weak`] a bhith [`ùrachadh`][ùrachadh] d gu `Arc`, ach tillidh seo [`None`] ma chaidh an luach a tha air a stòradh san riarachadh a leigeil seachad mu thràth.
/// Ann am faclan eile, chan eil molaidhean `Weak` a `cumail an luach taobh a-staigh an riarachadh beò;ge-tà, bidh iad * a`cumail an riarachadh (an stòr taic airson an luach) beò.
///
/// Cha tèid cearcall eadar molaidhean `Arc` a thuigsinn gu bràth.
/// Air an adhbhar seo, thathas a `cleachdadh [`Weak`] gus cearcallan a bhriseadh.Mar eisimpleir, dh`fhaodadh craobh a bhith le comharran làidir `Arc` bho nodan pàrant gu clann, agus molaidhean [`Weak`] bho chloinn air ais gu am pàrantan.
///
/// # Iomraidhean clonaidh
///
/// Thathas a `cruthachadh iomradh ùr bho neach-cunntais cunntais iomraidh a tha ann mar-thà a` cleachdadh an `Clone` trait a chaidh a chuir an gnìomh airson [`Arc<T>`][Arc] agus [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Tha an dà chiallachadh gu h-ìosal co-ionann.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // tha a, b, agus foo uile nan Arcs a tha a `comharrachadh an aon àite cuimhne
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` gu fèin-ghluasadach gu `T` (tron [`Deref`][deref] trait), gus an urrainn dhut dòighean `T` a ghairm air luach de sheòrsa `Arc<T>`.Gus ainmean a sheachnadh le modhan `T`, tha modhan `Arc<T>` fhèin nan gnìomhan co-cheangailte, ris an canar a` cleachdadh [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Canar cuideachd gnìomhachadh traits mar `Clone` le bhith a`cleachdadh co-aonta làn teisteanais.
/// Is fheàrr le cuid de dhaoine criathragan làn theisteanais a chleachdadh, ach is fheàrr le cuid eile a bhith a `cleachdadh co-aonta modh-gairm.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Co-chòrdadh modh-gairm
/// let arc2 = arc.clone();
/// // Co-chòrdadh làn teisteanais
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] na fèin-ghluasad gu `T`, oir is dòcha gu bheil an luach a-staigh air a leigeil sìos mu thràth.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// A `roinneadh cuid de dhàta so-ruigsinneach eadar snàithleanan:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Thoir fa-near nach bi sinn ** a `ruith na deuchainnean seo an seo.
// Bidh an luchd-togail windows a `faighinn fìor mhì-thoilichte ma tha snàithlean a` toirt a-mach na prìomh snàithlean agus an uairsin a `dol a-mach aig an aon àm (rudeigin deadlocks) agus mar sin bidh sinn dìreach a` seachnadh seo gu tur le bhith gun a bhith a `ruith na deuchainnean sin.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// A `roinneadh [`AtomicUsize`] mutable:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Faic an [`rc` documentation][rc_examples] airson tuilleadh eisimpleirean de chunntadh iomraidh san fharsaingeachd.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` na dhreach de [`Arc`] aig a bheil iomradh neo-seilbh air an riarachadh a tha air a riaghladh.
/// Gheibhear a-steach don riarachadh le bhith a `gairm [`upgrade`] air a` phuing `Weak`, a thilleas [`Roghainn`]`<`[`Arc`] `<T>>`.
///
/// Leis nach eil iomradh `Weak` a `cunntadh a dh` ionnsaigh seilbh, cha chuir e stad air an luach a tha air a stòradh san riarachadh a bhith air a leigeil sìos, agus chan eil `Weak` fhèin a `toirt gealltanas sam bith mun luach a tha fhathast ann.
///
/// Mar sin faodaidh e [`None`] a thilleadh nuair a bhios [`ùrachadh`] d.
/// Thoir fa-near ge-tà gu bheil iomradh `Weak` * a `cur casg air an riarachadh fhèin (an stòr taic) bho bhith air a thuigsinn.
///
/// Tha comharradh `Weak` feumail airson iomradh sealach a chumail air an riarachadh a tha [`Arc`] a `riaghladh gun a bhith a` cur casg air a luach a-staigh a bhith air a leigeil sìos.
/// Tha e cuideachd air a chleachdadh gus casg a chuir air iomraidhean cearcallach eadar stiùiridhean [`Arc`], oir cha leigeadh iomraidhean co-shealbh a-riamh [`Arc`] a leigeil sìos.
/// Mar eisimpleir, dh `fhaodadh craobh a bhith le comharran làidir [`Arc`] bho nodan pàrant gu clann, agus molaidhean `Weak` bho chloinn air ais gu am pàrantan.
///
/// Is e an dòigh àbhaisteach air comharradh `Weak` fhaighinn [`Arc::downgrade`] a ghairm.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Is e `NonNull` a tha seo gus leigeil le meud den t-seòrsa seo a mheudachadh ann an enums, ach chan eil e gu riatanach na chomharraiche dligheach.
    //
    // `Weak::new` a `suidheachadh seo gu `usize::MAX` gus nach fheum e àite a riarachadh air a` chàrn.
    // Chan e luach a tha sin a bhios aig fìor phuing a-riamh oir tha co-thaobhadh 2 aig RcBox.
    // Chan eil seo comasach ach nuair a tha `T: Sized`;chan eil `T` gun stad a-riamh a `crochadh.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Is e seo repr(C) gu future-proof an aghaidh ath-òrdachadh làraich a dh `fhaodadh a bhith ann, a chuireadh bacadh air [into|from]_raw() a bha sàbhailte air dhòigh eile de sheòrsan taobh a-staigh transmutable.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // tha an luach usize::MAX ag obair mar sentinel airson "locking" sealach an comas molaidhean lag ùrachadh no ìsleachadh feadhainn làidir;tha seo air a chleachdadh gus rèisean a sheachnadh ann an `make_mut` agus `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// A `togail `Arc<T>` ùr.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Tòisich a `chunntais lag mar 1 a tha na chomharradh lag a tha air a chumail leis a h-uile moladh làidir (kinda), faic std/rc.rs airson tuilleadh fiosrachaidh
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// A `togail `Arc<T>` ùr a` cleachdadh iomradh lag air fhèin.
    /// Bidh luach `None` a `feuchainn ri ùrachadh a dhèanamh air an iomradh lag mus till an gnìomh seo.
    /// Ach, faodar an iomradh lag a bhith air a clònadh gu saor agus air a stòradh airson a chleachdadh aig àm nas fhaide air adhart.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Tog an taobh a-staigh ann an stàite "uninitialized" le aon iomradh lag.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Tha e cudromach nach bi sinn a `toirt seachad seilbh air a` phuing lag, no eile dh `fhaodadh an cuimhne a bhith air a shaoradh mus till `data_fn`.
        // Nam biodh sinn dha-rìribh ag iarraidh seilbh a thoirt seachad, dh `fhaodadh sinn comharraiche lag a bharrachd a chruthachadh dhuinn fhìn, ach bheireadh seo ùrachadh a bharrachd don chunntas iomraidh lag a dh` fhaodadh nach biodh feum air a chaochladh.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // A-nis is urrainn dhuinn an luach a-staigh a thòiseachadh gu ceart agus an iomradh lag againn a thionndadh gu iomradh làidir.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Feumaidh an sgrìobhadh gu h-àrd a bhith follaiseach don raon dàta le snàithleanan sam bith a choimheadas cunntadh làidir nach eil idir.
            // Mar sin feumaidh sinn òrdugh "Release" co-dhiù gus sioncronadh leis an `compare_exchange_weak` ann an `Weak::upgrade`.
            //
            // "Acquire" chan eil feum air òrdachadh.
            // Nuair a bhios sinn a `beachdachadh air na giùlan a dh`fhaodadh a bhith aig `data_fn` cha leig sinn a leas ach coimhead air na dh` fhaodadh e a dhèanamh le iomradh air `Weak` nach gabh ùrachadh:
            //
            // - Faodaidh e *clone* an `Weak`, ag àrdachadh an àireamh iomraidh lag.
            // - Faodaidh e na clones sin a leigeil sìos, a `lughdachadh an àireamh iomraidh lag (ach gun a bhith gu neoni).
            //
            // Chan eil na fo-bhuaidhean sin a `toirt buaidh oirnn ann an dòigh sam bith, agus chan eil frith-bhuaidhean sam bith eile comasach le còd sàbhailte a-mhàin.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Bu chòir iomraidhean làidir co-roinnte a bhith aig iomraidhean làidir, mar sin na ruith an inneal-sgrios airson an t-seann iomradh lag againn.
        //
        mem::forget(weak);
        strong
    }

    /// A `togail `Arc` ùr le susbaint neo-aithnichte.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Toiseach tòiseachaidh:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// A `togail `Arc` ùr le susbaint neo-aithnichte, leis a` chuimhne air a lìonadh le bytes `0`.
    ///
    ///
    /// Faic [`MaybeUninit::zeroed`][zeroed] airson eisimpleirean de chleachdadh ceart agus ceàrr den dòigh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// A `togail `Pin<Arc<T>>` ùr.
    /// Mura cuir `T` an gnìomh `Unpin`, thèid `data` a phronnadh mar chuimhneachan agus cha ghabh a ghluasad.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// A `togail `Arc<T>` ùr, a` tilleadh mearachd ma dh `fhailicheas an riarachadh.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Tòisich a `chunntais lag mar 1 a tha na chomharradh lag a tha air a chumail leis a h-uile moladh làidir (kinda), faic std/rc.rs airson tuilleadh fiosrachaidh
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// A `togail `Arc` ùr le susbaint neo-aithnichte, a` tilleadh mearachd ma dh `fhailicheas an riarachadh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Toiseach tòiseachaidh:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// A `togail `Arc` ùr le susbaint neo-aithnichte, leis a` chuimhne air a lìonadh le `0` bytes, a `tilleadh mearachd ma dh` fhailicheas an riarachadh.
    ///
    ///
    /// Faic [`MaybeUninit::zeroed`][zeroed] airson eisimpleirean de chleachdadh ceart agus ceàrr den dòigh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// A `tilleadh an luach a-staigh, ma tha aon iomradh làidir aig an `Arc`.
    ///
    /// Rud eile, thèid [`Err`] a thilleadh leis an aon `Arc` a chaidh a-steach.
    ///
    ///
    /// Bidh seo a `soirbheachadh eadhon ged a tha iomraidhean lag ann fhathast.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Dèan stiùireadh lag gus an iomradh làidir-lag a tha soilleir a ghlanadh
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// A `togail sliseag ùr le cunntadh atamach le susbaint neo-aithnichte.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Toiseach tòiseachaidh:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// A `togail sliseag ùr le cunntadh atamach le susbaint neo-aithnichte, leis a` chuimhne air a lìonadh le bytes `0`.
    ///
    ///
    /// Faic [`MaybeUninit::zeroed`][zeroed] airson eisimpleirean de chleachdadh ceart agus ceàrr den dòigh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Tionndadh gu `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Coltach ri [`MaybeUninit::assume_init`], tha e an urra ris an neach-fios a bhith a `gealltainn gu bheil an luach a-staigh ann an staid tòiseachaidh.
    ///
    /// Le bhith a `gairm seo nuair nach eil an susbaint air a làn thòiseachadh fhathast ag adhbhrachadh giùlan neo-mhìnichte sa bhad.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Toiseach tòiseachaidh:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Tionndadh gu `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Coltach ri [`MaybeUninit::assume_init`], tha e an urra ris an neach-fios a bhith a `gealltainn gu bheil an luach a-staigh ann an staid tòiseachaidh.
    ///
    /// Le bhith a `gairm seo nuair nach eil an susbaint air a làn thòiseachadh fhathast ag adhbhrachadh giùlan neo-mhìnichte sa bhad.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Toiseach tòiseachaidh:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// A `caitheamh an `Arc`, a` tilleadh a `phuing fillte.
    ///
    /// Gus aodion cuimhne a sheachnadh feumar am puing a thionndadh air ais gu `Arc` a `cleachdadh [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// A `toirt stiùireadh amh don dàta.
    ///
    /// Chan eilear a `toirt buaidh air na cunntasan ann an dòigh sam bith agus chan eilear a` caitheamh an `Arc`.
    /// Tha an comharradh dligheach cho fad `s gu bheil cunntasan làidir anns an `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SÀBHAILTEACHD: Chan urrainn dha seo a dhol tro Deref::deref no RcBoxPtr::inner air sgàth
        // feumar seo gus dearbhadh raw/mut a chumail gus am bi me
        // `get_mut` comasach air sgrìobhadh tron phuing às deidh don Rc faighinn air ais tro `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// A `togail `Arc<T>` bho stiùireadh amh.
    ///
    /// Feumaidh gun deach am puing amh a thilleadh roimhe le gairm gu [`Arc<U>::into_raw`][into_raw] far am feum `U` an aon mheud agus co-thaobhadh ri `T`.
    /// Tha seo fìor gu fìrinneach ma tha `U` `T`.
    /// Thoir fa-near, mura h-e `T` a th `ann an `U` ach gu bheil an aon mheud is co-thaobhadh aige, tha seo gu bunaiteach mar a bhith a` gluasad iomraidhean de dhiofar sheòrsaichean.
    /// Faic [`mem::transmute`][transmute] airson tuilleadh fiosrachaidh mu na cuingeadan a tha a `buntainn sa chùis seo.
    ///
    /// Feumaidh neach-cleachdaidh `from_raw` dèanamh cinnteach nach tèid luach sònraichte `T` a leigeil sìos ach aon turas.
    ///
    /// Tha an gnìomh seo cunnartach oir dh `fhaodadh cleachdadh neo-iomchaidh leantainn gu mì-shàbhailteachd cuimhne, eadhon ged nach ruigear an `Arc<T>` a chaidh a thilleadh a-riamh.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Tionndaidh air ais gu `Arc` gus casg a chuir air aodion.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Bhiodh gairmean eile gu `Arc::from_raw(x_ptr)` neo-shàbhailte.
    /// }
    ///
    /// // Chaidh an cuimhne a shaoradh nuair a chaidh `x` a-mach à farsaingeachd gu h-àrd, agus mar sin tha `x_ptr` a-nis crochte!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Cuir air ais an fhrith-rathad gus an ArcInner tùsail a lorg.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// A `cruthachadh stiùireadh [`Weak`] ùr don riarachadh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Tha an Relaxed seo ceart gu leòr oir tha sinn a `sgrùdadh luach an CAS gu h-ìosal.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // thoir sùil air a bheil an cuntar lag an-dràsta "locked";ma tha, snìomh.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: tha an còd seo an-dràsta a `seachnadh comas air cus sruthadh
            // a-steach usize::MAX;sa chumantas feumar an dà chuid Rc agus Arc atharrachadh gus dèiligeadh ri cus sruthadh.
            //

            // Eu-coltach ri Clone(), feumaidh sinn seo a bhith na leughadh Acquire gus sioncronadh leis an sgrìobhadh a `tighinn bho `is_unique`, gus an tachair na tachartasan ron sgrìobhadh sin mus leugh thu seo.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Dèan cinnteach nach cruthaich sinn Lag crochte
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Gets an àireamh de [`Weak`] Pointers gus seo a riarachadh.
    ///
    /// # Safety
    ///
    /// Tha an dòigh seo leis fhèin sàbhailte, ach le bhith ga chleachdadh gu ceart feumar cùram a bharrachd.
    /// Faodaidh snàithlean eile an cunntadh lag atharrachadh aig àm sam bith, a `toirt a-steach eadar a bhith ag ainmeachadh an dòigh seo agus a bhith ag obair air an toradh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Tha an dearbhadh seo deimhinnte oir cha do roinn sinn an `Arc` no `Weak` eadar snàithleanan.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Ma tha an cunntadh lag glaiste an-dràsta, b `e luach a` chunntais 0 dìreach mus deach a `ghlas a ghabhail.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Faigh an àireamh de chomharran (`Arc`) làidir don riarachadh seo.
    ///
    /// # Safety
    ///
    /// Tha an dòigh seo leis fhèin sàbhailte, ach le bhith ga chleachdadh gu ceart feumar cùram a bharrachd.
    /// Faodaidh snàithlean eile an cunntadh làidir atharrachadh aig àm sam bith, a `toirt a-steach eadar a bhith ag ainmeachadh an dòigh seo agus a bhith ag obair air an toradh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Tha an dearbhadh seo deimhinnte oir cha do roinn sinn an `Arc` eadar snàithleanan.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// A `meudachadh a` chunntais iomraidh làidir air an `Arc<T>` co-cheangailte ris a `phuing a chaidh a thoirt seachad le aon.
    ///
    /// # Safety
    ///
    /// Feumaidh am fiosaiche fhaighinn tro `Arc::into_raw`, agus feumaidh an eisimpleir `Arc` co-cheangailte a bhith dligheach (ie
    /// feumaidh an cunntadh làidir a bhith co-dhiù 1) airson fad a `mhodh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Tha an dearbhadh seo deimhinnte oir cha do roinn sinn an `Arc` eadar snàithleanan.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Cùm Arc, ach na bi a `suathadh ri ath-chunntadh le bhith a` pasgadh a-steach ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // A-nis àrdaich ath-chunntadh, ach na leig às ath-chunntadh ùr an dàrna cuid
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// A `lughdachadh an àireamh iomraidh làidir air an `Arc<T>` co-cheangailte ris a` phuing a chaidh a thoirt seachad le aon.
    ///
    /// # Safety
    ///
    /// Feumaidh am fiosaiche fhaighinn tro `Arc::into_raw`, agus feumaidh an eisimpleir `Arc` co-cheangailte a bhith dligheach (ie
    /// làidir cunntadh feumaidh co-dhiù 1) nuair a invoking dòigh seo.
    /// Faodar an dòigh seo a chleachdadh gus an `Arc` deireannach agus an stòradh cùl-taic a leigeil ma sgaoil, ach cha bu chòir **a bhith air a ghairm** às deidh an `Arc` deireannach a leigeil ma sgaoil.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Tha na dearbhaidhean sin deimhinnte oir cha do roinn sinn an `Arc` eadar snàithleanan.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Tha seo a 'unsafety e ceart gu leòr fhad' sa bha seo oir arc tha beò sinn a dhol an urras gu bheil an taobh a-staigh na chomharra a tha dligheach.
        // A bharrachd air an sin, tha fios againn gur e `Sync` an structar `ArcInner` fhèin leis gu bheil an dàta a-staigh `Sync` cuideachd, agus mar sin tha sinn ceart gu leòr iasad a thoirt a-mach airson na susbaint sin.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Pàirt neo-loidhneach de `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Dèan sgrios air an dàta aig an àm seo, eadhon ged is dòcha nach saor sinn riarachadh a `bhogsa fhèin (is dòcha gu bheil comharran lag fhathast nan laighe timcheall).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Leig às an ref lag còmhla air a chumail leis a h-uile iomradh làidir
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// A `tilleadh `true` ma tha an dà` Arc`s a` comharrachadh an aon riarachadh (ann an vein coltach ri [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// A `riarachadh `ArcInner<T>` le àite gu leòr airson luach a-staigh nach eil cinnteach far a bheil an luach air a thoirt seachad.
    ///
    /// Canar an gnìomh `mem_to_arcinner` ris a `phuing dàta agus feumaidh e inneal-stiùiridh (a dh` fhaodadh a bhith reamhar) a thilleadh airson an `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Obraich a-mach cruth a `cleachdadh an cruth luach a chaidh a thoirt seachad.
        // Roimhe sin, chaidh cruth a thomhas air an abairt `&*(ptr as* const ArcInner<T>)`, ach chruthaich seo iomradh mì-chomharraichte (faic #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// A `riarachadh `ArcInner<T>` le àite gu leòr airson luach a-staigh nach eil cinnteach far a bheil an luach air a thoirt seachad, a` tilleadh mearachd ma dh `fhàillig an riarachadh.
    ///
    ///
    /// Canar an gnìomh `mem_to_arcinner` ris a `phuing dàta agus feumaidh e inneal-stiùiridh (a dh` fhaodadh a bhith reamhar) a thilleadh airson an `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Obraich a-mach cruth a `cleachdadh an cruth luach a chaidh a thoirt seachad.
        // Roimhe sin, chaidh cruth a thomhas air an abairt `&*(ptr as* const ArcInner<T>)`, ach chruthaich seo iomradh mì-chomharraichte (faic #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Tòisich an ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// A `riarachadh `ArcInner<T>` le àite gu leòr airson luach a-staigh gun luach.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Riarachadh airson an `ArcInner<T>` a `cleachdadh an luach a chaidh a thoirt seachad.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Leth-bhreac luach mar bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Saor an riarachadh gun a bhith a `leigeil às na tha ann
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// A `riarachadh `ArcInner<[T]>` leis an fhad a chaidh a thoirt seachad.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Dèan lethbhreac de eileamaidean bho slice a-steach do Arc <\[T\]> a chaidh a riarachadh às ùr
    ///
    /// Neo-shàbhailte oir feumaidh an neach-glacaidh seilbh a ghabhail no ceangal `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// A `togail `Arc<[T]>` bho iterator a tha aithnichte gu bheil e de mheud sònraichte.
    ///
    /// Chan eil giùlan air a mhìneachadh ma tha am meud ceàrr.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Geàrd Panic fhad `s a tha e a` clònadh eileamaidean T.
        // Ma thachras panic, thèid eileamaidean a chaidh a sgrìobhadh a-steach don ArcInner ùr a leigeil sìos, an uairsin an cuimhne a shaoradh.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pointer chun chiad eileamaid
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Uile soilleir.Na dìochuimhnich an geàrd gus nach saor e an ArcInner ùr.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Speisealachadh trait air a chleachdadh airson `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// A `dèanamh clon den phuing `Arc`.
    ///
    /// Bidh seo a `cruthachadh stiùireadh eile chun an aon riarachadh, ag àrdachadh an àireamh iomraidh làidir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Tha a bhith a `cleachdadh òrdachadh socair ceart an seo, oir tha eòlas air an iomradh tùsail a` cur casg air snàithleanan eile bho bhith a `cuir às don nì gu mearachdach.
        //
        // Mar a chaidh a mhìneachadh san [Boost documentation][1], Faodar àrdachadh a dhèanamh air a `chunntair iomraidh an-còmhnaidh le memory_order_relaxed: Chan urrainnear iomraidhean ùra air rud a chruthachadh ach bho iomradh a th` ann mar-thà, agus feumaidh a bhith a `dol seachad air iomradh a tha ann mar-thà bho aon snàithlean gu fear eile sioncronadh riatanach sam bith a thoirt seachad.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Ach feumaidh sinn dìon an aghaidh cunntasan mòra gun fhios nach bi cuideigin `mem: : dìochuimhnich Arcs.
        // Mura dèan sinn seo faodaidh an cunntadh cur thairis agus cleachdaidh luchd-cleachdaidh an-asgaidh.
        // Bidh sinn a `dol gu gràin gu `isize::MAX` leis a` bharail nach eil snàithleanan ~2 billean ag àrdachadh a `chunntais iomraidh aig an aon àm.
        //
        // Cha tèid an branch seo a ghabhail a-riamh ann am prògram reusanta sam bith.
        //
        // Bidh sinn a `sgur a chionn` s gu bheil prògram mar seo air a dhol bhuaithe gu mòr, agus chan eil dragh againn taic a thoirt dha.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// A 'dèanamh iomradh mutable a thoirt a-steach dhan `Arc`.
    ///
    /// Ma tha comharran `Arc` no [`Weak`] eile aig an aon riarachadh, cruthaichidh `make_mut` riarachadh ùr agus bheir e ionnsaigh air [`clone`][clone] air an luach a-staigh gus dèanamh cinnteach à seilbh gun samhail.
    /// Thathas cuideachd a `toirt iomradh air seo mar clone-on-write.
    ///
    /// Thoir fa-near gu bheil seo eadar-dhealaichte bho ghiùlan [`Rc::make_mut`] a bhios a `cuir às do chomharran `Weak` sam bith a tha air fhàgail.
    ///
    /// Faic cuideachd [`get_mut`][get_mut], a dh `fhàilligeas seach a bhith a` clònadh.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Cha clone mi dad
    /// let mut other_data = Arc::clone(&data); // Cha clone dàta a-staigh
    /// *Arc::make_mut(&mut data) += 1;         // Dàta a-staigh clones
    /// *Arc::make_mut(&mut data) += 1;         // Cha clone mi dad
    /// *Arc::make_mut(&mut other_data) *= 2;   // Cha clone mi dad
    ///
    /// // A-nis tha `data` agus `other_data` a `comharrachadh diofar riarachadh.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Thoir fa-near gu bheil sinn a `cumail gach cuid iomradh làidir agus iomradh lag.
        // Mar sin, le bhith a `leigeil às ar n-iomradh làidir a-mhàin cha toir sin leis fhèin cuimhne a bhith air a thuigsinn.
        //
        // Cleachd Acquire gus dèanamh cinnteach gum faic sinn sgrìobhadh sam bith gu `weak` a thachras mus sgrìobh an sgaoileadh (ie, lùghdachaidhean) gu `strong`.
        // Leis gu bheil cunntas lag againn, chan eil teansa sam bith gum faodadh an ArcInner fhèin a bhith air a thuigsinn.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Tha comharradh làidir eile ann, mar sin feumaidh sinn clone.
            // Ro-riarachadh cuimhne gus leigeil le bhith a `sgrìobhadh an luach clonaichte gu dìreach.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Gu leòr a `fulang anns na tha gu h-àrd oir tha seo gu bunaiteach na optimization: tha sinn an-còmhnaidh a` rèiseadh le comharran lag gan leigeil sìos.
            // A `chùis as miosa, bidh sinn a` riarachadh Arc ùr gun fheum.
            //

            // Thug sinn air falbh an t-iomradh làidir mu dheireadh, ach tha refs lag a bharrachd air fhàgail.
            // Gluaisidh sinn an susbaint gu Arc ùr, agus cuiridh sinn na tagraidhean lag eile ann an suidheachadh neo-dhligheach.
            //

            // Thoir fa-near nach eil e comasach dha leughadh `weak` toradh usize::MAX (ie, glaiste), oir chan urrainnear an cunntadh lag a ghlasadh le snàithlean le iomradh làidir.
            //
            //

            // Dèan stuth air a `phuing lag shoilleir againn fhìn, gus an urrainn dha an ArcInner a ghlanadh mar a dh` fheumar.
            //
            let _weak = Weak { ptr: this.ptr };

            // An urrainn dìreach an dàta a ghoid, chan eil air fhàgail ach Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // B `e sinn an aon iomradh de gach seòrsa;bump air ais suas an cunntadh ref làidir.
            //
            this.inner().strong.store(1, Release);
        }

        // Coltach ri `get_mut()`, tha an neo-shàbhailteachd ceart gu leòr oir bha an t-iomradh againn an dàrna cuid gun samhail an toiseach, no thàinig e gu bhith na aon air a bhith a `clònadh na bha ann.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Tillidh tu iomradh gluasadach a-steach don `Arc` a chaidh a thoirt seachad, mura h-eil comharran `Arc` no [`Weak`] eile ann chun an aon riarachadh.
    ///
    ///
    /// A `tilleadh [`None`] air dhòigh eile, seach nach eil e sàbhailte luach co-roinnte a thionndadh.
    ///
    /// Faic cuideachd [`make_mut`][make_mut], a bheir [`clone`][clone] an luach a-staigh nuair a tha comharran eile ann.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Tha an neo-shàbhailteachd seo ceart gu leòr oir tha sinn a `gealltainn gur e am puing a thilleas an aon *neach-comharrachaidh* a thèid a thilleadh gu T.
            // Tha an cunntas iomraidh againn cinnteach gu bheil 1 aig an ìre seo, agus dh `fheum sinn gur e `mut` an Arc fhèin, agus mar sin tha sinn a` tilleadh an aon iomradh a dh `fhaodadh a bhith air an dàta a-staigh.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// A `tilleadh iomradh gluasadach a-steach don `Arc` a chaidh a thoirt seachad, gun sgrùdadh sam bith.
    ///
    /// Faic cuideachd [`get_mut`], a tha sàbhailte agus a nì sgrùdaidhean iomchaidh.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Chan fhaodar comharran `Arc` no [`Weak`] sam bith eile a thoirt don aon riarachadh a bhith air an dì-chlàradh fhad `s a mhaireas an iasad a chaidh a thilleadh.
    ///
    /// Tha seo fìor gu h-obann mura h-eil leithid de chomharran ann, mar eisimpleir dìreach às deidh `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Tha sinn faiceallach gun *gun* teisteanas a chruthachadh a `còmhdach raointean "count", oir bhiodh seo a` tighinn còmhla ri ruigsinneachd co-shìnte air na cunntasan iomraidh (me.
        // le `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Obraich a-mach an e seo an t-iomradh sònraichte (a `toirt a-steach tagraidhean lag) don dàta bunaiteach.
    ///
    ///
    /// Thoir fa-near gu feum seo an cunntadh ref lag a ghlasadh.
    fn is_unique(&mut self) -> bool {
        // glas a `chunntair lag ma tha e coltach gur sinn an aon neach-gleidhidh lag.
        //
        // Bidh an leubail togail an seo a `dèanamh cinnteach gum bi dàimh a` tachairt ro làimh le sgrìobhadh sam bith gu `strong` (gu sònraichte ann an `Weak::upgrade`) mus tig lughdachadh air a `chunntas `weak` (tro `Weak::drop`, a bhios a` cleachdadh sgaoileadh).
        // Mura deach an t-ùrachadh lag ùraichte a leigeil sìos a-riamh, bidh an CAS an seo a `fàilligeadh agus mar sin chan eil dragh againn sioncronachadh.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Feumaidh seo a bhith na `Acquire` gus sioncronachadh le lughdachadh a `chunntair `strong` ann an `drop`-an aon ruigsinneachd a thachras nuair a thathar a` leigeil às an iomradh mu dheireadh.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Tha an sgrìobhadh naidheachd an seo a `sioncronadh le leughadh ann an `downgrade`, gu h-èifeachdach a` cur casg air an leughadh gu h-àrd de `strong` bho bhith a `tachairt às deidh an sgrìobhadh.
            //
            //
            self.inner().weak.store(1, Release); // leig às a `ghlas
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Drops an `Arc`.
    ///
    /// Bidh seo a `lughdachadh a` chunntais iomraidh làidir.
    /// Ma tha an cunntas iomraidh làidir a `ruighinn neoni is e na h-aon iomraidhean eile (ma tha sin ann) [`Weak`], mar sin bidh sinn `drop` an luach a-staigh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Cha chlò-bhualadh dad
    /// drop(foo2);   // Clò-bhualadh "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Seach `fetch_sub` atamach mar-thà, chan eil sinn a dh'fheumas synchronize eile le ceangal a-nall mur eil sinn a 'dol a sguabadh às nì.
        // Tha an aon loidsig a `buntainn ris an `fetch_sub` gu h-ìosal ris a` chunntas `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Tha feum air an fheansa seo gus casg a chuir air ath-òrdachadh cleachdadh an dàta agus cuir às don dàta.
        // Leis gu bheil e air a chomharrachadh `Release`, tha lughdachadh a `chunntais iomraidh a` sioncronadh leis an fheansa `Acquire` seo.
        // Tha seo a `ciallachadh gum bi cleachdadh an dàta a` tachairt mus lughdaich e an àireamh iomraidh, a thachras ron fheansa seo, a thachras mus tèid an dàta a dhubhadh às.
        //
        // Mar a chaidh a mhìneachadh san [Boost documentation][1],
        //
        // > Tha e cudromach gun cuir thu a-steach ruigsinneachd sam bith air an nì ann an aon
        // > snàithlean (tro iomradh a tha ann mar-thà) gus *tachairt mus* cuir às
        // > an nì ann an snàithlean eadar-dhealaichte.Tha seo air a choileanadh le "release"
        // > obrachadh às deidh dhut iomradh a leigeil sìos (ruigsinneachd sam bith air an nì
        // > tron iomradh seo gu cinnteach air tachairt roimhe seo), agus an
        // > "acquire" obrachadh mus cuir thu às an nì.
        //
        // Gu sònraichte, ged a tha susbaint Arc mar as trice neo-ghluasadach, tha e comasach sgrìobhadh a-staigh a sgrìobhadh gu rudeigin mar Mutex<T>.
        // Leis nach fhaighear Mutex nuair a thèid a dhubhadh às, chan urrainn dhuinn a bhith an urra ri loidsig sioncronaidh gus sgrìobhaidhean a dhèanamh ann an snàithlean A ri fhaicinn le inneal-sgrios a tha a `ruith ann an snàithlean B.
        //
        //
        // Thoir fa-near cuideachd gum faodadh e bhith gu bheil feansa Acquire an àite feansa Acquire an seo, a dh `fhaodadh coileanadh a leasachadh ann an suidheachaidhean làn connspaid.Faic [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Feuch ri an `Arc<dyn Any + Send + Sync>` a thoirt sìos gu seòrsa cruadhtan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// A `togail `Weak<T>` ùr, gun a bhith a` riarachadh cuimhne sam bith.
    /// Bidh a bhith a `gairm [`upgrade`] air an luach tillidh an-còmhnaidh a` toirt [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Seòrsa cuideachaidh gus cothrom a thoirt do na h-àireamhan iomraidh gun a bhith a `dèanamh beachdan sam bith mun raon dàta.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// A `tilleadh stiùireadh amh chun an nì `T` air a bheil an `Weak<T>` seo a` toirt iomradh.
    ///
    /// Chan eil am puing dligheach ach ma tha cuid de dh `iomraidhean làidir ann.
    /// Faodaidh am puing a bhith crochte, gun ainm no eadhon [`null`] air dhòigh eile.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Tha na dhà a `comharrachadh an aon rud
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Bidh an làidir an seo ga chumail beò, gus am faigh sinn cothrom air an rud fhathast.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ach chan ann tuilleadh.
    /// // Faodaidh sinn dhèanamh weak.as_ptr(), ach a 'faighinn cothrom a' chomharra a leanadh gu undefined giùlan.
    /// // assert_eq! ("hello", mì-shàbhailte {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ma tha am puing a `crochadh, tillidh sinn an sentinel gu dìreach.
            // Chan urrainn seo a bhith na sheòladh pàighidh dligheach, oir tha an t-uallach pàighidh co-dhiù co-thaobhach ri ArcInner (usize).
            ptr as *const T
        } else {
            // SÀBHAILTEACHD: ma thilleas is_dangling meallta, tha an comharradh dereferencable.
            // Faodar an t-uallach pàighidh a leigeil sìos aig an ìre seo, agus feumaidh sinn tùsachd a chumail suas, mar sin cleachd làimhseachadh puing amh.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// A `caitheamh an `Weak<T>` agus ga thionndadh gu bhith na chomharradh amh.
    ///
    /// Bidh seo ag atharrachadh a `phuing lag gu bhith na chomharraiche amh, fhad` s a tha e fhathast a `gleidheadh seilbh aon iomradh lag (chan eil an cunntas lag air atharrachadh leis an obrachadh seo).
    /// Faodar a thionndadh air ais don `Weak<T>` le [`from_raw`].
    ///
    /// Tha na h-aon chuingealachaidhean ann a bhith a `faighinn cothrom air targaid a` phuing mar a tha le [`as_ptr`] a `buntainn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Bidh e ag atharrachadh puing amh a chaidh a chruthachadh roimhe le [`into_raw`] air ais gu `Weak<T>`.
    ///
    /// Faodaidh seo a bhith air a chleachdadh gu sàbhailte fhaighinn làidir iomradh (le fòn [`upgrade`] an dèidh sin) no deallocate an lag cunntadh le tadhal air an `Weak<T>`.
    ///
    /// Bidh e a `gabhail seilbh air aon iomradh lag (ach a-mhàin comharran a chruthaich [`new`], leis nach eil dad aca sin; tha an dòigh fhathast ag obair orra).
    ///
    /// # Safety
    ///
    /// Feumaidh gun tàinig am puing bhon [`into_raw`] agus feumaidh e fhathast an iomradh lag a dh'fhaodadh a bhith aige.
    ///
    /// Tha e ceadaichte don chunntas làidir a bhith 0 aig àm gairm seo.
    /// Ach a dh `aindeoin sin, tha seo a` gabhail seilbh air aon iomradh lag a tha an-dràsta air a riochdachadh mar chomharradh amh (chan eil an cunntas lag air atharrachadh leis an obrachadh seo) agus mar sin feumar a bhith air a chàradh le gairm roimhe gu [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Lùghdaich an cunntadh lag mu dheireadh.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Faic Weak::as_ptr airson co-theacsa air mar a thig am puing inntrigidh.

        let ptr = if is_dangling(ptr as *mut T) {
            // 'S e seo crochte Lag.
            ptr as *mut ArcInner<T>
        } else {
            // Rud eile, tha sinn cinnteach gun tàinig am fiosaiche bho lag nondangling.
            // SÀBHAILTEACHD: tha data_offset sàbhailte a ghairm, oir tha ptr a `toirt iomradh air T. fìor (a dh` fhaodadh a bhith air tuiteam).
            let offset = unsafe { data_offset(ptr) };
            // Mar sin, bidh sinn a `cur cùl ris a` chothromachadh gus an RcBox gu lèir fhaighinn.
            // SÀBHAILTEACHD: thàinig am puing bho lag, agus mar sin tha am frith-rathad seo sàbhailte.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SÀBHAILTEACHD: tha sinn a-nis air am puing Weak tùsail fhaighinn air ais, agus mar sin is urrainn dhuinn an Lag a chruthachadh.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// A `feuchainn ris a` phuing `Weak` ùrachadh gu [`Arc`], a `cur dàil air tuiteam den luach a-staigh ma tha e soirbheachail.
    ///
    ///
    /// A `tilleadh [`None`] ma chaidh an luach a-staigh a leigeil sìos bhon uair sin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Dèan sgrios air gach moladh làidir.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Bidh sinn a `cleachdadh lùb CAS gus an cunntadh làidir àrdachadh an àite fetch_add oir cha bu chòir don ghnìomh seo an cunntas iomraidh a thoirt bho neoni gu aon.
        //
        //
        let inner = self.inner()?;

        // Uallach fois oir tha sgrìobhadh sam bith de 0 as urrainn dhuinn a choimhead a `fàgail an raon ann an staid maireannach neoni (mar sin tha leughadh "stale" de 0 gu math), agus tha luach sam bith eile air a dhearbhadh tron CAS gu h-ìosal.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Faic beachdan ann an `Arc::clone` airson carson a bhios sinn a `dèanamh seo (airson `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Tha fois gu math ceart airson a `chùis fàilligeadh oir chan eil dùil sam bith againn mun stàit ùr.
            // Tha feum air togail airson a `chùis soirbheachaidh gus sioncronadh le `Arc::new_cyclic`, nuair a dh` fhaodar an luach a-staigh a thòiseachadh an dèidh do iomraidhean `Weak` a bhith air an cruthachadh mu thràth.
            // Anns a `chùis sin, tha sinn an dùil cumail ris an luach làn-tòiseachaidh.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null sgrùdadh gu h-àrd
                Err(old) => n = old,
            }
        }
    }

    /// Faigh an àireamh de chomharran (`Arc`) làidir a tha a `comharrachadh an riarachadh seo.
    ///
    /// Ma chaidh `self` a chruthachadh a `cleachdadh [`Weak::new`], tillidh seo 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// A `faighinn tuairmse den àireamh de chomharran `Weak` a tha a` comharrachadh an riarachadh seo.
    ///
    /// Ma chaidh `self` a chruthachadh a `cleachdadh [`Weak::new`], no mura h-eil comharran làidir air fhàgail, tillidh seo 0.
    ///
    /// # Accuracy
    ///
    /// Air sgàth mion-fhiosrachadh buileachaidh, faodaidh an luach a chaidh a thilleadh a bhith dheth le 1 gach taobh nuair a bhios snàithleanan eile a `làimhseachadh` Arc`s no`Weak`s a tha a` comharrachadh an aon riarachadh.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Bho chunnaic sinn gu robh co-dhiù aon neach-comharrachaidh làidir ann às deidh dhuinn an cunntas lag a leughadh, tha fios againn gu robh an iomradh lag a tha ri thuigsinn (an làthair nuair a tha iomraidhean làidir beò) fhathast timcheall nuair a chunnaic sinn an cunntadh lag, agus mar sin is urrainn dhuinn a thoirt air falbh gu sàbhailte.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// A `tilleadh `None` nuair a tha am puing crochte agus nach eil `ArcInner` air a riarachadh, (ie, nuair a chaidh an `Weak` seo a chruthachadh le `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Tha sinn faiceallach gun *gun* teisteanas a chruthachadh a `còmhdach an raon "data", oir dh` fhaodadh an raon a bhith air a thionndadh aig an aon àm (mar eisimpleir, ma thèid an `Arc` mu dheireadh a leigeil sìos, thèid an raon dàta a leigeil sìos na àite).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// A `tilleadh `true` ma tha an dà` lag a`comharrachadh an aon riarachadh (coltach ri [`ptr::eq`]), no mura h-eil an dà chuid a`comharrachadh riarachadh sam bith (oir chaidh an cruthachadh le `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Leis gu bheil seo a `dèanamh coimeas eadar molaidhean tha e a` ciallachadh gum bi `Weak::new()` co-ionann ri chèile, eadhon ged nach eil iad a `comharrachadh riarachadh sam bith.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// A `dèanamh coimeas eadar `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// A `dèanamh clon den phuing `Weak` a tha a` comharrachadh an aon riarachadh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Faic beachdan ann an Arc::clone() airson carson a tha seo socair.
        // Faodaidh seo fetch_add a chleachdadh (gun aire a thoirt don ghlas) oir chan eil an cunntadh lag glaiste ach far nach eil *comharran lag* eile ann.
        //
        // (Mar sin chan urrainn dhuinn a bhith a `ruith a` chòd seo sa chùis sin).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Faic beachdan ann an Arc::clone() airson carson a bhios sinn a `dèanamh seo (airson mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// A `togail `Weak<T>` ùr, gun a bhith a` riarachadh cuimhne.
    /// Bidh a bhith a `gairm [`upgrade`] air an luach tillidh an-còmhnaidh a` toirt [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Drops a `phuing `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Cha chlò-bhualadh dad
    /// drop(foo);        // Clò-bhualadh "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Ma gheibh sinn a-mach gur e sinne an neach-comharrachaidh lag mu dheireadh, an uairsin tha an ùine aige an dàta a thuigsinn gu tur.Faic an deasbad ann an Arc::drop() mu na h-òrdughan cuimhne
        //
        // Chan fheumar sgrùdadh a dhèanamh airson an stàit glaiste an seo, oir chan urrainnear an cunntadh lag a ghlasadh mura robh dìreach aon ref lag ann, a `ciallachadh nach fhaodadh tuiteam ach ruith às deidh sin air an ref lag a tha air fhàgail, nach urrainn tachairt ach às deidh a` ghlas a leigeil ma sgaoil.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Tha sinn a `dèanamh an speisealachadh seo an seo, agus chan ann mar optimization nas fharsainge air `&T`, oir bhiodh e air dhòigh eile a` cur cosgais ris a h-uile sgrùdadh co-ionannachd air refs.
/// Tha sinn a `gabhail ris gu bheil` Arc`s air an cleachdadh gus luachan mòra a stòradh, a tha slaodach gu clone, ach cuideachd trom airson sgrùdadh airson co-ionannachd, ag adhbhrachadh gum bi a`chosgais seo a` pàigheadh nas fhasa.
///
/// Tha e cuideachd nas dualtaiche dà chlòn `Arc` a bhith agad, a tha a `comharrachadh an aon luach, na dà`&T`s.
///
/// Chan urrainn dhuinn seo a dhèanamh ach nuair a dh `fhaodadh `T: Eq` mar `PartialEq` a bhith a dh`aona ghnothach neo-shùbailte.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Co-ionannachd airson dà `Arc`.
    ///
    /// Tha dà `Arc` co-ionann ma tha na luachan a-staigh aca co-ionann, eadhon ged a tha iad air an stòradh ann an riarachadh eadar-dhealaichte.
    ///
    /// Ma tha `T` cuideachd a `buileachadh `Eq` (a` ciallachadh sùbailteachd co-ionannachd), tha dà `Arc` a tha a` comharrachadh an aon riarachadh an-còmhnaidh co-ionann.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Neo-ionannachd airson dà `Arc`s.
    ///
    /// Tha dà `Arc` neo-chothromach ma tha na luachan a-staigh aca neo-ionann.
    ///
    /// Ma tha `T` cuideachd a `buileachadh `Eq` (a` ciallachadh sùbailteachd co-ionannachd), tha dà `Arc` a tha a` comharrachadh an aon luach a-riamh neo-chothromach.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Coimeas pàirt airson dà `Arc`s.
    ///
    /// Tha an dà rud air an coimeas le bhith a `gairm `partial_cmp()` air na luachan a-staigh aca.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Nas lugha na coimeas airson dà `Arc`s.
    ///
    /// Tha an dà rud air an coimeas le bhith a `gairm `<` air na luachan a-staigh aca.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Coimeas `nas lugha na no co-ionann ri` airson dà `Arc`.
    ///
    /// Tha an dà rud air an coimeas le bhith a `gairm `<=` air na luachan a-staigh aca.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Coimeas nas motha na dà `Arc`s.
    ///
    /// Tha an dà rud air an coimeas le bhith a `gairm `>` air na luachan a-staigh aca.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Coimeas 'nas motha na no co-ionann ri' airson dà `Arc`.
    ///
    /// Tha an dà rud air an coimeas le bhith a `gairm `>=` air na luachan a-staigh aca.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Coimeas airson dà `Arc`s.
    ///
    /// Tha an dà rud air an coimeas le bhith a `gairm `cmp()` air na luachan a-staigh aca.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// A `cruthachadh `Arc<T>` ùr, leis an luach `Default` airson `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Thoir seachad sliseag le cunntas fiosrachaidh agus lìon e le bhith a `cliogadh nithean` v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Thoir seachad `str` le cunntas iomraidh agus dèan lethbhreac de `v` a-steach.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Thoir seachad `str` le cunntas iomraidh agus dèan lethbhreac de `v` a-steach.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Gluais nì ann am bogsa gu riarachadh ùr le cunntas fiosrachaidh.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Thoir seachad sliseag le cunntas iomraidh agus gluais nithean `v` a-steach ann.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Leig leis an Vec a chuimhne a shaoradh, ach gun a susbaint a sgrios
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// A `toirt gach eileamaid den `Iterator` agus ga chruinneachadh a-steach do `Arc<[T]>`.
    ///
    /// # Feartan coileanaidh
    ///
    /// ## A `chùis choitcheann
    ///
    /// Anns a `chùis choitcheann, tha cruinneachadh a-steach do `Arc<[T]>` air a dhèanamh le bhith a` cruinneachadh a-steach do `Vec<T>` an toiseach.Is e sin, nuair a sgrìobhas tu na leanas:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// tha seo gad ghiùlan fhèin mar gum biodh sinn a `sgrìobhadh:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Bidh a `chiad sheata de riarachadh a` tachairt an seo.
    ///     .into(); // Tha dàrna riarachadh airson `Arc<[T]>` a `tachairt an seo.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Bidh seo a `riarachadh uimhir de thursan` s a dh `fheumar airson an `Vec<T>` a thogail agus an uairsin riaraichidh e aon uair airson an `Vec<T>` a thionndadh chun `Arc<[T]>`.
    ///
    ///
    /// ## Iterators de fhad aithnichte
    ///
    /// Nuair a chuireas an `Iterator` agad `TrustedLen` an gnìomh agus gu bheil e de mheud sònraichte, thèid aon riarachadh a dhèanamh airson an `Arc<[T]>`.Mar eisimpleir:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Tha dìreach aon riarachadh a `tachairt an seo.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Speisealachadh trait air a chleachdadh airson cruinneachadh a-steach do `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Is e seo a `chùis airson iterator `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SÀBHAILTEACHD: Feumaidh sinn dèanamh cinnteach gu bheil fad ceart aig an iterator agus a th `againn.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Teich air ais gu buileachadh àbhaisteach.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Faigh an cothromachadh taobh a-staigh `ArcInner` airson an t-uallach pàighidh air cùl puing.
///
/// # Safety
///
/// Feumaidh an neach-comharrachaidh iomradh a thoirt air (agus meata-dàta dligheach a bhith aige airson) eisimpleir T a bha dligheach roimhe, ach tha cead aig an T a bhith air a leigeil seachad.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Co-thaobhadh an luach gun luach gu deireadh an ArcInner.
    // Leis gur e repr(C) a th `ann an RcBox, bidh e an-còmhnaidh mar an raon mu dheireadh mar chuimhneachan.
    // Sàbhailteachd: a mhàin unsized bho na seòrsaichean ghabhas tha sliseagan, trait Rudan,
    // agus seòrsachan taobh a-muigh, tha an riatanas sàbhailteachd inntrigidh gu leòr an-dràsta gus riatanasan align_of_val_raw a shàsachadh;is e seo mion-fhiosrachadh buileachaidh den chànan nach fhaodar earbsa a bhith taobh a-muigh std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}