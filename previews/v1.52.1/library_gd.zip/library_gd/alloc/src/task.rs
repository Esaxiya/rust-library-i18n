#![stable(feature = "wake_trait", since = "1.51.0")]
//! Seòrsan agus Traits airson a bhith ag obair le gnìomhan asyncronach.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Cur an gnìomh gnìomh a dhùsgadh air neach-cùraim an tiomnaidh.
///
/// Faodar an trait seo a chleachdadh gus [`Waker`] a chruthachadh.
/// Faodaidh neach-cùraim an tiomnaidh an trait seo a mhìneachadh, agus sin a chleachdadh gus Waker a thogail gus a dhol gu na gnìomhan a thèid a choileanadh air an neach-cùraim sin.
///
/// Tha an trait seo na roghainn cuimhne-sàbhailte agus ergonomic an àite [`RawWaker`] a thogail.
/// Tha e a `toirt taic don dealbhadh tiomnaidh cumanta anns a bheil an dàta a thathar a` cleachdadh gus gnìomh a dhùsgadh air a stòradh ann an [`Arc`].
/// Chan urrainn do chuid de luchd-cùraim an tiomnaidh (gu sònraichte an fheadhainn airson siostaman freumhaichte) an API seo a chleachdadh, agus is e sin as coireach gu bheil [`RawWaker`] ann mar roghainn eile airson nan siostaman sin.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Dreuchd `block_on` bunaiteach a bheir future agus a ruitheas e gu crìochnachadh air an t-snàthainn gnàthach.
///
/// **Note:** Tha an eisimpleir seo a `malairt ceartas airson sìmplidheachd.
/// Gus casg a chuir air deadlocks, feumaidh buileachadh ìre toraidh dèiligeadh ri gairmean eadar-mheadhanach gu `thread::unpark` a bharrachd air cuiridhean neadachaidh.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Bana-bhuidseach a dhùisgeas an t-snàthainn gnàthach nuair a thèid a ghairm.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Ruith future gu crìochnachadh air an t-snàthainn gnàthach.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Pin an future gus an tèid a phoileachadh.
///     let mut fut = Box::pin(fut);
///
///     // Cruthaich co-theacs ùr airson a chuir air adhart chun future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Ruith an future gu crìochnachadh.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Dùisg an obair seo.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Dùisg an obair seo gun a bhith ag ithe an neach-glacaidh.
    ///
    /// Ma tha neach-cùraim an tiomnaidh a `toirt taic do dhòigh nas saoire a bhith a` dùsgadh gun a bhith ag ithe an neach-glacaidh, bu chòir dha a dhol thairis air an dòigh seo.
    /// Gu gnàthach, bidh e a `gleusadh an [`Arc`] agus a` gairm [`wake`] air a `chlon.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SÀBHAILTEACHD: Tha seo sàbhailte oir bidh raw_waker a `togail gu sàbhailte
        // RawWaker bho Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Tha an gnìomh prìobhaideach seo airson RawWaker a thogail air a chleachdadh, seach
// a `toirt seo a-steach don impl `From<Arc<W>> for RawWaker`, gus dèanamh cinnteach nach eil sàbhailteachd `From<Arc<W>> for Waker` an urra ris an t-seirbheis trait ceart, an àite sin bidh an dà impls a` gairm a `ghnìomh seo gu dìreach agus gu follaiseach.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Meudaich cunntas iomraidh an arc gus a cloneadh.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Wake le luach, a `gluasad an Arc a-steach don ghnìomh Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Dùisg le bhith a `toirt iomradh, cuir am frasair ann am ManuallyDrop gus nach leig thu às e
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Lùghdaich àireamh iomraidh an Arc air drop
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}