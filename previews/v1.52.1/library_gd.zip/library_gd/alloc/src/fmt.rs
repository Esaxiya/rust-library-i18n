//! Goireasan airson cruth agus clò-bhualadh `String`s.
//!
//! Anns a `mhodal seo tha an taic ruith-ùine airson leudachadh co-aonta [`format!`].
//! Tha am macro seo air a bhuileachadh anns an inneal-cruinneachaidh gus fiosan a thoirt don mhodal seo gus argamaidean a chruth aig àm-ruith gu sreathan.
//!
//! # Usage
//!
//! Thathas an dùil gum bi am macro [`format!`] eòlach air an fheadhainn a tha a `tighinn bho ghnìomhan C's `printf`/`fprintf` no gnìomh `str.format` Python.
//!
//! Eisimpleirean de na [`format!`] leudachan tha:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" le prìomh zeros
//! ```
//!
//! Bhon fheadhainn sin, chì thu gur e sreang cruth a th `anns a` chiad argamaid.Tha an neach-cruinneachaidh ag iarraidh gum bi seo litireil sreang;chan urrainnear caochladair a thoirt a-steach (gus sgrùdadh dligheachd a dhèanamh).
//! An uairsin cuiridh an t-inneal-cruinneachaidh an sreang cruth a-mach agus co-dhùinidh e a bheil an liosta argamaidean a chaidh a thoirt seachad freagarrach airson a thoirt don t-sreang cruth seo.
//!
//! Gus aon luach a thionndadh gu sreang, cleachd am modh [`to_string`].Cleachdaidh seo an cruth [`Display`] trait.
//!
//! ## Paramadairean suidheachaidh
//!
//! Tha cead aig gach argamaid cruth a bhith a `sònrachadh dè an argamaid luach a tha e a` toirt iomradh, agus ma thèid fhàgail às, thathas a `gabhail ris gur e "the next argument" a th` ann.
//! Mar eisimpleir, bheireadh an sreang cruth `{} {} {}` trì paramadairean, agus bhiodh iad air an cruth anns an aon òrdugh 'sa tha iad air an toirt seachad.
//! Bhiodh an sreang cruth `{2} {1} {0}`, ge-tà, a `cur cruth air argamaidean ann an òrdugh cas.
//!
//! Faodaidh cùisean a bhith beagan duilich nuair a thòisicheas tu a `dèanamh eadar-mheasgachadh den dà sheòrsa de shònrachadh suidheachadh.Faodar smaoineachadh air an t-sònrachadh "next argument" mar iterator thairis air an argamaid.
//! Gach uair a chithear sònrachadh "next argument", bidh an iterator ag adhartachadh.Bidh seo a `leantainn gu giùlan mar seo:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Cha deach an itealaiche a-staigh thairis air an argamaid adhartachadh leis an àm a chithear a `chiad `{}`, agus mar sin bidh e a` clò-bhualadh a `chiad argamaid.An uairsin nuair a ruigeas e an dàrna `{}`, tha an iterator air a dhol air adhart chun dàrna argamaid.
//! Gu bunaiteach, chan eil paramadairean a tha ag ainmeachadh an argamaid aca gu sònraichte a `toirt buaidh air paramadairean nach eil ag ainmeachadh argamaid a thaobh sònrachaidhean suidheachaidh.
//!
//! Feumar sreang cruth gus na h-argamaidean gu lèir aige a chleachdadh, air dhòigh eile is e mearachd ùine cur ri chèile a th `ann.Faodaidh tu iomradh a thoirt air an aon argamaid barrachd air aon uair anns an t-sreang cruth.
//!
//! ## Paramadairean ainmichte
//!
//! Chan eil Rust fhèin co-ionnan ri Python de pharamadairean ainmichte ri gnìomh, ach tha am macro [`format!`] na leudachadh co-aonta a leigeas leis luathachadh paramadairean ainmichte.
//! Tha paramadairean ainmichte air an liostadh aig deireadh liosta nan argamaidean agus tha an co-aonta:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Mar eisimpleir, tha na h-abairtean [`format!`] a leanas uile a `cleachdadh argamaid ainmichte:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Chan eil e dligheach paramadairean suidheachaidh a chuir (an fheadhainn gun ainmean) às deidh argamaidean aig a bheil ainmean.Coltach ri paramadairean suidheachaidh, chan eil e dligheach a bhith a `toirt seachad paramadairean ainmichte nach eil air an cleachdadh leis an t-sreang cruth.
//!
//! # Paramadairean cruth
//!
//! Faodaidh gach argamaid a tha air a chruth-atharrachadh a bhith air atharrachadh le grunn pharaimearan cruth (a `freagairt ri `format_spec` ann an [the syntax](#syntax)).Tha na paramadairean sin a` toirt buaidh air riochdachadh sreang de na thathar a `cruth.
//!
//! ## Width
//!
//! ```
//! // Bidh iad sin uile a `clò-bhualadh "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Is e paramadair a tha seo airson an "minimum width" a bu chòir an cruth a ghabhail.
//! Mura lìon sreang an luach an iomadh caractar seo, thèid am pleadhag a tha air a shònrachadh le fill/alignment a chleachdadh gus an àite a tha a dhìth a ghabhail (faic gu h-ìosal).
//!
//! Faodar an luach airson an leud a thoirt seachad cuideachd mar [`usize`] anns an liosta de pharamadairean le bhith a `cur postfix `$` ris, a` nochdadh gur e [`usize`] an dàrna argamaid a tha a `sònrachadh an leud.
//!
//! Chan eil a bhith a `toirt iomradh air argamaid le co-aonta an dolar a` toirt buaidh air a `chunntair "next argument", mar sin mar as trice is e deagh bheachd a th` ann iomradh a thoirt air argamaidean a rèir suidheachadh, no argamaidean ainmichte a chleachdadh.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Tha an caractar lìonaidh roghainneil agus co-thaobhadh air a thoirt seachad mar as trice ann an co-bhonn ris a `paramadair [`width`](#width).Feumar a mhìneachadh ro `width`, dìreach às deidh an `:`.
//! Tha seo a `sealltainn ma tha an luach a thathar a` cruth nas lugha na `width` thèid cuid de charactaran a bharrachd a chlò-bhualadh timcheall air.
//! Tha lìonadh a `tighinn anns na tionndaidhean a leanas airson co-thaobhadh eadar-dhealaichte:
//!
//! * `[fill]<` - tha an argamaid air a cho-thaobhadh ann an colbhan `width`
//! * `[fill]^` - tha an argamaid stèidhichte sa mheadhan ann an colbhan `width`
//! * `[fill]>` - tha an argamaid ceangailte gu ceart ann an colbhan `width`
//!
//! Is e an [fill/alignment](#fillalignment) bunaiteach airson neo-àireamhan àite agus co-thaobhadh clì.Tha an roghainn airson cruth-àireamhan àireamhach cuideachd na charactar àite ach le co-thaobhadh ceart.
//! Ma tha bratach `0` (faic gu h-ìosal) air a shònrachadh airson àireamhan, is e an caractar lìonaidh so-thuigsinn `0`.
//!
//! Thoir fa-near gur dòcha nach bi co-thaobhadh le cuid de sheòrsan.Gu sònraichte, chan eil e air a bhuileachadh san fharsaingeachd airson an `Debug` trait.
//! Is e dòigh math air dèanamh cinnteach gu bheil pleadhag air a chuir a-steach gus cruth a chuir air do chuir a-steach, an uairsin cuir a-steach an sreang seo gus an toradh agad fhaighinn:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Halo Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Tha iad sin uile nam brataichean ag atharrachadh giùlan an cruth.
//!
//! * `+` - Tha seo an dùil airson seòrsachan àireamhach agus tha e a `nochdadh gum bu chòir an soidhne a bhith air a chlò-bhualadh an-còmhnaidh.Cha tèid soidhnichean adhartach a chlò-bhualadh gu bunaiteach, agus cha tèid an soidhne àicheil a chlò-bhualadh ach gu bunaiteach airson an `Signed` trait.
//! Tha am bratach seo a `nochdadh gum bu chòir an soidhne ceart (`+` no `-`) a bhith air a chlò-bhualadh an-còmhnaidh.
//! * `-` - Gun chleachdadh an-dràsta
//! * `#` - Tha am bratach seo a `nochdadh gum bu chòir an cruth clò-bhualaidh "alternate" a chleachdadh.Is iad na cruthan eile:
//!     * `#?` - deas-chlò-bhualadh an cruth [`Debug`]
//!     * `#x` - ron argamaid le `0x`
//!     * `#X` - ron argamaid le `0x`
//!     * `#b` - ron argamaid le `0b`
//!     * `#o` - ron argamaid le `0o`
//! * `0` - Tha seo air a chleachdadh gus sealltainn airson cruthan integer gum bu chòir an padding gu `width` a bhith air a dhèanamh le caractar `0` a bharrachd air a bhith mothachail air soidhnichean.
//! Bheireadh cruth mar `{:08}` toradh `00000001` airson an integer `1`, agus bheireadh an aon chruth `-0000001` airson an integer `-1`.
//! Mothaich gu bheil aon nas lugha na neoni anns an dreach àicheil na an dreach adhartach.
//!         Thoir fa-near gum bi zeros padding an-còmhnaidh air an cur às deidh an t-soidhne (ma tha sin ann) agus ro na h-àireamhan.Nuair a thèid an cleachdadh còmhla ris a `bhratach `#`, tha riaghailt coltach ris a` buntainn: tha zeros padding air an cuir a-steach às deidh an ro-leasachan ach ro na h-àireamhan.
//!         Tha an ro-leasachan air a thoirt a-steach don leud iomlan.
//!
//! ## Precision
//!
//! Airson seòrsachan neo-àireamhach, faodar seo a mheas mar "maximum width".
//! Ma tha an sreang a thig às a sin nas fhaide na an leud seo, tha e an uairsin air a theàrnadh don iomadh caractar seo agus tha an luach truncated sin air a sgaoileadh le `fill`, `alignment` agus `width` ceart ma tha na paramadairean sin air an suidheachadh.
//!
//! Airson seòrsachan riatanach, cha toirear aire dha seo.
//!
//! Airson seòrsan puing fleòdraidh, tha seo a `nochdadh cia mheud figear às deidh a` phuing deicheach a bu chòir a bhith air a chlò-bhualadh.
//!
//! Tha trì dòighean ann airson an `precision` a tha thu ag iarraidh a shònrachadh:
//!
//! 1. Integer `.N`:
//!
//!    is e an integer `N` fhèin an cruinneas.
//!
//! 2. Integer no ainm air a leantainn le soidhne dolar `.N$`:
//!
//!    cleachd cruth *argamaid*`N` (a dh `fheumas a bhith na `usize`) mar cho mionaideach.
//!
//! 3. Rionnag `.*`:
//!
//!    `.*` a `ciallachadh gu bheil an `{...}` seo co-cheangailte ri cuir a-steach ann an cruth *dà* seach aon: tha a` chiad chur-a-steach a `cumail cruinneas `usize`, agus tha luach clò-bhualaidh aig an dàrna fear.
//!    Thoir fa-near, anns a `chùis seo, ma chleachdas aon an sreang cruth `{<arg>:<spec>.*}`, an uairsin tha am pàirt `<arg>` a` toirt iomradh air an* luach * airson clò-bhualadh, agus feumaidh an `precision` a thighinn a-steach ron `<arg>`.
//!
//! Mar eisimpleir, bidh na gairmean a leanas uile a `clò-bhualadh an aon rud `Hello x is 0.01000`:
//!
//! ```
//! // Is e Hello {arg 0 ("x")} {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Is e Hello {arg 1 ("x")} {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Is e Hello {arg 0 ("x")} {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Is e Hello {next arg ("x")} {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Is e Hello {next arg ("x")} {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Is e Hello {next arg ("x")} {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Fhad 'sa tha iad sin:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! clò-bhuail trì rudan gu math eadar-dhealaichte:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Ann an cuid de chànanan prògramaidh, tha giùlan gnìomhan cruth sreang an urra ri suidheachadh locale an t-siostam obrachaidh.
//! Chan eil bun-bheachd ionadail aig na gnìomhan cruth a tha leabharlann àbhaisteach Rust a `toirt seachad agus bheir iad seachad na h-aon toraidhean air a h-uile siostam ge bith dè an rèiteachadh a th` aig an neach-cleachdaidh.
//!
//! Mar eisimpleir, bidh an còd a leanas an-còmhnaidh a `clò-bhualadh `1.5` eadhon ged a bhios locale an t-siostaim a` cleachdadh dealaiche deicheach seach dot.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Faodar na caractaran litireil `{` agus `}` a thoirt a-steach ann an sreang le bhith air thoiseach orra leis an aon charactar.Mar eisimpleir, tha an caractar `{` air a theicheadh le `{{` agus tha an caractar `}` air teicheadh le `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Gus geàrr-chunntas, an seo gheibh thu gràmar iomlan sreangan cruth.
//! Tha an co-chòrdadh airson a `chànan cruth a thathar a` cleachdadh air a tharraing bho chànanan eile, mar sin cha bu chòir dha a bhith ro coimheach.Tha argumaidean air an cruth le co-aonta coltach ri Python, a `ciallachadh gu bheil argamaidean air an cuairteachadh le `{}` an àite an `%` coltach ri C.
//! Is e an fhìor ghràmar airson an cruth cruth:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Anns a `ghràmar gu h-àrd, is dòcha nach bi caractaran `'{'` no `'}'` ann an `text`.
//!
//! # A `cruth traits
//!
//! Nuair a dh `iarras tu argamaid a bhith air a chruth le seòrsa sònraichte, tha thu gu dearbh ag iarraidh gum bi argamaid a` buntainn ri trait sònraichte.
//! Leigidh seo le iomadh seòrsa fìor a bhith air an cruth tro `{:x}` (mar [`i8`] a bharrachd air [`isize`]).Is e am mapadh gnàthach de sheòrsaichean gu traits:
//!
//! * *dad* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] le integers hexadecimal ann an litrichean beaga
//! * `X?` ⇒ [`Debug`] le integers hexadecimal àrd-chùis
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Is e a tha seo a `ciallachadh gum faodar argamaid sam bith a chuireas an [`fmt::Binary`][`Binary`] trait an sàs ann an cruth `{:b}`.Tha buileachadh air a thoirt seachad airson na traits seo airson grunn sheòrsaichean prìomhadail leis an leabharlann àbhaisteach cuideachd.
//!
//! Mura h-eil cruth air a shònrachadh (mar ann an `{}` no `{:6}`), is e an cruth trait a chaidh a chleachdadh an [`Display`] trait.
//!
//! Nuair a chuireas tu cruth trait an gnìomh airson an seòrsa agad fhèin, feumaidh tu modh an ainm-sgrìobhte a chuir an gnìomh:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // an seòrsa àbhaisteach againn
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Thèid an seòrsa agad seachad mar fo-iomradh `self`, agus an uairsin bu chòir don ghnìomh toradh a chuir a-steach don t-sruth `f.buf`.Tha e an urra ri gach buileachadh trait cruth a bhith a `cumail gu ceart ris na paramadairean cruth a chaidh iarraidh.
//! Bidh luachan nam paramadairean sin air an liostadh ann an raointean structar [`Formatter`].Gus cuideachadh le seo, tha structar [`Formatter`] cuideachd a `toirt seachad cuid de dhòighean cuideachaidh.
//!
//! A bharrachd air an sin, is e luach tillidh a `ghnìomh seo [`fmt::Result`] a tha na sheòrsa eile de [` Toradh`]`<(),`[`std: : fmt::Mearachd`]`> `.
//! Bu chòir do bhuileachadh cruth dèanamh cinnteach gu bheil iad a `sgaoileadh mhearachdan bhon [`Formatter`] (me, nuair a bhios iad a` gairm [`write!`]).
//! Ach, cha bu chòir dhaibh mearachdan a thilleadh gu spuriously.
//! Is e sin, feumaidh buileachadh cruth agus mearachd a thilleadh ach ma thilleas an [`Formatter`] a chaidh a-steach mearachd.
//! Tha seo air sgàth, an aghaidh na tha an t-ainm-sgrìobhte gnìomh a `moladh, gur e obair neo-mhearachdach a th` ann an cruth sreang.
//! Chan eil an gnìomh seo ach a `tilleadh toradh oir dh` fhaodadh sgrìobhadh chun t-sruth a tha a `fàiligeadh fàiligeadh agus feumaidh e dòigh a thoirt seachad airson a bhith ag adhbhrachadh gun do thachair mearachd air ais suas a` chruach.
//!
//! Bhiodh eisimpleir de bhith a `buileachadh an cruth traits coltach:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Tha luach `f` a `buileachadh an `Write` trait, agus is e sin a tha an sgrìobhadh!tha dùil aig macro.
//!         // Thoir fa-near gu bheil an cruth seo a `seachnadh nam brataichean a tha air an toirt seachad airson sreangan cruth.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Bidh diofar traits a `ceadachadh diofar chruthan de sheòrsa de sheòrsa.
//! // Is e brìgh an cruth seo meud vector a chlò-bhualadh.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Thoir urram do na brataichean cruth le bhith a `cleachdadh an dòigh cuideachaidh `pad_integral` air an nì Formatter.
//!         // Faic na sgrìobhainnean modh airson mion-fhiosrachadh, agus faodar an gnìomh `pad` a chleachdadh gus sreangan a phasgadh.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Tha adhbharan sònraichte aig an dà chruth traits:
//!
//! - [`fmt::Display`][`Display`] tha buileachadh a `dearbhadh gum faodar an seòrsa a riochdachadh gu creideasach mar sreang UTF-8 an-còmhnaidh.Chan eilear an dùil ** gum bi a h-uile seòrsa a`buileachadh an [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] bu chòir buileachadh a chuir an gnìomh airson **gach** seòrsa poblach.
//!   Mar as trice bidh toradh a `riochdachadh na stàite a-staigh cho dìleas sa ghabhas.
//!   Is e adhbhar an [`Debug`] trait a bhith a `comasachadh còd debugging Rust.Anns a`mhòr-chuid de chùisean, tha cleachdadh `#[derive(Debug)]` gu leòr agus air a mholadh.
//!
//! Eisimpleirean den toradh bhon dà traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Macros co-cheangailte
//!
//! Tha grunn macros co-cheangailte anns an teaghlach [`format!`].Is iad an fheadhainn a tha air an cur an gnìomh an-dràsta:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Tha seo agus [`writeln!`] nan dà macros a tha air an cleachdadh gus an sreang cruth a sgaoileadh gu sruth sònraichte.Tha seo air a chleachdadh gus casg a chur air riarachadh eadar-mheadhanach de shreathan cruth agus an àite sin sgrìobh an toradh gu dìreach.
//! Fon chochall, tha an gnìomh seo gu dearbh a `toirt ionnsaigh air a` ghnìomh [`write_fmt`] a tha air a mhìneachadh air an [`std::io::Write`] trait.
//! Is e eisimpleir eisimpleir:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Bidh seo agus [`println!`] a `sgaoileadh an toradh gu stdout.Coltach ris an macro [`write!`], is e amas nam macros sin cuibhreannan eadar-mheadhanach a sheachnadh nuair a bhios iad a`clò-bhualadh toradh.Is e eisimpleir eisimpleir:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Tha na macros [`eprint!`] agus [`eprintln!`] co-ionann ri [`print!`] agus [`println!`], fa leth, ach bidh iad a `sgaoileadh an toradh gu stderr.
//!
//! ### `format_args!`
//!
//! Is e macro neònach a tha seo a thathas a `cleachdadh gus a dhol seachad gu sàbhailte air rud neo-shoilleir a` toirt cunntas air sreang an cruth.Chan fheum an nì seo riarachadh tiùrr sam bith a chruthachadh, agus chan eil e a `toirt iomradh ach air fiosrachadh mun chruach.
//! Fon chochall, tha na macros co-cheangailte uile air an cur an gnìomh a thaobh seo.
//! An toiseach, is e cleachdadh eisimpleir:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Is e toradh macro [`format_args!`] luach de sheòrsa [`fmt::Arguments`].
//! Faodar an structar seo an uairsin a chuir air adhart gu gnìomhan [`write`] agus [`format`] taobh a-staigh a `mhodal seo gus an sreang cruth a phròiseasadh.
//! Is e amas na macro seo tuilleadh casg a chuir air cuibhreannan eadar-mheadhanach nuair a bhios tu a `dèiligeadh ri sreangan cruth.
//!
//! Mar eisimpleir, dh `fhaodadh leabharlann logaidh an co-chòrdadh cruth àbhaisteach a chleachdadh, ach bhiodh e a` dol timcheall an structair seo gus am bi e air a dhearbhadh càite am bu chòir toradh a dhol.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Bidh an gnìomh `format` a `toirt structar [`Arguments`] agus a` tilleadh an sreang cruth a thàinig às.
///
///
/// Faodar an eisimpleir [`Arguments`] a chruthachadh leis an macro [`format_args!`].
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Thoir fa-near gur dòcha gum biodh e nas fheàrr [`format!`] a chleachdadh.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}