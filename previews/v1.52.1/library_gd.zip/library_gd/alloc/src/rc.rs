//! Molaidhean cunntais iomraidh le aon snàithlean.Tha 'Rc' a `seasamh airson` Reference
//! Counted'.
//!
//! Tha an seòrsa [`Rc<T>`][`Rc`] a `toirt seachad seilbh co-roinnte air luach de sheòrsa `T`, air a riarachadh sa chàrn.
//! Le bhith a `toirt cuireadh do [`clone`][clone] air [`Rc`] a` toirt a-mach stiùireadh ùr chun an aon riarachadh anns an tiùrr.
//! Nuair a thèid am puing [`Rc`] mu dheireadh gu riarachadh sònraichte a sgrios, tha an luach a tha air a stòradh san riarachadh sin (ris an canar gu tric "inner value") air a leigeil sìos cuideachd.
//!
//! Bidh iomraidhean co-roinnte ann an Rust a `dì-cheadachadh mùthadh gu bunaiteach, agus tha [`Rc`] mar eisgeachd: mar as trice chan urrainn dhut iomradh gluasadach fhaighinn air rudeigin taobh a-staigh [`Rc`].
//! Ma tha feum agad air mutability, cuir [`Cell`] no [`RefCell`] taobh a-staigh an [`Rc`];faic [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] a `cleachdadh cunntadh iomraidh neo-atamach.
//! Tha seo a `ciallachadh gu bheil os-cionn gu math ìosal, ach chan urrainnear [`Rc`] a chuir eadar snàithleanan, agus mar sin chan eil [`Rc`] a` buileachadh [`Send`][send].
//! Mar thoradh air an sin, nì an trusaiche Rust sgrùdadh *aig àm cur ri chèile* nach eil thu a `cur [` Rc`] s eadar snàithleanan.
//! Ma tha feum agad air cunntadh iomraidh ioma-snàthainn, atamach, cleachd [`sync::Arc`][arc].
//!
//! Faodar an dòigh [`downgrade`][downgrade] a chleachdadh gus stiùireadh [`Weak`] neo-seilbh a chruthachadh.
//! Faodaidh puing [`Weak`] a bhith [`ùrachadh`][ùrachadh] d gu [`Rc`], ach tillidh seo [`None`] ma chaidh an luach a tha air a stòradh san riarachadh a leigeil seachad mu thràth.
//! Ann am faclan eile, chan eil molaidhean `Weak` a `cumail an luach taobh a-staigh an riarachadh beò;ge-tà, bidh iad * a`cumail an riarachadh (an stòr taic airson an luach a-staigh) beò.
//!
//! Cha tèid cearcall eadar molaidhean [`Rc`] a thuigsinn gu bràth.
//! Air an adhbhar seo, thathas a `cleachdadh [`Weak`] gus cearcallan a bhriseadh.
//! Mar eisimpleir, dh `fhaodadh craobh a bhith le comharran làidir [`Rc`] bho nodan pàrant gu clann, agus molaidhean [`Weak`] bho chloinn air ais gu am pàrantan.
//!
//! `Rc<T>` fèin-ghluasad gu fèin-ghluasadach gu `T` (tron [`Deref`] trait), gus an urrainn dhut dòighean `T` a ghairm air luach de sheòrsa [`Rc<T>`][`Rc`].
//! Gus ainmean a sheachnadh le modhan `T`, tha modhan [`Rc<T>`][`Rc`] fhèin nan gnìomhan co-cheangailte, ris an canar [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Canar cuideachd gnìomhachadh traits mar `Clone` le bhith a`cleachdadh co-aonta làn teisteanais.
//! Is fheàrr le cuid de dhaoine criathragan làn theisteanais a chleachdadh, ach is fheàrr le cuid eile a bhith a `cleachdadh co-aonta modh-gairm.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Co-chòrdadh modh-gairm
//! let rc2 = rc.clone();
//! // Co-chòrdadh làn teisteanais
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] na fèin-ghluasad gu `T`, oir is dòcha gu bheil an luach a-staigh air a leigeil sìos mu thràth.
//!
//! # Iomraidhean clonaidh
//!
//! Thathas a `cruthachadh iomradh ùr air an aon riarachadh ri comharradh cunntais iomraidh gnàthaichte a` cleachdadh an `Clone` trait a chaidh a chuir an gnìomh airson [`Rc<T>`][`Rc`] agus [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Tha an dà chiallachadh gu h-ìosal co-ionann.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a agus b an dà chuid a `comharrachadh an aon àite cuimhne ri foo.
//! ```
//!
//! Is e an co-chòrdadh `Rc::clone(&from)` am fear as gnàthaiche leis gu bheil e a `toirt a-mach brìgh a` chòd nas soilleire.
//! Anns an eisimpleir gu h-àrd, tha an co-chòrdadh seo ga dhèanamh nas fhasa faicinn gu bheil an còd seo a `cruthachadh iomradh ùr seach a bhith a` dèanamh lethbhreac de shusbaint iomlan foo.
//!
//! # Examples
//!
//! Beachdaich air suidheachadh far a bheil seata de `Gadget`s le `Owner` sònraichte.
//! Tha sinn airson gum bi a `phuing` Gadget` againn chun an `Owner` aca.Chan urrainn dhuinn seo a dhèanamh le seilbh gun samhail, oir is dòcha gum buin barrachd air aon inneal don aon `Owner`.
//! [`Rc`] a `leigeil leinn `Owner` a cho-roinn eadar ioma` Gadget`s, agus an `Owner` a bhith air a riarachadh fhad` s a tha puingean `Gadget` sam bith ann.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... raointean eile
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... raointean eile
//! }
//!
//! fn main() {
//!     // Cruthaich `Owner` le cunntas iomraidh.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Cruthaich `Gadget`s a bhuineas do `gadget_owner`.
//!     // Le bhith a `gleusadh an `Rc<Owner>` bheir sinn stiùireadh ùr don aon riarachadh `Owner`, ag àrdachadh a` chunntais iomraidh sa phròiseas.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Cuir às don caochlaideach ionadail `gadget_owner` againn.
//!     drop(gadget_owner);
//!
//!     // A dh `aindeoin a bhith a` leigeil sìos `gadget_owner`, tha e comasach dhuinn fhathast ainm an `Owner` de na `Gadget`s a chlò-bhualadh.
//!     // Tha seo air sgàth nach do thuit sinn ach aon `Rc<Owner>`, chan e an `Owner` a tha e a `comharrachadh.
//!     // Cho fad `s a tha puingean `Rc<Owner>` eile aig an aon riarachadh `Owner`, bidh e beò.
//!     // Bidh an ro-mheasadh achaidh `gadget1.owner.name` ag obair leis gu bheil `Rc<Owner>` gu fèin-ghluasadach a `dol sìos gu `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Aig deireadh na gnìomh, tha `gadget1` agus `gadget2` air an sgrios, agus còmhla riutha tha na h-iomraidhean mu dheireadh air an `Owner` againn.
//!     // Tha Gadget Man a-nis air a sgrios cuideachd.
//!     //
//! }
//! ```
//!
//! Ma dh `atharraicheas na riatanasan againn, agus feumaidh sinn cuideachd a bhith comasach air gluasad bho `Owner` gu `Gadget`, ruithidh sinn gu duilgheadasan.
//! Tha comharradh [`Rc`] bho `Owner` gu `Gadget` a `toirt a-steach cearcall.
//! Tha seo a `ciallachadh nach urrainn na cunntasan iomraidh aca ruighinn gu 0, agus cha tèid an riarachadh a sgrios gu bràth:
//! aodion cuimhne.Gus faighinn timcheall air seo, is urrainn dhuinn molaidhean [`Weak`] a chleachdadh.
//!
//! Tha Rust gu dearbh ga dhèanamh caran duilich an lùb seo a thoirt gu buil sa chiad àite.Gus crìoch a chur air dà luach a tha a `comharrachadh a chèile, feumaidh aon dhiubh a bhith caochlaideach.
//! Tha seo duilich oir tha [`Rc`] a `cur an gnìomh sàbhailteachd cuimhne le bhith a` toirt a-mach iomraidhean co-roinnte a-mhàin mun luach a tha e a `pasgadh, agus chan eil iad sin a` ceadachadh gluasad gu dìreach.
//! Feumaidh sinn am pàirt den luach a tha sinn ag iarraidh a thàthadh ann an [`RefCell`], a bheir seachad *mutability taobh a-staigh*: dòigh gus mutability a choileanadh tro iomradh coitcheann.
//! [`RefCell`] a `cur an gnìomh riaghailtean iasaid Rust aig àm-ruith.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... raointean eile
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... raointean eile
//! }
//!
//! fn main() {
//!     // Cruthaich `Owner` le cunntas iomraidh.
//!     // Thoir fa-near gu bheil sinn air an 'Owner`'s vector de` Gadget`s a chuir am broinn `RefCell` gus an urrainn dhuinn a thionndadh tro iomradh coitcheann.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Cruthaich `Gadget`s a bhuineas do `gadget_owner`, mar roimhe seo.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Cuir na `Gadget`s ris an `Owner` aca.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` thig iasad fiùghantach gu crìch an seo.
//!     }
//!
//!     // Iterate thairis air na `Gadget`s againn, a` clò-bhualadh am mion-fhiosrachadh aca.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` tha `Weak<Gadget>`.
//!         // Leis nach urrainn do chomharran `Weak` gealltainn gum bi an riarachadh fhathast ann, feumaidh sinn `upgrade` a ghairm, a thilleas `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Anns a `chùis seo tha fios againn gu bheil an riarachadh fhathast ann, agus mar sin tha sinn dìreach `unwrap` an `Option`.
//!         // Ann am prògram nas toinnte, is dòcha gum feum thu làimhseachadh mearachd gràsmhor airson toradh `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Aig deireadh na gnìomh, tha `gadget_owner`, `gadget1`, agus `gadget2` air an sgrios.
//!     // Chan eil molaidhean (`Rc`) làidir a-nis air na h-innealan, agus mar sin tha iad air an sgrios.
//!     // Tha seo a `toirt buaidh air a` chunntas iomraidh air Gadget Man, agus mar sin thèid a sgrios cuideachd.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Is e seo repr(C) gu future-proof an aghaidh ath-òrdachadh làraich a dh `fhaodadh a bhith ann, a chuireadh bacadh air [into|from]_raw() a bha sàbhailte air dhòigh eile de sheòrsan taobh a-staigh transmutable.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Puing-cunntais aon-snàithlean.Tha 'Rc' a `seasamh airson` Reference
/// Counted'.
///
/// Faic an [module-level documentation](./index.html) airson tuilleadh fiosrachaidh.
///
/// Tha na modhan in-ghnèitheach de `Rc` uile nan gnìomhan co-cheangailte, a tha a `ciallachadh gum feum thu an gairm mar me, [`Rc::get_mut(&mut value)`][get_mut] an àite `value.get_mut()`.
/// Bidh seo a `seachnadh còmhstri le modhan den t-seòrsa `T` a-staigh.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Tha an neo-shàbhailteachd seo ceart gu leòr oir ged a tha an Rc seo beò tha sinn cinnteach gu bheil am puing a-staigh dligheach.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// A `togail `Rc<T>` ùr.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Tha comharradh lag a tha so-thuigsinn leis na comharran làidir uile, a nì cinnteach nach bi an inneal-sgrios lag a-riamh a `saoradh an riarachadh fhad` s a tha an inneal-sgrios làidir a `ruith, eadhon ged a tha am puing lag air a stòradh am broinn an tè làidir.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// A `togail `Rc<T>` ùr a` cleachdadh iomradh lag air fhèin.
    /// Bidh luach `None` a `feuchainn ri ùrachadh a dhèanamh air an iomradh lag mus till an gnìomh seo.
    ///
    /// Ach, faodar an iomradh lag a bhith air a clònadh gu saor agus air a stòradh airson a chleachdadh aig àm nas fhaide air adhart.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... barrachd raointean
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Tog an taobh a-staigh ann an stàite "uninitialized" le aon iomradh lag.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Tha e cudromach nach bi sinn a `toirt seachad seilbh air a` phuing lag, no eile dh `fhaodadh an cuimhne a bhith air a shaoradh mus till `data_fn`.
        // Nam biodh sinn dha-rìribh ag iarraidh seilbh a thoirt seachad, dh `fhaodadh sinn comharraiche lag a bharrachd a chruthachadh dhuinn fhìn, ach bheireadh seo ùrachadh a bharrachd don chunntas iomraidh lag a dh` fhaodadh nach biodh feum air a chaochladh.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Bu chòir iomraidhean làidir co-roinnte a bhith aig iomraidhean làidir, mar sin na ruith an inneal-sgrios airson an t-seann iomradh lag againn.
        //
        mem::forget(weak);
        strong
    }

    /// A `togail `Rc` ùr le susbaint neo-aithnichte.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Toiseach tòiseachaidh:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// A `togail `Rc` ùr le susbaint neo-aithnichte, leis a` chuimhne air a lìonadh le bytes `0`.
    ///
    ///
    /// Faic [`MaybeUninit::zeroed`][zeroed] airson eisimpleirean de chleachdadh ceart agus ceàrr den dòigh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// A `togail `Rc<T>` ùr, a` tilleadh mearachd ma dh `fhailicheas an riarachadh
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Tha comharradh lag a tha so-thuigsinn leis na comharran làidir uile, a nì cinnteach nach bi an inneal-sgrios lag a-riamh a `saoradh an riarachadh fhad` s a tha an inneal-sgrios làidir a `ruith, eadhon ged a tha am puing lag air a stòradh am broinn an tè làidir.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// A `togail `Rc` ùr le susbaint neo-aithnichte, a` tilleadh mearachd ma dh `fhailicheas an riarachadh
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Toiseach tòiseachaidh:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// A `togail `Rc` ùr le susbaint neo-aithnichte, leis a` chuimhne air a lìonadh le `0` bytes, a `tilleadh mearachd ma dh` fhailicheas an riarachadh
    ///
    ///
    /// Faic [`MaybeUninit::zeroed`][zeroed] airson eisimpleirean de chleachdadh ceart agus ceàrr den dòigh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// A `togail `Pin<Rc<T>>` ùr.
    /// Mura cuir `T` an gnìomh `Unpin`, thèid `value` a phronnadh mar chuimhneachan agus cha ghabh a ghluasad.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// A 'tilleadh a-staigh luach, ma tha dìreach aon `Rc` làidir iomradh.
    ///
    /// Rud eile, thèid [`Err`] a thilleadh leis an aon `Rc` a chaidh a-steach.
    ///
    ///
    /// Bidh seo a `soirbheachadh eadhon ged a tha iomraidhean lag ann fhathast.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // dèan lethbhreac den rud a tha na bhroinn

                // Innis dha Weaks nach urrainn dhaibh a bhith air am brosnachadh le bhith a `lughdachadh a` chunntais làidir, agus an uairsin cuir às don chomharraiche "strong weak" a tha ri thuigsinn fhad `s a bhios iad cuideachd a` làimhseachadh loidsig tuiteam le bhith dìreach a `ciùradh lag lag.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// A `togail sliseag ùr le cunntadh fiosrachaidh le susbaint neo-aithnichte.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Toiseach tòiseachaidh:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// A `togail sliseag ùr le cunntadh fiosrachaidh le susbaint neo-aithnichte, leis a` chuimhne air a lìonadh le bytes `0`.
    ///
    ///
    /// Faic [`MaybeUninit::zeroed`][zeroed] airson eisimpleirean de chleachdadh ceart agus ceàrr den dòigh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Tionndadh gu `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Coltach ri [`MaybeUninit::assume_init`], tha e an urra ris an neach-fios a bhith a `gealltainn gu bheil an luach a-staigh ann an staid tòiseachaidh.
    ///
    /// Le bhith a `gairm seo nuair nach eil an susbaint air a làn thòiseachadh fhathast ag adhbhrachadh giùlan neo-mhìnichte sa bhad.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Toiseach tòiseachaidh:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Tionndadh gu `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Coltach ri [`MaybeUninit::assume_init`], tha e an urra ris an neach-fios a bhith a `gealltainn gu bheil an luach a-staigh ann an staid tòiseachaidh.
    ///
    /// Le bhith a `gairm seo nuair nach eil an susbaint air a làn thòiseachadh fhathast ag adhbhrachadh giùlan neo-mhìnichte sa bhad.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Toiseach tòiseachaidh:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// A `caitheamh an `Rc`, a` tilleadh a `phuing fillte.
    ///
    /// Gus aodion cuimhne a sheachnadh feumar am puing a thionndadh air ais gu `Rc` a `cleachdadh [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// A `toirt stiùireadh amh don dàta.
    ///
    /// Chan eilear a `toirt buaidh air na cunntasan ann an dòigh sam bith agus chan eilear a` caitheamh an `Rc`.
    /// Tha an comharradh dligheach cho fad `s gu bheil cunntasan làidir anns an `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SÀBHAILTEACHD: Chan urrainn dha seo a dhol tro Deref::deref no Rc::inner air sgàth
        // feumar seo gus dearbhadh raw/mut a chumail gus am bi me
        // `get_mut` comasach air sgrìobhadh tron phuing às deidh don Rc faighinn air ais tro `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// A `togail `Rc<T>` bho stiùireadh amh.
    ///
    /// Feumaidh gun deach am puing amh a thilleadh roimhe le gairm gu [`Rc<U>::into_raw`][into_raw] far am feum `U` an aon mheud agus co-thaobhadh ri `T`.
    /// Tha seo fìor gu fìrinneach ma tha `U` `T`.
    /// Thoir fa-near, mura h-e `T` a th `ann an `U` ach gu bheil an aon mheud is co-thaobhadh aige, tha seo gu bunaiteach mar a bhith a` gluasad iomraidhean de dhiofar sheòrsaichean.
    /// Faic [`mem::transmute`][transmute] airson tuilleadh fiosrachaidh mu na cuingeadan a tha a `buntainn sa chùis seo.
    ///
    /// Feumaidh neach-cleachdaidh `from_raw` dèanamh cinnteach nach tèid luach sònraichte `T` a leigeil sìos ach aon turas.
    ///
    /// Tha an gnìomh seo cunnartach oir dh `fhaodadh cleachdadh neo-iomchaidh leantainn gu mì-shàbhailteachd cuimhne, eadhon ged nach ruigear an `Rc<T>` a chaidh a thilleadh a-riamh.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Tionndaidh air ais gu `Rc` gus casg a chuir air aodion.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Bhiodh gairmean eile gu `Rc::from_raw(x_ptr)` neo-shàbhailte.
    /// }
    ///
    /// // Chaidh an cuimhne a shaoradh nuair a chaidh `x` a-mach à farsaingeachd gu h-àrd, agus mar sin tha `x_ptr` a-nis crochte!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Cuir air ais an fhrith-rathad gus an RcBox tùsail a lorg.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// A `cruthachadh stiùireadh [`Weak`] ùr don riarachadh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Dèan cinnteach nach cruthaich sinn Lag crochte
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Gets an àireamh de [`Weak`] Pointers gus seo a riarachadh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Faigh an àireamh de chomharran (`Rc`) làidir don riarachadh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// A `tilleadh `true` mura h-eil comharran `Rc` no [`Weak`] eile san riarachadh seo.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Tillidh tu iomradh gluasadach a-steach don `Rc` a chaidh a thoirt seachad, mura h-eil comharran `Rc` no [`Weak`] eile ann chun an aon riarachadh.
    ///
    ///
    /// A `tilleadh [`None`] air dhòigh eile, seach nach eil e sàbhailte luach co-roinnte a thionndadh.
    ///
    /// Faic cuideachd [`make_mut`][make_mut], a bheir [`clone`][clone] an luach a-staigh nuair a tha comharran eile ann.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// A `tilleadh iomradh gluasadach a-steach don `Rc` a chaidh a thoirt seachad, gun sgrùdadh sam bith.
    ///
    /// Faic cuideachd [`get_mut`], a tha sàbhailte agus a nì sgrùdaidhean iomchaidh.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Chan fhaodar comharran `Rc` no [`Weak`] sam bith eile a thoirt don aon riarachadh a bhith air an dì-chlàradh fhad `s a mhaireas an iasad a chaidh a thilleadh.
    ///
    /// Tha seo fìor gu h-obann mura h-eil leithid de chomharran ann, mar eisimpleir dìreach às deidh `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Tha sinn faiceallach gun *gun* teisteanas a chruthachadh a `còmhdach raointean "count", oir bhiodh seo an aghaidh ruigsinneachd do na cunntasan iomraidh (me.
        // le `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// A `tilleadh `true` ma tha an dà` Rc`s a` comharrachadh an aon riarachadh (ann an vein coltach ri [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// A `dèanamh iomradh gluasadach air an `Rc` a chaidh a thoirt seachad.
    ///
    /// Ma tha comharran `Rc` eile aig an aon riarachadh, an uairsin bheir `make_mut` [`clone`] an luach a-staigh gu riarachadh ùr gus dèanamh cinnteach à seilbh gun samhail.
    /// Thathas cuideachd a `toirt iomradh air seo mar clone-on-write.
    ///
    /// Mura h-eil comharran `Rc` eile air an riarachadh seo, thèid comharran [`Weak`] don riarachadh seo a sgaradh.
    ///
    /// Faic cuideachd [`get_mut`], a dh `fhàilligeas seach a bhith a` clònadh.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Cha clone mi dad
    /// let mut other_data = Rc::clone(&data);    // Cha clone dàta a-staigh
    /// *Rc::make_mut(&mut data) += 1;        // Dàta a-staigh clones
    /// *Rc::make_mut(&mut data) += 1;        // Cha clone mi dad
    /// *Rc::make_mut(&mut other_data) *= 2;  // Cha clone mi dad
    ///
    /// // A-nis tha `data` agus `other_data` a `comharrachadh diofar riarachadh.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] thèid molaidhean a thoirt às a chèile:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Gotta clone an dàta, tha Rcs eile ann.
            // Ro-riarachadh cuimhne gus leigeil le bhith a `sgrìobhadh an luach clonaichte gu dìreach.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // An urrainn dìreach an dàta a ghoid, chan eil air fhàgail ach Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Thoir air falbh ref làidir làidir-lag (chan fheumar a bhith a `ciùird lag meallta an seo-tha fios againn gum faod Weaks eile glanadh dhuinn)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Tha an neo-shàbhailteachd seo ceart gu leòr oir tha sinn a `gealltainn gur e am puing a thilleas an aon *neach-comharrachaidh* a thèid a thilleadh gu T.
        // Tha sinn cinnteach gu bheil an àireamh iomraidh againn aig 1 aig an ìre seo, agus dh `iarr sinn gum biodh an `Rc<T>` fhèin mar `mut`, agus mar sin tha sinn a` tilleadh an aon iomradh a dh `fhaodadh a bhith againn air an riarachadh.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Feuch ri an `Rc<dyn Any>` a thoirt sìos gu seòrsa cruadhtan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// A `riarachadh `RcBox<T>` le àite gu leòr airson luach a-staigh nach eil cinnteach far a bheil an luach air a thoirt seachad.
    ///
    /// Canar an gnìomh `mem_to_rcbox` ris a `phuing dàta agus feumaidh e inneal-stiùiridh (a dh` fhaodadh a bhith reamhar) a thilleadh airson an `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Obraich a-mach cruth a `cleachdadh an cruth luach a chaidh a thoirt seachad.
        // Roimhe sin, chaidh cruth a thomhas air an abairt `&*(ptr as* const RcBox<T>)`, ach chruthaich seo iomradh mì-chomharraichte (faic #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// A `riarachadh `RcBox<T>` le àite gu leòr airson luach a-staigh nach eil cinnteach far a bheil an luach air a thoirt seachad, a` tilleadh mearachd ma dh `fhàillig an riarachadh.
    ///
    ///
    /// Canar an gnìomh `mem_to_rcbox` ris a `phuing dàta agus feumaidh e inneal-stiùiridh (a dh` fhaodadh a bhith reamhar) a thilleadh airson an `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Obraich a-mach cruth a `cleachdadh an cruth luach a chaidh a thoirt seachad.
        // Roimhe sin, chaidh cruth a thomhas air an abairt `&*(ptr as* const RcBox<T>)`, ach chruthaich seo iomradh mì-chomharraichte (faic #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Riarachadh airson an dealbhadh.
        let ptr = allocate(layout)?;

        // Tòisich an RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// A `riarachadh `RcBox<T>` le àite gu leòr airson luach a-staigh gun luach
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Riarachadh airson an `RcBox<T>` a `cleachdadh an luach a chaidh a thoirt seachad.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Leth-bhreac luach mar bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Saor an riarachadh gun a bhith a `leigeil às na tha ann
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// A `riarachadh `RcBox<[T]>` leis an fhad a chaidh a thoirt seachad.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Dèan lethbhreac de eileamaidean bho sliseag a-steach do Rc <\[T\]> ùr
    ///
    /// Neo-shàbhailte oir feumaidh an neach-glacaidh seilbh a ghabhail no ceangal `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// A `togail `Rc<[T]>` bho iterator a tha aithnichte gu bheil e de mheud sònraichte.
    ///
    /// Chan eil giùlan air a mhìneachadh ma tha am meud ceàrr.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Geàrd Panic fhad `s a tha e a` clònadh eileamaidean T.
        // Ma thachras panic, thèid eileamaidean a chaidh a sgrìobhadh a-steach don RcBox ùr a leigeil sìos, an uairsin an cuimhne a shaoradh.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pointer chun chiad eileamaid
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Uile soilleir.Na dìochuimhnich an geàrd gus nach saor e an RcBox ùr.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Speisealachadh trait air a chleachdadh airson `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Drops an `Rc`.
    ///
    /// Bidh seo a `lughdachadh a` chunntais iomraidh làidir.
    /// Ma tha an cunntas iomraidh làidir a `ruighinn neoni is e na h-aon iomraidhean eile (ma tha sin ann) [`Weak`], mar sin bidh sinn `drop` an luach a-staigh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Cha chlò-bhualadh dad
    /// drop(foo2);   // Clò-bhualadh "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // sgrios an rud a th `ann
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // thoir air falbh am putan "strong weak" a tha ri thuigsinn a-nis gu bheil sinn air na tha ann a sgrios.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// A `dèanamh clone den phuing `Rc`.
    ///
    /// Bidh seo a `cruthachadh stiùireadh eile chun an aon riarachadh, ag àrdachadh an àireamh iomraidh làidir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// A `cruthachadh `Rc<T>` ùr, leis an luach `Default` airson `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack gus leigeil le speisealachadh air `Eq` eadhon ged a tha modh aig `Eq`.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Tha sinn a `dèanamh an speisealachadh seo an seo, agus chan ann mar optimization nas fharsainge air `&T`, oir bhiodh e air dhòigh eile a` cur cosgais ris a h-uile sgrùdadh co-ionannachd air refs.
/// Tha sinn a `gabhail ris gu bheil` Rc`s air an cleachdadh gus luachan mòra a stòradh, a tha slaodach airson clònadh, ach cuideachd trom airson sgrùdadh airson co-ionannachd, ag adhbhrachadh gum bi a`chosgais seo a` pàigheadh nas fhasa.
///
/// Tha e nas dualtaiche cuideachd dà chlòn `Rc` a bhith agad, a tha a `comharrachadh an aon luach, na dà`&T`s.
///
/// Chan urrainn dhuinn seo a dhèanamh ach nuair a dh `fhaodadh `T: Eq` mar `PartialEq` a bhith a dh`aona ghnothach neo-shùbailte.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Co-ionannachd airson dà `Rc`s.
    ///
    /// Tha dà `Rc` co-ionann ma tha na luachan a-staigh aca co-ionann, eadhon ged a tha iad air an stòradh ann an riarachadh eadar-dhealaichte.
    ///
    /// Ma tha `T` cuideachd a `buileachadh `Eq` (a` ciallachadh sùbailteachd co-ionannachd), tha dà`Rc a tha a`comharrachadh an aon riarachadh an-còmhnaidh co-ionann.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Neo-ionannachd airson dà `Rc`s.
    ///
    /// Tha dà `Rc 'neo-ionann ma tha na luachan a-staigh aca neo-ionann.
    ///
    /// Ma tha `T` cuideachd a `buileachadh `Eq` (a` ciallachadh sùbailteachd co-ionannachd), chan eil dà`Rc a tha a`comharrachadh an aon riarachadh a-riamh neo-chothromach.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Coimeas pàirt airson dà `Rc`s.
    ///
    /// Tha an dà rud air an coimeas le bhith a `gairm `partial_cmp()` air na luachan a-staigh aca.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Nas lugha na coimeas airson dà `Rc`s.
    ///
    /// Tha an dà rud air an coimeas le bhith a `gairm `<` air na luachan a-staigh aca.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Coimeas `nas lugha na no co-ionann ri` airson dà` Rc.
    ///
    /// Tha an dà rud air an coimeas le bhith a `gairm `<=` air na luachan a-staigh aca.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Coimeas nas motha na dà `Rc`s.
    ///
    /// Tha an dà rud air an coimeas le bhith a `gairm `>` air na luachan a-staigh aca.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Coimeas 'nas motha na no co-ionann ri' dà Rc.
    ///
    /// Tha an dà rud air an coimeas le bhith a `gairm `>=` air na luachan a-staigh aca.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Coimeas airson dà `Rc`s.
    ///
    /// Tha an dà rud air an coimeas le bhith a `gairm `cmp()` air na luachan a-staigh aca.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Thoir seachad sliseag le cunntas fiosrachaidh agus lìon e le bhith a `cliogadh nithean` v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Thoir seachad sliseag sreang le cunntadh fiosrachaidh agus dèan lethbhreac de `v` a-steach.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Thoir seachad sliseag sreang le cunntadh fiosrachaidh agus dèan lethbhreac de `v` a-steach.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Gluais nì ann am bogsa gu riarachadh ùr, air a chunntadh.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Thoir seachad sliseag le cunntas iomraidh agus gluais nithean `v` a-steach ann.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Leig leis an Vec a chuimhne a shaoradh, ach gun a susbaint a sgrios
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// A `toirt gach eileamaid den `Iterator` agus ga chruinneachadh a-steach do `Rc<[T]>`.
    ///
    /// # Feartan coileanaidh
    ///
    /// ## A `chùis choitcheann
    ///
    /// Anns a `chùis choitcheann, tha cruinneachadh a-steach do `Rc<[T]>` air a dhèanamh le bhith a` cruinneachadh a-steach do `Vec<T>` an toiseach.Is e sin, nuair a sgrìobhas tu na leanas:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// tha seo gad ghiùlan fhèin mar gum biodh sinn a `sgrìobhadh:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Bidh a `chiad sheata de riarachadh a` tachairt an seo.
    ///     .into(); // Chaidh an dàrna riarachadh airson `Rc<[T]>` tachairt an seo.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Bidh seo a `riarachadh uimhir de thursan` s a dh `fheumar airson an `Vec<T>` a thogail agus an uairsin riaraichidh e aon uair airson an `Vec<T>` a thionndadh chun `Rc<[T]>`.
    ///
    ///
    /// ## Iterators de fhad aithnichte
    ///
    /// Nuair a chuireas an `Iterator` agad `TrustedLen` an gnìomh agus gu bheil e de mheud sònraichte, thèid aon riarachadh a dhèanamh airson an `Rc<[T]>`.Mar eisimpleir:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Tha dìreach aon riarachadh a `tachairt an seo.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Speisealachadh trait air a chleachdadh airson cruinneachadh a-steach do `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Is e seo a `chùis airson iterator `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SÀBHAILTEACHD: Feumaidh sinn dèanamh cinnteach gu bheil fad ceart aig an iterator agus a th `againn.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Teich air ais gu buileachadh àbhaisteach.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` na dhreach de [`Rc`] aig a bheil iomradh neo-seilbh air an riarachadh a tha air a riaghladh.Gheibhear a-steach don riarachadh le bhith a `gairm [`upgrade`] air a` phuing `Weak`, a thilleas [`Roghainn`]`<`[`Rc`] `<T>>`.
///
/// Leis nach eil iomradh `Weak` a `cunntadh a dh` ionnsaigh seilbh, cha chuir e stad air an luach a tha air a stòradh san riarachadh a bhith air a leigeil sìos, agus chan eil `Weak` fhèin a `toirt gealltanas sam bith mun luach a tha fhathast ann.
/// Mar sin faodaidh e [`None`] a thilleadh nuair a bhios [`ùrachadh`] d.
/// Thoir fa-near ge-tà gu bheil iomradh `Weak` * a `cur casg air an riarachadh fhèin (an stòr taic) bho bhith air a thuigsinn.
///
/// Tha comharradh `Weak` feumail airson iomradh sealach a chumail air an riarachadh a tha [`Rc`] a `riaghladh gun a bhith a` cur casg air a luach a-staigh a bhith air a leigeil sìos.
/// Tha e cuideachd air a chleachdadh gus casg a chuir air iomraidhean cearcallach eadar stiùiridhean [`Rc`], oir cha leigeadh iomraidhean co-shealbh a-riamh [`Rc`] a leigeil sìos.
/// Mar eisimpleir, dh `fhaodadh craobh a bhith le comharran làidir [`Rc`] bho nodan pàrant gu clann, agus molaidhean `Weak` bho chloinn air ais gu am pàrantan.
///
/// Is e an dòigh àbhaisteach air comharradh `Weak` fhaighinn [`Rc::downgrade`] a ghairm.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Is e `NonNull` a tha seo gus leigeil le meud den t-seòrsa seo a mheudachadh ann an enums, ach chan eil e gu riatanach na chomharraiche dligheach.
    //
    // `Weak::new` a `suidheachadh seo gu `usize::MAX` gus nach fheum e àite a riarachadh air a` chàrn.
    // Chan e luach a tha sin a bhios aig fìor phuing a-riamh oir tha co-thaobhadh 2 aig RcBox.
    // Chan eil seo comasach ach nuair a tha `T: Sized`;chan eil `T` gun stad a-riamh a `crochadh.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// A `togail `Weak<T>` ùr, gun a bhith a` riarachadh cuimhne sam bith.
    /// Bidh a bhith a `gairm [`upgrade`] air an luach tillidh an-còmhnaidh a` toirt [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Seòrsa cuideachaidh gus cothrom a thoirt do na h-àireamhan iomraidh gun a bhith a `dèanamh beachdan sam bith mun raon dàta.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// A `tilleadh stiùireadh amh chun an nì `T` air a bheil an `Weak<T>` seo a` toirt iomradh.
    ///
    /// Chan eil am puing dligheach ach ma tha cuid de dh `iomraidhean làidir ann.
    /// Faodaidh am puing a bhith crochte, gun ainm no eadhon [`null`] air dhòigh eile.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Tha na dhà a `comharrachadh an aon rud
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Bidh an làidir an seo ga chumail beò, gus am faigh sinn cothrom air an rud fhathast.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ach chan ann tuilleadh.
    /// // Faodaidh sinn dhèanamh weak.as_ptr(), ach a 'faighinn cothrom a' chomharra a leanadh gu undefined giùlan.
    /// // assert_eq! ("hello", mì-shàbhailte {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ma tha am puing a `crochadh, tillidh sinn an sentinel gu dìreach.
            // Chan urrainn seo a bhith na sheòladh pàighidh dligheach, oir tha an t-uallach pàighidh co-dhiù co-thaobhach ri RcBox (usize).
            ptr as *const T
        } else {
            // SÀBHAILTEACHD: ma thilleas is_dangling meallta, tha an comharradh dereferencable.
            // Faodar an t-uallach pàighidh a leigeil sìos aig an ìre seo, agus feumaidh sinn tùsachd a chumail suas, mar sin cleachd làimhseachadh puing amh.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// A `caitheamh an `Weak<T>` agus ga thionndadh gu bhith na chomharradh amh.
    ///
    /// Bidh seo ag atharrachadh a `phuing lag gu bhith na chomharraiche amh, fhad` s a tha e fhathast a `gleidheadh seilbh aon iomradh lag (chan eil an cunntas lag air atharrachadh leis an obrachadh seo).
    /// Faodar a thionndadh air ais don `Weak<T>` le [`from_raw`].
    ///
    /// Tha na h-aon chuingealachaidhean ann a bhith a `faighinn cothrom air targaid a` phuing mar a tha le [`as_ptr`] a `buntainn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Bidh e ag atharrachadh puing amh a chaidh a chruthachadh roimhe le [`into_raw`] air ais gu `Weak<T>`.
    ///
    /// Faodaidh seo a bhith air a chleachdadh gu sàbhailte fhaighinn làidir iomradh (le fòn [`upgrade`] an dèidh sin) no deallocate an lag cunntadh le tadhal air an `Weak<T>`.
    ///
    /// Bidh e a `gabhail seilbh air aon iomradh lag (ach a-mhàin comharran a chruthaich [`new`], leis nach eil dad aca sin; tha an dòigh fhathast ag obair orra).
    ///
    /// # Safety
    ///
    /// Feumaidh gun tàinig am puing bhon [`into_raw`] agus feumaidh e fhathast an iomradh lag a dh'fhaodadh a bhith aige.
    ///
    /// Tha e ceadaichte don chunntas làidir a bhith 0 aig àm gairm seo.
    /// Ach a dh `aindeoin sin, tha seo a` gabhail seilbh air aon iomradh lag a tha an-dràsta air a riochdachadh mar chomharradh amh (chan eil an cunntas lag air atharrachadh leis an obrachadh seo) agus mar sin feumar a bhith air a chàradh le gairm roimhe gu [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Lùghdaich an cunntadh lag mu dheireadh.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Faic Weak::as_ptr airson co-theacsa air mar a thig am puing inntrigidh.

        let ptr = if is_dangling(ptr as *mut T) {
            // 'S e seo crochte Lag.
            ptr as *mut RcBox<T>
        } else {
            // Rud eile, tha sinn cinnteach gun tàinig am fiosaiche bho lag nondangling.
            // SÀBHAILTEACHD: tha data_offset sàbhailte a ghairm, oir tha ptr a `toirt iomradh air T. fìor (a dh` fhaodadh a bhith air tuiteam).
            let offset = unsafe { data_offset(ptr) };
            // Mar sin, bidh sinn a `cur cùl ris a` chothromachadh gus an RcBox gu lèir fhaighinn.
            // SÀBHAILTEACHD: thàinig am puing bho lag, agus mar sin tha am frith-rathad seo sàbhailte.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SÀBHAILTEACHD: tha sinn a-nis air am puing Weak tùsail fhaighinn air ais, agus mar sin is urrainn dhuinn an Lag a chruthachadh.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// A `feuchainn ris a` phuing `Weak` ùrachadh gu [`Rc`], a `cur dàil air tuiteam den luach a-staigh ma tha e soirbheachail.
    ///
    ///
    /// A `tilleadh [`None`] ma chaidh an luach a-staigh a leigeil sìos bhon uair sin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Dèan sgrios air gach moladh làidir.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Faigh an àireamh de chomharran (`Rc`) làidir a tha a `comharrachadh an riarachadh seo.
    ///
    /// Ma chaidh `self` a chruthachadh a `cleachdadh [`Weak::new`], tillidh seo 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Faigh an àireamh de chomharran `Weak` a tha a `comharrachadh an riarachadh seo.
    ///
    /// Mura h-eil comharran làidir air fhàgail, tillidh seo gu neoni.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // thoir air falbh am ptr lag a tha ri thuigsinn
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// `None` nuair a thilleas a 'chomharra a tha crochte agus chan eil an riarachadh `RcBox`, (' se sin, 'nuair a `Weak` seo a chruthachadh le `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Tha sinn faiceallach gun *gun* teisteanas a chruthachadh a `còmhdach an raon "data", oir dh` fhaodadh an raon a bhith air a thionndadh aig an aon àm (mar eisimpleir, ma thèid an `Rc` mu dheireadh a leigeil sìos, thèid an raon dàta a leigeil sìos na àite).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// A `tilleadh `true` ma tha an dà` lag a`comharrachadh an aon riarachadh (coltach ri [`ptr::eq`]), no mura h-eil an dà chuid a`comharrachadh riarachadh sam bith (oir chaidh an cruthachadh le `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Leis gu bheil seo a `dèanamh coimeas eadar molaidhean tha e a` ciallachadh gum bi `Weak::new()` co-ionann ri chèile, eadhon ged nach eil iad a `comharrachadh riarachadh sam bith.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// A `dèanamh coimeas eadar `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Drops a `phuing `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Cha chlò-bhualadh dad
    /// drop(foo);        // Clò-bhualadh "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // bidh an cunntadh lag a `tòiseachadh aig 1, agus cha tèid e gu neoni mura h-eil na comharran làidir air a dhol à bith.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// A `dèanamh clon den phuing `Weak` a tha a` comharrachadh an aon riarachadh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// A `togail `Weak<T>` ùr, a` riarachadh cuimhne airson `T` gun a bhith ga thòiseachadh.
    /// Bidh a bhith a `gairm [`upgrade`] air an luach tillidh an-còmhnaidh a` toirt [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Rinn sinn sgrùdadh_add an seo gus dèiligeadh ri mem::forget gu sàbhailte.Gu sònraichte
// ma nì thu mem::forget Rcs (no Weaks), faodaidh an ath-chunntadh cur thairis, agus an uairsin faodaidh tu an riarachadh a shaoradh fhad `s a tha Rcs (no Weaks) gun phàigheadh.
//
// Bidh sinn a `sgur a chionn` s gur e suidheachadh cho lag a tha seo nach eil dragh againn mu na thachras-cha bu chòir dha fìor phrògram eòlas fhaighinn air seo a-riamh.
//
// Bu chòir seo a bhith glè àrd os cionn oir cha leig thu a leas a bhith a `gleusadh iad sin ann an Rust le taing dha seilbh agus gluasad-semantics.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Tha sinn airson casg a chuir air cus-shruth an àite a bhith a `leigeil às an luach.
        // Cha bhi an cunntas iomraidh gu bràth nuair a thèid seo a ghairm;
        // a dh `aindeoin sin, tha sinn a` cuir a-steach giorrachadh an seo gus LLVM a mholadh aig optimization a chaidh a chall air dhòigh eile.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Tha sinn airson casg a chuir air cus-shruth an àite a bhith a `leigeil às an luach.
        // Cha bhi an cunntas iomraidh gu bràth nuair a thèid seo a ghairm;
        // a dh `aindeoin sin, tha sinn a` cuir a-steach giorrachadh an seo gus LLVM a mholadh aig optimization a chaidh a chall air dhòigh eile.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Faigh an cothromachadh taobh a-staigh `RcBox` airson an t-uallach pàighidh air cùl puing.
///
/// # Safety
///
/// Feumaidh an neach-comharrachaidh iomradh a thoirt air (agus meata-dàta dligheach a bhith aige airson) eisimpleir T a bha dligheach roimhe, ach tha cead aig an T a bhith air a leigeil seachad.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Co-thaobhadh an luach gun luach gu deireadh an RcBox.
    // Leis gur e repr(C) a th `ann an RcBox, bidh e an-còmhnaidh mar an raon mu dheireadh mar chuimhneachan.
    // Sàbhailteachd: a mhàin unsized bho na seòrsaichean ghabhas tha sliseagan, trait Rudan,
    // agus seòrsachan taobh a-muigh, tha an riatanas sàbhailteachd inntrigidh gu leòr an-dràsta gus riatanasan align_of_val_raw a shàsachadh;is e seo mion-fhiosrachadh buileachaidh den chànan nach fhaodar earbsa a bhith taobh a-muigh std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}