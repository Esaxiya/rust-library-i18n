//! Sealladh de mheud fiùghantach a-steach do shreath a tha faisg air làimh, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Is e sliseagan sealladh a-steach do bhloc cuimhne air a riochdachadh mar chomharradh agus fad.
//!
//! ```
//! // a `sliseag Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // a `coiteachadh sreath gu sliseag
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Tha sliseagan an dàrna cuid gluasadach no air an roinn.
//! Is e `&[T]` an seòrsa sliseag roinnte, agus is e `&mut [T]` an seòrsa sliseag gluasadach, far a bheil `T` a `riochdachadh an seòrsa eileamaid.
//! Mar eisimpleir, faodaidh tu mùchadh a dhèanamh air a `bhloc cuimhne a tha sliseag gluasadach a` comharrachadh:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Seo cuid de na rudan a tha sa mhodal seo:
//!
//! ## Structs
//!
//! Tha grunn structaran ann a tha feumail airson sliseagan, leithid [`Iter`], a tha a `riochdachadh itealadh thairis air sliseag.
//!
//! ## Gnìomhachadh Trait
//!
//! Tha grunn bhuileachadh de traits cumanta airson sliseagan.Am measg eisimpleirean tha:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], airson sliseagan aig a bheil an seòrsa eileamaid [`Eq`] no [`Ord`].
//! * [`Hash`] - airson sliseagan aig a bheil an seòrsa eileamaid [`Hash`].
//!
//! ## Iteration
//!
//! Bidh na sliseagan a `buileachadh `IntoIterator`.Bidh an iterator a`toirt a-mach iomraidhean air na h-eileamaidean sliseag.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Bidh an sliseag mutable a `toirt a-mach iomraidhean caochlaideach air na h-eileamaidean:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Bidh an iterator seo a `toirt a-mach iomraidhean caochlaideach mu eileamaidean an t-sliseag, mar sin ged is e `i32` an seòrsa eileamaid den t-slice, is e `&mut i32` an seòrsa eileamaid den iterator.
//!
//!
//! * [`.iter`] agus [`.iter_mut`] na modhan sònraichte airson na h-itealain bunaiteach a thilleadh.
//! * Is e tuilleadh dhòighean a thilleas itealain [`.split`], [`.splitn`], [`.chunks`], [`.windows`] agus barrachd.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Chan eil mòran de na cleachdaidhean anns a `mhodal seo air an cleachdadh ach anns an rèiteachadh deuchainn.
// Tha e nas glaine dìreach an rabhadh unused_imports a chuir dheth na bhith gan càradh.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Modhan leudachadh sliseag bunaiteach
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) a dh `fheumar airson macro `vec!` a bhuileachadh aig àm deuchainn NB, faic am modal `hack` san fhaidhle seo airson tuilleadh fiosrachaidh.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) a dh `fheumar airson `Vec::clone` a bhuileachadh aig àm deuchainn NB, faic am modal `hack` san fhaidhle seo airson tuilleadh fiosrachaidh.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Leis nach eil cfg(test) `impl [T]` ri fhaighinn, tha na trì gnìomhan sin gu dearbh nan dòighean a tha ann an `impl [T]` ach nach eil ann an `core::slice::SliceExt`, feumaidh sinn na gnìomhan sin a thoirt seachad airson deuchainn `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Cha bu chòir dhuinn feart in-loidhne a chur ris an seo oir tha seo air a chleachdadh ann am macro `vec!` sa mhòr-chuid agus ag adhbhrachadh toirt air ais foirfe.
    // Faic #71204 airson beachdachadh agus toraidhean foirfe.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // chaidh nithean a chomharrachadh an toiseach anns an lùb gu h-ìosal
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) riatanach airson LLVM gus sgrùdaidhean crìochan a thoirt air falbh agus tha codegen nas fheàrr na zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // chaidh an vec a riarachadh agus a thòiseachadh gu h-àrd chun an fhad seo co-dhiù.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // air a riarachadh gu h-àrd le comas `s`, agus tòiseachadh gu `s.len()` ann an ptr::copy_to_non_overlapping gu h-ìosal.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Deasaich an sliseag.
    ///
    /// Tha an seòrsa seo seasmhach (ie, chan eil e ag ath-òrdachadh eileamaidean co-ionnan) agus *O*(*n*\*log(* n*)) cùis as miosa.
    ///
    /// Nuair a tha e iomchaidh, b `fheàrr a sheòrsachadh neo-sheasmhach oir tha e mar as trice nas luaithe na bhith a` rèiteach seasmhach agus chan eil e a `riarachadh cuimhne cuideachaidh.
    /// Faic [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Buileachadh gnàthach
    ///
    /// Tha an algorithm gnàthach na sheòrsa aonaidh atharrachail, ath-aithriseach air a bhrosnachadh le [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Tha e air a dhealbhadh gus a bhith gu math luath ann an cùisean far a bheil an sliseag cha mhòr air a sheòrsachadh, no air a dhèanamh suas de dhà shreath no barrachd air an rèiteachadh aon às deidh a chèile.
    ///
    ///
    /// Cuideachd, bidh e a `riarachadh stòradh sealach leth meud `self`, ach airson sliseagan goirid thèid seòrsa cuir a-steach nach eil a` riarachadh a chleachdadh na àite.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Deasaich an sliseag le gnìomh coimeasach.
    ///
    /// Tha an seòrsa seo seasmhach (ie, chan eil e ag ath-òrdachadh eileamaidean co-ionnan) agus *O*(*n*\*log(* n*)) cùis as miosa.
    ///
    /// Feumaidh an gnìomh coimeasach òrdugh iomlan a mhìneachadh airson na h-eileamaidean san t-slice.Mura h-eil an òrdachadh gu h-iomlan, tha òrdugh nan eileamaidean neo-ainmichte.
    /// Is e òrdugh òrdugh iomlan ma tha e (airson a h-uile `a`, `b` agus `c`):
    ///
    /// * iomlan agus antisymmetric: tha dìreach aon de `a < b`, `a == b` no `a > b` fìor, agus
    /// * tar-ghluasadach, tha `a < b` agus `b < c` a `ciallachadh `a < c`.Feumaidh an aon rud a bhith ann airson an dà chuid `==` agus `>`.
    ///
    /// Mar eisimpleir, ged nach eil [`f64`] a `buileachadh [`Ord`] air sgàth `NaN != NaN`, is urrainn dhuinn `partial_cmp` a chleachdadh mar ar gnìomh seòrsa nuair a tha fios againn nach eil `NaN` anns an t-sliseag.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Nuair a tha e iomchaidh, b `fheàrr a sheòrsachadh neo-sheasmhach oir tha e mar as trice nas luaithe na bhith a` rèiteach seasmhach agus chan eil e a `riarachadh cuimhne cuideachaidh.
    /// Faic [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Buileachadh gnàthach
    ///
    /// Tha an algorithm gnàthach na sheòrsa aonaidh atharrachail, ath-aithriseach air a bhrosnachadh le [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Tha e air a dhealbhadh gus a bhith gu math luath ann an cùisean far a bheil an sliseag cha mhòr air a sheòrsachadh, no air a dhèanamh suas de dhà shreath no barrachd air an rèiteachadh aon às deidh a chèile.
    ///
    /// Cuideachd, bidh e a `riarachadh stòradh sealach leth meud `self`, ach airson sliseagan goirid thèid seòrsa cuir a-steach nach eil a` riarachadh a chleachdadh na àite.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // cùl-sheòrsachadh
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Deasaich an sliseag le prìomh obair às-tharraing.
    ///
    /// Tha an seòrsa seo seasmhach (ie, chan eil e ag ath-òrdachadh eileamaidean co-ionnan) agus *O*(*m*\* * n *\* log(*n*)) anns a `chùis as miosa, far a bheil a` phrìomh ghnìomh *O*(*m*).
    ///
    /// Airson prìomh ghnìomhan daor (me
    /// gnìomhan nach eil nan ruigsinneachd seilbh sìmplidh no obraichean bunaiteach), tha coltas ann gum bi [`sort_by_cached_key`](slice::sort_by_cached_key) gu math nas luaithe, leis nach eil e a `toirt air ais iuchraichean eileamaid.
    ///
    ///
    /// Nuair a tha e iomchaidh, b `fheàrr a sheòrsachadh neo-sheasmhach oir tha e mar as trice nas luaithe na bhith a` rèiteach seasmhach agus chan eil e a `riarachadh cuimhne cuideachaidh.
    /// Faic [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Buileachadh gnàthach
    ///
    /// Tha an algorithm gnàthach na sheòrsa aonaidh atharrachail, ath-aithriseach air a bhrosnachadh le [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Tha e air a dhealbhadh gus a bhith gu math luath ann an cùisean far a bheil an sliseag cha mhòr air a sheòrsachadh, no air a dhèanamh suas de dhà shreath no barrachd air an rèiteachadh aon às deidh a chèile.
    ///
    /// Cuideachd, bidh e a `riarachadh stòradh sealach leth meud `self`, ach airson sliseagan goirid thèid seòrsa cuir a-steach nach eil a` riarachadh a chleachdadh na àite.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Deasaich an sliseag le prìomh obair às-tharraing.
    ///
    /// Rè a sheòrsachadh, is e dìreach aon uair gach eileamaid a chanar ris a `phrìomh ghnìomh.
    ///
    /// Tha an seòrsa seo seasmhach (ie, chan eil e ag ath-òrdachadh eileamaidean co-ionnan) agus *O*(*m*\* * n *+* n *\* log(*n*)) anns a `chùis as miosa, far a bheil a` phrìomh ghnìomh *O*(*m*) .
    ///
    /// Airson prìomh dhleastanasan sìmplidh (me, gnìomhan a tha nan ruigsinneachd seilbh no obraichean bunaiteach), tha coltas ann gum bi [`sort_by_key`](slice::sort_by_key) nas luaithe.
    ///
    /// # Buileachadh gnàthach
    ///
    /// Tha an algorithm gnàthach stèidhichte air [pattern-defeating quicksort][pdqsort] le Orson Peters, a tha a `cothlamadh a` chùis cuibheasach luath de quicksort air thuaiream leis a `chùis as luaithe as luaithe de heapsort, agus aig an aon àm a` coileanadh ùine shreathach air sliseagan le pàtrain sònraichte.
    /// Bidh e a `cleachdadh cuid de thuaiream gus cùisean degenerate a sheachnadh, ach le seed stèidhichte gus giùlan deimhinnte a thoirt seachad an-còmhnaidh.
    ///
    /// Anns a `chùis as miosa, bidh an algorithm a` riarachadh stòradh sealach ann an `Vec<(K, usize)>` fad na sliseag.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Macro Helper airson clàr-amais ar vector a rèir an seòrsa as lugha a tha comasach, gus riarachadh a lughdachadh.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Tha na h-eileamaidean de `indices` gun samhail, mar a tha iad air an clàradh, agus mar sin bidh seòrsa sam bith seasmhach a thaobh an t-slice tùsail.
                // Bidh sinn a `cleachdadh `sort_unstable` an seo oir tha feum air nas lugha de riarachadh cuimhne.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Dèan leth-bhreacan `self` a-steach do `Vec` ùr.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // An seo, faodar `s` agus `x` atharrachadh gu neo-eisimeileach.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Dèan leth-bhreacan `self` a-steach do `Vec` ùr le inneal-sgaoilidh.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // An seo, faodar `s` agus `x` atharrachadh gu neo-eisimeileach.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, faic am modal `hack` san fhaidhle seo airson tuilleadh fiosrachaidh.
        hack::to_vec(self, alloc)
    }

    /// Bidh e ag atharrachadh `self` gu vector gun clones no riarachadh.
    ///
    /// Faodar an vector a thig às a thionndadh air ais gu bogsa tro `Vec<T>`'s modh `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` cha ghabh a chleachdadh tuilleadh oir chaidh atharrachadh gu `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, faic am modal `hack` san fhaidhle seo airson tuilleadh fiosrachaidh.
        hack::into_vec(self)
    }

    /// A `cruthachadh vector le bhith ag ath-aithris sliseag `n` uair.
    ///
    /// # Panics
    ///
    /// Bidh an gnìomh seo panic nam biodh an comas a `dol thairis.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// A panic air faighinn thairis air:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Ma tha `n` nas motha na neoni, faodar a roinn mar `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` an àireamh a tha air a riochdachadh leis a `phàirt '1' as fhaide air falbh de `n`, agus is e `rem` am pàirt eile de `n`.
        //
        //

        // A `cleachdadh `Vec` gus faighinn gu `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` tha ath-aithris air a dhèanamh le bhith a `dùblachadh `buf` expn`-times.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Ma tha `m > 0`, tha pìosan air fhàgail suas chun '1' as fhaide air falbh.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` tha comas `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) tha ath-aithris air a dhèanamh le bhith a` dèanamh lethbhreac de chiad ath-aithris `rem` bho `buf` fhèin.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Tha seo neo-cheangailte bho `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` co-ionann ri `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// A `flatachadh sliseag de `T` gu aon luach `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// A `flatachadh sliseag de `T` a-steach do aon luach `Self::Output`, a` cur dealaiche sònraichte eadar gach fear.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// A `flatachadh sliseag de `T` a-steach do aon luach `Self::Output`, a` cur dealaiche sònraichte eadar gach fear.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// A `tilleadh vector anns a bheil leth-bhreac den t-sliseag seo far a bheil gach byte air a mhapadh chun a` chùis àrd ASCII aige.
    ///
    ///
    /// Tha litrichean ASCII 'a' gu 'z' air am mapadh gu 'A' gu 'Z', ach tha litrichean neo-ASCII gun atharrachadh.
    ///
    /// Gus faighinn thairis air an luach a tha na àite, cleachd [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// A `tilleadh vector anns a bheil leth-bhreac den t-sliseag seo far a bheil gach byte air a mhapadh chun a` chùis as ìsle aige ASCII.
    ///
    ///
    /// Tha litrichean ASCII 'A' gu 'Z' air am mapadh gu 'a' gu 'z', ach tha litrichean neo-ASCII gun atharrachadh.
    ///
    /// Gus an luach a lughdachadh na àite, cleachd [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Leudachadh traits airson sliseagan thairis air seòrsachan dàta sònraichte
////////////////////////////////////////////////////////////////////////////////

/// Helper trait airson [`[T]: : concat`](slice::concat).
///
/// Note: chan eil am paramadair seòrsa `Item` air a chleachdadh anns an trait seo, ach leigidh e le impls a bhith nas gnèitheile.
/// Às aonais, gheibh sinn a `mhearachd seo:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Tha seo air sgàth gum faodadh seòrsaichean `V` a bhith ann le grunn impls `Borrow<[_]>`, gus am biodh grunn sheòrsaichean `T` an sàs:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// An seòrsa a thig às deidh concatenation
    type Output;

    /// Cur an gnìomh [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Helper trait airson [`[T]: : join`](slice::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// An seòrsa a thig às deidh concatenation
    type Output;

    /// Cur an gnìomh [`[T]: : join`](slice::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Gnìomhachadh àbhaisteach trait airson sliseagan
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // leig às rud sam bith san targaid nach tèid a sgrìobhadh thairis
        target.truncate(self.len());

        // target.len <= self.len mar thoradh air an truncate gu h-àrd, agus mar sin tha na sliseagan an seo an-còmhnaidh a-staigh.
        //
        let (init, tail) = self.split_at(target.len());

        // ath-chleachdadh na luachan a tha ann allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Cuir a-steach `v[0]` ann an sreath ro-sheòrsach `v[1..]` gus am bi `v[..]` slàn air a sheòrsachadh.
///
/// Is e seo am fo-ghnè iomlan de sheòrsa cuir a-steach.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Tha trì dòighean ann airson cuir a-steach a bhuileachadh an seo:
            //
            // 1. Dèan iomlaid air eileamaidean faisg air làimh gus am faigh a `chiad fhear a cheann-uidhe deireannach.
            //    Ach, san dòigh seo bidh sinn a `dèanamh lethbhreac de dhàta timcheall air barrachd na tha riatanach.
            //    Ma tha eileamaidean nan structaran mòra (cosgail ri leth-bhreac), bidh an dòigh seo slaodach.
            //
            // 2. Iterate gus an lorgar an àite cheart airson a `chiad eileamaid.
            // An uairsin gluais na h-eileamaidean às deidh sin gus àite a dhèanamh dha agus mu dheireadh cuir e a-steach don toll a tha air fhàgail.
            // Is e dòigh math a tha seo.
            //
            // 3. Dèan lethbhreac den chiad eileamaid ann an caochladair sealach.Iterate gus an lorgar an àite ceart air a shon.
            // Mar a thèid sinn air adhart, dèan lethbhreac de gach eileamaid a chaidh a ghluasad a-steach don t-slot a tha roimhe.
            // Mu dheireadh, dèan lethbhreac de dhàta bhon caochladair sealach a-steach don toll a tha air fhàgail.
            // Tha an dòigh seo fìor mhath.
            // Sheall comharran-tomhais coileanadh beagan nas fheàrr na leis an 2na dòigh.
            //
            // Chaidh a h-uile modh a shlat-tomhais, agus sheall an 3mh toraidhean as fheàrr.Mar sin thagh sinn am fear sin.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Tha staid eadar-mheadhanach a `phròiseas cuir a-steach an-còmhnaidh air a leantainn le `hole`, a tha a` frithealadh dà adhbhar:
            // 1. A `dìon ionracas `v` bho panics ann an `is_less`.
            // 2. Lìon an toll a tha air fhàgail ann an `v` aig a `cheann thall.
            //
            // Sàbhailteachd Panic:
            //
            // Ma tha `is_less` panics aig àm sam bith tron phròiseas, thèid `hole` a leigeil sìos agus lìon e an toll ann an `v` le `tmp`, mar sin a `dèanamh cinnteach gu bheil `v` fhathast a` cumail a h-uile nì a ghlèidh e an toiseach dìreach aon uair.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` a `tuiteam agus mar sin a` dèanamh leth-bhreac de `tmp` a-steach don toll a tha air fhàgail ann an `v`.
        }
    }

    // Nuair a thuit e, dèan lethbhric bho `src` a-steach do `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Bidh aonaidhean nach eil a `lughdachadh a` ruith `v[..mid]` agus `v[mid..]` a `cleachdadh `buf` mar stòradh sealach, agus a` stòradh an toradh gu `v[..]`.
///
/// # Safety
///
/// Feumaidh an dà shliseag a bhith falamh agus feumaidh `mid` a bhith ann an crìochan.
/// Feumaidh bufair `buf` a bhith fada gu leòr gus lethbhreac den t-sliseag as giorra a chumail.
/// Cuideachd, chan fhaod `T` a bhith na sheòrsa de mheud neoni.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Bidh am pròiseas aonaidh a `dèanamh lethbhreac den ruith as giorra a-steach do `buf`.
    // An uairsin bidh e a `leantainn an ruith a chaidh a chopaigeadh às ùr agus an ruith nas fhaide air adhart (no air ais), a` dèanamh coimeas eadar na h-ath eileamaidean gun chead agus a `dèanamh lethbhreac den fhear as lugha (no nas motha) a-steach do `v`.
    //
    // Cho luath `s a thèid an ruith as giorra a chaitheamh gu h-iomlan, thèid am pròiseas a dhèanamh.Ma thèid an ruith nas fhaide a chaitheamh an toiseach, feumaidh sinn leth-bhreac a dhèanamh de na tha air fhàgail den ruith as giorra a-steach don toll a tha air fhàgail ann an `v`.
    //
    // Tha staid eadar-mheadhanach a `phròiseis an-còmhnaidh air a leantainn le `hole`, a tha a` frithealadh dà adhbhar:
    // 1. A `dìon ionracas `v` bho panics ann an `is_less`.
    // 2. Lìon an toll a tha air fhàgail ann an `v` ma thèid an ruith nas fhaide a chaitheamh an toiseach.
    //
    // Sàbhailteachd Panic:
    //
    // Ma tha `is_less` panics aig àm sam bith tron phròiseas, thèid `hole` a leigeil sìos agus lìon e an toll ann an `v` leis an raon gun chead ann an `buf`, mar sin a `dèanamh cinnteach gu bheil `v` fhathast a` cumail a h-uile nì a bha e a `cumail an toiseach dìreach aon uair.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Tha an ruith chlì nas giorra.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // An toiseach, tha na comharran sin a `comharrachadh toiseach an arrays.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Cleachd an taobh as lugha.
            // Ma tha e co-ionann, is fheàrr leat an ruith chlì gus seasmhachd a chumail suas.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Tha an ruith cheart nas giorra.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // An toiseach, bidh na comharran sin a `comharrachadh seachad air cinn nan àirdean aca.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Cleachd an taobh as motha.
            // Ma tha e co-ionann, is fheàrr leat an ruith cheart gus seasmhachd a chumail suas.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Mu dheireadh, thèid `hole` a leigeil sìos.
    // Mura deach an ruith as giorra a chaitheamh gu h-iomlan, thèid na tha air fhàgail dheth a chopaigeadh a-steach don toll ann an `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Nuair a thuit e, dèan lethbhreac den raon `start..end` gu `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` chan e seòrsa de mheud neoni a th `ann, agus mar sin tha e ceart gu leòr a roinn a rèir a mheud.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Bidh an seòrsa aonadh seo a `faighinn iasad de chuid de bheachdan (ach chan e sin uile) bho TimSort, a tha air a mhìneachadh gu mionaideach [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Bidh an algorithm a `comharrachadh gluasadan a tha a` teàrnadh gu teann agus nach eil a `teàrnadh, ris an canar ruith nàdarra.Tha cruach de ruithean ri thighinn fhathast ri aonachadh.
/// Tha gach ruith ùr air a phutadh air a `chruach, agus an uairsin tha cuid de chàraidean de ruith faisg air làimh air an aonachadh gus am bi an dà ionnsaigh sin riaraichte:
///
/// 1. airson gach `i` ann an `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. airson gach `i` ann an `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Bidh na h-invariants a `dèanamh cinnteach gur e an ùine ruith iomlan *O*(*n*\*log(* n*)) as miosa.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Thèid sliseagan suas ris an fhad seo a sheòrsachadh le bhith a `cleachdadh seòrsa cuir a-steach.
    const MAX_INSERTION: usize = 20;
    // Tha ruithidhean glè ghoirid air an leudachadh le bhith a `cleachdadh seòrsa cuir a-steach gus a bhith a` cuairteachadh co-dhiù mòran de na h-eileamaidean sin.
    const MIN_RUN: usize = 10;

    // Chan eil giùlan brìgheil aig seòrsan meud neoni.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Bidh arrays goirid gan rèiteachadh nan àite tro sheòrsa cuir a-steach gus cuibhreannan a sheachnadh.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Thoir seachad bufair airson a chleachdadh mar chuimhne sgrìobach.Bidh sinn a `cumail an fhaid 0 gus an urrainn dhuinn leth-bhreacan tana de shusbaint `v` a chumail ann gun a bhith a` cur cunnart air na dtors a tha a `ruith air lethbhric ma tha `is_less` panics.
    //
    // Nuair a thèid dà ruith de sheòrsa a chur còmhla, bidh am bufair seo a `cumail leth-bhreac den ruith as giorra, a bhios an-còmhnaidh aig a` char as fhaide aig `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Gus ruith nàdurrach ann an `v` a chomharrachadh, bidh sinn a `dol thairis air ais.
    // Dh `fhaodadh sin a bhith coltach ri co-dhùnadh neònach, ach smaoinich air an fhìrinn gum bi aonaidhean nas trice a` dol an taobh eile (forwards).
    // A rèir slatan-tomhais, tha an aonachadh air adhart beagan nas luaithe na bhith a `tighinn air ais.
    // Gus crìochnachadh, tha a bhith a `comharrachadh ruith le bhith a` dol air ais a `leasachadh coileanadh.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Lorg an ath ruith nàdarra, agus cuir air ais e ma tha e a `teàrnadh gu teann.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Cuir a-steach beagan a bharrachd eileamaidean san ruith ma tha e ro ghoirid.
        // Tha an seòrsa cuir a-steach nas luaithe na bhith a `tighinn còmhla air sreathan goirid, agus mar sin bidh seo a` leasachadh coileanadh gu mòr.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Brùth an ruith seo air a `chruach.
        runs.push(Run { start, len: end - start });
        end = start;

        // Cuir còmhla cuid de chàraidean de ruith faisg air làimh gus na h-ionnsaigh a shàsachadh.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Mu dheireadh, feumaidh dìreach aon ruith fuireach anns a `chruach.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // A `sgrùdadh stac ruith agus a` comharrachadh an ath phaidhir ruith gus tighinn còmhla.
    // Gu sònraichte, ma thèid `Some(r)` a thilleadh, tha sin a `ciallachadh gum feumar `runs[r]` agus `runs[r + 1]` a chur còmhla an ath rud.
    // Ma bu chòir don algorithm cumail a `togail ruith ùr na àite, thèid `None` a thilleadh.
    //
    // Tha TimSort cliùiteach airson a bhuileachadh, mar a chaidh a mhìneachadh an seo:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Is e fìor bhrìgh na sgeòil: feumaidh sinn na h-ionnsaigh a chuir an sàs air na ceithir ruith as àirde air a `chruach.
    // Chan eil a bhith gan cur an sàs air dìreach trì as àirde gu leòr gus dèanamh cinnteach gum bi na h-invariants fhathast a `cumail airson *a h-uile* ruith anns a` chruach.
    //
    // Bidh an gnìomh seo gu ceart a `sgrùdadh invariants airson na ceithir ruith as àirde.
    // A bharrachd air an sin, ma thòisicheas an ruith as àirde aig clàr-amais 0, bidh e an-còmhnaidh ag iarraidh obrachadh còmhla gus an tèid an stac fodha, gus an cuir thu crìoch air.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}