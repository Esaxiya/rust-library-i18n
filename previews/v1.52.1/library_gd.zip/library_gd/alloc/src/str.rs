//! Sliseagan sreang unicode.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Is e an seòrsa `&str` aon de dhà phrìomh sheòrsa sreang, agus am fear eile `String`.
//! Eu-coltach ris an coimeas `String` aige, tha na tha ann air iasad.
//!
//! # Cleachdadh bunaiteach
//!
//! Dearbhadh sreang bunaiteach de sheòrsa `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! An seo tha sinn air litearra sreang ainmeachadh, ris an canar cuideachd sreang sreang.
//! Tha beatha statach aig litearrachd teudach, a tha a `ciallachadh gu bheil cinnt ann gum bi an sreang `hello_world` dligheach fad a` phrògraim gu lèir.
//!
//! Is urrainn dhuinn beatha `hello_world` a shònrachadh gu sònraichte cuideachd:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Chan eil mòran de na cleachdaidhean anns a `mhodal seo air an cleachdadh ach anns an rèiteachadh deuchainn.
// Tha e nas glaine dìreach an rabhadh unused_imports a chuir dheth na bhith gan càradh.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: Chan eil `str` ann an `Concat<str>` a `ciallachadh an seo.
/// Chan eil am paramadair seòrsa seo den trait ann ach gus comas a thoirt dha impl eile.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // bidh lùban le meudan cruaidh a `ruith fada nas luaithe a` speisealachadh nan cùisean le faid dealachaidh beaga
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // tuiteam neo-riaghailteach meud neo-neoni
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Optimized join buileachadh a tha ag obair airson an dà chuid Vec<T>(T: Leth-bhreac) agus vec a-staigh String An-dràsta (2018-05-13) tha bug ann le co-dhùnadh agus speisealachadh seòrsa (faic cùis #36262) Air an adhbhar seo SliceConcat<T>chan eil e sònraichte airson T: Copy agus SliceConcat<str>is e an aon neach-cleachdaidh an gnìomh seo.
// Tha e air fhàgail na àite airson an àm nuair a bhios sin stèidhichte.
//
// is e na crìochan airson String-join S: Borrow<str>agus airson Vec-join Borrow <[T]> [T] agus str an dà chuid impl AsRef <[T]> airson cuid T
// => s.borrow().as_ref() agus bidh sliseagan againn an-còmhnaidh
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // is e a `chiad sliseag an aon fhear às aonais dealaiche roimhe
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // obrachadh a-mach an fhìor fhad iomlan den Vec ceangailte ma tha an àireamhachadh `len` a `dol thairis, bidh panic againn a bhiodh sinn air ruith a-mach à cuimhne co-dhiù agus feumaidh an còrr den ghnìomh an Vec gu lèir a ro-riarachadh airson sàbhailteachd
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // ullaich bufair neo-aithnichte
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // leth-bhreac lethbhreacadair agus sliseagan thairis gun sgrùdaidhean crìochnachaidh a `gineadh lùban le frith-rathaidean cruaidh airson luchd-sgaraidh beaga leasachaidhean mòra comasach (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Faodaidh buileachadh neònach iasad diofar sliseagan a thilleadh airson an àireamhachadh faid agus an leth-bhreac fhèin.
        //
        // Dèan cinnteach nach nochd sinn bytes neo-aithnichte don neach-fios.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Dòighean airson sliseagan sreang.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Bidh e ag atharrachadh `Box<str>` gu `Box<[u8]>` gun a bhith a `dèanamh copaidh no riarachadh.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// A `dol an àite a h-uile maids de phàtran le sreang eile.
    ///
    /// `replace` a `cruthachadh [`String`] ùr, agus a` dèanamh lethbhreac den dàta bhon t-sreang seo a-steach.
    /// Fhad `s a tha e a` dèanamh sin, bidh e a `feuchainn ri maids de phàtran a lorg.
    /// Ma lorgas e gin, cuiridh e an t-sliseag sreang ùr na àite.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Nuair nach eil am pàtran co-ionnan:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// A `dol an àite a` chiad maidsean N de phàtran le sreang eile.
    ///
    /// `replacen` a `cruthachadh [`String`] ùr, agus a` dèanamh lethbhreac den dàta bhon t-sreang seo a-steach.
    /// Fhad `s a tha e a` dèanamh sin, bidh e a `feuchainn ri maids de phàtran a lorg.
    /// Ma lorgas e gin, cuiridh e an t-sliseag sreang ùr nan àite aig a `mhòr-chuid de `count`.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Nuair nach eil am pàtran co-ionnan:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // An dòchas na h-amannan ath-riarachadh a lughdachadh
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// A `tilleadh an litrichean beaga a tha co-ionnan ris an t-sreang sreang seo, mar [`String`] ùr.
    ///
    /// 'Lowercase' air a mhìneachadh a rèir cumhachan an Unicode Derived Core Property `Lowercase`.
    ///
    /// Leis gum faod cuid de charactaran leudachadh gu grunn charactaran nuair a dh `atharraicheas iad a` chùis, bidh an gnìomh seo a `tilleadh [`String`] an àite a bhith ag atharrachadh a` pharamadair na àite.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Eisimpleir duilich, le sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // ach aig deireadh facal, is e ς, chan e σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Chan eil cànanan gun chùis air an atharrachadh:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ mapaichean gu σ, ach aig deireadh facal far a bheil e a `mapadh gu ς.
                // Is e seo an aon (contextual) cumhach ach mapadh neo-eisimeileach cànain ann an `SpecialCasing.txt`, mar sin còd cruaidh e an àite uidheamachd coitcheann "condition".
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // airson mìneachadh `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// A `tilleadh an uppercase co-ionann ris an t-sreang sreang seo, mar [`String`] ùr.
    ///
    /// 'Uppercase' air a mhìneachadh a rèir cumhachan an Unicode Derived Core Property `Uppercase`.
    ///
    /// Leis gum faod cuid de charactaran leudachadh gu grunn charactaran nuair a dh `atharraicheas iad a` chùis, bidh an gnìomh seo a `tilleadh [`String`] an àite a bhith ag atharrachadh a` pharamadair na àite.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Chan eil sgriobtaichean gun chùis air an atharrachadh:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Faodaidh aon charactar a bhith ioma:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Bidh e ag atharrachadh [`Box<str>`] gu [`String`] gun a bhith a `dèanamh copaidh no riarachadh.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// A `cruthachadh [`String`] ùr le bhith ag ath-aithris sreang `n` uair.
    ///
    /// # Panics
    ///
    /// Bidh an gnìomh seo panic nam biodh an comas a `dol thairis.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// A panic air faighinn thairis air:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// A `tilleadh leth-bhreac den sreang seo far a bheil gach caractar air a mhapadh chun a` chùis àrd ASCII aige.
    ///
    ///
    /// Tha litrichean ASCII 'a' gu 'z' air am mapadh gu 'A' gu 'Z', ach tha litrichean neo-ASCII gun atharrachadh.
    ///
    /// Gus faighinn thairis air an luach a tha na àite, cleachd [`make_ascii_uppercase`].
    ///
    /// Gus gabhail ri caractaran ASCII a bharrachd air caractaran neo-ASCII, cleachd [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() a `gleidheadh an UTF-8 invariant.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// A `tilleadh leth-bhreac den sreang seo far a bheil gach caractar air a mhapadh chun a` chùis as ìsle aige ASCII.
    ///
    ///
    /// Tha litrichean ASCII 'A' gu 'Z' air am mapadh gu 'a' gu 'z', ach tha litrichean neo-ASCII gun atharrachadh.
    ///
    /// Gus an luach a lughdachadh na àite, cleachd [`make_ascii_lowercase`].
    ///
    /// Gus caractaran ASCII a thoirt a-steach a bharrachd air caractaran neo-ASCII, cleachd [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() a `gleidheadh an UTF-8 invariant.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Bidh e ag atharrachadh sliseag bocsa de bhocsa gu sliseag sreang le bogsa gun a bhith a `dèanamh cinnteach gu bheil UTF-8 dligheach anns an t-sreang.
///
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}