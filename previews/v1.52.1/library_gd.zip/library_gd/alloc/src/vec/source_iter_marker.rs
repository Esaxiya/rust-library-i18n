use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Comharra speisealta airson a bhith a `tional loidhne-phìoban itealain a-steach do Vec fhad` s a tha e ag ath-chleachdadh an riarachadh stòr, i.e.
/// a `cur an gnìomh an loidhne-phìoban na àite.
///
/// Tha feum air pàrant SourceIter trait gus am faigh an gnìomh sònraichte cothrom air an riarachadh a tha ri ath-chleachdadh.
/// Ach chan eil e gu leòr airson an speisealachadh a bhith dligheach.
/// Faic crìochan a bharrachd air an impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Tha an std-internal SourceIter/InPlaceIterable traits air an cur an gnìomh le slabhraidhean Adapter a-mhàin <Adapter<Adapter<IntoIter>>> (uile le core/std).
// Tha crìochan a bharrachd air buileachadh an adapter (nas fhaide na `impl<I: Trait> Trait for Adapter<I>`) a-mhàin an urra ri traits eile a tha air an comharrachadh mar speisealachadh traits (Leth-bhreac, TrustedRandomAccess, FusedIterator).
//
// I.e. chan eil an comharradh an urra ri beatha de sheòrsaichean a gheibh luchd-cleachdaidh.Modulo an toll Leth-bhreac, air a bheil grunn speisealaichean eile an urra mu thràth.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Riatanasan a bharrachd nach gabh an cur an cèill tro trait bounds.Tha sinn an urra ri measadh seasmhach na àite:
        // a) no ZSTan oir cha bhiodh riarachadh sam bith ann airson ath-chleachdadh agus àireamhachd puing bhiodh panic b) meud a rèir mar a tha air iarraidh le cùmhnant Alloc c) tha co-thaobhadh a rèir mar a tha riatanach le cùmhnant Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // tuiteam air ais gu buileachadh nas gnèitheile
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // cleachdadh feuchaibh-fhillte bho
        // - tha e nas fheàrr airson cuid de na h-innealan-atharrachaidh iterator
        // - eu-coltach ris a `mhòr-chuid de dhòighean iteachaidh a-staigh, cha toir e ach &mut fèin
        // - bidh e a `leigeil leinn a` phuing sgrìobhaidh a shnìomh tro na taighean-seinnse aige agus fhaighinn air ais aig a `cheann thall
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iteration air soirbheachadh, na leig às do cheann
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // thoir sùil air an deach gabhail ri cùmhnant SourceIter mar chatat: mura robh iad ann is dòcha nach dèan sinn eadhon chun na h-ìre seo
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // thoir sùil air cùmhnant InPlaceIterable.Cha bhith seo comasach ach ma rinn an itealaiche puing na stòr idir.
        // Ma tha e a 'cleachdadh unchecked cothrom tro TrustedRandomAccess an uair sin an tobar chomharra a' fuireach anns a 'chiad suidheachadh is chan urrainn dhuinn iomradh ga chleachdadh mar
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // leig às luachan sam bith a tha air fhàgail aig earball an stòr ach cuir casg air tuiteam den riarachadh fhèin aon uair `s gu bheil IntoIter a` dol a-mach à farsaingeachd ma thuiteas an panics, bidh sinn cuideachd a `leigeil a-mach eileamaidean sam bith a chaidh a chruinneachadh a-steach do dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // chan urrainnear a `chùmhnant InPlaceIterable a dhearbhadh gu mionaideach an seo leis gu bheil iomradh sònraichte aig try_fold air comharradh an stòr nach urrainn dhuinn a dhèanamh ach dèanamh cinnteach a bheil e fhathast ann an raon
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}