use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Reultair a chleachdas dùnadh gus faighinn a-mach am bu chòir eileamaid a thoirt air falbh.
///
/// Tha an structar seo air a chruthachadh le [`Vec::drain_filter`].
/// Faic na sgrìobhainnean aige airson tuilleadh.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Clàr-amais an rud a thèid a sgrùdadh leis an ath ghairm gu `next`.
    pub(super) idx: usize,
    /// An àireamh de nithean a chaidh a dhrèanadh (removed) gu ruige seo.
    pub(super) del: usize,
    /// An fhad tùsail de `vec` mus deach a dhrèanadh.
    pub(super) old_len: usize,
    /// Tha an deuchainn sìoltachain ro-innse.
    pub(super) pred: F,
    /// Tha bratach a tha a `comharrachadh panic air tachairt anns an ro-innse deuchainn sìoltachain.
    /// Tha seo air a chleachdadh mar sanas ann am buileachadh tuiteam gus casg a chuir air caitheamh a `chòrr den `DrainFilter`.
    /// Thèid stuth neo-ullaichte sam bith a thionndadh air ais san `vec`, ach cha tèid nithean sam bith eile a leigeil seachad no deuchainn a dhèanamh orra leis an t-sìoltachan.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// A `tilleadh iomradh air an neach-sònrachaidh bunaiteach.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Ùraich an clàr-amais *às deidh* canar an predicate.
                // Ma thèid an clàr-amais ùrachadh ro-làimh agus an ro-innse panics, bhiodh an eileamaid aig a `chlàr-amais seo air a leigeil a-mach.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Is e suidheachadh gu math duilich a tha seo, agus gu dearbh chan eil dad ceart ri dhèanamh.
                        // Chan eil sinn airson cumail oirnn a `feuchainn ri `pred` a chuir gu bàs, agus mar sin bidh sinn dìreach a` dèanamh cùl-taic de na h-eileamaidean gun phròiseas agus ag innse don vec gu bheil iad ann fhathast.
                        //
                        // Feumar an cùl-taic gus casg a chuir air tuiteam dùbailte den rud mu dheireadh a chaidh a dhrèanadh gu soirbheachail ro panic san ro-innse.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Feuch ri na h-eileamaidean a tha air fhàgail ithe mura h-eil an sìoltachan ro-innseach air clisgeadh.
        // Cuiridh sinn cùl ri eileamaidean sam bith a tha air fhàgail co-dhiù a tha sinn air clisgeadh mu thràth no ma tha an caitheamh an seo panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}