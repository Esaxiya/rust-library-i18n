// Suidhich fad an vec nuair a thèid an luach `SetLenOnDrop` a-mach à farsaingeachd.
//
// Is e am beachd: Tha an raon faid ann an SetLenOnDrop na chaochladair ionadail a chì an optimizer nach eil e a `co-thaobhadh ri stòran sam bith tro chomharradh dàta Vec.
// Is e seo sruth-obrach airson cùis anailis ailias #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}