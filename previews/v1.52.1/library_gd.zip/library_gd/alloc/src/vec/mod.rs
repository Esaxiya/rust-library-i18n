//! Seòrsa eagar fàsmhor dlùth le susbaint air a riarachadh le tiùrr, sgrìobhte `Vec<T>`.
//!
//! Tha clàr-amais `O(1)` aig Vectors, putadh `O(1)` air a thortachadh (gu deireadh) agus `O(1)` pop (bhon deireadh).
//!
//!
//! Bidh Vectors a `dèanamh cinnteach nach bi iad a-riamh a` riarachadh barrachd air `isize::MAX` bytes.
//!
//! # Examples
//!
//! Faodaidh tu gu sònraichte [`Vec`] a chruthachadh le [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... no le bhith a `cleachdadh macro [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // deich neoni
//! ```
//!
//! Faodaidh tu luachan [`push`] a chuir air deireadh vector (a dh'fhàsas an vector mar a dh `fheumar):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Bidh luachan popping ag obair san aon dòigh:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Bidh Vectors cuideachd a `toirt taic do chlàr-amais (tron [`Index`] agus [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Seòrsa eagar fàsmhor ri taobh, air a sgrìobhadh mar `Vec<T>` agus air fhuaimneachadh 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Tha am macro [`vec!`] air a thoirt seachad gus tùsachadh a dhèanamh nas goireasaiche:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Faodaidh e cuideachd gach eileamaid de `Vec<T>` a thòiseachadh le luach sònraichte.
/// Is dòcha gum bi seo nas èifeachdaiche na bhith a `coileanadh riarachadh agus tùsachadh ann an ceumannan fa leth, gu sònraichte nuair a thòisicheas tu vector de neoni:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Tha na leanas co-ionann, ach a dh `fhaodadh a bhith nas slaodaiche:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Airson tuilleadh fiosrachaidh, faic [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Cleachd `Vec<T>` mar chruach èifeachdach:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Clò-bhualaidhean 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Leigidh an seòrsa `Vec` faighinn gu luachan a rèir clàr-amais, seach gu bheil e a `buileachadh an [`Index`] trait.Bidh eisimpleir nas soilleire:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // seallaidh e '2'
/// ```
///
/// Ach bi faiceallach: ma tha thu 'feuchainn ri cothrom fhaighinn air an clàr-amais nach eil anns a' `Vec`, bidh agad bathar-bog panic!Chan urrainn dhut seo a dhèanamh:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Cleachd [`get`] agus [`get_mut`] ma tha thu airson faighinn a-mach a bheil an clàr-amais san `Vec`.
///
/// # Slicing
///
/// Faodaidh `Vec` a bhith gluasadach.Air an làimh eile, tha sliseagan nan stuthan leughaidh a-mhàin.
/// Gus [slice][prim@slice] fhaighinn, cleachd [`&`].Eisimpleir:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... agus sin e!
/// // faodaidh tu cuideachd a dhèanamh mar seo:
/// let u: &[usize] = &v;
/// // no mar seo:
/// let u: &[_] = &v;
/// ```
///
/// Ann an Rust, tha e nas cumanta a bhith a `dol seachad air sliseagan mar argamaidean seach vectors nuair a tha thu dìreach airson ruigsinneachd leughaidh a thoirt seachad.Tha an aon rud a`dol airson [`String`] agus [`&str`].
///
/// # Comas agus ath-riarachadh
///
/// Is e comas vector an ìre de dh `àite a chaidh a riarachadh airson eileamaidean future sam bith a thèid a chur ris an vector.Cha bu chòir seo a mheasgadh le *fad* vector, a tha a`sònrachadh an àireamh de fhìor eileamaidean taobh a-staigh an vector.
/// Ma tha fad vector a `dol thairis air a chomas, thèid a chomas àrdachadh gu fèin-ghluasadach, ach feumar na h-eileamaidean aige ath-riarachadh.
///
/// Mar eisimpleir, bhiodh vector le comas 10 agus fad 0 na vector falamh le àite airson 10 eileamaidean a bharrachd.Cha bhith a `putadh 10 no nas lugha de eileamaidean air an vector ag atharrachadh a comas no ag adhbhrachadh ath-riarachadh.
/// Ach, ma thèid fad an vector a mheudachadh gu 11, feumaidh e ath-riarachadh, a dh `fhaodadh a bhith slaodach.Air an adhbhar seo, thathas a`moladh [`Vec::with_capacity`] a chleachdadh nuair as urrainnear gus sònrachadh dè cho mòr sa tha dùil gum faigh an vector.
///
/// # Guarantees
///
/// Air sgàth a nàdar iongantach bunaiteach, tha `Vec` a `toirt mòran gheallaidhean mun dealbhadh aige.Bidh seo a`dèanamh cinnteach gu bheil e cho ìosal os cionn na ghabhas sa chùis choitcheann, agus faodar a làimhseachadh gu ceart ann an dòighean prìomhadail le còd neo-shàbhailte.Thoir fa-near gu bheil na geallaidhean sin a `toirt iomradh air `Vec<T>` gun teisteanas.
/// Ma thèid paramadairean seòrsa a bharrachd a chur ris (me, gus taic a thoirt do luchd-sgaoilidh àbhaisteach), faodaidh a bhith a `dol thairis air na fàbharan aca an giùlan atharrachadh.
///
/// Gu bunaiteach, tha `Vec` agus bidh e an-còmhnaidh na triple (puing, comas, fad).Chan eil barrachd, chan eil nas lugha.Tha òrdugh nan raointean sin gu tur neo-ainmichte, agus bu chòir dhut na dòighean iomchaidh a chleachdadh gus iad sin atharrachadh.
/// Cha tèid am puing gu bràth a-null, agus mar sin tha an seòrsa seo null-pointer-optimized.
///
/// Ach, dh `fhaodadh nach bi am puing gu dearbh a` comharrachadh cuimhne a chaidh a riarachadh.
/// Gu sònraichte, ma thogas tu `Vec` le comas 0 tro [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], no le bhith a `gairm [`shrink_to_fit`] air Vec falamh, cha riaraich e cuimhne.San aon dòigh, ma ghlèidheas tu seòrsan meud neoni taobh a-staigh `Vec`, cha riaraich e àite dhaibh.
/// *Thoir fa-near, sa chùis seo, is dòcha nach toir an `Vec` cunntas air [`capacity`] de 0*.
/// `Vec` a riarachadh ma tha agus dìreach ma tha [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// San fharsaingeachd, tha mion-fhiosrachadh mu riarachadh `Vec` gu math subailte-ma tha thu an dùil cuimhne a riarachadh a`cleachdadh `Vec` agus a chleachdadh airson rudeigin eile (an dàrna cuid gus a dhol gu còd neo-shàbhailte, no gus do chruinneachadh le taic cuimhne fhèin a thogail), bi cinnteach gus an cuimhne seo a thuigsinn le bhith a`cleachdadh `from_raw_parts` gus an `Vec` fhaighinn air ais agus an uairsin a leigeil às.
///
/// Ma tha `Vec`*air* cuimhne a riarachadh, tha an cuimhne air a bheil e a `comharrachadh air a` chàrn (mar a tha e air a mhìneachadh leis an riaraiche Rust air a rèiteachadh gus a chleachdadh gu bunaiteach), agus tha na puingean aige a `comharrachadh [`len`] eileamaidean tòiseachaidh, dlùth-cheangail ann an òrdugh (na bhiodh tu a` dèanamh faic an do cho-èignich thu e gu sliseag), air a leantainn le [`comas`]`,`[`len`] gu loidsigeach neo-aithnichte, co-shìnte ri chèile.
///
///
/// Faodar vector anns a bheil na h-eileamaidean `'a'` agus `'b'` le comas 4 fhaicinn mar gu h-ìosal.Is e am pàirt gu h-àrd an structar `Vec`, tha comharradh ann gu ceann an riarachaidh anns an tiùrr, fad agus comas.
/// Is e am pàirt gu h-ìosal an riarachadh air an tiùrr, bloc cuimhne co-shìnte.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - Tha **uninit** a `riochdachadh cuimhne nach eil air a thòiseachadh, faic [`MaybeUninit`].
/// - Note: chan eil an ABI seasmhach agus chan eil `Vec` a `toirt gealladh sam bith mu chruth a chuimhne (a` gabhail a-steach òrdugh raointean).
///
/// `Vec` cha dèan iad "small optimization" gu bràth far a bheil eileamaidean air an stòradh air a `chruach airson dà adhbhar:
///
/// * Dhèanadh e nas duilghe còd mì-shàbhailte `Vec` a làimhseachadh gu ceart.Cha bhiodh seòladh seasmhach aig susbaint `Vec` mura deidheadh a ghluasad ach, agus bhiodh e na bu dorra faighinn a-mach an robh `Vec` air cuimhne a riarachadh.
///
/// * Bheireadh e peanas don chùis choitcheann, a `toirt a-steach branch a bharrachd air gach ruigsinneachd.
///
/// `Vec` cha lughdaich e gu fèin-ghluasadach, eadhon ged a bhios e falamh.Bidh seo a `dèanamh cinnteach nach tachair riarachadh no tuigse neo-riatanach.Le bhith a`falmhachadh `Vec` agus an uairsin ga lìonadh air ais suas chun an aon [`len`] cha bu chòir fiosan sam bith a thoirt don neach-riarachaidh.Ma tha thu airson cuimhne gun chleachdadh a shaoradh, cleachd [`shrink_to_fit`] no [`shrink_to`].
///
/// [`push`] agus cha toir [`insert`] (ath) riarachadh a-riamh ma tha an comas aithriseach gu leòr.Bidh [`push`] agus [`insert`] * a `riarachadh ma tha [` len`]`==`[`comas`].Is e sin, tha an comas a chaidh aithris gu tur ceart, agus faodar earbsa a bhith ann.Faodar a chleachdadh eadhon gus an cuimhne a chaidh a thoirt seachad le `Vec` a shaoradh le làimh ma thogras tu.
/// Faodaidh modhan cuir a-steach mòr * ath-riarachadh, eadhon nuair nach eil sin riatanach.
///
/// `Vec` chan eil sin a `gealltainn ro-innleachd fàis sònraichte nuair a thèid ath-riarachadh nuair a tha e làn, no nuair a thèid [`reserve`] a ghairm.Tha an ro-innleachd làithreach bunaiteach agus dh`fhaodadh gum biodh e feumail feart fàis neo-sheasmhach a chleachdadh.Ge bith dè an ro-innleachd a thèid a chleachdadh geallaidh e gu cinnteach *O*(1) amortachadh [`push`].
///
/// `vec![x; n]`, Bidh `vec![a, b, c, d]`, agus [`Vec::with_capacity(n)`][`Vec::with_capacity`], uile a `toirt a-mach `Vec` leis a` chomas a chaidh iarraidh.
/// Ma tha [`len`]`==`[`comas`], (mar a tha fìor airson macro [`vec!`]), faodar `Vec<T>` a thionndadh gu agus bho [`Box<[T]>`][owned slice] gun ath-riarachadh no gluasad nan eileamaidean.
///
/// `Vec` cha sgrìobh e gu sònraichte dàta sam bith a thèid a thoirt air falbh, ach cha ghlèidh e gu sònraichte e.Is e a chuimhne neo-aithnichte àite sgrìobadh a dh `fhaodadh e a chleachdadh ge-tà tha e ag iarraidh.Bidh e san fharsaingeachd dhèanamh dìreach ge bith dè as èifeachdaiche no furasta a chaochladh a chur an gnìomh.Na bi earbsa ann an dàta air a thoirt air falbh airson a dhubhadh às airson adhbharan tèarainteachd.
/// Fiù `s ma chuireas tu sìos `Vec`, is dòcha gun tèid am bufair aige ath-chleachdadh le `Vec` eile.
/// Fiù mura cuir thu cuimhne `Vec` an-toiseach, is dòcha nach tachair sin leis nach eil an optimizer den bheachd gur e frith-bhuaidh a tha seo a dh` fheumar a ghleidheadh.
/// Tha aon chùis ann nach bris sinn, ge-tà: tha cleachdadh còd `unsafe` gus sgrìobhadh chun cus comas, agus an uairsin àrdachadh an fhaid gus a bhith co-ionnan, an-còmhnaidh dligheach.
///
/// An-dràsta, chan eil `Vec` a `gealltainn an òrdugh anns an tèid eileamaidean a leigeil sìos.
/// Tha an t-òrdugh air atharrachadh san àm a dh `fhalbh agus dh` fhaodadh e atharrachadh a-rithist.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Modhan gnèitheach
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// A `togail `Vec<T>` ùr, falamh.
    ///
    /// Cha riaraich an vector gus an tèid eileamaidean a phutadh air.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// A `togail `Vec<T>` ùr, falamh leis a` chomas ainmichte.
    ///
    /// Bidh an vector comasach air eileamaidean `capacity` a chumail gun ath-riarachadh.
    /// Ma tha `capacity` 0, cha riaraich an vector.
    ///
    /// Tha e cudromach toirt fa-near, ged a tha an *comas* ainmichte aig an vector a chaidh a thilleadh, bidh fad neoni * aig an vector.
    ///
    /// Airson mìneachadh air an eadar-dhealachadh eadar faid agus comas, faic *[Comas agus ath-riarachadh]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // Chan eil nithean anns an vector, eadhon ged a tha comas aige airson barrachd
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Tha iad sin uile air an dèanamh gun ath-riarachadh ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ach dh `fhaodadh seo toirt air an vector ath-riarachadh
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// A `cruthachadh `Vec<T>` gu dìreach bho na pàirtean amh de vector eile.
    ///
    /// # Safety
    ///
    /// Tha seo glè shàbhailte, mar thoradh air an àireamh de luchd-ionnsaigh nach eilear a `sgrùdadh:
    ///
    /// * `ptr` feumar a bhith air a riarachadh roimhe seo tro [`String`]/`Vec<T>`(co-dhiù, tha e glè choltach gum bi e ceàrr mura robh).
    /// * `T` feumaidh an aon mheud agus co-thaobhadh a bhith aige ris na chaidh `ptr` a riarachadh.
    ///   (Chan eil `T` aig a bheil co-thaobhadh cho teann gu leòr, feumaidh an co-thaobhadh a bhith co-ionann gus coinneachadh ris an riatanas [`dealloc`] gum feumar cuimhne a riarachadh agus a thuigsinn leis an aon chruth.)
    ///
    /// * `length` feumaidh e a bhith nas lugha na no co-ionann ri `capacity`.
    /// * `capacity` feumaidh an comas a bhith aig a `phuing.
    ///
    /// Faodaidh briseadh iad sin duilgheadasan adhbhrachadh mar bhith a `truailleadh structaran dàta a-staigh an neach-sònrachaidh.Mar eisimpleir chan eil e **sàbhailte**`Vec<u8>` a thogail bho stiùireadh gu sreath C `char` le fad `size_t`.
    /// Chan eil e sàbhailte cuideachd aon a thogail bho `Vec<u16>` agus a fhad, oir tha an neach-riarachaidh a `gabhail cùram mun cho-thaobhadh, agus tha co-thaobhadh eadar-dhealaichte aig an dà sheòrsa sin.
    /// Chaidh am bufair a riarachadh le co-thaobhadh 2 (airson `u16`), ach an dèidh dha a thionndadh gu `Vec<u8>` thèid a thuigsinn le co-thaobhadh 1.
    ///
    /// Tha seilbh `ptr` air a ghluasad gu h-èifeachdach chun `Vec<T>` a dh `fhaodadh an uairsin susbaint a` chuimhne a chomharraich am putan aig toil a thuigsinn, ath-riarachadh no atharrachadh.
    /// Dèan cinnteach nach bi dad sam bith eile a `cleachdadh a` phuing às deidh dhut an gnìomh seo a ghairm.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Ùraich seo nuair a thèid vec_into_raw_parts a dhèanamh seasmhach.
    ///     // Cuir stad air a bhith a `ruith inneal-sgrios` v` gus am bi smachd iomlan againn air an riarachadh.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Tarraing a-mach na diofar phìosan fiosrachaidh cudromach mu `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Cuir thairis cuimhne le 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Cuir a h-uile càil air ais còmhla ann an Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// A `togail `Vec<T, A>` ùr, falamh.
    ///
    /// Cha riaraich an vector gus an tèid eileamaidean a phutadh air.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// A `togail `Vec<T, A>` ùr, falamh leis a` chomas ainmichte leis an riaraiche a chaidh a thoirt seachad.
    ///
    /// Bidh an vector comasach air eileamaidean `capacity` a chumail gun ath-riarachadh.
    /// Ma tha `capacity` 0, cha riaraich an vector.
    ///
    /// Tha e cudromach toirt fa-near, ged a tha an *comas* ainmichte aig an vector a chaidh a thilleadh, bidh fad neoni * aig an vector.
    ///
    /// Airson mìneachadh air an eadar-dhealachadh eadar faid agus comas, faic *[Comas agus ath-riarachadh]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // Chan eil nithean anns an vector, eadhon ged a tha comas aige airson barrachd
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Tha iad sin uile air an dèanamh gun ath-riarachadh ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ach dh `fhaodadh seo toirt air an vector ath-riarachadh
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// A `cruthachadh `Vec<T, A>` gu dìreach bho na pàirtean amh de vector eile.
    ///
    /// # Safety
    ///
    /// Tha seo glè shàbhailte, mar thoradh air an àireamh de luchd-ionnsaigh nach eilear a `sgrùdadh:
    ///
    /// * `ptr` feumar a bhith air a riarachadh roimhe seo tro [`String`]/`Vec<T>`(co-dhiù, tha e glè choltach gum bi e ceàrr mura robh).
    /// * `T` feumaidh an aon mheud agus co-thaobhadh a bhith aige ris na chaidh `ptr` a riarachadh.
    ///   (Chan eil `T` aig a bheil co-thaobhadh cho teann gu leòr, feumaidh an co-thaobhadh a bhith co-ionann gus coinneachadh ris an riatanas [`dealloc`] gum feumar cuimhne a riarachadh agus a thuigsinn leis an aon chruth.)
    ///
    /// * `length` feumaidh e a bhith nas lugha na no co-ionann ri `capacity`.
    /// * `capacity` feumaidh an comas a bhith aig a `phuing.
    ///
    /// Faodaidh briseadh iad sin duilgheadasan adhbhrachadh mar bhith a `truailleadh structaran dàta a-staigh an neach-sònrachaidh.Mar eisimpleir chan eil e **sàbhailte**`Vec<u8>` a thogail bho stiùireadh gu sreath C `char` le fad `size_t`.
    /// Chan eil e sàbhailte cuideachd aon a thogail bho `Vec<u16>` agus a fhad, oir tha an neach-riarachaidh a `gabhail cùram mun cho-thaobhadh, agus tha co-thaobhadh eadar-dhealaichte aig an dà sheòrsa sin.
    /// Chaidh am bufair a riarachadh le co-thaobhadh 2 (airson `u16`), ach an dèidh dha a thionndadh gu `Vec<u8>` thèid a thuigsinn le co-thaobhadh 1.
    ///
    /// Tha seilbh `ptr` air a ghluasad gu h-èifeachdach chun `Vec<T>` a dh `fhaodadh an uairsin susbaint a` chuimhne a chomharraich am putan aig toil a thuigsinn, ath-riarachadh no atharrachadh.
    /// Dèan cinnteach nach bi dad sam bith eile a `cleachdadh a` phuing às deidh dhut an gnìomh seo a ghairm.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Ùraich seo nuair a thèid vec_into_raw_parts a dhèanamh seasmhach.
    ///     // Cuir stad air a bhith a `ruith inneal-sgrios` v` gus am bi smachd iomlan againn air an riarachadh.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Tarraing a-mach na diofar phìosan fiosrachaidh cudromach mu `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Cuir thairis cuimhne le 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Cuir a h-uile càil air ais còmhla ann an Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// A `lobhadh `Vec<T>` na phàirtean amh.
    ///
    /// A `tilleadh a` phuing amh chun an dàta bunaiteach, fad an vector (ann an eileamaidean), agus comas ainmichte an dàta (ann an eileamaidean).
    /// Is iad sin na h-aon argamaidean san aon òrdugh ris na h-argamaidean gu [`from_raw_parts`].
    ///
    /// An dèidh a 'gairm a' ghnìomh seo, an neach-conaltraidh a tha uallach airson an cuimhne roimhe seo air a stiùireadh leis a `Vec`.
    /// Is e an aon dòigh air seo a dhèanamh am puing amh, fad, agus comas a thionndadh air ais gu `Vec` leis a `ghnìomh [`from_raw_parts`], a` leigeil leis an inneal-sgrios an glanadh a dhèanamh.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Faodaidh sinn a-nis a 'dèanamh atharrachaidhean air a' cho-phàirtean, leithid transmuting amh chomharra air co-chòrdail seòrsa.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// A `lobhadh `Vec<T>` na phàirtean amh.
    ///
    /// Thilleas amh na chomharra air an cùl dàta, fad an vector (ann eileamaidean), a 'riarachadh comas an dàta (ann eileamaidean), agus allocator.
    /// Is iad sin na h-aon argamaidean san aon òrdugh ris na h-argamaidean gu [`from_raw_parts_in`].
    ///
    /// An dèidh a 'gairm a' ghnìomh seo, an neach-conaltraidh a tha uallach airson an cuimhne roimhe seo air a stiùireadh leis a `Vec`.
    /// Is e an aon dòigh air seo a dhèanamh am puing amh, fad, agus comas a thionndadh air ais gu `Vec` leis a `ghnìomh [`from_raw_parts_in`], a` leigeil leis an inneal-sgrios an glanadh a dhèanamh.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Faodaidh sinn a-nis a 'dèanamh atharrachaidhean air a' cho-phàirtean, leithid transmuting amh chomharra air co-chòrdail seòrsa.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// A `tilleadh an àireamh de eileamaidean a dh` fhaodas an vector a chumail gun ath-riarachadh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// A `gleidheadh comas airson co-dhiù `additional` barrachd eileamaidean a chuir a-steach san `Vec<T>` a chaidh a thoirt seachad.
    /// Is dòcha gun glèidh an cruinneachadh barrachd àite gus ath-riarachadh tric a sheachnadh.
    /// Às deidh `reserve` a ghairm, bidh comas nas motha na no co-ionann ri `self.len() + additional`.
    /// A `dèanamh dad ma tha comas gu leòr mar-thà.
    ///
    /// # Panics
    ///
    /// Panics ma ùr comas nas àirde `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// A `glèidheadh a` chomais as lugha airson dìreach `additional` barrachd eileamaidean a chuir a-steach san `Vec<T>` a chaidh a thoirt seachad.
    ///
    /// Às deidh `reserve_exact` a ghairm, bidh comas nas motha na no co-ionann ri `self.len() + additional`.
    /// A `dèanamh dad ma tha an comas gu leòr mar-thà.
    ///
    /// Thoir fa-near gum faod an neach-riarachaidh barrachd àite a thoirt don chruinneachadh na tha e ag iarraidh.
    /// Mar sin, chan urrainnear a bhith an urra ri comas a bhith fìor bheag.
    /// B `fheàrr le `reserve` ma tha dùil ri cuir a-steach future.
    ///
    /// # Panics
    ///
    /// Panics ma tha an comas ùr a `dol thairis air `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// A `feuchainn ri comas a ghlèidheadh airson co-dhiù `additional` barrachd eileamaidean a chuir a-steach san `Vec<T>` a chaidh a thoirt seachad.
    /// Is dòcha gun glèidh an cruinneachadh barrachd àite gus ath-riarachadh tric a sheachnadh.
    /// Às deidh `try_reserve` a ghairm, bidh comas nas motha na no co-ionann ri `self.len() + additional`.
    /// A `dèanamh dad ma tha comas gu leòr mar-thà.
    ///
    /// # Errors
    ///
    /// Ma tha an comas a `dol thairis, no ma tha an neach-riarachaidh ag aithris air fàiligeadh, thèid mearachd a thilleadh.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Glèidh a `chuimhne ro-làimh, a` falbh mura h-urrainn dhuinn
    ///     output.try_reserve(data.len())?;
    ///
    ///     // A-nis tha fios againn nach urrainn seo OOM a dhèanamh ann am meadhan ar n-obair iom-fhillte
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // gu math toinnte
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// A `feuchainn ris a` chomas as lugha a ghleidheadh airson eileamaidean `additional` dìreach a chuir a-steach san `Vec<T>` a chaidh a thoirt seachad.
    /// Às deidh dha `try_reserve_exact` a ghairm, bidh comas nas motha na no co-ionann ri `self.len() + additional` ma thilleas e `Ok(())`.
    ///
    /// A `dèanamh dad ma tha an comas gu leòr mar-thà.
    ///
    /// Thoir fa-near gum faod an neach-riarachaidh barrachd àite a thoirt don chruinneachadh na tha e ag iarraidh.
    /// Mar sin, chan urrainnear a bhith an urra ri comas a bhith fìor bheag.
    /// B `fheàrr le `reserve` ma tha dùil ri cuir a-steach future.
    ///
    /// # Errors
    ///
    /// Ma tha an comas a `dol thairis, no ma tha an neach-riarachaidh ag aithris air fàiligeadh, thèid mearachd a thilleadh.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Glèidh a `chuimhne ro-làimh, a` falbh mura h-urrainn dhuinn
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // A-nis tha fios againn nach urrainn seo OOM a dhèanamh ann am meadhan ar n-obair iom-fhillte
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // gu math toinnte
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// A `lughdachadh comas an vector cho mòr` s a ghabhas.
    ///
    /// Bidh e a `tuiteam sìos cho faisg` s as urrainn don fhad ach is dòcha gum bi an neach-sònrachaidh fhathast ag innse don vector gu bheil àite ann airson beagan a bharrachd eileamaidean.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Chan eil an comas a-riamh nas lugha na an fhaid, agus chan eil dad ri dhèanamh nuair a tha iad co-ionann, agus mar sin is urrainn dhuinn cùis panic a sheachnadh ann an `RawVec::shrink_to_fit` le bhith dìreach ga ghairm le comas nas motha.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// A `crìonadh comas an vector le crìoch nas ìsle.
    ///
    /// Bidh an comas co-dhiù cho mòr ris an dà chuid an fhaid agus an luach a chaidh a thoirt seachad.
    ///
    ///
    /// Ma tha an comas làithreach nas ìsle na an ìre as ìsle, is e neo-op a tha seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Bidh e ag atharrachadh an vector gu [`Box<[T]>`][owned slice].
    ///
    /// Thoir fa-near gun leig seo sìos cus comas.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Thèid comas sam bith a bharrachd a thoirt air falbh:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// A `giorrachadh an vector, a` cumail a `chiad eileamaidean `len` agus a` leigeil às a `chòrr.
    ///
    /// Ma tha `len` nas motha na fad gnàthach vector, chan eil buaidh sam bith aig seo.
    ///
    /// Faodaidh an dòigh [`drain`] aithris air `truncate`, ach tha e ag adhbhrachadh gun tèid na h-eileamaidean a bharrachd a thilleadh an àite tuiteam.
    ///
    ///
    /// Thoir fa-near nach eil buaidh sam bith aig an dòigh seo air comas ainmichte an vector.
    ///
    /// # Examples
    ///
    /// A `triall còig eileamaid vector gu dà eileamaid:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Chan eil truncation a `tachairt nuair a tha `len` nas motha na fad làithreach an vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// A `tilgeil nuair a tha `len == 0` co-ionnan ri bhith a` gairm modh [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Tha seo sàbhailte oir:
        //
        // * tha an sliseag a chaidh seachad gu `drop_in_place` dligheach;tha cùis `len > self.len` a `seachnadh a bhith a` cruthachadh sliseag neo-dhligheach, agus
        // * tha an `len` den vector air a lughdachadh mus cuir e fios gu `drop_in_place`, gus nach tèid luach sam bith a leigeil sìos dà uair air eagal `s gum biodh `drop_in_place` gu panic aon uair (ma tha e panics dà uair, sguir am prògram).
        //
        //
        //
        unsafe {
            // Note: Tha e san amharc gur e `>` a tha seo agus chan e `>=`.
            //       Le bhith ga atharrachadh gu `>=` tha buaidh àicheil air coileanadh ann an cuid de chùisean.
            //       Faic #78884 airson tuilleadh.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// A `toirt a-mach sliseag anns a bheil an vector gu lèir.
    ///
    /// Co-ionann ri `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// A `toirt a-mach sliseag gluasadach den vector gu lèir.
    ///
    /// Co-ionann ri `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// A `tilleadh stiùireadh amh gu bufair vector.
    ///
    /// Feumaidh an neach-fòn dèanamh cinnteach gu bheil an vector a `toirt a-mach a` phuing a thilleas an gnìomh seo, no air dhòigh eile thig e gu crìch a `comharrachadh sgudal.
    /// Dh `fhaodadh atharrachadh an vector adhbhrachadh gum bi am bufair aige air ath-riarachadh, a dhèanadh cuideachd comharran sam bith ris gu neo-dhligheach.
    ///
    /// Feumaidh an neach-fios cuideachd dèanamh cinnteach nach tèid a `chuimhne a tha am puing (non-transitively) a` sgrìobhadh thuige (ach taobh a-staigh `UnsafeCell`) a `cleachdadh a` phuing seo no puing sam bith a thig às.
    /// Ma dh `fheumas tu susbaint na sliseag a mhùchadh, cleachd [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Bidh sinn a `toirt sgàil air an dòigh slice den aon ainm gus nach tèid thu tro `deref`, a chruthaicheas iomradh eadar-mheadhanach.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// A `tilleadh stiùireadh gluasadach neo-shàbhailte gu bufair vector.
    ///
    /// Feumaidh an neach-fòn dèanamh cinnteach gu bheil an vector a `toirt a-mach a` phuing a thilleas an gnìomh seo, no air dhòigh eile thig e gu crìch a `comharrachadh sgudal.
    ///
    /// Dh `fhaodadh atharrachadh an vector adhbhrachadh gum bi am bufair aige air ath-riarachadh, a dhèanadh cuideachd comharran sam bith ris gu neo-dhligheach.
    ///
    /// # Examples
    ///
    /// ```
    /// // Riarachadh vector mòr gu leòr airson 4 eileamaidean.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Tòisich eileamaidean tro sgrìobhadh puing amh, an uairsin cuir sìos fad.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Bidh sinn a `toirt sgàil air an dòigh slice den aon ainm gus nach tèid thu tro `deref_mut`, a chruthaicheas iomradh eadar-mheadhanach.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// A `tilleadh iomradh air an neach-sònrachaidh bunaiteach.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// A `sparradh fad an vector gu `new_len`.
    ///
    /// Is e obrachadh ìre ìosal a tha seo nach eil a `cumail suas gin de na h-invariants àbhaisteach den t-seòrsa.
    /// Mar as trice bidh atharrachadh fad vector air a dhèanamh le bhith a `cleachdadh aon de na h-obraichean sàbhailte na àite, leithid [`truncate`], [`resize`], [`extend`], no [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` feumaidh e a bhith nas lugha na no co-ionann ri [`capacity()`].
    /// - Feumar na h-eileamaidean aig `old_len..new_len` a thòiseachadh.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Faodaidh an dòigh seo a bhith feumail airson suidheachaidhean far a bheil an vector a `frithealadh mar bufair airson còd eile, gu sònraichte thairis air FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Is e seo dìreach cnàimhneach as ìsle airson an eisimpleir doc;
    /// # // na cleachd seo mar àite tòiseachaidh airson fìor leabharlann.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // A rèir docaichean an dòigh FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SÀBHAILTEACHD: Nuair a thilleas `deflateGetDictionary` `Z_OK`, tha e a 'cumail:
    ///     // 1. `dict_length` chaidh eileamaidean a thòiseachadh.
    ///     // 2.
    ///     // `dict_length` <=an comas (32_768) a tha a `dèanamh `set_len` sàbhailte a ghairm.
    ///     unsafe {
    ///         // Dèan gairm FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... agus ùraich an fhaid chun na chaidh a thòiseachadh.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Ged a tha an eisimpleir a leanas làidir, tha aodion cuimhne ann bho nach deach na vectors a-staigh a shaoradh mus deach an gairm `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` falamh agus mar sin chan fheumar eileamaidean a thòiseachadh.
    /// // 2. `0 <= capacity` an-còmhnaidh a `cumail ge bith dè a th` ann an `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Mar as trice, an seo, bhiodh aon a `cleachdadh [`clear`] na àite gus an susbaint a leigeil sìos gu ceart agus mar sin gun a bhith a` leigeil às cuimhne.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// A `toirt air falbh eileamaid bhon vector agus ga thilleadh.
    ///
    /// Tha an eileamaid mu dheireadh den vector air a chur na àite.
    ///
    /// Chan eil seo a `gleidheadh òrdachadh, ach is e O(1) a th` ann.
    ///
    /// # Panics
    ///
    /// Panics ma tha `index` a-mach à crìochan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Bidh sinn a `cur an àite fèin [clàr-amais] leis an eileamaid mu dheireadh.
            // Thoir fa-near, ma shoirbhicheas leis an sgrùdadh crìochan gu h-àrd, feumaidh eileamaid mu dheireadh a bhith ann (a dh `fhaodas a bhith fèin [clàr-amais] fhèin).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Cuir a-steach eileamaid aig suidheachadh `index` taobh a-staigh an vector, a `gluasad a h-uile eileamaid às a dhèidh air an taobh cheart.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma tha `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // àite airson an eileamaid ùr
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // infallible An spot gus an luach ùr a chuir
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Gluais a h-uile càil thairis gus àite a dhèanamh.
                // (A `dùblachadh an eileamaid` clàr-amais `ann an dà àite an dèidh a chèile.)
                ptr::copy(p, p.offset(1), len - index);
                // Sgrìobh a-steach e, a `sgrìobhadh thairis air a` chiad leth-bhreac den eileamaid `index`th.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// A `toirt air falbh agus a` tilleadh an eileamaid aig suidheachadh `index` taobh a-staigh an vector, a `gluasad a h-uile eileamaid às a dhèidh air an taobh chlì.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma tha `index` a-mach à crìochan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // an àite às a bheil sinn a `toirt.
                let ptr = self.as_mut_ptr().add(index);
                // dèan lethbhreac dheth, gu mì-shàbhailte le leth-bhreac den luach air a `chruach agus anns an vector aig an aon àm.
                //
                ret = ptr::read(ptr);

                // Gluais a h-uile càil sìos gus an àite sin a lìonadh.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// A `gleidheadh dìreach na h-eileamaidean a tha air an comharrachadh leis an predicate.
    ///
    /// Ann am faclan eile, cuir às na h-eileamaidean `e` gu lèir gus am bi `f(&e)` a `tilleadh `false`.
    /// Bidh an dòigh seo ag obair na àite, a `tadhal air gach eileamaid dìreach aon uair san òrdugh thùsail, agus a` gleidheadh òrdugh nan eileamaidean glèidhte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Leis gu bheileas a `tadhal air na h-eileamaidean dìreach aon uair anns an òrdugh tùsail, faodar stàite taobh a-muigh a chleachdadh gus co-dhùnadh dè na h-eileamaidean a bu chòir a chumail.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Seachain drop dùbailte mura tèid an geàrd drop a chuir gu bàs, oir is dòcha gun dèan sinn beagan tuill tron phròiseas.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-giullachd len-> |^-ri taobh sgrùdadh
        //                  | <-sguabadh às cnt-> |
        //      | <-original_len-> |Glèidhidh: Eileamaidean a tha a `ro-innse toradh fìor.
        //
        // Toll: Slot eileamaid air a ghluasad no air tuiteam.
        // Gun sgrùdadh: Eileamaidean dligheach gun sgrùdadh.
        //
        // Thèid an geàrd drop seo a ghairm nuair a thèid predicate no `drop` de eileamaid panked.
        // Bidh e a `gluasad eileamaidean gun sgrùdadh gus tuill a chòmhdach agus `set_len` chun an fhad cheart.
        // Ann an cùisean nuair nach bi predicate agus `drop` a `clisgeadh, thèid a chuir às.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SÀBHAILTEACHD: Feumaidh trailing nithean neo-sgrùdaichte a bhith dligheach bho nach bi sinn uair sam bith a `beantainn riutha.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SÀBHAILTEACHD: An dèidh tuill a lìonadh, tha a h-uile rud mar chuimhneachan dlùth.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SÀBHAILTEACHD: Feumaidh eileamaid neo-sgrùdaichte a bhith dligheach.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Adhart tràth a sheachnadh dùbailte drop ma `drop_in_place` chlisg.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SÀBHAILTEACHD: Cha bhith sinn a `suathadh ris an eileamaid seo a-rithist às deidh tuiteam.
                unsafe { ptr::drop_in_place(cur) };
                // Chuir sinn air adhart a `chunntair mu thràth.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SÀBHAILTEACHD: `deleted_cnt`> 0, mar sin chan fhaod an slot toll a dhol thairis air an eileamaid làithreach.
                // Bidh sinn a `cleachdadh leth-bhreac airson gluasad, agus cha bhith sinn a` suathadh ris an eileamaid seo a-rithist.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Tha gach nì air a phròiseasadh.Faodar seo a mheudachadh gu `set_len` le LLVM.
        drop(g);
    }

    /// A `toirt air falbh a h-uile ach a` chiad de na h-eileamaidean leantainneach anns an vector a tha a `fuasgladh chun an aon iuchair.
    ///
    ///
    /// Ma tha an vector air a sheòrsachadh, bidh seo a `toirt air falbh a h-uile dùblachadh.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// A `toirt air falbh a h-uile ach a` chiad fhear de na h-eileamaidean leantainneach anns an vector a `sàsachadh dàimh co-ionannachd sònraichte.
    ///
    /// Tha an gnìomh `same_bucket` air a thoirt seachad a `toirt iomradh air dà eileamaid bhon vector agus feumaidh e dearbhadh a bheil na h-eileamaidean a` dèanamh coimeas eadar iad.
    /// Tha na h-eileamaidean air an toirt seachad ann an òrdugh eile bhon òrdugh aca san t-sliseag, mar sin ma thilleas `same_bucket(a, b)` `true`, thèid `a` a thoirt air falbh.
    ///
    ///
    /// Ma tha an vector air a sheòrsachadh, bidh seo a `toirt air falbh a h-uile dùblachadh.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// A `cur eileamaid ri cùl cruinneachadh.
    ///
    /// # Panics
    ///
    /// Panics ma ùr comas nas àirde `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Bidh seo a `panic no a` sgur ma tha sinn a `riarachadh> isize::MAX bytes no nam biodh an àrdachadh faid a` cur thairis airson seòrsachan meud neoni.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Thoir air falbh an eileamaid mu dheireadh bho vector agus till e air ais, no [`None`] ma tha e falamh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Moves h-uile eileamaid de `other` `Self` a-steach, a 'fàgail `other` falamh.
    ///
    /// # Panics
    ///
    /// Panics ma tha an àireamh de eileamaidean anns an vector a `dol thairis air `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// A `cur eileamaidean ri `Self` bho bufair eile.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// A `cruthachadh itealadair drèanaidh a bheir air falbh an raon ainmichte anns an vector agus a bheir toradh de na nithean a chaidh a thoirt air falbh.
    ///
    /// Nuair a thèid an iterator **a leigeil sìos**, thèid a h-uile eileamaid san raon a thoirt a-mach às an vector, eadhon ged nach deach an iterator a chaitheamh gu h-iomlan.
    /// Mura h-eil **an iterator** air a leigeil sìos (le [`mem::forget`] mar eisimpleir), chan eil e soilleir cia mheud eileamaid a thèid a thoirt air falbh.
    ///
    /// # Panics
    ///
    /// Panics ma tha an t-àite tòiseachaidh nas motha na a `phuing crìochnachaidh no ma tha an t-àite crìochnachaidh nas motha na fad an vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Bidh làn raon a `glanadh an vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Sàbhailteachd cuimhne
        //
        // Nuair a thèid an Drain a chruthachadh an toiseach, bidh e a `giorrachadh fad an stòr vector gus dèanamh cinnteach nach fhaighear eileamaidean neo-aithnichte no gluasad bho idir mura faigh an sgriosadair Drain a-riamh ruith.
        //
        //
        // Bheir Drain ptr::read a-mach na luachan airson an toirt air falbh.
        // Nuair a bhios e deiseil, thèid leth-bhreac a tha air fhàgail den vec a chopaigeadh air ais gus an toll a chòmhdach, agus tha an fhaid vector air a thoirt air ais don fhad ùr.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // cuir faid self.vec airson tòiseachadh, gus a bhith sàbhailte gun fhios nach tèid Drain a leigeil a-mach
            self.set_len(start);
            // Cleachd na iasaid ann an IterMut gus sealltainn iasaid a giùlan air fad Drain iterator (mar &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// A `glanadh an vector, a` toirt air falbh a h-uile luach.
    ///
    /// Thoir fa-near nach eil buaidh sam bith aig an dòigh seo air comas ainmichte an vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// A `tilleadh an àireamh de eileamaidean anns an vector, ris an canar cuideachd an 'length' aige.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// A `tilleadh `true` mura h-eil eileamaidean anns an vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Roinnidh e an cruinneachadh gu dhà aig a `chlàr-innse a chaidh a thoirt seachad.
    ///
    /// A `tilleadh vector a chaidh a riarachadh às ùr anns a bheil na h-eileamaidean anns an raon `[at, len)`.
    /// Às deidh a `ghairm, thèid an vector tùsail fhàgail anns a bheil na h-eileamaidean `[0, at)` leis a` chomas a bh `ann roimhe gun atharrachadh.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma tha `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // faodaidh an vector ùr am bufair tùsail a ghabhail thairis agus an leth-bhreac a sheachnadh
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // `set_len` gu mì-shàbhailte agus copaidh nithean gu `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Ath-mheudachadh an `Vec` na àite gus am bi `len` co-ionann ri `new_len`.
    ///
    /// Ma tha `new_len` nas motha na `len`, tha an `Vec` air a leudachadh leis an eadar-dhealachadh, le gach slot a bharrachd air a lìonadh le toradh gairm an dùnadh `f`.
    ///
    /// Thig na luachan toraidh bho `f` gu crìch anns an `Vec` anns an òrdugh a chaidh a chruthachadh.
    ///
    /// Ma tha `new_len` nas lugha na `len`, tha an `Vec` dìreach air a theàrnadh.
    ///
    /// Bidh an dòigh seo a `cleachdadh dùnadh gus luachan ùra a chruthachadh air a h-uile putadh.Nam b`fheàrr leat [`Clone`] luach sònraichte, cleachd [`Vec::resize`].
    /// Ma tha thu airson an [`Default`] trait a chleachdadh gus luachan a ghineadh, faodaidh tu [`Default::default`] a thoirt seachad mar an dàrna argamaid.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// A `caitheamh agus ag aoidion an `Vec`, a` tilleadh iomradh gluasadach don t-susbaint, `&'a mut [T]`.
    /// Thoir fa-near gum feum an seòrsa `T` a bhith fada os cionn na beatha taghte `'a`.
    /// Mura h-eil ach iomraidhean statach aig an t-seòrsa, no gin idir, faodaidh seo a bhith air a thaghadh mar `'static`.
    ///
    /// Tha an gnìomh seo coltach ris a `ghnìomh [`leak`][Box::leak] air [`Box`] ach a-mhàin nach eil dòigh ann air a` chuimhne a chaidh a leigeil ma sgaoil fhaighinn air ais.
    ///
    ///
    /// Tha an gnìomh seo feumail sa mhòr-chuid airson dàta a tha beò airson a `chòrr de bheatha a` phrògraim.
    /// Ma chuireas tu sìos an t-iomradh a chaidh a thilleadh, thig cuimhne a-mach.
    ///
    /// # Examples
    ///
    /// Cleachdadh sìmplidh:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// A 'tilleadh air fhàgail a bharrachd air comas na vector mar sliseag `MaybeUninit<T>`.
    ///
    /// Faodar an sliseag a chaidh a thilleadh a chleachdadh gus an vector a lìonadh le dàta (me
    /// le bhith a `leughadh bho fhaidhle) mus comharraich thu an dàta mar a chaidh a thòiseachadh a` cleachdadh an dòigh [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Allocate vector mòr gu leòr airson 10 eileamaidean.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Lìon a-steach na ciad 3 eileamaidean.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Comharraich a `chiad 3 eileamaidean den vector mar a bhith air an tòiseachadh.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Chan eil an dòigh seo air a bhuileachadh a thaobh `split_at_spare_mut`, gus casg a chuir air molaidhean neo-dhligheach chun bufair.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// A `tilleadh susbaint vector mar sliseag de `T`, còmhla ris a` chomas a bharrachd a tha air fhàgail den vector mar sliseag de `MaybeUninit<T>`.
    ///
    /// Faodar an sliseag comas a bharrachd a thilleadh a chleachdadh gus an vector a lìonadh le dàta (me le bhith a `leughadh bho fhaidhle) mus comharraich thu an dàta mar a chaidh a thòiseachadh a` cleachdadh an dòigh [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Thoir fa-near gur e API ìre ìosal a tha seo, a bu chòir a chleachdadh le cùram airson adhbharan optimization.
    /// Ma dh `fheumas tu dàta a chuir ri `Vec` faodaidh tu [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] no [`resize_with`] a chleachdadh, a rèir dè na feumalachdan mionaideach agad.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Glèidh àite a bharrachd mòr gu leòr airson 10 eileamaidean.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Lìon a-steach an ath 4 eileamaidean.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Comharraich na 4 eileamaidean den vector mar a bhith air an tòiseachadh.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - Thathas a `toirt fa-near do len agus mar sin cha tèid atharrachadh gu bràth
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Sàbhailteachd: tha atharrachadh air a thilleadh .2 (&mut usize) air a mheas mar an aon rud ri bhith a `gairm `.set_len(_)`.
    ///
    /// Tha an dòigh seo air a chleachdadh gus cothrom sònraichte fhaighinn air a h-uile pàirt vec aig an aon àm ann an `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` tha e cinnteach gum bi e dligheach airson eileamaidean `len`
        // - `spare_ptr` a `comharrachadh aon eileamaid seachad air a` bhufair, gus nach gabh e thairis le `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Ath-mheudachadh an `Vec` na àite gus am bi `len` co-ionann ri `new_len`.
    ///
    /// Ma tha `new_len` nas motha na `len`, tha an `Vec` air a leudachadh leis an eadar-dhealachadh, le gach slot a bharrachd air a lìonadh le `value`.
    ///
    /// Ma tha `new_len` nas lugha na `len`, tha an `Vec` dìreach air a theàrnadh.
    ///
    /// Feumaidh an dòigh seo `T` gus [`Clone`] a chuir an gnìomh, gus a bhith comasach air an luach a chaidh seachad a ghleusadh.
    /// Ma tha feum agad air barrachd sùbailteachd (no ma tha thu airson a bhith an urra ri [`Default`] an àite [`Clone`]), cleachd [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// A `gleusadh agus a` ceangal a h-uile eileamaid ann an sliseag ris an `Vec`.
    ///
    /// Iterates thairis air an slice `other`, clones gach eileamaid, agus an uairsin ga cheangal ris an `Vec` seo.
    /// Tha an `other` vector air a ghluasad ann an òrdugh.
    ///
    /// Thoir fa-near gu bheil an gnìomh seo co-ionann ri [`extend`] ach a-mhàin gu bheil e speisealta a bhith ag obair le sliseagan na àite.
    ///
    /// Ma gheibh agus nuair a gheibh Rust speisealachadh chan eil e coltach gum bi an gnìomh seo air a mholadh (ach fhathast ri fhaighinn).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Dèan lethbhreac de eileamaidean bho raon `src` gu deireadh an vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` a `gealltainn gu bheil an raon a chaidh a thoirt seachad dligheach airson clàr-amais fèin
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Tha an còd seo a `toirt coitcheann do `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Leudaich an vector le luachan `n`, a `cleachdadh an gineadair a chaidh a thoirt seachad.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Cleachd SetLenOnDrop gus obrachadh timcheall air biast far nach tuig compiler an stòr tro `ptr` tro self.set_len() no ailias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Sgrìobh gach eileamaid ach am fear mu dheireadh
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Meudaich an fhaid anns a h-uile ceum air eagal next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Faodaidh sinn an eileamaid mu dheireadh a sgrìobhadh gu dìreach gun a bhith a `clònadh gun fheum
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len air a shuidheachadh le geàrd farsaingeachd
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// A `toirt air falbh eileamaidean leantainneach às deidh sin anns an vector a rèir buileachadh [`PartialEq`] trait.
    ///
    ///
    /// Ma tha an vector air a sheòrsachadh, bidh seo a `toirt air falbh a h-uile dùblachadh.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Modhan agus gnìomhan a-staigh
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` feumaidh clàr-amais dligheach a bhith ann
    /// - `self.capacity() - self.len()` feumaidh a bhith `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - tha len air a mheudachadh a-mhàin às deidh eileamaidean a thòiseachadh
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - tha an neach-fios a `dearbhadh gu bheil src na chlàr-amais dligheach
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Chaidh Element dìreach a thòiseachadh le `MaybeUninit::write`, mar sin tha e ceart gu leòr àrdachadh
            // - tha len air a mheudachadh an dèidh gach eileamaid gus casg a chuir air aodion (faic cùis #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - tha an neach-fios a `dearbhadh gu bheil `src` na chlàr-amais dligheach
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Tha an dà phuing air an cruthachadh bho iomraidhean sliseag sònraichte (`&mut [_]`) gus am bi iad dligheach agus nach gabh iad thairis.
            //
            // - Is iad na h-eileamaidean: Dèan lethbhreac gus am bi e ceart gu leòr lethbhreac a dhèanamh dhiubh, gun dad a dhèanamh leis na luachan tùsail
            // - `count` tha e co-ionann ris an len de `source`, mar sin tha an stòr dligheach airson leughaidhean `count`
            // - `.reserve(count)` a `gealltainn gu bheil `spare.len() >= count` cho spàl dligheach airson sgrìobhadh `count`
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Chaidh na h-eileamaidean a thòiseachadh le `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Gnìomhachadh cumanta trait airson Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): le cfg(test) chan eil an dòigh in-ghnèitheach `[T]::to_vec`, a tha riatanach airson mìneachadh a `mhodh seo, ri fhaighinn.
    // An àite sin cleachd an gnìomh `slice::to_vec` nach fhaighear ach le cfg(test) NB faic am modal slice::hack ann an slice.rs airson tuilleadh fiosrachaidh
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // leig às rud sam bith nach tèid a sgrìobhadh thairis
        self.truncate(other.len());

        // self.len <= other.len mar thoradh air a `bhriogais gu h-àrd, agus mar sin tha na sliseagan an seo an-còmhnaidh a-staigh.
        //
        let (init, tail) = other.split_at(self.len());

        // ath-chleachdadh na luachan a tha ann allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// A `cruthachadh itealaiche caitheamh, is e sin, fear a ghluaiseas gach luach a-mach às an vector (bho thoiseach gu deireadh).
    /// Chan urrainnear an vector a chleachdadh às deidh seo a ghairm.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s tha seòrsa String ann, chan e &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // dòigh duilleach ris am bi diofar bhuileachaidhean SpecFrom/SpecExtend a `tiomnadh nuair nach eil tuilleadh optimachaidh aca ri chur an sàs
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Tha seo fìor airson iterator coitcheann.
        //
        // Bu chòir an gnìomh seo a bhith co-ionnan gu moralta:
        //
        //      airson rud ann an iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // Chan urrainn dha NB cur thairis leis gum feumadh sinn àite seòlaidh a riarachadh
                self.set_len(len + 1);
            }
        }
    }

    /// A `cruthachadh itealaiche splicing a thèid an àite an raon ainmichte anns an vector leis an iterator `replace_with` a chaidh a thoirt seachad agus a bheir toradh de na nithean a chaidh a thoirt air falbh.
    ///
    /// `replace_with` chan fheum an aon fhaid ri `range`.
    ///
    /// `range` a thoirt air falbh, fiù 's ma tha an iterator Chan eil sgriosar gu deireadh.
    ///
    /// Tha e neo-shònraichte cia mheud eileamaid a thèid a thoirt bhon vector ma thèid an luach `Splice` a leigeil a-mach.
    ///
    /// Chan eilear a `caitheamh an iterator ion-chuir `replace_with` ach nuair a thèid luach `Splice` a leigeil sìos.
    ///
    /// Tha seo nas fheàrr ma tha:
    ///
    /// * Tha an earball (eileamaidean anns an vector às deidh `range`) falamh,
    /// * no `replace_with` faighear nas lugha na no co-ionnan eileamaidean `range` a dh'fhaid
    /// * no ìosal a 'dol a `size_hint()` tha dearbh.
    ///
    /// Rud eile, tha vector sealach air a riarachadh agus tha an earball air a ghluasad dà uair.
    ///
    /// # Panics
    ///
    /// Panics ma tha an t-àite tòiseachaidh nas motha na a `phuing crìochnachaidh no ma tha an t-àite crìochnachaidh nas motha na fad an vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// A `cruthachadh itealaiche a bhios a` cleachdadh dùnadh gus faighinn a-mach am bu chòir eileamaid a thoirt air falbh.
    ///
    /// Ma tha an dùnadh a `tilleadh fìor, tha an eileamaid air a thoirt air falbh agus air a thoirt a-mach.
    /// Ma thilleas an dùnadh meallta, fuirichidh an eileamaid anns an vector agus cha toir an iterator toradh dha.
    ///
    /// Tha cleachdadh an dòigh seo co-ionann ris a `chòd a leanas:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // do chòd an seo
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Ach tha `drain_filter` nas fhasa a chleachdadh.
    /// `drain_filter` tha e nas èifeachdaiche cuideachd, oir is urrainn dha na h-eileamaidean den eagar a thionndadh air ais gu mòr.
    ///
    /// Thoir fa-near gu bheil `drain_filter` cuideachd a `leigeil leat a h-uile eileamaid den dùnadh sìoltachain a thionndadh, ge bith a bheil thu airson a chumail no a thoirt air falbh.
    ///
    ///
    /// # Examples
    ///
    /// A `roinneadh sreath a-steach do dh` oidhcheannan is neònach, ag ath-chleachdadh an riarachadh tùsail:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Dìon an aghaidh sinn a bhith ag aodion (leudachadh aodion)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Leudaich buileachadh a tha a `dèanamh lethbhreac de eileamaidean a-mach à iomraidhean mus cuir thu air adhart iad air an Vec.
///
/// Tha am buileachadh seo speisealaichte airson itealain slice, far am bi e a `cleachdadh [`copy_from_slice`] gus an sliseag gu lèir a cheangal ris aig an aon àm.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// A `toirt buaidh air coimeas vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// A `toirt buaidh air òrdachadh vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // cleachd drop airson [T] cleachd sliseag amh gus iomradh a thoirt air na h-eileamaidean den vector mar an seòrsa as laige a tha riatanach;
            //
            // dh'fhaodadh ceistean dligheachd a sheachnadh ann an cuid de chùisean
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // Bidh RawVec a `làimhseachadh tuigseocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// A `cruthachadh `Vec<T>` falamh.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: deuchainn a `tarraing ann an libstd, a dh` adhbhraicheas mearachdan an seo
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: deuchainn a `tarraing ann an libstd, a dh` adhbhraicheas mearachdan an seo
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Faigh susbaint iomlan an `Vec<T>` mar raon, ma tha a mheud dìreach co-ionann ris an raon a chaidh iarraidh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Mura h-eil an fhaid a `freagairt, thig an cur-a-steach air ais ann an `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Ma tha thu ceart gu leòr le dìreach a `faighinn ro-leasachan den `Vec<T>`, faodaidh tu [`.truncate(N)`](Vec::truncate) a ghairm an toiseach.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SÀBHAILTEACHD: Tha `.set_len(0)` an-còmhnaidh làidir.
        unsafe { vec.set_len(0) };

        // SÀBHAILTEACHD: A `Vec` a 'chomharra-còmhnaidh a' co-thaobhadh gu ceart, agus
        // tha an co-thaobhadh a dh `fheumas an raon co-ionann ris na nithean.
        // Rinn sinn sgrùdadh na bu thràithe gu bheil stuthan gu leòr againn.
        // Cha tuit na nithean dùbailte oir tha an `set_len` ag innse don `Vec` gun a bhith gan leigeil sìos cuideachd.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}