//! Seòrsa puing airson riarachadh tiùrr.
//!
//! [`Box<T>`], air ainmeachadh gu cas mar 'box', a `toirt seachad an cruth as sìmplidh de riarachadh tiùrr ann an Rust.Bidh bogsaichean a`toirt seachad seilbh airson an riarachadh seo, agus a`leigeil às na tha annta nuair a thèid iad a-mach à farsaingeachd.Bidh bogsaichean cuideachd a`dèanamh cinnteach nach bi iad a-riamh a` riarachadh barrachd air bytes `isize::MAX`.
//!
//! # Examples
//!
//! Gluais luach bhon chruach chun tiùr le bhith a `cruthachadh [`Box`]:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! Gluais luach bho [`Box`] air ais chun stac le [dereferencing]:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! A `cruthachadh structar dàta ath-chuairteach:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Bidh seo a `clò-bhualadh` Cons (1, Cons(2, Nil))`.
//!
//! Feumaidh bogsaichean ath-chuairteachadh a bhith ann am bogsa, oir ma bha mìneachadh `Cons` a `coimhead mar seo:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Cha bhiodh e ag obair.Tha seo air sgàth gu bheil meud `List` an urra ri cia mheud eileamaid a tha air an liosta, agus mar sin chan eil fios againn dè an cuimhne a bu chòir a riarachadh airson `Cons`.Le bhith a `toirt a-steach [`Box<T>`], aig a bheil meud sònraichte, tha fios againn dè cho mòr sa dh` fheumas `Cons` a bhith.
//!
//! # Cruth cuimhne
//!
//! Airson luachan neo-neoni, cleachdaidh [`Box`] an riaraiche [`Global`] airson a riarachadh.Tha e dligheach an dà dhòigh a thionndadh eadar [`Box`] agus comharradh amh air a riarachadh leis an riaraiche [`Global`], leis gu bheil an [`Layout`] a chaidh a chleachdadh leis an riaraiche ceart airson an seòrsa.
//!
//! Nas mionaidiche, faodar `value:*mut T` a chaidh a riarachadh leis an riaraiche [`Global`] le `Layout::for_value(&* value)` a thionndadh gu bogsa a `cleachdadh [`Box::<T>::from_raw(value)`].
//! Air an làimh eile, faodar an cuimhne a tha a `toirt taic do `value:*mut T` a fhuaireadh bho [`Box::<T>::into_raw`] a bhith air a thuigsinn le bhith a` cleachdadh an riaraiche [`Global`] le [`Layout::for_value(&* value)`].
//!
//! Airson luachan meud neoni, feumaidh am puing `Box` a bhith fhathast [valid] airson leughaidhean agus sgrìobhadh agus co-thaobhadh gu leòr.
//! Gu sònraichte, bidh a bhith a `tilgeil litearra integer neo-neoni co-thaobhach gu puing amh a` toirt a-mach comharradh dligheach, ach tha comharradh a `comharrachadh a-steach do chuimhne a chaidh a riarachadh roimhe nach eil dligheach bho chaidh a shaoradh.
//! Is e an dòigh a thathar a `moladh Bogsa a thogail gu ZST mura h-urrainnear `Box::new` a chleachdadh a bhith a` cleachdadh [`ptr::NonNull::dangling`].
//!
//! Cho fad ri `T: Sized`, tha cinnteach gum bi `Box<T>` air a riochdachadh mar aon neach-comharrachaidh agus tha e cuideachd co-chòrdail ri ABI le molaidhean C (ie an seòrsa C `T*`).
//! Tha seo a `ciallachadh ma tha gnìomhan taobh a-muigh "C" Rust agad ris an canar bho C, faodaidh tu na gnìomhan Rust sin a mhìneachadh le bhith a` cleachdadh seòrsaichean `Box<T>`, agus `T*` a chleachdadh mar an seòrsa co-fhreagarrach air an taobh C.
//! Mar eisimpleir, smaoinich air a `cheann-cinn C seo a tha ag ainmeachadh gnìomhan a chruthaicheas agus a sgrios cuid de luach `Foo`:
//!
//! ```c
//! /* C header */
//!
//! /* A `toirt seilbh air ais don neach-fios */
//! struct Foo* foo_new(void);
//!
//! /* A `gabhail seilbh bhon neach-fios;no-op nuair a thèid a ghairm le NULL */
//! void foo_delete(struct Foo*);
//! ```
//!
//! Faodar an dà ghnìomh seo a chuir an gnìomh ann an Rust mar a leanas.An seo, tha an seòrsa `struct Foo*` bho C air eadar-theangachadh gu `Box<Foo>`, a tha a `glacadh nan cuingealachaidhean seilbh.
//! Thoir fa-near cuideachd gu bheil an argamaid so-ruigsinneach gu `foo_delete` air a riochdachadh ann an Rust mar `Option<Box<Foo>>`, leis nach urrainn `Box<Foo>` a bhith null.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! Fiù ged a tha an aon riochdachadh aig `Box<T>` agus C ABI ri comharradh C, chan eil sin a `ciallachadh gun urrainn dhut `T*` neo-riaghailteach a thionndadh gu `Box<T>` agus a bhith an dùil gun obraich cùisean.
//! `Box<T>` bidh luachan an-còmhnaidh air an co-thaobhadh gu h-iomlan, comharran neo-null.A bharrachd air an sin, feuchaidh an inneal-sgrios airson `Box<T>` gus an luach a shaoradh leis an neach-sgaoilidh cruinneil.San fharsaingeachd, is e an cleachdadh as fheàrr dìreach `Box<T>` a chleachdadh airson molaidhean a thàinig bhon neach-riarachaidh cruinneil.
//!
//! **Cudromach.** Co-dhiù an-dràsta, bu chòir dhut a bhith a `seachnadh a bhith a` cleachdadh seòrsaichean `Box<T>` airson gnìomhan a tha air am mìneachadh ann an C ach air an toirt bho Rust.Anns na cùisean sin, bu chòir dhut sealltainn gu dìreach air na seòrsaichean C cho dlùth `s a ghabhas.
//! Faodaidh cleachdadh seòrsaichean mar `Box<T>` far a bheil mìneachadh C dìreach a `cleachdadh `T*` leantainn gu giùlan neo-mhìnichte, mar a chaidh a mhìneachadh ann an [rust-lang/unsafe-code-guidelines#198][ucg#198].
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Seòrsa puing airson riarachadh tiùrr.
///
/// Faic an [module-level documentation](../../std/boxed/index.html) airson tuilleadh.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// A `riarachadh cuimhne air an tiùrr agus an uairsin a` cur `x` a-steach ann.
    ///
    /// Cha bhith seo a `riarachadh gu dearbh ma tha `T` de mheud neoni.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// A `togail bogsa ùr le susbaint neo-aithnichte.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Toiseach tòiseachaidh:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// A `togail `Box` ùr le susbaint neo-aithnichte, leis a` chuimhne air a lìonadh le bytes `0`.
    ///
    ///
    /// Faic [`MaybeUninit::zeroed`][zeroed] airson eisimpleirean de chleachdadh ceart agus ceàrr den dòigh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// A `togail `Pin<Box<T>>` ùr.
    /// Mura cuir `T` an gnìomh `Unpin`, thèid `x` a phronnadh mar chuimhneachan agus cha ghabh a ghluasad.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// A `riarachadh cuimhne air a` chàrn agus an uairsin a `cur `x` a-steach, a` tilleadh mearachd ma dh `fhailicheas an riarachadh
    ///
    ///
    /// Cha bhith seo a `riarachadh gu dearbh ma tha `T` de mheud neoni.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// A `togail bogsa ùr le susbaint neo-aithnichte air an tiùrr, a` tilleadh mearachd ma dh `fhailicheas an riarachadh
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Toiseach tòiseachaidh:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// A `togail `Box` ùr le susbaint neo-aithnichte, leis a` chuimhne air a lìonadh le bytes `0` air an tiùrr
    ///
    ///
    /// Faic [`MaybeUninit::zeroed`][zeroed] airson eisimpleirean de chleachdadh ceart agus ceàrr den dòigh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// A `riarachadh cuimhne anns an riaraiche a chaidh a thoirt seachad agus an uairsin a` cur `x` a-steach ann.
    ///
    /// Cha bhith seo a `riarachadh gu dearbh ma tha `T` de mheud neoni.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// A `riarachadh cuimhne anns an riaraiche a chaidh a thoirt seachad agus an uairsin a` cur `x` a-steach, a `tilleadh mearachd ma dh` fhailicheas an riarachadh
    ///
    ///
    /// Cha bhith seo a `riarachadh gu dearbh ma tha `T` de mheud neoni.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// A `togail bogsa ùr le susbaint neo-aithnichte anns an riaraiche a chaidh a thoirt seachad.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Toiseach tòiseachaidh:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: B `fheàrr le maids thairis air unwrap_or_else bho dhùin e uaireannan nach gabh a chleachdadh.
        // Dhèanadh sin meud còd nas motha.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// A `togail bogsa ùr le susbaint neo-aithnichte anns an riaraiche a chaidh a thoirt seachad, a` tilleadh mearachd ma dh `fhailicheas an riarachadh
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Toiseach tòiseachaidh:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// A `togail `Box` ùr le susbaint neo-aithnichte, leis a` chuimhne air a lìonadh le bytes `0` anns an riarachadh a chaidh a thoirt seachad.
    ///
    ///
    /// Faic [`MaybeUninit::zeroed`][zeroed] airson eisimpleirean de chleachdadh ceart agus ceàrr den dòigh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: B `fheàrr le maids thairis air unwrap_or_else bho dhùin e uaireannan nach gabh a chleachdadh.
        // Dhèanadh sin meud còd nas motha.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// A `togail `Box` ùr le susbaint neo-aithnichte, leis a` chuimhne air a lìonadh le bytes `0` anns an riaraiche a chaidh a thoirt seachad, a `tilleadh mearachd ma dh` fhailicheas an riarachadh,
    ///
    ///
    /// Faic [`MaybeUninit::zeroed`][zeroed] airson eisimpleirean de chleachdadh ceart agus ceàrr den dòigh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// A `togail `Pin<Box<T, A>>` ùr.
    /// Mura cuir `T` an gnìomh `Unpin`, thèid `x` a phronnadh mar chuimhneachan agus cha ghabh a ghluasad.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// Bidh e ag atharrachadh `Box<T>` gu `Box<[T]>`
    ///
    /// Chan eil an tionndadh seo a `riarachadh air an tiùrr agus bidh e a` tachairt na àite.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// A `caitheamh an `Box`, a` tilleadh an luach fillte.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// A `togail sliseag bogsa ùr le susbaint neo-aithnichte.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Toiseach tòiseachaidh:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// A `togail sliseag bogsa ùr le susbaint neo-aithnichte, leis a` chuimhne air a lìonadh le bytes `0`.
    ///
    ///
    /// Faic [`MaybeUninit::zeroed`][zeroed] airson eisimpleirean de chleachdadh ceart agus ceàrr den dòigh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// A `togail sliseag bogsa ùr le susbaint neo-aithnichte anns an riaraiche a chaidh a thoirt seachad.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Toiseach tòiseachaidh:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// A `togail sliseag bogsa ùr le susbaint neo-aithnichte anns an riaraiche a chaidh a thoirt seachad, leis a` chuimhne air a lìonadh le bytes `0`.
    ///
    ///
    /// Faic [`MaybeUninit::zeroed`][zeroed] airson eisimpleirean de chleachdadh ceart agus ceàrr den dòigh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// Tionndadh gu `Box<T, A>`.
    ///
    /// # Safety
    ///
    /// Coltach ri [`MaybeUninit::assume_init`], tha e an urra ris an neach-fios a bhith a `gealltainn gu bheil an luach ann an staid tòiseachaidh.
    ///
    /// Le bhith a `gairm seo nuair nach eil an susbaint air a làn thòiseachadh fhathast ag adhbhrachadh giùlan neo-mhìnichte sa bhad.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Toiseach tòiseachaidh:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// Tionndadh gu `Box<[T], A>`.
    ///
    /// # Safety
    ///
    /// Coltach ri [`MaybeUninit::assume_init`], tha e an urra ris an neach-fios gealltainn gu bheil na luachan ann an staid tòiseachaidh.
    ///
    /// Le bhith a `gairm seo nuair nach eil an susbaint air a làn thòiseachadh fhathast ag adhbhrachadh giùlan neo-mhìnichte sa bhad.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Toiseach tòiseachaidh:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// A `togail bogsa bho chomharradh amh.
    ///
    /// Às deidh an gnìomh seo a ghairm, is ann leis an `Box` a tha mar thoradh air a `phuing amh.
    /// Gu sònraichte, gairmidh an destructor `Box` an destructor `T` agus saor an cuimhne a chaidh a thoirt seachad.
    /// Gus am bi seo sàbhailte, feumaidh an cuimhne a bhith air a riarachadh a rèir an [memory layout] a chleachd `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Tha an gnìomh seo cunnartach oir dh `fhaodadh cleachdadh neo-iomchaidh duilgheadasan cuimhne adhbhrachadh.
    /// Mar eisimpleir, dh `fhaodadh saor-dhùbailte tachairt ma thèid an gnìomh a ghairm dà uair air an aon phuing amh.
    ///
    /// Tha na cumhaichean sàbhailteachd air am mìneachadh anns an roinn [memory layout].
    ///
    /// # Examples
    ///
    /// Dèan ath-chuairteachadh air `Box` a chaidh a thionndadh roimhe gu puing amh a `cleachdadh [`Box::into_raw`]:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Cruthaich `Box` le làimh bhon toiseach le bhith a `cleachdadh an inneal-sgaoilidh cruinne:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // San fharsaingeachd feumar .write gus feuchainn ri milleadh a dhèanamh air susbaint (uninitialized) roimhe de `ptr`, ach airson an eisimpleir shìmplidh seo bhiodh `*ptr = 5` air obrachadh cuideachd.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// A `togail bogsa bho chomharradh amh anns an riaraiche a chaidh a thoirt seachad.
    ///
    /// Às deidh an gnìomh seo a ghairm, is ann leis an `Box` a tha mar thoradh air a `phuing amh.
    /// Gu sònraichte, gairmidh an destructor `Box` an destructor `T` agus saor an cuimhne a chaidh a thoirt seachad.
    /// Gus am bi seo sàbhailte, feumaidh an cuimhne a bhith air a riarachadh a rèir an [memory layout] a chleachd `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Tha an gnìomh seo cunnartach oir dh `fhaodadh cleachdadh neo-iomchaidh duilgheadasan cuimhne adhbhrachadh.
    /// Mar eisimpleir, dh `fhaodadh saor-dhùbailte tachairt ma thèid an gnìomh a ghairm dà uair air an aon phuing amh.
    ///
    /// # Examples
    ///
    /// Dèan ath-chuairteachadh air `Box` a chaidh a thionndadh roimhe gu comharra amh a `cleachdadh [`Box::into_raw_with_allocator`]:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Cruthaich `Box` le làimh le bhith a `cleachdadh inneal-sgaoilidh an t-siostaim:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // San fharsaingeachd feumar .write gus feuchainn ri milleadh a dhèanamh air susbaint (uninitialized) roimhe de `ptr`, ach airson an eisimpleir shìmplidh seo bhiodh `*ptr = 5` air obrachadh cuideachd.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// A `caitheamh an `Box`, a` tilleadh stiùireadh amh fillte.
    ///
    /// Bidh am puing air a cho-thaobhadh gu ceart agus neo-null.
    ///
    /// Às deidh an gnìomh seo a ghairm, tha uallach air an neach-conaltraidh airson a `chuimhne a chaidh a riaghladh roimhe leis an `Box`.
    /// Gu sònraichte, bu chòir don neach-fòn `T` a sgrios gu ceart agus an cuimhne a leigeil ma sgaoil, a `toirt aire don [memory layout] a tha `Box` a` cleachdadh.
    /// Is e an dòigh as fhasa seo a dhèanamh am puing amh a thionndadh air ais gu `Box` leis a `ghnìomh [`Box::from_raw`], a` leigeil leis an inneal-sgrios `Box` an glanadh a dhèanamh.
    ///
    ///
    /// Note: tha seo na ghnìomh co-cheangailte, a tha a `ciallachadh gum feum thu a ghairm mar `Box::into_raw(b)` an àite `b.into_raw()`.
    /// Tha seo gus nach bi strì ann le dòigh air an t-seòrsa a-staigh.
    ///
    /// # Examples
    /// Ag atharrachadh a `phuing amh air ais gu `Box` le [`Box::from_raw`] airson glanadh fèin-ghluasadach:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Glanadh làimhe le bhith a `ruith an inneal-sgrios agus a` tuigsinn a `chuimhne:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// A `caitheamh an `Box`, a` tilleadh stiùireadh amh fillte agus an neach-riarachaidh.
    ///
    /// Bidh am puing air a cho-thaobhadh gu ceart agus neo-null.
    ///
    /// Às deidh an gnìomh seo a ghairm, tha uallach air an neach-conaltraidh airson a `chuimhne a chaidh a riaghladh roimhe leis an `Box`.
    /// Gu sònraichte, bu chòir don neach-fòn `T` a sgrios gu ceart agus an cuimhne a leigeil ma sgaoil, a `toirt aire don [memory layout] a tha `Box` a` cleachdadh.
    /// Is e an dòigh as fhasa seo a dhèanamh am puing amh a thionndadh air ais gu `Box` leis a `ghnìomh [`Box::from_raw_in`], a` leigeil leis an inneal-sgrios `Box` an glanadh a dhèanamh.
    ///
    ///
    /// Note: tha seo na ghnìomh co-cheangailte, a tha a `ciallachadh gum feum thu a ghairm mar `Box::into_raw_with_allocator(b)` an àite `b.into_raw_with_allocator()`.
    /// Tha seo gus nach bi strì ann le dòigh air an t-seòrsa a-staigh.
    ///
    /// # Examples
    /// Ag atharrachadh a `phuing amh air ais gu `Box` le [`Box::from_raw_in`] airson glanadh fèin-ghluasadach:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Glanadh làimhe le bhith a `ruith an inneal-sgrios agus a` tuigsinn a `chuimhne:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Tha bogsa air aithneachadh mar "unique pointer" le Stacked Borrows, ach air an taobh a-staigh tha e na chomharradh amh airson an t-siostam seòrsa.
        // Cha bhiodh e air a thionndadh gu dìreach gu puing amh aithneachadh mar "releasing" a `phuing shònraichte gus cead a thoirt do ruigsinneachd amh, agus mar sin feumaidh a h-uile modh puing amh a dhol tro `Box::leak`.
        //
        // A `tionndadh *sin* gu stiùireadh amh a` giùlan gu ceart.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// A `tilleadh iomradh air an neach-sònrachaidh bunaiteach.
    ///
    /// Note: tha seo na ghnìomh co-cheangailte, a tha a `ciallachadh gum feum thu a ghairm mar `Box::allocator(&b)` an àite `b.allocator()`.
    /// Tha seo gus nach bi strì ann le dòigh air an t-seòrsa a-staigh.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// A `caitheamh agus ag aoidion an `Box`, a` tilleadh iomradh gluasadach, `&'a mut T`.
    /// Thoir fa-near gum feum an seòrsa `T` a bhith fada os cionn na beatha taghte `'a`.
    /// Mura h-eil ach iomraidhean statach aig an t-seòrsa, no gin idir, faodaidh seo a bhith air a thaghadh mar `'static`.
    ///
    /// Tha an gnìomh seo feumail sa mhòr-chuid airson dàta a tha beò airson a `chòrr de bheatha a` phrògraim.
    /// Ma chuireas tu sìos an t-iomradh a chaidh a thilleadh, thig cuimhne a-mach.
    /// Mura gabh seo a dhèanamh, bu chòir an iomradh a bhith air a phasgadh an toiseach le gnìomh [`Box::from_raw`] a `toirt a-mach `Box`.
    ///
    /// Faodar an `Box` seo a leigeil sìos an uairsin a sgrios `T` gu ceart agus a `leigeil às a` chuimhne a chaidh a riarachadh.
    ///
    /// Note: tha seo na ghnìomh co-cheangailte, a tha a `ciallachadh gum feum thu a ghairm mar `Box::leak(b)` an àite `b.leak()`.
    /// Tha seo gus nach bi strì ann le dòigh air an t-seòrsa a-staigh.
    ///
    /// # Examples
    ///
    /// Cleachdadh sìmplidh:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Dàta gun fheum:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// Bidh e ag atharrachadh `Box<T>` gu `Pin<Box<T>>`
    ///
    /// Chan eil an tionndadh seo a `riarachadh air an tiùrr agus bidh e a` tachairt na àite.
    ///
    /// Tha seo cuideachd ri fhaighinn tro [`From`].
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // Chan eil e comasach gluasad taobh a-staigh `Pin<Box<T>>` a ghluasad no ath-nuadhachadh nuair a tha `T: !Unpin`, agus mar sin tha e sàbhailte a chuir gu dìreach gun riatanasan a bharrachd.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Na dèan dad, tha drop an-dràsta air a dhèanamh leis an trusaiche.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// A `cruthachadh `Box<T>`, leis an luach `Default` airson T.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// A `tilleadh bogsa ùr le `clone()` de shusbaint a` bhogsa seo.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // Tha an luach an aon rud
    /// assert_eq!(x, y);
    ///
    /// // Ach tha iad nan nithean gun samhail
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Ro-riarachadh cuimhne gus leigeil le bhith a `sgrìobhadh an luach clonaichte gu dìreach.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// A `dèanamh lethbhreac de shusbaint` stòr`a-steach do `self` gun a bhith a`cruthachadh riarachadh ùr.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // Tha an luach an aon rud
    /// assert_eq!(x, y);
    ///
    /// // Agus cha do thachair riarachadh sam bith
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // bidh seo a `dèanamh leth-bhreac den dàta
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// Bidh e ag atharrachadh seòrsa coitcheann `T` gu `Box<T>`
    ///
    /// Bidh an tionndadh a `riarachadh air an tiùrr agus a` gluasad `t` bhon chruach a-steach dha.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// Bidh e ag atharrachadh `Box<T>` gu `Pin<Box<T>>`
    ///
    /// Chan eil an tionndadh seo a `riarachadh air an tiùrr agus bidh e a` tachairt na àite.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// Bidh e ag atharrachadh `&[T]` gu `Box<[T]>`
    ///
    /// Bidh an tionndadh seo a `riarachadh air an tiùrr agus a` dèanamh leth-bhreac de `slice`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // cruthaich a&[u8] a thèid a chleachdadh gus Bogsa <[u8]> a chruthachadh
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// Bidh e ag atharrachadh `&str` gu `Box<str>`
    ///
    /// Bidh an tionndadh seo a `riarachadh air an tiùrr agus a` dèanamh leth-bhreac de `s`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// Bidh e ag atharrachadh `Box<str>` gu `Box<[u8]>`
    /// Chan eil an tionndadh seo a `riarachadh air an tiùrr agus bidh e a` tachairt na àite.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // cruthaich Bogsa<str>a thèid a chleachdadh gus Bogsa <[u8]> a chruthachadh
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // cruthaich a&[u8] a thèid a chleachdadh gus Bogsa <[u8]> a chruthachadh
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// Bidh e ag atharrachadh `[T; N]` gu `Box<[T]>`
    /// Bidh an tionndadh seo a `gluasad an raon gu cuimhne a tha air ùr riarachadh.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Feuch ri am bogsa a thoirt sìos gu seòrsa cruadhtan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Feuch ri am bogsa a thoirt sìos gu seòrsa cruadhtan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Feuch ri am bogsa a thoirt sìos gu seòrsa cruadhtan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Cha bhith e comasach an Uniq a-staigh a thoirt a-mach gu dìreach bhon bhogsa, ach an àite sin bidh sinn ga thilgeil gu * const a tha a `co-thaobhadh ris an Unique
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Speisealachadh airson meud `I`s a bhios a`cleachdadh` Tha mi a `buileachadh `last()` an àite an àbhaist.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}