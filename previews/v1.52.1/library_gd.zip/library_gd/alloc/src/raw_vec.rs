#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Tha susbaint a `chuimhne ùr neo-aithnichte.
    Uninitialized,
    /// Tha an cuimhne ùr cinnteach gum bi e neoni.
    Zeroed,
}

/// Goireas aig ìre ìosal airson a bhith a `riarachadh, ag ath-riarachadh agus a` tuigsinn bufair cuimhne air an tiùrr gun a bhith draghail mu dheidhinn a h-uile cùis oisean a tha na lùib.
///
/// Tha an seòrsa seo sàr-mhath airson na structaran dàta agad fhèin a thogail mar Vec agus VecDeque.
/// Gu sònraichte:
///
/// * A `dèanamh `Unique::dangling()` air seòrsachan meud neoni.
/// * A `dèanamh `Unique::dangling()` air cuibhreannan de dh'fhaid neoni.
/// * A `seachnadh `Unique::dangling()` a shaoradh.
/// * A `glacadh a h-uile thar-shruth ann an coimpiutairean comas (gan adhartachadh gu "capacity overflow" panics).
/// * Geàrdan an aghaidh siostaman 32-bit a `riarachadh barrachd air bytes isize::MAX.
/// * Geàrdan an aghaidh a bhith a `cur thairis air an fhad agad.
/// * A `gairm `handle_alloc_error` airson cuibhreannan fallible.
/// * A `toirt a-steach `ptr::Unique` agus mar sin a` toirt an neach-cleachdaidh leis na buannachdan co-cheangailte ris.
/// * A `cleachdadh an còrr a chaidh a thilleadh bhon neach-riarachaidh gus an comas as motha a tha ri fhaighinn a chleachdadh.
///
/// Chan eil an seòrsa seo ann an dòigh sam bith a `sgrùdadh a` chuimhne a tha e a `riaghladh.Nuair a thèid a leigeil às bidh e *a`leigeil às a chuimhne, ach cha bhith e* a` feuchainn ris na tha ann a leigeil seachad.
/// Tha e an urra ris an neach-cleachdaidh `RawVec` na fìor rudan *air an stòradh* taobh a-staigh `RawVec` a làimhseachadh.
///
/// Thoir fa-near gu bheil an còrr de sheòrsa meud neoni an-còmhnaidh gun chrìoch, agus mar sin bidh `capacity()` an-còmhnaidh a `tilleadh `usize::MAX`.
/// Tha seo a `ciallachadh gum feum thu a bhith faiceallach nuair a nì thu cuairt timcheall an t-seòrsa seo le `Box<[T]>`, oir cha toir `capacity()` an fhaid.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Tha seo ann air sgàth nach fheum `#[unstable]` `const fn`s cumail ri `min_const_fn` agus mar sin chan urrainnear an ainmeachadh ann an`min_const_fn`s an dàrna cuid.
    ///
    /// Ma dh `atharraicheas tu `RawVec<T>::new` no eisimeileachd, feuch an toir thu a-steach gun dad a thoirt a-steach a bhiodh fìor a` dol an aghaidh `min_const_fn`.
    ///
    /// NOTE: Dh `fhaodadh sinn an hack seo a sheachnadh agus sgrùdadh a dhèanamh air co-chòrdadh ri cuid de fheart `#[rustc_force_min_const_fn]` a dh` fheumas a bhith a `gèilleadh ri `min_const_fn` ach nach eil gu riatanach a` ceadachadh a ghairm ann an `stable(...) const fn`/còd cleachdaiche gun a bhith a `comasachadh `foo` nuair a tha `#[rustc_const_unstable(feature = "foo", issue = "01234")]` an làthair.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// A `cruthachadh an `RawVec` as motha a tha comasach (air tiùr an t-siostaim) gun a bhith a` riarachadh.
    /// Ma `T` Tha deagh meud, seo an uair sin a 'dèanamh `RawVec` le comas `0`.
    /// Ma tha `T` de mheud neoni, an uairsin nì e `RawVec` le comas `usize::MAX`.
    /// Feumail airson a bhith a `buileachadh riarachadh dàil.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// A `cruthachadh `RawVec` (air tiùr an t-siostaim) leis an dearbh chomas agus riatanasan co-thaobhadh airson `[T; capacity]`.
    /// Tha seo co-ionnan ri bhith a `gairm `RawVec::new` nuair a tha `capacity` `0` no `T` aig ìre neoni.
    /// Thoir fa-near, ma tha `T` de mheud neoni tha seo a `ciallachadh nach fhaigh thu * `RawVec` leis a` chomas a chaidh iarraidh.
    ///
    /// # Panics
    ///
    /// Panics ma tha an comas a chaidh iarraidh nas àirde na `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Giorrachadh air OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Coltach ri `with_capacity`, ach tha e a `gealltainn gum bi am bufair neoni.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Ag ath-riochdachadh `RawVec` bho stiùireadh agus comas.
    ///
    /// # Safety
    ///
    /// Feumar an `ptr` a riarachadh (air tiùrr an t-siostaim), agus leis an `capacity` a chaidh a thoirt seachad.
    /// Chan urrainn don `capacity` a bhith nas àirde na `isize::MAX` airson seòrsachan meud.(dìreach dragh air siostaman 32-bit).
    /// Is dòcha gu bheil comas suas ri `usize::MAX` aig ZST vectors.
    /// Ma thig an `ptr` agus `capacity` bho `RawVec`, tha seo cinnteach.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tha Tiny Vecs balbh.Air adhart gu:
    // - 8 ma tha meud na h-eileamaid 1, seach gu bheil luchd-sgaoilidh cruachan dualtach iarrtas nas lugha na 8 bytes a chuairteachadh gu co-dhiù 8 bytes.
    //
    // - 4 ma tha eileamaidean meadhanach mòr (<=1 KiB).
    // - 1 air dhòigh eile, gus cus àite a sheachnadh airson Vecs glè ghoirid.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Coltach ri `new`, ach air a pharaimeachadh thairis air an roghainn neach-sònrachaidh airson an `RawVec` a chaidh a thilleadh.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` a `ciallachadh "unallocated".Thathas a`toirt fa-near do sheòrsan meud neoni.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Coltach ri `with_capacity`, ach air a pharaimeachadh thairis air an roghainn neach-sònrachaidh airson an `RawVec` a chaidh a thilleadh.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Coltach ri `with_capacity_zeroed`, ach air a pharaimeachadh thairis air an roghainn neach-sònrachaidh airson an `RawVec` a chaidh a thilleadh.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Bidh e ag atharrachadh `Box<[T]>` gu `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Bidh e ag atharrachadh am bufair gu `Box<[MaybeUninit<T>]>` leis an `len` ainmichte.
    ///
    /// Thoir fa-near gum bi seo ag ath-chruthachadh gu ceart atharrachaidhean `cap` sam bith a chaidh a choileanadh.(Faic an tuairisgeul seòrsa airson mion-fhiosrachadh).
    ///
    /// # Safety
    ///
    /// * `len` feumaidh e a bhith nas motha no co-ionann ris a `chomas a chaidh iarraidh o chionn ghoirid, agus
    /// * `len` feumaidh e a bhith nas lugha na no co-ionann ri `self.capacity()`.
    ///
    /// Thoir fa-near, gum faodadh an comas a chaidh iarraidh agus `self.capacity()` a bhith eadar-dhealaichte, oir dh `fhaodadh neach-riarachaidh bloc cuimhne nas motha a thilleadh agus a thilleadh na chaidh iarraidh.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Dèan sgrùdadh air slàintealachd leth den riatanas sàbhailteachd (chan urrainn dhuinn sgrùdadh a dhèanamh air an leth eile).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Bidh sinn a `seachnadh `unwrap_or_else` an seo leis gu bheil e a` dol thairis air an ìre de LLVM IR a chaidh a chruthachadh.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Ag ath-riochdachadh `RawVec` bho stiùireadh, comas, agus neach-riarachaidh.
    ///
    /// # Safety
    ///
    /// Feumaidh an `ptr` a bhith air a riarachadh (tron riaraiche ainmichte `alloc`), agus leis an `capacity` a chaidh a thoirt seachad.
    /// Chan urrainn don `capacity` a bhith nas àirde na `isize::MAX` airson seòrsachan meud.
    /// (dìreach dragh air siostaman 32-bit).
    /// Is dòcha gu bheil comas suas ri `usize::MAX` aig ZST vectors.
    /// Ma thig an `ptr` agus `capacity` bho `RawVec` a chaidh a chruthachadh tro `alloc`, tha sin cinnteach.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// A `faighinn stiùireadh amh gu toiseach an riarachadh.
    /// Thoir fa-near gur e seo `Unique::dangling()` ma tha `capacity == 0` no `T` de mheud neoni.
    /// Anns a `chiad chùis, feumaidh tu a bhith faiceallach.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// A `faighinn comas an riarachaidh.
    ///
    /// Bidh seo an-còmhnaidh `usize::MAX` ma tha `T` de mheud neoni.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// A `tilleadh iomradh co-roinnte don neach-riarachaidh a` toirt taic don `RawVec` seo.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Tha cnap cuimhne air a riarachadh againn, gus an tèid againn air sgrùdaidhean ruith-seachad a sheachnadh gus an cruth gnàthach againn fhaighinn.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// A `dèanamh cinnteach gu bheil co-dhiù àite gu leòr anns a` bhufair airson eileamaidean `len + additional` a chumail.
    /// Mura h-eil comas gu leòr aige mu thràth, bidh e ag ath-riarachadh àite gu leòr a bharrachd air àite socair cofhurtail gus giùlan *O*(1) a thortachadh.
    ///
    /// Cuiridh e casg air a `ghiùlan seo nam biodh e gun fheum a bhith ag adhbhrachadh fhèin gu panic.
    ///
    /// Ma tha `len` nas àirde na `self.capacity()`, is dòcha nach bi seo a `riarachadh an àite a chaidh iarraidh.
    /// Chan eil seo fìor cunnartach, ach dh `fhaodadh an còd neo-shàbhailte *a sgrìobhas tu* a tha an urra ri giùlan na gnìomh seo briseadh.
    ///
    /// Tha seo air leth freagarrach airson a bhith a `buileachadh gnìomhachd mòr-bhrùthaidh mar `extend`.
    ///
    /// # Panics
    ///
    /// Panics ma ùr comas nas àirde `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Giorrachadh air OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // bhiodh an tèarmann air a dhol air adhart no air clisgeadh nam biodh an len a `dol thairis air `isize::MAX` agus mar sin tha seo sàbhailte a dhèanamh gun sgrùdadh a-nis.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// An aon rud ri `reserve`, ach a `tilleadh air mearachdan an àite a bhith a` clisgeadh no a `sgur.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// A `dèanamh cinnteach gu bheil co-dhiù àite gu leòr anns a` bhufair airson eileamaidean `len + additional` a chumail.
    /// Mura h-eil e mar-thà, ath-riaraichidh e an ìre as lugha de chuimhne a tha riatanach.
    /// Sa chumantas bidh seo dìreach mar an uiread de chuimhne a tha riatanach, ach ann am prionnsapal tha an neach-riarachaidh an-asgaidh barrachd a thoirt air ais na dh `iarr sinn.
    ///
    ///
    /// Ma tha `len` nas àirde na `self.capacity()`, is dòcha nach bi seo a `riarachadh an àite a chaidh iarraidh.
    /// Chan eil seo fìor cunnartach, ach dh `fhaodadh an còd neo-shàbhailte *a sgrìobhas tu* a tha an urra ri giùlan na gnìomh seo briseadh.
    ///
    /// # Panics
    ///
    /// Panics ma ùr comas nas àirde `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Giorrachadh air OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// An aon rud ri `reserve_exact`, ach a `tilleadh air mearachdan an àite a bhith a` clisgeadh no a `sgur.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// A `lughdachadh an riarachaidh sìos chun t-sùim ainmichte.
    /// Mas e 0 an t-suim a chaidh a thoirt seachad, gu dearbh a `tuigsinn gu tur.
    ///
    /// # Panics
    ///
    /// Panics ma tha an sùim a chaidh a thoirt seachad *nas motha* na an comas làithreach.
    ///
    /// # Aborts
    ///
    /// Giorrachadh air OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Tilleadh ma bufair feumalachdan a 'fàs a choileanadh air an robh feum comas a bharrachd.
    /// Air a chleachdadh sa mhòr-chuid gus gairmean glèidhte a dhèanamh comasach gun a bhith a `toirt a-steach `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Mar as trice thèid am modh seo a chuir sa bhad iomadh uair.Mar sin tha sinn airson gum bi e cho beag `s a ghabhas, gus amannan cur ri chèile a leasachadh.
    // Ach tha sinn cuideachd ag iarraidh gum bi uimhir den t-susbaint aige comasach gu staitistigeil agus a dhèanamh, gus am bi an còd a chaidh a chruthachadh a `ruith nas luaithe.
    // Mar sin, tha an dòigh seo air a sgrìobhadh gu faiceallach gus am bi a h-uile còd a tha an urra ri `T` taobh a-staigh e, fhad `s a tha uimhir den chòd nach eil an urra ri `T` sa ghabhas ann an gnìomhan a tha neo-ghnèitheach thairis air `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Tha seo air a dhèanamh cinnteach leis na co-theacsan gairm.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Bhon a thilleas sinn comas `usize::MAX` nuair a tha `elem_size`
            // 0, le bhith a `ruighinn an seo gu riatanach a` ciallachadh gu bheil an `RawVec` cus.
            return Err(CapacityOverflow);
        }

        // Chan eil dad as urrainn dhuinn a dhèanamh mu na sgrùdaidhean sin, gu duilich.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Tha seo a `gealltainn fàs exponential.
        // Chan urrainn don dùblachadh a dhol thairis oir is e `cap <= isize::MAX` agus an seòrsa `cap` `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` neo-ghnèitheach thairis air `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Tha na cuingeadan air an dòigh seo glè choltach ris an fheadhainn air `grow_amortized`, ach mar as trice bidh an dòigh seo air a chuir sa bhad cho tric agus mar sin chan eil e cho riatanach.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Bhon a thilleas sinn comas `usize::MAX` nuair a tha meud an t-seòrsa
            // 0, le bhith a `ruighinn an seo gu riatanach a` ciallachadh gu bheil an `RawVec` cus.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` neo-ghnèitheach thairis air `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Tha an gnìomh seo taobh a-muigh `RawVec` gus amannan cur ri chèile a lughdachadh.Faic an iomradh gu h-àrd `RawVec::grow_amortized` airson mion-fhiosrachadh.
// (Chan eil am paramadair `A` cudromach, seach gu bheil an àireamh de dhiofar sheòrsaichean `A` a chithear ann an cleachdadh mòran nas lugha na an àireamh de sheòrsaichean `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Thoir sùil airson a `mhearachd an seo gus meud `RawVec::grow_*` a lughdachadh.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Bidh an neach-riarachaidh a `dèanamh sgrùdadh airson co-ionannachd co-thaobhadh
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// A `saoradh a` chuimhne a tha leis an `RawVec`*gun* a `feuchainn ris na tha ann a leigeil seachad.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Prìomh ghnìomh airson làimhseachadh mearachd glèidhte.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Feumaidh sinn gealltainn na leanas:
// * Cha bhith sinn uair sam bith a `riarachadh nithean meud byte `> isize::MAX`.
// * Cha bhith sinn a `dol thairis air `usize::MAX` agus gu dearbh a` riarachadh ro bheag.
//
// Air 64-bit feumaidh sinn dìreach sgrùdadh a dhèanamh airson faighinn thairis air oir bidh sinn gu cinnteach a `feuchainn ri `> isize::MAX` bytes a riarachadh.
// Air 32-bit agus 16-bit feumaidh sinn geàrd a bharrachd a chuir ris airson seo air eagal gu bheil sinn a `ruith air àrd-ùrlar a dh` fhaodas a h-uile 4GB a chleachdadh ann an àite luchd-cleachdaidh, me, PAE no x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Is e aon phrìomh dhleastanas a tha an urra ri comas aithris a bhith a `cur thairis.
// Nì seo cinnteach nach bi an ginealach còd co-cheangailte ris na panics ach glè bheag oir chan eil ann ach aon àite far a bheil panics seach cnap air feadh a `mhodal.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}