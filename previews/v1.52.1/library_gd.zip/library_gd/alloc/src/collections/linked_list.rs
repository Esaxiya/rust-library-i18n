//! Liosta le ceangal dùbailte le nodan seilbh.
//!
//! Tha an `LinkedList` a `ceadachadh eileamaidean putadh is popping aig gach ceann ann an ùine chunbhalach.
//!
//! NOTE: Tha e an-còmhnaidh nas fheàrr [`Vec`] no [`VecDeque`] a chleachdadh leis gu bheil soithichean stèidhichte air raon mar as trice nas luaithe, nas èifeachdaiche a thaobh cuimhne, agus a `dèanamh feum nas fheàrr de tasgadan CPU.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// Liosta le ceangal dùbailte le nodan seilbh.
///
/// Tha an `LinkedList` a `ceadachadh eileamaidean putadh is popping aig gach ceann ann an ùine chunbhalach.
///
/// NOTE: Tha e an-còmhnaidh nas fheàrr `Vec` no `VecDeque` a chleachdadh leis gu bheil soithichean stèidhichte air raon mar as trice nas luaithe, nas èifeachdaiche a thaobh cuimhne, agus a `dèanamh feum nas fheàrr de tasgadan CPU.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// Reultair thairis air na h-eileamaidean de `LinkedList`.
///
/// Tha an `struct` seo air a chruthachadh le [`LinkedList::iter()`].
/// Faic na sgrìobhainnean aige airson tuilleadh.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) Thoir air falbh fàbhar `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// Ath-aithrisiche gluasadach thairis air na h-eileamaidean de `LinkedList`.
///
/// Tha an `struct` seo air a chruthachadh le [`LinkedList::iter_mut()`].
/// Faic na sgrìobhainnean aige airson tuilleadh.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // Chan eil *an* liosta iomlan againn an seo a-mhàin, chaidh iomraidhean air nód's `element` a thoirt seachad leis an iterator!Mar sin bi faiceallach nuair a bhios tu a `cleachdadh seo;feumaidh na modhan ris an canar a bhith mothachail gum faod comharran a bhith a`taobhadh ri `element`.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// Itealain seilbh thairis air na h-eileamaidean de `LinkedList`.
///
/// Tha an `struct` seo air a chruthachadh leis an dòigh [`into_iter`] air [`LinkedList`] (air a thoirt seachad leis an `IntoIterator` trait).
/// Faic na sgrìobhainnean aige airson tuilleadh.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// dòighean prìobhaideach
impl<T> LinkedList<T> {
    /// Cuir an nód a chaidh a thoirt air beulaibh an liosta.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // Bidh an dòigh seo a `gabhail cùram gun a bhith a` cruthachadh iomraidhean gluasadach air nodan slàn, gus dligheachd chomharran tarraing a-steach gu `element` a chumail suas.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // Gun a bhith a `cruthachadh iomraidhean (unique!) mutable ùra a` dol thairis air `element`.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// A `toirt air falbh agus a` tilleadh an nód air beulaibh an liosta.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // Bidh an dòigh seo a `gabhail cùram gun a bhith a` cruthachadh iomraidhean gluasadach air nodan slàn, gus dligheachd chomharran tarraing a-steach gu `element` a chumail suas.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // Gun a bhith a `cruthachadh iomraidhean (unique!) mutable ùra a` dol thairis air `element`.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Cuir an nód a chaidh a thoirt seachad air cùl an liosta.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // Bidh an dòigh seo a `gabhail cùram gun a bhith a` cruthachadh iomraidhean gluasadach air nodan slàn, gus dligheachd chomharran tarraing a-steach gu `element` a chumail suas.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // Gun a bhith a `cruthachadh iomraidhean (unique!) mutable ùra a` dol thairis air `element`.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// A `toirt air falbh agus a` tilleadh an nód aig cùl an liosta.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // Bidh an dòigh seo a `gabhail cùram gun a bhith a` cruthachadh iomraidhean gluasadach air nodan slàn, gus dligheachd chomharran tarraing a-steach gu `element` a chumail suas.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // Gun a bhith a `cruthachadh iomraidhean (unique!) mutable ùra a` dol thairis air `element`.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// A `ceangal an nód ainmichte bhon liosta làithreach.
    ///
    /// Rabhadh: cha dèan seo sgrùdadh gum buin an nód a chaidh a thoirt seachad don liosta làithreach.
    ///
    /// Bidh an dòigh seo a `gabhail cùram gun a bhith a` cruthachadh iomraidhean gluasadach air `element`, gus dligheachd phuingean aliasing a chumail suas.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // tha am fear seo againn a-nis, is urrainn dhuinn &mut a chruthachadh.

        // Gun a bhith a `cruthachadh iomraidhean (unique!) mutable ùra a` dol thairis air `element`.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // is e an nód seo an nód ceann
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // is e an nód seo an nód earball
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// Splices sreath de nodan eadar dà nodan a th `ann.
    ///
    /// Rabhadh: cha dèan seo sgrùdadh gum buin an nód a chaidh a thoirt seachad don dà liosta a tha ann.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // Bidh an dòigh seo a `gabhail cùram gun a bhith a` cruthachadh grunn iomraidhean gluasadach air nodan slàn aig an aon àm, gus dligheachd chomharran aliasing a chumail a-steach do `element`.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// A `lorg a h-uile nod bho liosta ceangailte mar shreath de nodan.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Is e an nód sgoltadh an nód ceann ùr den dàrna pàirt
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // Fix ptr ceann an dàrna pàirt
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Is e an nód sgoltadh an nód earball ùr den chiad phàirt agus tha ceann an dàrna pàirt aige.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // Fix an earball ptr den chiad phàirt
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// A `cruthachadh `LinkedList<T>` falamh.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// A `cruthachadh `LinkedList` falamh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// Gluais a h-uile eileamaid bho `other` gu deireadh an liosta.
    ///
    /// Bidh seo ag ath-chleachdadh na nodan gu lèir bho `other` agus gan gluasad a-steach gu `self`.
    /// Às deidh na h-obrachaidh seo, bidh `other` a `fàs falamh.
    ///
    /// Bu chòir don obrachadh seo a bhith a `cunntadh ann an ùine *O*(1) agus *O*(1) cuimhne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` ceart gu leòr an seo oir tha cothrom sònraichte againn air an dà liosta gu h-iomlan.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Gluais a h-uile eileamaid bho `other` gu toiseach an liosta.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` ceart gu leòr an seo oir tha cothrom sònraichte againn air an dà liosta gu h-iomlan.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// A `toirt seachad iterator air adhart.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// A `toirt seachad itealaiche air adhart le iomraidhean gluasadach.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// A `toirt seachad cursair aig an eileamaid aghaidh.
    ///
    /// Tha an cursair a `comharrachadh an eileamaid "ghost" ma tha an liosta falamh.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// A `toirt seachad cursair le obair deasachaidh aig an eileamaid aghaidh.
    ///
    /// Tha an cursair a `comharrachadh an eileamaid "ghost" ma tha an liosta falamh.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// A `toirt seachad cursair aig an eileamaid chùil.
    ///
    /// Tha an cursair a `comharrachadh an eileamaid "ghost" ma tha an liosta falamh.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// A `toirt seachad cursair le obair deasachaidh aig an eileamaid chùil.
    ///
    /// Tha an cursair a `comharrachadh an eileamaid "ghost" ma tha an liosta falamh.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// A `tilleadh `true` ma tha an `LinkedList` falamh.
    ///
    /// Bu chòir don obrachadh seo a bhith a `cunntadh ann an ùine *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// A `tilleadh fad an `LinkedList`.
    ///
    /// Bu chòir don obrachadh seo a bhith a `cunntadh ann an ùine *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Thoir air falbh a h-uile eileamaid bhon `LinkedList`.
    ///
    /// Bu chòir don obrachadh seo a bhith a `cunntadh ann an ùine *O*(*n*).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// A `tilleadh `true` ma tha eileamaid anns an `LinkedList` a tha co-ionann ris an luach a chaidh a thoirt seachad.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// A `toirt iomradh air an eileamaid aghaidh, no `None` ma tha an liosta falamh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// A `toirt seachad iomradh gluasadach air an eileamaid aghaidh, no `None` ma tha an liosta falamh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// A `toirt iomradh air an eileamaid chùil, no `None` ma tha an liosta falamh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// A `toirt seachad iomradh gluasadach air an eileamaid chùil, no `None` ma tha an liosta falamh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Cuir eileamaid an toiseach air an liosta.
    ///
    /// Bu chòir don obrachadh seo a bhith a `cunntadh ann an ùine *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// Thoir air falbh a `chiad eileamaid agus till e, no `None` ma tha an liosta falamh.
    ///
    ///
    /// Bu chòir don obrachadh seo a bhith a `cunntadh ann an ùine *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// A `cur eileamaid ri cùl liosta.
    ///
    /// Bu chòir don obrachadh seo a bhith a `cunntadh ann an ùine *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// Thoir air falbh an eileamaid mu dheireadh bho liosta agus till e, no `None` ma tha e falamh.
    ///
    ///
    /// Bu chòir don obrachadh seo a bhith a `cunntadh ann an ùine *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// Roinnidh e an liosta gu dhà aig a `chlàr-innse a chaidh a thoirt seachad.
    /// Tillidh a h-uile càil às deidh a `chlàr-innse a chaidh a thoirt seachad, a` toirt a-steach an clàr-amais.
    ///
    /// Bu chòir don obrachadh seo a bhith a `cunntadh ann an ùine *O*(*n*).
    ///
    /// # Panics
    ///
    /// Panics ma tha `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // Gu h-ìosal, bidh sinn ag itealaich a dh `ionnsaigh an nód` i-1`th, an toiseach no bhon deireadh, a rèir dè a bhiodh na bu luaithe.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // an àite a bhith a `sgìtheadh le bhith a` cleachdadh .skip() (a chruthaicheas structar ùr), bidh sinn a `sgrìobadh le làimh gus am faigh sinn cothrom air an raon cinn gun a bhith an urra ri mion-fhiosrachadh buileachaidh Skip
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // nas fheàrr dheth a `tòiseachadh bhon deireadh
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// Thoir air falbh an eileamaid aig a `chlàr-innse a chaidh a thoirt seachad agus a thilleadh.
    ///
    /// Bu chòir don obrachadh seo a bhith a `cunntadh ann an ùine *O*(*n*).
    ///
    /// # Panics
    /// Panics ma tha aig>=len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // Gu h-ìosal, bidh sinn ag itealaich a dh `ionnsaigh an nód aig a` chlàr-innse a chaidh a thoirt seachad, an dara cuid bhon toiseach no bhon deireadh, a rèir dè a bhiodh nas luaithe.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// A `cruthachadh itealaiche a bhios a` cleachdadh dùnadh gus faighinn a-mach am bu chòir eileamaid a thoirt air falbh.
    ///
    /// Ma tha an dùnadh a `tilleadh fìor, tha an eileamaid air a thoirt air falbh agus air a thoirt a-mach.
    /// Ma thilleas an dùnadh meallta, fuirichidh an eileamaid air an liosta agus cha toir an iterator toradh dha.
    ///
    /// Thoir fa-near gu bheil `drain_filter` a `leigeil leat a h-uile eileamaid den dùnadh sìoltachain a thionndadh, ge bith a bheil thu airson a chumail no a thoirt air falbh.
    ///
    ///
    /// # Examples
    ///
    /// A `roinneadh liosta gu oidhcheannan is neònach, ag ath-chleachdadh an liosta thùsail:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // seachain cùisean air iasad.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // Lean air adhart leis an aon lùb a nì sinn gu h-ìosal.Cha ruith seo ach nuair a tha inneal-sgrios air clisgeadh.
                // Ma tha fear eile panics falbhaidh seo.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Feum air beatha gun cheangal gus faighinn 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Feum air beatha gun cheangal gus faighinn 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Feum air beatha gun cheangal gus faighinn 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Feum air beatha gun cheangal gus faighinn 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// Cùrsair thairis air `LinkedList`.
///
/// Tha `Cursor` coltach ri iterator, ach a-mhàin gum faod e gu saor a shireadh air ais is a-mach.
///
/// Bidh cùrsairean an-còmhnaidh a `laighe eadar dà eileamaid air an liosta, agus clàr-amais ann an dòigh cruinn gu loidsigeach.
/// Gus gabhail ri seo, tha neo-eileamaid "ghost" ann a bheir `None` eadar ceann agus earball an liosta.
///
///
/// Nuair a thèid a chruthachadh, bidh cursors a `tòiseachadh aig toiseach an liosta, no an "ghost" neo-eileamaid ma tha an liosta falamh.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// Cùrsair thairis air `LinkedList` le obair deasachaidh.
///
/// Tha `Cursor` coltach ri iterator, ach a-mhàin gum faod e gu saor a shireadh air ais is a-mach, agus gun urrainn dha an liosta a thionndadh gu sàbhailte aig àm iteachaidh.
/// Tha seo air sgàth gu bheil beatha nan iomraidhean a thug e seachad ceangailte ri a bheatha fhèin, an àite dìreach an liosta bunaiteach.
/// Tha seo a `ciallachadh nach urrainn dha cursors grunn eileamaidean a thoirt a-mach aig an aon àm.
///
/// Bidh cùrsairean an-còmhnaidh a `laighe eadar dà eileamaid air an liosta, agus clàr-amais ann an dòigh cruinn gu loidsigeach.
/// Gus gabhail ri seo, tha neo-eileamaid "ghost" ann a bheir `None` eadar ceann agus earball an liosta.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// A `tilleadh clàr-amais suidheachadh a` chùrsair taobh a-staigh an `LinkedList`.
    ///
    /// Bidh seo a `tilleadh `None` ma tha an cursair an-dràsta a` comharrachadh an eileamaid "ghost".
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Gluais an cursair chun ath eileamaid den `LinkedList`.
    ///
    /// Ma tha an cursair a `comharrachadh an eileamaid "ghost" an uairsin gluaisidh seo e chun chiad eileamaid den `LinkedList`.
    /// Ma tha e a `comharrachadh an eileamaid mu dheireadh den `LinkedList`, gluaisidh seo e chun an eileamaid "ghost".
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Cha robh eileamaid gnàthach againn;bha an cursair na shuidhe aig an t-suidheachadh tòiseachaidh Bu chòir an ath eileamaid a bhith aig ceann an liosta
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Bha eileamaid roimhe againn, mar sin rachamaid chun ath fhear
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Gluais an cursair chun eileamaid roimhe den `LinkedList`.
    ///
    /// Ma tha an cursair a `comharrachadh an eileamaid "ghost" an uairsin gluaisidh seo e chun eileamaid mu dheireadh den `LinkedList`.
    /// Ma tha e a `comharrachadh a` chiad eileamaid den `LinkedList`, gluaisidh seo e chun an eileamaid "ghost".
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Gun gnàthach.Tha sinn aig toiseach an liosta.Toradh Chan eil gin agus leum chun deireadh.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Have prev.Toradh e agus rachaibh chun eileamaid roimhe.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// A `tilleadh iomradh air an eileamaid ris a bheil an cursair a` comharrachadh.
    ///
    /// Bidh seo a `tilleadh `None` ma tha an cursair an-dràsta a` comharrachadh an eileamaid "ghost".
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// A `tilleadh iomradh air an ath eileamaid.
    ///
    /// Ma tha an cursair a `comharrachadh an eileamaid "ghost" an uairsin tillidh seo a` chiad eileamaid den `LinkedList`.
    /// Ma tha e a `comharrachadh an eileamaid mu dheireadh den `LinkedList` tha seo a` tilleadh `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// A `tilleadh iomradh air an eileamaid roimhe.
    ///
    /// Ma tha an cursair a `comharrachadh an eileamaid "ghost" an uairsin tillidh seo an eileamaid mu dheireadh den `LinkedList`.
    /// Ma tha e a `comharrachadh a` chiad eileamaid den `LinkedList` tha seo a `tilleadh `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// A `tilleadh clàr-amais suidheachadh a` chùrsair taobh a-staigh an `LinkedList`.
    ///
    /// Bidh seo a `tilleadh `None` ma tha an cursair an-dràsta a` comharrachadh an eileamaid "ghost".
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Gluais an cursair chun ath eileamaid den `LinkedList`.
    ///
    /// Ma tha an cursair a `comharrachadh an eileamaid "ghost" an uairsin gluaisidh seo e chun chiad eileamaid den `LinkedList`.
    /// Ma tha e a `comharrachadh an eileamaid mu dheireadh den `LinkedList`, gluaisidh seo e chun an eileamaid "ghost".
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Cha robh eileamaid gnàthach againn;bha an cursair na shuidhe aig an t-suidheachadh tòiseachaidh Bu chòir an ath eileamaid a bhith aig ceann an liosta
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Bha eileamaid roimhe againn, mar sin rachamaid chun ath fhear
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Gluais an cursair chun eileamaid roimhe den `LinkedList`.
    ///
    /// Ma tha an cursair a `comharrachadh an eileamaid "ghost" an uairsin gluaisidh seo e chun eileamaid mu dheireadh den `LinkedList`.
    /// Ma tha e a `comharrachadh a` chiad eileamaid den `LinkedList`, gluaisidh seo e chun an eileamaid "ghost".
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Gun gnàthach.Tha sinn aig toiseach an liosta.Toradh Chan eil gin agus leum chun deireadh.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Have prev.Toradh e agus rachaibh chun eileamaid roimhe.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// A `tilleadh iomradh air an eileamaid ris a bheil an cursair a` comharrachadh.
    ///
    /// Bidh seo a `tilleadh `None` ma tha an cursair an-dràsta a` comharrachadh an eileamaid "ghost".
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// A `tilleadh iomradh air an ath eileamaid.
    ///
    /// Ma tha an cursair a `comharrachadh an eileamaid "ghost" an uairsin tillidh seo a` chiad eileamaid den `LinkedList`.
    /// Ma tha e a `comharrachadh an eileamaid mu dheireadh den `LinkedList` tha seo a` tilleadh `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// A `tilleadh iomradh air an eileamaid roimhe.
    ///
    /// Ma tha an cursair a `comharrachadh an eileamaid "ghost" an uairsin tillidh seo an eileamaid mu dheireadh den `LinkedList`.
    /// Ma tha e a `comharrachadh a` chiad eileamaid den `LinkedList` tha seo a `tilleadh `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// A `tilleadh cùrsair leughaidh a-mhàin a` comharrachadh an eileamaid làithreach.
    ///
    /// Tha beatha an `Cursor` a chaidh a thilleadh ceangailte ri beatha an `CursorMut`, a `ciallachadh nach urrainn dha a dhol thairis air an `CursorMut` agus gu bheil an `CursorMut` reòta fad beatha an `Cursor`.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// A-nis na h-obraichean deasachaidh liosta

impl<'a, T> CursorMut<'a, T> {
    /// Cuir a-steach eileamaid ùr a-steach don `LinkedList` às deidh an tè a th `ann an-dràsta.
    ///
    /// Ma tha an cursair a `comharrachadh an eileamaid "ghost" an uairsin tha an eileamaid ùr air a chuir a-steach air beulaibh an `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // Tha clàr-amais neo-eileamaid "ghost" air atharrachadh.
                self.index = self.list.len;
            }
        }
    }

    /// Cuir a-steach eileamaid ùr a-steach don `LinkedList` ron fhear làithreach.
    ///
    /// Ma tha an cursair a `comharrachadh an eileamaid "ghost" an uairsin tha an eileamaid ùr air a chuir a-steach aig deireadh an `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// Thoir air falbh an eileamaid làithreach bhon `LinkedList`.
    ///
    /// Tha an eileamaid a chaidh a thoirt air falbh air a thilleadh, agus tha an cursair air a ghluasad gus a chomharrachadh chun ath eileamaid san `LinkedList`.
    ///
    ///
    /// Ma tha an cursair an-dràsta a `comharrachadh an eileamaid "ghost" chan eil eileamaid air a thoirt air falbh agus tha `None` air a thilleadh.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// Thoir air falbh an eileamaid làithreach bhon `LinkedList` gun a bhith a `tuigsinn nód an liosta.
    ///
    /// Tha an nód a chaidh a thoirt air falbh air a thilleadh mar `LinkedList` ùr anns nach eil ach an nód sin.
    /// Tha an cursair air a ghluasad gu bhith a `comharrachadh an ath eileamaid den `LinkedList` gnàthach.
    ///
    /// Ma tha an cursair an-dràsta a `comharrachadh an eileamaid "ghost" chan eil eileamaid air a thoirt air falbh agus tha `None` air a thilleadh.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// Cuir a-steach na h-eileamaidean bhon `LinkedList` a chaidh a thoirt seachad às deidh an tè làithreach.
    ///
    /// Ma tha an cursair a `comharrachadh an eileamaid "ghost" an uairsin tha na h-eileamaidean ùra air an cuir a-steach aig toiseach an `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // Tha clàr-amais neo-eileamaid "ghost" air atharrachadh.
                self.index = self.list.len;
            }
        }
    }

    /// Cuir a-steach na h-eileamaidean bhon `LinkedList` a chaidh a thoirt seachad ron fhear làithreach.
    ///
    /// Ma tha an cursair a `comharrachadh an eileamaid "ghost" an uairsin tha na h-eileamaidean ùra air an cuir a-steach aig deireadh an `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// Roinn an liosta gu dhà às deidh an eileamaid làithreach.
    /// Tillidh seo liosta ùr air a dhèanamh suas de gach nì às deidh a `chursair, leis an liosta thùsail a` gleidheadh a h-uile dad roimhe.
    ///
    ///
    /// Ma tha an cursair a `comharrachadh an eileamaid "ghost" an uairsin gluaisidh susbaint iomlan an `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // Tha clàr-amais neo-eileamaid "ghost" air atharrachadh gu 0.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// Roinn an liosta gu dhà ron eileamaid làithreach.
    /// Tillidh seo liosta ùr anns am bi a h-uile dad ron cursair, leis an liosta thùsail a `gleidheadh a h-uile càil às deidh.
    ///
    ///
    /// Ma tha an cursair a `comharrachadh an eileamaid "ghost" an uairsin gluaisidh susbaint iomlan an `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// Iterator air a thoirt gu buil le bhith a `gairm `drain_filter` air LinkedList.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` ceart gu leòr le bhith a `toirt iomradh air iomraidhean `element`.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Cleachd an liosta gu iterator le eileamaidean a rèir luach.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// Dèan cinnteach gu bheil `LinkedList` agus na h-itealain leughaidh a-mhàin covariant anns na paramadairean seòrsa aca.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}