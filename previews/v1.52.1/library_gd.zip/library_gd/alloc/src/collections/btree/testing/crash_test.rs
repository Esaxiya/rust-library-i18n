use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Blueprint airson suidheachaidhean duilich deuchainn tubaist a bhios a `cumail sùil air tachartasan sònraichte.
/// Faodar cuid de shuidheachaidhean a rèiteachadh gu panic aig àm air choreigin.
/// Is e tachartasan `clone`, `drop` no cuid de `query` gun urra.
///
/// Tha dummies deuchainn tubaist air an comharrachadh agus air an òrdachadh le id, gus an urrainnear an cleachdadh mar iuchraichean ann am BTreeMap.
/// Chan eil am buileachadh a `cleachdadh a dh'aona ghnothach an urra ri rud sam bith a tha air a mhìneachadh anns an crate, ach a-mhàin an `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// A `cruthachadh dealbhadh dummy deuchainn tubaist.Bidh an `id` a`dearbhadh òrdugh agus co-ionannachd shuidheachaidhean.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// A `cruthachadh eisimpleir de dhuslach deuchainn tubaist a bhios a` clàradh na tachartasan a dh `fhiosraich e agus gu roghnach panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// A `tilleadh cia mheud uair a chaidh clisgeadh a dhèanamh.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// A `tilleadh cia mheud uair a chaidh an dadam a leigeil sìos.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// A `tilleadh cia mheud uair a chaidh am ball `query` a ghairm.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Cuid de cheist gun urra, agus tha an toradh mu thràth air a thoirt seachad.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}