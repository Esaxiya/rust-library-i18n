use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// Thoir air falbh paidhir prìomh luach bhon chraoibh, agus tillidh e am paidhir sin, a bharrachd air an duilleach edge a rèir an t-seann phaidhir sin.
    /// Tha e comasach gu bheil seo a `falmhachadh nód freumh a tha a-staigh, a bu chòir don neach-fòn pop a-mach bhon mhapa a tha a` cumail na craoibhe.
    /// Bu chòir don neach-fios cuideachd lùghdachadh a dhèanamh air faid a `mhapa.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // Feumaidh sinn dìochuimhneachadh gu sealach an seòrsa leanaibh, oir chan eil seòrsa nód sònraichte ann airson pàrantan duilleach a tha faisg air làimh.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // SÀBHAILTEACHD: Is e `new_pos` an duilleag às an do thòisich sinn no bràthair no piuthar.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // A-mhàin ma chaidh sinn còmhla, tha am pàrant (ma tha sin ann) air crìonadh, ach le bhith a `leum air a` cheum a leanas air dhòigh eile cha bhith e a `pàigheadh dheth ann an comharran-measaidh.
            //
            // SÀBHAILTEACHD: Cha bhith sinn a `sgrios no ag ath-rèiteachadh na duilleige far a bheil `pos`
            // le bhith a `làimhseachadh a phàrant gu ath-chuairteachail;aig a`char as miosa bidh sinn a`sgrios no ag ath-rèiteachadh a`phàrant tron t-seanair no a seanmhair, mar sin ag atharrachadh an ceangal ris a` phàrant taobh a-staigh na duilleige.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // Thoir air falbh KV faisg air làimh bhon duilleach aige agus an uairsin cuir air ais e an àite an eileamaid a chaidh iarraidh oirnn a thoirt air falbh.
        //
        // B `fheàrr leat an KV clì ri taobh, airson na h-adhbharan air an liostadh ann an `choose_parent_kv`.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // Is dòcha gun deach an nód a-staigh a ghoid no a thoirt còmhla.
        // Gabh air ais chun làimh dheis gus faighinn a-mach càite a thàinig an KV tùsail gu crìch.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}