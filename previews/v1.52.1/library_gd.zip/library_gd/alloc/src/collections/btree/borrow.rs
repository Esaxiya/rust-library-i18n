use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modailean ath-thionndadh de dh `iomradh sònraichte, nuair a tha fios agad nach tèid an ath-thionndadh agus a shliochd uile (ie, a h-uile comharradh agus iomradh a thig bhuaithe) a chleachdadh tuilleadh aig àm air choreigin, às deidh sin tha thu airson an iomradh sònraichte tùsail a chleachdadh a-rithist .
///
///
/// Mar as trice bidh an t-inneal-iasaid a `làimhseachadh an cruachadh seo de dh` iasadan dhut, ach tha cuid de shruth smachd a choileanas an cruachadh seo ro iom-fhillte airson an trusaiche a leantainn.
/// Leigidh `DormantMutRef` leat sgrùdadh a dhèanamh air iasad dhut fhèin, fhad `s a tha thu fhathast a` cur an cèill a nàdar cruachan, agus a `gabhail a-steach an còd puing amh a dh` fheumar gus seo a dhèanamh gun ghiùlan neo-mhìnichte.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Glac iasad sònraichte, agus cuir air ais e sa bhad.
    /// Airson an trusaiche, tha beatha an t-iomradh ùr co-ionann ri beatha an t-iomradh tùsail, ach feumaidh tu promise a chleachdadh airson ùine nas giorra.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SÀBHAILTEACHD: bidh sinn a `cumail an iasad air feadh` a via `_marker`, agus bidh sinn a `nochdadh
        // a-mhàin an iomradh seo, mar sin tha e gun samhail.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Till air ais chun iasad sònraichte a chaidh a ghlacadh an toiseach.
    ///
    /// # Safety
    ///
    /// Feumaidh an ath-thionndadh a thighinn gu crìch, ie, chan fhaodar an iomradh a thill `new` agus a h-uile comharra agus iomradh a thàinig bhuaithe a chleachdadh tuilleadh.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SÀBHAILTEACHD: tha na cumhaichean sàbhailteachd againn fhìn a `ciallachadh gu bheil an iomradh seo a-rithist gun samhail.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;