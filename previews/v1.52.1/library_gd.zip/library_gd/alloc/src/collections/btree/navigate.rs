use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Bidh sealach a `toirt a-mach co-ionnan eile nach gabh gluasad den aon raon.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// A `lorg oirean duilleach sònraichte a` cuairteachadh raon sònraichte ann an craobh.
    /// A `tilleadh an dàrna cuid paidhir de làmhan eadar-dhealaichte a-steach don aon chraobh no paidhir de roghainnean falamh.
    ///
    /// # Safety
    ///
    /// Mura h-eil `BorrowType` `Immut`, na cleachd na làmhan dà-fhillte gus tadhal air an aon KV dà uair.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Co-ionann ri `(root1.first_leaf_edge(), root2.last_leaf_edge())` ach nas èifeachdaiche.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Lorgar am paidhir oirean duilleach a `cuairteachadh raon sònraichte ann an craobh.
    ///
    /// Tha an toradh brìoghmhor a-mhàin ma tha a `chraobh air òrdachadh le iuchair, mar a tha a` chraobh ann an `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // SÀBHAILTEACHD: tha an seòrsa iasad againn neo-ghluasadach.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Lorgar am paidhir oirean duilleach a `cuairteachadh craobh gu lèir.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// A `sgoltadh iomradh sònraichte a-steach do phaidhir oirean duilleach a` cuairteachadh raon sònraichte.
    /// Is e an toradh iomraidhean neo-shònraichte a `ceadachadh mùthadh (some), a dh` fheumar a chleachdadh gu faiceallach.
    ///
    /// Tha an toradh brìoghmhor a-mhàin ma tha a `chraobh air òrdachadh le iuchair, mar a tha a` chraobh ann an `BTreeMap`.
    ///
    ///
    /// # Safety
    /// Na cleachd na làmhan dùbailte gus tadhal air an aon KV dà uair.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// A `sgoltadh iomradh sònraichte a-steach do phaidhir oirean duilleach a` cuairteachadh làn raon na craoibhe.
    /// Tha na toraidhean nan iomraidhean neo-shònraichte a `ceadachadh mùthadh (de luachan a-mhàin), mar sin feumar an cleachdadh le cùram.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Bidh sinn a `dùblachadh freumh NodeRef an seo-cha bhith sinn a` tadhal air an aon KV dà uair, agus cha bhi sinn uair sam bith a `crìochnachadh le iomraidhean luach thar-tharraingeach.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// A `sgoltadh iomradh sònraichte a-steach do phaidhir oirean duilleach a` cuairteachadh làn raon na craoibhe.
    /// Tha na toraidhean nan iomraidhean neo-shònraichte a tha a `ceadachadh mùthadh uamhasach millteach, mar sin feumar a chleachdadh leis a` chùram as motha.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Bidh sinn a `dùblachadh freumh NodeRef an seo-cha bhith sinn a-riamh a` faighinn thuige ann an dòigh a tha a `dol thairis air iomraidhean a gheibhear bhon fhreumh.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// A `toirt làimhseachadh duille edge, tillidh [`Result::Ok`] le cas chun KV nàbaidh air an taobh cheart, a tha an dàrna cuid san aon nód duilleach no ann an nód sinnsear.
    ///
    /// Mas e an duilleach edge am fear mu dheireadh sa chraoibh, tillidh [`Result::Err`] leis a `nód root.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// A `toirt làmh edge duilleach, tillidh [`Result::Ok`] le cas chun KV nàbaidh air an taobh chlì, a tha an dàrna cuid san aon nód duilleach no ann an nód sinnsear.
    ///
    /// Mas e an duilleach edge a `chiad fhear sa chraoibh, tillidh [`Result::Err`] leis a` nód root.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// A `toirt làmh edge a-staigh, tillidh [`Result::Ok`] le cas chun KV nàbaidh air an taobh cheart, a tha an dàrna cuid san aon nód a-staigh no ann an nód sinnsear.
    ///
    /// Mas e an edge a-staigh am fear mu dheireadh sa chraoibh, tillidh [`Result::Err`] leis a `nód root.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// A `toirt làimhseachadh duilleach edge a-steach do chraobh a tha a` bàsachadh, tillidh an ath dhuilleag edge air an taobh cheart, agus am paidhir luach-iuchrach eatarra, a tha an dàrna cuid san aon nód duille, ann an nód sinnsear, no nach eil idir ann.
    ///
    ///
    /// Bidh an dòigh seo cuideachd a `tuigsinn node(s) sam bith a ruigeas e deireadh.
    /// Tha seo a `ciallachadh mura h-eil paidhir prìomh luach eile ann, bidh an còrr den chraoibh air a bhith air a thuigsinn agus chan eil dad air fhàgail airson tilleadh.
    ///
    /// # Safety
    /// Chan fhaod an edge a chaidh a thoirt seachad a bhith air a thilleadh roimhe le counter `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// A `toirt làmh edge duilleach a-steach do chraobh a tha a` bàsachadh, tillidh an ath dhuilleag edge air an taobh chlì, agus am paidhir luach-iuchrach eatarra, a tha an dàrna cuid san aon nód duille, ann an nód sinnsear, no nach eil idir ann.
    ///
    ///
    /// Bidh an dòigh seo cuideachd a `tuigsinn node(s) sam bith a ruigeas e deireadh.
    /// Tha seo a `ciallachadh mura h-eil paidhir prìomh luach eile ann, bidh an còrr den chraoibh air a bhith air a thuigsinn agus chan eil dad air fhàgail airson tilleadh.
    ///
    /// # Safety
    /// Chan fhaod an edge a chaidh a thoirt seachad a bhith air a thilleadh roimhe le counter `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Deallocates cnap de nodan bhon duilleach suas chun fhreumh.
    /// Is e seo an aon dòigh air a `chòrr de chraobh a thuigsinn às deidh do `deallocating_next` agus `deallocating_next_back` a bhith a` brùchdadh aig gach taobh den chraoibh, agus air an aon edge a bhualadh.
    /// Leis nach eilear an dùil a bhith air an gairm ach nuair a thèid na h-iuchraichean is luachan uile a thilleadh, cha tèid glanadh a dhèanamh air gin de na h-iuchraichean no luachan.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Gluais an làmh edge chun ath dhuilleag edge agus tillidh e iomraidhean air an iuchair agus an luach eatarra.
    ///
    ///
    /// # Safety
    /// Feumaidh KV eile a bhith san rathad a chaidh a shiubhal.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Gluais an làmh edge chun duilleach roimhe edge agus tillidh e iomraidhean air an iuchair agus an luach eatarra.
    ///
    ///
    /// # Safety
    /// Feumaidh KV eile a bhith san rathad a chaidh a shiubhal.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Gluais an làmh edge chun ath dhuilleag edge agus tillidh e iomraidhean air an iuchair agus an luach eatarra.
    ///
    ///
    /// # Safety
    /// Feumaidh KV eile a bhith san rathad a chaidh a shiubhal.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Tha a bhith a `dèanamh seo mu dheireadh nas luaithe, a rèir slatan-tomhais.
        kv.into_kv_valmut()
    }

    /// Gluais an làmh edge chun duilleach roimhe agus tillidh e iomraidhean air an iuchair agus an luach eatarra.
    ///
    ///
    /// # Safety
    /// Feumaidh KV eile a bhith san rathad a chaidh a shiubhal.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Tha a bhith a `dèanamh seo mu dheireadh nas luaithe, a rèir slatan-tomhais.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Gluais an làmh edge duilleach chun ath dhuilleag edge agus tillidh e an iuchair agus an luach eatarra, a `tuigsinn nodan sam bith a dh` fhàgas tu fhad `s a dh` fhàgas tu an edge co-fhreagarrach anns an nód pàrant aige a `crochadh.
    ///
    /// # Safety
    /// - Feumaidh KV eile a bhith san rathad a chaidh a shiubhal.
    /// - Cha deach an KV sin a thilleadh roimhe le counter `next_back_unchecked` air leth-bhreac sam bith de na làmhan a bhathar a `cleachdadh airson a dhol thairis air a` chraoibh.
    ///
    /// Is e an aon dhòigh sàbhailte air a dhol air adhart leis an làimhseachadh ùraichte a bhith ga choimeas, ga leigeil sìos, a `gairm an dòigh seo a-rithist le ùmhlachd do na cumhaichean sàbhailteachd aige, no cuir fios gu counter `next_back_unchecked` le ùmhlachd do na cumhaichean sàbhailteachd aige.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Gluais an làmh duilleach edge chun duilleach edge roimhe agus tillidh e an iuchair agus an luach eatarra, a `tuigsinn nodan sam bith a dh` fhàgas tu fhad `s a dh` fhàgas tu an edge co-fhreagarrach anns an nód pàrant aige a `crochadh.
    ///
    /// # Safety
    /// - Feumaidh KV eile a bhith san rathad a chaidh a shiubhal.
    /// - Cha deach an duilleag edge sin a thilleadh roimhe le counter `next_unchecked` air leth-bhreac sam bith de na làmhan a bhathar a `cleachdadh airson a dhol thairis air a` chraoibh.
    ///
    /// Is e an aon dhòigh sàbhailte air a dhol air adhart leis an làimhseachadh ùraichte a bhith ga choimeas, ga leigeil sìos, a `gairm an dòigh seo a-rithist le ùmhlachd do na cumhaichean sàbhailteachd aige, no cuir fios gu counter `next_unchecked` le ùmhlachd do na cumhaichean sàbhailteachd aige.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// A `tilleadh an duilleag as fhaide air falbh edge ann an no fo nód, ann am faclan eile, an edge a dh` fheumas tu an toiseach nuair a bhios tu a `seòladh air adhart (no mu dheireadh nuair a bhios tu a` seòladh air ais).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// A `tilleadh an duilleag as fheàrr edge ann an no fo nód, ann am faclan eile, an edge a dh` fheumas tu mu dheireadh nuair a bhios tu a `seòladh air adhart (no an toiseach nuair a bhios tu a` seòladh air ais).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// A `tadhal air nodan duilleach agus KVan a-staigh ann an òrdugh iuchraichean a tha a` dìreadh, agus cuideachd a `tadhal air nodan a-staigh gu h-iomlan ann an doimhneachd a` chiad òrdugh, a `ciallachadh gu bheil nodan a-staigh a` tighinn ro na KVan fa-leth agus na nodan cloinne aca.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Obraich a-mach an àireamh de eileamaidean ann an craobh (fo).
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// A `tilleadh an duilleag edge as fhaisge air KV airson seòladh air adhart.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// A `tilleadh an duilleag edge as fhaisge air KV airson seòladh air ais.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}