use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// A `cumail suas nód a dh` fhaodadh a bhith gu math tearc le bhith a `tighinn còmhla le no a` goid bho bràthair no piuthar.
    /// Ma shoirbhicheas leis ach aig cosgais a bhith a `crìonadh an nód pàrant, tillidh e an nód pàrant crùbach sin.
    /// A `tilleadh `Err` ma tha an nód na fhreumh falamh.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// A `cumail suas nód a dh` fhaodadh a bhith gu math gann, agus ma dh `adhbhraicheas sin an nód pàrant aige a` crìonadh, stocaidh e suas am pàrant, gu ath-chuairteachail.
    /// A `tilleadh `true` ma shuidhich e a` chraobh, `false` mura b `urrainn dhi oir dh` fhàs an nód freumh falamh.
    ///
    /// Chan eil an dòigh seo a `sùileachadh gum bi sinnsearan mar-thà gann mu inntrigeadh agus panics ma thachras e ri sinnsear falamh.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// A `toirt air falbh ìrean falamh air a` mhullach, ach a `cumail duilleag falamh ma tha a` chraobh gu lèir falamh.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// Stocan suas no cuir còmhla nodan fo-thalamh air crìoch cheart na craoibhe.
    /// Feumaidh na nodan eile, an fheadhainn nach eil nam freumh no edge as fheàrr, a bhith aig co-dhiù eileamaidean MIN_LEN mu thràth.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// An clon co-chothromach de `fix_right_border`.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// Stoc suas nodan fo-thalamh sam bith air crìoch cheart na craoibhe.
    /// Feumaidh na nodan eile, an fheadhainn nach eil nam freumh no edge as fheàrr, a bhith deiseil gus suas ri eileamaidean MIN_LEN a ghoid.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // Thoir sùil air a bheil am pàiste ceart gu leòr fo-aois.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // Feumaidh sinn goid.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // Gabh nas fhaide sìos.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// A `cumail suas a` phàiste chlì, a `gabhail ris nach eil an leanabh ceart fo aois, agus a` solarachadh eileamaid a bharrachd gus leigeil leis a `chlann aca aonachadh gun a bhith fo aois.
    ///
    /// A `tilleadh an leanabh clì.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` gus readjust a sheachnadh ma thachras aonachadh air an ath ìre.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// A `cumail suas a` phàiste cheart, a `gabhail ris nach eil an leanabh clì fo aois, agus a` solarachadh eileamaid a bharrachd gus leigeil leis a `chlann aca a thighinn còmhla gun a bhith fo aois.
    ///
    /// A `tilleadh ge bith càite an do chrìochnaich an leanabh ceart.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` gus readjust a sheachnadh ma thachras aonachadh air an ath ìre.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}