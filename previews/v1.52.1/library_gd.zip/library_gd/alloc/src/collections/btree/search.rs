use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Ceangal in-ghabhalach airson a bhith a `coimhead, dìreach mar `Bound::Included(T)`.
    Included(T),
    /// Ceangal toirmeasgach airson a bhith a `coimhead, dìreach mar `Bound::Excluded(T)`.
    Excluded(T),
    /// Ceangal in-ghabhaltach gun chumhachan, dìreach mar `Bound::Unbounded`.
    AllIncluded,
    /// Ceangal gun chumhachan.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// A `coimhead suas iuchair a chaidh a thoirt seachad ann an craobh (fo) le ceann an nód, gu ath-chuairteachail.
    /// A `tilleadh `Found` le làimhseachadh an KV maidsidh, ma tha sin ann.
    /// Rud eile, tillidh `GoDown` le làmh na duilleige edge far a bheil an iuchair.
    ///
    /// Tha an toradh brìoghmhor a-mhàin ma tha a `chraobh air òrdachadh le iuchair, mar a tha a` chraobh ann an `BTreeMap`.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// A `teàrnadh don nód as fhaisge far a bheil an edge a tha a` maidseadh crìoch nas ìsle an raoin eadar-dhealaichte bhon edge a `maidseadh an ceangal àrd, ie, an nód as fhaisge aig a bheil co-dhiù aon iuchair anns an raon.
    ///
    ///
    /// Ma lorgar e, tillidh e `Ok` leis an nód sin, bidh am paidhir de chlàran-amais edge ann a `toirt a-steach an raon, agus am paidhir chrìochan co-fhreagarrach airson leantainn air adhart leis an rannsachadh anns na nodan leanaibh, air eagal` s gu bheil an nód a-staigh.
    ///
    /// Mura lorgar e, tillidh e `Err` leis an duilleag edge a `maidseadh an raon gu lèir.
    ///
    /// Tha an toradh brìoghmhor a-mhàin ma tha a `chraobh air òrdachadh le iuchair.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Bu chòir a bhith a `seachnadh nan caochladairean sin.
        // Tha sinn a `gabhail ris gu bheil na crìochan a chaidh aithris le `range` a` fuireach mar a tha iad, ach dh `fhaodadh buileachadh nàimhdeil atharrachadh eadar gairmean (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// A `lorg edge anns an nód a` toirt a-steach crìoch ìosal raon.
    /// Cuideachd a `tilleadh an tè as ìsle a thèid a chleachdadh airson a bhith a` leantainn air adhart leis an rannsachadh anns a `nód leanaibh a tha a` maidseadh, ma tha `self` na nód a-staigh.
    ///
    ///
    /// Tha an toradh brìoghmhor a-mhàin ma tha a `chraobh air òrdachadh le iuchair.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Clone de `find_lower_bound_edge` airson a `cheangal àrd.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// A `coimhead suas iuchair shònraichte anns an nód, gun ath-chuairteachadh.
    /// A `tilleadh `Found` le làimhseachadh an KV maidsidh, ma tha sin ann.
    /// Rud eile, tillidh `GoDown` le làmh an edge far am faighear an iuchair (ma tha an nód a-staigh) no far an urrainnear an iuchair a chuir a-steach.
    ///
    ///
    /// Tha an toradh brìoghmhor a-mhàin ma tha a `chraobh air òrdachadh le iuchair, mar a tha a` chraobh ann an `BTreeMap`.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// A `tilleadh an dàrna cuid clàr-amais KV anns an nód aig a bheil an iuchair (no a leithid), no an clàr-amais edge far a bheil an iuchair.
    ///
    ///
    /// Tha an toradh brìoghmhor a-mhàin ma tha a `chraobh air òrdachadh le iuchair, mar a tha a` chraobh ann an `BTreeMap`.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// A `lorg clàr-amais edge anns an nód a` toirt a-steach crìoch nas ìsle de raon.
    /// Cuideachd a `tilleadh an tè as ìsle a thèid a chleachdadh airson a bhith a` leantainn air adhart leis an rannsachadh anns a `nód leanaibh a tha a` maidseadh, ma tha `self` na nód a-staigh.
    ///
    ///
    /// Tha an toradh brìoghmhor a-mhàin ma tha a `chraobh air òrdachadh le iuchair.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Clone de `find_lower_bound_index` airson a `cheangal àrd.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}