use core::intrinsics;
use core::mem;
use core::ptr;

/// Bidh seo a `dol an àite an luach air cùl iomradh sònraichte `v` le bhith a` gairm a `ghnìomh iomchaidh.
///
///
/// Ma thachras panic ann an dùnadh `change`, thèid casg a chuir air a `phròiseas air fad.
#[allow(dead_code)] // cùm mar dhealbh agus airson cleachdadh future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Tha seo an àite an luach air cùl an t-iomradh sònraichte `v` le bhith a `gairm a` ghnìomh iomchaidh, agus a `tilleadh toradh a fhuaireadh air an t-slighe.
///
///
/// Ma thachras panic ann an dùnadh `change`, thèid casg a chuir air a `phròiseas air fad.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}