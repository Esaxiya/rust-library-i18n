use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// A `cur a-steach a h-uile paidhir prìomh luach bhon aonadh de dhà itealaiche a tha a` dìreadh, ag àrdachadh caochladair `length` air an t-slighe.Tha an tè mu dheireadh ga dhèanamh nas fhasa don neach-fòn aodion a sheachnadh nuair a bhios neach-làimhseachaidh drop a `clisgeadh.
    ///
    /// Ma bheir an dà itealaiche an aon iuchair a-mach, bidh an dòigh seo a `leigeil sìos a` chàraid bhon iterator chlì agus a `ceangal a` chàraid bhon ite cheart.
    ///
    /// Ma tha thu airson gum bi a `chraobh a` tighinn gu crìch ann an òrdugh a tha a `dìreadh gu cruaidh, mar airson `BTreeMap`, bu chòir don dà itealaiche iuchraichean a thoirt a-mach ann an òrdugh a tha a` dìreadh gu cruaidh, gach fear nas motha na na h-iuchraichean uile sa chraoibh, a `toirt a-steach iuchraichean sam bith a tha sa chraoibh mu thràth nuair a thig thu a-steach.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Bidh sinn ag ullachadh gus `left` agus `right` a chur còmhla ann an sreath air an òrdachadh ann an ùine shreathach.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Aig an aon àm, bidh sinn a `togail craobh bhon t-sreath air a sheòrsachadh ann an ùine shreathach.
        self.bulk_push(iter, length)
    }

    /// A `putadh a h-uile paidhir prìomh luach gu deireadh na craoibhe, ag àrdachadh caochladair `length` air an t-slighe.
    /// Tha an tè mu dheireadh ga dhèanamh nas fhasa don neach-fòn aodion a sheachnadh nuair a bhios an iterator a `clisgeadh.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Iterate tro na paidhrichean prìomh luach uile, gan putadh gu nodan aig an ìre cheart.
        for (key, value) in iter {
            // Feuch ri paidhir prìomh luach a phutadh a-steach don nód duilleach gnàthach.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Chan eil àite air fhàgail, theirig suas agus brùth an sin.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Lorg nòd le àite air fhàgail, brùth an seo.
                                open_node = parent;
                                break;
                            } else {
                                // Rach suas a-rithist.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Tha sinn aig a `mhullach, a` cruthachadh nód freumh ùr agus a `putadh an sin.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Brùth paidhir luach-iuchrach agus fo-thiotal ceart ùr.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Gabh sìos chun duilleach as motha a-rithist.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Meudaich fad gach iteachaidh, gus dèanamh cinnteach gu bheil am mapa a `leigeil sìos na h-eileamaidean ceangailte eadhon ged a bhios iad a` toirt air adhart clisgeadh an iterator.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Reultair airson dà shreath a sheòrsachadh ann an aon
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Ma tha dà iuchair co-ionann, till am paidhir luach-iuchrach bhon stòr cheart.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}