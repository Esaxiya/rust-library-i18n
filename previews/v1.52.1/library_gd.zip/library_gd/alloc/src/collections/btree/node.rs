// Is e seo oidhirp air buileachadh a `leantainn air leth freagarrach
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Leis nach eil seòrsaichean eisimeileach agus ath-chuairteachadh polymorphic aig Rust, bidh sinn a `dèanamh tòrr de mhì-shàbhailteachd.
//

// Is e prìomh amas a `mhodal seo iom-fhillteachd a sheachnadh le bhith a` làimhseachadh na craoibhe mar stuth coitcheann (ma tha cumadh neònach oirre) agus a `seachnadh dèiligeadh ris a` mhòr-chuid de na h-invariants B-Tree.
//
// Mar sin, chan eil dragh aig a `mhodal seo a bheil na h-inntrigidhean air an òrdachadh, dè na nodan a dh` fhaodas a bhith gann, no eadhon dè tha fo-sgrìobhadh a `ciallachadh.Ach, tha sinn an urra ri corra ionnsaigh:
//
// - Feumaidh craobhan a bhith èideadh depth/height.Tha seo a `ciallachadh gu bheil an aon fhaid aig a h-uile slighe sìos gu duilleag bho nód a chaidh a thoirt seachad.
// - Tha nód de dh'fhaid `n` le iuchraichean `n`, luachan `n`, agus oirean `n + 1`.
//   Tha seo a `ciallachadh gu bheil co-dhiù aon edge aig eadhon nód falamh.
//   Airson nód duille, tha "having an edge" a-mhàin a `ciallachadh gun urrainn dhuinn suidheachadh a chomharrachadh anns an nód, leis gu bheil oirean duille falamh agus nach eil feum air riochdachadh dàta.
// Ann an nód a-staigh, tha edge an dà chuid a `comharrachadh suidheachadh agus a` toirt a-steach comharradh gu nód leanaibh.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// An riochdachadh bunaiteach de nodan duille agus pàirt de riochdachadh nodan a-staigh.
struct LeafNode<K, V> {
    /// Tha sinn airson a bhith covariant ann an `K` agus `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Clàr-amais an nód seo a-steach do raon `edges` an nód pàrant.
    /// `*node.parent.edges[node.parent_idx]` bu chòir an aon rud a bhith ann ri `node`.
    /// Chan eilear a `gealltainn seo a thòiseachadh nuair a tha `parent` neo-null.
    parent_idx: MaybeUninit<u16>,

    /// An àireamh de iuchraichean agus luachan a tha an nód seo a `stòradh.
    len: u16,

    /// Na h-arrays a bhios a `stòradh dàta fìor an nód.
    /// Chan eil ach a `chiad eileamaidean `len` de gach sreath air an tòiseachadh agus dligheach.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// A `tòiseachadh `LeafNode` ùr na àite.
    unsafe fn init(this: *mut Self) {
        // Mar phoileasaidh coitcheann, bidh sinn a `fàgail raointean gun aithneachadh ma dh` fhaodas iad a bhith, oir bu chòir seo a bhith an dà chuid beagan nas luaithe agus nas fhasa a lorg ann an Valgrind.
        //
        unsafe {
            // tha parent_idx, iuchraichean, agus vals uile MayUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// A `cruthachadh bogsa ùr `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// An riochdachadh bunaiteach de nodan a-staigh.Coltach ri `LeafNode`s, bu chòir iad sin a bhith falaichte air cùl`BoxedNode`s gus casg a chuir air iuchraichean agus luachan neo-aithnichte.
/// Faodar puing sam bith gu `InternalNode` a thionndadh gu dìreach gu puing chun a `phàirt `LeafNode` a tha fon nód, a` leigeil le còd obrachadh air nodan duilleach is a-staigh gu gnèitheach gun eadhon a bhith cinnteach dè an dà rud a tha puing a `comharrachadh.
///
/// Tha an togalach seo air a chomasachadh le bhith a `cleachdadh `repr(C)`.
///
#[repr(C)]
// gdb_providers.py a `cleachdadh an seòrsa ainm seo airson introspection.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Molaidhean do chlann an nód seo.
    /// `len + 1` tha cuid dhiubh sin air am meas mar thùs agus dligheach, ach a-mhàin faisg air an deireadh, fhad `s a tha a` chraobh air a cumail tro iasad seòrsa `Dying`, tha cuid de na puingean sin a `crochadh.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// A `cruthachadh bogsa ùr `InternalNode`.
    ///
    /// # Safety
    /// Is e invariant de nodan a-staigh gu bheil co-dhiù aon edge tùsail agus dligheach aca.
    /// Chan eil an gnìomh seo a `stèidheachadh a leithid de edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Cha leig sinn a leas ach an dàta a thòiseachadh;tha na h-oirean mayUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Puing stiùirichte, neo-null gu nód.Tha seo an dàrna cuid na chomharraiche seilbh gu `LeafNode<K, V>` no na chomharraiche seilbh gu `InternalNode<K, V>`.
///
/// Ach, chan eil fiosrachadh ann an `BoxedNode` a thaobh dè an dà sheòrsa nod a th `ann, agus, gu ìre air sgàth an dìth fiosrachaidh seo, chan eil e na sheòrsa air leth agus chan eil sgrios ann.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Nòd freumh craobh seilbh.
///
/// Thoir fa-near nach eil inneal-sgriosaidh ann, agus feumar a ghlanadh le làimh.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// A `tilleadh craobh ùr le seilbh, le a nód freumh fhèin a tha falamh an toiseach.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` chan fhaod e a bhith neoni.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Bidh e gu mòr a `faighinn iasad den nód freumh aig a bheil seilbh.
    /// Eu-coltach ri `reborrow_mut`, tha seo sàbhailte oir chan urrainnear an luach toraidh a chleachdadh gus am freumh a sgrios, agus chan urrainnear iomradh eile a thoirt air a `chraoibh.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Beag air bheag bidh e a `faighinn iasad den nód freumh aig a bheil seilbh.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Eadar-ghluasad gu h-iongantach gu iomradh a cheadaicheas traversal agus a tha a `tabhann dhòighean millteach agus glè bheag eile.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Cuir nòd ùr a-staigh le aon edge a `comharrachadh an nód freumh a bh` ann roimhe, dèan an nód ùr sin an nód freumh, agus thoir air ais e.
    /// Tha seo a `meudachadh na h-àirde le 1 agus tha e an aghaidh `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, ach gu bheil sinn dìreach air dìochuimhneachadh gu bheil sinn a-staigh a-nis:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// A `toirt air falbh an nód freumh a-staigh, a` cleachdadh a `chiad leanabh aige mar an nód freumh ùr.
    /// Mar a thathar an dùil a bhith air a ghairm nuair nach eil ach aon leanabh aig an nód root, chan eil glanadh air a dhèanamh air gin de na h-iuchraichean, luachan agus clann eile.
    ///
    /// Tha seo a `lughdachadh na h-àirde le 1 agus tha e an aghaidh `push_internal_level`.
    ///
    /// A dh `fheumas ruigsinneachd toirmeasgach air an nì `Root` ach chan ann air a` nód root;
    /// cha chuir e làmhan no iomraidhean eile air a `nód root ann an dòigh neo-dhligheach.
    ///
    /// Panics mura h-eil ìre a-staigh ann, ie, mas e duilleag a th `anns a` nód root.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SÀBHAILTEACHD: dhearbh sinn a bhith a-staigh.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SÀBHAILTEACHD: fhuair sinn iasad de `self` a-mhàin agus tha an seòrsa iasad aige toirmeasgach.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SÀBHAILTEACHD: tha a `chiad edge an-còmhnaidh air a thòiseachadh.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. Tha `NodeRef` an-còmhnaidh covariant ann an `K` agus `V`, eadhon nuair a tha an `BorrowType` `Mut`.
// Tha seo ceàrr gu teicnigeach, ach chan urrainn dha mì-shàbhailteachd sam bith adhbhrachadh mar thoradh air cleachdadh taobh a-staigh `NodeRef` oir tha sinn a `fuireach gu tur coitcheann thairis air `K` agus `V`.
//
// Ach, gach uair a bhios seòrsa poblach a `pasgadh `NodeRef`, dèan cinnteach gu bheil an eadar-dhealachadh ceart aige.
//
/// Iomradh air nód.
///
/// Tha grunn pharaimearan aig an seòrsa seo a bhios a `cumail smachd air mar a bhios e ag obair:
/// - `BorrowType`: Seòrsa duilich a tha a `toirt cunntas air an t-seòrsa iasad agus a` giùlan beatha.
///    - Nuair a tha seo `Immut<'a>`, tha an `NodeRef` ag obair an ìre mhath mar `&'a Node`.
///    - Nuair is e `ValMut<'a>` a tha seo, tha an `NodeRef` ag obair an ìre mhath mar `&'a Node` a thaobh iuchraichean agus structar craoibhe, ach tha e cuideachd a `leigeil le mòran iomraidhean caochlaideach mu luachan air feadh na craoibhe a bhith a` fuireach còmhla.
///    - Nuair is e seo `Mut<'a>`, tha an `NodeRef` ag obair an ìre mhath mar `&'a mut Node`, ged a tha modhan cuir a-steach a `leigeil le puing gluasadach luach a bhith a` fuireach còmhla.
///    - Nuair a tha seo `Owned`, tha an `NodeRef` ag obair an ìre mhath mar `Box<Node>`, ach chan eil inneal-sgrios ann, agus feumar a ghlanadh le làimh.
///    - Nuair is e seo `Dying`, tha an `NodeRef` fhathast ag obair an ìre mhath mar `Box<Node>`, ach tha dòighean aige a `chraobh a sgrios beag air bheag, agus faodaidh dòighean àbhaisteach, ged nach eil iad air an comharrachadh mar neo-shàbhailte a bhith a` gairm, ionnsaigh a thoirt air UB ma thèid a ghairm gu ceàrr.
///
///   Leis gu bheil `NodeRef` sam bith a `ceadachadh seòladh tron chraoibh, tha `BorrowType` gu h-èifeachdach a` buntainn ris a `chraoibh gu lèir, chan ann a-mhàin ris an nód fhèin.
/// - `K` agus `V`: Is iad seo na seòrsaichean iuchraichean agus luachan a tha air an stòradh anns na nodan.
/// - `Type`: Faodaidh seo a bhith `Leaf`, `Internal`, no `LeafOrInternal`.
/// Nuair a tha seo `Leaf`, tha an `NodeRef` a `comharrachadh nodan duille, nuair a tha seo `Internal` tha an `NodeRef` a` comharrachadh gu nód a-staigh, agus nuair a tha seo `LeafOrInternal` dh `fhaodadh an `NodeRef` a bhith a` comharrachadh gach seòrsa nód.
///   `Type` ainmeachadh `NodeType` nuair a thèid a chleachdadh taobh a-muigh `NodeRef`.
///
/// Bidh an dà chuid `BorrowType` agus `NodeType` a `cuingealachadh dè na modhan a bhios sinn a` cur an gnìomh, gus brath a ghabhail air sàbhailteachd seòrsa statach.Tha cuingealachaidhean ann air an dòigh as urrainn dhuinn a leithid de chuingealachaidhean a chuir an gnìomh:
/// - Airson gach paramadair seòrsa, chan urrainn dhuinn ach dòigh a mhìneachadh gu gnèitheach no airson aon seòrsa sònraichte.
/// Mar eisimpleir, chan urrainn dhuinn dòigh mar `into_kv` a mhìneachadh gu coitcheann airson a h-uile `BorrowType`, no aon uair airson gach seòrsa a tha a `giùlan beatha, oir tha sinn airson gun till e iomraidhean `&'a`.
///   Mar sin, bidh sinn ga mhìneachadh a-mhàin airson an seòrsa `Immut<'a>` as cumhachdaiche.
/// - Chan urrainn dhuinn co-èigneachadh so-thuigsinn fhaighinn bho ràdh `Mut<'a>` gu `Immut<'a>`.
///   Mar sin, feumaidh sinn `reborrow` a ghairm gu sònraichte air `NodeRef` nas cumhachdaiche gus modh mar `into_kv` a ruighinn.
///
/// A h-uile modh air `NodeRef` a thilleas cuid de sheòrsa iomraidh, an dàrna cuid:
/// - Gabh `self` a rèir luach, agus till am beatha air a ghiùlan le `BorrowType`.
///   Aig amannan, gus a leithid de dhòigh-obrach a ghairm, feumaidh sinn `reborrow_mut` a ghairm.
/// - Gabh `self` le iomradh, agus tillidh (implicitly) beatha an t-iomradh sin, an àite an ùine-beatha a tha `BorrowType` a `giùlan.
/// San dòigh sin, tha an neach-dearbhaidh iasad a `gealltainn gum fuirich an `NodeRef` air iasad fhad` s a thèid an iomradh air ais a chleachdadh.
///   Bidh na modhan a tha a `toirt taic do chuir a-steach a` lùbadh an riaghailt seo le bhith a `tilleadh stiùireadh amh, ie, iomradh gun bheatha sam bith.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Tha an àireamh de ìrean a tha an nód agus ìre nan duilleagan bho chèile, seasmhach den nód nach urrainn a mhìneachadh gu h-iomlan le `Type`, agus nach eil an nód fhèin a `stòradh.
    /// Cha leig sinn a leas ach àirde a `nód root a stòradh, agus àirde gach nód eile fhaighinn bhuaithe.
    /// Feumaidh a bhith neoni ma tha `Type` `Leaf` agus neo-neoni ma tha `Type` `Internal`.
    ///
    ///
    height: usize,
    /// A `phuing chun duilleach no nód a-staigh.
    /// Tha mìneachadh `InternalNode` a `dèanamh cinnteach gu bheil am puing dligheach gach taobh.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Unpack iomradh nód a chaidh a phacaigeadh mar `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// A `nochdadh dàta de nód a-staigh.
    ///
    /// A `tilleadh ptr amh gus nach cuir thu iomraidhean eile air an nód seo gu neo-dhligheach.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SÀBHAILTEACHD: is e `Internal` an seòrsa nód statach.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// A `faighinn cothrom air dàta bho nód a-staigh.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// A `lorg fad an nód.Is e seo an àireamh de iuchraichean no luachan.
    /// Is e an àireamh oirean `len() + 1`.
    /// Thoir fa-near, a dh `aindeoin a bhith sàbhailte, faodaidh a bhith a` gairm an gnìomh seo an taobh-bhuaidh bho bhith a `cuir an cèill iomraidhean mutable a chruthaich còd neo-shàbhailte.
    ///
    pub fn len(&self) -> usize {
        // Gu deatamach, chan fhaigh sinn a-steach ach air raon `len` an seo.
        // Mas e marker::ValMut a th `ann am BorrowType, is dòcha gu bheil iomraidhean suaicheanta air luachan nach fheum sinn a dhligheachadh.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// A `tilleadh an àireamh de ìrean a tha an nód agus na duilleagan bho chèile.
    /// Tha àirde neoni a `ciallachadh gur e duilleag fhèin a th` anns an nód.
    /// Ma tha thu a `dèanamh dealbh de chraobhan leis an fhreumh air a` mhullach, tha an àireamh ag ràdh aig dè an àirde a nochdas an nód.
    /// Ma chì thu craobhan le duilleagan air am muin, tha an àireamh ag ràdh cho àrd sa tha a `chraobh a` leudachadh os cionn an nód.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Bidh sealach a `toirt a-mach iomradh so-ruigsinneach eile air an aon nód.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// A `nochdadh cuibhreann duilleach de dhuilleag no nód a-staigh.
    ///
    /// A `tilleadh ptr amh gus nach cuir thu iomraidhean eile air an nód seo gu neo-dhligheach.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Feumaidh an nód a bhith dligheach airson cuibhreann LeafNode co-dhiù.
        // Chan e seo iomradh san t-seòrsa NodeRef oir chan eil fios againn am bu chòir dha a bhith gun samhail no air a roinneadh.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Lorg pàrant an nód gnàthach.
    /// A `tilleadh `Ok(handle)` ma tha pàrant aig an nód gnàthach, far a bheil `handle` a` comharrachadh edge a `phàrant a tha a` comharrachadh an nód gnàthach.
    ///
    /// A `tilleadh `Err(self)` mura h-eil pàrant aig an nód gnàthach, a` toirt air ais an `NodeRef` tùsail.
    ///
    /// Tha ainm a `mhodh a` gabhail ris gum bi thu a `dèanamh dhealbhan de chraobhan leis a` nód root air a `mhullach.
    ///
    /// `edge.descend().ascend().unwrap()` agus cha bu chòir `node.ascend().unwrap().descend()` an dà chuid, nuair a shoirbhicheas leotha, dad a dhèanamh.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Feumaidh sinn molaidhean amh a chleachdadh airson nodan oir, ma tha BorrowType marker::ValMut, is dòcha gum bi iomraidhean suaicheanta air luachan nach fheum sinn a bhith neo-dhligheach.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Thoir fa-near gum feum `self` a bhith gun adhbhar.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Thoir fa-near gum feum `self` a bhith gun adhbhar.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// A `nochdadh cuibhreann duilleach de dhuilleag no nód a-staigh ann an craobh do-ruigsinneach.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SÀBHAILTEACHD: chan urrainnear iomradh sam bith a thoirt air a `chraoibh seo air iasad mar `Immut`.
        unsafe { &*ptr }
    }

    /// A `faighinn sealladh air iasad a-steach do na h-iuchraichean a tha air an stòradh san nód.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Coltach ri `ascend`, a `faighinn iomradh air nód pàrant nód, ach bidh e cuideachd a` tuigsinn an nód gnàthach sa phròiseas.
    /// Tha seo cunnartach oir bidh an nód gnàthach fhathast ruigsinneach a dh `aindeoin gu bheil e air a thuigsinn.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Tha mì-shàbhailte a `dearbhadh don neach-cruinneachaidh am fiosrachadh statach gur e `Leaf` an nód seo.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Tha mì-shàbhailte a `dearbhadh don neach-cruinneachaidh am fiosrachadh statach gur e `Internal` an nód seo.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Bidh sealach a `toirt a-mach iomradh eile, gluasadach air an aon nód.Thoir an aire, oir tha an dòigh seo gu math cunnartach, gu dùbailte oir is dòcha nach bi e a`nochdadh cunnartach sa bhad.
    ///
    /// Leis gum faod comharran gluasadach gluasad gu àite sam bith timcheall air a `chraoibh, tha e furasta an comharraiche a thilleadh a chleachdadh gus am bi am puing tùsail a` crochadh, a-mach à crìochan, no neo-dhligheach fo riaghailtean iasaid cruachan.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) smaoinich air paramadair seòrsa eile a chuir ri `NodeRef` a tha a `cuingealachadh cleachdadh dhòighean seòlaidh air molaidhean ath-thionndaidh, a` cur casg air an neo-shàbhailteachd seo.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Bidh iasad a `faighinn cothrom air cuibhreann duilleach de dhuilleag no nód a-staigh sam bith.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SÀBHAILTEACHD: tha cothrom sònraichte againn air an nód gu lèir.
        unsafe { &mut *ptr }
    }

    /// A `tairgse ruigsinneachd gun chead air cuibhreann duilleach de dhuilleag no nód a-staigh.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SÀBHAILTEACHD: tha cothrom sònraichte againn air an nód gu lèir.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// A `faighinn cothrom air iasad air pàirt den phrìomh raon stòraidh.
    ///
    /// # Safety
    /// `index` ann an crìochan 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SÀBHAILTEACHD: cha bhith e comasach don neach-fios tuilleadh dhòighean a ghairm air fhèin
        // gus an tèid prìomh iomradh na sliseag a leigeil seachad, leis gu bheil cothrom sònraichte againn airson beatha an iasaid.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// A `faighinn a-mach ruigsinneachd air leth air eileamaid no sliseag de raon stòraidh luach an nód.
    ///
    /// # Safety
    /// `index` ann an crìochan 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SÀBHAILTEACHD: cha bhith e comasach don neach-fios tuilleadh dhòighean a ghairm air fhèin
        // gus an tèid an iomradh sliseag luach a leigeil sìos, leis gu bheil cothrom sònraichte againn airson beatha an iasaid.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// A `faighinn a-mach ruigsinneachd air leth air eileamaid no sliseag de raon stòraidh an nód airson susbaint edge.
    ///
    /// # Safety
    /// `index` ann an crìochan 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SÀBHAILTEACHD: cha bhith e comasach don neach-fios tuilleadh dhòighean a ghairm air fhèin
        // gus an tèid an iomradh sliseag edge a leigeil sìos, leis gu bheil cothrom sònraichte againn airson beatha an iasaid.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Tha barrachd air eileamaidean tùsail `idx` aig an nód.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Cha bhith sinn a `cruthachadh ach iomradh air an aon eileamaid anns a bheil ùidh againn, gus a bhith a` seachnadh co-thaobhadh le iomraidhean sònraichte mu eileamaidean eile, gu sònraichte, an fheadhainn a thilleas chun neach-fios ann an aithrisean nas tràithe.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Feumaidh sinn coerce gu molaidhean eagar neo-aonaichte air sgàth Rust issue #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// A `faighinn cothrom air iasad de fhad an nód.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// A `suidheachadh ceangal an nód ris a phàrant edge, gun a bhith a` cur iomraidhean eile ris an nód gu neo-dhligheach.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// A `glanadh ceangal na freumh ris a phàrant edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Cuir paidhir prìomh luach gu deireadh an nód.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Tha a h-uile rud a thill `range` na chlàr-amais dligheach edge airson an nód.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Cuir paidhir luach-iuchrach, agus edge ri dhol air taobh deas na paidhir sin, gu deireadh an nód.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// A `dèanamh cinnteach an e nód `Internal` no nód `Leaf` a th` ann an nód.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Iomradh air paidhir luach sònraichte sònraichte no edge taobh a-staigh nód.
/// Feumaidh am paramadair `Node` a bhith na `NodeRef`, agus faodaidh an `Type` a bhith an dàrna cuid `KV` (a `comharrachadh làmh air paidhir prìomh luach) no `Edge` (a` comharrachadh làmh air edge).
///
/// Thoir fa-near gum faod làmhan `Edge` a bhith aig eadhon nodan `Leaf`.
/// An àite a bhith a `riochdachadh comharradh gu nód leanaibh, tha iad sin a` riochdachadh na h-àiteachan far am biodh comharran-cloinne a `dol eadar na paidhrichean prìomh luach.
/// Mar eisimpleir, ann an nód le fad 2, bhiodh 3 àiteachan edge comasach, aon air taobh clì an nód, aon eadar an dà phaidhir, agus aon air taobh deas an nód.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Chan fheum sinn làn-choitcheann `#[derive(Clone)]`, oir is e an aon uair a bhios `Node` `Clone` nuair a tha e na iomradh so-ruigsinneach agus mar sin `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// A `faighinn air ais an nód anns a bheil am paidhir edge no prìomh luach a tha an làimhseachadh seo a` comharrachadh.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// A `tilleadh suidheachadh an làimhseachaidh seo anns an nód.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// A `cruthachadh làmh ùr gu paidhir prìomh luach ann an `node`.
    /// Neo-shàbhailte oir feumaidh an neach-fòn dèanamh cinnteach gu bheil `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Dh `fhaodadh seo a bhith na bhuileachadh poblach air PartialEq, ach air a chleachdadh sa mhodal seo a-mhàin.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Bidh sealach a `toirt a-mach grèim eile nach gabh gluasad air an aon àite.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Chan urrainn dhuinn Handle::new_kv no Handle::new_edge a chleachdadh oir chan eil fios againn dè an seòrsa a th `ann
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Tha mì-shàbhailte a `dearbhadh don neach-cruinneachaidh am fiosrachadh statach gur e `Leaf` a th` ann an nód an làimhseachaidh.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Bidh sealach a `toirt a-mach grèim eile, gluasadach san aon àite.
    /// Thoir an aire, oir tha an dòigh seo gu math cunnartach, gu dùbailte oir is dòcha nach bi e a `nochdadh cunnartach sa bhad.
    ///
    ///
    /// Airson mion-fhiosrachadh, faic `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Chan urrainn dhuinn Handle::new_kv no Handle::new_edge a chleachdadh oir chan eil fios againn dè an seòrsa a th `ann
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// A `cruthachadh làmh ùr gu edge ann an `node`.
    /// Neo-shàbhailte oir feumaidh an neach-fòn dèanamh cinnteach gu bheil `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// A `toirt seachad clàr-amais edge far a bheil sinn airson cuir a-steach do nód air a lìonadh gu comas, a` dèanamh clàr-amais KV ciallach de phuing sgoltadh agus far an cuir thu a-steach e.
///
/// Is e amas a `phuing sgoltadh gum bi an iuchair agus an luach aige a` tighinn gu crìch ann an nód pàrant;
/// bidh na h-iuchraichean, na luachan agus na h-oirean air taobh clì a `phuing sgoltadh gu bhith nan leanabh clì;
/// bidh na h-iuchraichean, na luachan agus na h-oirean air taobh deas a `phuing sgoltadh gu bhith nan leanabh ceart.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Bidh Rust issue #74834 a `feuchainn ris na riaghailtean co-chothromach seo a mhìneachadh.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Cuir a-steach paidhir luach-iuchrach ùr eadar na paidhrichean luach-iuchrach air taobh deas agus clì an edge seo.
    /// Tha an dòigh seo a `gabhail ris gu bheil àite gu leòr anns an nód airson am paidhir ùr a bhith iomchaidh.
    ///
    /// Tha am puing a chaidh a thilleadh a `comharrachadh an luach a chaidh a chuir a-steach.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Cuir a-steach paidhir luach-iuchrach ùr eadar na paidhrichean luach-iuchrach air taobh deas agus clì an edge seo.
    /// Bidh an dòigh seo a `cuairteachadh an nód mura h-eil àite gu leòr ann.
    ///
    /// Tha am puing a chaidh a thilleadh a `comharrachadh an luach a chaidh a chuir a-steach.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Ceartaich am pàrant agus an clàr-amais anns a `nód leanaibh ris a bheil an edge seo a` ceangal.
    /// Tha seo feumail nuair a thèid òrdugh oirean atharrachadh,
    fn correct_parent_link(self) {
        // Cruthaich backpointer gun a bhith a `toirt iomradh air iomraidhean eile air an nód.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Cuir a-steach paidhir luach-iuchrach ùr agus edge a thèid air taobh deas na paidhir ùr sin eadar an edge seo agus am paidhir luach-iuchrach air taobh deas an edge seo.
    /// Tha an dòigh seo a `gabhail ris gu bheil àite gu leòr anns an nód airson am paidhir ùr a bhith iomchaidh.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Cuir a-steach paidhir luach-iuchrach ùr agus edge a thèid air taobh deas na paidhir ùr sin eadar an edge seo agus am paidhir luach-iuchrach air taobh deas an edge seo.
    /// Bidh an dòigh seo a `cuairteachadh an nód mura h-eil àite gu leòr ann.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Cuir a-steach paidhir luach-iuchrach ùr eadar na paidhrichean luach-iuchrach air taobh deas agus clì an edge seo.
    /// Bidh an dòigh seo a `cuairteachadh an nód mura h-eil àite gu leòr ann, agus a` feuchainn ris a `chuibhreann roinnte a chuir a-steach don nód pàrant gu ath-chuairteachadh, gus an ruigear am freumh.
    ///
    ///
    /// Mas e `Fit` an toradh a chaidh a thilleadh, faodaidh nód an làimhseachaidh a bhith mar nód edge no sinnsear.
    /// Mas e `Split` an toradh a chaidh a thilleadh, bidh an raon `left` mar bhun-nód.
    /// Tha am puing a chaidh a thilleadh a `comharrachadh an luach a chaidh a chuir a-steach.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Lorgar an nód air a bheil an edge seo a `toirt iomradh.
    ///
    /// Tha ainm a `mhodh a` gabhail ris gum bi thu a `dèanamh dhealbhan de chraobhan leis a` nód root air a `mhullach.
    ///
    /// `edge.descend().ascend().unwrap()` agus cha bu chòir `node.ascend().unwrap().descend()` an dà chuid, nuair a shoirbhicheas leotha, dad a dhèanamh.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Feumaidh sinn molaidhean amh a chleachdadh airson nodan oir, ma tha BorrowType marker::ValMut, is dòcha gum bi iomraidhean suaicheanta air luachan nach fheum sinn a bhith neo-dhligheach.
        // Chan eil dragh sam bith ann a bhith a `faighinn cothrom air an raon àirde oir tha an luach sin air a chopaigeadh.
        // Thoir an aire, aon uair `s gu bheil am puing node air a dhì-chlàradh, gum faigh sinn cothrom air na h-oirean le iomradh (Rust issue #73987) agus gun cuir thu iomradh sam bith eile air no taobh a-staigh na sreath, ma tha gin ann.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Chan urrainn dhuinn prìomh dhòighean agus luach air leth a ghairm, oir tha a bhith a `gairm an dàrna fear neo-dhligheach an iomradh a thill a` chiad fhear.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Cuir an àite an iuchair agus an luach air a bheil an làimhseachadh KV a `toirt iomradh.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// A `cuideachadh le bhith a` buileachadh `split` airson `NodeType` sònraichte, le bhith a `gabhail cùram de dhàta duilleach.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// A `cuairteachadh an nód bunaiteach ann an trì pàirtean:
    ///
    /// - Tha an nód air a theàrnadh gus nach bi ann ach na paidhrichean prìomh luach air taobh clì an làimhseachaidh seo.
    /// - Tha an iuchair agus an luach air a bheil an làmh seo a `toirt iomradh.
    /// - Tha na paidhrichean prìomh luach air taobh deas an làimhseachaidh seo air an cur ann an nód ùr-riaraichte.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Thoir air falbh am paidhir luach-iuchrach air an do chomharraich an làmh seo agus till e air ais, còmhla ris an edge a thuit am paidhir luach-iuchrach a-steach.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// A `cuairteachadh an nód bunaiteach ann an trì pàirtean:
    ///
    /// - Tha an nód air a theàrnadh gus nach bi ann ach na h-oirean agus na paidhrichean luach-iuchrach air taobh clì an làimhseachaidh seo.
    /// - Tha an iuchair agus an luach air a bheil an làmh seo a `toirt iomradh.
    /// - A h-uile h-oirean agus prìomh-luach an càraidean air an làimh dheis den seo a làmh a chur a-steach às ùr air a riarachadh node.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// A `riochdachadh seisean airson a bhith a` luachadh agus a `coileanadh gnìomhachd cothromachaidh timcheall air paidhir prìomh luach a-staigh.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// A `taghadh co-theacs cothromachaidh a` toirt a-steach an nód mar phàiste, mar sin eadar an KV sa bhad air an taobh chlì no air an taobh dheas anns a `nód phàrant.
    /// A `tilleadh `Err` mura h-eil pàrant ann.
    /// Panics ma tha am pàrant falamh.
    ///
    /// B `fheàrr leis an taobh chlì, a bhith cho math ma tha an nód a chaidh a thoirt seachad ann an dòigh air choreigin, a` ciallachadh an seo a-mhàin gu bheil nas lugha de eileamaidean aige na am bràthair no an taobh chlì agus na bràthair no piuthar cheart, ma tha iad ann.
    /// Anns a `chùis sin, bidh aonachadh leis an sibling chlì nas luaithe, oir chan fheum sinn ach eileamaidean N an nód a ghluasad, an àite a bhith gan gluasad chun taobh cheart agus a` gluasad barrachd air eileamaidean N air beulaibh.
    /// Tha a bhith a `goid bho na peathraichean clì cuideachd mar as trice nas luaithe, oir chan fheum sinn ach eileamaidean N an nód a ghluasad chun taobh cheart, an àite a bhith a` gluasad co-dhiù N de na h-eileamaidean bràthar gu clì.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// A `tilleadh a bheil e comasach aonachadh a dhèanamh, ie, a bheil rùm gu leòr ann an nód gus an KV meadhanach a thoirt còmhla leis an dà nod leanaibh a tha faisg air làimh.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// A `dèanamh aonachadh agus a` leigeil le dùnadh co-dhùnadh dè a thilleas.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SÀBHAILTEACHD: tha àirde nan nodan a tha air an aonachadh nas ìsle na an àirde
                // den nód den edge seo, mar sin os cionn neoni, agus mar sin tha iad a-staigh.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// A `tighinn còmhla ri paidhir luach-iuchrach a` phàrant agus an dà nod leanaibh faisg air làimh a-steach don nód leanaibh chlì agus a `tilleadh an nód pàrant shrunk.
    ///
    ///
    /// Panics mura dèan sinn `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// A `tighinn còmhla ri paidhir luach-iuchrach a` phàrant agus an dà nod leanaibh faisg air làimh a-steach don nód leanaibh chlì agus a `tilleadh an nód leanaibh sin.
    ///
    ///
    /// Panics mura dèan sinn `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// A `tighinn còmhla ri paidhir luach-iuchrach a` phàrant agus an dà nod leanaibh faisg air làimh a-steach don nód leanaibh chlì agus a `tilleadh an làmh edge anns an nód leanaibh sin far an do chrìochnaich an leanabh rianail edge,
    ///
    ///
    /// Panics mura dèan sinn `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Thoir air falbh paidhir prìomh luach bhon phàiste chlì agus cuir e ann an stòradh prìomh luach a `phàrant, fhad` s a tha e a `putadh seann phaidhir luach prìomh phàrant a-steach don phàiste cheart.
    ///
    /// A `tilleadh làmh chun edge anns a` phàiste cheart a rèir far an tàinig an edge tùsail a chaidh a shònrachadh le `track_right_edge_idx` gu crìch.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Thoir air falbh paidhir prìomh luach bhon phàiste cheart agus cuir e ann an stòr prìomh luach a `phàrant, fhad` s a tha e a `putadh seann phaidhir luach prìomh phàrant air a` phàiste chlì.
    ///
    /// A `tilleadh làmh chun edge anns a` phàiste chlì a chaidh a shònrachadh le `track_left_edge_idx`, nach do ghluais.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Bidh seo a `goid coltach ri `steal_left` ach a` goid grunn eileamaidean aig an aon àm.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Dèan cinnteach gun goid sinn gu sàbhailte.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Gluais dàta duille.
            {
                // Dèan rùm airson eileamaidean air an goid anns a `phàiste cheart.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Gluais eileamaidean bhon phàiste chlì chun fhear cheart.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Gluais am paidhir as fhaide air falbh chun phàrant.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Gluais paidhir prìomh luach pàrant chun leanabh ceart.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Dèan rùm airson oirean a chaidh a ghoid.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Stiùir oirean.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// An clon co-chothromach de `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Dèan cinnteach gun goid sinn gu sàbhailte.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Gluais dàta duille.
            {
                // Gluais am paidhir as còir air a ghoid chun phàrant.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Gluais paidhir prìomh luach pàrant chun leanabh chlì.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Gluais eileamaidean bhon phàiste cheart chun an taobh chlì.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Lìon beàrn far am b `àbhaist eileamaidean a chaidh a ghoid a bhith.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Stiùir oirean.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Lìon beàrn far am b `àbhaist oirean a chaidh a ghoid.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// A `toirt air falbh fiosrachadh statach sam bith a tha ag ràdh gur e nód `Leaf` a tha san nód seo.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// A `toirt air falbh fiosrachadh statach sam bith a tha ag ràdh gur e nód `Internal` a tha san nód seo.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// A `dèanamh cinnteach an e nód `Internal` no nód `Leaf` an nód bunaiteach.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Gluais an iar-leasachan às deidh `self` bho aon nód gu fear eile.Feumaidh `right` a bhith falamh.
    /// Tha a `chiad edge de `right` fhathast gun atharrachadh.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Toradh cuir a-steach, nuair a dh `fheumadh nód leudachadh nas fhaide na a chomas.
pub struct SplitResult<'a, K, V, NodeType> {
    // Nòd atharraichte sa chraobh a th `ann le eileamaidean agus oirean a bhuineas don taobh chlì de `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Tha cuid de iuchair agus luach air an sgaradh, airson an cuir a-steach ann an àite eile.
    pub kv: (K, V),
    // Nòd ùr seilbh, neo-cheangailte, le eileamaidean agus oirean a bhuineas don taobh cheart de `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Co-dhiù a tha iomraidhean nodan den t-seòrsa iasad seo a `ceadachadh gluasad thairis gu nodan eile sa chraoibh.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal Chan eil needede, tha e a 'cleachdadh a' tachairt mar thoradh air `borrow_mut`.
        // Le bhith a `dì-chomasachadh traversal, agus dìreach a` cruthachadh iomraidhean ùra air freumhaichean, tha fios againn gu bheil a h-uile iomradh den t-seòrsa `Owned` gu nód freumh.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Cuir a-steach luach ann an sliseag de eileamaidean tùsail le aon eileamaid neo-aithnichte an uairsin.
///
/// # Safety
/// Tha barrachd air eileamaidean `idx` aig an t-slice.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// A `toirt air falbh agus a` toirt air ais luach bho sliseag de na h-eileamaidean tùsail uile, a `fàgail às deidh aon eileamaid gun fhiosta.
///
///
/// # Safety
/// Tha barrachd air eileamaidean `idx` aig an t-slice.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Gluais na h-eileamaidean ann an suidheachadh sliseag `distance` air an taobh chlì.
///
/// # Safety
/// Tha co-dhiù eileamaidean `distance` aig an slice.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Gluais na h-eileamaidean ann an suidheachadh sliseag `distance` air an taobh cheart.
///
/// # Safety
/// Tha co-dhiù eileamaidean `distance` aig an slice.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Gluais a h-uile luach bho sliseag de eileamaidean tùsail gu sliseag de eileamaidean neo-aithnichte, a `fàgail às deidh `src` mar a h-uile dad neo-aithnichte.
///
/// Ag obair mar `dst.copy_from_slice(src)` ach chan fheum `T` a bhith `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;