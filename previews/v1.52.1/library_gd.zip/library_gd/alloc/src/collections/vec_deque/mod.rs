//! Ciudha le dà cheann air a chuir an gnìomh le bufair fàinne a ghabhas fàs.
//!
//! Anns a `chiudha seo tha cuir a-steach agus toirt air falbh *O*(1) bho gach ceann den t-soitheach.
//! Tha clàr-amais *O*(1) aige cuideachd mar vector.
//! Chan fheum na h-eileamaidean a tha ann an lethbhreac a dhèanamh, agus thèid an ciudha a chuir air falbh ma tha an seòrsa a tha na bhroinn air a chuir air falbh.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Cumhachd as motha de dhà

/// Ciudha le dà cheann air a chuir an gnìomh le bufair fàinne a ghabhas fàs.
///
/// Is e cleachdadh "default" den t-seòrsa seo mar ciudha [`push_back`] a chleachdadh gus cuir ris a `chiudha, agus [`pop_front`] gus a thoirt air falbh bhon ciudha.
///
/// [`extend`] agus [`append`] a `putadh air a` chùl san dòigh seo, agus ag itealaich thairis air `VecDeque` a `dol aghaidh ri aghaidh.
///
/// Leis gur e bufair fàinne a th `ann an `VecDeque`, is dòcha nach eil na h-eileamaidean aige ceangailte ri cuimhne.
/// Ma tha thu airson faighinn gu na h-eileamaidean mar aon sliseag, mar airson a sheòrsachadh gu h-èifeachdach, faodaidh tu [`make_contiguous`] a chleachdadh.
/// Bidh e a `cuairteachadh an `VecDeque` gus nach bi na h-eileamaidean aige a` fighe, agus a `tilleadh sliseag shiùbhlach gu sreath nan eileamaidean a tha a-nis dlùth.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // tha earball agus ceann nan comharran a-steach don bhufair.
    // Bidh earball an-còmhnaidh a `comharrachadh a` chiad eileamaid a dh `fhaodadh a leughadh, tha an Ceann an-còmhnaidh a` comharrachadh far am bu chòir dàta a sgrìobhadh.
    //
    // Ma tha earball==ceann tha am bufair falamh.Tha fad an ringbuffer air a mhìneachadh mar an astar eadar an dà rud.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// A `ruith an inneal-sgrios airson a h-uile rud san t-sliseag nuair a thèid a leigeil sìos (mar as trice no aig àm gun fhiosta).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // cleachd drop airson [T]
            ptr::drop_in_place(front);
        }
        // Bidh RawVec a `làimhseachadh tuigseocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// A `cruthachadh `VecDeque<T>` falamh.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Marginally nas goireasaiche
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Marginally nas goireasaiche
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Airson seòrsachan meud neoni, tha sinn an-còmhnaidh aig a `chomas as motha
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Tionndaidh ptr gu sliseag
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Tionndaidh ptr gu sliseag mut
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Gluais eileamaid a-mach às an bufair
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// A `sgrìobhadh eileamaid a-steach don bhufair, ga ghluasad.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// A `tilleadh `true` ma tha am bufair aig làn chomas.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Tillidh e an clàr-amais anns a `bhufair bhunasach airson clàr-amais eileamaidean loidsigeach sònraichte.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Tillidh e an clàr-amais anns a `bhufair bhunasach airson clàr-amais eileamaidean loidsigeach + addend.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Tillidh e an clàr-amais anns a `bhufair bhunasach airson clàr-amais eileamaidean loidsigeach sònraichte, subtrahend.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// A `dèanamh lethbhreac de bhloc cuimhne faisg air làimh bho src gu dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// A `dèanamh lethbhreac de bhloc cuimhne faisg air làimh bho src gu dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// A `dèanamh lethbhreac de bhloc cuimhne a dh` fhaodadh a bhith fada bho src gu dest.
    /// (abs(dst - src) chan fhaod + len) a bhith nas motha na cap() (Feumaidh co-dhiù aon sgìre leantainneach a bhith a `dol thairis air eadar src agus dest).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // Cha bhith src a `pasgadh, cha bhith dst a` pasgadh
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst ro src, cha bhith src a `pasgadh, dst wraps
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src ro dst, cha bhith src a `pasgadh, dst wraps
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst ro src, src wraps, cha bhith dst a `pasgadh
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src mus dst, src wraps, dst no wrap
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst ro src, src wraps, dst wraps
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src ro dst, src wraps, dst wraps
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Frobs na h-earrannan ceann agus earball timcheall gus a bhith a `làimhseachadh an fhìrinn gu bheil sinn dìreach air ath-riarachadh.
    /// Neo-shàbhailte oir tha earbsa aige ann an old_capacity.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Gluais an earrann faisg air làimh den bhufair fàinne TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // A Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// A `cruthachadh `VecDeque` falamh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// A `cruthachadh `VecDeque` falamh le àite airson co-dhiù eileamaidean `capacity`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 leis gu bheil an ringbuffer an-còmhnaidh a `fàgail aon àite falamh
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// A `toirt iomradh air an eileamaid aig a` chlàr-innse a chaidh a thoirt seachad.
    ///
    /// Is e eileamaid aig clàr-amais 0 aghaidh a `chiudha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// A `toirt seachad iomradh gluasadach air an eileamaid aig a` chlàr-innse a chaidh a thoirt seachad.
    ///
    /// Is e eileamaid aig clàr-amais 0 aghaidh a `chiudha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// A `dèanamh iomlaid air eileamaidean aig clàran-amais `i` agus `j`.
    ///
    /// `i` agus is dòcha gum bi `j` co-ionann.
    ///
    /// Is e eileamaid aig clàr-amais 0 aghaidh a `chiudha.
    ///
    /// # Panics
    ///
    /// Panics ma tha an dàrna clàr-amais taobh a-muigh crìochan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// A `tilleadh an àireamh de eileamaidean a dh` fhaodas an `VecDeque` a chumail gun ath-riarachadh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// A `glèidheadh a` chomais as lugha airson dìreach `additional` barrachd eileamaidean a chuir a-steach san `VecDeque` a chaidh a thoirt seachad.
    /// A `dèanamh dad ma tha an comas gu leòr mar-thà.
    ///
    /// Thoir fa-near gum faod an neach-riarachaidh barrachd àite a thoirt don chruinneachadh na tha e ag iarraidh.
    /// Mar sin chan urrainnear a bhith an urra ri comas a bhith fìor bheag.
    /// B `fheàrr le [`reserve`] ma tha dùil ri cuir a-steach future.
    ///
    /// # Panics
    ///
    /// Panics ma tha an comas ùr a `dol thairis air `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// A `gleidheadh comas airson co-dhiù `additional` barrachd eileamaidean a chuir a-steach san `VecDeque` a chaidh a thoirt seachad.
    /// Is dòcha gun glèidh an cruinneachadh barrachd àite gus ath-riarachadh tric a sheachnadh.
    ///
    /// # Panics
    ///
    /// Panics ma tha an comas ùr a `dol thairis air `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// A `feuchainn ris a` chomas as lugha a ghleidheadh airson dìreach `additional` barrachd eileamaidean a chuir a-steach san `VecDeque<T>` a chaidh a thoirt seachad.
    ///
    /// Às deidh `try_reserve_exact` a ghairm, bidh comas nas motha na no co-ionann ri `self.len() + additional`.
    /// A `dèanamh dad ma tha an comas gu leòr mar-thà.
    ///
    /// Thoir fa-near gum faod an neach-riarachaidh barrachd àite a thoirt don chruinneachadh na tha e ag iarraidh.
    /// Mar sin, chan urrainnear a bhith an urra ri comas a bhith fìor bheag.
    /// B `fheàrr le `reserve` ma tha dùil ri cuir a-steach future.
    ///
    /// # Errors
    ///
    /// Ma tha an comas a `dol thairis air `usize`, no ma tha an neach-riarachaidh ag aithris air fàiligeadh, thèid mearachd a thilleadh.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Glèidh a `chuimhne ro-làimh, a` falbh mura h-urrainn dhuinn
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // A-nis tha fios againn nach urrainn seo OOM(Out-Of-Memory) a dhèanamh ann am meadhan ar n-obair iom-fhillte
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // gu math toinnte
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// A `feuchainn ri comas a ghlèidheadh airson co-dhiù `additional` barrachd eileamaidean a chuir a-steach san `VecDeque<T>` a chaidh a thoirt seachad.
    /// Is dòcha gun glèidh an cruinneachadh barrachd àite gus ath-riarachadh tric a sheachnadh.
    /// Às deidh `try_reserve` a ghairm, bidh comas nas motha na no co-ionann ri `self.len() + additional`.
    /// A `dèanamh dad ma tha comas gu leòr mar-thà.
    ///
    /// # Errors
    ///
    /// Ma tha an comas a `dol thairis air `usize`, no ma tha an neach-riarachaidh ag aithris air fàiligeadh, thèid mearachd a thilleadh.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Glèidh a `chuimhne ro-làimh, a` falbh mura h-urrainn dhuinn
    ///     output.try_reserve(data.len())?;
    ///
    ///     // A-nis tha fios againn nach urrainn seo OOM a dhèanamh ann am meadhan ar n-obair iom-fhillte
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // gu math toinnte
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// A `lughdachadh comas an `VecDeque` cho mòr` s a ghabhas.
    ///
    /// Bidh e a `tuiteam sìos cho faisg` s as urrainn don fhad ach is dòcha gum bi an neach-sònrachaidh fhathast ag innse don `VecDeque` gu bheil àite ann airson beagan a bharrachd eileamaidean.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// A `lughdachadh comas an `VecDeque` le crìoch nas ìsle.
    ///
    /// Bidh an comas co-dhiù cho mòr ris an dà chuid an fhaid agus an luach a chaidh a thoirt seachad.
    ///
    ///
    /// Ma tha an comas làithreach nas ìsle na an ìre as ìsle, is e neo-op a tha seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Cha leig sinn a leas dragh a ghabhail mu thar-shruth oir chan urrainn dha `self.len()` no `self.capacity()` a bhith `usize::MAX` a-riamh.
        // +1 oir bidh an ringbuffer an-còmhnaidh a `fàgail aon àite falamh.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Tha trì cùisean inntinneach:
            //   Tha na h-eileamaidean uile a-mach às na crìochan a tha a dhìth Tha eileamaidean faisg air a chèile, agus tha an ceann a-mach às na crìochan a tha a dhìth
            //
            //
            // Aig a h-uile àm eile, chan eil buaidh air suidheachadh eileamaidean.
            //
            // A `nochdadh gum bu chòir eileamaidean aig a` cheann a ghluasad.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Gluais eileamaidean bho na crìochan a tha thu ag iarraidh (dreuchdan às deidh target_cap)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// A `giorrachadh an `VecDeque`, a` cumail a `chiad eileamaidean `len` agus a` leigeil às a `chòrr.
    ///
    ///
    /// Ma tha `len` nas motha na fad làithreach an `VecDeque`, chan eil buaidh sam bith aig seo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// A `ruith an inneal-sgrios airson a h-uile rud san t-sliseag nuair a thèid a leigeil sìos (mar as trice no aig àm gun fhiosta).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Sàbhailte oir:
        //
        // * Tha sliseag sam bith a chaidh a thoirt do `drop_in_place` dligheach;tha `len <= front.len()` aig an dàrna cùis agus tha tilleadh air `len > self.len()` a `dèanamh cinnteach gu bheil `begin <= back.len()` sa chiad chùis
        //
        // * Tha ceann an VecDeque air a ghluasad mus gairm e `drop_in_place`, agus mar sin chan eil luach air a leigeil sìos dà uair ma tha `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Dèan cinnteach gu bheil an dàrna leth air a leigeil fiù 's nuair a destructor anns a' chiad aon panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// A `tilleadh itealadair aghaidh-ri-cùl.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// A `tilleadh itealaiche aghaidh ri aghaidh a thilleas iomraidhean gluasadach.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // SÀBHAILTEACHD: Tha an invariant sàbhailteachd `IterMut` a-staigh air a stèidheachadh leis gu bheil an
        // `ring` bidh sinn a `cruthachadh sliseag dereferencable fad beatha` _.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// A `tilleadh paidhir sliseagan anns a bheil, ann an òrdugh, susbaint an `VecDeque`.
    ///
    /// Ma chaidh [`make_contiguous`] a ghairm roimhe, bidh a h-uile eileamaid den `VecDeque` anns a `chiad sliseag agus bidh an dàrna sliseag falamh.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// A `tilleadh paidhir sliseagan anns a bheil, ann an òrdugh, susbaint an `VecDeque`.
    ///
    /// Ma chaidh [`make_contiguous`] a ghairm roimhe, bidh a h-uile eileamaid den `VecDeque` anns a `chiad sliseag agus bidh an dàrna sliseag falamh.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// A `tilleadh àireamh nan eileamaidean anns an `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// A `tilleadh `true` ma tha an `VecDeque` falamh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// A `cruthachadh iterator a tha a` còmhdach an raon ainmichte san `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics ma tha an t-àite tòiseachaidh nas motha na a `phuing crìochnachaidh no ma tha an t-àite crìochnachaidh nas motha na fad an vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Tha làn raon a `còmhdach gach susbaint
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Tha an iomradh co-roinnte a th `againn ann an &self air a chumail suas anns an` _ of Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// A `cruthachadh iterator a tha a` còmhdach an raon ainmichte mutable anns an `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics ma tha an t-àite tòiseachaidh nas motha na a `phuing crìochnachaidh no ma tha an t-àite crìochnachaidh nas motha na fad an vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Tha làn raon a `còmhdach gach susbaint
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // SÀBHAILTEACHD: Tha an invariant sàbhailteachd `IterMut` a-staigh air a stèidheachadh leis gu bheil an
        // `ring` bidh sinn a `cruthachadh sliseag dereferencable fad beatha` _.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// A `cruthachadh itealadair drèanaidh a bheir air falbh an raon ainmichte san `VecDeque` agus a bheir toradh de na nithean a chaidh a thoirt air falbh.
    ///
    /// Nota 1: Thèid an raon eileamaid a thoirt air falbh eadhon ged nach eilear ag ithe an iterator gu deireadh.
    ///
    /// Nota 2: Tha e neo-shònraichte cia mheud eileamaid a thèid a thoirt a-mach às an deic, mura tèid luach `Drain` a leigeil sìos, ach thig an iasad a tha e a `tighinn gu crìch (me, air sgàth `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics ma tha an t-àite tòiseachaidh nas motha na a `phuing crìochnachaidh no ma tha an t-àite crìochnachaidh nas motha na fad an vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Bidh làn raon a `glanadh a h-uile susbaint
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Sàbhailteachd cuimhne
        //
        // Nuair a thèid an Drain a chruthachadh an toiseach, tha an stòr stòr air a ghiorrachadh gus dèanamh cinnteach nach fhaighear eileamaidean neo-aithnichte no gluasad bho rud sam bith mura faigh an sgriosadair Drain a-riamh ruith.
        //
        //
        // Bheir Drain ptr::read a-mach na luachan airson an toirt air falbh.
        // Nuair a bhios e deiseil, thèid an dàta a tha air fhàgail a chopaigeadh air ais gus an toll a chòmhdach, agus thèid na luachan head/tail ath-nuadhachadh gu ceart.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Tha eileamaidean an deque air an roinn ann an trì roinnean:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // Bidh sinn a `stòradh drain_tail mar self.head, agus drain_head agus self.head mar after_tail agus after_head fa leth air an Drain.
        // Bidh seo cuideachd a `briseadh an raon èifeachdach mar sin ma thèid an Drain a leigeil a-mach, dhìochuimhnich sinn mu na luachan a dh` fhaodadh a bhith air an gluasad às deidh toiseach an drain.
        //
        //
        //        T th H.
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" mu na luachan às deidh toiseach an drain gus an tèid an drain a chrìochnachadh agus an inneal-sgrios Drain a ruith.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Gu deatamach, cha bhith sinn a `cruthachadh ach iomraidhean co-roinnte bho `self` an seo agus leugh sinn bhuaithe.
                // Cha bhith sinn a `sgrìobhadh gu `self` no a` dol air ais gu iomradh gluasadach.
                // Mar sin tha am puing amh a chruthaich sinn gu h-àrd, airson `deque`, fhathast dligheach.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// A `glanadh an `VecDeque`, a` toirt air falbh a h-uile luach.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// A `tilleadh `true` ma tha eileamaid anns an `VecDeque` a tha co-ionann ris an luach a chaidh a thoirt seachad.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// A `toirt iomradh air an eileamaid aghaidh, no `None` ma tha an `VecDeque` falamh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// A `toirt seachad iomradh gluasadach air an eileamaid aghaidh, no `None` ma tha an `VecDeque` falamh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// A `toirt iomradh air an eileamaid chùil, no `None` ma tha an `VecDeque` falamh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// A `toirt seachad iomradh gluasadach air an eileamaid chùil, no `None` ma tha an `VecDeque` falamh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Thoir air falbh a `chiad eileamaid agus till e air ais, no `None` ma tha an `VecDeque` falamh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Thoir air falbh an eileamaid mu dheireadh bhon `VecDeque` agus till e, no `None` ma tha e falamh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// A `caitheamh eileamaid ris an `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// A `cur eileamaid ri cùl an `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Am bu chòir dhuinn beachdachadh air `head == 0` a bhith a `ciallachadh
        // gu bheil `self` faisg air làimh?
        self.tail <= self.head
    }

    /// Thoir air falbh eileamaid bho àite sam bith san `VecDeque` agus till e air ais, a `cur a` chiad eileamaid na àite.
    ///
    ///
    /// Chan eil seo a `gleidheadh òrdachadh, ach tha e *O*(1).
    ///
    /// A `tilleadh `None` ma tha `index` a-mach à crìochan.
    ///
    /// Is e eileamaid aig clàr-amais 0 aghaidh a `chiudha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Thoir air falbh eileamaid bho àite sam bith san `VecDeque` agus till e air ais, a `cur an eileamaid mu dheireadh na àite.
    ///
    ///
    /// Chan eil seo a `gleidheadh òrdachadh, ach tha e *O*(1).
    ///
    /// A `tilleadh `None` ma tha `index` a-mach à crìochan.
    ///
    /// Is e eileamaid aig clàr-amais 0 aghaidh a `chiudha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Cuir a-steach eileamaid aig `index` taobh a-staigh an `VecDeque`, a `gluasad a h-uile eileamaid le clàran-amais nas motha na no co-ionann ri `index` a dh` ionnsaigh a `chùil.
    ///
    ///
    /// Is e eileamaid aig clàr-amais 0 aghaidh a `chiudha.
    ///
    /// # Panics
    ///
    /// Panics ma tha `index` nas motha na fad `VecDeque`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Gluais an àireamh as lugha de na h-eileamaidean anns a `bhufair fàinne agus cuir a-steach an rud a chaidh a thoirt seachad
        //
        // Aig a `char as motha len/2, thèid 1 eileamaid a ghluasad. O(min(n, n-i))
        //
        // Tha trì prìomh chùisean ann:
        //  Tha eileamaidean ceangailte ri chèile
        //      - cùis shònraichte nuair a tha earball 0 Tha eileamaidean mì-shoilleir agus tha an cuir a-steach ann an roinn an earbaill Tha eileamaidean diofraichte agus tha an cuir a-steach ann an roinn a `chinn
        //
        //
        // Airson gach aon dhiubh sin tha dà chùis a bharrachd:
        //  Tha cuir a-steach nas fhaisge air earball Tha cuir a-steach nas fhaisge air a cheann
        //
        // Prìomh: H, self.head
        //      T, self.tail o, Eileamaid dhligheach I, Cuir a-steach eileamaid A, An eileamaid a bu chòir a bhith às deidh a `phuing cuir a-steach M, A` comharrachadh gun deach an eileamaid a ghluasad
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [A oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // co-shìnte, cuir a-steach nas fhaisge air an earball:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // co-shìnte, cuir a-steach nas fhaisge air earball agus earball 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // A `gluasad an earbaill mu thràth, agus mar sin cha bhith sinn a` dèanamh ach leth-bhreac de eileamaidean `index - 1`.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // co-shìnte, cuir a-steach nas fhaisge air a `cheann:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, cuir a-steach nas fhaisge air earball, roinn earball:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, cuir a-steach nas fhaisge air ceann, roinn earball:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // copaidh eileamaidean suas gu ceann ùr
                    self.copy(1, 0, self.head);

                    // dèan lethbhreac den eileamaid mu dheireadh gu àite falamh aig bonn a `bhufair
                    self.copy(0, self.cap() - 1, 1);

                    // gluais eileamaidean bho idx gu deireadh air adhart gun a bhith a `toirt a-steach ^ eileamaid
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // discontiguous, cuir a-steach nas fhaisge air earball, roinn ceann, agus tha e aig clàr-amais neoni anns a `bhufair a-staigh:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // copaidh eileamaidean suas gu earball ùr
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // dèan lethbhreac den eileamaid mu dheireadh gu àite falamh aig bonn a `bhufair
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontiguous, cuir a-steach nas fhaisge air earball, roinn ceann:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // copaidh eileamaidean suas gu earball ùr
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // dèan lethbhreac den eileamaid mu dheireadh gu àite falamh aig bonn a `bhufair
                    self.copy(self.cap() - 1, 0, 1);

                    // gluais eileamaidean bho idx-1 gus crìoch a chuir air adhart gun a bhith a `toirt a-steach ^ eileamaid
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, cuir a-steach nas fhaisge air ceann, roinn ceann:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // is dòcha gun deach earball atharrachadh agus mar sin feumaidh sinn ath-chuairteachadh
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// A `toirt air falbh agus a` tilleadh an eileamaid aig `index` bhon `VecDeque`.
    /// Ge bith dè an ceann as fhaisge air a `phuing gluasaid thèid a ghluasad gus rùm a dhèanamh, agus thèid na h-eileamaidean air fad air a bheil buaidh a ghluasad gu dreuchdan ùra.
    ///
    /// A `tilleadh `None` ma tha `index` a-mach à crìochan.
    ///
    /// Is e eileamaid aig clàr-amais 0 aghaidh a `chiudha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Tha trì prìomh chùisean ann:
        //  Tha eileamaidean co-shìnte Tha eileamaidean eadar-dhealaichte agus tha an toirt air falbh ann an roinn an earbaill Tha eileamaidean eadar-dhealaichte agus tha an toirt air falbh anns a `phrìomh cheann
        //
        //      - cùis sònraichte nuair a tha eileamaidean ceangailte gu teicnigeach, ach self.head =0
        //
        // Airson gach aon dhiubh sin tha dà chùis a bharrachd:
        //  Tha cuir a-steach nas fhaisge air earball Tha cuir a-steach nas fhaisge air a cheann
        //
        // Prìomh: H, self.head
        //      T, self.tail o, Eileamaid dligheach x, Eileamaid air a chomharrachadh airson toirt air falbh R, A `comharrachadh eileamaid a thathar a` toirt air falbh M, A `comharrachadh gun deach an eileamaid a ghluasad
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // co-shìnte, thoir air falbh nas fhaisge air an earball:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // co-shìnte, thoir air falbh nas fhaisge air do cheann:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, cuir air falbh nas fhaisge air earball, roinn earball:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, cuir air falbh nas fhaisge air ceann, roinn ceann:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, thoir air falbh nas fhaisge air ceann, roinn earball:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // no leth-mhì-shoilleir, thoir air falbh ri taobh ceann, earball:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // tarraing a-steach eileamaidean ann an roinn an earbaill
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // A `cur casg air fo-shruth.
                    if self.head != 0 {
                        // dèan lethbhreac den chiad eileamaid gu àite falamh
                        self.copy(self.cap() - 1, 0, 1);

                        // gluais eileamaidean ann an roinn a `chinn air ais
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontiguous, cuir air falbh nas fhaisge air earball, roinn ceann:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // tarraing a-steach eileamaidean suas gu idx
                    self.copy(1, 0, idx);

                    // dèan lethbhreac den eileamaid mu dheireadh gu àite falamh
                    self.copy(0, self.cap() - 1, 1);

                    // gluais eileamaidean bho earball gu deireadh air adhart, ach an tè mu dheireadh
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Roinn an `VecDeque` gu dhà aig a `chlàr-innse a chaidh a thoirt seachad.
    ///
    /// A `tilleadh `VecDeque` a chaidh a riarachadh às ùr.
    /// `self` tha eileamaidean `[0, at)` ann, agus tha eileamaidean `[at, len)` anns an `VecDeque` a chaidh a thilleadh.
    ///
    /// Thoir fa-near nach atharraich comas `self`.
    ///
    /// Is e eileamaid aig clàr-amais 0 aghaidh a `chiudha.
    ///
    /// # Panics
    ///
    /// Panics ma tha `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` na laighe sa chiad leth.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // dìreach gabh an dàrna leth.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` na laighe san dàrna leth, feumar feart a thoirt air na h-eileamaidean a leum sinn sa chiad leth.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Glanadh far a bheil cinn nam bufairean
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Gluais na h-eileamaidean `other` gu `self`, a `fàgail `other` falamh.
    ///
    /// # Panics
    ///
    /// Panics ma tha an àireamh ùr de eileamaidean ann fhèin a `dol thairis air `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // naive impl
        self.extend(other.drain(..));
    }

    /// A `gleidheadh dìreach na h-eileamaidean a tha air an comharrachadh leis an predicate.
    ///
    /// Ann am faclan eile, cuir às do na h-eileamaidean `e` gu lèir gus am bi `f(&e)` a `tilleadh meallta.
    /// Bidh an dòigh seo ag obair na àite, a `tadhal air gach eileamaid dìreach aon uair san òrdugh thùsail, agus a` gleidheadh òrdugh nan eileamaidean glèidhte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Is dòcha gum bi an dearbh òrdugh feumail airson sùil a chumail air stàite a-muigh, mar chlàr-amais.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Faodaidh seo panic no giorrachadh
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Dèan dà uiread de mheud bufair.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Atharraich an `VecDeque` na àite gus am bi `len()` co-ionann ri `new_len`, an dàrna cuid le bhith a `toirt air falbh cus eileamaidean bhon chùl no le bhith a` cur a-steach eileamaidean a chaidh a chruthachadh le bhith a `gairm `generator` air a` chùl.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// A `rèiteachadh stòradh a-staigh na deic seo gus am bi e na aon sliseag ri thaobh, a thillear an uairsin.
    ///
    /// Chan eil an dòigh seo a `riarachadh agus chan eil e ag atharrachadh òrdugh nan eileamaidean a chaidh a chuir a-steach.Mar a thilleas e sliseag gluasadach, faodar seo a chleachdadh gus deque a sheòrsachadh.
    ///
    /// Cho luath `s a bhios an stòradh a-staigh faisg air làimh, tillidh na modhan [`as_slices`] agus [`as_mut_slices`] susbaint iomlan an `VecDeque` ann an aon sliseag.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// A `rèiteachadh susbaint deque.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // a `rèiteach an deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // a sheòrsachadh ann an òrdugh eile
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// A `faighinn ruigsinneachd so-ruigsinneach don t-sliseag ri thaobh.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // faodaidh sinn a-nis a bhith cinnteach gu bheil a h-uile eileamaid den deic ann an `slice`, fhad `s a tha e fhathast a` faighinn cothrom do-ruigsinneach air `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // tha àite gu leòr an-asgaidh airson an earball a chopaigeadh aig aon àm, tha seo a `ciallachadh gun gluais sinn an ceann air ais, agus an uairsin lethbhreac a dhèanamh den earball chun t-suidheachadh cheart.
            //
            //
            // bho: DEFGH .... ABC
            // gu: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Chan eil sinn a `beachdachadh air an-dràsta .... ABCDEFGH
            // a bhith dlùth ri chèile oir bhiodh `head` mar `0` sa chùis seo.
            // Ged is dòcha gu bheil sinn airson seo atharrachadh chan eil e idir duilich oir tha beagan àiteachan an dùil gum bi `is_contiguous` a `ciallachadh gun urrainn dhuinn dìreach sleamhnachadh le bhith a` cleachdadh `buf[tail..head]`.
            //
            //

            // tha àite gu leòr an-asgaidh airson an ceann a chopaigeadh aig aon àm, tha seo a `ciallachadh gun gluais sinn an earball air adhart an toiseach, agus an uairsin lethbhreac a dhèanamh den cheann chun t-suidheachadh cheart.
            //
            //
            // bho: FGH .... ABCDE
            // gu: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // tha an-asgaidh nas lugha na an dà chuid ceann agus earball, tha seo a `ciallachadh gum feum sinn "swap" an earball agus an ceann a thoirt gu slaodach.
            //
            //
            // bho: EFGHI ... ABCD no HIJK.ABCDEFG
            // gu: ABCDEFGHI ... no ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Tha an duilgheadas coitcheann a `coimhead mar an GHIJKLM seo ... ABCDEF, mus dèanar iomlaid sam bith ABCDEFM ... GHIJKL, às deidh 1 pas de suaipichean ABCDEFGHIJM ... KL, iomlaid gus an ruig an edge clì an stòr temp
                //                  - an uairsin ath-thòiseachadh an algorithm le stòr (smaller) ùr Uaireannan ruigear an stòr temp nuair a tha an edge ceart aig deireadh a `bhufair, tha seo a` ciallachadh gu bheil sinn air an òrdugh cheart a bhualadh le nas lugha de suaipean!
                //
                // E.g
                // EF..ABCD ABCDEF .., às deidh ceithir iomlaid a-mhàin tha sinn deiseil
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// A `tionndadh na h-àiteachan ciudha dà-fhillte `mid` air an taobh chlì.
    ///
    /// Equivalently,
    /// - A `tionndadh nì `mid` a-steach don chiad shuidheachadh.
    /// - Pops a `chiad nithean `mid` agus brùth iad chun deireadh.
    /// - A `tionndadh àiteachan `len() - mid` air an taobh cheart.
    ///
    /// # Panics
    ///
    /// Ma tha `mid` nas motha na `len()`.
    /// Thoir fa-near gu bheil `mid == len()` a `dèanamh _not_ panic agus gur e cuairteachadh no-op a th` ann.
    ///
    /// # Complexity
    ///
    /// A `toirt ùine `*O*(min(mid, len() - mid))` agus gun àite a bharrachd.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// A `tionndadh na h-àiteachan ciudha dà-fhillte `k` air an taobh cheart.
    ///
    /// Equivalently,
    /// - Rothaich a `chiad rud gu suidheachadh `k`.
    /// - Pops na nithean `k` mu dheireadh agus gam putadh chun aghaidh.
    /// - A `tionndadh àiteachan `len() - k` air an taobh chlì.
    ///
    /// # Panics
    ///
    /// Ma tha `k` nas motha na `len()`.
    /// Thoir fa-near gu bheil `k == len()` a `dèanamh _not_ panic agus gur e cuairteachadh no-op a th` ann.
    ///
    /// # Complexity
    ///
    /// A `toirt ùine `*O*(min(k, len() - k))` agus gun àite a bharrachd.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // SÀBHAILTEACHD: tha an dà dhòigh a leanas ag iarraidh gum bi an tomhas cuairteachaidh
    // a bhith nas lugha na leth faid an deic.
    //
    // `wrap_copy` ag iarraidh gum bi `min(x, cap() - x) + copy_len <= cap()`, ach na `min` a-riamh nas motha na leth a `chomais, ge bith dè x, mar sin tha e fuaim a bhith a` gairm an seo oir tha sinn a `gairm le rudeigin nas lugha na leth an fhaid, nach eil a-riamh os cionn leth a` chomais.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Bidh Binary a `dèanamh sgrùdadh air an `VecDeque` seo a chaidh a sheòrsachadh airson eileamaid sònraichte.
    ///
    /// Ma lorgar an luach tha [`Result::Ok`] air a thilleadh, anns a bheil clàr-amais an eileamaid maidsidh.
    /// Ma tha grunn gheamannan ann, dh `fhaodadh aon de na maidsean a thilleadh.
    /// Mura lorgar an luach tha [`Result::Err`] air a thilleadh, anns a bheil an clàr-amais far an gabhadh eileamaid maidsidh a chuir a-steach fhad `s a bha e a` cumail òrdugh ann an òrdugh.
    ///
    ///
    /// # Examples
    ///
    /// A `coimhead suas sreath de cheithir eileamaidean.
    /// Lorgar a `chiad fhear, le suidheachadh air a dhearbhadh gu sònraichte;cha lorgar an dàrna agus an treas fear;dh'fhaodadh an ceathramh suidheachadh sam bith a cho-fhreagairt ann an `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Ma tha thu airson rud a chuir a-steach gu `VecDeque` air a sheòrsachadh, fhad `s a chumas tu òrdugh òrdugh:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Bidh Binary a `dèanamh sgrùdadh air an `VecDeque` seo a chaidh a sheòrsachadh le gnìomh coimeasach.
    ///
    /// Bu chòir don ghnìomh coimeasach òrdugh a chuir an gnìomh a tha a rèir òrdugh seòrsa an `VecDeque` bunaiteach, a `tilleadh còd òrduigh a tha a` nochdadh an e an argamaid aige `Less`, `Equal` no `Greater` na an targaid a tha thu ag iarraidh.
    ///
    ///
    /// Ma lorgar an luach tha [`Result::Ok`] air a thilleadh, anns a bheil clàr-amais an eileamaid maidsidh.Ma tha grunn gheamannan ann, dh `fhaodadh aon de na maidsean a thilleadh.
    /// Mura lorgar an luach tha [`Result::Err`] air a thilleadh, anns a bheil an clàr-amais far an gabhadh eileamaid maidsidh a chuir a-steach fhad `s a bha e a` cumail òrdugh ann an òrdugh.
    ///
    /// # Examples
    ///
    /// A `coimhead suas sreath de cheithir eileamaidean.Lorgar a`chiad fhear, le suidheachadh air a dhearbhadh gu sònraichte;cha lorgar an dàrna agus an treas fear;dh'fhaodadh an ceathramh suidheachadh sam bith a cho-fhreagairt ann an `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Bidh Binary a `dèanamh sgrùdadh air an `VecDeque` seo a chaidh a sheòrsachadh le prìomh obair às-tharraing.
    ///
    /// A `gabhail ris gu bheil an `VecDeque` air a sheòrsachadh leis an iuchair, mar eisimpleir le [`make_contiguous().sort_by_key()`](#method.make_contiguous) a` cleachdadh an aon phrìomh obair às-tharraing.
    ///
    ///
    /// Ma lorgar an luach tha [`Result::Ok`] air a thilleadh, anns a bheil clàr-amais an eileamaid maidsidh.
    /// Ma tha grunn gheamannan ann, dh `fhaodadh aon de na maidsean a thilleadh.
    /// Mura lorgar an luach tha [`Result::Err`] air a thilleadh, anns a bheil an clàr-amais far an gabhadh eileamaid maidsidh a chuir a-steach fhad `s a bha e a` cumail òrdugh ann an òrdugh.
    ///
    /// # Examples
    ///
    /// A `coimhead suas sreath de cheithir eileamaidean ann an sliseag de chàraidean air an òrdachadh leis na dàrna eileamaidean aca.
    /// Lorgar a `chiad fhear, le suidheachadh air a dhearbhadh gu sònraichte;cha lorgar an dàrna agus an treas fear;dh'fhaodadh an ceathramh suidheachadh sam bith a cho-fhreagairt ann an `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Atharraich an `VecDeque` na àite gus am bi `len()` co-ionann ri new_len, an dàrna cuid le bhith a `toirt air falbh cus eileamaidean bhon chùl no le bhith a` ceangal clones de `value` ris a `chùl.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Tillidh e an clàr-amais anns a `bhufair bhunasach airson clàr-amais eileamaidean loidsigeach sònraichte.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // tha meud an-còmhnaidh na chumhachd 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Obraich a-mach an àireamh de eileamaidean a tha air fhàgail ri leughadh anns a `bhufair
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // tha meud an-còmhnaidh na chumhachd 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // An-còmhnaidh air a roinn ann an trì earrannan, mar eisimpleir: fèin: [a b c|d e f] eile: [0 1 2 3|4 5] aghaidh=3, meadhan=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Cha bhith e comasach Hash::hash_slice a chleachdadh air sliseagan air an tilleadh le modh as_slices oir faodaidh an fhaid aca a bhith eadar-dhealaichte ann an deicean a tha co-ionann ri chèile.
        //
        //
        // Chan eil Hasher ach a `gealltainn co-ionannachd airson an dearbh sheata de ghlaodhan ris na modhan aige.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// A `caitheamh an `VecDeque` gu bhith na itealaiche aghaidh ri aghaidh a` toirt a-mach eileamaidean a rèir luach.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Bu chòir an gnìomh seo a bhith co-ionnan gu moralta:
        //
        //      airson rud ann an iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Tionndaidh [`Vec<T>`] gu [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Bidh seo a `seachnadh ath-riarachadh far an gabh sin dèanamh, ach tha na cumhaichean airson sin teann, agus an urra ri atharrachadh, agus mar sin cha bu chòir earbsa a bhith ann mura tàinig an `Vec<T>` bho `From<VecDeque<T>>` agus nach deach ath-riarachadh.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Chan eil riarachadh ceart ann airson ZST a bhith draghail mu chomas, ach chan urrainn dha `VecDeque` a bhith a `làimhseachadh cho fada ri `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Feumaidh sinn ath-mheudachadh mura h-eil an comas cumhachd dà, ro bheag no mura h-eil co-dhiù aon àite an-asgaidh ann.
            // Bidh sinn a `dèanamh seo fhad` s a tha e fhathast san `Vec` agus mar sin tuitidh na nithean air panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Tionndaidh [`VecDeque<T>`] gu [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Chan fheum seo a-riamh ath-riarachadh, ach feumaidh e gluasad dàta *O*(*n*) a dhèanamh mura tachair am bufair cruinn aig toiseach an riarachaidh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Is e am fear seo *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Feumaidh am fear seo ath-rèiteachadh dàta.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}