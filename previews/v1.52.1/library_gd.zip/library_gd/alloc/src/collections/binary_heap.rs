//! Ciudha prìomhachais air a chuir an gnìomh le tiùr binary.
//!
//! Tha cuir a-steach agus popping an eileamaid as motha iom-fhillteachd ùine *O*(log(*n*)).
//! Is e a bhith a `sgrùdadh an eileamaid as motha *O*(1).Faodar tionndadh vector gu tiùr binary a dhèanamh na àite, agus tha iom-fhillteachd *O*(*n*) aige.
//! Faodar tiùr binary a thionndadh gu vector air a sheòrsachadh, a `leigeil leis a chleachdadh airson heapsort in-àite *O*(*n*\*log(* n*)).
//!
//! # Examples
//!
//! Is e seo eisimpleir nas motha a tha a `buileachadh [Dijkstra's algorithm][dijkstra] gus an [shortest path problem][sssp] fhuasgladh air [directed graph][dir_graph].
//!
//! Tha e a `sealltainn mar a chleachdas tu [`BinaryHeap`] le seòrsachan àbhaisteach.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Tha an ciudha prìomhachais an urra ri `Ord`.
//! // Cuir an trait an gnìomh gu sònraichte gus am bi an ciudha na min-heap an àite max-heap.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Mothaich gu bheil sinn a `gluasad an òrdugh mu chosgaisean.
//!         // Ann an cùis ceangail bidh sinn a `dèanamh coimeas eadar dreuchdan, tha feum air a` cheum seo gus buileachadh `PartialEq` agus `Ord` a dhèanamh cunbhalach.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` feumar a bhuileachadh cuideachd.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Tha gach nód air a riochdachadh mar `usize`, airson buileachadh nas giorra.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // An algorithm slighe as giorra aig Dijkstra.
//!
//! // Tòisich aig `start` agus cleachd `dist` gus sùil a chumail air an astar as giorra a tha ann an-dràsta gu gach nód.Chan eil am buileachadh seo èifeachdach a thaobh cuimhne oir dh `fhaodadh e nodan dùblaichte fhàgail anns a` chiudha.
//! //
//! // Bidh e cuideachd a `cleachdadh `usize::MAX` mar luach sentinel, airson buileachadh nas sìmplidh.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=an astar as giorra an-dràsta bho `start` gu `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Tha sinn aig `start`, le cosgais neoni
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Dèan sgrùdadh air a `chrìoch le nodan cosgais nas ìsle an toiseach (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Air neo dh `fhaodadh sinn a bhith air leantainn air adhart a` lorg a h-uile slighe as giorra
//!         if position == goal { return Some(cost); }
//!
//!         // Cudromach oir is dòcha gu bheil sinn air dòigh nas fheàrr a lorg mu thràth
//!         if cost > dist[position] { continue; }
//!
//!         // Airson gach nód as urrainn dhuinn a ruighinn, faic an urrainn dhuinn dòigh a lorg le cosgais nas ìsle a `dol tron nód seo
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Ma tha, cuir ris a `chrìoch agus lean air adhart
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Relaxation, tha sinn a-nis air dòigh nas fheàrr a lorg
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Amas nach gabh ruigsinn
//!     None
//! }
//!
//! fn main() {
//!     // Is e seo an graf stiùirichte a tha sinn a `dol a chleachdadh.
//!     // Tha àireamhan nan nód a `freagairt ris na diofar stàitean, agus tha na cuideaman edge a` samhlachadh cosgais gluasad bho aon nód gu fear eile.
//!     //
//!     // Thoir fa-near gu bheil na h-oirean aon-shligheach.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Tha an graf air a riochdachadh mar liosta iomaill far a bheil liosta de na h-oirean a-muigh aig gach clàr-amais, a rèir luach nód.
//!     // Air a thaghadh airson cho èifeachdach sa tha e.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Nòd 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Nòd 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Nòd 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Nòd 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Nòd 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Ciudha prìomhachais air a chuir an gnìomh le tiùr binary.
///
/// Is e mullach mòr a bhios an seo.
///
/// Is e mearachd loidsigeach a th `ann airson nì atharrachadh ann an dòigh is gum bi òrdugh an nì an coimeas ri nì sam bith eile, mar a chaidh a dhearbhadh leis an `Ord` trait, ag atharrachadh fhad` s a tha e san tiùrr.
///
/// Mar as trice chan urrainnear seo a dhèanamh ach tro `Cell`, `RefCell`, stàite cruinneil, I/O, no còd neo-shàbhailte.
/// Chan eil an giùlan a thig bho mhearachd loidsigeach mar sin air a shònrachadh, ach cha toir e giùlan neo-mhìnichte.
/// Dh `fhaodadh seo a bhith a` toirt a-steach panics, toraidhean ceàrr, giorrachadh, call cuimhne, agus neo-chrìochnachadh.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Leigidh co-dhùnadh seòrsa dhuinn ainm sgrìobhte sònraichte fhàgail air falbh (a bhiodh `BinaryHeap<i32>` san eisimpleir seo).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Faodaidh sinn peek a chleachdadh gus sùil a thoirt air an ath rud anns a `chàrn.
/// // Anns a `chùis seo, chan eil nithean ann fhathast gus am faigh sinn gin.
/// assert_eq!(heap.peek(), None);
///
/// // Nach cuir sinn beagan sgòran ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // A-nis tha peek a `sealltainn an rud as cudromaiche anns an tiùrr.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Faodaidh sinn sgrùdadh a dhèanamh air fad tiùrr.
/// assert_eq!(heap.len(), 3);
///
/// // Faodaidh sinn ath-aithris a dhèanamh air na nithean anns a `chàrn, ged a thilleas iad air ais ann an òrdugh air thuaiream.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Ma chuireas sinn na sgòran sin an àite sin, bu chòir dhaibh tilleadh ann an òrdugh.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Is urrainn dhuinn dùn nithean sam bith a tha air fhàgail a ghlanadh.
/// heap.clear();
///
/// // Bu chòir an dùn a-nis a bhith falamh.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Faodar an dàrna cuid `std::cmp::Reverse` no buileachadh àbhaisteach `Ord` a chleachdadh gus `BinaryHeap` a dhèanamh na min-heap.
/// Tha seo a `toirt air `heap.pop()` an luach as lugha a thilleadh an àite an fhear as motha.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Lìon luachan ann an `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Ma chuireas sinn na sgòran sin a-nis, bu chòir dhaibh a thighinn air ais san òrdugh eile.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Iom-fhillteachd ùine
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Tha an luach airson `push` na chosgais ris a bheil dùil;tha na sgrìobhainnean modh a `toirt seachad sgrùdadh nas mionaidiche.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Structar a `pasgadh iomradh gluasadach air an rud as motha air `BinaryHeap`.
///
///
/// Tha an `struct` seo air a chruthachadh leis an dòigh [`peek_mut`] air [`BinaryHeap`].
/// Faic na sgrìobhainnean aige airson tuilleadh.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // SÀBHAILTEACHD: Chan eil PeekMut air a chuir sa bhad ach airson tiùrran nach eil falamh.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SÀBHAILTE: Chan eil PeekMut air a chuir sa bhad ach airson tiùrran nach eil falamh
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SÀBHAILTE: Chan eil PeekMut air a chuir sa bhad ach airson tiùrran nach eil falamh
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Thoir air falbh an luach peeked bhon tiùrr agus till e.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// A `cruthachadh `BinaryHeap<T>` falamh.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// A `cruthachadh `BinaryHeap` falamh mar max-heap.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// A `cruthachadh `BinaryHeap` falamh le comas sònraichte.
    /// Bidh seo a `ro-riarachadh cuimhne gu leòr airson eileamaidean `capacity`, gus nach fheum an `BinaryHeap` a bhith air ath-riarachadh gus am bi co-dhiù mòran luachan ann.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Tillidh e iomradh gluasadach air an rud as motha anns an tiùrr binary, no `None` ma tha e falamh.
    ///
    /// Note: Ma tha an luach `PeekMut` air a leigeil a-mach, faodaidh an dùn a bhith ann an staid neo-chunbhalach.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Iom-fhillteachd ùine
    ///
    /// Ma thèid an rud atharrachadh, is e an iom-fhillteachd ùine as miosa *O*(log(*n*)), air dhòigh eile is e *O*(1) a th `ann.
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Thoir air falbh an rud as motha bhon tiùr binary agus thoir air ais e, no `None` ma tha e falamh.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Iom-fhillteachd ùine
    ///
    /// Is e a `chosgais as miosa de `pop` air tiùr anns a bheil eileamaidean *n**O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // SÀBHAILTEACHD: Tha !self.is_empty() a `ciallachadh gu bheil self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// A `putadh nì air an tiùrr binary.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Iom-fhillteachd ùine
    ///
    /// Is e a `chosgais ris a bheil dùil de `push`, cuibheasach thairis air a h-uile òrdugh a dh` fhaodadh a bhith air a phutadh, agus thairis air àireamh mhòr de phutan,*O*(1).
    ///
    /// Is e seo an metric cosgais as ciallaiche nuair a bhios tu a `putadh eileamaidean nach eil * mar-thà ann am pàtran de sheòrsa sam bith.
    ///
    /// Bidh an iom-fhillteachd ùine a `crìonadh ma thèid eileamaidean a phutadh ann an òrdugh dìreadh gu ìre mhòr.
    /// Anns a `chùis as miosa, tha eileamaidean air am putadh ann an òrdugh a` dìreadh agus is e a `chosgais cruinnichte airson gach putadh *O*(log(*n*)) an aghaidh tiùrr anns a bheil eileamaidean *n*.
    ///
    /// Is e a `chosgais as miosa de ghairm *singilte* gu `push`*O*(*n*).Bidh a`chùis as miosa a` tachairt nuair a bhios comas air a shaoradh agus feumach air ath-mheudachadh.
    /// Chaidh a `chosgais ath-mheudachadh a thomhas anns na h-àireamhan roimhe.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // SÀBHAILTEACHD: Bho phut sinn rud ùr tha e a `ciallachadh sin
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// A `caitheamh an `BinaryHeap` agus a` tilleadh vector ann an òrdugh (ascending) air a sheòrsachadh.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SÀBHAILTEACHD: Tha `end` a `dol bho `self.len() - 1` gu 1 (an dà chuid air an toirt a-steach),
            //  mar sin tha e an-còmhnaidh na chlàr-amais dligheach airson faighinn a-steach.
            //  Tha e sàbhailte faighinn gu clàr-amais 0 (ie `ptr`), air sgàth
            //  1 <=deireadh <self.len(), a `ciallachadh self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SÀBHAILTEACHD: Tha `end` a `dol bho `self.len() - 1` gu 1 (an dà chuid air an toirt a-steach) mar sin:
            //  0 <1 <=deireadh <= self.len(), 1 <self.len() A tha a `ciallachadh 0 <deireadh is deireadh <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Bidh buileachadh sift_up agus sift_down a `cleachdadh blocaichean mì-shàbhailte gus eileamaid a ghluasad a-mach às an vector (a` fàgail às deidh toll), gluais air feadh an fheadhainn eile agus gluais an eileamaid a chaidh a thoirt air ais don vector aig àite deireannach an toll.
    //
    // Tha an seòrsa `Hole` air a chleachdadh gus seo a riochdachadh, agus dèan cinnteach gu bheil an toll air a lìonadh air ais aig deireadh a raon obrach, eadhon air panic.
    // Tha a bhith a `cleachdadh toll a` lughdachadh a `bhàillidh seasmhach an taca ri bhith a` cleachdadh suaipean, a tha a `toirt a-steach a dhà uimhir de ghluasadan.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Feumaidh an neach-fòn gealltainn gum bi `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Thoir a-mach an luach aig `pos` agus cruthaich toll.
        // SÀBHAILTEACHD: Tha an neach-fios a `gealltainn gu bheil pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // SÀBHAILTEACHD: hole.pos()> tòiseachadh>=0, a `ciallachadh hole.pos()> 0
            //  agus mar sin chan urrainn hole.pos(), 1 a dhol fodha.
            //  Tha seo a `gealltainn gum bi pàrant <hole.pos() mar sin na chlàr-amais dligheach agus cuideachd!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SÀBHAILTEACHD: Dìreach mar gu h-àrd
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Gabh eileamaid aig `pos` agus gluais e sìos an tiùrr, fhad `s a tha a chlann nas motha.
    ///
    ///
    /// # Safety
    ///
    /// Feumaidh an neach-fòn gealltainn gum bi `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // SÀBHAILTEACHD: Tha an neach-fios a `gealltainn gum bi pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Lùb invariant: leanabh==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // dèan coimeas ris an fhear as motha den dithis chloinne SÀBHAILTEACHD: leanabh <deireadh, 1 <self.len() agus leanabh + 1 <deireadh <= self.len(), mar sin tha iad nan clàran-amais dligheach.
            //
            //  leanabh==2 *hole.pos() + 1!= hole.pos() agus leanabh + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: Dh `fhaodadh 2 *hole.pos() + 1 no 2* hole.pos() + 2 cur thairis ma tha T na ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ma tha sinn ann an òrdugh mu thràth, stad.
            // SÀBHAILTEACHD: tha an leanabh a-nis an dara cuid an seann leanabh no an seann leanabh + 1
            //  Dhearbh sinn mu thràth gur e <self.len() agus!= hole.pos() an dà chuid
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SÀBHAILTEACHD: an aon rud gu h-àrd.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SÀBHAILTEACHD: &&cuairt ghoirid, a tha a `ciallachadh sin anns an
        //  an dàrna suidheachadh tha e mar-thà fìor gu bheil leanabh==deireadh, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SÀBHAILTEACHD: tha leanabh air a dhearbhadh mar-thà mar chlàr-amais dligheach agus
            //  leanabh==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Feumaidh an neach-fòn gealltainn gum bi `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SÀBHAILTEACHD: tha pos <len air a ghealltainn leis an neach-fios agus
        //  gu follaiseach len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Gabh eileamaid aig `pos` agus gluais e fad na slighe sìos an tiùrr, an uairsin criathraich e chun a shuidheachadh.
    ///
    ///
    /// Note: Tha seo nas luaithe nuair a tha fios gu bheil an eileamaid mòr/bu chòir dha a bhith nas fhaisge air a `bhonn.
    ///
    /// # Safety
    ///
    /// Feumaidh an neach-fòn gealltainn gum bi `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SÀBHAILTEACHD: Tha an neach-fios a `gealltainn gu bheil pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Lùb invariant: leanabh==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // SÀBHAILTEACHD: leanabh <deireadh, 1 <self.len() agus
            //  leanabh + 1 <deireadh <= self.len(), mar sin tha iad nan clàran-amais dligheach.
            //  leanabh==2 *hole.pos() + 1!= hole.pos() agus leanabh + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: Dh `fhaodadh 2 *hole.pos() + 1 no 2* hole.pos() + 2 cur thairis ma tha T na ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SÀBHAILTEACHD: Dìreach mar gu h-àrd
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SÀBHAILTEACHD: leanabh==deireadh, 1 <self.len(), mar sin tha e na chlàr-amais dligheach
            //  agus leanabh==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // SÀBHAILTEACHD: is e pos an suidheachadh anns an toll agus chaidh a dhearbhadh mu thràth
        //  a bhith na chlàr-amais dligheach.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SÀBHAILTEACHD: n a `tòiseachadh bho self.len()/2 agus a` dol sìos gu 0.
            //  Is e an aon chùis nuair! (N <self.len()) ma tha self.len() ==0, ach tha e air a riaghladh a-mach le suidheachadh na lùb.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Gluais na h-eileamaidean `other` gu `self`, a `fàgail `other` falamh.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` a `gabhail obrachaidhean O(len1 + len2) agus mu 2 *(len1 + len2) coimeasan anns a` chùis as miosa fhad `s a bhios `extend` a` gabhail obrachaidhean O(len2* log(len1)) agus timcheall air coimeasan 1 *len2* log_2(len1) anns a `chùis as miosa, a` gabhail ris len1>= len2.
        // Airson tiùrran nas motha, chan eil a `phuing crossover a` leantainn an reusanachadh seo agus chaidh a dhearbhadh gu h-ìmpireil.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// A `tilleadh itealaiche a bhios a` faighinn eileamaidean air ais ann an òrdugh tiùrr.
    /// Thèid na h-eileamaidean a chaidh a lorg a thoirt a-mach às an tiùrr tùsail.
    /// Thèid na h-eileamaidean a tha air fhàgail a thoirt air falbh nuair a thig iad ann an òrdugh cruachan.
    ///
    /// Note:
    /// * `.drain_sorted()` tha *O*(*n*\*log(* n*)); tòrr nas slaodaiche na `.drain()`.
    ///   Bu chòir dhut an dàrna fear a chleachdadh airson a `mhòr-chuid de chùisean.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // a `toirt air falbh a h-uile eileamaid ann an òrdugh cruachan
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// A `gleidheadh dìreach na h-eileamaidean a tha air an comharrachadh leis an predicate.
    ///
    /// Ann am faclan eile, cuir às na h-eileamaidean `e` gu lèir gus am bi `f(&e)` a `tilleadh `false`.
    /// Thathas a `tadhal air na h-eileamaidean ann an òrdugh neo-chuibhrichte (agus neo-ainmichte).
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // na cum ach àireamhan cothromach
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// A `tilleadh itealaiche a` tadhal air na luachan uile anns an vector bunaiteach, ann an òrdugh deas-ghnàthach.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Clò-bhuail 1, 2, 3, 4 ann an òrdugh deas-ghnàthach
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// A `tilleadh itealaiche a bhios a` faighinn eileamaidean air ais ann an òrdugh tiùrr.
    /// Bidh an dòigh seo ag ithe an tiùrr tùsail.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Tillidh e an rud as motha anns an tiùrr binary, no `None` ma tha e falamh.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Iom-fhillteachd ùine
    ///
    /// Is e cosgais *O*(1) anns a `chùis as miosa.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// A `tilleadh an àireamh de eileamaidean a dh` fhaodas an dùn binary a chumail gun ath-riarachadh.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// A `glèidheadh a` chomais as lugha airson dìreach `additional` barrachd eileamaidean a chuir a-steach san `BinaryHeap` a chaidh a thoirt seachad.
    /// A `dèanamh dad ma tha an comas gu leòr mar-thà.
    ///
    /// Thoir fa-near gum faod an neach-riarachaidh barrachd àite a thoirt don chruinneachadh na tha e ag iarraidh.
    /// Mar sin chan urrainnear a bhith an urra ri comas a bhith fìor bheag.
    /// B `fheàrr le [`reserve`] ma tha dùil ri cuir a-steach future.
    ///
    /// # Panics
    ///
    /// Panics ma tha an comas ùr a `dol thairis air `usize`.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// A `gleidheadh comas airson co-dhiù `additional` barrachd eileamaidean a chuir a-steach san `BinaryHeap`.
    /// Is dòcha gun glèidh an cruinneachadh barrachd àite gus ath-riarachadh tric a sheachnadh.
    ///
    /// # Panics
    ///
    /// Panics ma tha an comas ùr a `dol thairis air `usize`.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// A `tilgeil air falbh uiread de chomas a bharrachd.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// A `tilgeil air falbh comas le crìoch nas ìsle.
    ///
    /// Bidh an comas co-dhiù cho mòr ris an dà chuid an fhaid agus an luach a chaidh a thoirt seachad.
    ///
    ///
    /// Ma tha an comas làithreach nas ìsle na an ìre as ìsle, is e neo-op a tha seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// A `caitheamh an `BinaryHeap` agus a` tilleadh an vector bunaiteach ann an òrdugh deas-ghnàthach.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Thèid clò-bhualadh ann an òrdugh air choreigin
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// A `tilleadh fad an tiùrr binary.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// A `dèanamh cinnteach a bheil an dùn binary falamh.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// A `glanadh a` chàrn binary, a `tilleadh itealaiche thairis air na h-eileamaidean a chaidh a thoirt air falbh.
    ///
    /// Tha na h-eileamaidean air an toirt air falbh ann an òrdugh neo-riaghailteach.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Drops a h-uile rud bhon tiùr binary.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Tha toll a `riochdachadh toll ann an sliseag ie, clàr-amais gun luach dligheach (oir chaidh a ghluasad bho no a dhùblachadh).
///
/// Ann an tuiteam, bheir `Hole` air ais an sliseag le bhith a `lìonadh suidheachadh an toll leis an luach a chaidh a thoirt air falbh bho thùs.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Cruthaich `Hole` ùr aig clàr-amais `pos`.
    ///
    /// Neo-shàbhailte oir feumaidh pos a bhith taobh a-staigh an dàta.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SÀBHAILTE: bu chòir pos a bhith am broinn an t-sliseag
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// A `tilleadh iomradh air an eileamaid a chaidh a thoirt air falbh.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// A `tilleadh iomradh air an eileamaid aig `index`.
    ///
    /// Neo-shàbhailte oir feumaidh clàr-amais a bhith taobh a-staigh an dàta dàta agus gun a bhith co-ionann ri pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Gluais toll gu àite ùr
    ///
    /// Neo-shàbhailte oir feumaidh clàr-amais a bhith taobh a-staigh an dàta dàta agus gun a bhith co-ionann ri pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // lìon an toll a-rithist
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Reultair thairis air na h-eileamaidean de `BinaryHeap`.
///
/// Tha an `struct` seo air a chruthachadh le [`BinaryHeap::iter()`].
/// Faic na sgrìobhainnean aige airson tuilleadh.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Thoir air falbh fàbhar `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Itealain seilbh thairis air na h-eileamaidean de `BinaryHeap`.
///
/// Tha an `struct` seo air a chruthachadh le [`BinaryHeap::into_iter()`] (air a thoirt seachad leis an `IntoIterator` trait).
/// Faic na sgrìobhainnean aige airson tuilleadh.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Ath-aithrisiche drèanaidh thairis air na h-eileamaidean de `BinaryHeap`.
///
/// Tha an `struct` seo air a chruthachadh le [`BinaryHeap::drain()`].
/// Faic na sgrìobhainnean aige airson tuilleadh.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Ath-aithrisiche drèanaidh thairis air na h-eileamaidean de `BinaryHeap`.
///
/// Tha an `struct` seo air a chruthachadh le [`BinaryHeap::drain_sorted()`].
/// Faic na sgrìobhainnean aige airson tuilleadh.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// A `toirt air falbh eileamaidean tiùrr ann an òrdugh tiùrr.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Bidh e ag atharrachadh `Vec<T>` gu `BinaryHeap<T>`.
    ///
    /// Bidh an tionndadh seo a `tachairt na àite, agus tha iom-fhillteachd ùine *O*(*n*) aige.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Bidh e ag atharrachadh `BinaryHeap<T>` gu `Vec<T>`.
    ///
    /// Chan fheum an tionndadh seo gluasad no riarachadh dàta, agus tha iom-fhillteachd ùine ann.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// A `cruthachadh itealaiche caitheamh, is e sin, fear a ghluaiseas gach luach a-mach às an tiùrr binary ann an òrdugh deas-ghnàthach.
    /// Chan urrainnear an dùn binary a chleachdadh an dèidh seo a ghairm.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Clò-bhuail 1, 2, 3, 4 ann an òrdugh deas-ghnàthach
    /// for x in heap.into_iter() {
    ///     // tha seòrsa i32 aig x, chan e &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}