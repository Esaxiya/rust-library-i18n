//! # Leabharlann riarachadh bunaiteach agus cruinneachaidhean Rust
//!
//! Tha an leabharlann seo a `toirt seachad molaidhean agus cruinneachaidhean snasail airson a bhith a` riaghladh luachan air an riarachadh le cruachan.
//!
//! Mar as trice cha bhith feum air an leabharlann seo, mar libcore, a chleachdadh gu dìreach leis gu bheil na susbaint aice air an ath-mhalairt san [`std` crate](../std/index.html).
//! Ach mar as trice cha bhith Crates a bhios a `cleachdadh feart `#![no_std]` an urra ri `std`, mar sin bhiodh iad a` cleachdadh an crate seo na àite.
//!
//! ## Luachan bogsa
//!
//! Tha an seòrsa [`Box`] na sheòrsa puing smart.Chan urrainn ach aon neach-seilbh a bhith ann an [`Box`], agus faodaidh an sealbhadair co-dhùnadh am susbaint a thionndadh, a tha beò air an tiùrr.
//!
//! Faodar an seòrsa seo a chuir am measg snàithleanan gu h-èifeachdach leis gu bheil meud luach `Box` an aon rud ri meud puing.
//! Bidh structaran dàta coltach ri craobhan gu tric air an togail le bogsaichean oir gu tric chan eil ach aon sealbhadair aig gach nód, am pàrant.
//!
//! ## Molaidhean cunntais iomraidh
//!
//! Tha an seòrsa [`Rc`] na sheòrsa puing iomraidh neo-threadsafe air a chunntadh airson cuimhne a cho-roinn taobh a-staigh snàithlean.
//! Bidh puing [`Rc`] a `pasgadh seòrsa, `T`, agus a` ceadachadh ruigsinneachd gu `&T` a-mhàin, iomradh co-roinnte.
//!
//! Tha an seòrsa seo feumail nuair a tha mutability oighre (mar a bhith a `cleachdadh [`Box`]) ro chuingealaichte airson tagradh, agus gu tric bidh e air a pharadh leis na seòrsaichean [`Cell`] no [`RefCell`] gus cead a thoirt dha mutation.
//!
//!
//! ## Atomically iomradh a thoirt air molaidhean cunntadh
//!
//! Tha an seòrsa [`Arc`] co-ionann ri threadsafe den t-seòrsa [`Rc`].Tha e a `toirt seachad an aon seòrsa gnìomh de [`Rc`], ach a-mhàin gu feum e gum bi an seòrsa `T` a tha ann air a roinn.
//! A bharrachd air an sin, tha [`Arc<T>`][`Arc`] fhèin ri chuir air falbh fhad `s nach eil [`Rc<T>`][`Rc`].
//!
//! Tha an seòrsa seo a `ceadachadh ruigsinneachd co-roinnte air an dàta a tha ann, agus gu tric bidh e air a pharadh le prìomhairean sioncronaidh leithid mutexes gus leigeil le goireasan co-roinnte a bhith air an cuairteachadh.
//!
//! ## Collections
//!
//! Tha buileachadh nan structaran dàta adhbhar coitcheann as cumanta air am mìneachadh san leabharlann seo.Tha iad air an ath-mhalairt tron [standard collections library](../std/collections/index.html).
//!
//! ## charn coluadar
//!
//! Tha am modal [`alloc`](alloc/index.html) a `mìneachadh an eadar-aghaidh ìre ìosal chun an neach-sgaoilidh cruinne àbhaisteach.Chan eil e co-chòrdail ris an riarachadh libc API.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// Gu teicnigeach, is e bug a tha seo ann an rustdoc: tha rustdoc a `faicinn gu bheil an sgrìobhainn air blocaichean `#[lang = slice_alloc]` airson `&[T]`, aig a bheil sgrìobhainnean cuideachd a` cleachdadh am feart seo ann an `core`, agus tha e a `fàs meallta nach eil an geata feart air a chomasachadh.
// Bhiodh e na b `fheàrr nach dèanadh e sgrùdadh airson a` gheata feart airson docaichean bho crates eile, ach leis nach urrainn seo nochdadh ach airson rudan lang, chan eil e coltach gum b `fhiach e a chàradh.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// Leig le bhith a `dèanamh deuchainn air an leabharlann seo

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Modal le macros a-staigh air an cleachdadh le modalan eile (feumar a thoirt a-steach ro mhodalan eile).
#[macro_use]
mod macros;

// Bha cruachan air an solarachadh airson ro-innleachdan riarachaidh aig ìre ìosal

pub mod alloc;

// Seòrsaichean prìomhaideach a `cleachdadh na cruachan gu h-àrd

// Feumar mìneachadh mionaideach a dhèanamh air a `mhod bho `boxed.rs` gus a bhith a` dùblachadh na lang-nithean nuair a bhios tu a `togail deuchainn cfg;ach feumaidh iad cuideachd leigeil le còd dearbhaidhean `use boxed::Box;` a bhith aca.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}