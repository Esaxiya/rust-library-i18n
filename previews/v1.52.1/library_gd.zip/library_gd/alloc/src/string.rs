//! Sreang UTF-8-encoded, fàs.
//!
//! Anns a `mhodal seo tha an seòrsa [`String`], an [`ToString`] trait airson a thionndadh gu sreangan, agus grunn sheòrsaichean mearachd a dh` fhaodadh a bhith mar thoradh air a bhith ag obair le [`String`] s.
//!
//!
//! # Examples
//!
//! Tha iomadh dòigh ann air [`String`] ùr a chruthachadh bho litearra sreang:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Faodaidh tu [`String`] ùr a chruthachadh bho fhear a tha ann le bhith a `co-chòrdadh ris
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Ma tha vector agad de bytes UTF-8 dligheach, faodaidh tu [`String`] a dhèanamh a-mach às.Faodaidh tu an cùl a dhèanamh cuideachd.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Tha fios againn gu bheil na bytes sin dligheach, mar sin cleachdaidh sinn `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Sreang UTF-8-encoded, fàs.
///
/// Is e an seòrsa `String` an seòrsa sreang as cumanta aig a bheil seilbh air susbaint na sreang.Tha dlùth dhàimh aige ris an neach a fhuair e air iasad, an [`str`] prìomhadail.
///
/// # Examples
///
/// Faodaidh tu `String` a chruthachadh bho [a literal string][`str`] le [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Faodaidh tu [`char`] a cheangal ri `String` leis an dòigh [`push`], agus [`&str`] a cheangal ris an dòigh [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Ma tha vector de UTF-8 bytes agad, faodaidh tu `String` a chruthachadh bhuaithe leis an dòigh [`from_utf8`]:
///
/// ```
/// // cuid bytes, ann an vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Tha fios againn gu bheil na bytes sin dligheach, mar sin cleachdaidh sinn `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// Tha `String`s an-còmhnaidh dligheach UTF-8.Tha beagan bhuadhan aig seo, agus is e a `chiad fhear ma tha feum agad air sreang neo-UTF-8, beachdaich air [`OsString`].Tha e coltach, ach às aonais an cuingealachadh UTF-8.Is e an dàrna brìgh nach urrainn dhut clàr-amais a dhèanamh ann an `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Tha clàr-amais an dùil a bhith na obair seasmhach-ùine, ach chan eil còdachadh UTF-8 a `leigeil leinn seo a dhèanamh.A bharrachd air an sin, chan eil e soilleir dè an seòrsa rud a bu chòir don chlàr-amais a thilleadh: byte, còd-còd, no brabhsair grapheme.
/// Bidh na modhan [`bytes`] agus [`chars`] a `tilleadh itealain thairis air a` chiad dhà, fa leth.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// Bidh `String`s a`buileachadh [`Deref`]`<Target=str>`, agus mar sin sealbhaich na modhan [` str`] gu lèir.A bharrachd air an sin, tha seo a`ciallachadh gun urrainn dhut `String` a thoirt seachad gu gnìomh a bheir [`&str`] le bhith a` cleachdadh ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Cruthaichidh seo [`&str`] bhon `String` agus bheir e a-steach e. Tha an tionndadh seo gu math saor, agus mar sin san fharsaingeachd, gabhaidh gnìomhan ri [`&str`] s mar argamaidean mura feum iad `String` airson adhbhar sònraichte.
///
/// Ann an cuid de chùisean chan eil fiosrachadh gu leòr aig Rust gus an tionndadh seo, ris an canar co-èigneachadh [`Deref`].Anns an eisimpleir a leanas tha sliseag sreang [`&'a str`][`&str`] a `buileachadh an trait `TraitExample`, agus tha an gnìomh `example_func` a` toirt rud sam bith a chuireas an trait an gnìomh.
/// Anns a `chùis seo dh` fheumadh Rust dà thionndadh a dhèanamh a rèir coltais, rud nach eil dòigh aig Rust ri dhèanamh.
/// Air an adhbhar sin, cha chuir an eisimpleir a leanas ri chèile.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Tha dà roghainn ann a dh `obraicheadh na àite.Is e a`chiad fhear an loidhne `example_func(&example_string);` atharrachadh gu `example_func(example_string.as_str());`, a` cleachdadh an dòigh [`as_str()`] gus an sliseag sreang anns a bheil an sreang a thoirt a-mach gu follaiseach.
/// Bidh an dàrna dòigh ag atharrachadh `example_func(&example_string);` gu `example_func(&*example_string);`.
/// Anns a 'chùis seo a tha sinn a dereferencing a `String` gu [`str`][`&str`], an sin tarraing air an [`str`][`&str`] ais gu [`&str`].
/// Tha an dàrna dòigh nas gnàthach, ach bidh an dithis ag obair gus an tionndadh a dhèanamh gu follaiseach an àite a bhith an urra ris an tionndadh a tha ri thuigsinn.
///
/// # Representation
///
/// Tha `String` air a dhèanamh suas de thrì phàirtean: stiùireadh gu cuid de bytes, fad, agus comas.Bidh am puing a `comharrachadh bufair a-staigh `String` a` cleachdadh gus an dàta aige a stòradh.Is e an fhaid an àireamh de bytes a tha air an stòradh anns a `bhufair an-dràsta, agus is e an comas meud a` bhufair ann am bytes.
///
/// Mar sin, bidh an fhaid an-còmhnaidh nas lugha na no co-ionann ris a `chomas.
///
/// Tha am bufair seo an-còmhnaidh air a stòradh air an tiùrr.
///
/// Faodaidh tu sùil a thoirt orra sin leis na modhan [`as_ptr`], [`len`], agus [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Ùraich seo nuair a thèid vec_into_raw_parts a dhèanamh seasmhach.
/// // Cuir casg air a bhith a `leigeil às dàta String gu fèin-ghluasadach
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // sgeulachd tha naoi deug bytes
/// assert_eq!(19, len);
///
/// // Faodaidh sinn String ath-thogail a-mach à ptr, len, agus comas.
/// // Tha seo uile cunnartach oir tha e an urra rinn dèanamh cinnteach gu bheil na pàirtean dligheach:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Ma tha comas gu leòr aig `String`, cha chuir e eileamaidean ris a-rithist.Mar eisimpleir, smaoinich air a `phrògram seo:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Bheir seo a-mach na leanas:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// An toiseach, chan eil cuimhne againn air a riarachadh idir, ach mar a bhios sinn a `ceangal ris an t-sreang, bidh e a` meudachadh a comas gu h-iomchaidh.Ma chleachdas sinn an dòigh [`with_capacity`] an àite sin gus an comas ceart a riarachadh an toiseach:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Bidh sinn a `crìochnachadh le toradh eadar-dhealaichte:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// An seo, chan fheumar barrachd cuimhne a riarachadh taobh a-staigh an lùb.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Luach mearachd a dh `fhaodadh a bhith ann nuair a thionndaidheas tu `String` bho byte UTF-8 vector.
///
/// Is e an seòrsa seo an seòrsa mearachd airson an dòigh [`from_utf8`] air [`String`].
/// Tha e air a dhealbhadh ann an dòigh gus ath-riarachadh a sheachnadh gu faiceallach: bheir an dòigh [`into_bytes`] air ais am byte vector a chaidh a chleachdadh san oidhirp tionndaidh.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Tha an seòrsa [`Utf8Error`] a tha [`std::str`] a `toirt seachad a` riochdachadh mearachd a dh `fhaodadh tachairt nuair a thionndaidheas tu sliseag de [` u8`] s gu [`&str`].
/// Anns an t-seagh seo, tha e na analog gu `FromUtf8Error`, agus gheibh thu fear bho `FromUtf8Error` tron dòigh [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// // cuid de bytes neo-dhligheach, ann an vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Luach mearachd a dh `fhaodadh a bhith ann nuair a thionndaidheas tu `String` bho sliseag byte UTF-16.
///
/// Is e an seòrsa seo an seòrsa mearachd airson an dòigh [`from_utf16`] air [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// A `cruthachadh `String` falamh ùr.
    ///
    /// Leis gu bheil an `String` falamh, cha riaraich seo bufair tùsail sam bith.Ged a tha sin a `ciallachadh gu bheil a` chiad obair seo gu math saor, dh `fhaodadh e cus riarachadh adhbhrachadh nas fhaide air adhart nuair a chuireas tu dàta ris.
    ///
    /// Ma tha beachd agad air an ìre de dhàta a chumas an `String`, smaoinich air an dòigh [`with_capacity`] gus casg a chuir air cus ath-riarachadh.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// A `cruthachadh `String` falamh ùr le comas sònraichte.
    ///
    /// Tha bufair a-staigh aig `String 'airson an dàta aca a chumail.
    /// Is e an comas fad a `bhufair sin, agus faodar a cheasnachadh leis an dòigh [`capacity`].
    /// Bidh an dòigh seo a `cruthachadh `String` falamh, ach aon le bufair tùsail a chumas `capacity` bytes.
    /// Tha seo feumail nuair a dh `fhaodadh tu a bhith a` ceangal dòrlach dàta ris an `String`, a `lughdachadh an àireamh de ath-riarachadh a dh` fheumas e a dhèanamh.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Mas e an comas a chaidh a thoirt seachad `0`, cha tachair riarachadh sam bith, agus tha an dòigh seo co-ionann ris an dòigh [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Chan eil clàir anns an t-sreang, eadhon ged a tha comas aige barrachd
    /// assert_eq!(s.len(), 0);
    ///
    /// // Tha iad sin uile air an dèanamh gun ath-riarachadh ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... ach dh `fhaodadh seo toirt air an t-sreang ath-riarachadh
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): le cfg(test) chan eil an dòigh in-ghnèitheach `[T]::to_vec`, a tha riatanach airson mìneachadh a `mhodh seo, ri fhaighinn.
    // Leis nach eil feum againn air an dòigh seo airson adhbharan deuchainn, bidh mi dìreach ga stobadh NB faic am modal slice::hack ann an slice.rs airson tuilleadh fiosrachaidh
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Bidh e ag atharrachadh vector de bytes gu `String`.
    ///
    /// Tha sreang ([`String`]) air a dhèanamh de bytes ([`u8`]), agus tha vector de bytes ([`Vec<u8>`]) air a dhèanamh de bytes, agus mar sin bidh an gnìomh seo ag atharrachadh eadar an dà rud.
    /// Chan eil a h-uile sliseag byte dligheach `String`s, ge-tà: tha `String` ag iarraidh gu bheil e dligheach UTF-8.
    /// `from_utf8()` sgrùdaidhean gus dèanamh cinnteach gu bheil na bytes dligheach UTF-8, agus an uairsin an tionndadh.
    ///
    /// Ma tha thu cinnteach gu bheil an sliseag byte dligheach UTF-8, agus nach eil thu airson faighinn thairis air an sgrùdadh dligheachd, tha dreach neo-shàbhailte den ghnìomh seo, [`from_utf8_unchecked`], aig a bheil an aon ghiùlan ach a `leum às an t-seic.
    ///
    ///
    /// Bidh an dòigh seo a `gabhail cùram gus nach dèan thu leth-bhreac den vector, air sgàth èifeachdas.
    ///
    /// Ma tha feum agad air [`&str`] an àite `String`, beachdaich air [`str::from_utf8`].
    ///
    /// Is e taobh a-staigh an dòigh seo [`into_bytes`].
    ///
    /// # Errors
    ///
    /// A `tilleadh [`Err`] mura h-eil an sliseag UTF-8 le tuairisgeul air carson nach e UTF-8 na bytes a chaidh a thoirt seachad.Tha an vector a ghluais thu a-steach cuideachd air a thoirt a-steach.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// // cuid bytes, ann an vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Tha fios againn gu bheil na bytes sin dligheach, mar sin cleachdaidh sinn `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Beart ceàrr:
    ///
    /// ```
    /// // cuid de bytes neo-dhligheach, ann an vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Faic na docaichean airson [`FromUtf8Error`] airson tuilleadh fiosrachaidh mu na as urrainn dhut a dhèanamh leis a `mhearachd seo.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Bidh e ag atharrachadh sliseag de bytes gu sreang, a `toirt a-steach caractaran neo-dhligheach.
    ///
    /// Tha sreathan air an dèanamh le bytes ([`u8`]), agus tha sliseag de bytes ([`&[u8]`][byteslice]) air a dhèanamh le bytes, agus mar sin bidh an gnìomh seo ag atharrachadh eadar an dà rud.Chan eil a h-uile sliseag byte nan sreangan dligheach, ge-tà: feumar sreangan a bhith dligheach UTF-8.
    /// Aig an àm seo atharrachadh, `from_utf8_lossy()` a chur an àite sam bith mì-dhligheach UTF-8 sreathan le [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], a tha a 'coimhead mar seo:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Ma tha thu cinnteach gu bheil an sliseag byte dligheach UTF-8, agus nach eil thu airson faighinn thairis air an tionndadh, tha dreach neo-shàbhailte den ghnìomh seo, [`from_utf8_unchecked`], aig a bheil an aon ghiùlan ach a `leum às na sgrùdaidhean.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Bidh an gnìomh seo a `tilleadh [`Cow<'a, str>`].Ma tha an sliseag byte againn neo-dhligheach UTF-8, feumaidh sinn na caractaran ùra a chuir a-steach, a dh`atharraicheas meud an t-sreang, agus mar sin, a dh` fheumas `String`.
    /// Ach ma tha e dligheach mu thràth UTF-8, chan fheum sinn riarachadh ùr.
    /// Leigidh an seòrsa tilleadh seo leinn an dà chùis a làimhseachadh.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// // cuid bytes, ann an vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Beart ceàrr:
    ///
    /// ```
    /// // cuid de bytes neo-dhligheach
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Cuir a-mach UTF-16-encoded vector `v` a-steach do `String`, a `tilleadh [`Err`] ma tha dàta neo-dhligheach ann an `v`.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Cha bhith seo air a dhèanamh tro collect: : <Result<_, _>> () airson adhbharan coileanaidh.
        // FIXME: faodar an gnìomh a dhèanamh nas sìmplidhe a-rithist nuair a tha #48994 dùinte.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Cuir a-mach sliseag `v` le còd UTF-16 a-steach do `String`, a `dol an àite dàta neo-dhligheach le [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Eu-coltach ri [`from_utf8_lossy`] a thilleas [`Cow<'a, str>`], bidh `from_utf16_lossy` a `tilleadh `String` bhon a dh` fheumas an tionndadh UTF-16 gu UTF-8 riarachadh cuimhne.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// A `lobhadh `String` na phàirtean amh.
    ///
    /// A `tilleadh a` phuing amh chun an dàta bunaiteach, fad an t-sreang (ann am bytes), agus comas riaraichte an dàta (ann am bytes).
    /// Is iad sin na h-aon argamaidean san aon òrdugh ris na h-argamaidean gu [`from_raw_parts`].
    ///
    /// Às deidh an gnìomh seo a ghairm, tha uallach air an neach-conaltraidh airson a `chuimhne a chaidh a riaghladh roimhe leis an `String`.
    /// Is e an aon dòigh air seo a dhèanamh am puing amh, fad, agus comas a thionndadh air ais gu `String` le gnìomh [`from_raw_parts`], a `leigeil leis an inneal-sgrios an glanadh a dhèanamh.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// A `cruthachadh `String` ùr bho fhad, comas, agus stiùireadh.
    ///
    /// # Safety
    ///
    /// Tha seo glè shàbhailte, mar thoradh air an àireamh de luchd-ionnsaigh nach eilear a `sgrùdadh:
    ///
    /// * Feumaidh a `chuimhne aig `buf` a bhith air a riarachadh roimhe leis an aon neach-riarachaidh a bhios an leabharlann àbhaisteach a` cleachdadh, le co-thaobhadh riatanach de dìreach 1.
    /// * `length` feumaidh e a bhith nas lugha na no co-ionann ri `capacity`.
    /// * `capacity` feumaidh an luach ceart a bhith ann.
    /// * Feumaidh a `chiad bytes `length` aig `buf` a bhith dligheach UTF-8.
    ///
    /// Faodaidh briseadh iad sin duilgheadasan adhbhrachadh mar bhith a `truailleadh structaran dàta a-staigh an neach-sònrachaidh.
    ///
    /// Tha seilbh `buf` air a ghluasad gu h-èifeachdach chun `String` a dh `fhaodadh an uairsin susbaint a` chuimhne a chomharraich am putan aig toil a thuigsinn, ath-riarachadh no atharrachadh.
    /// Dèan cinnteach nach bi dad sam bith eile a `cleachdadh a` phuing às deidh dhut an gnìomh seo a ghairm.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Ùraich seo nuair a thèid vec_into_raw_parts a dhèanamh seasmhach.
    ///     // Cuir casg air a bhith a `leigeil às dàta String gu fèin-ghluasadach
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Bidh e ag atharrachadh vector de bytes gu `String` gun a bhith cinnteach gu bheil UTF-8 dligheach anns an t-sreang.
    ///
    /// Faic an dreach sàbhailte, [`from_utf8`], airson tuilleadh fiosrachaidh.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Tha an gnìomh seo cunnartach oir chan eil e a `dèanamh cinnteach gu bheil na bytes a chaidh a thoirt dha dligheach UTF-8.
    /// Ma thèid an cuingeachadh seo a bhriseadh, faodaidh e cùisean mì-shàbhailteachd cuimhne adhbhrachadh le luchd-cleachdaidh future den `String`, oir tha an còrr den leabharlann àbhaisteach a `gabhail ris gu bheil` String`s dligheach UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// // cuid bytes, ann an vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Bidh e ag atharrachadh `String` gu byte vector.
    ///
    /// Bidh seo a `caitheamh an `String`, mar sin cha leig sinn a leas a chopaigeadh.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// A `toirt a-mach sliseag sreang anns a bheil an `String` gu lèir.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Bidh e ag atharrachadh `String` gu sliseag sreang gluasadach.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// A `cur pìos sreang ris a` cheann thall air deireadh an `String` seo.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// A `tilleadh comas an t-sreang seo, ann am bytes.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// A `dèanamh cinnteach gu bheil comas an` String` seo co-dhiù `additional` bytes nas motha na an fhaid.
    ///
    /// Faodar an comas a mheudachadh le barrachd air `additional` bytes ma thaghas e, gus casg a chuir air ath-riarachadh tric.
    ///
    ///
    /// Mura h-eil thu ag iarraidh an giùlan "at least" seo, faic am modh [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics ma tha an comas ùr a `dol thairis air [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Is dòcha nach àrdaich seo an comas:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s a-nis tha fad 2 agus comas 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Leis gu bheil comas 8 a bharrachd againn mu thràth, a `gairm seo ...
    /// s.reserve(8);
    ///
    /// // ... chan eil àrdachadh ann an da-rìribh.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// A `dèanamh cinnteach gu bheil an comas` String` seo `additional` bytes nas motha na an fhaid.
    ///
    /// Beachdaich air a bhith a `cleachdadh an dòigh [`reserve`] mura h-eil fios agad gu cinnteach nas fheàrr na an neach-sgaoilidh.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics ma tha an comas ùr a `dol thairis air `usize`.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Is dòcha nach àrdaich seo an comas:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s a-nis tha fad 2 agus comas 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Leis gu bheil comas 8 a bharrachd againn mu thràth, a `gairm seo ...
    /// s.reserve_exact(8);
    ///
    /// // ... chan eil àrdachadh ann an da-rìribh.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// A `feuchainn ri comas a ghlèidheadh airson co-dhiù `additional` barrachd eileamaidean a chuir a-steach san `String` a chaidh a thoirt seachad.
    /// Is dòcha gun glèidh an cruinneachadh barrachd àite gus ath-riarachadh tric a sheachnadh.
    /// Às deidh `reserve` a ghairm, bidh comas nas motha na no co-ionann ri `self.len() + additional`.
    /// A `dèanamh dad ma tha comas gu leòr mar-thà.
    ///
    /// # Errors
    ///
    /// Ma tha an comas a `dol thairis, no ma tha an neach-riarachaidh ag aithris air fàiligeadh, thèid mearachd a thilleadh.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Glèidh a `chuimhne ro-làimh, a` falbh mura h-urrainn dhuinn
    ///     output.try_reserve(data.len())?;
    ///
    ///     // A-nis tha fios againn nach urrainn seo OOM a dhèanamh ann am meadhan ar n-obair iom-fhillte
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// A `feuchainn ris a` chomas as lugha a ghleidheadh airson dìreach `additional` barrachd eileamaidean a chuir a-steach san `String` a chaidh a thoirt seachad.
    ///
    /// Às deidh `reserve_exact` a ghairm, bidh comas nas motha na no co-ionann ri `self.len() + additional`.
    /// A `dèanamh dad ma tha an comas gu leòr mar-thà.
    ///
    /// Thoir fa-near gum faod an neach-riarachaidh barrachd àite a thoirt don chruinneachadh na tha e ag iarraidh.
    /// Mar sin, chan urrainnear a bhith an urra ri comas a bhith fìor bheag.
    /// B `fheàrr le `reserve` ma tha dùil ri cuir a-steach future.
    ///
    /// # Errors
    ///
    /// Ma tha an comas a `dol thairis, no ma tha an neach-riarachaidh ag aithris air fàiligeadh, thèid mearachd a thilleadh.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Glèidh a `chuimhne ro-làimh, a` falbh mura h-urrainn dhuinn
    ///     output.try_reserve(data.len())?;
    ///
    ///     // A-nis tha fios againn nach urrainn seo OOM a dhèanamh ann am meadhan ar n-obair iom-fhillte
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// A `lughdachadh comas an `String` seo gus a bhith co-ionnan ris an fhaid aige.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// A `lughdachadh comas an `String` seo le crìoch nas ìsle.
    ///
    /// Bidh an comas co-dhiù cho mòr ris an dà chuid an fhaid agus an luach a chaidh a thoirt seachad.
    ///
    ///
    /// Ma tha an comas làithreach nas ìsle na an ìre as ìsle, is e neo-op a tha seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// A `cur an [`char`] a chaidh a thoirt seachad gu deireadh an `String` seo.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// A `tilleadh pìos byte den t-susbaint` String` seo.
    ///
    /// Is e taobh a-staigh an dòigh seo [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// A `giorrachadh an `String` seo chun fhaid ainmichte.
    ///
    /// Ma tha `new_len` nas motha na fad gnàthach an t-sreang, chan eil buaidh sam bith aig seo.
    ///
    ///
    /// Thoir fa-near nach eil buaidh sam bith aig an dòigh seo air comas ainmichte an t-sreang
    ///
    /// # Panics
    ///
    /// Panics mura h-eil `new_len` na laighe air crìoch [`char`].
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Air falbh mu dheireadh caractar bho an t-sreang bufair agus tilleadh e.
    ///
    /// A `tilleadh [`None`] ma tha an `String` seo falamh.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Thoir air falbh [`char`] bhon `String` seo aig suidheachadh byte agus till e.
    ///
    /// Is e obrachadh *O*(*n*) a tha seo, leis gu feum e leth-bhreac a dhèanamh de gach eileamaid den bhufair.
    ///
    /// # Panics
    ///
    /// Panics ma tha `idx` nas motha no co-ionann ri fad an `String`, no mura h-eil e na laighe air crìoch [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Thoir air falbh a h-uile maids de phàtran `pat` anns an `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Thèid geamannan a lorg agus a thoirt air falbh iteratively, mar sin, ann an cùisean far a bheil pàtrain còmhnaidh le chèile, ach a 'chiad pàtran thèid a thoirt air falbh:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // Sàbhailteachd: a 'tòiseachadh agus a cheann a bhios air utf8 Byte crìochan gach
        // na docairean Searcher
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Na glèidh ach na caractaran a tha air an sònrachadh leis an predicate.
    ///
    /// Ann am faclan eile, cuir às do na caractaran `c` gu lèir gus am bi `f(c)` a `tilleadh `false`.
    /// Bidh an dòigh seo ag obair na àite, a `tadhal air gach caractar dìreach aon uair san òrdugh thùsail, agus a` gleidheadh òrdugh nan caractaran glèidhte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Is dòcha gum bi an dearbh òrdugh feumail airson sùil a chumail air stàite a-muigh, mar chlàr-amais.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Puing idx chun ath char
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Cuir a-steach caractar a-steach don `String` seo aig suidheachadh byte.
    ///
    /// Is e obrachadh *O*(*n*) a tha seo oir feumaidh e leth-bhreac a dhèanamh de gach eileamaid den bhufair.
    ///
    /// # Panics
    ///
    /// Panics ma tha `idx` nas motha na fad an 'String`, no mura h-eil e na laighe air crìoch [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Cuir a-steach sliseag sreang a-steach don `String` seo aig suidheachadh byte.
    ///
    /// Is e obrachadh *O*(*n*) a tha seo oir feumaidh e leth-bhreac a dhèanamh de gach eileamaid den bhufair.
    ///
    /// # Panics
    ///
    /// Panics ma tha `idx` nas motha na fad an 'String`, no mura h-eil e na laighe air crìoch [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// A `tilleadh iomradh gluasadach air susbaint an `String` seo.
    ///
    /// # Safety
    ///
    /// Tha an gnìomh seo cunnartach oir chan eil e a `dèanamh cinnteach gu bheil na bytes a chaidh a thoirt dha dligheach UTF-8.
    /// Ma thèid an cuingeachadh seo a bhriseadh, faodaidh e cùisean mì-shàbhailteachd cuimhne adhbhrachadh le luchd-cleachdaidh future den `String`, oir tha an còrr den leabharlann àbhaisteach a `gabhail ris gu bheil` String`s dligheach UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// A `tilleadh fad an `String` seo, ann am bytes, chan e [` char`] s no graphemes.
    /// Ann am faclan eile, is dòcha nach e rud a tha duine a `meas fad na sreang.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// A `tilleadh `true` ma tha fad neoni aig an `String` seo, agus `false` air dhòigh eile.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Roinn an sreang ann an dà leth aig a `chlàr-amais byte a chaidh a thoirt seachad.
    ///
    /// A `tilleadh `String` a chaidh a riarachadh às ùr.
    /// `self` tha bytes `[0, at)` ann, agus tha bytes `[at, len)` anns an `String` a chaidh a thilleadh.
    /// `at` feumaidh a bhith air crìoch puing còd UTF-8.
    ///
    /// Thoir fa-near nach atharraich comas `self`.
    ///
    /// # Panics
    ///
    /// Panics mura h-eil `at` air crìoch puing còd `UTF-8`, no ma tha e nas fhaide na a `phuing còd mu dheireadh den sreang.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Truncates an `String` seo, a `toirt air falbh a h-uile susbaint.
    ///
    /// Ged a tha seo a `ciallachadh gum bi fad neoni aig an `String`, cha bhith e a` suathadh ris a `chomas aige.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// A `cruthachadh itealadair drèanaidh a bheir air falbh an raon ainmichte san `String` agus a bheir toradh den `chars` a chaidh a thoirt air falbh.
    ///
    ///
    /// Note: Tha an raon eileamaid air a thoirt air falbh eadhon mura h-eil an iterator air a chaitheamh gu deireadh.
    ///
    /// # Panics
    ///
    /// Panics mura h-eil an t-àite tòiseachaidh no an t-àite crìochnachaidh na laighe air crìoch [`char`], no ma tha iad a-mach à crìochan.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Thoir air falbh an raon suas gus an β bhon t-sreang
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Bidh làn raon a `glanadh an sreang
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Sàbhailteachd cuimhne
        //
        // Chan eil na cùisean sàbhailteachd cuimhne aig an tionndadh Drain de dhreach sàbhailteachd cuimhne den dreach vector.
        // Tha an dàta dìreach bytes sìmplidh.
        // Leis gu bheil an toirt air falbh raon a `tachairt ann an Drop, ma thèid an iterator Drain a leigeil a-mach, cha tachair an toirt air falbh.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Thoir a-mach dà iasad aig an aon àm.
        // Cha ruigear an &mut String gus am bi an iteachadh seachad, ann an Drop.
        let self_ptr = self as *mut _;
        // SÀBHAILTEACHD: Bidh `slice::range` agus `is_char_boundary` a `dèanamh na sgrùdaidhean crìochan iomchaidh.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Thoir air falbh an raon ainmichte san t-sreang, agus cuir an sreang ainmichte na àite.
    /// Chan fheum an sreang a chaidh a thoirt a bhith den aon fhaid ris an raon.
    ///
    /// # Panics
    ///
    /// Panics mura h-eil an t-àite tòiseachaidh no an t-àite crìochnachaidh na laighe air crìoch [`char`], no ma tha iad a-mach à crìochan.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Cuir an àite an raon suas gus an β bhon t-sreang
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Sàbhailteachd cuimhne
        //
        // Chan eil na cùisean sàbhailteachd cuimhne aig Splice vector aig Replace_range.
        // den dreach vector.Tha an dàta dìreach bytes sìmplidh.

        // RABHADH: Bhiodh a bhith a `mìneachadh an caochlaideach seo mì-chinnteach (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // RABHADH: Bhiodh a bhith a `mìneachadh an caochlaideach seo mì-chinnteach (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Bhiodh cleachdadh `range` a-rithist mì-chinnteach (#81138) Tha sinn a `gabhail ris gum fuirich na crìochan a chaidh aithris le `range` mar an ceudna, ach dh` fhaodadh buileachadh nàimhdeil atharrachadh eadar gairmean
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Bidh e ag atharrachadh an `String` seo gu bhith na [`Box`]`<`[`str`] `>`.
    ///
    /// Leigidh seo sìos comas sam bith a bharrachd.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// A `tilleadh sliseag de [` u8`] s bytes a chaidh feuchainn ri tionndadh gu `String`.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// // cuid de bytes neo-dhligheach, ann an vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// A `tilleadh na bytes a chaidh feuchainn ri tionndadh gu `String`.
    ///
    /// Tha an dòigh seo air a thogail gu faiceallach gus riarachadh a sheachnadh.
    /// Gabhaidh e ris a `mhearachd, a` gluasad a-mach na bytes, gus nach fheumar leth-bhreac de na bytes a dhèanamh.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// // cuid de bytes neo-dhligheach, ann an vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Fetch a `Utf8Error` gus tuilleadh fiosrachaidh fhaighinn mu fhàilligeadh an tionndaidh.
    ///
    /// Tha an seòrsa [`Utf8Error`] a tha [`std::str`] a `toirt seachad a` riochdachadh mearachd a dh `fhaodadh tachairt nuair a thionndaidheas tu sliseag de [` u8`] s gu [`&str`].
    /// Anns an t-seagh seo, tha e na analog gu `FromUtf8Error`.
    /// Faic na sgrìobhainnean aige airson tuilleadh fiosrachaidh mu bhith ga chleachdadh.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// // cuid de bytes neo-dhligheach, ann an vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // tha a `chiad byte neo-dhligheach an seo
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Leis gu bheil sinn ag itealaich thairis air `String`s, is urrainn dhuinn co-dhiù aon riarachadh a sheachnadh le bhith a`faighinn a`chiad sreang bhon iterator agus a` ceangal ris a h-uile sreang a thig às a dhèidh.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Leis gu bheil sinn ag itealaich thairis air CoWs, is urrainn dhuinn (potentially) co-dhiù aon riarachadh a sheachnadh le bhith a `faighinn a` chiad rud agus a `ceangal ris a h-uile rud a thig às a dhèidh.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Impl goireasachd a bhios a `tiomnadh don impl airson `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// A `cruthachadh `String` falamh.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// A `toirt buaidh air a` ghnìomhaiche `+` airson a bhith a `co-dhùnadh dà shreath.
///
/// Bidh seo a `caitheamh an `String` air an làimh chlì agus ag ath-chleachdadh am bufair (ga fhàs ma tha sin riatanach).
/// Tha seo air a dhèanamh gus nach bi thu a `riarachadh `String` ùr agus a` dèanamh lethbhreac den t-susbaint iomlan air a h-uile obrachadh, a bheireadh ùine ruith *O*(*n*^ 2) nuair a thogas tu sreang *n*-byte le ath-bhualadh a-rithist.
///
///
/// Chan eil an sreang air an làimh dheis air iasad ach;thèid na tha ann a chopaigeadh a-steach don `String` a chaidh a thilleadh.
///
/// # Examples
///
/// Tha a bhith a `co-dhùnadh dà` String`s a`toirt a`chiad fhear le luach agus a`faighinn iasad air an dàrna fear:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` air a ghluasad agus chan urrainnear a chleachdadh an seo tuilleadh.
/// ```
///
/// Ma tha thu airson cumail a `cleachdadh a` chiad `String`, faodaidh tu cloneadh agus cuir ris a `chlon na àite:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` fhathast dligheach an seo.
/// ```
///
/// Faodar sliseagan concatenating `&str` a dhèanamh le bhith a `tionndadh a` chiad fhear gu `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// A `cur an gnìomh gnìomhaiche `+=` airson a chuir a-steach gu `String`.
///
/// Tha an aon ghiùlan aig an seo ris an dòigh [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Alias seòrsa airson [`Infallible`].
///
/// Tha an ailias seo ann airson co-fhreagarrachd air ais, agus is dòcha nach tèid a mholadh aig a `cheann thall.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// A trait airson luach a thionndadh gu `String`.
///
/// Tha an trait seo air a chuir an gnìomh gu fèin-ghluasadach airson seòrsa sam bith a chuireas an [`Display`] trait an gnìomh.
/// Mar sin, cha bu chòir `ToString` a bhith air a bhuileachadh gu dìreach:
/// [`Display`] Bu chòir a chur an gnìomh an àite, agus gheibh thu an `ToString` cur an gnìomh an-asgaidh.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Bidh e ag atharrachadh an luach a chaidh a thoirt gu `String`.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Anns a `bhuileachadh seo, an dòigh `to_string` panics ma thilleas buileachadh `Display` mearachd.
/// Tha seo a `comharrachadh buileachadh `Display` ceàrr leis nach till `fmt::Write for String` mearachd fhèin a-riamh.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Is e stiùireadh cumanta gun a bhith a `toirt a-steach gnìomhan coitcheann.
    // Ach, le bhith a `toirt air falbh `#[inline]` bhon dòigh seo ag adhbhrachadh ath-thilleadh neo-dearmadach.
    // Faic <https://github.com/rust-lang/rust/pull/74852>, an oidhirp mu dheireadh gus feuchainn ri a thoirt air falbh.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Bidh e ag atharrachadh `&mut str` gu `String`.
    ///
    /// Tha an toradh air a riarachadh air an tiùrr.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: deuchainn a `tarraing ann an libstd, a dh` adhbhraicheas mearachdan an seo
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Bidh e ag atharrachadh an sliseag `str` bogsaichte gu `String`.
    /// Tha e inntinneach gu bheil seilbh aig an sliseag `str`.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Bidh e ag atharrachadh an `String` a chaidh a thoirt seachad gu sliseag `str` ann am bogsa a tha ann an seilbh.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Bidh e ag atharrachadh sliseag sreang gu tionndadh Borrowed.
    /// Chan eilear a `dèanamh riarachadh tiùrr, agus chan eilear a` dèanamh lethbhreac den sreang.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Bidh e ag atharrachadh sreang gu tionndadh seilbh.
    /// Chan eilear a `dèanamh riarachadh tiùrr, agus chan eilear a` dèanamh lethbhreac den sreang.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Bidh e ag atharrachadh iomradh String gu caochladh air iasad.
    /// Chan eilear a `dèanamh riarachadh tiùrr, agus chan eilear a` dèanamh lethbhreac den sreang.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Converts an `String` thoirt gu vector `Vec` a 'cumail luachan seòrsa `u8`.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Iterator drèanaidh airson `String`.
///
/// Tha an structar seo air a chruthachadh leis an dòigh [`drain`] air [`String`].
/// Faic na sgrìobhainnean aige airson tuilleadh.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Thèid a chleachdadh mar&'a mut String anns an inneal-sgrios
    string: *mut String,
    /// Toiseach pàirt ri thoirt air falbh
    start: usize,
    /// Deireadh a `phàirt airson a thoirt air falbh
    end: usize,
    /// Raon gnàthach a tha air fhàgail airson a thoirt air falbh
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Cleachd Vec::drain.
            // "Reaffirm" na sgrùdaidhean crìochnachaidh gus nach tèid còd panic a chuir a-steach a-rithist.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// A `tilleadh an sreang (fo) eile den iterator seo mar sliseag.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: uncomment AsRef impls gu h-ìosal nuair a bhios tu a `dèanamh seasmhach.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Uncomment nuair a bhios tu a `dèanamh seasmhach air `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>airson Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> airson Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}