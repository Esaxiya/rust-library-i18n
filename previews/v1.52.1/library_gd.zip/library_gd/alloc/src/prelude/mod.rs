//! An riarachadh Prelude
//!
//! Is e adhbhar a `mhodal seo lasachadh a dhèanamh air in-mhalairt de nithean a chleachdar gu cumanta den `alloc` crate le bhith a` cur in-mhalairt glob gu mullach nam modalan:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;