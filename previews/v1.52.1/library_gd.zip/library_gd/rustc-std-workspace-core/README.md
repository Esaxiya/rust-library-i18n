# An `rustc-std-workspace-core` crate

'S e seo crate Shìm agus falamh crate a tha dìreach a' crochadh air `libcore` agus reexports h-uile a th 'ann.
Tha crate tha an Crux de cumhachdachadh an ìre leabharlainn crochadh air crates bho crates.io

Crates air crates.io gu bheil an ìre leabharlainn crochadh air an fheum a tha an crochadh air an `rustc-std-workspace-core` crate bho crates.io, a tha falamh.

Bidh sinn a `cleachdadh `[patch]` gus a dhol thairis air an crate san ionad-tasgaidh seo.
Mar thoradh air, crates air crates.io a bhios a 'tarraing a-eisimeileachd edge gu `libcore`, an dreach seo air a mhìneachadh ann an ionad-tasgaidh.
A bu chòir a tharruing a h-uile eisimeileachd oirean gus dèanamh cinnteach Cargo crates a 'togail gu soirbheachail!

Thoir fa-near gum feum crates air crates.io a bhith an urra ris an crate seo leis an ainm `core` airson gum bi a h-uile càil ag obair ceart.Airson sin a dhèanamh faodaidh iad:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Tro bhith a `cleachdadh an iuchair `package` tha an crate air ath-ainmeachadh gu `core`, a` ciallachadh gum bi e coltach

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

nuair a Cargo invokes a 'cruinneachadh, a' sàsachadh fillte a-staigh `extern crate core` Stiùireadh stealladh le compiler.




