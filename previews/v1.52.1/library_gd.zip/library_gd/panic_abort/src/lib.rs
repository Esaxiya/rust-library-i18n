//! Cur an gnìomh Rust panics tro ghinean pròiseas
//!
//! Nuair a thèid an coimeas ris a `bhuileachadh tro bhith a` falamhachadh, tha an crate seo *tòrr* nas sìmplidh!Le bhith ga ràdh, chan eil e idir cho ioma-chruthach, ach seo e!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" an t-uallach pàighidh agus gluasad chun a 'ghiorraidh iomchaidh air an àrd-ùrlar sin.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // cuir fòn gu std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Air Windows, cleachd an uidheamachd __fastfail a tha sònraichte don phròiseasar.Ann Windows 8 agus an dèidh sin, bidh seo crìoch a chur air a 'phròiseas a' ruith anns a 'bhad gun sam bith ann ach a-mhàin phròiseas-treòrachaidh.
            // Ann an dreachan nas tràithe de Windows, thèid an sreath seo de stiùiridhean a làimhseachadh mar bhriseadh ruigsinneachd, a `toirt a` phròiseas gu crìch ach gun a bhith a `seachnadh a h-uile neach-làimhseachaidh eisgeachd.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: 'S e seo an aon buileachadh mar ann libstd aig `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Tha seo ... rud beag neònach.An tl; dr;is gu feumar seo a cheangal gu ceart, tha am mìneachadh nas fhaide gu h-ìosal.
//
// Right a-nis a 'binaries de libcore/libstd soitheach gu bheil sinn uile air a chur ri chèile le `-C panic=unwind`.Tha seo air a dhèanamh gus dèanamh cinnteach gu bheil an binaries maximally a tha co-chòrdail le mòran mar an suidheachaidhean sa ghabhas.
// Tha a chur ri chèile, ge-tà, a 'cur feum "personality function" airson a h-uile gnìomhan a chur ri chèile le `-C panic=unwind`.Tha an gnìomh pearsantachd seo air a chòdachadh gu cruaidh ris an t-samhla `rust_eh_personality` agus tha e air a mhìneachadh leis an nì `eh_personality` lang.
//
// So...
// dìreach a 'mìneachadh carson nach lang a' phìos seo?Math ceist!Tha an dòigh anns a bheil amannan ruith panic ceangailte ann an da-rìribh beagan leis gu bheil iad "sort of" ann an stòr crate an trusaiche, ach dìreach ceangailte mura h-eil ceangal eile ann.
//
// Tha seo a 'cinn suas a' ciallachadh gu bheil an dà chuid an seo crate agus an panic_unwind crate urrainn a 'nochdadh ann an cruinneachadh a crate stòr, agus ma tha an dà chuid mìneachadh an `eh_personality` lang phìos an uair sin bidh bhuail mearachd.
//
// Gus seo a làimhseachadh chan fheum an trusaiche ach an `eh_personality` a mhìneachadh ma tha an ùine ruith panic ceangailte ann an ùine ruith gun fhios, agus air dhòigh eile chan fheumar a mhìneachadh (mar sin gu ceart).
// Anns a 'chùis seo, ge-tà, dìreach a' mìneachadh seo leabharlainn seo samhla mar sin co-dhiù cuid pearsa an àiteigin.
//
// Bunaiteach seo samhla dìreach a mhìneachadh gus a dhol suas gu wired libcore/libstd binaries, ach nach bu chòir a bhith air a gairm mar nach eil sinn a 'ceangal ann an unwinding runtime aig na h-uile.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Air x86_64-pc-uinneagan-gnu sinn a 'cleachdadh againn fhèin pearsantachd ghnìomh a dh'fheumas a thilleadh `ExceptionContinueSearch` mar a tha sinn a' dol seachad air ar n-uile fhrèamaichean.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Coltach ris gu h-àrd, tha seo a `freagairt ris an nì `eh_catch_typeinfo` lang nach eil air a chleachdadh ach air Emscripten an-dràsta.
    //
    // Bho panics ach a-mhàin Chan eil ghineadh agus cèin ach a-mhàin an-dràsta UB le -C panic=abort (ged a dh'fhaodadh seo a bhith fo ùmhlachd atharrachadh), sam bith catch_unwind gairmean gu bràth a 'cleachdadh seo typeinfo.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Canar na dhà againn leis na stuthan tòiseachaidh againn air i686-pc-windows-gnu, ach chan fheum iad dad a dhèanamh gus am bi na cuirp nan lìn.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}