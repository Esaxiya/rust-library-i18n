//! Gun iarraidh airson targaid *wasm32*.
//!
//! An-dràsta chan eil sinn a `toirt taic dha seo, agus mar sin chan eil seo ach stubs.

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    intrinsics::abort()
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    intrinsics::abort()
}