//! Unwinding panics airson Miri.
use alloc::boxed::Box;
use core::any::Any;

// Tha an seòrsa de payload gu bheil an Miri einnsean propagates tro unwinding dhuinn.
// Feumaidh meud pointer a bhith ann.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Dreuchd taobh a-muigh air a sholarachadh le Miri gus tòiseachadh a `falamhachadh.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Tha payload sinn seachad gu `miri_start_panic` bidh an dearbh argamaid a gheibh sinn ann an `cleanup` gu h-ìosal.
    // Mar sin bidh sinn dìreach ga bhogsa suas aon uair, gus rudeigin meud-puing fhaighinn.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Faigh air ais an `Box` bunaiteach.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}