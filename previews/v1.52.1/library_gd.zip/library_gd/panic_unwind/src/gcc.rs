//! Buileachadh panics le taic bho libgcc/libunwind (ann an cruth air choreigin).
//!
//! Airson chùl air eisgeachd a làimhseachadh agus cruach unwinding faicibh "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) agus sgrìobhainnean co-cheangailte às.
//! Tha iad sin math cuideachd:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Geàrr-chunntas goirid
//!
//! Bidh làimhseachadh eisgeachd a `tachairt ann an dà ìre: ìre sgrùdaidh agus ìre glanaidh.
//!
//! Ann an dà ìre a 'unwinder cuairtean cruach buird o bhàrr gu bonn a' cleachdadh fiosrachadh bho na cruach frèam unwind earrannan an-dràsta a 'phròiseas modalan ("module" seo a' buntainn ris an t-Suirbhidh Òrdanais modal, ie, an executable no fiùghantach leabharlainn).
//!
//!
//! Airson gach cruach frèam, tha e invokes co-cheangailte "personality routine", aig a bheil seòladh cuideachd a 'stòradh ann an unwind info earrann.
//!
//! Anns an ìre rannsachaidh, is e obair gnàthach pearsantachd a bhith a `sgrùdadh nì a tha air a thilgeil, agus a thighinn gu co-dhùnadh am bu chòir a ghlacadh aig an fhrèam stac sin.Aon uair 'an cìobair frèam air a chomharrachadh, cleanup ìre a' tòiseachadh.
//!
//! Ann an cleanup-cheum, an unwinder invokes gach pearsa gnàthach a-rithist.
//! An turas seo tha e co-dhùnadh a (ma) cleanup code feumalachdan gu bhith a 'ruith airson na cruach cèis.Ma tha, tha an smachd air a ghluasad gu branch sònraichte anns a `bhuidheann gnìomh, an "landing pad", a bheir ionnsaigh air luchd-sgrios, a` saoradh cuimhne, msaa.
//! Aig deireadh a 'tighinn air tìr pad, smachd air a ghluasad air ais gu unwinder agus unwinding Prògram.
//!
//! Aon uair `s gu bheil an stac air a leigeil sìos gu ìre frèam an neach-làimhseachaidh, stadaidh stadan agus bidh an cleachdadh pearsantachd mu dheireadh a` gluasad smachd chun bhloc glacaidh.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust a 'chlas ach a-mhàin aithnichear.
// Tha seo air a chleachdadh le pearsantachd cleachdaidhean gus co-dhùnadh a chaidh a thilgeil ach a-mhàin le aca fhèin runtime.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-reiceadair, cànan
    0x4d4f5a_00_52555354
}

// Chaidh ids clàraidh a thogail bho LLVM's TargetLowering::getExceptionPointerRegister() agus TargetLowering::getExceptionSelectorRegister() airson gach ailtireachd, agus an uairsin air am mapadh gu àireamhan clàraidh DWARF tro chlàran mìneachadh clàr (mar as trice<arch>RegisterInfo.td, lorg "DwarfRegNum").
//
// Faic cuideachd http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Tha an còd a leanas stèidhichte air cleachdaidhean pearsantachd C agus C++ GCC.Airson fiosrachadh, faic:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM Gnìomh pearsantachd EHABI.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS a `cleachdadh an cleachdadh àbhaisteach an àite seach gu bheil e a` cleachdadh SjLj a `falamhachadh.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Canaidh backtraces air ARM an cleachdadh pearsantachd le state==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Anns na cùisean sin tha sinn airson cumail oirnn a `falamhachadh na cruaich, air neo bhiodh na cùl-stòran againn uile a` tighinn gu crìch aig __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // An troich unwinder_Unwind_Context gabhail ris gu bheil a 'cumail rudan mar an gnìomh agus LSDA Pointers, ge-tà ARM EHABI gan cur a-steach ach a-mhàin nì.
            // A ghleidheadh ainmean-sgrìobhte de dhreuchdan mar _Unwind_GetLanguageSpecificData(), a 'gabhail a-mhàin an co-theacsa na chomharra, GCC pearsantachd cleachdaidhean stash a chomharra air exception_object ann an co-theacsa, a' cleachdadh briosgaidean location airson ARM aig "scratch register" (r12).
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Tha tuilleadh prìomh modh-obrach a bhiodh a 'toirt an làn mhìneachadh air ARM aig_Unwind_Context ann ar libunwind bindings agus a dh'iarraidh an dhìth dàta bho sin gu dìreach, bypassing Dwarf-chòrdalachd dreuchdan.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // Tha EHABI ag iarraidh air a `chleachdadh pearsantachd ùrachadh a dhèanamh air luach SP ann an tasgadan cnap-starra an nì eisgeachd.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Air ARM EHABI tha e mar dhleastanas air a `chleachdadh pearsantachd gun a bhith a` dìochuimhneachadh aon fhrèam cruachan mus till e (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // air a mhìneachadh ann an libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Gnìomh pearsantachd bunaiteach, a tha air a chleachdadh gu dìreach air a `mhòr-chuid de thargaidean agus gu neo-dhìreach air Windows x86_64 tro SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Air x86_64 MinGW targaidean, unwinding innleachd SEH Ach an cìobair unwind dàta (aka LSDA) a 'cleachdadh GCC-chòrdail còdachadh.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // An dòigh pearsantachd airson a `mhòr-chuid de na targaidean againn.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // A 'tilleadh dèiligeadh ri puingean 1 Byte seachad air an gairm teagasg, a dh'fhaodadh a bhith ann an ath IP raon LSDA ann an raon a' bhùird.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Frame gun chlàradh fiosrachaidh
//
// Ann an ìomhaigh gach modal tha earrann fiosrachaidh neo-fhiosrachail frèam (mar as trice ".eh_frame").Nuair a bhios am modal loaded/unloaded-steach don phròiseas, a 'unwinder feumar innse mu na location den earrann seo mar chuimhneachan air.Tha na dòighean sin a choileanadh ag atharrachadh a rèir an àrd-chabhsair.
// Air cuid (me, Linux), faodaidh an neach-dìolaidh earrannan fiosrachaidh neo-fhiosrachail a lorg leotha fhèin (le bhith ag àireamhachadh modalan luchdaichte an-dràsta tron dl_iterate_phdr() API and finding their ".eh_frame" sections); Tha cuid eile, mar Windows, ag iarraidh air modalan na h-earrannan fiosrachaidh neo-fhiosrachail aca a chlàradh tro API neo-fhiosrachaidh.
//
//
// Tha am modal seo a `mìneachadh dà shamhla air a bheil iomradh agus air an gairm bho rsbegin.rs gus ar fiosrachadh a chlàradh le ùine ruith GCC.
// Tha cur an gnìomh a tha cruach unwinding (oir a nis) a chur dheth chun libgcc_eh, ge-tà Rust crates sin a chleachdadh Rust-inntrig puingean sònraichte a sheachnadh a dh'fhaodadh a bhith air còmhstri sam bith GCC runtime.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}