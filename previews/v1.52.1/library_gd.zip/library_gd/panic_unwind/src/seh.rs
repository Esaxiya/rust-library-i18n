//! Windows SEH
//!
//! Air Windows (an-dràsta dìreach air MSVC), is e an dòigh làimhseachaidh eisgeachd àbhaisteach Làimhseachadh Eisgeachd Structaraichte (SEH).
//! Tha seo gu math eadar-dhealaichte seach Dwarf stèidhichte ach a-mhàin làimhseachadh (me, dè eile unix àrd-chabhsairean a 'cleachdadh) a thaobh compiler internals, mar sin LLVM tha a dhìth gu math fada a bharrachd taic airson SEH.
//!
//! Gu h-aithghearr, is e na thachras an seo:
//!
//! 1. Tha `panic` gnìomh ag iarraidh an ìre Windows gnìomh `_CxxThrowException` a thilgeil a C++ -mar an ceudna, a triggering an unwinding phròiseas.
//! 2.
//! A h-uile tìr ceapan a chruthachadh leis an compiler cleachdadh pearsantachd gnìomh `__CxxFrameHandler3`, tha fuincsean ann an CRT, agus unwinding code ann Windows Thèid seo a chleachdadh pearsantachd gnìomh gus an gnìomh a h-uile cleanup còd air a 'chruach.
//!
//! 3. All compiler-ghineadh gairmean gu `invoke` tha tìr pad seata mar `cleanuppad` LLVM teagasg, a 'sealltainn toiseach a' cleanup àbhaisteach.
//! Tha pearsantachd ('san ceum 2, a mhìneachadh ann an CRT) a tha uallach airson ruith na cleanup cleachdaidhean.
//! 4. Mu dheireadh tha an còd "catch" anns an `try` intrinsic (air a ghineadh leis an trusaiche) air a chur gu bàs agus a `nochdadh gum bu chòir smachd a thighinn air ais gu Rust.
//! Tha seo air a dhèanamh tro stiùireadh `catchswitch` a bharrachd air stiùireadh `catchpad` ann an teirmean LLVM IR, mu dheireadh a `tilleadh smachd àbhaisteach chun phrògram le stiùireadh `catchret`.
//!
//! Nithean sònraichte eadar-dhealachaidhean bhon gcc stèidhichte ach a-mhàin làimhseachadh tha:
//!
//! * Chan eil gnìomh pearsantachd àbhaisteach aig Rust, tha e an àite *an-còmhnaidh*`__CxxFrameHandler3`.A bharrachd air an sin, cha tèid sìoladh a bharrachd a dhèanamh, agus mar sin bidh sinn a `tighinn gu crìch a` glacadh eisgeachdan C++ sam bith a bhios a `coimhead coltach ris an t-seòrsa a tha sinn a` tilgeil.
//! Cuimhnich gur tilgeil eisgeachd a-steach Rust tha undefined giùlan co-dhiù, mar sin, bu chòir seo a bhith grinn.
//! * Tha sinn an d 'fhuair cuid de dàta air a sgaoileadh air feadh na unwinding chrìoch, gu sònraichte a `Box<dyn Any + Send>`.Coltach ri Dwarf ach a-mhàin an dà Pointers a stòradh mar payload ann ach a-mhàin fhèin.
//! Air MSVC, ge-tà, chan eil feum airson a bharrachd charn riarachadh oir ghairm cruach a ghleidheadh fhad 'sa Criathrag gnìomhan a thathar a chur gu bàs.
//! Tha seo a 'ciallachadh gu bheil an Pointers a' dol gu dìreach do `_CxxThrowException` a tha an uair sin air ais a dhreuchd ann an criathar a sgrìobhadh gu 'chruaich frèam de na `try` ghnèitheach.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Feumaidh seo a bhith air sgàth an Roghainn sinn a ghlacadh ach a-mhàin le iomradh agus a destructor Tha bàs leis an C++ runtime.
    // Nuair a bhios sinn a 'gabhail an Box a-mach às ach a-mhàin, feumaidh sinn fhàgail ach a-mhàin ann an staid dligheach airson a bhith a' ruith gun destructor-dùbailte 'leigeil a' bhogsa.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// An toiseach, dòrlach de mhìneachaidhean seòrsa.Tha corra-àrd-ùrlar sònraichte oddities an seo, agus tòrr a tha a 'blatantly lethbhreacadh bho LLVM.'S e adhbhar na h-uile a tha seo a chur an gnìomh `panic` gnìomh gu h-ìosal tro gairm gu `_CxxThrowException`.
//
// A 'ghnìomh seo a' toirt dà-argamaidean.Tha a 'chiad chomharra air an dàta a tha sinn a' dol ann, a tha sa chùis seo a tha againn trait nì.Gu math furasta a lorg!An ath, ge-tà, tha e nas iom-fhillte.
// Tha seo na chomharradh air structar `_ThrowInfo`, agus sa chumantas thathas an dùil dìreach cunntas a thoirt air an eisgeachd a thathas a `tilgeil.
//
// An-dràsta tha am mìneachadh den t-seòrsa [1] seo beagan fuilt, agus is e am prìomh rud neònach (agus eadar-dhealachadh bhon artaigil air-loidhne) gu bheil na molaidhean air 32-bit ach air 64-bit tha na molaidhean air an cur an cèill mar fhrith-rathaidean 32-bit bhon Ìomhaigh `__ImageBase`.
//
// Tha am macro `ptr_t` agus `ptr!` anns na modalan gu h-ìosal air an cleachdadh gus seo a chuir an cèill.
//
// Bidh a `chuartan de mhìneachaidhean seòrsa cuideachd a` leantainn gu dlùth na tha LLVM a `sgaoileadh airson an seòrsa obrachaidh seo.Mar eisimpleir, ma tha thu seo a chur ri chèile C++ code air MSVC-mach agus an LLVM IR:
//
//      #include <stdint.h>
//
//      structar rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      Void foo() { rust_panic a = {0, 1};
//          tilg a;}
//
// Sin an ìre mhath na tha sinn a 'feuchainn ri emulate.Chaidh a `mhòr-chuid de na luachan seasmhach gu h-ìosal a chopaigeadh bho LLVM,
//
// Ann an suidheachadh sam bith, tha na structaran sin uile air an togail san aon dòigh, agus tha e dìreach rudeigin labhairteach dhuinn.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Thoir fa-near gu bheil sinn a `seachnadh riaghailtean riaghlaidh ainmean an seo: chan eil sinn airson gum bi C++ comasach air Rust panics a ghlacadh le bhith dìreach ag ainmeachadh `struct rust_panic`.
//
//
// Nuair a bhios tu ag atharrachadh, dèan cinnteach gu bheil an sreang ainm seòrsa a `maidseadh gu dìreach ris an fhear a chaidh a chleachdadh ann an `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Tha thoiseach `\x01` Byte seo an da-rìribh draoidheil chomharran a LLVM gu *Cha* cur a-steach sam bith eile mangling mar prefixing le `_` caractar.
    //
    //
    // 'S e samhla seo air a chleachdadh le na vtable C++ ' s `std::type_info`.
    // Tha comharran den t-seòrsa `std::type_info`, tuairisgeulan seòrsa, aig a `chlàr seo.
    // Tha tuairisgeulan seòrsa air an ainmeachadh leis na structaran C++ EH a tha air am mìneachadh gu h-àrd agus a bhios sinn a `togail gu h-ìosal.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Chan eil an tuairisgeul seòrsa seo air a chleachdadh ach nuair a thathar a `tilgeil eisgeachd.
// Tha iasg a 'phàirt a làimhseachadh le Feuch ghnèitheach, a tha a' gineadh aice fhèin TypeDescriptor.
//
// 'S e seo breagha bho na MSVC runtime cleachdaidhean coimeas sreang air an t-seòrsa-ainm gu gèam TypeDescriptors seach a bhith na chomharra air co-ionannachd.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Sgriosadair air a chleachdadh ma cho-dhùnas còd C++ an eisgeachd a ghlacadh agus a leigeil às gun a bhith ga iomadachadh.
// An t-iasg na phàirt de Feuch ghnèitheach cuiridh a 'chiad focal ach a-mhàin a nì 0 sin a tha e a' leum le destructor.
//
// Thoir fa-near gu bheil x86 Windows a `cleachdadh co-chruinneachadh gairm "thiscall" airson gnìomhan ball C++ an àite a` chùmhnant gairm "C" bunaiteach.
//
// Tha exception_copy ghnìomh a tha car sònraichte seo: tha e invoked le MSVC runtime fo try/catch bacaidh agus an panic gu bheil sinn a ghineadh an seo thèid a chleachdadh mar thoradh air an leth-bhreac ach a-mhàin.
//
// Tha seo air a chleachdadh leis an C++ runtime gus taic a ghlacadh ach a-mhàin le std::exception_ptr, a tha, chan urrainn dhuinn taic a thoirt air sgàth 'Box<dyn Any>Chan eil clonable.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // Bidh_CxxThrowException a `cur gu bàs gu tur air an fhrèam stac seo, agus mar sin cha leigear a leas `data` a ghluasad chun tiùrr.
    // Tha sinn dìreach a 'dol seachad cruach chomharra air a' ghnìomh seo.
    //
    // Tha feum air an ManuallyDrop an seo leis nach eil sinn ag iarraidh gun tèid Eisgeachd a leigeil seachad nuair a thig e a-mach.
    // An àite sin bidh e a 'tuiteam exception_cleanup a tha invoked leis an C++ runtime.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Seo ... faodaidh e iongnadh air, agus mar sin airidh air.Air an 32-bit MSVC an Pointers eadar na structar a tha dìreach sin, Pointers.
    // Air MSVC 64-bit, ge-tà, tha na comharran eadar structaran air an cur an cèill mar fhrith-rathaidean 32-bit bho `__ImageBase`.
    //
    // Mar sin, air 32-bit MSVC faodaidh sinn cur an cèill sin uile Pointers ann an `static`s h-àrd.
    // Air an 64-bit MSVC, a bhiodh againn air a chur an cèill ann an toirt air falbh Pointers statics, a Rust Chan eil an-dràsta a 'ceadachadh, agus mar sin chan urrainn dhuinn dha-rìribh a' dèanamh sin.
    //
    // Is e an ath rud as fheàrr, an uairsin na structaran sin a lìonadh a-steach aig àm-ruith (tha panicking mar-thà mar an "slow path" co-dhiù).
    // Mar sin an seo bidh sinn ag ath-mhìneachadh a h-uile gin de na raointean puing sin mar integers 32-bit agus an uairsin a `stòradh an luach buntainneach a-steach dha (gu h-atamach, mar a dh` fhaodadh gum bi panics co-aimsireil a `tachairt).
    //
    // Gu teicnigeach is dòcha gun dèan an ùine ruith leughadh neo-riaghailteach de na raointean sin, ach gu teòiridh cha leugh iad an luach *ceàrr* agus mar sin cha bu chòir dha a bhith ro dhona ...
    //
    // Ann an cùis sam bith, feumaidh sinn na fìrinn rudeigin a dhèanamh mar seo gus an urrainn dhuinn a chur an cèill barrachd ann an obraichean statics (agus faodaidh sinn a-riamh a bhith comasach).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Tha uallach pàighidh NULL an seo a `ciallachadh gun d` fhuair sinn an seo bhon glacadh (...) de __rust_try.
    // Bidh seo a `tachairt nuair a thèid eisgeachd cèin neo-Rust a ghlacadh.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Feumaidh an t-inneal-cruinneachaidh a bhith ann (me, is e rud lang a th `ann), ach cha bhith an neach-cruinneachaidh a-riamh ag ainmeachadh oir is e __C_specific_handler no_except_handler3 an gnìomh pearsantachd a tha an-còmhnaidh air a chleachdadh.
//
// Mar sin chan eil an seo ach stob anabarrach.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}