//! Buileachadh panics tro cruach unwinding
//!
//! Tha seo a 'crate tha buileachadh panics ann Rust cleachdadh "most native" cruach unwinding uidheamachd an àrd-chabhsair seo ga chur ri chèile airson.
//! Tha seo gu riatanach air a roinn ann an trì bucaid an-dràsta:
//!
//! 1. Bidh targaidean MSVC a `cleachdadh SEH anns an fhaidhle `seh.rs`.
//! 2. Emscripten C++ a 'cleachdadh ach a-mhàin ann an `emcc.rs` faidhle.
//! 3. Bidh na targaidean eile gu lèir a `cleachdadh libunwind/libgcc anns an fhaidhle `gcc.rs`.
//!
//! Gheibhear barrachd sgrìobhainnean mu gach buileachadh anns a `mhodal fa leth.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` air a cleachdadh le Miri, sàmhchair cho rabhaidhean.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Tha nithean tòiseachaidh Rust runtime an urra ris na samhlaidhean sin, mar sin dèan poblach iad.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Targaidean nach cuir taic ri bhith a `falamhachadh.
        // - arch=wasm32
        // - os=gin (targaidean "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Cleachd na Miri runtime.
        // Feumaidh sinn fhathast cuideachd a luchdadh àbhaisteach runtime gu h-àrd, mar rustc lang an dùil cuid de nithean bho sin gu bhith air a mhìneachadh.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Cleachd an fhìor ùine ruith.
        use real_imp as imp;
    }
}

extern "C" {
    /// Neach-làimhseachaidh ann an libstd ris an canar nuair a thèid rud panic a leigeil sìos taobh a-muigh `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler ann libstd ghairm nuair cèin ach a-mhàin air a ghlacadh.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Clàir phuing airson togail eisgeachd, dìreach riochdairean an àrd-ùrlar sònraichte a chur an gnìomh.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}