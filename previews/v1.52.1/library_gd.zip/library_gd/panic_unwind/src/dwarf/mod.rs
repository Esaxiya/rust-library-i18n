//! Goireasan airson parsadh sruthan dàta DWARF-encoded.
//! Faic inbhe <http://www.dwarfstd.org>, DWARF-4, Earrann 7, "Data Representation"
//!

// Chan eil am modal seo air a chleachdadh ach le x86_64-pc-windows-gnu airson a-nis, ach tha sinn ga chur ri chèile anns a h-uile àite gus regressions a sheachnadh.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // Tha sruthan DWARF air am pacadh, mar sin me, is dòcha nach biodh u32 air a cho-thaobhadh air crìoch 4-byte.
    // Faodaidh seo duilgheadasan adhbhrachadh air àrd-ùrlaran le riatanasan teann co-thaobhadh.
    // Le bhith a `pasgadh dàta ann an structar "packed", tha sinn ag innse don backend còd "misalignment-safe" a ghineadh.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // Tha còdan ULEB128 agus SLEB128 air am mìneachadh ann an Earrann 7.6, "Variable Length Data".
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}