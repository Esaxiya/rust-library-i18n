//! `Cell` caochlaideach airson amannan beatha (scoped).

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// Seòrsa tagradh lambda, le beatha.
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// Seòrsa lambda a `toirt fad beatha, ie, `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) projection obair timcheall air an cuingealachadh le newtype FIXME(#52812) àite le `&'a mut <T as ApplyL<'b>>::Out`
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// A `suidheachadh an luach ann an `self` gu `replacement` fhad` s a tha e a `ruith `f`, a gheibh an seann luach, gu siùbhlach.
    /// Tha seann bidh luach a thoirt air ais an dèidh `f` slighean a-mach, fiù 's le panic, nam measg atharrachaidhean a dhèanamh ris le `f`.
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// Còmhdach a 'dèanamh cinnteach gu bheil an cealla-còmhnaidh a' dol a lìonadh (le tùsail atharrachadh, optionally atharrachadh le `f`), fiù 's ma bha `f` chlisg.
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// A `suidheachadh an luach ann an `self` gu `value` fhad` s a tha thu a `ruith `f`.
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}