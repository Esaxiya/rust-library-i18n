# An `rustc-std-workspace-std` crate

Faic sgrìobhainnean airson an `rustc-std-workspace-core` crate.