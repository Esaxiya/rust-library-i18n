# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Leabharlann airson a bhith a `faighinn backtraces aig àm-ruith airson Rust.
Tha an leabharlann seo ag amas air taic na leabharlann àbhaisteach a neartachadh le bhith a `toirt seachad eadar-aghaidh prògramaichte airson obrachadh leis, ach tha e cuideachd a` toirt taic do bhith a `clò-bhualadh an cùl-raon gnàthach mar panics libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Gus dìreach cùl-raon a ghlacadh agus dàil a chuir air dèiligeadh ris gu àm nas fhaide air adhart, faodaidh tu an seòrsa `Backtrace` àrd-ìre a chleachdadh.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Ach, ma tha thu ag iarraidh barrachd ruigsinneachd amh air an fhìor obair lorg, faodaidh tu na gnìomhan `trace` agus `resolve` a chleachdadh gu dìreach.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Rèitich am putan stiùiridh seo gu ainm samhla
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // cùm a `dol chun ath fhrèam
    });
}
```

# License

Tha am pròiseact seo ceadaichte fo aon seach aon

 * Ceadachas Apache, Tionndadh 2.0, ([LICENSE-APACHE](LICENSE-APACHE) no http://www.apache.org/licenses/LICENSE-2.0)
 * Cead MIT ([LICENSE-MIT](LICENSE-MIT) no http://opensource.org/licenses/MIT)

aig do roghainn.

### Contribution

Mura h-eil thu ag innse a chaochladh, bidh tabhartas sam bith a chaidh a chuir a-steach a dh`aona ghnothach airson a thoirt a-steach ann an backtrace-rs leat, mar a tha e air a mhìneachadh ann an cead Apache-2.0, air a cheadachadh gu dùbailte mar gu h-àrd, gun chumhachan no cumhaichean a bharrachd.







