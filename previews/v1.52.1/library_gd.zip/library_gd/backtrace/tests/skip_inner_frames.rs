use backtrace::Backtrace;

// Chan obraich an deuchainn seo ach air àrd-ùrlaran aig a bheil gnìomh `symbol_address` obrach airson frèamaichean a tha ag aithris seòladh tòiseachaidh samhla.
// Mar thoradh air an sin chan eil e air a chomasachadh ach air beagan àrd-ùrlaran.
//
const ENABLED: bool = cfg!(all(
    // Windows cha deach a dhearbhadh gu fìor, agus chan eil OSX a `toirt taic dha-rìribh a bhith a` lorg frèam cuairteachaidh, mar sin cuir dheth seo
    //
    target_os = "linux",
    // Air ARM a `lorg a` ghnìomh cuairteachaidh dìreach a `tilleadh an ip fhèin.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}