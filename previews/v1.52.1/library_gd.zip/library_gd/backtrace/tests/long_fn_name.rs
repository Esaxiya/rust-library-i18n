use backtrace::Backtrace;

// Ainm modal 50-caractar
mod _234567890_234567890_234567890_234567890_234567890 {
    // Ainm structair 50-caractar
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// Feumar ainmean gnìomh fada a theàrnadh gu (MAX_SYM_NAME, 1) caractaran.
// Chan eil ach deuchainn seo a ruith airson msvc, bho gnu Prints "<no info>" airson a h-uile fhrèamaichean.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // 10 ath-aithris de ainm structair, mar sin is e ainm gnìomh làn theisteanas atleast 10 *(50 + 50)* 2=2000 caractar a dh `fhaid.
    //
    // Tha e nas fhaide gu dearbh leis gu bheil e cuideachd a `toirt a-steach `::`, `<>` agus ainm a` mhodal gnàthach
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}