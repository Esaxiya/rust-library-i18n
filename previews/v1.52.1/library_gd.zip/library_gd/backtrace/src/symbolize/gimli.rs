//! Taic airson samhlachadh a `cleachdadh an `gimli` crate air crates.io
//!
//! Is e seo am buileachadh samhlachaidh bunaiteach airson Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // is e breug a th `ann am beatha statach a bhith a` slaodadh timcheall air dìth taic airson structaran fèin-iomraidh.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Tionndadh gu 'beatha statach oir cha bu chòir dha na samhlaidhean iasad ach `map` agus `stash` agus tha sinn gan gleidheadh gu h-ìosal.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Airson leabharlannan dùthchasach a luchdachadh air Windows, faic beagan deasbaid air rust-lang/rust#71060 airson na diofar ro-innleachdan an seo.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Chan eil leabharlannan MinGW an-dràsta a `toirt taic do ASLR (rust-lang/rust#16514), ach faodar DLLs a ghluasad fhathast san àite seòlaidh.
            // Tha e coltach gu bheil seòlaidhean ann am fiosrachadh deasbaid uile mar gum biodh an leabharlann seo air a luchdachadh aig a "image base", a tha na raon anns na cinn faidhle COFF aige.
            // Leis gur e seo a tha e coltach gu bheil debuginfo a `liostadh bidh sinn a` parsadh a `bhòrd samhla agus a` stòradh seòlaidhean mar gum biodh an leabharlann air a luchdachadh aig "image base" cuideachd.
            //
            // Is dòcha nach tèid an leabharlann a luchdachadh aig "image base", ge-tà.
            // (is dòcha gu bheil rudeigin eile air a luchdachadh an sin?) Seo far a bheil an raon `bias` a `tighinn a-steach, agus feumaidh sinn luach `bias` a dhearbhadh an seo.Gu mì-fhortanach ged nach eil e soilleir ciamar a gheibh thu seo bho mhodal luchdaichte.
            // Is e na tha againn, ge-tà, an fhìor sheòladh luchdan (`modBaseAddr`).
            //
            // Mar rud beag cop-a-mach airson a-nis bidh sinn a `mmap am faidhle, a` leughadh fiosrachadh bann-cinn an fhaidhle, agus an uairsin a `leigeil às am mmap.Tha seo ana-caitheamh oir is dòcha gum fosgail sinn am mmap nas fhaide air adhart, ach bu chòir seo obrachadh gu leòr airson a-nis.
            //
            // Aon uair `s gu bheil an `image_base` againn (àite luchdaidh a tha thu ag iarraidh) agus an `base_addr` (fìor àite luchdaidh) is urrainn dhuinn an `bias` (eadar-dhealachadh eadar an fhìor agus miannaichte) a lìonadh a-steach agus an uairsin is e an seòladh ainmichte gach earrann an `image_base` oir is e sin a tha am faidhle ag ràdh.
            //
            //
            // Airson a-nis tha e coltach nach urrainn dhuinn eu-coltach ri ELF/MachO a dhèanamh le aon earrann anns gach leabharlann, a `cleachdadh `modBaseSize` mar a` mheud iomlan.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS a `cleachdadh cruth faidhle Mach-O agus a` cleachdadh APIan sònraichte DYLD gus liosta de leabharlannan dùthchasach a tha nam pàirt den tagradh a luchdachadh.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Faigh ainm an leabharlainn seo a tha a rèir slighe far am faodar a luchdachadh cuideachd.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Luchdaich ceann ìomhaigh an leabharlainn seo agus tiomnadh gu `object` gus na h-òrdughan luchdan a pharsadh gus am faigh sinn a-mach na h-earrannan gu lèir a tha an sàs an seo.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Iterate thairis air na roinnean agus clàraich roinnean aithnichte airson earrannan a lorgas sinn.
            // A bharrachd air sin clàraich earrannan teacsa fiosrachaidh airson a ghiullachd nas fhaide air adhart, faic na beachdan gu h-ìosal.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Obraich a-mach an "slide" airson an leabharlann seo a tha a `tighinn gu crìch mar a` chlaonadh a bhios sinn a `cleachdadh gus faighinn a-mach càite a bheil nithean cuimhne air an luchdachadh.
            // Tha seo caran de cho-dhùnadh neònach ge-tà agus tha e mar thoradh air a bhith a `feuchainn beagan rudan anns an dùthaich agus a` faicinn dè a tha a `stobadh.
            //
            // Is e a `bheachd choitcheann gum bi an `bias` a bharrachd air `stated_virtual_memory_address` aig earrann far a bheil e san àite seòlaidh fhèin.
            // Is e an rud eile ris a bheil sinn an urra, ge-tà, gur e fìor sheòladh as aonais an `bias` an clàr-amais airson coimhead suas anns a `chlàr samhla agus debuginfo.
            //
            // Tha e coltach gu bheil na h-àireamhan sin ceàrr airson leabharlannan luchdaichte le siostaman.Airson luchd-gnìomh dùthchasach, ge-tà, tha coltas ceart air.
            // A `togail cuid de loidsig bho stòr LLDB tha cuid de chùisean sònraichte aige airson a` chiad roinn `__TEXT` air a luchdachadh bho fhrith-thionndadh faidhle 0 le meud nonzero.
            // Airson adhbhar sam bith nuair a tha seo an làthair tha e coltach gu bheil e a `ciallachadh gu bheil an clàr samhlaidhean an coimeas ri dìreach an sleamhnag vmaddr airson an leabharlann.
            // Mura h-eil e *an làthair* tha an clàr samhla an coimeas ris an t-sleamhnag vmaddr a bharrachd air seòladh ainmichte na h-earrainn.
            //
            // Gus an suidheachadh seo a làimhseachadh mura faigh sinn * earrann teacsa aig faidhle air a chothromachadh le neoni, bidh sinn a `meudachadh a` chlaonadh le seòladh ainmichte nan ciad earrannan teacsa agus a `lughdachadh gach seòladh ainmichte leis an t-suim sin cuideachd.
            //
            // San dòigh sin tha an clàr samhla an-còmhnaidh a `nochdadh a rèir meud claonadh an leabharlainn.
            // Tha e coltach gu bheil na toraidhean ceart airson a bhith a `samhlachadh tron chlàr samhla.
            //
            // Gu h-onarach chan eil mi gu tur cinnteach a bheil seo ceart no a bheil rudeigin eile ann a bu chòir innse mar a nì thu seo.
            // Airson a-nis ged a tha coltas ann gu bheil seo ag obair math gu leòr (?) agus bu chòir dhuinn a bhith comasach air seo a tweak thar ùine ma tha sin riatanach.
            //
            // Airson tuilleadh fiosrachaidh faic #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Unix eile (me
        // Bidh àrd-ùrlaran Linux) a `cleachdadh ELF mar chruth faidhle nì agus mar as trice bidh iad a` cur an gnìomh API ris an canar `dl_iterate_phdr` gus leabharlannan dùthchasach a luchdachadh.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` bu chòir a bhith nan comharran dligheach.
        // `vec` bu chòir a bhith na chomharradh dligheach air `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 chan eil e gu dùthchasach a `toirt taic do fhiosrachadh deasbaid, ach cuiridh an siostam togail fiosrachadh deasbaid aig slighe `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Bu chòir a h-uile càil eile ELF a chleachdadh, ach chan eil fios aca ciamar a luchdaicheas tu leabharlannan dùthchasach.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// A h-uile leabharlann co-roinnte aithnichte a chaidh a luchdachadh.
    libraries: Vec<Library>,

    /// Mapaichean tasgadan far am bi sinn a `cumail fiosrachadh corrach parsail.
    ///
    /// Tha comas stèidhichte air an liosta seo airson an ùine togail gu lèir nach bi a `meudachadh.
    /// Tha an eileamaid `usize` de gach paidhir na chlàr-amais a-steach do `libraries` gu h-àrd far a bheil `usize::max_value()` a `riochdachadh an gnìomh gnàthach.
    ///
    /// Tha an `Mapping` a `co-fhreagairt fiosrachadh dwarf parsed.
    ///
    /// Thoir fa-near gur e tasgadan LRU a tha seo agus bidh sinn a `gluasad rudan timcheall an seo mar a bhios sinn a` samhlachadh seòlaidhean.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Pàirtean den leabharlann seo air an luchdachadh don chuimhne, agus far a bheil iad air an luchdachadh.
    segments: Vec<LibrarySegment>,
    /// An "bias" den leabharlann seo, mar as trice far a bheil e air a luchdachadh gu cuimhne.
    /// Tha an luach seo air a chur ri seòladh ainmichte gach earrann gus an fhìor sheòladh cuimhne brìgheil fhaighinn anns a bheil am pìos air a luchdachadh.
    /// A bharrachd air an sin, tha am bias seo air a thoirt air falbh bho sheòlaidhean cuimhne brìgheil fìor gus clàr-amais a-steach do debuginfo agus an clàr samhla.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Seòladh ainmichte na h-earrainn seo anns an fhaidhle nì.
    /// Chan e seo gu dearbh far a bheil am pìos air a luchdachadh, ach is e an seòladh seo a bharrachd air `bias` an leabharlainn anns a bheil e.
    ///
    stated_virtual_memory_address: usize,
    /// Tha meud an roinn ths mar chuimhneachan.
    len: usize,
}

// mì-shàbhailte oir feumar seo a shioncronachadh bhon taobh a-muigh
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // mì-shàbhailte oir feumar seo a shioncronachadh bhon taobh a-muigh
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Cache LRU glè bheag, gu math sìmplidh airson mapadh fiosrachaidh deasbaid.
        //
        // Bu chòir an ìre hit a bhith gu math àrd, seach nach eil an stac àbhaisteach a `dol eadar mòran leabharlannan co-roinnte.
        //
        // Tha na structaran `addr2line::Context` gu math daor a chruthachadh.
        // Tha dùil gun tèid a chosgais a ghearradh a-mach le ceistean `locate` às deidh sin, a bheir buaidh air na structaran a chaidh a thogail nuair a bhios iad a `togail` addr2line: : Co-theacsa`s gus astar luath fhaighinn.
        //
        // Mura biodh an tasgadan seo againn, cha bhiodh an t-amortachadh sin a `tachairt a-riamh, agus bhiodh cùl-taic samhlachail ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // A 'chiad suas, ma deuchainn seo `lib` Tha earrann sam bith anns an `addr` (làimhseachadh imrich).Ma thèid an sgrùdadh seo seachad faodaidh sinn leantainn air adhart gu h-ìosal agus an seòladh eadar-theangachadh.
                //
                // Thoir fa-near gu bheil sinn a `cleachdadh `wrapping_add` an seo gus sgrùdaidhean thar-shruth a sheachnadh.Tha e air fhaicinn anns an fhàsach gu bheil an tomhas claonadh SVMA + a`dol thairis.
                // Tha e a `coimhead caran neònach a bhiodh a` tachairt ach chan eil mòran ann as urrainn dhuinn a dhèanamh mu dheidhinn ach is dòcha dìreach a `seachnadh nan earrannan sin bhon a tha iad dualtach a bhith a` comharrachadh don fhànais.
                //
                // Thàinig seo suas an toiseach ann an rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // A-nis gu bheil fios againn gu bheil `addr` ann an `lib`, is urrainn dhuinn a chothromachadh leis a `chlaonadh gus an seòladh cuimhne virutal ainmichte a lorg.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: às deidh an t-suidheachadh seo a chrìochnachadh gun a bhith a `tilleadh tràth
        // bho mhearachd, tha inntrigeadh an tasgadan airson an t-slighe seo aig clàr-amais 0.

        if let Some(idx) = idx {
            // Nuair a tha am mapadh san tasgadan mu thràth, gluais e chun bheulaibh.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Nuair nach eil am mapadh san tasgadan, cruthaich mapadh ùr, cuir a-steach e air beulaibh an tasgadan, agus cuir a-mach an inntrigeadh tasgadan as sine ma tha sin riatanach.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // na leig às an `'static` fad-beatha, dèan cinnteach gu bheil e air a chuairteachadh gu dìreach sinn fhìn
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Leudaich beatha `sym` gu `'static` bhon a dh `fheumas sinn gu mì-fhortanach an seo, ach tha e a-riamh a` dol a-mach mar iomradh agus mar sin cha bu chòir iomradh sam bith a chumail air taobh a-muigh na frèam seo co-dhiù.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Mu dheireadh, faigh mapadh tasgadan no cruthaich mapadh ùr airson an fhaidhle seo, agus dèan measadh air fiosrachadh DWARF gus an file/line/name a lorg airson an t-seòladh seo.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// B `urrainn dhuinn fiosrachadh frèam a lorg airson an t-samhla seo, agus tha frèam` addr2line` air an taobh a-staigh leis a h-uile mion-fhiosrachadh nitty gritty.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Cha b `urrainn dhuinn fiosrachadh deasbaid a lorg, ach lorg sinn e ann an clàr samhlaidhean an elf so-ghnìomhaichte.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}