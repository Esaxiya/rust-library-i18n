//! Ro-innleachd samhlachaidh a `cleachdadh a` chòd DWARF-parsing ann an libbacktrace.
//!
//! Tha an leabharlann libbacktrace C, mar as trice air a chuairteachadh le gcc, a `toirt taic chan ann a-mhàin a bhith a` gineadh cùl-raon (nach bi sinn a `cleachdadh ann an da-rìribh) ach cuideachd a` samhlachadh an cùl-raon agus a `làimhseachadh fiosrachadh deasbaid dwarf mu dheidhinn rudan mar fhrèamaichean loidhneach agus whatnot.
//!
//!
//! Tha seo gu math toinnte mar thoradh air mòran de dhraghan an seo, ach is e am beachd bunaiteach:
//!
//! * An toiseach canaidh sinn `backtrace_syminfo`.Bidh seo a `faighinn fiosrachadh samhla bhon chlàr samhlachail fiùghantach mas urrainn dhuinn.
//! * An ath rud bidh sinn a `gairm `backtrace_pcinfo`.Sgaoilidh seo bùird debuginfo ma tha iad rim faighinn agus leigidh sinn leinn fiosrachadh fhaighinn air ais mu fhrèamaichean a-staigh, ainmean faidhle, àireamhan loidhne, msaa.
//!
//! Tha tòrr cleas ann mu bhith a `faighinn na bùird troich a-steach do libbacktrace, ach an dòchas nach e deireadh an t-saoghail a th` ann agus gu bheil e soilleir gu leòr nuair a leughas tu gu h-ìosal.
//!
//! Is e seo an ro-innleachd samhlachaidh bunaiteach airson àrd-ùrlaran neo-MSVC agus neo-OSX.Ann an libstd ged is e seo an ro-innleachd bunaiteach airson OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Mas urrainnear, is fheàrr leat an t-ainm `function` a tha a `tighinn bho debuginfo agus mar as trice faodaidh e a bhith nas cruinne airson frèamaichean in-loidhne mar eisimpleir.
                // Mura h-eil sin an làthair ged a thuiteas tu air ais gu ainm clàr nan samhlaidhean a tha air an comharrachadh ann an `symname`.
                //
                // Thoir fa-near gum faod `function` a bhith a `faireachdainn beagan nas neo-mhearachdach, mar eisimpleir a bhith air an liostadh mar `try<i32,closure>` isntead de `std::panicking::try::do_call`.
                //
                // Chan eil e gu math soilleir carson, ach gu h-iomlan tha coltas nas cruinne air an ainm `function`.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // na dèan dad an-dràsta
}

/// Seòrsa a `phuing `data` a chaidh a-steach do `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Aon uair `s gu bheil an gairm air ais seo air a ghairm bho `backtrace_syminfo` nuair a thòisicheas sinn air fuasgladh bidh sinn a` dol nas fhaide gus `backtrace_pcinfo` a ghairm.
    // Bidh an gnìomh `backtrace_pcinfo` a `co-chomhairleachadh fiosrachadh deasbaid agus a` feuchainn ri rudan a dhèanamh mar a bhith a `faighinn fiosrachadh file/line air ais a bharrachd air frèaman le loidhne.
    // Thoir fa-near ged a dh `fhaodadh `backtrace_pcinfo` fàiligeadh no gun a bhith a` dèanamh mòran mura h-eil fiosrachadh deasbaid ann, mar sin ma thachras sin tha sinn cinnteach gun cuir thu fios air ais le co-dhiù aon samhla bhon `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Seòrsa a `phuing `data` a chaidh a-steach do `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Tha an libbacktrace API a `toirt taic do bhith a` cruthachadh stàite, ach chan eil e a `toirt taic do bhith a` sgrios stàite.
// Tha mi gu pearsanta a `gabhail ris gu bheil seo a` ciallachadh gu bheil stàite gu bhith air a cruthachadh agus an uairsin a bhith beò gu bràth.
//
// Bu mhath leam inneal-làimhseachaidh at_exit() a chlàradh a bhios a `glanadh na stàite seo, ach chan eil libbacktrace a` toirt seachad dòigh sam bith airson sin a dhèanamh.
//
// Leis na cuingeadan sin, tha stàite glèidhte aig a `ghnìomh seo a tha air a thomhas a` chiad uair a thèid seo iarraidh.
//
// Cuimhnich gu bheil cùl-taic a `tachairt gu h-obann (aon ghlas cruinne).
//
// Thoir fa-near gu bheil dìth sioncronaidh an seo mar thoradh air an riatanas gu bheil `resolve` air a shioncronachadh bhon taobh a-muigh.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Na bi a `cleachdadh comasan snàithleach libbacktrace oir tha sinn an-còmhnaidh ga ghairm ann an dòigh shioncronach.
        //
        0,
        error_cb,
        ptr::null_mut(), // gun dàta a bharrachd
    );

    return STATE;

    // Thoir fa-near, airson gum bi libbacktrace ag obair idir feumaidh e fiosrachadh deasbaid DWARF a lorg airson an gnìomh gnàthach.Mar as trice bidh e a `dèanamh sin tro ghrunn dhòighean a` toirt a-steach, ach gun a bhith cuibhrichte gu:
    //
    // * /proc/self/exe air àrd-ùrlaran le taic
    // * Chaidh ainm an fhaidhle a-steach gu follaiseach nuair a bha e a `cruthachadh stàite
    //
    // Tha an leabharlann libbacktrace na wad mòr de chòd C.Tha seo gu nàdarra a `ciallachadh gu bheil so-leòntachd sàbhailteachd cuimhne ann, gu sònraichte nuair a thathar a` làimhseachadh debuginfo mì-mhodhail.
    // Tha Libstd air a bhith a `ruith a-steach gu leòr dhiubh sin gu h-eachdraidheil.
    //
    // Ma thèid /proc/self/exe a chleachdadh faodaidh sinn dearmad a dhèanamh orra mar as trice oir tha sinn a `gabhail ris gur e "mostly correct" a th` ann an libbacktrace agus air dhòigh eile cha bhith sinn a `dèanamh rudan neònach le fiosrachadh deasbaid dwarf "attempted to be correct".
    //
    //
    // Ma chuireas sinn a-steach ainm faidhle, ge-tà, tha e comasach air cuid de àrd-ùrlaran (mar BSDs) far am faod cleasaiche droch-rùnach faidhle neo-riaghailteach a chuir san àite sin.
    // Tha seo a `ciallachadh ma dh` innseas sinn libbacktrace mu ainm faidhle is dòcha gu bheil e a `cleachdadh faidhle rèiteachaidh, is dòcha ag adhbhrachadh segfaults.
    // Mura h-innis sinn dad libbacktrace ge-tà cha dèan e dad air àrd-ùrlaran nach cuir taic ri slighean mar /proc/self/exe!
    //
    // Leis a h-uile càil a bhios sinn a `feuchainn cho cruaidh` s as urrainn dhuinn gus nach cuir sinn * a-steach ainm faidhle, ach feumaidh sinn air àrd-ùrlaran nach eil a `toirt taic do /proc/self/exe idir.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Thoir fa-near gum biodh e na b 'fheàrr dhuinn `std::env::current_exe` a chleachdadh, ach chan urrainn dhuinn `std` iarraidh an seo.
            //
            // Cleachd `_NSGetExecutablePath` gus an t-slighe gnàthaichte gnàthach a luchdachadh a-steach gu àite statach (a tha, ma tha e ro bheag, dìreach leig seachad).
            //
            //
            // Thoir fa-near gu bheil earbsa mhòr againn ann an libbacktrace an seo gus nach bàsaich sinn air gnìomhan coirbte, ach gu cinnteach tha ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows tha modh ann airson faidhlichean fhosgladh far nach urrainnear an toirt às às deidh dha fhosgladh.
            // Is e sin san fharsaingeachd a tha sinn ag iarraidh an seo oir tha sinn airson dèanamh cinnteach nach bi an gnìomh againn ag atharrachadh a-mach bhuainn às deidh dhuinn a thoirt seachad gu libbacktrace, an dòchas maothaicheas sinn an comas dàta neo-riaghailteach a thoirt a-steach gu libbacktrace (a dh `fhaodadh a bhith air a dhroch làimhseachadh).
            //
            //
            // Leis gu bheil sinn a `dèanamh beagan dannsa an seo gus feuchainn ri seòrsa de ghlas fhaighinn air an ìomhaigh againn fhèin:
            //
            // * Faigh grèim air a `phròiseas làithreach, luchdaich ainm a fhaidhle.
            // * Fosgail faidhle don ainm faidhle sin leis na brataichean ceart.
            // * Ath-luchdaich ainm faidhle a `phròiseas làithreach, a` dèanamh cinnteach gu bheil e mar an ceudna
            //
            // Ma thèid sin seachad tha sinn ann an teòiridh gu dearbh air faidhle ar pròiseas fhosgladh agus tha sinn cinnteach nach atharraich e.FWIW tha cnap de seo air a chopaigeadh bho libstd gu h-eachdraidheil, agus mar sin is e seo am mìneachadh as fheàrr agam air na bha a `tachairt.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Bidh seo a `fuireach ann an cuimhne statach gus an urrainn dhuinn a thilleadh.
                static mut BUF: [i8; N] = [0; N];
                // ... agus tha seo a `fuireach air a` chruach bhon a tha e sealach
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // a `leigeil a-mach `handle` a dh`aona ghnothach oir bu chòir don fhosgladh sin ar glas a ghlèidheadh air ainm an fhaidhle seo.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Tha sinn airson sliseag a th `air a thoirt gu crìch a thoirt air ais, mar sin ma chaidh a h-uile càil a lìonadh a-steach agus gu bheil e co-ionann ris an fhad iomlan an uairsin tha sin co-ionann ri fàilligeadh.
                //
                //
                // Rud eile nuair a thilleas tu soirbheachas dèan cinnteach gu bheil an nul byte air a thoirt a-steach don t-slice.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // tha mearachdan backtrace an-dràsta air an sguabadh fon ruga
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Cuir fòn gu API `backtrace_syminfo` a bu chòir (bho bhith a `leughadh a` chòd) `syminfo_cb` a ghairm dìreach aon uair (no fàilligeadh le mearachd a rèir coltais).
    // Bidh sinn an uairsin a `làimhseachadh barrachd taobh a-staigh an `syminfo_cb`.
    //
    // Thoir fa-near gum bi sinn a `dèanamh seo oir bidh `syminfo` a` co-chomhairleachadh ris a `chlàr samhlaidhean, a` lorg ainmean samhlaidhean eadhon mura h-eil fiosrachadh deasbaid ann am binary.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}