// air a chleachdadh a-mhàin air Linux an-dràsta, mar sin leig le còd marbh an àite eile
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Sònraiche raon sìmplidh airson bufairean byte.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// A `riarachadh bufair den mheud ainmichte agus a` tilleadh iomradh gluasadach air.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SÀBHAILTEACHD: is e seo an aon ghnìomh a bhios a-riamh a `togail mutable
        // iomradh air `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SÀBHAILTEACHD: cha bhith sinn a `toirt air falbh eileamaidean bho `self.buffers` a-riamh, mar sin iomradh
        // chun an dàta taobh a-staigh bufair bidh beò cho fada ri `self`.
        &mut buffers[i]
    }
}