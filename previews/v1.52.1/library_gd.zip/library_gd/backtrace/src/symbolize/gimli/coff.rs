use super::{Context, Mapping, Path, Stash, Vec};
use core::convert::TryFrom;
use object::pe::{ImageDosHeader, ImageSymbol};
use object::read::pe::{ImageNtHeaders, ImageOptionalHeader, SectionTable};
use object::read::StringTable;
use object::{Bytes, LittleEndian as LE};

#[cfg(target_pointer_width = "32")]
type Pe = object::pe::ImageNtHeaders32;
#[cfg(target_pointer_width = "64")]
type Pe = object::pe::ImageNtHeaders64;

impl Mapping {
    pub fn new(path: &Path) -> Option<Mapping> {
        let map = super::mmap(path)?;
        Mapping::mk(map, |data, stash| Context::new(stash, Object::parse(data)?))
    }
}

pub struct Object<'a> {
    data: Bytes<'a>,
    sections: SectionTable<'a>,
    symbols: Vec<(usize, &'a ImageSymbol)>,
    strings: StringTable<'a>,
}

pub fn get_image_base(data: &[u8]) -> Option<usize> {
    let data = Bytes(data);
    let dos_header = ImageDosHeader::parse(data).ok()?;
    let (nt_headers, _, _) = dos_header.nt_headers::<Pe>(data).ok()?;
    usize::try_from(nt_headers.optional_header().image_base()).ok()
}

impl<'a> Object<'a> {
    fn parse(data: &'a [u8]) -> Option<Object<'a>> {
        let data = Bytes(data);
        let dos_header = ImageDosHeader::parse(data).ok()?;
        let (nt_headers, _, nt_tail) = dos_header.nt_headers::<Pe>(data).ok()?;
        let sections = nt_headers.sections(nt_tail).ok()?;
        let symtab = nt_headers.symbols(data).ok()?;
        let strings = symtab.strings();
        let image_base = usize::try_from(nt_headers.optional_header().image_base()).ok()?;

        // Cruinnich na samhlaidhean gu lèir ann an vector ionadail a tha air a sheòrsachadh a rèir seòladh agus anns a bheil dàta gu leòr gus ionnsachadh mu ainm an t-samhla.
        // Thoir fa-near nach coimhead sinn ach air samhlaidhean gnìomh agus cuideachd a `toirt fa-near gu bheil na h-earrannan 1-chlàr-amais oir tha an roinn neoni sònraichte (apparently).
        //
        //
        //
        let mut symbols = Vec::new();
        let mut i = 0;
        let len = symtab.len();
        while i < len {
            let sym = symtab.symbol(i).ok()?;
            i += 1 + sym.number_of_aux_symbols as usize;
            let section_number = sym.section_number.get(LE);
            if sym.derived_type() != object::pe::IMAGE_SYM_DTYPE_FUNCTION || section_number == 0 {
                continue;
            }
            let addr = usize::try_from(sym.value.get(LE)).ok()?;
            let section = sections
                .section(usize::try_from(section_number).ok()?)
                .ok()?;
            let va = usize::try_from(section.virtual_address.get(LE)).ok()?;
            symbols.push((addr + va + image_base, sym));
        }
        symbols.sort_unstable_by_key(|x| x.0);
        Some(Object {
            data,
            sections,
            strings,
            symbols,
        })
    }

    pub fn section(&self, _: &Stash, name: &str) -> Option<&'a [u8]> {
        Some(
            self.sections
                .section_by_name(self.strings, name.as_bytes())?
                .1
                .pe_data(self.data)
                .ok()?
                .0,
        )
    }

    pub fn search_symtab<'b>(&'b self, addr: u64) -> Option<&'b [u8]> {
        // Thoir fa-near, eu-coltach ri cruthan eile, chan eil COFF a `toirt a-steach meud gach samhla.
        // Mar oidhirp dìg mu dheireadh lorg an samhla *as fhaisge* gu seòladh sònraichte agus till am fear sin.
        // Bidh seo a `fàs gu math soirbheachail aon uair` s gu bheil samhlaidhean a `tòiseachadh air an toirt air falbh oir faodaidh na samhlaidhean a thilleadh an seo a bhith gu tur ceàrr, ach chan eil beachd sam bith againn fios a bhith againn ciamar a lorgas sinn sin.
        //
        //
        //
        let addr = usize::try_from(addr).ok()?;
        let i = match self.symbols.binary_search_by_key(&addr, |p| p.0) {
            Ok(i) => i,
            // mar as trice chan eil `addr` san raon, ach is e `i` far an cuir sinn a-steach e, agus mar sin feumaidh an suidheachadh roimhe a bhith aig an ìre as lugha na `addr`
            //
            //
            Err(i) => i.checked_sub(1)?,
        };
        self.symbols[i].1.name(self.strings).ok()
    }

    pub(super) fn search_object_map(&self, _addr: u64) -> Option<(&Context<'_>, u64)> {
        None
    }
}