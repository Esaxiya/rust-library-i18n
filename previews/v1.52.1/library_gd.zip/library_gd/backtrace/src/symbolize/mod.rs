use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Rèitich seòladh gu samhla, a `dol seachad air an t-samhla chun an dùnadh ainmichte.
///
/// Bidh an gnìomh seo a `coimhead suas an t-seòladh a chaidh a thoirt seachad ann an raointean leithid an clàr samhla ionadail, clàr samhlachail fiùghantach, no fiosrachadh deasbaid DWARF (a rèir buileachadh gnìomhach) gus samhlaidhean a lorg a bheir toradh.
///
///
/// Tha an dùnadh Chan fhaodar a ghairm ma fhearr cha b 'urrainn a bhith air a thaisbeanadh, agus tha e cuideachd a dh'fhaodadh a bhith air a ghairm barrachd air aon uair ann an cùis inlined dreuchdan.
///
/// Tha na samhlaidhean a gheibhear a `riochdachadh an cur gu bàs aig an `addr` ainmichte, a` tilleadh paidhrichean file/line airson an t-seòladh sin (ma tha sin ri fhaighinn).
///
/// Thoir fa-near, ma tha `Frame` agad, thathas a `moladh an gnìomh `resolve_frame` a chleachdadh an àite an tè seo.
///
/// # Feartan riatanach
///
/// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
///
/// # Panics
///
/// Bidh an gnìomh seo a `feuchainn ri panic a-riamh, ach ma thug an `cb` seachad panics, bidh cuid de àrd-chabhsairean a` toirt air panic dùbailte stad a chuir air a `phròiseas.
/// Bidh cuid de dh `àrd-chabhsairean a` cleachdadh leabharlann C a bhios a `cleachdadh glaodhan taobh a-staigh nach gabh faighinn troimhe, agus mar sin ma bhriogas tu air `cb` faodaidh e pròiseas a ghiorrachadh.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // dìreach coimhead air an fhrèam gu h-àrd
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Rèitich frèam a chaidh a ghlacadh roimhe gu samhla, a `dol seachad air an t-samhla chun an dùnadh ainmichte.
///
/// Bidh am functin seo a `coileanadh an aon ghnìomh ri `resolve` ach a-mhàin gu bheil e a` gabhail `Frame` mar argamaid an àite seòladh.
/// Faodaidh seo leigeil le cuid de bhuileachadh àrd-ùrlair cùl-taic fiosrachadh samhla nas cruinne a thoirt seachad no fiosrachadh mu fhrèamaichean in-loidhne mar eisimpleir.
///
/// Thathas a `moladh seo a chleachdadh mas urrainn dhut.
///
/// # Feartan riatanach
///
/// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
///
/// # Panics
///
/// Bidh an gnìomh seo a `feuchainn ri panic a-riamh, ach ma thug an `cb` seachad panics, bidh cuid de àrd-chabhsairean a` toirt air panic dùbailte stad a chuir air a `phròiseas.
/// Bidh cuid de dh `àrd-chabhsairean a` cleachdadh leabharlann C a bhios a `cleachdadh glaodhan taobh a-staigh nach gabh faighinn troimhe, agus mar sin ma bhriogas tu air `cb` faodaidh e pròiseas a ghiorrachadh.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // dìreach coimhead air an fhrèam gu h-àrd
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Mar as trice is e luachan IP bho fhrèamaichean cruachan (always?) an stiùireadh *às deidh* a `ghairm sin an fhìor lorg stac.
// Le bhith a `samhlachadh seo air, tha an àireamh filename/line aon air thoiseach agus is dòcha a-steach don bheàrn ma tha e faisg air deireadh a` ghnìomh.
//
// Tha e coltach gu bheil seo an-còmhnaidh mar sin air gach àrd-ùrlar, agus mar sin bidh sinn an-còmhnaidh a `toirt air falbh fear bho ip a chaidh a rèiteachadh gus fuasgladh fhaighinn don stiùireadh gairm a bh` ann roimhe an àite an stiùireadh a thilleadh thuige.
//
//
// Bhiodh e math nach dèanadh sinn seo.
// Bhiodh e na b `fheàrr gum biodh sinn ag iarraidh air luchd-fios de na `resolve` APIs an seo an -1 a dhèanamh le làimh agus cunntas a thoirt gu bheil iad ag iarraidh fiosrachadh àite airson an stiùireadh *roimhe*, chan e an-dràsta.
// Bhiodh e na b 'fheàrr dhuinn nochdadh air `Frame` ma tha sinn gu dearbh a' seòladh an ath stiùireadh no an t-sruth.
//
// Airson a-nis ged is e dragh gu math sònraichte a tha seo agus mar sin bidh sinn an-còmhnaidh a `toirt air falbh fear.
// Bu chòir do luchd-cleachdaidh cumail ag obair agus a bhith a `faighinn deagh thoraidhean math, mar sin bu chòir dhuinn a bhith math gu leòr.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Co-ionann ri `resolve`, dìreach mì-shàbhailte oir tha e neo-shioncronach.
///
/// Chan eil geallaidhean sioncronaidh aig a `ghnìomh seo ach tha e ri fhaighinn nuair nach eil am feart `std` den crate seo air a chur ri chèile.
/// Faic gnìomh `resolve` airson tuilleadh sgrìobhainnean agus eisimpleirean.
///
/// # Panics
///
/// Faic fiosrachadh air `resolve` airson caitean air clisgeadh `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Co-ionann ri `resolve_frame`, dìreach mì-shàbhailte oir tha e neo-shioncronach.
///
/// Chan eil geallaidhean sioncronaidh aig a `ghnìomh seo ach tha e ri fhaighinn nuair nach eil am feart `std` den crate seo air a chur ri chèile.
/// Faic gnìomh `resolve_frame` airson tuilleadh sgrìobhainnean agus eisimpleirean.
///
/// # Panics
///
/// Faic fiosrachadh air `resolve_frame` airson caitean air clisgeadh `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait a `riochdachadh rùn samhla ann am faidhle.
///
/// Tha an trait seo air a thoirt a-mach mar stuth trait airson an dùnadh a chaidh a thoirt don ghnìomh `backtrace::resolve`, agus cha mhòr nach eil e air a chuir air falbh leis nach eil fios dè am buileachadh a tha air a chùlaibh.
///
///
/// Faodaidh samhla fiosrachadh co-theacsail a thoirt seachad mu ghnìomh, mar eisimpleir ainm, ainm faidhle, àireamh loidhne, seòladh mionaideach, msaa.
/// Chan eil a h-uile fiosrachadh an-còmhnaidh ri fhaighinn ann an samhla, ge-tà, agus mar sin bidh gach dòigh a `tilleadh `Option`.
///
///
pub struct Symbol {
    // TODO: feumar an ceangal fad-beatha seo a leantainn mu dheireadh gu `Symbol`,
    // ach tha sin an-dràsta na atharrachadh mòr.
    // Airson a-nis tha seo sàbhailte leis nach eil `Symbol` a-riamh air a thoirt seachad le iomradh agus nach gabh a clònadh.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// A `tilleadh ainm na gnìomh seo.
    ///
    /// Faodar an structar a chaidh a thilleadh a chleachdadh gus grunn thogalaichean a cheasnachadh mu ainm an t-samhla:
    ///
    ///
    /// * Bidh buileachadh `Display` a `clò-bhualadh an samhla demangled.
    /// * Faodar faighinn gu luach amh `str` an t-samhla (ma tha e dligheach utf-8).
    /// * Faodar faighinn gu na bytes amh airson ainm an t-samhla.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// A `tilleadh seòladh tòiseachaidh na gnìomh seo.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// A `tilleadh ainm an fhaidhle amh mar sliseag.
    /// 'S e seo sa mhòr-chuid feumail airson `no_std` àrainneachdan.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// A `tilleadh àireamh a` cholbh airson far a bheil an samhla seo a `coileanadh an-dràsta.
    ///
    /// Chan eil ach gimli an-dràsta a `toirt seachad luach an seo agus eadhon an uairsin a-mhàin ma thilleas `filename` `Some`, agus mar sin tha e an uairsin fo ùmhlachd caveats coltach ris.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// A `tilleadh an àireamh loidhne airson far a bheil an samhla seo a` coileanadh an-dràsta.
    ///
    /// Mar as trice is e `Some` an luach toraidh seo ma thilleas `filename` `Some`, agus mar thoradh air an sin tha e fo ùmhlachd chlàran coltach ris.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// A `tilleadh ainm an fhaidhle far an deach an gnìomh seo a mhìneachadh.
    ///
    /// Chan eil seo ri fhaighinn an-dràsta ach nuair a thathas a `cleachdadh libbacktrace no gimli (me
    /// unix àrd-ùrlaran eile) agus nuair a thèid binary a chur ri chèile le debuginfo.
    /// Ma ni mò de na h coinneachadh ri an uair sin bidh seo buailtiche tilleadh `None`.
    ///
    /// # Feartan riatanach
    ///
    /// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Is dòcha samhla C++ parsed, ma dh `fhàillig parsadh an samhla mangled mar Rust.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Dèan cinnteach gun cum thu am meud neoni seo, gus nach bi cosgais aig an fheart `cpp_demangle` nuair a tha e ciorramach.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Pasgadair timcheall ainm samhla gus luchd-ruigsinneachd ergonomic a thoirt don ainm dì-mheadhanaichte, na bytes amh, an sreang amh, msaa.
///
// Leig seachad còd marbh airson nuair nach eil am feart `cpp_demangle` air a chomasachadh.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// A `cruthachadh ainm samhla ùr bho na bytes bunaiteach amh.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// A `tilleadh ainm samhla (mangled) amh mar `str` ma tha an samhla dligheach utf-8.
    ///
    /// Cleachd am buileachadh `Display` ma tha thu ag iarraidh an dreach dì-mheadhanaichte.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// A `tilleadh ainm an t-samhla amh mar liosta de bytes
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Dh `fhaodadh seo clò-bhualadh mura h-eil an samhla dì-mheadhanaichte dligheach, mar sin làimhsich thu a` mhearachd an seo gu gràsmhor le bhith gun a bhith ga leudachadh a-mach.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Feuch a thoirt air ais a thasgadh chuimhneachan air a chleachdadh gus seòlaidhean symbolicate.
///
/// Feuchaidh an dòigh seo ri structaran dàta cruinneil sam bith a leigeil ma sgaoil a chaidh a ghairm air feadh na cruinne no san t-snàthainn a bhios mar as trice a `riochdachadh fiosrachadh DWARF parsaichte no a leithid.
///
///
/// # Caveats
///
/// Ged a tha an gnìomh seo an-còmhnaidh ri fhaighinn cha dèan e dad air a `mhòr-chuid de ghnìomhachadh.
/// Chan eil leabharlannan mar dbghelp no libbacktrace a `toirt seachad goireasan gus stàite a thuigsinn agus a` chuimhne a chaidh a riarachadh a riaghladh.
/// Airson a-nis is e feart `gimli-symbolize` den crate seo an aon fheart far a bheil buaidh sam bith aig a `ghnìomh seo.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}