//! Modal gus cuideachadh le bhith a `riaghladh ceangalaichean dbghelp air Windows
//!
//! Tha cùl-stòran air Windows (co-dhiù airson MSVC) air an cumhachd gu ìre mhòr tro `dbghelp.dll` agus na diofar dhleastanasan a tha na bhroinn.
//! Tha na gnìomhan sin an-dràsta air an luchdachadh *gu dinimigeach* an àite a bhith a `ceangal ri `dbghelp.dll` gu staitistigeil.
//! Tha seo air a dhèanamh an-dràsta leis an leabharlann àbhaisteach (agus tha e riatanach ann an teòiridh an sin), ach tha e na oidhirp gus cuideachadh le bhith a `lughdachadh eisimeileachd statach dll ann an leabharlann oir tha cùl-stòran mar as trice gu math roghainneil.
//!
//! Le bhith ga ràdh, tha `dbghelp.dll` cha mhòr an-còmhnaidh a `luchdachadh air Windows.
//!
//! Thoir fa-near, ged a tha sinn a `luchdachadh suas an taic seo gu fiùghantach chan urrainn dhuinn na mìneachaidhean amh ann an `winapi` a chleachdadh, ach an àite sin feumaidh sinn na seòrsachan puing gnìomh a mhìneachadh sinn fhìn agus sin a chleachdadh.
//! Chan eil sinn dha-rìribh ag iarraidh a bhith an sàs ann a bhith a `dùblachadh winapi, agus mar sin tha feart Cargo `verify-winapi` againn a tha ag ràdh gu bheil a h-uile ceangal a` maidseadh an fheadhainn ann an winapi agus tha am feart seo air a chomasachadh air CI.
//!
//! Mu dheireadh, bheir thu fa-near an seo nach eil an dll airson `dbghelp.dll` a-riamh air a luchdachadh, agus tha sin a dh'aona ghnothach.
//! Is e an smaoineachadh gum faod sinn a chuir air feadh na cruinne agus a chleachdadh eadar gairmean chun API, a `seachnadh loads/unloads daor.
//! Ma tha seo na dhuilgheadas dha lorgairean aodion no rudeigin mar sin is urrainn dhuinn a dhol tarsainn air an drochaid nuair a ruigeas sinn an sin.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Obraich timcheall air `SymGetOptions` agus `SymSetOptions` gun a bhith an làthair ann an winapi fhèin.
// A chaochladh chan eil seo air a chleachdadh ach nuair a bhios sinn a `dèanamh sgrùdadh dùbailte air seòrsan winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Gun mhìneachadh ann an winapi fhathast
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Tha seo air a mhìneachadh ann an winapi, ach tha e ceàrr (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Gun mhìneachadh ann an winapi fhathast
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Tha am macro seo air a chleachdadh gus structar `Dbghelp` a mhìneachadh anns a bheil taobh a-staigh na comharran gnìomh a dh `fhaodadh sinn a luchdachadh.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// An DLL luchdaichte airson `dbghelp.dll`
            dll: HMODULE,

            // A h-uile puing gnìomh airson gach gnìomh a dh `fhaodadh sinn a chleachdadh
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // An toiseach chan eil sinn air an DLL a luchdachadh
            dll: 0 as *mut _,
            // Tha a h-uile gnìomh air a shuidheachadh gu neoni gus a ràdh gu feum iad a bhith air an luchdachadh gu dinamach.
            //
            $($name: 0,)*
        };

        // Clò-bhuail goireasach airson gach seòrsa gnìomh.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Oidhirpean gus `dbghelp.dll` fhosgladh.
            /// A `tilleadh soirbheachas ma dh` obraich e no mearachd ma dh `fhailicheas `LoadLibraryW`.
            ///
            /// Panics ma tha leabharlann air a luchdachadh mu thràth.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Dreuchd airson gach dòigh a bu mhath leinn a chleachdadh.
            // Nuair a thèid a ghairm leughaidh e an dàrna cuid am putan gnìomh tasgadan no luchdaichidh e e agus tillidh e an luach luchdaichte.
            // Thathas ag ràdh gu bheil luchdan a `soirbheachadh.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Neach-ionaid goireas gus na glasan glanaidh a chleachdadh gus iomradh a thoirt air gnìomhan dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Tòisich a h-uile taic a tha riatanach gus faighinn gu gnìomhan `dbghelp` API bhon crate seo.
///
///
/// Thoir fa-near gu bheil an gnìomh seo **sàbhailte**, tha an sioncronadh fhèin aig an taobh a-staigh.
/// Thoir fa-near cuideachd gu bheil e sàbhailte an gnìomh seo a ghairm iomadh uair gu ath-chuairteachail.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Is e a `chiad rud a dh` fheumas sinn a dhèanamh gus an gnìomh seo a shioncronachadh.Faodar seo a ghairm aig an aon àm bho snàithleanan eile no gu ath-chuairteachail taobh a-staigh aon snàithlean.
        // Thoir fa-near gu bheil e nas duilghe na sin ge-tà oir feumaidh na tha sinn a `cleachdadh an seo, `dbghelp`,*cuideachd* a bhith air a shioncronachadh leis a h-uile neach-fios eile gu `dbghelp` sa phròiseas seo.
        //
        // Mar as trice chan eil dha-rìribh mòran ghlaodhan gu `dbghelp` san aon phròiseas agus is dòcha gu bheil sinn a `gabhail ris gu sàbhailte gur e sinne an aon fheadhainn a tha a` faighinn cothrom air.
        // Ach, tha aon phrìomh neach-cleachdaidh eile ann a dh `fheumas sinn dragh a dhèanamh a tha gu h-ìoranta sinn fhìn, ach anns an leabharlann àbhaisteach.
        // Tha leabharlann àbhaisteach Rust an urra ris an crate seo airson taic backtrace, agus tha an crate seo ann cuideachd air crates.io.
        // Tha seo a `ciallachadh ma tha an leabharlann àbhaisteach a` clò-bhualadh cùl-taic panic is dòcha gum bi e rèis leis an crate seo a `tighinn bho crates.io, ag adhbhrachadh segfaults.
        //
        // Gus cuideachadh le fuasgladh fhaighinn air an duilgheadas sioncronaidh seo tha sinn a `cleachdadh cleas sònraichte airson Windows an seo (tha e, às deidh a h-uile càil, na chuingealachadh sònraichte air Windows mu shioncronadh).
        // Bidh sinn a `cruthachadh *seisean-ionadail* ainmichte mutex gus a` ghairm seo a dhìon.
        // Is e an rùn an seo nach fheum an leabharlann àbhaisteach agus an crate seo APIan ìre Rust a cho-roinn gus sioncronadh an seo ach an àite sin faodaidh iad obrachadh air cùl na seallaidhean gus dèanamh cinnteach gu bheil iad a `sioncronadh le chèile.
        //
        // San dòigh sin nuair a thèid an gnìomh seo a ghairm tron leabharlann àbhaisteach no tro crates.io faodaidh sinn a bhith cinnteach gu bheilear a `faighinn an aon mutex.
        //
        // Mar sin is e sin uile ri ràdh gur e a `chiad rud a nì sinn an seo gu bheil sinn gu h-atamach a` cruthachadh `HANDLE` a tha na mutex ainmichte air Windows.
        // Synchronize sinn beagan eile a 'ceangal a bhith a' roinn a 'ghnìomh seo a dh'aon ghnothach agus a' dèanamh cinnteach nach robh ach aon cas a chruthachadh gach eisimpleir de ghnìomh seo.
        // Thoir fa-near nach tèid an làimhseachadh a dhùnadh a-riamh aon uair `s gu bheil e air a stòradh air feadh na cruinne.
        //
        // Às deidh dhuinn a dhol a-steach don ghlas bidh sinn dìreach ga fhaighinn, agus bidh e an urra ris an inneal `Init` a bheir sinn seachad a leigeil seachad mu dheireadh.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Glè mhath, phew!A-nis gu bheil sinn uile a sàbhailte thìmichte, leig a-rìribh a 'tòiseachadh a' giollachd a h-uile càil.
        // An toiseach feumaidh sinn dèanamh cinnteach gu bheil `dbghelp.dll` air a luchdachadh sa phròiseas seo.
        // Bidh sinn a `dèanamh seo gu dinamach gus eisimeileachd statach a sheachnadh.
        // Chaidh seo a dhèanamh gu h-eachdraidheil gus obrachadh timcheall air cùisean ceangail neònach agus tha e an dùil binaries a dhèanamh beagan nas so-ghiùlain oir chan eil seo gu ìre mhòr ach goireas deasbaid.
        //
        //
        // Aon uair `s gu bheil sinn air `dbghelp.dll` fhosgladh feumaidh sinn cuid de ghnìomhan tòiseachaidh a ghairm ann, agus tha sin nas mionaidiche gu h-ìosal.
        // Cha bhith sinn a `dèanamh seo ach aon turas, ge-tà, agus mar sin tha boolean cruinne againn a` nochdadh a bheil sinn air a dhèanamh fhathast no nach eil.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Dèan cinnteach gu bheil bratach `SYMOPT_DEFERRED_LOADS` air a shuidheachadh, oir a rèir docaichean MSVC fhèin mu dheidhinn seo: "This is the fastest, most efficient way to use the symbol handler.", mar sin dèanamaid sin!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Cuir air adhart samhlaidhean le MSVC.Thoir fa-near gum faod seo fàiligeadh, ach bidh sinn ga leigeil seachad.
        // Chan eil tunna de dh `ealain ro-làimh airson seo per se, ach tha e coltach gu bheil LLVM air an taobh a-staigh a` seachnadh luach tilleadh an seo agus tha aon de na leabharlannan slàintealachd ann an LLVM a `clò-bhualadh rabhadh eagallach ma dh` fhàilligeas seo ach gu bunaiteach bidh e ga leigeil seachad san fhad-ùine.
        //
        //
        // Is e aon chùis a tha seo a `tighinn suas tòrr airson Rust gu bheil an leabharlann àbhaisteach agus an crate seo air crates.io le chèile airson a bhith a` farpais airson `SymInitializeW`.
        // Gu h-eachdraidheil bha an leabharlann àbhaisteach airson a bhith a `tòiseachadh an uairsin an glanadh sin a` mhòr-chuid den ùine, ach a-nis gu bheil e a `cleachdadh an crate seo tha e a` ciallachadh gum faigh cuideigin a-mach an toiseach agus bidh am fear eile a `togail a` ghnothaich sin.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}