#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Cruth airson backtraces.
///
/// Faodar an seòrsa seo a chleachdadh gus cùl-raon a chlò-bhualadh ge bith cò às a tha an backtrace fhèin a `tighinn.
/// Ma tha seòrsa `Backtrace` agad tha an gnìomh `Debug` mu thràth a `cleachdadh an cruth clò-bhualaidh seo.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Na stoidhlichean clò-bhualaidh as urrainn dhuinn a chlò-bhualadh
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// A `clò-bhualadh cùl-raon nas teinne anns nach eil ach fiosrachadh buntainneach
    Short,
    /// A `clò-bhualadh cùl-raon anns a bheil a h-uile fiosrachadh comasach
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Cruthaich `BacktraceFmt` ùr a sgrìobhas toradh chun `fmt` a chaidh a thoirt seachad.
    ///
    /// Bidh an argamaid `format` a `cumail smachd air an stoidhle anns a bheil an cùl-taic air a chlò-bhualadh, agus thèid an argamaid `print_path` a chleachdadh gus eisimpleirean `BytesOrWideString` de dh` ainmean faidhle a chlò-bhualadh.
    /// Cha bhith an seòrsa seo fhèin a `clò-bhualadh ainmean faidhle sam bith, ach feumar an ais-ghairm seo a dhèanamh.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// A `clò-bhualadh ro-ràdh airson an cùl-taic mu bhith air a chlò-bhualadh.
    ///
    /// Tha seo a dhìth air cuid de àrd-chabhsairean airson backtraces a bhith air an samhlachadh gu h-iomlan nas fhaide air adhart, agus air dhòigh eile bu chòir seo a bhith mar a `chiad dhòigh air an cuir thu fios às deidh dhut `BacktraceFmt` a chruthachadh.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// A `cur frèam ris an toradh backtrace.
    ///
    /// Bidh an gealladh seo a `tilleadh eisimpleir RAII de `BacktraceFrameFmt` a ghabhas a chleachdadh gus frèam a chlò-bhualadh, agus nuair a thèid a sgrios àrdaichidh e an t-inneal-aghaidh frèam.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// A `crìochnachadh toradh backtrace.
    ///
    /// Chan eil seo ach neo-op ach tha e air a chur ris airson co-chòrdalachd future le cruthan backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // An-dràsta no-op-- a `toirt a-steach an hook seo gus leigeil le cuir-ris future.
        Ok(())
    }
}

/// Cruth cruth airson dìreach aon fhrèam de chùl-raon.
///
/// Tha an seòrsa seo air a chruthachadh leis a `ghnìomh `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Clò-bhuail `BacktraceFrame` leis an cruth-frèam seo.
    ///
    /// Bidh seo gu cunbhalach a `clò-bhualadh a h-uile suidheachadh `BacktraceSymbol` taobh a-staigh an `BacktraceFrame`.
    ///
    /// # Feartan riatanach
    ///
    /// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Clò-bhuail `BacktraceSymbol` taobh a-staigh `BacktraceFrame`.
    ///
    /// # Feartan riatanach
    ///
    /// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: chan eil seo math nach bi sinn a `clò-bhualadh rud sam bith
            // le neo-utf8 ainmean-faidhle.
            // Gu fortanach tha cha mhòr a h-uile dad utf8 agus mar sin cha bu chòir seo a bhith ro dhona.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// A `clò-bhualadh `Frame` agus `Symbol` amh, mar as trice bho taobh a-staigh glaodhan amh an crate seo.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Cuir frèam amh ris an toradh backtrace.
    ///
    /// Bidh an dòigh seo, eu-coltach ris na bh `ann roimhe, a` gabhail na h-argamaidean amh gun fhios nach bi iad gan lorg bho dhiofar àiteachan.
    /// Thoir fa-near gur dòcha gur e seo grunn thursan airson aon fhrèam.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// A `cur frèam amh ri toradh backtrace, a` toirt a-steach fiosrachadh colbh.
    ///
    /// Bidh an dòigh seo, mar a bh `ann roimhe, a` gabhail na h-argamaidean amh gun fhios nach bi iad gan lorg bho dhiofar àiteachan.
    /// Thoir fa-near gur dòcha gur e seo grunn thursan airson aon fhrèam.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Chan urrainn dha Fuchsia a bhith a `samhlachadh taobh a-staigh pròiseas agus mar sin tha cruth sònraichte aige a dh` fhaodar a chleachdadh gus samhlachadh nas fhaide air adhart.
        // Clò-bhuail sin an àite seòlaidhean clò-bhualaidh anns a `chruth againn fhèin an seo.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Chan fheumar frèamaichean "null" a chlò-bhualadh, tha e gu bunaiteach dìreach a `ciallachadh gu robh cùl-taic an t-siostaim beagan dèidheil air a bhith a` lorg air ais gu math fada.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Gus meud TCB a lughdachadh ann an enclave Sgx, chan eil sinn airson comas rùn samhla a bhuileachadh.
        // An àite sin, is urrainn dhuinn frith-sgrìobhadh an t-seòlaidh a chlò-bhualadh an seo, a dh `fhaodadh a bhith air a mhapadh nas fhaide air adhart gus a` ghnìomh a cheartachadh.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Clò-bhuail clàr-amais an fhrèam a bharrachd air stiùireadh stiùiridh roghainneil an fhrèam.
        // Ma tha sinn nas fhaide na a `chiad ìomhaigh den fhrèam seo ged a bhios sinn dìreach a` clò-bhualadh àite geal iomchaidh.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // An ath rud sgrìobh a-mach ainm an t-samhla, a `cleachdadh an cruth eile airson tuilleadh fiosrachaidh ma tha sinn làn-chùl.
        // An seo bidh sinn a `làimhseachadh samhlaidhean aig nach eil ainm,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Agus mu dheireadh suas, clò-bhuail an àireamh filename/line ma tha iad rim faighinn.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line air an clò-bhualadh air loidhnichean fon ainm samhla, mar sin clò-bhuail cuid de rùm geal iomchaidh gus sinn fhèin a cho-thaobhadh gu ceart.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Tiomnadh don ath-ghairm taobh a-staigh againn gus ainm an fhaidhle a chlò-bhualadh agus an uairsin an àireamh loidhne a chlò-bhualadh.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Cuir àireamh colbh ris, ma tha e ri fhaighinn.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Tha sinn a-mhàin a 'gabhail cùram mu dheidhinn a' chiad samhla frèam
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}