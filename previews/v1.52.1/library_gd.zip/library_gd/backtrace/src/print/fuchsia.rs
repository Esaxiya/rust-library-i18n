use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // Bidh dl_iterate_phdr a `gabhail fios air ais a gheibh comharradh dl_phdr_info airson a h-uile DSO a chaidh a cheangal a-steach don phròiseas.
    // Bidh dl_iterate_phdr cuideachd a `dèanamh cinnteach gu bheil an ceangal fiùghantach glaiste bho thoiseach gu deireadh an iteachaidh.
    // Ma thilleas an ais-ghairm luach neo-neoni tha an itealadh air a thoirt gu crìch tràth.
    // 'data' thèid gabhail ris mar an treas argamaid ris a `ghairm air ais air gach gairm.
    // 'size' a `toirt meud an dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Feumaidh sinn an ID togail agus cuid de dhàta bunaiteach prògramadh a roinn a tha a `ciallachadh gum feum sinn beagan stuth bhon t-sònrachadh ELF cuideachd.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// A-nis feumaidh sinn ath-riochdachadh, beagan airson beagan, structar an t-seòrsa dl_phdr_info a tha an ceangal fiùghantach gnàthach fuchsia a `cleachdadh.
// Tha a `chrìoch ABI seo aig Chromium cuideachd a bharrachd air crashpad.
// Aig a `cheann thall bu mhath leinn na cùisean sin a ghluasad gus sgrùdadh elf a chleachdadh ach dh` fheumamaid sin a thoirt seachad san SDK agus cha deach sin a dhèanamh fhathast.
//
// Mar sin tha sinn (agus iadsan) an sàs ann a bhith a `cleachdadh an dòigh seo a tha a` tighinn an cois ceangal teann ris an fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Chan eil dòigh againn fios a bhith againn a bheil e_phoff agus e_phnum dligheach.
    // bu chòir libc dèanamh cinnteach à seo dhuinn ge-tà gus am bi e sàbhailte sliseag a chruthachadh an seo.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Tha Elf_Phdr a `riochdachadh bann-cinn prògram ELF 64-bit ann an seasmhachd an ailtireachd targaid.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Tha Phdr a `riochdachadh bann prògram dligheach ELF agus na tha ann.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Chan eil dòigh againn air sgrùdadh a bheil p_addr no p_memsz dligheach.
    // Bidh libc Fuchsia a `parsadh nan notaichean an toiseach ach mar sin air sgàth a bhith an seo feumaidh na cinn-cinn seo a bhith dligheach.
    //
    // Chan eil NoteIter ag iarraidh gum bi an dàta bunaiteach dligheach ach feumaidh e na crìochan a bhith dligheach.
    // Tha sinn an dòchas gu bheil libc air dèanamh cinnteach gu bheil seo fìor dhuinn an seo.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// An seòrsa nota airson IDan togail.
const NT_GNU_BUILD_ID: u32 = 3;

// Tha Elf_Nhdr a `riochdachadh bann-nota nota ELF ann an seasmhachd an targaid.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Tha nota a `riochdachadh nota ELF (header + susbaint).
// Tha an t-ainm air fhàgail mar sliseag u8 oir chan eil e an-còmhnaidh air a thoirt gu crìch agus tha rust ga dhèanamh furasta gu leòr dèanamh cinnteach gu bheil na bytes a `maidseadh an dàrna cuid.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// Leigidh NoteIter leat itealaich gu sàbhailte thairis air earrann nota.
// Bidh e a `tighinn gu crìch cho luath` s a thachras mearachd no nach eil barrachd notaichean ann.
// Ma nì thu ath-aithris air dàta neo-dhligheach bidh e ag obair mar nach deach notaichean a lorg.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Tha e na chleachdadh làidir gu bheil am puing agus am meud a chaidh a thoirt seachad a `comharrachadh raon dligheach de bytes a ghabhas leughadh.
    // Faodaidh susbaint nam bytes sin a bhith mar rud sam bith ach feumaidh an raon a bhith dligheach airson seo a bhith sàbhailte.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// tha align_to a `co-thaobhadh 'x' ri co-thaobhadh` to`-byte a`gabhail ris gur e cumhachd 2 a th` ann an 'to'.
// Tha seo a `leantainn pàtran àbhaisteach ann an còd parsaidh C/C ++ ELF far a bheil (x + gu, 1)&-to air a chleachdadh.
// Cha leig Rust leat dearmad a dhèanamh air cleachdadh gus am bi mi a `cleachdadh
// Tionndadh 2-còmhla gus sin ath-chruthachadh.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// bidh take_bytes_align4 ag ithe num bytes bhon t-slice (ma tha e an làthair) agus a bharrachd air sin a `dèanamh cinnteach gu bheil an sliseag mu dheireadh air a cho-thaobhadh gu ceart.
// Ma tha an dàrna cuid an àireamh de bytes a chaidh iarraidh ro mhòr no nach urrainnear an sliseag ath-dhealbhadh às deidh sin leis nach eil gu leòr de na bytes a tha air fhàgail, chan eil gin air a thilleadh agus chan eil an sliseag air atharrachadh.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Chan eil fìor ionnsaighean aig a `ghnìomh seo a dh` fheumas an neach-conaltraidh cumail suas ach is dòcha gum bu chòir 'bytes' a bhith air a cho-thaobhadh airson coileanadh (agus air cuid de dh `ailtireachd ceart).
// Is dòcha gu bheil na luachan ann an raointean Elf_Nhdr neoni ach tha an gnìomh seo a `dèanamh cinnteach nach bi an leithid de rud ann.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Tha seo sàbhailte fhad `s a tha àite gu leòr ann agus dhearbh sinn sin anns an aithris gu h-àrd agus mar sin cha bu chòir seo a bhith cunnartach.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Thoir fa-near gu bheil sice_of: :<Elf_Nhdr>() A tha an-còmhnaidh 4-Byte rèir a chèile.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Thoir sùil air a bheil sinn air an deireadh a ruighinn.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Bidh sinn ag atharrachadh a-mach nhdr ach bidh sinn a `beachdachadh gu faiceallach air an structar a thig às.
        // Chan eil earbsa againn air na namesz no descsz agus cha bhith sinn a `dèanamh co-dhùnaidhean mì-shàbhailte stèidhichte air an t-seòrsa.
        //
        // Mar sin, eadhon ma gheibh sinn a-mach sgudal iomlan bu chòir dhuinn a bhith sàbhailte fhathast.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// A `nochdadh gu bheil e comasach earrann a chuir an gnìomh.
const PERM_X: u32 = 0b00000001;
/// A `nochdadh gu bheil e comasach earrann a sgrìobhadh.
const PERM_W: u32 = 0b00000010;
/// A `nochdadh gu bheil earrann ri leughadh.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// A `riochdachadh earrann ELF aig àm-ruith.
struct Segment {
    /// A `toirt seachad seòladh brìgheil runtime susbaint na h-earrainn seo.
    addr: usize,
    /// A `toirt meud cuimhne susbaint na h-earrainn seo.
    size: usize,
    /// A `toirt seòladh brìgheil modal a` phìos seo leis an fhaidhle ELF.
    mod_rel_addr: usize,
    /// A `toirt seachad na ceadan a gheibhear ann am faidhle ELF.
    /// Ach is dòcha nach e na ceadan sin a tha an làthair aig àm-ruith.
    flags: Perm,
}

/// A `leigeil aon itealadh thairis air Earrannan bho DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// A `riochdachadh ELF DSO (Rud Co-roinnte Dynamic).
/// Tha an seòrsa seo a `toirt iomradh air an dàta a tha air a stòradh san DSO fhèin seach a bhith a` dèanamh a leth-bhreac fhèin.
struct Dso<'a> {
    /// Bidh an ceangal fiùghantach an-còmhnaidh a `toirt ainm dhuinn, eadhon ged a tha an t-ainm falamh.
    /// Ann an cùis a `phrìomh ghnìomhaiche bidh an t-ainm seo falamh.
    /// Ann an cùis nì co-roinnte is e am soname a th `ann (faic DT_SONAME).
    name: &'a str,
    /// Air Fuchsia tha IDan aig cha mhòr a h-uile binaries ach chan e iarrtas teann a tha seo.
    /// Chan eil dòigh ann fiosrachadh DSO a mhaidseadh le faidhle ELF fìor às deidh sin mura h-eil build_id ann agus mar sin feumaidh sinn gum bi fear an seo aig a h-uile DSO.
    ///
    /// Thathas a `toirt fa-near DSOan às aonais build_id.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// A `tilleadh itealaiche thairis air Earrannan san DSO seo.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Bidh na mearachdan sin a `còdachadh chùisean a thig am bàrr fhad` s a bhios iad a `parsadh fiosrachaidh mu gach DSO.
///
enum Error {
    /// Tha NameError a `ciallachadh gun do thachair mearachd fhad` s a bha e ag atharrachadh sreang stoidhle C gu sreang rust.
    ///
    NameError(core::str::Utf8Error),
    /// Tha BuildIDError a `ciallachadh nach do lorg sinn ID togail.
    /// Dh `fhaodadh seo a bhith air sgàth nach robh ID togail aig an DSO no air sgàth gu robh an earrann anns an ID togail air a dhroch dhealbhadh.
    ///
    BuildIDError,
}

/// A `gairm an dàrna cuid 'dso' no 'error' airson gach DSO ceangailte ris a` phròiseas leis an inneal-ceangail fiùghantach.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter aig am bi aon de na dòighean ithe ris an canar foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr dèanamh cinnteach gu bheil info.name bidh a chomharrachadh dligheach location.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Bidh an gnìomh seo a `clò-bhualadh comharra samhlaiche Fuchsia airson a h-uile fiosrachadh a tha ann an DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}