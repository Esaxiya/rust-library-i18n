use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Riochdachadh cùl-raon seilbh agus fèin-chumte.
///
/// Faodar an structar seo a chleachdadh gus cùl-raon a ghlacadh aig diofar amannan ann am prògram agus an dèidh sin a chleachdadh gus sgrùdadh a dhèanamh air dè a bha an cùl-raon aig an àm sin.
///
///
/// `Backtrace` a `toirt taic do chlò-bhualadh breagha de backtraces tro bhuileachadh `Debug`.
///
/// # Feartan riatanach
///
/// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Tha frèamaichean an seo air an liostadh bho mhullach gu bonn na cruaich
    frames: Vec<BacktraceFrame>,
    // Is e an clàr-amais a tha sinn a `creidsinn a tha mar fhìor thoiseach a` chùl-fhiosrachaidh, a `seachnadh frèamaichean mar `Backtrace::new` agus `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// A ghlacadh dreach de fhrèam ann backtrace.
///
/// Tha an seòrsa seo air a thilleadh mar liosta bho `Backtrace::frames` agus tha e a `riochdachadh aon fhrèam cruachan ann an cùl-raon a chaidh a ghlacadh.
///
/// # Feartan riatanach
///
/// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Tionndadh glaiste de shamhla ann an cùl-raon.
///
/// Tha an seòrsa seo air a thilleadh mar liosta bho `BacktraceFrame::symbols` agus a `riochdachadh na meata-dàta airson samhla ann an cùl-raon.
///
/// # Feartan riatanach
///
/// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// A `glacadh cùl-raon aig làrach gairm na gnìomh seo, a` tilleadh riochdachadh seilbh.
    ///
    /// Tha an gnìomh seo feumail airson a bhith a `riochdachadh cùl-raon mar rud ann an Rust.Faodar an luach seo a thilleadh a chuir air feadh snàithleanan agus air a chlò-bhualadh ann an àite eile, agus is e adhbhar an luach seo a bhith gu tur fèin-chumte.
    ///
    /// Thoir fa-near gum faod e a bhith gu math daor air cuid de àrd-chabhsairean a bhith a `faighinn làn-chùl agus fuasgladh.
    /// Ma tha a `chosgais cus airson an tagradh agad thathar a` moladh `Backtrace::new_unresolved()` a chleachdadh an àite a bhith a `seachnadh ceum fuasgladh nan samhlaidhean (a bhios mar as trice a` toirt nas fhaide) agus a leigeas le sin a chuir dheth gu ceann-latha nas fhaide air adhart.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Feartan riatanach
    ///
    /// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // airson dèanamh cinnteach gu bheil frèam an seo gus a thoirt air falbh
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Coltach ri `new` ach a-mhàin nach bi seo a `fuasgladh samhlaidhean sam bith, tha seo dìreach a` glacadh a `chùl-taic mar liosta de sheòlaidhean.
    ///
    /// Aig àm nas fhaide air adhart faodar an gnìomh `resolve` a ghairm gus samhlaidhean an backtrace seo fhuasgladh gu ainmean a ghabhas leughadh.
    /// Tha an gnìomh seo ann oir faodaidh am pròiseas fuasglaidh ùine mhòr a thoirt ach ged is ann ainneamh a thèid clò-bhualadh sam bith a chlò-bhualadh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // chan eil ainmean samhla ann
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // ainmean samhlaidhean a-nis an làthair
    /// ```
    ///
    /// # Feartan riatanach
    ///
    /// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
    ///
    ///
    ///
    #[inline(never)] // airson dèanamh cinnteach gu bheil frèam an seo gus a thoirt air falbh
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// A `tilleadh na frèamaichean bhon àm a chaidh an cùl-raon seo a ghlacadh.
    ///
    /// Tha coltas gur e a `chiad inntrigeadh den t-slice seo an gnìomh `Backtrace::new`, agus tha coltas ann gu bheil am frèam mu dheireadh rudeigin mu mar a thòisich an snàithlean seo no am prìomh ghnìomh.
    ///
    ///
    /// # Feartan riatanach
    ///
    /// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Ma chaidh an cùl-raon seo a chruthachadh bho `new_unresolved`, rèitichidh an gnìomh seo a h-uile seòladh sa chùl-raon gu na h-ainmean samhlachail aca.
    ///
    ///
    /// Ma chaidh an cùl-raon seo a rèiteachadh roimhe no ma chaidh a chruthachadh tro `new`, chan eil an gnìomh seo a `dèanamh dad.
    ///
    /// # Feartan riatanach
    ///
    /// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Co-ionann ri `Frame::ip`
    ///
    /// # Feartan riatanach
    ///
    /// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Co-ionann ri `Frame::symbol_address`
    ///
    /// # Feartan riatanach
    ///
    /// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Co-ionann ri `Frame::module_base_address`
    ///
    /// # Feartan riatanach
    ///
    /// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// A `tilleadh liosta nan samhlaidhean a tha am frèam seo a` freagairt.
    ///
    /// Mar as trice chan eil ann ach aon samhla airson gach frèam, ach uaireannan ma tha grunn dhleastanasan air an toirt a-steach do aon fhrèam, thèid grunn shamhlaidhean a thilleadh.
    /// Is e a `chiad samhla a tha air a liostadh an "innermost function", ach is e an samhla mu dheireadh an tè as fhaide a-muigh (neach-fios mu dheireadh).
    ///
    /// Thoir fa-near, ma thàinig am frèam seo bho chùl-raon gun fhuasgladh an uairsin tillidh seo liosta falamh.
    ///
    /// # Feartan riatanach
    ///
    /// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Co-ionann ri `Symbol::name`
    ///
    /// # Feartan riatanach
    ///
    /// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Co-ionann ri `Symbol::addr`
    ///
    /// # Feartan riatanach
    ///
    /// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Co-ionann ri `Symbol::filename`
    ///
    /// # Feartan riatanach
    ///
    /// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Co-ionann ri `Symbol::lineno`
    ///
    /// # Feartan riatanach
    ///
    /// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Co-ionann ri `Symbol::colno`
    ///
    /// # Feartan riatanach
    ///
    /// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Nuair a bhios sinn a `clò-bhualadh slighean bidh sinn a` feuchainn ris a `chwd a stialladh ma tha e ann, air dhòigh eile bidh sinn dìreach a` clò-bhualadh na slighe mar a tha.
        // Thoir fa-near nach bi sinn cuideachd a `dèanamh seo ach airson an cruth goirid, oir ma tha e làn tha e coltach gu bheil sinn airson a h-uile càil a chlò-bhualadh.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}