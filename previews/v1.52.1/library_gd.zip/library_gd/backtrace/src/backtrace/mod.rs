use core::ffi::c_void;
use core::fmt;

/// A `sgrùdadh a` chruach gairm a th `ann an-dràsta, a` dol seachad air na frèamaichean gnìomhach uile a-steach don dùnadh a chaidh a thoirt seachad gus cunntas cruachan a thomhas.
///
/// Is e an gnìomh seo inneal-obrach an leabharlainn seo ann a bhith a `tomhas lorgan cruachan airson prògram.Tha an `cb` a chaidh a thoirt seachad a`toirt a-mach eisimpleirean de `Frame` a tha a`riochdachadh fiosrachadh mun fhrèam gairm sin air a`chruach.
/// Tha an dùnadh a `toirt a-mach frèamaichean ann am fasan gu h-àrd (ris an canar gnìomhan an toiseach).
///
/// Tha luach tilleadh an dùnaidh na chomharra air am bu chòir an cùl-raon cumail a `dol.Cuiridh luach tillidh de `false` crìoch air a`chùl-raon agus tillidh e sa bhad.
///
/// Aon uair `s gu bheil `Frame` air fhaighinn is dòcha gum bi thu airson `backtrace::resolve` a ghairm gus an `ip` (stiùireadh stiùiridh) no seòladh samhla a thionndadh gu `Symbol` tro am faodar ainm agus/no ainm faidhle/àireamh loidhne ionnsachadh.
///
///
/// Thoir fa-near gur e gnìomh ìre ìosal a tha seo agus ma tha thu airson, mar eisimpleir, cùl-raon a ghlacadh airson a sgrùdadh nas fhaide air adhart, is dòcha gum bi an seòrsa `Backtrace` nas freagarraiche.
///
/// # Feartan riatanach
///
/// Feumaidh an gnìomh seo feart `std` den `backtrace` crate a chomasachadh, agus tha am feart `std` air a chomasachadh gu bunaiteach.
///
/// # Panics
///
/// Bidh an gnìomh seo a `feuchainn ri panic a-riamh, ach ma thug an `cb` seachad panics, bidh cuid de àrd-chabhsairean a` toirt air panic dùbailte stad a chuir air a `phròiseas.
/// Bidh cuid de dh `àrd-chabhsairean a` cleachdadh leabharlann C a bhios a `cleachdadh glaodhan taobh a-staigh nach gabh faighinn troimhe, agus mar sin ma bhriogas tu air `cb` faodaidh e pròiseas a ghiorrachadh.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // lean air adhart leis a `chùl-raon
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Co-ionann ri `trace`, dìreach mì-shàbhailte oir tha e neo-shioncronach.
///
/// Chan eil geallaidhean sioncronaidh aig a `ghnìomh seo ach tha e ri fhaighinn nuair nach eil am feart `std` den crate seo air a chur ri chèile.
/// Faic gnìomh `trace` airson tuilleadh sgrìobhainnean agus eisimpleirean.
///
/// # Panics
///
/// Faic fiosrachadh air `trace` airson caitean air clisgeadh `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Thug trait a `riochdachadh aon fhrèam de chùl-raon, toradh gu gnìomh `trace` den crate seo.
///
/// Gheibhear frèamaichean a `dùnadh an obair lorg, agus cha mhòr nach eil am frèam air a chuir air falbh leis nach eil fios an-còmhnaidh mun bhuileachadh gu àm ruith.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// A `tilleadh stiùireadh stiùiridh an fhrèam seo an-dràsta.
    ///
    /// Mar as trice is e seo an ath stiùireadh airson a chuir an gnìomh san fhrèam, ach chan eil a h-uile gnìomh a `liostadh seo le cruinneas 100% (ach sa chumantas tha e gu math faisg).
    ///
    ///
    /// Thathas a `moladh an luach seo a thoirt seachad gu `backtrace::resolve` gus a thionndadh gu ainm samhla.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// A `tilleadh stiùireadh stac gnàthach an fhrèam seo.
    ///
    /// Mura h-urrainn do backend a `phuing stac airson an fhrèam seo fhaighinn air ais, thèid puing null a thilleadh.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// A `tilleadh seòladh samhla tòiseachaidh frèam na gnìomh seo.
    ///
    /// Feuchaidh seo ri ath-thionndadh a dhèanamh air a `phuing stiùiridh a thill `ip` gu toiseach a` ghnìomh, a `tilleadh an luach sin.
    ///
    /// Ann an cuid de chùisean, ge-tà, tillidh backends dìreach `ip` bhon ghnìomh seo.
    ///
    /// Faodar an luach a chaidh a thilleadh a chleachdadh uaireannan ma dh `fhàillig `backtrace::resolve` air an `ip` a chaidh a thoirt seachad gu h-àrd.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// A `tilleadh seòladh bunaiteach a` mhodal dham buin am frèam.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Feumaidh seo a thighinn an toiseach, gus dèanamh cinnteach gu bheil Miri a `faighinn prìomhachas thairis air an àrd-ùrlar aoigheachd
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // a-mhàin air a chleachdadh ann an dbghelp a `samhlachadh
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}