//! Taic backtrace a `cleachdadh libunwind/gcc_s/etc APIs.
//!
//! Anns a `mhodal seo tha comas air a` chruach a leigeil a-mach a `cleachdadh APIan ann an stoidhle libunwind.
//! Thoir fa-near gu bheil dòrlach iomlan de bhuileachadh an API coltach ri libunwind, agus tha seo dìreach a `feuchainn ri bhith co-chòrdail ris a` mhòr-chuid dhiubh uile aig an aon àm an àite a bhith piocach.
//!
//!
//! Tha an libunwind API air a stiùireadh le `_Unwind_Backtrace` agus tha e gu math earbsach ann a bhith a `gineadh cùl-raon.
//! Chan eil e gu tur soilleir ciamar a bhios e ga dhèanamh (frèam stiùireadh? Eh_frame info? An dà chuid?) Ach tha e coltach gun obraich e!
//!
//! Tha a `mhòr-chuid de iom-fhillteachd a` mhodal seo a `làimhseachadh nan diofar eadar-dhealachaidhean àrd-ùrlar thairis air buileachadh libunwind.
//! Rud eile tha seo gu math sìmplidh Rust ceangailteach ris na libunwind APIs.
//!
//! Is e seo an API dì-cheadachaidh bunaiteach airson gach àrd-ùrlar nach eil ann an Windows an-dràsta.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// Le stiùireadh libunwind amh cha bu chòir a-riamh faighinn a-steach ann an dòigh furasta le snàithlean, mar sin is e `Sync` a th `ann.
// Nuair a chuireas sinn gu snàithleanan eile tro `Clone` bidh sinn an-còmhnaidh ag atharrachadh gu dreach nach eil a `cumail comharran taobh a-staigh, mar sin bu chòir dhuinn a bhith `Send` cuideachd.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // Tha e coltach gu bheil air OSX `_Unwind_FindEnclosingFunction` a` tilleadh stiùireadh gu ... rudeigin nach eil soilleir.
        // Chan eil e an-còmhnaidh an gnìomh cuairteachaidh airson adhbhar sam bith.
        // Chan eil e gu tur soilleir dhomh dè a tha a `dol an seo, mar sin pessimize seo airson a-nis agus dìreach thoir air ais an ip.
        //
        // Thoir fa-near gu bheil an deuchainn `skip_inner_frames.rs` air a leum air OSX air sgàth a `chlàs seo, agus ma tha seo stèidhichte faodar an deuchainn sin a ruith air OSX!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// Eadar-aghaidh leabharlann neo-fhiosrachail air a chleachdadh airson cùl-stòran
///
/// Thoir fa-near gu bheil còd marbh ceadaichte oir an seo dìreach ceanglaichean chan eil iOS a `cleachdadh a h-uile gin dhiubh ach le bhith a` cur barrachd configs a tha sònraichte don àrd-ùrlar a `truailleadh a` chòd cus
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // air a chleachdadh le ARM EABI a-mhàin
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // Chan eil_Unwind_Backtrace dùthchasach air iOS
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // ri fhaighinn bho GCC 4.2.0, bu chòir a bhith ceart gu leòr airson ar n-adhbhar
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // Is e mì-ainm a th `anns a` ghnìomh seo: an àite a bhith a `faighinn Seòladh Canonical Frame an fhrèam seo (aka SP an neach-fios) bidh e a` tilleadh SP an fhrèam seo.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x a `cleachdadh luach CFA claon, mar sin feumaidh sinn_Unwind_GetGR a chleachdadh gus clàr puing stac (%r15) fhaighinn an àite a bhith an urra ri_Unwind_GetCFA.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // Air android agus gàirdean, tha an gnìomh `_Unwind_GetIP` agus dòrlach de dhaoine eile nam macros, agus mar sin bidh sinn a `mìneachadh ghnìomhan anns a bheil leudachadh nam macros.
    //
    //
    // TODO: ceangal ris an fhaidhle cinn a tha a `mìneachadh nam macros sin, mas urrainn dhut a lorg.
    // (Chan urrainn dhomh, fitzgen, am faidhle cinn a lorg a chaidh cuid de na macro leudachaidhean sin fhaighinn air iasad bho thùs.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 tha comharradh na cruaich air gàirdean.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // Chan eil an gnìomh seo ann cuideachd air Android no ARM/Linux, mar sin dèan e neo-op.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}