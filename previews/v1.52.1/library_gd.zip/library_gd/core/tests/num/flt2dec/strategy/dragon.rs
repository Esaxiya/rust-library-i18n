use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Tha Miri ro shlaodach
fn exact_sanity_test() {
    // Tha an deuchainn seo a 'ruith suas cinn dè as urrainn dhomh a-mhàin a tha a' gabhail cuid de oisean-Ish chùis `exp2` an leabharlainn gnìomh, air am mìneachadh ann an ge bith dè C runtime sinn a 'cleachdadh.
    // Ann an VS 2013 tha e coltach gu robh bug air a `ghnìomh seo leis gu bheil an deuchainn seo a` fàiligeadh nuair a tha e ceangailte, ach le VS 2015 tha coltas ann gu bheil am biast stèidhichte oir tha an deuchainn a `ruith gu math.
    //
    // Tha e coltach gu bheil am biast mar eadar-dhealachadh ann an luach toraidh `exp2(-1057)`, far an till e ann an VS 2013 dùbailte leis a `phàtran bit 0x2 agus ann an VS 2015 bidh e a` tilleadh 0x20000.
    //
    //
    // Airson a-nis dìreach leig seachad an deuchainn seo gu tur air MSVC oir tha e air a dhearbhadh ann an àite eile co-dhiù agus chan eil ùidh mhòr againn ann a bhith a `dèanamh deuchainn air buileachadh exp2 gach àrd-ùrlar.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}