use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Chan e farsaingeachd uachdar seasmhach a tha seo, ach tha e a `cuideachadh le bhith a` cumail `?` saor eatorra, eadhon ged nach urrainn do LLVM brath a ghabhail air an-dràsta.
    //
    // (Gu mì-fhortanach Toradh Roghainn agus tha neo-chunbhalach, mar sin chan urrainn ControlFlow mhaidseadh an dà chuid.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}