use core::cell::Cell;
use core::cmp::Ordering;
use core::result::Result::{Err, Ok};

#[test]
fn test_position() {
    let b = [1, 2, 3, 5, 5];
    assert_eq!(b.iter().position(|&v| v == 9), None);
    assert_eq!(b.iter().position(|&v| v == 5), Some(3));
    assert_eq!(b.iter().position(|&v| v == 3), Some(2));
    assert_eq!(b.iter().position(|&v| v == 0), None);
}

#[test]
fn test_rposition() {
    let b = [1, 2, 3, 5, 5];
    assert_eq!(b.iter().rposition(|&v| v == 9), None);
    assert_eq!(b.iter().rposition(|&v| v == 5), Some(4));
    assert_eq!(b.iter().rposition(|&v| v == 3), Some(2));
    assert_eq!(b.iter().rposition(|&v| v == 0), None);
}

#[test]
fn test_binary_search() {
    let b: [i32; 0] = [];
    assert_eq!(b.binary_search(&5), Err(0));

    let b = [4];
    assert_eq!(b.binary_search(&3), Err(0));
    assert_eq!(b.binary_search(&4), Ok(0));
    assert_eq!(b.binary_search(&5), Err(1));

    let b = [1, 2, 4, 6, 8, 9];
    assert_eq!(b.binary_search(&5), Err(3));
    assert_eq!(b.binary_search(&6), Ok(3));
    assert_eq!(b.binary_search(&7), Err(4));
    assert_eq!(b.binary_search(&8), Ok(4));

    let b = [1, 2, 4, 5, 6, 8];
    assert_eq!(b.binary_search(&9), Err(6));

    let b = [1, 2, 4, 6, 7, 8, 9];
    assert_eq!(b.binary_search(&6), Ok(3));
    assert_eq!(b.binary_search(&5), Err(3));
    assert_eq!(b.binary_search(&8), Ok(5));

    let b = [1, 2, 4, 5, 6, 8, 9];
    assert_eq!(b.binary_search(&7), Err(5));
    assert_eq!(b.binary_search(&0), Err(0));

    let b = [1, 3, 3, 3, 7];
    assert_eq!(b.binary_search(&0), Err(0));
    assert_eq!(b.binary_search(&1), Ok(0));
    assert_eq!(b.binary_search(&2), Err(1));
    assert!(match b.binary_search(&3) {
        Ok(1..=3) => true,
        _ => false,
    });
    assert!(match b.binary_search(&3) {
        Ok(1..=3) => true,
        _ => false,
    });
    assert_eq!(b.binary_search(&4), Err(4));
    assert_eq!(b.binary_search(&5), Err(4));
    assert_eq!(b.binary_search(&6), Err(4));
    assert_eq!(b.binary_search(&7), Ok(4));
    assert_eq!(b.binary_search(&8), Err(5));

    let b = [(); usize::MAX];
    assert_eq!(b.binary_search(&()), Ok(usize::MAX / 2));
}

#[test]
fn test_binary_search_by_overflow() {
    let b = [(); usize::MAX];
    assert_eq!(b.binary_search_by(|_| Ordering::Equal), Ok(usize::MAX / 2));
    assert_eq!(b.binary_search_by(|_| Ordering::Greater), Err(0));
    assert_eq!(b.binary_search_by(|_| Ordering::Less), Err(usize::MAX));
}

#[test]
// Dèan deuchainn air giùlan sònraichte buileachaidh nuair a lorgas tu eileamaidean co-ionann.
// Tha e ceart gu leòr a bhriseadh an deuchainn seo, ach nuair a nì thu t-sloc ruith e air leth glic.
fn test_binary_search_implementation_details() {
    let b = [1, 1, 2, 2, 3, 3, 3];
    assert_eq!(b.binary_search(&1), Ok(1));
    assert_eq!(b.binary_search(&2), Ok(3));
    assert_eq!(b.binary_search(&3), Ok(5));
    let b = [1, 1, 1, 1, 1, 3, 3, 3, 3];
    assert_eq!(b.binary_search(&1), Ok(4));
    assert_eq!(b.binary_search(&3), Ok(7));
    let b = [1, 1, 1, 1, 3, 3, 3, 3, 3];
    assert_eq!(b.binary_search(&1), Ok(2));
    assert_eq!(b.binary_search(&3), Ok(4));
}

#[test]
fn test_partition_point() {
    let b: [i32; 0] = [];
    assert_eq!(b.partition_point(|&x| x < 5), 0);

    let b = [4];
    assert_eq!(b.partition_point(|&x| x < 3), 0);
    assert_eq!(b.partition_point(|&x| x < 4), 0);
    assert_eq!(b.partition_point(|&x| x < 5), 1);

    let b = [1, 2, 4, 6, 8, 9];
    assert_eq!(b.partition_point(|&x| x < 5), 3);
    assert_eq!(b.partition_point(|&x| x < 6), 3);
    assert_eq!(b.partition_point(|&x| x < 7), 4);
    assert_eq!(b.partition_point(|&x| x < 8), 4);

    let b = [1, 2, 4, 5, 6, 8];
    assert_eq!(b.partition_point(|&x| x < 9), 6);

    let b = [1, 2, 4, 6, 7, 8, 9];
    assert_eq!(b.partition_point(|&x| x < 6), 3);
    assert_eq!(b.partition_point(|&x| x < 5), 3);
    assert_eq!(b.partition_point(|&x| x < 8), 5);

    let b = [1, 2, 4, 5, 6, 8, 9];
    assert_eq!(b.partition_point(|&x| x < 7), 5);
    assert_eq!(b.partition_point(|&x| x < 0), 0);

    let b = [1, 3, 3, 3, 7];
    assert_eq!(b.partition_point(|&x| x < 0), 0);
    assert_eq!(b.partition_point(|&x| x < 1), 0);
    assert_eq!(b.partition_point(|&x| x < 2), 1);
    assert_eq!(b.partition_point(|&x| x < 3), 1);
    assert_eq!(b.partition_point(|&x| x < 4), 4);
    assert_eq!(b.partition_point(|&x| x < 5), 4);
    assert_eq!(b.partition_point(|&x| x < 6), 4);
    assert_eq!(b.partition_point(|&x| x < 7), 4);
    assert_eq!(b.partition_point(|&x| x < 8), 5);
}

#[test]
fn test_iterator_nth() {
    let v: &[_] = &[0, 1, 2, 3, 4];
    for i in 0..v.len() {
        assert_eq!(v.iter().nth(i).unwrap(), &v[i]);
    }
    assert_eq!(v.iter().nth(v.len()), None);

    let mut iter = v.iter();
    assert_eq!(iter.nth(2).unwrap(), &v[2]);
    assert_eq!(iter.nth(1).unwrap(), &v[4]);
}

#[test]
fn test_iterator_nth_back() {
    let v: &[_] = &[0, 1, 2, 3, 4];
    for i in 0..v.len() {
        assert_eq!(v.iter().nth_back(i).unwrap(), &v[v.len() - i - 1]);
    }
    assert_eq!(v.iter().nth_back(v.len()), None);

    let mut iter = v.iter();
    assert_eq!(iter.nth_back(2).unwrap(), &v[2]);
    assert_eq!(iter.nth_back(1).unwrap(), &v[0]);
}

#[test]
fn test_iterator_last() {
    let v: &[_] = &[0, 1, 2, 3, 4];
    assert_eq!(v.iter().last().unwrap(), &4);
    assert_eq!(v[..1].iter().last().unwrap(), &0);
}

#[test]
fn test_iterator_count() {
    let v: &[_] = &[0, 1, 2, 3, 4];
    assert_eq!(v.iter().count(), 5);

    let mut iter2 = v.iter();
    iter2.next();
    iter2.next();
    assert_eq!(iter2.count(), 3);
}

#[test]
fn test_chunks_count() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let c = v.chunks(3);
    assert_eq!(c.count(), 2);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let c2 = v2.chunks(2);
    assert_eq!(c2.count(), 3);

    let v3: &[i32] = &[];
    let c3 = v3.chunks(2);
    assert_eq!(c3.count(), 0);
}

#[test]
fn test_chunks_nth() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let mut c = v.chunks(2);
    assert_eq!(c.nth(1).unwrap(), &[2, 3]);
    assert_eq!(c.next().unwrap(), &[4, 5]);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let mut c2 = v2.chunks(3);
    assert_eq!(c2.nth(1).unwrap(), &[3, 4]);
    assert_eq!(c2.next(), None);
}

#[test]
fn test_chunks_nth_back() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let mut c = v.chunks(2);
    assert_eq!(c.nth_back(1).unwrap(), &[2, 3]);
    assert_eq!(c.next().unwrap(), &[0, 1]);
    assert_eq!(c.next(), None);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let mut c2 = v2.chunks(3);
    assert_eq!(c2.nth_back(1).unwrap(), &[0, 1, 2]);
    assert_eq!(c2.next(), None);
    assert_eq!(c2.next_back(), None);

    let v3: &[i32] = &[0, 1, 2, 3, 4];
    let mut c3 = v3.chunks(10);
    assert_eq!(c3.nth_back(0).unwrap(), &[0, 1, 2, 3, 4]);
    assert_eq!(c3.next(), None);

    let v4: &[i32] = &[0, 1, 2];
    let mut c4 = v4.chunks(10);
    assert_eq!(c4.nth_back(1_000_000_000usize), None);
}

#[test]
fn test_chunks_last() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let c = v.chunks(2);
    assert_eq!(c.last().unwrap()[1], 5);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let c2 = v2.chunks(2);
    assert_eq!(c2.last().unwrap()[0], 4);
}

#[test]
fn test_chunks_zip() {
    let v1: &[i32] = &[0, 1, 2, 3, 4];
    let v2: &[i32] = &[6, 7, 8, 9, 10];

    let res = v1
        .chunks(2)
        .zip(v2.chunks(2))
        .map(|(a, b)| a.iter().sum::<i32>() + b.iter().sum::<i32>())
        .collect::<Vec<_>>();
    assert_eq!(res, vec![14, 22, 14]);
}

#[test]
fn test_chunks_mut_count() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let c = v.chunks_mut(3);
    assert_eq!(c.count(), 2);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let c2 = v2.chunks_mut(2);
    assert_eq!(c2.count(), 3);

    let v3: &mut [i32] = &mut [];
    let c3 = v3.chunks_mut(2);
    assert_eq!(c3.count(), 0);
}

#[test]
fn test_chunks_mut_nth() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let mut c = v.chunks_mut(2);
    assert_eq!(c.nth(1).unwrap(), &[2, 3]);
    assert_eq!(c.next().unwrap(), &[4, 5]);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let mut c2 = v2.chunks_mut(3);
    assert_eq!(c2.nth(1).unwrap(), &[3, 4]);
    assert_eq!(c2.next(), None);
}

#[test]
fn test_chunks_mut_nth_back() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let mut c = v.chunks_mut(2);
    assert_eq!(c.nth_back(1).unwrap(), &[2, 3]);
    assert_eq!(c.next().unwrap(), &[0, 1]);

    let v1: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let mut c1 = v1.chunks_mut(3);
    assert_eq!(c1.nth_back(1).unwrap(), &[0, 1, 2]);
    assert_eq!(c1.next(), None);

    let v3: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let mut c3 = v3.chunks_mut(10);
    assert_eq!(c3.nth_back(0).unwrap(), &[0, 1, 2, 3, 4]);
    assert_eq!(c3.next(), None);

    let v4: &mut [i32] = &mut [0, 1, 2];
    let mut c4 = v4.chunks_mut(10);
    assert_eq!(c4.nth_back(1_000_000_000usize), None);
}

#[test]
fn test_chunks_mut_last() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let c = v.chunks_mut(2);
    assert_eq!(c.last().unwrap(), &[4, 5]);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let c2 = v2.chunks_mut(2);
    assert_eq!(c2.last().unwrap(), &[4]);
}

#[test]
fn test_chunks_mut_zip() {
    let v1: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let v2: &[i32] = &[6, 7, 8, 9, 10];

    for (a, b) in v1.chunks_mut(2).zip(v2.chunks(2)) {
        let sum = b.iter().sum::<i32>();
        for v in a {
            *v += sum;
        }
    }
    assert_eq!(v1, [13, 14, 19, 20, 14]);
}

#[test]
fn test_chunks_exact_count() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let c = v.chunks_exact(3);
    assert_eq!(c.count(), 2);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let c2 = v2.chunks_exact(2);
    assert_eq!(c2.count(), 2);

    let v3: &[i32] = &[];
    let c3 = v3.chunks_exact(2);
    assert_eq!(c3.count(), 0);
}

#[test]
fn test_chunks_exact_nth() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let mut c = v.chunks_exact(2);
    assert_eq!(c.nth(1).unwrap(), &[2, 3]);
    assert_eq!(c.next().unwrap(), &[4, 5]);

    let v2: &[i32] = &[0, 1, 2, 3, 4, 5, 6];
    let mut c2 = v2.chunks_exact(3);
    assert_eq!(c2.nth(1).unwrap(), &[3, 4, 5]);
    assert_eq!(c2.next(), None);
}

#[test]
fn test_chunks_exact_nth_back() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let mut c = v.chunks_exact(2);
    assert_eq!(c.nth_back(1).unwrap(), &[2, 3]);
    assert_eq!(c.next().unwrap(), &[0, 1]);
    assert_eq!(c.next(), None);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let mut c2 = v2.chunks_exact(3);
    assert_eq!(c2.nth_back(0).unwrap(), &[0, 1, 2]);
    assert_eq!(c2.next(), None);
    assert_eq!(c2.next_back(), None);

    let v3: &[i32] = &[0, 1, 2, 3, 4];
    let mut c3 = v3.chunks_exact(10);
    assert_eq!(c3.nth_back(0), None);
}

#[test]
fn test_chunks_exact_last() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let c = v.chunks_exact(2);
    assert_eq!(c.last().unwrap(), &[4, 5]);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let c2 = v2.chunks_exact(2);
    assert_eq!(c2.last().unwrap(), &[2, 3]);
}

#[test]
fn test_chunks_exact_remainder() {
    let v: &[i32] = &[0, 1, 2, 3, 4];
    let c = v.chunks_exact(2);
    assert_eq!(c.remainder(), &[4]);
}

#[test]
fn test_chunks_exact_zip() {
    let v1: &[i32] = &[0, 1, 2, 3, 4];
    let v2: &[i32] = &[6, 7, 8, 9, 10];

    let res = v1
        .chunks_exact(2)
        .zip(v2.chunks_exact(2))
        .map(|(a, b)| a.iter().sum::<i32>() + b.iter().sum::<i32>())
        .collect::<Vec<_>>();
    assert_eq!(res, vec![14, 22]);
}

#[test]
fn test_chunks_exact_mut_count() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let c = v.chunks_exact_mut(3);
    assert_eq!(c.count(), 2);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let c2 = v2.chunks_exact_mut(2);
    assert_eq!(c2.count(), 2);

    let v3: &mut [i32] = &mut [];
    let c3 = v3.chunks_exact_mut(2);
    assert_eq!(c3.count(), 0);
}

#[test]
fn test_chunks_exact_mut_nth() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let mut c = v.chunks_exact_mut(2);
    assert_eq!(c.nth(1).unwrap(), &[2, 3]);
    assert_eq!(c.next().unwrap(), &[4, 5]);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4, 5, 6];
    let mut c2 = v2.chunks_exact_mut(3);
    assert_eq!(c2.nth(1).unwrap(), &[3, 4, 5]);
    assert_eq!(c2.next(), None);
}

#[test]
fn test_chunks_exact_mut_nth_back() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let mut c = v.chunks_exact_mut(2);
    assert_eq!(c.nth_back(1).unwrap(), &[2, 3]);
    assert_eq!(c.next().unwrap(), &[0, 1]);
    assert_eq!(c.next(), None);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let mut c2 = v2.chunks_exact_mut(3);
    assert_eq!(c2.nth_back(0).unwrap(), &[0, 1, 2]);
    assert_eq!(c2.next(), None);
    assert_eq!(c2.next_back(), None);

    let v3: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let mut c3 = v3.chunks_exact_mut(10);
    assert_eq!(c3.nth_back(0), None);
}

#[test]
fn test_chunks_exact_mut_last() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let c = v.chunks_exact_mut(2);
    assert_eq!(c.last().unwrap(), &[4, 5]);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let c2 = v2.chunks_exact_mut(2);
    assert_eq!(c2.last().unwrap(), &[2, 3]);
}

#[test]
fn test_chunks_exact_mut_remainder() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let c = v.chunks_exact_mut(2);
    assert_eq!(c.into_remainder(), &[4]);
}

#[test]
fn test_chunks_exact_mut_zip() {
    let v1: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let v2: &[i32] = &[6, 7, 8, 9, 10];

    for (a, b) in v1.chunks_exact_mut(2).zip(v2.chunks_exact(2)) {
        let sum = b.iter().sum::<i32>();
        for v in a {
            *v += sum;
        }
    }
    assert_eq!(v1, [13, 14, 19, 20, 4]);
}

#[test]
fn test_array_chunks_infer() {
    let v: &[i32] = &[0, 1, 2, 3, 4, -4];
    let c = v.array_chunks();
    for &[a, b, c] in c {
        assert_eq!(a + b + c, 3);
    }

    let v2: &[i32] = &[0, 1, 2, 3, 4, 5, 6];
    let total = v2.array_chunks().map(|&[a, b]| a * b).sum::<i32>();
    assert_eq!(total, 2 * 3 + 4 * 5);
}

#[test]
fn test_array_chunks_count() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let c = v.array_chunks::<3>();
    assert_eq!(c.count(), 2);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let c2 = v2.array_chunks::<2>();
    assert_eq!(c2.count(), 2);

    let v3: &[i32] = &[];
    let c3 = v3.array_chunks::<2>();
    assert_eq!(c3.count(), 0);
}

#[test]
fn test_array_chunks_nth() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let mut c = v.array_chunks::<2>();
    assert_eq!(c.nth(1).unwrap(), &[2, 3]);
    assert_eq!(c.next().unwrap(), &[4, 5]);

    let v2: &[i32] = &[0, 1, 2, 3, 4, 5, 6];
    let mut c2 = v2.array_chunks::<3>();
    assert_eq!(c2.nth(1).unwrap(), &[3, 4, 5]);
    assert_eq!(c2.next(), None);
}

#[test]
fn test_array_chunks_nth_back() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let mut c = v.array_chunks::<2>();
    assert_eq!(c.nth_back(1).unwrap(), &[2, 3]);
    assert_eq!(c.next().unwrap(), &[0, 1]);
    assert_eq!(c.next(), None);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let mut c2 = v2.array_chunks::<3>();
    assert_eq!(c2.nth_back(0).unwrap(), &[0, 1, 2]);
    assert_eq!(c2.next(), None);
    assert_eq!(c2.next_back(), None);

    let v3: &[i32] = &[0, 1, 2, 3, 4];
    let mut c3 = v3.array_chunks::<10>();
    assert_eq!(c3.nth_back(0), None);
}

#[test]
fn test_array_chunks_last() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let c = v.array_chunks::<2>();
    assert_eq!(c.last().unwrap(), &[4, 5]);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let c2 = v2.array_chunks::<2>();
    assert_eq!(c2.last().unwrap(), &[2, 3]);
}

#[test]
fn test_array_chunks_remainder() {
    let v: &[i32] = &[0, 1, 2, 3, 4];
    let c = v.array_chunks::<2>();
    assert_eq!(c.remainder(), &[4]);
}

#[test]
fn test_array_chunks_zip() {
    let v1: &[i32] = &[0, 1, 2, 3, 4];
    let v2: &[i32] = &[6, 7, 8, 9, 10];

    let res = v1
        .array_chunks::<2>()
        .zip(v2.array_chunks::<2>())
        .map(|(a, b)| a.iter().sum::<i32>() + b.iter().sum::<i32>())
        .collect::<Vec<_>>();
    assert_eq!(res, vec![14, 22]);
}

#[test]
fn test_array_chunks_mut_infer() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5, 6];
    for a in v.array_chunks_mut() {
        let sum = a.iter().sum::<i32>();
        *a = [sum; 3];
    }
    assert_eq!(v, &[3, 3, 3, 12, 12, 12, 6]);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4, 5, 6];
    v2.array_chunks_mut().for_each(|[a, b]| core::mem::swap(a, b));
    assert_eq!(v2, &[1, 0, 3, 2, 5, 4, 6]);
}

#[test]
fn test_array_chunks_mut_count() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let c = v.array_chunks_mut::<3>();
    assert_eq!(c.count(), 2);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let c2 = v2.array_chunks_mut::<2>();
    assert_eq!(c2.count(), 2);

    let v3: &mut [i32] = &mut [];
    let c3 = v3.array_chunks_mut::<2>();
    assert_eq!(c3.count(), 0);
}

#[test]
fn test_array_chunks_mut_nth() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let mut c = v.array_chunks_mut::<2>();
    assert_eq!(c.nth(1).unwrap(), &[2, 3]);
    assert_eq!(c.next().unwrap(), &[4, 5]);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4, 5, 6];
    let mut c2 = v2.array_chunks_mut::<3>();
    assert_eq!(c2.nth(1).unwrap(), &[3, 4, 5]);
    assert_eq!(c2.next(), None);
}

#[test]
fn test_array_chunks_mut_nth_back() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let mut c = v.array_chunks_mut::<2>();
    assert_eq!(c.nth_back(1).unwrap(), &[2, 3]);
    assert_eq!(c.next().unwrap(), &[0, 1]);
    assert_eq!(c.next(), None);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let mut c2 = v2.array_chunks_mut::<3>();
    assert_eq!(c2.nth_back(0).unwrap(), &[0, 1, 2]);
    assert_eq!(c2.next(), None);
    assert_eq!(c2.next_back(), None);

    let v3: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let mut c3 = v3.array_chunks_mut::<10>();
    assert_eq!(c3.nth_back(0), None);
}

#[test]
fn test_array_chunks_mut_last() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let c = v.array_chunks_mut::<2>();
    assert_eq!(c.last().unwrap(), &[4, 5]);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let c2 = v2.array_chunks_mut::<2>();
    assert_eq!(c2.last().unwrap(), &[2, 3]);
}

#[test]
fn test_array_chunks_mut_remainder() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let c = v.array_chunks_mut::<2>();
    assert_eq!(c.into_remainder(), &[4]);
}

#[test]
fn test_array_chunks_mut_zip() {
    let v1: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let v2: &[i32] = &[6, 7, 8, 9, 10];

    for (a, b) in v1.array_chunks_mut::<2>().zip(v2.array_chunks::<2>()) {
        let sum = b.iter().sum::<i32>();
        for v in a {
            *v += sum;
        }
    }
    assert_eq!(v1, [13, 14, 19, 20, 4]);
}

#[test]
fn test_array_windows_infer() {
    let v: &[i32] = &[0, 1, 0, 1];
    assert_eq!(v.array_windows::<2>().count(), 3);
    let c = v.array_windows();
    for &[a, b] in c {
        assert_eq!(a + b, 1);
    }

    let v2: &[i32] = &[0, 1, 2, 3, 4, 5, 6];
    let total = v2.array_windows().map(|&[a, b, c]| a + b + c).sum::<i32>();
    assert_eq!(total, 3 + 6 + 9 + 12 + 15);
}

#[test]
fn test_array_windows_count() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let c = v.array_windows::<3>();
    assert_eq!(c.count(), 4);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let c2 = v2.array_windows::<6>();
    assert_eq!(c2.count(), 0);

    let v3: &[i32] = &[];
    let c3 = v3.array_windows::<2>();
    assert_eq!(c3.count(), 0);
}

#[test]
fn test_array_windows_nth() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let snd = v.array_windows::<4>().nth(1);
    assert_eq!(snd, Some(&[1, 2, 3, 4]));
    let mut arr_windows = v.array_windows::<2>();
    assert_ne!(arr_windows.nth(0), arr_windows.nth(0));
    let last = v.array_windows::<3>().last();
    assert_eq!(last, Some(&[3, 4, 5]));
}

#[test]
fn test_array_windows_nth_back() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let snd = v.array_windows::<4>().nth_back(1);
    assert_eq!(snd, Some(&[1, 2, 3, 4]));
    let mut arr_windows = v.array_windows::<2>();
    assert_ne!(arr_windows.nth_back(0), arr_windows.nth_back(0));
}

#[test]
fn test_rchunks_count() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let c = v.rchunks(3);
    assert_eq!(c.count(), 2);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let c2 = v2.rchunks(2);
    assert_eq!(c2.count(), 3);

    let v3: &[i32] = &[];
    let c3 = v3.rchunks(2);
    assert_eq!(c3.count(), 0);
}

#[test]
fn test_rchunks_nth() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let mut c = v.rchunks(2);
    assert_eq!(c.nth(1).unwrap(), &[2, 3]);
    assert_eq!(c.next().unwrap(), &[0, 1]);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let mut c2 = v2.rchunks(3);
    assert_eq!(c2.nth(1).unwrap(), &[0, 1]);
    assert_eq!(c2.next(), None);
}

#[test]
fn test_rchunks_nth_back() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let mut c = v.rchunks(2);
    assert_eq!(c.nth_back(1).unwrap(), &[2, 3]);
    assert_eq!(c.next_back().unwrap(), &[4, 5]);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let mut c2 = v2.rchunks(3);
    assert_eq!(c2.nth_back(1).unwrap(), &[2, 3, 4]);
    assert_eq!(c2.next_back(), None);
}

#[test]
fn test_rchunks_last() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let c = v.rchunks(2);
    assert_eq!(c.last().unwrap()[1], 1);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let c2 = v2.rchunks(2);
    assert_eq!(c2.last().unwrap()[0], 0);
}

#[test]
fn test_rchunks_zip() {
    let v1: &[i32] = &[0, 1, 2, 3, 4];
    let v2: &[i32] = &[6, 7, 8, 9, 10];

    let res = v1
        .rchunks(2)
        .zip(v2.rchunks(2))
        .map(|(a, b)| a.iter().sum::<i32>() + b.iter().sum::<i32>())
        .collect::<Vec<_>>();
    assert_eq!(res, vec![26, 18, 6]);
}

#[test]
fn test_rchunks_mut_count() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let c = v.rchunks_mut(3);
    assert_eq!(c.count(), 2);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let c2 = v2.rchunks_mut(2);
    assert_eq!(c2.count(), 3);

    let v3: &mut [i32] = &mut [];
    let c3 = v3.rchunks_mut(2);
    assert_eq!(c3.count(), 0);
}

#[test]
fn test_rchunks_mut_nth() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let mut c = v.rchunks_mut(2);
    assert_eq!(c.nth(1).unwrap(), &[2, 3]);
    assert_eq!(c.next().unwrap(), &[0, 1]);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let mut c2 = v2.rchunks_mut(3);
    assert_eq!(c2.nth(1).unwrap(), &[0, 1]);
    assert_eq!(c2.next(), None);
}

#[test]
fn test_rchunks_mut_nth_back() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let mut c = v.rchunks_mut(2);
    assert_eq!(c.nth_back(1).unwrap(), &[2, 3]);
    assert_eq!(c.next_back().unwrap(), &[4, 5]);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let mut c2 = v2.rchunks_mut(3);
    assert_eq!(c2.nth_back(1).unwrap(), &[2, 3, 4]);
    assert_eq!(c2.next_back(), None);
}

#[test]
fn test_rchunks_mut_last() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let c = v.rchunks_mut(2);
    assert_eq!(c.last().unwrap(), &[0, 1]);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let c2 = v2.rchunks_mut(2);
    assert_eq!(c2.last().unwrap(), &[0]);
}

#[test]
fn test_rchunks_mut_zip() {
    let v1: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let v2: &[i32] = &[6, 7, 8, 9, 10];

    for (a, b) in v1.rchunks_mut(2).zip(v2.rchunks(2)) {
        let sum = b.iter().sum::<i32>();
        for v in a {
            *v += sum;
        }
    }
    assert_eq!(v1, [6, 16, 17, 22, 23]);
}

#[test]
fn test_rchunks_exact_count() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let c = v.rchunks_exact(3);
    assert_eq!(c.count(), 2);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let c2 = v2.rchunks_exact(2);
    assert_eq!(c2.count(), 2);

    let v3: &[i32] = &[];
    let c3 = v3.rchunks_exact(2);
    assert_eq!(c3.count(), 0);
}

#[test]
fn test_rchunks_exact_nth() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let mut c = v.rchunks_exact(2);
    assert_eq!(c.nth(1).unwrap(), &[2, 3]);
    assert_eq!(c.next().unwrap(), &[0, 1]);

    let v2: &[i32] = &[0, 1, 2, 3, 4, 5, 6];
    let mut c2 = v2.rchunks_exact(3);
    assert_eq!(c2.nth(1).unwrap(), &[1, 2, 3]);
    assert_eq!(c2.next(), None);
}

#[test]
fn test_rchunks_exact_nth_back() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let mut c = v.rchunks_exact(2);
    assert_eq!(c.nth_back(1).unwrap(), &[2, 3]);
    assert_eq!(c.next_back().unwrap(), &[4, 5]);

    let v2: &[i32] = &[0, 1, 2, 3, 4, 5, 6];
    let mut c2 = v2.rchunks_exact(3);
    assert_eq!(c2.nth_back(1).unwrap(), &[4, 5, 6]);
    assert_eq!(c2.next(), None);
}

#[test]
fn test_rchunks_exact_last() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let c = v.rchunks_exact(2);
    assert_eq!(c.last().unwrap(), &[0, 1]);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let c2 = v2.rchunks_exact(2);
    assert_eq!(c2.last().unwrap(), &[1, 2]);
}

#[test]
fn test_rchunks_exact_remainder() {
    let v: &[i32] = &[0, 1, 2, 3, 4];
    let c = v.rchunks_exact(2);
    assert_eq!(c.remainder(), &[0]);
}

#[test]
fn test_rchunks_exact_zip() {
    let v1: &[i32] = &[0, 1, 2, 3, 4];
    let v2: &[i32] = &[6, 7, 8, 9, 10];

    let res = v1
        .rchunks_exact(2)
        .zip(v2.rchunks_exact(2))
        .map(|(a, b)| a.iter().sum::<i32>() + b.iter().sum::<i32>())
        .collect::<Vec<_>>();
    assert_eq!(res, vec![26, 18]);
}

#[test]
fn test_rchunks_exact_mut_count() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let c = v.rchunks_exact_mut(3);
    assert_eq!(c.count(), 2);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let c2 = v2.rchunks_exact_mut(2);
    assert_eq!(c2.count(), 2);

    let v3: &mut [i32] = &mut [];
    let c3 = v3.rchunks_exact_mut(2);
    assert_eq!(c3.count(), 0);
}

#[test]
fn test_rchunks_exact_mut_nth() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let mut c = v.rchunks_exact_mut(2);
    assert_eq!(c.nth(1).unwrap(), &[2, 3]);
    assert_eq!(c.next().unwrap(), &[0, 1]);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4, 5, 6];
    let mut c2 = v2.rchunks_exact_mut(3);
    assert_eq!(c2.nth(1).unwrap(), &[1, 2, 3]);
    assert_eq!(c2.next(), None);
}

#[test]
fn test_rchunks_exact_mut_nth_back() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let mut c = v.rchunks_exact_mut(2);
    assert_eq!(c.nth_back(1).unwrap(), &[2, 3]);
    assert_eq!(c.next_back().unwrap(), &[4, 5]);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4, 5, 6];
    let mut c2 = v2.rchunks_exact_mut(3);
    assert_eq!(c2.nth_back(1).unwrap(), &[4, 5, 6]);
    assert_eq!(c2.next(), None);
}

#[test]
fn test_rchunks_exact_mut_last() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4, 5];
    let c = v.rchunks_exact_mut(2);
    assert_eq!(c.last().unwrap(), &[0, 1]);

    let v2: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let c2 = v2.rchunks_exact_mut(2);
    assert_eq!(c2.last().unwrap(), &[1, 2]);
}

#[test]
fn test_rchunks_exact_mut_remainder() {
    let v: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let c = v.rchunks_exact_mut(2);
    assert_eq!(c.into_remainder(), &[0]);
}

#[test]
fn test_rchunks_exact_mut_zip() {
    let v1: &mut [i32] = &mut [0, 1, 2, 3, 4];
    let v2: &[i32] = &[6, 7, 8, 9, 10];

    for (a, b) in v1.rchunks_exact_mut(2).zip(v2.rchunks_exact(2)) {
        let sum = b.iter().sum::<i32>();
        for v in a {
            *v += sum;
        }
    }
    assert_eq!(v1, [0, 16, 17, 22, 23]);
}

#[test]
fn test_windows_count() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let c = v.windows(3);
    assert_eq!(c.count(), 4);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let c2 = v2.windows(6);
    assert_eq!(c2.count(), 0);

    let v3: &[i32] = &[];
    let c3 = v3.windows(2);
    assert_eq!(c3.count(), 0);
}

#[test]
fn test_windows_nth() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let mut c = v.windows(2);
    assert_eq!(c.nth(2).unwrap()[1], 3);
    assert_eq!(c.next().unwrap()[0], 3);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let mut c2 = v2.windows(4);
    assert_eq!(c2.nth(1).unwrap()[1], 2);
    assert_eq!(c2.next(), None);
}

#[test]
fn test_windows_nth_back() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let mut c = v.windows(2);
    assert_eq!(c.nth_back(2).unwrap()[0], 2);
    assert_eq!(c.next_back().unwrap()[1], 2);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let mut c2 = v2.windows(4);
    assert_eq!(c2.nth_back(1).unwrap()[1], 1);
    assert_eq!(c2.next_back(), None);
}

#[test]
fn test_windows_last() {
    let v: &[i32] = &[0, 1, 2, 3, 4, 5];
    let c = v.windows(2);
    assert_eq!(c.last().unwrap()[1], 5);

    let v2: &[i32] = &[0, 1, 2, 3, 4];
    let c2 = v2.windows(2);
    assert_eq!(c2.last().unwrap()[0], 3);
}

#[test]
fn test_windows_zip() {
    let v1: &[i32] = &[0, 1, 2, 3, 4];
    let v2: &[i32] = &[6, 7, 8, 9, 10];

    let res = v1
        .windows(2)
        .zip(v2.windows(2))
        .map(|(a, b)| a.iter().sum::<i32>() + b.iter().sum::<i32>())
        .collect::<Vec<_>>();

    assert_eq!(res, [14, 18, 22, 26]);
}

#[test]
#[allow(const_err)]
fn test_iter_ref_consistency() {
    use std::fmt::Debug;

    fn test<T: Copy + Debug + PartialEq>(x: T) {
        let v: &[T] = &[x, x, x];
        let v_ptrs: [*const T; 3] = match v {
            [ref v1, ref v2, ref v3] => [v1 as *const _, v2 as *const _, v3 as *const _],
            _ => unreachable!(),
        };
        let len = v.len();

        // nth(i)
        for i in 0..len {
            assert_eq!(&v[i] as *const _, v_ptrs[i]); // thoir sùil air an raon v_ptrs, dìreach airson a bhith cinnteach
            let nth = v.iter().nth(i).unwrap();
            assert_eq!(nth as *const _, v_ptrs[i]);
        }
        assert_eq!(v.iter().nth(len), None, "nth(len) should return None");

        // tro àtha le nth(0)
        {
            let mut it = v.iter();
            for i in 0..len {
                let next = it.nth(0).unwrap();
                assert_eq!(next as *const _, v_ptrs[i]);
            }
            assert_eq!(it.nth(0), None);
        }

        // next()
        {
            let mut it = v.iter();
            for i in 0..len {
                let remaining = len - i;
                assert_eq!(it.size_hint(), (remaining, Some(remaining)));

                let next = it.next().unwrap();
                assert_eq!(next as *const _, v_ptrs[i]);
            }
            assert_eq!(it.size_hint(), (0, Some(0)));
            assert_eq!(it.next(), None, "The final call to next() should return None");
        }

        // next_back()
        {
            let mut it = v.iter();
            for i in 0..len {
                let remaining = len - i;
                assert_eq!(it.size_hint(), (remaining, Some(remaining)));

                let prev = it.next_back().unwrap();
                assert_eq!(prev as *const _, v_ptrs[remaining - 1]);
            }
            assert_eq!(it.size_hint(), (0, Some(0)));
            assert_eq!(it.next_back(), None, "The final call to next_back() should return None");
        }
    }

    fn test_mut<T: Copy + Debug + PartialEq>(x: T) {
        let v: &mut [T] = &mut [x, x, x];
        let v_ptrs: [*mut T; 3] = match v {
            [ref v1, ref v2, ref v3] => {
                [v1 as *const _ as *mut _, v2 as *const _ as *mut _, v3 as *const _ as *mut _]
            }
            _ => unreachable!(),
        };
        let len = v.len();

        // nth(i)
        for i in 0..len {
            assert_eq!(&mut v[i] as *mut _, v_ptrs[i]); // thoir sùil air an raon v_ptrs, dìreach airson a bhith cinnteach
            let nth = v.iter_mut().nth(i).unwrap();
            assert_eq!(nth as *mut _, v_ptrs[i]);
        }
        assert_eq!(v.iter().nth(len), None, "nth(len) should return None");

        // tro àtha le nth(0)
        {
            let mut it = v.iter();
            for i in 0..len {
                let next = it.nth(0).unwrap();
                assert_eq!(next as *const _, v_ptrs[i]);
            }
            assert_eq!(it.nth(0), None);
        }

        // next()
        {
            let mut it = v.iter_mut();
            for i in 0..len {
                let remaining = len - i;
                assert_eq!(it.size_hint(), (remaining, Some(remaining)));

                let next = it.next().unwrap();
                assert_eq!(next as *mut _, v_ptrs[i]);
            }
            assert_eq!(it.size_hint(), (0, Some(0)));
            assert_eq!(it.next(), None, "The final call to next() should return None");
        }

        // next_back()
        {
            let mut it = v.iter_mut();
            for i in 0..len {
                let remaining = len - i;
                assert_eq!(it.size_hint(), (remaining, Some(remaining)));

                let prev = it.next_back().unwrap();
                assert_eq!(prev as *mut _, v_ptrs[remaining - 1]);
            }
            assert_eq!(it.size_hint(), (0, Some(0)));
            assert_eq!(it.next_back(), None, "The final call to next_back() should return None");
        }
    }

    // Dèan cinnteach gu bheil itealain agus pàtrain sliseag a `toirt seachad seòlaidhean cunbhalach airson diofar sheòrsaichean, nam measg ZSTn.
    //
    test(0u32);
    test(());
    test([0u32; 0]); // ZST le co-thaobhadh> 0
    test_mut(0u32);
    test_mut(());
    test_mut([0u32; 0]); // ZST le co-thaobhadh> 0
}

// Chan eil buileachadh gnàthach SliceIndex a `làimhseachadh dhòighean gu h-orthogonally bho sheòrsaichean raon;mar sin, is fhiach deuchainn a dhèanamh air na h-obraichean clàr-amais air gach cur-a-steach.
//
//
mod slice_index {
    // Sgrùdaidhean seo a h-uile sia 'comharrachadh dhòighean-obrach, a thoirt a-steach an raon a bu chòir a soirbheachadh.
    // (CHAN EIL freagarrach airson cuir a-steach neo-dhligheach a dhearbhadh)
    macro_rules! assert_range_eq {
        ($arr:expr, $range:expr, $expected:expr) => {
            let mut arr = $arr;
            let mut expected = $expected;
            {
                let s: &[_] = &arr;
                let expected: &[_] = &expected;

                assert_eq!(&s[$range], expected, "(in assertion for: index)");
                assert_eq!(s.get($range), Some(expected), "(in assertion for: get)");
                unsafe {
                    assert_eq!(
                        s.get_unchecked($range),
                        expected,
                        "(in assertion for: get_unchecked)",
                    );
                }
            }
            {
                let s: &mut [_] = &mut arr;
                let expected: &mut [_] = &mut expected;

                assert_eq!(&mut s[$range], expected, "(in assertion for: index_mut)",);
                assert_eq!(
                    s.get_mut($range),
                    Some(&mut expected[..]),
                    "(in assertion for: get_mut)",
                );
                unsafe {
                    assert_eq!(
                        s.get_unchecked_mut($range),
                        expected,
                        "(in assertion for: get_unchecked_mut)",
                    );
                }
            }
        };
    }

    // Dèan cinnteach gum faigh am macro lorg air biastagan, oir mura h-urrainn dha, dè a tha sinn eadhon a `dèanamh an seo?
    //
    // (Bi mothachail nach eil seo ach a `sealltainn comas lorg bhiteagan anns an dòigh FIRST a tha panics, leis nach eil am macro air a dhealbhadh airson a chleachdadh ann an `should_panic`)
    //
    //
    //
    #[test]
    #[should_panic(expected = "out of range")]
    fn assert_range_eq_can_fail_by_panic() {
        assert_range_eq!([0, 1, 2], 0..5, [0, 1, 2]);
    }

    // (Bi mothachail nach eil seo a `sealltainn ach an comas lorg fhaighinn air biastagan anns an dòigh FIRST a chanas e, oir chan eil am macro air a dhealbhadh airson a chleachdadh ann an `should_panic`)
    //
    //
    #[test]
    #[should_panic(expected = "==")]
    fn assert_range_eq_can_fail_by_inequality() {
        assert_range_eq!([0, 1, 2], 0..2, [0, 1, 2]);
    }

    // Cùisean deuchainn airson droch obair clàr-amais.
    //
    // Bidh seo a `gineadh cùisean deuchainn `should_panic` airson cùisean deuchainn Index/IndexMut agus `None` airson get/get_mut.
    //
    macro_rules! panic_cases {
        ($(
            // feumaidh ainm sònraichte a bhith aig gach cùis deuchainn gus àite a thoirt dha na deuchainnean
            in mod $case_name:ident {
                data: $data:expr;

                // optional:
                //
                // aon no barrachd a-steach coltach ris a bheil dàta [cuir a-steach] a `soirbheachadh, agus an toradh co-fhreagarrach mar raon.
                // Bidh seo a `cuideachadh le bhith a` dearbhadh "critical points" far a bheil raon inntrigidh a `dol thairis air a` chrìoch eadar dligheach agus neo-dhligheach.
                //
                // (leithid an toirt a-steach `len..len`, a tha dìreach gann dligheach)
                //
                $(
                    good: data[$good:expr] == $output:expr;
                )*

                bad: data[$bad:expr];
                message: $expect_msg:expr;
            }
        )*) => {$(
            mod $case_name {
                #[test]
                fn pass() {
                    let mut v = $data;

                    $( assert_range_eq!($data, $good, $output); )*

                    {
                        let v: &[_] = &v;
                        assert_eq!(v.get($bad), None, "(in None assertion for get)");
                    }

                    {
                        let v: &mut [_] = &mut v;
                        assert_eq!(v.get_mut($bad), None, "(in None assertion for get_mut)");
                    }
                }

                #[test]
                #[should_panic(expected = $expect_msg)]
                fn index_fail() {
                    let v = $data;
                    let v: &[_] = &v;
                    let _v = &v[$bad];
                }

                #[test]
                #[should_panic(expected = $expect_msg)]
                fn index_mut_fail() {
                    let mut v = $data;
                    let v: &mut [_] = &mut v;
                    let _v = &mut v[$bad];
                }
            }
        )*};
    }

    #[test]
    fn simple() {
        let v = [0, 1, 2, 3, 4, 5];

        assert_range_eq!(v, .., [0, 1, 2, 3, 4, 5]);
        assert_range_eq!(v, ..2, [0, 1]);
        assert_range_eq!(v, ..=1, [0, 1]);
        assert_range_eq!(v, 2.., [2, 3, 4, 5]);
        assert_range_eq!(v, 1..4, [1, 2, 3]);
        assert_range_eq!(v, 1..=3, [1, 2, 3]);
    }

    panic_cases! {
        in mod rangefrom_len {
            data: [0, 1, 2, 3, 4, 5];

            good: data[6..] == [];
            bad: data[7..];
            message: "out of range";
        }

        in mod rangeto_len {
            data: [0, 1, 2, 3, 4, 5];

            good: data[..6] == [0, 1, 2, 3, 4, 5];
            bad: data[..7];
            message: "out of range";
        }

        in mod rangetoinclusive_len {
            data: [0, 1, 2, 3, 4, 5];

            good: data[..=5] == [0, 1, 2, 3, 4, 5];
            bad: data[..=6];
            message: "out of range";
        }

        in mod rangeinclusive_len {
            data: [0, 1, 2, 3, 4, 5];

            good: data[0..=5] == [0, 1, 2, 3, 4, 5];
            bad: data[0..=6];
            message: "out of range";
        }

        in mod range_len_len {
            data: [0, 1, 2, 3, 4, 5];

            good: data[6..6] == [];
            bad: data[7..7];
            message: "out of range";
        }

        in mod rangeinclusive_len_len {
            data: [0, 1, 2, 3, 4, 5];

            good: data[6..=5] == [];
            bad: data[7..=6];
            message: "out of range";
        }
    }

    panic_cases! {
        in mod rangeinclusive_exhausted {
            data: [0, 1, 2, 3, 4, 5];

            good: data[0..=5] == [0, 1, 2, 3, 4, 5];
            good: data[{
                let mut iter = 0..=5;
                iter.by_ref().count(); // cuir às dha
                iter
            }] == [];

            // 0..=6 tha e a-mach à raon mus do shàraich e, agus mar sin tha e na adhbhar gum biodh e fhathast às deidh.
            //
            bad: data[{
                let mut iter = 0..=6;
                iter.by_ref().count(); // cuir às dha
                iter
            }];
            message: "out of range";
        }
    }

    panic_cases! {
        in mod range_neg_width {
            data: [0, 1, 2, 3, 4, 5];

            good: data[4..4] == [];
            bad: data[4..3];
            message: "but ends at";
        }

        in mod rangeinclusive_neg_width {
            data: [0, 1, 2, 3, 4, 5];

            good: data[4..=3] == [];
            bad: data[4..=2];
            message: "but ends at";
        }
    }

    panic_cases! {
        in mod rangeinclusive_overflow {
            data: [0, 1];

            // note: le bhith a `cleachdadh 0 gu sònraichte a` dèanamh cinnteach gu bheil toradh de thar-shruth aig 0..0,
            //       gus nach till `get` dìreach Chan eil gin airson an adhbhar ceàrr.
            bad: data[0 ..= usize::MAX];
            message: "maximum usize";
        }

        in mod rangetoinclusive_overflow {
            data: [0, 1];

            bad: data[..= usize::MAX];
            message: "maximum usize";
        }
    } // panic_cases!
}

#[test]
fn test_find_rfind() {
    let v = [0, 1, 2, 3, 4, 5];
    let mut iter = v.iter();
    let mut i = v.len();
    while let Some(&elt) = iter.rfind(|_| true) {
        i -= 1;
        assert_eq!(elt, v[i]);
    }
    assert_eq!(i, 0);
    assert_eq!(v.iter().rfind(|&&x| x <= 3), Some(&3));
}

#[test]
fn test_iter_folds() {
    let a = [1, 2, 3, 4, 5]; // len> 4 mar sin tha an unroll air a chleachdadh
    assert_eq!(a.iter().fold(0, |acc, &x| 2 * acc + x), 57);
    assert_eq!(a.iter().rfold(0, |acc, &x| 2 * acc + x), 129);
    let fold = |acc: i32, &x| acc.checked_mul(2)?.checked_add(x);
    assert_eq!(a.iter().try_fold(0, &fold), Some(57));
    assert_eq!(a.iter().try_rfold(0, &fold), Some(129));

    // geàrr-circuiting try_fold, tro dhòighean eile
    let a = [0, 1, 2, 3, 5, 5, 5, 7, 8, 9];
    let mut iter = a.iter();
    assert_eq!(iter.position(|&x| x == 3), Some(3));
    assert_eq!(iter.rfind(|&&x| x == 5), Some(&5));
    assert_eq!(iter.len(), 2);
}

#[test]
fn test_rotate_left() {
    const N: usize = 600;
    let a: &mut [_] = &mut [0; N];
    for i in 0..N {
        a[i] = i;
    }

    a.rotate_left(42);
    let k = N - 42;

    for i in 0..N {
        assert_eq!(a[(i + k) % N], i);
    }
}

#[test]
fn test_rotate_right() {
    const N: usize = 600;
    let a: &mut [_] = &mut [0; N];
    for i in 0..N {
        a[i] = i;
    }

    a.rotate_right(42);

    for i in 0..N {
        assert_eq!(a[(i + 42) % N], i);
    }
}

#[test]
#[cfg_attr(miri, ignore)] // Tha Miri ro shlaodach
fn brute_force_rotate_test_0() {
    // Ann an cùis cùisean edge a `toirt a-steach grunn algorithm
    let n = 300;
    for len in 0..n {
        for s in 0..len {
            let mut v = Vec::with_capacity(len);
            for i in 0..len {
                v.push(i);
            }
            v[..].rotate_right(s);
            for i in 0..v.len() {
                assert_eq!(v[i], v.len().wrapping_add(i.wrapping_sub(s)) % v.len());
            }
        }
    }
}

#[test]
fn brute_force_rotate_test_1() {
    // `ptr_rotate` a `còmhdach uimhir de sheòrsan de chleachdadh puing, gur e dìreach deagh dheuchainn a tha seo airson molaidhean san fharsaingeachd.
    // Tha seo a 'cleachdadh `[usize; 4]` a bhualadh a h-uile aontaran gun chlòthadh Miri
    let n = 30;
    for len in 0..n {
        for s in 0..len {
            let mut v: Vec<[usize; 4]> = Vec::with_capacity(len);
            for i in 0..len {
                v.push([i, 0, 0, 0]);
            }
            v[..].rotate_right(s);
            for i in 0..v.len() {
                assert_eq!(v[i][0], v.len().wrapping_add(i.wrapping_sub(s)) % v.len());
            }
        }
    }
}

#[test]
#[cfg(not(target_arch = "wasm32"))]
fn sort_unstable() {
    use core::cmp::Ordering::{Equal, Greater, Less};
    use core::slice::heapsort;
    use rand::{rngs::StdRng, seq::SliceRandom, Rng, SeedableRng};

    // Tha Miri ro shlaodach (ach feumaidh i fhathast `chain` gus na seòrsaichean a mhaidseadh)
    let lens = if cfg!(miri) { (2..20).chain(0..0) } else { (2..25).chain(500..510) };
    let rounds = if cfg!(miri) { 1 } else { 100 };

    let mut v = [0; 600];
    let mut tmp = [0; 600];
    let mut rng = StdRng::from_entropy();

    for len in lens {
        let v = &mut v[0..len];
        let tmp = &mut tmp[0..len];

        for &modulus in &[5, 10, 100, 1000] {
            for _ in 0..rounds {
                for i in 0..len {
                    v[i] = rng.gen::<i32>() % modulus;
                }

                // Deasaich ann an òrdugh bunaiteach.
                tmp.copy_from_slice(v);
                tmp.sort_unstable();
                assert!(tmp.windows(2).all(|w| w[0] <= w[1]));

                // Deasaich ann an òrdugh dìreadh.
                tmp.copy_from_slice(v);
                tmp.sort_unstable_by(|a, b| a.cmp(b));
                assert!(tmp.windows(2).all(|w| w[0] <= w[1]));

                // Deasaich ann an òrdugh teàrnaidh.
                tmp.copy_from_slice(v);
                tmp.sort_unstable_by(|a, b| b.cmp(a));
                assert!(tmp.windows(2).all(|w| w[0] >= w[1]));

                // Dèan deuchainn air heapsort a `cleachdadh gnìomhaiche `<`.
                tmp.copy_from_slice(v);
                heapsort(tmp, |a, b| a < b);
                assert!(tmp.windows(2).all(|w| w[0] <= w[1]));

                // Dèan deuchainn air heapsort a `cleachdadh gnìomhaiche `>`.
                tmp.copy_from_slice(v);
                heapsort(tmp, |a, b| a > b);
                assert!(tmp.windows(2).all(|w| w[0] >= w[1]));
            }
        }
    }

    // Deasaich a `cleachdadh gnìomh coimeas gu tur air thuaiream.
    // Bidh seo ag ath-òrdachadh na h-eileamaidean *dòigh air choireigin*, ach cha dèan e panic.
    for i in 0..v.len() {
        v[i] = i as i32;
    }
    v.sort_unstable_by(|_, _| *[Less, Equal, Greater].choose(&mut rng).unwrap());
    v.sort_unstable();
    for i in 0..v.len() {
        assert_eq!(v[i], i as i32);
    }

    // Cha bu chòir panic.
    [0i32; 0].sort_unstable();
    [(); 10].sort_unstable();
    [(); 100].sort_unstable();

    let mut v = [0xDEADBEEFu64];
    v.sort_unstable();
    assert!(v == [0xDEADBEEF]);
}

#[test]
#[cfg(not(target_arch = "wasm32"))]
#[cfg_attr(miri, ignore)] // Tha Miri ro shlaodach
fn select_nth_unstable() {
    use core::cmp::Ordering::{Equal, Greater, Less};
    use rand::rngs::StdRng;
    use rand::seq::SliceRandom;
    use rand::{Rng, SeedableRng};

    let mut rng = StdRng::from_entropy();

    for len in (2..21).chain(500..501) {
        let mut orig = vec![0; len];

        for &modulus in &[5, 10, 1000] {
            for _ in 0..10 {
                for i in 0..len {
                    orig[i] = rng.gen::<i32>() % modulus;
                }

                let v_sorted = {
                    let mut v = orig.clone();
                    v.sort();
                    v
                };

                // Deasaich ann an òrdugh bunaiteach.
                for pivot in 0..len {
                    let mut v = orig.clone();
                    v.select_nth_unstable(pivot);

                    assert_eq!(v_sorted[pivot], v[pivot]);
                    for i in 0..pivot {
                        for j in pivot..len {
                            assert!(v[i] <= v[j]);
                        }
                    }
                }

                // Deasaich ann an òrdugh dìreadh.
                for pivot in 0..len {
                    let mut v = orig.clone();
                    let (left, pivot, right) = v.select_nth_unstable_by(pivot, |a, b| a.cmp(b));

                    assert_eq!(left.len() + right.len(), len - 1);

                    for l in left {
                        assert!(l <= pivot);
                        for r in right.iter_mut() {
                            assert!(l <= r);
                            assert!(pivot <= r);
                        }
                    }
                }

                // Deasaich ann an òrdugh teàrnaidh.
                let sort_descending_comparator = |a: &i32, b: &i32| b.cmp(a);
                let v_sorted_descending = {
                    let mut v = orig.clone();
                    v.sort_by(sort_descending_comparator);
                    v
                };

                for pivot in 0..len {
                    let mut v = orig.clone();
                    v.select_nth_unstable_by(pivot, sort_descending_comparator);

                    assert_eq!(v_sorted_descending[pivot], v[pivot]);
                    for i in 0..pivot {
                        for j in pivot..len {
                            assert!(v[j] <= v[i]);
                        }
                    }
                }
            }
        }
    }

    // Deasaich aig clàr-amais a `cleachdadh gnìomh coimeas gu tur air thuaiream.
    // Bidh seo ag ath-òrdachadh na h-eileamaidean *dòigh air choireigin*, ach cha dèan e panic.
    let mut v = [0; 500];
    for i in 0..v.len() {
        v[i] = i as i32;
    }

    for pivot in 0..v.len() {
        v.select_nth_unstable_by(pivot, |_, _| *[Less, Equal, Greater].choose(&mut rng).unwrap());
        v.sort();
        for i in 0..v.len() {
            assert_eq!(v[i], i as i32);
        }
    }

    // Cha bu chòir panic.
    [(); 10].select_nth_unstable(0);
    [(); 10].select_nth_unstable(5);
    [(); 10].select_nth_unstable(9);
    [(); 100].select_nth_unstable(0);
    [(); 100].select_nth_unstable(50);
    [(); 100].select_nth_unstable(99);

    let mut v = [0xDEADBEEFu64];
    v.select_nth_unstable(0);
    assert!(v == [0xDEADBEEF]);
}

#[test]
#[should_panic(expected = "index 0 greater than length of slice")]
fn select_nth_unstable_zero_length() {
    [0i32; 0].select_nth_unstable(0);
}

#[test]
#[should_panic(expected = "index 20 greater than length of slice")]
fn select_nth_unstable_past_length() {
    [0i32; 10].select_nth_unstable(20);
}

pub mod memchr {
    use core::slice::memchr::{memchr, memrchr};

    // deuchainn fallback implementations-àrd-chabhsairean air a h-uile
    #[test]
    fn matches_one() {
        assert_eq!(Some(0), memchr(b'a', b"a"));
    }

    #[test]
    fn matches_begin() {
        assert_eq!(Some(0), memchr(b'a', b"aaaa"));
    }

    #[test]
    fn matches_end() {
        assert_eq!(Some(4), memchr(b'z', b"aaaaz"));
    }

    #[test]
    fn matches_nul() {
        assert_eq!(Some(4), memchr(b'\x00', b"aaaa\x00"));
    }

    #[test]
    fn matches_past_nul() {
        assert_eq!(Some(5), memchr(b'z', b"aaaa\x00z"));
    }

    #[test]
    fn no_match_empty() {
        assert_eq!(None, memchr(b'a', b""));
    }

    #[test]
    fn no_match() {
        assert_eq!(None, memchr(b'a', b"xyz"));
    }

    #[test]
    fn matches_one_reversed() {
        assert_eq!(Some(0), memrchr(b'a', b"a"));
    }

    #[test]
    fn matches_begin_reversed() {
        assert_eq!(Some(3), memrchr(b'a', b"aaaa"));
    }

    #[test]
    fn matches_end_reversed() {
        assert_eq!(Some(0), memrchr(b'z', b"zaaaa"));
    }

    #[test]
    fn matches_nul_reversed() {
        assert_eq!(Some(4), memrchr(b'\x00', b"aaaa\x00"));
    }

    #[test]
    fn matches_past_nul_reversed() {
        assert_eq!(Some(0), memrchr(b'z', b"z\x00aaaa"));
    }

    #[test]
    fn no_match_empty_reversed() {
        assert_eq!(None, memrchr(b'a', b""));
    }

    #[test]
    fn no_match_reversed() {
        assert_eq!(None, memrchr(b'a', b"xyz"));
    }

    #[test]
    fn each_alignment_reversed() {
        let mut data = [1u8; 64];
        let needle = 2;
        let pos = 40;
        data[pos] = needle;
        for start in 0..16 {
            assert_eq!(Some(pos - start), memrchr(needle, &data[start..]));
        }
    }
}

#[test]
fn test_align_to_simple() {
    let bytes = [1u8, 2, 3, 4, 5, 6, 7];
    let (prefix, aligned, suffix) = unsafe { bytes.align_to::<u16>() };
    assert_eq!(aligned.len(), 3);
    assert!(prefix == [1] || suffix == [7]);
    let expect1 = [1 << 8 | 2, 3 << 8 | 4, 5 << 8 | 6];
    let expect2 = [1 | 2 << 8, 3 | 4 << 8, 5 | 6 << 8];
    let expect3 = [2 << 8 | 3, 4 << 8 | 5, 6 << 8 | 7];
    let expect4 = [2 | 3 << 8, 4 | 5 << 8, 6 | 7 << 8];
    assert!(
        aligned == expect1 || aligned == expect2 || aligned == expect3 || aligned == expect4,
        "aligned={:?} expected={:?} || {:?} || {:?} || {:?}",
        aligned,
        expect1,
        expect2,
        expect3,
        expect4
    );
}

#[test]
fn test_align_to_zst() {
    let bytes = [1, 2, 3, 4, 5, 6, 7];
    let (prefix, aligned, suffix) = unsafe { bytes.align_to::<()>() };
    assert_eq!(aligned.len(), 0);
    assert!(prefix == [1, 2, 3, 4, 5, 6, 7] || suffix == [1, 2, 3, 4, 5, 6, 7]);
}

#[test]
fn test_align_to_non_trivial() {
    #[repr(align(8))]
    struct U64(u64, u64);
    #[repr(align(8))]
    struct U64U64U32(u64, u64, u32);
    let data = [
        U64(1, 2),
        U64(3, 4),
        U64(5, 6),
        U64(7, 8),
        U64(9, 10),
        U64(11, 12),
        U64(13, 14),
        U64(15, 16),
    ];
    let (prefix, aligned, suffix) = unsafe { data.align_to::<U64U64U32>() };
    assert_eq!(aligned.len(), 4);
    assert_eq!(prefix.len() + suffix.len(), 2);
}

#[test]
fn test_align_to_empty_mid() {
    use core::mem;

    // Dèan cinnteach nach bi sinn a `cruthachadh sliseagan falamh gun chomharradh airson a` phàirt mheadhain, eadhon nuair a tha an sliseag iomlan ro ghoirid airson seòladh co-thaobhach a bhith ann.
    //
    let bytes = [1, 2, 3, 4, 5, 6, 7];
    type Chunk = u32;
    for offset in 0..4 {
        let (_, mid, _) = unsafe { bytes[offset..offset + 1].align_to::<Chunk>() };
        assert_eq!(mid.as_ptr() as usize % mem::align_of::<Chunk>(), 0);
    }
}

#[test]
fn test_align_to_mut_aliasing() {
    let mut val = [1u8, 2, 3, 4, 5];
    // `align_to_mut` `mid` chleachdadh gus a chruthachadh ann an dòigh a bha cuid de eadar-mheadhanach ceàrr aliasing, invalidating an thoradh `mid` sliseag.
    //
    let (begin, mid, end) = unsafe { val.align_to_mut::<[u8; 2]>() };
    assert!(begin.len() == 0);
    assert!(end.len() == 1);
    mid[0] = mid[1];
    assert_eq!(val, [3, 4, 3, 4, 5])
}

#[test]
fn test_slice_partition_dedup_by() {
    let mut slice: [i32; 9] = [1, -1, 2, 3, 1, -5, 5, -2, 2];

    let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.abs() == b.abs());

    assert_eq!(dedup, [1, 2, 3, 1, -5, -2]);
    assert_eq!(duplicates, [5, -1, 2]);
}

#[test]
fn test_slice_partition_dedup_empty() {
    let mut slice: [i32; 0] = [];

    let (dedup, duplicates) = slice.partition_dedup();

    assert_eq!(dedup, []);
    assert_eq!(duplicates, []);
}

#[test]
fn test_slice_partition_dedup_one() {
    let mut slice = [12];

    let (dedup, duplicates) = slice.partition_dedup();

    assert_eq!(dedup, [12]);
    assert_eq!(duplicates, []);
}

#[test]
fn test_slice_partition_dedup_multiple_ident() {
    let mut slice = [12, 12, 12, 12, 12, 11, 11, 11, 11, 11, 11];

    let (dedup, duplicates) = slice.partition_dedup();

    assert_eq!(dedup, [12, 11]);
    assert_eq!(duplicates, [12, 12, 12, 12, 11, 11, 11, 11, 11]);
}

#[test]
fn test_slice_partition_dedup_partialeq() {
    #[derive(Debug)]
    struct Foo(i32, i32);

    impl PartialEq for Foo {
        fn eq(&self, other: &Foo) -> bool {
            self.0 == other.0
        }
    }

    let mut slice = [Foo(0, 1), Foo(0, 5), Foo(1, 7), Foo(1, 9)];

    let (dedup, duplicates) = slice.partition_dedup();

    assert_eq!(dedup, [Foo(0, 1), Foo(1, 7)]);
    assert_eq!(duplicates, [Foo(0, 5), Foo(1, 9)]);
}

#[test]
fn test_copy_within() {
    // Tòisich a `crìochnachadh, le RangeTo.
    let mut bytes = *b"Hello, World!";
    bytes.copy_within(..3, 10);
    assert_eq!(&bytes, b"Hello, WorHel");

    // Crìoch airson tòiseachadh, le RangeFrom.
    let mut bytes = *b"Hello, World!";
    bytes.copy_within(10.., 0);
    assert_eq!(&bytes, b"ld!lo, World!");

    // A `dol thairis air, le RangeInclusive.
    let mut bytes = *b"Hello, World!";
    bytes.copy_within(0..=11, 1);
    assert_eq!(&bytes, b"HHello, World");

    // Slice slàn, le RangeFull.
    let mut bytes = *b"Hello, World!";
    bytes.copy_within(.., 0);
    assert_eq!(&bytes, b"Hello, World!");

    // Dèanamh cinnteach gu bheil lethbhreac aig deireadh sliseag cha adhbhar UB.
    let mut bytes = *b"Hello, World!";
    bytes.copy_within(13..13, 5);
    assert_eq!(&bytes, b"Hello, World!");
    bytes.copy_within(5..5, 13);
    assert_eq!(&bytes, b"Hello, World!");
}

#[test]
#[should_panic(expected = "range end index 14 out of range for slice of length 13")]
fn test_copy_within_panics_src_too_long() {
    let mut bytes = *b"Hello, World!";
    // Tha fad eil ach 13, 14 agus mar sin tha e a-mach à crìochan.
    bytes.copy_within(10..14, 0);
}

#[test]
#[should_panic(expected = "dest is out of bounds")]
fn test_copy_within_panics_dest_too_long() {
    let mut bytes = *b"Hello, World!";
    // Tha fad eil ach 13, agus mar sin sliseag dh'fhaid 4 Clàr-ìnnse 'tòiseachadh aig 10 a-mach à crìochan.
    bytes.copy_within(0..4, 10);
}

#[test]
#[should_panic(expected = "slice index starts at 2 but ends at 1")]
fn test_copy_within_panics_src_inverted() {
    let mut bytes = *b"Hello, World!";
    // 2 a tha nas motha na 1, mar sin tha an raon a tha mì-dhligheach.
    bytes.copy_within(2..1, 0);
}
#[test]
#[should_panic(expected = "attempted to index slice up to maximum usize")]
fn test_copy_within_panics_src_out_of_bounds() {
    let mut bytes = *b"Hello, World!";
    // dhèanadh raon in-ghabhalach a `crìochnachadh aig usize::MAX thar-shruth src_end
    bytes.copy_within(usize::MAX..=usize::MAX, 0);
}

#[test]
fn test_is_sorted() {
    let empty: [i32; 0] = [];

    assert!([1, 2, 2, 9].is_sorted());
    assert!(![1, 3, 2].is_sorted());
    assert!([0].is_sorted());
    assert!(empty.is_sorted());
    assert!(![0.0, 1.0, f32::NAN].is_sorted());
    assert!([-2, -1, 0, 3].is_sorted());
    assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    assert!(!["c", "bb", "aaa"].is_sorted());
    assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
}

#[test]
fn test_slice_run_destructors() {
    // Dèan cinnteach gu bheil luchd-sgrios a `ruith air litreachasan sliseag
    struct Foo<'a> {
        x: &'a Cell<isize>,
    }

    impl<'a> Drop for Foo<'a> {
        fn drop(&mut self) {
            self.x.set(self.x.get() + 1);
        }
    }

    fn foo(x: &Cell<isize>) -> Foo<'_> {
        Foo { x }
    }

    let x = &Cell::new(0);

    {
        let l = &[foo(x)];
        assert_eq!(l[0].x.get(), 0);
    }

    assert_eq!(x.get(), 1);
}