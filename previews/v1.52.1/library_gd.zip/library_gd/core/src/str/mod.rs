//! Làimhseachadh sreang.
//!
//! Airson tuilleadh fiosrachaidh, faic am modal [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. a-mach à crìochan
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. tòiseachadh <=deireadh
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. crìoch caractar
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // lorg an caractar
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` feumaidh e a bhith nas lugha na len agus crìoch char
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// A `tilleadh an fhaid `self`.
    ///
    /// Tha an fhaid seo ann am bytes, chan e [`char`] s no graphemes.
    /// Ann am faclan eile, is dòcha nach e rud a tha duine a `meas fad na sreang.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fancy f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// A `tilleadh `true` ma tha fad de neoni bytes aig `self`.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// A `dèanamh cinnteach gur e` index`-th byte a`chiad byte ann an sreath puing còd UTF-8 no deireadh an t-sreang.
    ///
    ///
    /// Tha an toiseach agus deireadh an t-sreang (nuair `Clàr-ìnnse== self.len()`) den bheachd gu bheil crìochan.
    ///
    /// A `tilleadh `false` ma tha `index` nas motha na `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // toiseach `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // an dàrna byte de `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // an treas byte de `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // Tha 0 agus len an-còmhnaidh ceart gu leòr.
        // Dèan deuchainn airson 0 gu follaiseach gus an urrainn dha an sgrùdadh a dhèanamh a-mach gu furasta agus sgiobadh leughadh dàta sreang airson a `chùis sin.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Tha seo beagan draoidheachd co-ionann ri: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Converts sreang sliseag gu Byte sliseag.
    /// Gus an sliseag byte a thionndadh air ais gu sliseag sreang, cleachd an gnìomh [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SÀBHAILTEACHD: fuaim seasmhach oir bidh sinn a `gluasad dà sheòrsa leis an aon chruth
        unsafe { mem::transmute(self) }
    }

    /// Bidh e ag atharrachadh sliseag sreang gluasadach gu sliseag byte mutable.
    ///
    /// # Safety
    ///
    /// Feumaidh an neach-conaltraidh dèanamh cinnteach gu bheil susbaint na sliseag dligheach UTF-8 mus tig an iasad gu crìch agus an `str` bunaiteach air a chleachdadh.
    ///
    ///
    /// Tha cleachdadh `str` nach eil na susbaint dligheach UTF-8 na ghiùlan neo-mhìnichte.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SÀBHAILTEACHD: tha an tilgeadh bho `&str` gu `&[u8]` sàbhailte bho `str`
        // tha an aon dreach ri `&[u8]` (chan urrainn ach libstd an gealladh seo a dhèanamh).
        // Tha dì-cheadachadh a `phuing sàbhailte bhon a thig e bho iomradh gluasadach a tha cinnteach gum bi e dligheach airson sgrìobhaidhean.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Bidh e ag atharrachadh sliseag sreang gu stiùireadh amh.
    ///
    /// Seach gur e sliseag bytes a th `ann an sliseagan sreang, tha am puing amh a` comharrachadh [`u8`].
    /// Bidh am putan seo a `comharrachadh a` chiad byte den t-sreang sreang.
    ///
    /// Feumaidh an neach-conaltraidh dèanamh cinnteach nach tèid sgrìobhadh chun a `phuing a chaidh a thilleadh a-riamh.
    /// Ma dh `fheumas tu susbaint na sliseag sreang a thionndadh, cleachd [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Bidh e ag atharrachadh sliseag sreang gluasadach gu puing amh.
    ///
    /// Seach gur e sliseag bytes a th `ann an sliseagan sreang, tha am puing amh a` comharrachadh [`u8`].
    /// Bidh am putan seo a `comharrachadh a` chiad byte den t-sreang sreang.
    ///
    /// Tha e an urra riut dèanamh cinnteach nach tèid an t-sreang sreang atharrachadh ach ann an dòigh a tha e dligheach UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// A `tilleadh fo-sgrìobhadh de `str`.
    ///
    /// Is e seo an roghainn neo-phasgach an àite an `str` a chlàr-amais.
    /// A `tilleadh [`None`] nuair a dh` obraicheadh obrachadh clàr-amais co-ionann panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // clàran-amais nach eil air crìochan sreath UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // a-mach à crìochan
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// A 'tilleadh a mutable subslice de `str`.
    ///
    /// Is e seo an roghainn neo-phasgach an àite an `str` a chlàr-amais.
    /// A `tilleadh [`None`] nuair a dh` obraicheadh obrachadh clàr-amais co-ionann panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // an fhad cheart
    /// assert!(v.get_mut(0..5).is_some());
    /// // a-mach à crìochan
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// A 'tilleadh an unchecked subslice de `str`.
    ///
    /// Is e seo an roghainn neo-sgrùdaichte an àite an `str` a chlàr-amais.
    ///
    /// # Safety
    ///
    /// Tha e an urra ri luchd-fios na dreuchd seo gu bheil na ro-òrdughan sin riaraichte:
    ///
    /// * Chan fhaod an clàr-amais tòiseachaidh a bhith nas àirde na an clàr-amais crìochnachaidh;
    /// * Feumaidh clàran-amais a bhith taobh a-staigh crìochan na sliseag tùsail;
    /// * Feumaidh clàran-amais laighe air crìochan sreath UTF-8.
    ///
    /// Mura dèan thu sin, dh `fhaodadh gum bi an sliseag sreang a chaidh a thilleadh a` toirt iomradh air cuimhne neo-dhligheach no a `dol an aghaidh nan invariants a tha an seòrsa `str` a` conaltradh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `get_unchecked` a chumail suas;
        // tha an sliseag dereferencable oir tha `self` na iomradh sàbhailte.
        // Tha am puing a chaidh a thilleadh sàbhailte oir feumaidh impilean `SliceIndex` gealltainn gu bheil e.
        unsafe { &*i.get_unchecked(self) }
    }

    /// A `tilleadh fo-sgrìobhadh gluasadach, neo-sgrùdaichte de `str`.
    ///
    /// Is e seo an roghainn neo-sgrùdaichte an àite an `str` a chlàr-amais.
    ///
    /// # Safety
    ///
    /// Tha e an urra ri luchd-fios na dreuchd seo gu bheil na ro-òrdughan sin riaraichte:
    ///
    /// * Chan fhaod an clàr-amais tòiseachaidh a bhith nas àirde na an clàr-amais crìochnachaidh;
    /// * Feumaidh clàran-amais a bhith taobh a-staigh crìochan na sliseag tùsail;
    /// * Feumaidh clàran-amais laighe air crìochan sreath UTF-8.
    ///
    /// Mura dèan thu sin, dh `fhaodadh gum bi an sliseag sreang a chaidh a thilleadh a` toirt iomradh air cuimhne neo-dhligheach no a `dol an aghaidh nan invariants a tha an seòrsa `str` a` conaltradh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `get_unchecked_mut` a chumail suas;
        // tha an sliseag dereferencable oir tha `self` na iomradh sàbhailte.
        // Tha am puing a chaidh a thilleadh sàbhailte oir feumaidh impilean `SliceIndex` gealltainn gu bheil e.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// A `cruthachadh sliseag sreang bho sliseag sreang eile, a` dol seachad air sgrùdaidhean sàbhailteachd.
    ///
    /// Mar as trice cha bhith seo air a mholadh, cleachd le rabhadh!Airson roghainn sàbhailte eile faic [`str`] agus [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Bidh an sliseag ùr seo a `dol bho `begin` gu `end`, a` toirt a-steach `begin` ach às aonais `end`.
    ///
    /// Gus sliseag sreang gluasadach fhaighinn na àite, faic am modh [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Tha e an urra ri luchd-fios na dreuchd seo gu bheil trì ro-òrdughan riaraichte:
    ///
    /// * `begin` chan fhaod e a bhith nas àirde na `end`.
    /// * `begin` agus feumaidh `end` a bhith nan suidheachadh byte taobh a-staigh an t-sreang sreang.
    /// * `begin` agus feumaidh `end` a bhith na laighe air crìochan sreath UTF-8.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `get_unchecked` a chumail suas;
        // tha an sliseag dereferencable oir tha `self` na iomradh sàbhailte.
        // Tha am puing a chaidh a thilleadh sàbhailte oir feumaidh impilean `SliceIndex` gealltainn gu bheil e.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// A `cruthachadh sliseag sreang bho sliseag sreang eile, a` dol seachad air sgrùdaidhean sàbhailteachd.
    /// Mar as trice cha bhith seo air a mholadh, cleachd le rabhadh!Airson roghainn sàbhailte eile faic [`str`] agus [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Bidh an sliseag ùr seo a `dol bho `begin` gu `end`, a` toirt a-steach `begin` ach às aonais `end`.
    ///
    /// Gus sliseag sreang so-ruigsinneach fhaighinn na àite, faic am modh [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Tha e an urra ri luchd-fios na dreuchd seo gu bheil trì ro-òrdughan riaraichte:
    ///
    /// * `begin` chan fhaod e a bhith nas àirde na `end`.
    /// * `begin` agus feumaidh `end` a bhith nan suidheachadh byte taobh a-staigh an t-sreang sreang.
    /// * `begin` agus feumaidh `end` a bhith na laighe air crìochan sreath UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `get_unchecked_mut` a chumail suas;
        // tha an sliseag dereferencable oir tha `self` na iomradh sàbhailte.
        // Tha am puing a chaidh a thilleadh sàbhailte oir feumaidh impilean `SliceIndex` gealltainn gu bheil e.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Divide aon sreang sliseag a-steach do dhà aig an clàr-amais.
    ///
    /// Bu chòir an argamaid, `mid`, a bhith air a chothromachadh le toiseach tòiseachaidh na sreang.
    /// Feumaidh e cuideachd a bhith air crìoch puing còd UTF-8.
    ///
    /// Bidh an dà shliseag a chaidh a thilleadh a `dol bho thoiseach na sliseag sreang gu `mid`, agus bho `mid` gu deireadh an t-sreang sreang.
    ///
    /// Gus sliseagan sreang gluasadach fhaighinn an àite sin, faic am modh [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics mura h-eil `mid` air crìoch puing còd UTF-8, no ma tha e seachad air deireadh a `phuing còd mu dheireadh den t-sreang.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary a `dèanamh cinnteach gu bheil an clàr-amais ann an [0, .len()]
        if self.is_char_boundary(mid) {
            // SÀBHAILTEACHD: dìreach dèan cinnteach gu bheil `mid` air crìoch char.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Divide aon mutable sreang sliseag a-steach do dhà aig an clàr-amais.
    ///
    /// Bu chòir an argamaid, `mid`, a bhith air a chothromachadh le toiseach tòiseachaidh na sreang.
    /// Feumaidh e cuideachd a bhith air crìoch puing còd UTF-8.
    ///
    /// Bidh an dà shliseag a chaidh a thilleadh a `dol bho thoiseach na sliseag sreang gu `mid`, agus bho `mid` gu deireadh an t-sreang sreang.
    ///
    /// Airson a dhol immutable sreang sliseagan an àite, faic an [`split_at`] dòigh.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics mura h-eil `mid` air crìoch puing còd UTF-8, no ma tha e seachad air deireadh a `phuing còd mu dheireadh den t-sreang.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary a `dèanamh cinnteach gu bheil an clàr-amais ann an [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SÀBHAILTEACHD: dìreach dèan cinnteach gu bheil `mid` air crìoch char.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// A `tilleadh itealaiche thairis air na [` char`] s ann an sliseag sreang.
    ///
    /// Leis gu bheil sliseag sreang a `toirt a-steach UTF-8 dligheach, is urrainn dhuinn itealaich tro sliseag sreang le [`char`].
    /// Bidh an dòigh seo a `tilleadh a leithid de iterator.
    ///
    /// Tha e cudromach cuimhneachadh gu bheil [`char`] a `riochdachadh Luach Sgèile Unicode, agus is dòcha nach eil e a` maidseadh do bheachd air dè a th `ann an 'character'.
    ///
    /// Is dòcha gur e atharrachadh thairis air cruinneachaidhean grapheme na tha thu ag iarraidh.
    /// Chan eil an comas-gnìomh seo air a thoirt seachad le leabharlann àbhaisteach Rust, thoir sùil air crates.io na àite.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Cuimhnich, is dòcha nach bi [`char`] s co-ionnan ris an intuition agad mu charactaran:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // chan e 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// A `tilleadh itealaiche thairis air na [` char`] s ann an sliseag sreang, agus an suidheachadh.
    ///
    /// Leis gu bheil sliseag sreang a `toirt a-steach UTF-8 dligheach, is urrainn dhuinn itealaich tro sliseag sreang le [`char`].
    /// Bidh an dòigh seo a `tilleadh itealaiche den dà [` char`] sin, a bharrachd air na dreuchdan byte aca.
    ///
    /// Bidh an iterator a `toirt a-mach tuples.Tha an suidheachadh an toiseach, tha an [`char`] san dàrna àite.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Cuimhnich, is dòcha nach bi [`char`] s co-ionnan ris an intuition agad mu charactaran:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // Cha (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // toirt fa-near don 3 an seo, ghabh an caractar mu dheireadh suas dà bhit
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Reultair thairis air bytes sliseag sreang.
    ///
    /// Mar sreang sliseag a dhèanamh suas de sreath de bytes, faodaidh sinn iterate tro sreang le sliseag Byte.
    /// Bidh an dòigh seo a `tilleadh a leithid de iterator.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// A `sgoltadh sliseag sreang le àite geal.
    ///
    /// Tillidh an iterator a thilleas sliseagan sreang a tha nam fo-sliseagan den t-sreang sreang tùsail, air an sgaradh le meud geal sam bith.
    ///
    ///
    /// 'Whitespace' air a mhìneachadh a rèir cumhachan an Unicode Derived Core Property `White_Space`.
    /// Mura h-eil thu ach airson sgoltadh air àite-geal ASCII na àite, cleachd [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Thathas a `beachdachadh air a h-uile seòrsa àite geal:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// A `sgoltadh sliseag sreang le àite-geal ASCII.
    ///
    /// Tha iterator thill till sreang sliseagan a tha fo-sliseagan de thùsail sreang sliseag, air an dealachadh le suim sam bith de ASCII whitespace.
    ///
    ///
    /// Airson sgaradh le Unicode `Whitespace` an àite, a 'cleachdadh [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// A h-uile seòrsa de ASCII whitespace Thathar a 'beachdachadh:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Reultair thairis air sreathan sreang, mar sliseagan sreang.
    ///
    /// Tha loidhnichean air an crìochnachadh le loidhne ùr (`\n`) no tilleadh carbad le biadhadh loidhne (`\r\n`).
    ///
    /// Tha an loidhne mu dheireadh a `crìochnachadh roghainneil.
    /// Tillidh sreang a thig gu crìch le loidhne dheireannach a `tilleadh na h-aon loidhnichean ri sreang a tha co-ionann ri chèile gun loidhne dheireannach a` tighinn gu crìch.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Chan eil feum air a `chrìoch dheireannach:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Reultair thairis air sreathan sreang.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// A `tilleadh itealaiche de `u16` thairis air an t-sreang air a chòdachadh mar UTF-16.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// A `tilleadh `true` ma tha am pàtran a chaidh a thoirt seachad a` maidseadh fo-slice den t-sreang sreang seo.
    ///
    /// A `tilleadh `false` mura dèan e sin.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// A `tilleadh `true` ma tha am pàtran a chaidh a thoirt seachad a` maidseadh ro-leasachan den t-sreang sreang seo.
    ///
    /// A `tilleadh `false` mura dèan e sin.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// `true` ma thilleas a 'thoirt pàtran matches a leasachan seo sreang sliseag.
    ///
    /// A `tilleadh `false` mura dèan e sin.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// A `tilleadh clàr-amais byte den chiad charactar den t-sreang sreang seo a tha a` maidseadh a `phàtrain.
    ///
    /// A `tilleadh [`None`] mura h-eil am pàtran a` freagairt.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Pàtranan sìmplidh:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Pàtranan nas iom-fhillte a `cleachdadh stoidhle gun phuing agus dùnadh:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Gun a bhith a `lorg a` phàtrain:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// A `tilleadh clàr-amais byte airson a` chiad charactar den mhaids as ceart den phàtran san t-sreang sreang seo.
    ///
    /// A `tilleadh [`None`] mura h-eil am pàtran a` freagairt.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Pàtranan sìmplidh:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Pàtranan nas iom-fhillte le dùnadh:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Gun a bhith a `lorg a` phàtrain:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Reultair os cionn fo-fhilleadh na sliseag sreang seo, air a sgaradh le caractaran a tha a rèir pàtran.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Giùlan Iterator
    ///
    /// Bidh an iterator a chaidh a thilleadh na [`DoubleEndedIterator`] ma tha am pàtran a `ceadachadh sgrùdadh cùil agus toradh sgrùdadh forward/reverse a` toirt a-mach na h-aon eileamaidean.
    /// Tha seo fìor airson, me, [`char`], ach chan eil airson `&str`.
    ///
    /// Ma tha am pàtran a `ceadachadh sgrùdadh cùil ach dh` fhaodadh na toraidhean aige a bhith eadar-dhealaichte bho sgrùdadh air adhart, faodar an dòigh [`rsplit`] a chleachdadh.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Pàtranan sìmplidh:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Mas e pàtran de chars a th `anns a` phàtran, roinn air gach tachartas de na caractaran:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Pàtran nas iom-fhillte, a `cleachdadh dùnadh:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Ma tha sreangan dealachaidh ioma-thaobhach ann an sreang, gheibh thu sreangan falamh anns an toradh:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Separators dlùth air an dealachadh le falamh sreang.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Tha sreathan aig toiseach no deireadh sreang le sreangan falamh.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Nuair a falamh sreang air a chleachdadh mar SEPARATOR, tha e eadar gach caractar ann an sreang, còmhla ri an toiseach agus deireadh an t-sreang.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Faodaidh luchd-sgaradh co-shìnte giùlan a dh `fhaodadh a bhith na iongnadh nuair a thèid àite geal a chleachdadh mar an dealaiche.Tha an còd seo ceart:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Tha e a `toirt _not_ dhut:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Cleachd [`split_whitespace`] airson an giùlan seo.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Reultair os cionn fo-fhilleadh na sliseag sreang seo, air a sgaradh le caractaran a tha a rèir pàtran.
    /// Tha e eadar-dhealaichte bhon iterator a rinn `split` leis gu bheil `split_inclusive` a `fàgail a` phàirt a tha air a mhaidseadh mar inneal-crìochnachaidh an fho-strat.
    ///
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Ma tha an eileamaid mu dheireadh den sreang air a mhaidseadh, thèid an eileamaid sin a mheas mar neach-crìochnachaidh an fho-strat roimhe.
    /// Is e an substring sin an rud mu dheireadh a thill an iterator.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Iterator thairis air fo-stratan den t-sreang sreang a chaidh a thoirt seachad, air a sgaradh le caractaran a tha air am maidseadh le pàtran agus air an toirt a-mach ann an òrdugh cas.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Giùlan Iterator
    ///
    /// Tha an iterator a chaidh a thilleadh ag iarraidh gum bi am pàtran a `toirt taic do sgrùdadh cùil, agus bidh e na [`DoubleEndedIterator`] ma bheir sgrùdadh forward/reverse na h-aon eileamaidean a-mach.
    ///
    ///
    /// Airson a bhith ag itealaich bhon bheulaibh, faodar an dòigh [`split`] a chleachdadh.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Pàtranan sìmplidh:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Pàtran nas iom-fhillte, a `cleachdadh dùnadh:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Ath-aithrisiche thairis air fo-fhilleadh den t-sreang sreang a chaidh a thoirt seachad, air a sgaradh le caractaran a tha air am maidseadh le pàtran.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Co-ionann ri [`split`], ach a 'slaodadh substring leum ma falamh.
    ///
    /// [`split`]: str::split
    ///
    /// Faodar an dòigh seo a chleachdadh airson dàta sreang a tha _terminated_, seach _separated_ a rèir pàtran.
    ///
    /// # Giùlan Iterator
    ///
    /// Bidh an iterator a chaidh a thilleadh na [`DoubleEndedIterator`] ma tha am pàtran a `ceadachadh sgrùdadh cùil agus toradh sgrùdadh forward/reverse a` toirt a-mach na h-aon eileamaidean.
    /// Tha seo fìor airson, me, [`char`], ach chan eil airson `&str`.
    ///
    /// Ma tha am pàtran a `ceadachadh sgrùdadh cùil ach dh` fhaodadh na toraidhean aige a bhith eadar-dhealaichte bho sgrùdadh air adhart, faodar an dòigh [`rsplit_terminator`] a chleachdadh.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Iterator thairis air fo-stratan de `self`, air an sgaradh le caractaran a tha air am maidseadh le pàtran agus air an toirt seachad ann an òrdugh cas.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Co-ionann ri [`split`], ach a 'slaodadh substring leum ma falamh.
    ///
    /// [`split`]: str::split
    ///
    /// Faodar an dòigh seo a chleachdadh airson dàta sreang a tha _terminated_, seach _separated_ a rèir pàtran.
    ///
    /// # Giùlan Iterator
    ///
    /// Tha an iterator a chaidh a thilleadh ag iarraidh gum bi am pàtran a `toirt taic do sgrùdadh cùil, agus bidh crìoch dhùbailte air ma bheir rannsachadh forward/reverse na h-aon eileamaidean a-mach.
    ///
    ///
    /// Airson a bhith ag itealaich bhon bheulaibh, faodar an dòigh [`split_terminator`] a chleachdadh.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Bidh iterator thairis air substrings den t-sreang sreang a chaidh a thoirt seachad, air a sgaradh le pàtran, air a chuingealachadh gu bhith a `tilleadh aig a` mhòr-chuid de nithean `n`.
    ///
    /// Ma thèid fo-stratan `n` a thilleadh, bidh an còrr den t-sreang anns an fho-strat mu dheireadh (an `n`th substring).
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Giùlan Iterator
    ///
    /// Cha bhith ceann dùbailte aig an iterator a chaidh a thilleadh, seach nach eil e èifeachdach taic a thoirt.
    ///
    /// Ma tha am pàtran a `ceadachadh sgrùdadh cùil, faodar an dòigh [`rsplitn`] a chleachdadh.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Pàtranan sìmplidh:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Pàtran nas iom-fhillte, a `cleachdadh dùnadh:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Bidh iterator thairis air substrings den t-sreang seo, air a sgaradh le pàtran, a `tòiseachadh bho dheireadh na sreang, air a chuingealachadh ri bhith a` tilleadh aig a `mhòr-chuid de nithean `n`.
    ///
    ///
    /// Ma thèid fo-stratan `n` a thilleadh, bidh an còrr den t-sreang anns an fho-strat mu dheireadh (an `n`th substring).
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Giùlan Iterator
    ///
    /// Cha bhith ceann dùbailte aig an iterator a chaidh a thilleadh, seach nach eil e èifeachdach taic a thoirt.
    ///
    /// Airson sgoltadh bhon bheulaibh, faodar an dòigh [`splitn`] a chleachdadh.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Pàtranan sìmplidh:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Pàtran nas iom-fhillte, a `cleachdadh dùnadh:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// A `sgoltadh an sreang air a` chiad tachartas den delimiter ainmichte agus a `tilleadh ro-leasachan ron delimiter agus iar-leasachan às deidh delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// A `sgoltadh an sreang air an tachartas mu dheireadh den delimiter ainmichte agus a` tilleadh ro-leasachan mus delimiter agus iar-leasachan às deidh delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// An iterator thairis air an disjoint matches de phàtran taobh a-staigh a thoirt seachad sreang sliseag.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Giùlan Iterator
    ///
    /// Bidh an iterator a chaidh a thilleadh na [`DoubleEndedIterator`] ma tha am pàtran a `ceadachadh sgrùdadh cùil agus toradh sgrùdadh forward/reverse a` toirt a-mach na h-aon eileamaidean.
    /// Tha seo fìor airson, me, [`char`], ach chan eil airson `&str`.
    ///
    /// Ma tha am pàtran a `ceadachadh sgrùdadh cùil ach dh` fhaodadh na toraidhean aige a bhith eadar-dhealaichte bho sgrùdadh air adhart, faodar an dòigh [`rmatches`] a chleachdadh.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Tha iterator thairis air na maidsean eas-chruthach de phàtran taobh a-staigh an t-sreang sreang seo, air a thoirt a-mach ann an òrdugh cas.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Giùlan Iterator
    ///
    /// Tha an iterator a chaidh a thilleadh ag iarraidh gum bi am pàtran a `toirt taic do sgrùdadh cùil, agus bidh e na [`DoubleEndedIterator`] ma bheir sgrùdadh forward/reverse na h-aon eileamaidean a-mach.
    ///
    ///
    /// Airson a bhith ag itealaich bhon bheulaibh, faodar an dòigh [`matches`] a chleachdadh.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Bidh iterator thairis air na maidsean eas-chruthach de phàtran taobh a-staigh an t-sreang sreang seo a bharrachd air a `chlàr-amais a thòisicheas an gèam.
    ///
    /// Airson maidsean de `pat` taobh a-staigh `self` a tha a `dol thairis air, chan eil ach na clàran-amais a` freagairt ris a `chiad gheama air an tilleadh.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Giùlan Iterator
    ///
    /// Bidh an iterator a chaidh a thilleadh na [`DoubleEndedIterator`] ma tha am pàtran a `ceadachadh sgrùdadh cùil agus toradh sgrùdadh forward/reverse a` toirt a-mach na h-aon eileamaidean.
    /// Tha seo fìor airson, me, [`char`], ach chan eil airson `&str`.
    ///
    /// Ma tha am pàtran a `ceadachadh sgrùdadh cùil ach dh` fhaodadh na toraidhean aige a bhith eadar-dhealaichte bho sgrùdadh air adhart, faodar an dòigh [`rmatch_indices`] a chleachdadh.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // dìreach a `chiad `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Tha iterator thairis air na maidsean eas-chruthach de phàtran taobh a-staigh `self`, air a thoirt a-mach ann an òrdugh cas còmhla ri clàr-amais a `mhaids.
    ///
    /// Airson matches de `pat` taobh a-staigh `self` a chèile, ach an Indices rèir a 'ghèam mu dheireadh a tha a' tilleadh.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Giùlan Iterator
    ///
    /// Tha an iterator a chaidh a thilleadh ag iarraidh gum bi am pàtran a `toirt taic do sgrùdadh cùil, agus bidh e na [`DoubleEndedIterator`] ma bheir sgrùdadh forward/reverse na h-aon eileamaidean a-mach.
    ///
    ///
    /// Airson a bhith ag itealaich bhon bheulaibh, faodar an dòigh [`match_indices`] a chleachdadh.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // dìreach an `aba` mu dheireadh
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// A `tilleadh sliseag sreang le àite geal air thoiseach agus air a thoirt air falbh.
    ///
    /// 'Whitespace' air a mhìneachadh a rèir cumhachan an Unicode Derived Core Property `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// A `tilleadh sliseag sreang le prìomh àite geal air a thoirt air falbh.
    ///
    /// 'Whitespace' air a mhìneachadh a rèir cumhachan an Unicode Derived Core Property `White_Space`.
    ///
    /// # Stiùireadh teacsa
    ///
    /// Is e sreang sreath de bytes.
    /// `start` ann an cho-theacsa seo a 'ciallachadh a' chiad suidheachadh a Byte sreang;airson cànan clì gu deas mar Beurla no Ruisis, bidh seo air an taobh chlì, agus airson cànanan deas gu clì mar Arabais no Eabhra, is e seo an taobh cheart.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// A `tilleadh sliseag sreang le àite geal air a thoirt air falbh.
    ///
    /// 'Whitespace' air a mhìneachadh a rèir cumhachan an Unicode Derived Core Property `White_Space`.
    ///
    /// # Stiùireadh teacsa
    ///
    /// Is e sreang sreath de bytes.
    /// `end` ann an cho-theacsa seo a 'ciallachadh mu dheireadh suidheachadh a Byte sreang;airson cànan clì gu deas mar Beurla no Ruisis, bidh seo air an taobh cheart, agus airson cànanan deas gu clì mar Arabais no Eabhra, is e seo an taobh chlì.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// A `tilleadh sliseag sreang le prìomh àite geal air a thoirt air falbh.
    ///
    /// 'Whitespace' air a mhìneachadh a rèir cumhachan an Unicode Derived Core Property `White_Space`.
    ///
    /// # Stiùireadh teacsa
    ///
    /// Is e sreang sreath de bytes.
    /// 'Left' tha an co-theacsa seo a `ciallachadh a` chiad shuidheachadh den t-sreang byte sin;airson cànan mar Arabais no Eabhra a tha `deas gu clì` seach `clì gu deas`, is e seo an taobh _right_, chan e an taobh chlì.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// A `tilleadh sliseag sreang le àite geal air a thoirt air falbh.
    ///
    /// 'Whitespace' air a mhìneachadh a rèir cumhachan an Unicode Derived Core Property `White_Space`.
    ///
    /// # Stiùireadh teacsa
    ///
    /// Is e sreang sreath de bytes.
    /// 'Right' ann an cho-theacsa seo a 'ciallachadh mu dheireadh suidheachadh a Byte sreang;airson cànan mar Arabais no Eabhra a tha `ceart gu clì` seach `clì gu deas`, is e seo an taobh _left_, chan e an taobh cheart.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// TILLEADH sreang le sliseag a h-uile Ro-leasachain agus suffixes a rèir pàtran uair is uair a thoirt air falbh.
    ///
    /// Faodaidh an [pattern] a bhith na [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Pàtranan sìmplidh:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Pàtran nas iom-fhillte, a `cleachdadh dùnadh:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Cuimhnich air a `gheama as tràithe a tha aithnichte, ceartaich e gu h-ìosal ma tha
            // Air gèam eadar-dhealaichte
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SÀBHAILTEACHD: Tha fios gu bheil `Searcher` a `tilleadh chlàran-amais dligheach.
        unsafe { self.get_unchecked(i..j) }
    }

    /// A `tilleadh sliseag sreang leis a h-uile ro-leasachan a tha a` maidseadh pàtran air a thoirt air falbh a-rithist.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Stiùireadh teacsa
    ///
    /// Is e sreang sreath de bytes.
    /// `start` ann an cho-theacsa seo a 'ciallachadh a' chiad suidheachadh a Byte sreang;airson cànan clì gu deas mar Beurla no Ruisis, bidh seo air an taobh chlì, agus airson cànanan deas gu clì mar Arabais no Eabhra, is e seo an taobh cheart.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SÀBHAILTEACHD: Tha fios gu bheil `Searcher` a `tilleadh chlàran-amais dligheach.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// TILLEADH sreang sliseag leis an ro-leasachan a thoirt air falbh.
    ///
    /// Ma thòisicheas an sreang leis a `phàtran `prefix`, tillidh e air ais às deidh an ro-leasachan, air a phasgadh ann an `Some`.
    /// Eu-coltach ri `trim_start_matches`, bidh an dòigh seo a `toirt air falbh an ro-leasachan dìreach aon uair.
    ///
    /// Mura tòisich an sreang le `prefix`, tillidh `None`.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// A `tilleadh sliseag sreang leis an iar-leasachan air a thoirt air falbh.
    ///
    /// Ma thig an sreang gu crìch leis a `phàtran `suffix`, tillidh e an t-substring ron iar-leasachan, air a phasgadh ann an `Some`.
    /// Eu-coltach ri `trim_end_matches`, bidh an dòigh seo a `toirt air falbh an iar-leasachan dìreach aon uair.
    ///
    /// Mura h-eil an sreang a `crìochnachadh le `suffix`, tillidh `None`.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// A `tilleadh sliseag sreang leis a h-uile iar-leasachan a tha a` maidseadh pàtran air a thoirt air falbh a-rithist.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Stiùireadh teacsa
    ///
    /// Is e sreang sreath de bytes.
    /// `end` ann an cho-theacsa seo a 'ciallachadh mu dheireadh suidheachadh a Byte sreang;airson cànan clì gu deas mar Beurla no Ruisis, bidh seo air an taobh cheart, agus airson cànanan deas gu clì mar Arabais no Eabhra, is e seo an taobh chlì.
    ///
    ///
    /// # Examples
    ///
    /// Pàtranan sìmplidh:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Pàtran nas iom-fhillte, a `cleachdadh dùnadh:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SÀBHAILTEACHD: Tha fios gu bheil `Searcher` a `tilleadh chlàran-amais dligheach.
        unsafe { self.get_unchecked(0..j) }
    }

    /// A `tilleadh sliseag sreang leis a h-uile ro-leasachan a tha a` maidseadh pàtran air a thoirt air falbh a-rithist.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Stiùireadh teacsa
    ///
    /// Is e sreang sreath de bytes.
    /// 'Left' tha an co-theacsa seo a `ciallachadh a` chiad shuidheachadh den t-sreang byte sin;airson cànan mar Arabais no Eabhra a tha `deas gu clì` seach `clì gu deas`, is e seo an taobh _right_, chan e an taobh chlì.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// A `tilleadh sliseag sreang leis a h-uile iar-leasachan a tha a` maidseadh pàtran air a thoirt air falbh a-rithist.
    ///
    /// Faodaidh an [pattern] a bhith na `&str`, [`char`], sliseag de [`char`] s, no gnìomh no dùnadh a tha a`dearbhadh a bheil caractar a`maidseadh.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Stiùireadh teacsa
    ///
    /// Is e sreang sreath de bytes.
    /// 'Right' ann an cho-theacsa seo a 'ciallachadh mu dheireadh suidheachadh a Byte sreang;airson cànan mar Arabais no Eabhra a tha `ceart gu clì` seach `clì gu deas`, is e seo an taobh _left_, chan e an taobh cheart.
    ///
    ///
    /// # Examples
    ///
    /// Pàtranan sìmplidh:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Pàtran nas iom-fhillte, a `cleachdadh dùnadh:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Parses an sreang seo gu seòrsa eile.
    ///
    /// Leis gu bheil `parse` cho coitcheann, faodaidh e duilgheadasan adhbhrachadh le co-dhùnadh seòrsa.
    /// Mar sin, `parse` S e aon de na beagan amannan chì thu na sheantansan gràdhach ris an canar 'turbofish': `::<>`.
    ///
    /// Tha seo a 'cuideachadh a' tuigsinn inference algairim sònraichte Dè an seòrsa a tha thu a 'feuchainn ri parse a-steach.
    ///
    /// `parse` urrainn parsadh a-steach do sheòrsa sam bith a chuireas an [`FromStr`] trait an gnìomh.
    ///

    /// # Errors
    ///
    /// Tillidh e [`Err`] mura h-eil e comasach an sliseag sreang seo a pharsadh a-steach don t-seòrsa a tha thu ag iarraidh.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// A `cleachdadh an 'turbofish' an àite a bhith a` comharrachadh `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// A `fàilligeadh a pharsadh:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Dèan cinnteach a bheil a h-uile caractar san t-sreang seo taobh a-staigh raon ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Is urrainn dhuinn gach byte a làimhseachadh mar charactar an seo: bidh gach caractar multibyte a `tòiseachadh le byte nach eil anns an raon ascii, agus mar sin stadaidh sinn an sin mu thràth.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// A `dèanamh cinnteach gu bheil dà shreath mar mhaids cùis-neo-mhothachail ASCII.
    ///
    /// Co-ionann ri `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ach gun a bhith a `riarachadh agus a` dèanamh copaidh de temporaries.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Converts seo a ASCII sreang gu h-àrd a 'chùis co-ionann ann an-àite.
    ///
    /// Tha litrichean ASCII 'a' gu 'z' air am mapadh gu 'A' gu 'Z', ach tha litrichean neo-ASCII gun atharrachadh.
    ///
    /// Gus luach àrd ùr a thilleadh gun a bhith ag atharrachadh an fhear a th `ann, cleachd [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SÀBHAILTEACHD: sàbhailte oir bidh sinn a `gluasad thairis air dà sheòrsa leis an aon chruth.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Converts seo sreang a thoirt a-ASCII ìsle chùis co-ionann ann an-àite.
    ///
    /// Tha litrichean ASCII 'A' gu 'Z' air am mapadh gu 'a' gu 'z', ach tha litrichean neo-ASCII gun atharrachadh.
    ///
    /// Gus luach ùr le ìsleachadh a thoirt air ais gun a bhith ag atharrachadh an fhear a th `ann, cleachd [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SÀBHAILTEACHD: sàbhailte oir bidh sinn a `gluasad thairis air dà sheòrsa leis an aon chruth.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Thoir air ais iterator a bhios a `teicheadh bho gach char ann an `self` le [`char::escape_debug`].
    ///
    ///
    /// Note: is e dìreach còdan puing grapheme leudaichte a thòisicheas an sreang.
    ///
    /// # Examples
    ///
    /// Mar iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// A `cleachdadh `println!` gu dìreach:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Tha an dà rud co-ionann ri:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// A `cleachdadh `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Thoir air ais iterator a bhios a `teicheadh bho gach char ann an `self` le [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Mar iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// A `cleachdadh `println!` gu dìreach:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Tha an dà rud co-ionann ri:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// A `cleachdadh `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Thoir air ais iterator a bhios a `teicheadh bho gach char ann an `self` le [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Mar iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// A `cleachdadh `println!` gu dìreach:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Tha an dà rud co-ionann ri:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// A `cleachdadh `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// A `cruthachadh str falamh
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// A 'cruthachadh falamh mutable str
    #[inline]
    fn default() -> Self {
        // SÀBHAILTEACHD: Tha an sreang falamh dligheach UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Seòrsa fn ainmichte, cloneable
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // Sàbhailteachd: cha sàbhailte
        unsafe { from_utf8_unchecked(bytes) }
    };
}