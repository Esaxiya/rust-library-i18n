//! Dòighean air `str` a chruthachadh bho slice bytes.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Bidh e ag atharrachadh sliseag de bytes gu sliseag sreang.
///
/// Tha sliseag sreang ([`&str`]) air a dhèanamh le bytes ([`u8`]), agus tha byte slice ([`&[u8]`][byteslice]) air a dhèanamh le bytes, agus mar sin bidh an gnìomh seo ag atharrachadh eadar an dà rud.
/// Chan eil a h-uile sliseag byte nan sliseagan sreang dligheach, ge-tà: tha [`&str`] ag iarraidh gu bheil e dligheach UTF-8.
/// `from_utf8()` sgrùdaidhean gus dèanamh cinnteach gu bheil na bytes dligheach UTF-8, agus an uairsin an tionndadh.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Ma tha thu cinnteach gu bheil an sliseag byte dligheach UTF-8, agus nach eil thu airson faighinn thairis air an sgrùdadh dligheachd, tha dreach neo-shàbhailte den ghnìomh seo, [`from_utf8_unchecked`], aig a bheil an aon ghiùlan ach a `leum às an t-seic.
///
///
/// Ma tha feum agad air `String` an àite `&str`, beachdaich air [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Leis gun urrainn dhut `[u8; N]` a riarachadh, agus faodaidh tu [`&[u8]`][byteslice] a thoirt dheth, is e an gnìomh seo aon dòigh air sreang a bhith air a riarachadh le stac.Tha eisimpleir den seo ann an earrann na h-eisimpleirean gu h-ìosal.
///
/// [byteslice]: slice
///
/// # Errors
///
/// A `tilleadh `Err` mura h-e UTF-8 an sliseag le tuairisgeul air carson nach e UTF-8 an sliseag a chaidh a thoirt seachad.
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// use std::str;
///
/// // cuid bytes, ann an vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Tha fios againn air seo bytes tha dligheach, agus mar sin dìreach a 'cleachdadh `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Beart ceàrr:
///
/// ```
/// use std::str;
///
/// // cuid de bytes neo-dhligheach, ann an vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Faic na docaichean airson [`Utf8Error`] airson tuilleadh fiosrachaidh mu na seòrsaichean mhearachdan a ghabhas tilleadh.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // cuid de bytes, ann an sreath air a riarachadh le stac
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Tha fios againn air seo bytes tha dligheach, agus mar sin dìreach a 'cleachdadh `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SÀBHAILTEACHD: Dìreach ruith dearbhadh.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Bidh e ag atharrachadh sliseag de bhiteagan gu sliseag sreang gluasadach.
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" mar vector mutable
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Mar a tha fios againn gu bheil na bytes sin dligheach, is urrainn dhuinn `unwrap()` a chleachdadh
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Beart ceàrr:
///
/// ```
/// use std::str;
///
/// // Cuid de bytes neo-dhligheach ann an mutable vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Faic na docaichean airson [`Utf8Error`] airson tuilleadh fiosrachaidh mu na seòrsaichean mhearachdan a ghabhas tilleadh.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SÀBHAILTEACHD: Dìreach ruith dearbhadh.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Converts sliseag bytes ri sreang sliseag gun cinnteach gu bheil an t-sreang mu dligheach UTF-8.
///
/// Faic an dreach sàbhailte, [`from_utf8`], airson tuilleadh fiosrachaidh.
///
/// # Safety
///
/// Tha an gnìomh seo cunnartach oir chan eil e a `dèanamh cinnteach gu bheil na bytes a chaidh a thoirt dha dligheach UTF-8.
/// Ma thèid an cuingeachadh seo a bhriseadh, thig giùlan neo-mhìnichte, oir tha an còrr de Rust a `gabhail ris gu bheil [`&str`] s dligheach UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// use std::str;
///
/// // cuid bytes, ann an vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gu bheil na bytes `v` dligheach UTF-8.
    // Cuideachd an urra ri `&str` agus `&[u8]` an aon dreach a bhith aca.
    unsafe { mem::transmute(v) }
}

/// Bidh e ag atharrachadh sliseag de bytes gu sliseag sreang gun a bhith a `dèanamh cinnteach gu bheil UTF-8 dligheach anns an t-sreang;dreach mutable.
///
///
/// Faic an dreach immutable, [`from_utf8_unchecked()`] airson tuilleadh fiosrachaidh.
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // Sàbhailteachd: a dh'fheumas an neach-conaltraidh barantas gun bytes `v`
    // tha UTF-8 dligheach, mar sin tha an tilgeadh gu `*mut str` sàbhailte.
    // Cuideachd, tha dì-cheadachadh a `phuing sàbhailte oir tha an comharradh sin a` tighinn bho iomradh a tha cinnteach a bhith dligheach airson sgrìobhaidhean.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}