//! A `mìneachadh seòrsa mearachd utf8.

use crate::fmt;

/// Mearachdan a dh'fhaodas tachairt nuair a thathar a `feuchainn ri sreath de [`u8`] a mhìneachadh mar sreang.
///
/// Mar sin, bidh an teaghlach `from_utf8` de ghnìomhan agus dhòighean-obrach airson an dà chuid [`String`] s agus [`&str`] s a `cleachdadh a` mhearachd seo, mar eisimpleir.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Faodar dòighean den t-seòrsa mearachd seo a chleachdadh gus comas-gnìomh coltach ri `String::from_utf8_lossy` a chruthachadh gun a bhith a `riarachadh cuimhne heap:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// A `tilleadh an clàr-amais anns an t-sreang a chaidh a thoirt seachad gus an deach UTF-8 dligheach a dhearbhadh.
    ///
    /// Is e an clàr-amais as motha a th `ann gun tilleadh `from_utf8(&input[..index])` `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::str;
    ///
    /// // cuid de bytes neo-dhligheach, ann an vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 a `tilleadh Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // tha an dàrna byte neo-dhligheach an seo
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// A 'toirt tuilleadh fiosrachaidh mu fàilligeadh:
    ///
    /// * `None`: chaidh deireadh an in-chuir a ruighinn gun dùil.
    ///   `self.valid_up_to()` is 1 gu 3 bytes bho dheireadh an in-chuir.
    ///   Ma tha sruth byte (leithid faidhle no socaid lìonra) ga dhì-chòdachadh mean air mhean, dh `fhaodadh seo a bhith na `char` dligheach aig a bheil sreath byte UTF-8 a` spangachadh ioma-chnap.
    ///
    ///
    /// * `Some(len)`: thachair byte ris nach robh dùil.
    ///   Is e an fhaid a tha air a thoirt seachad an t-sreath byte neo-dhligheach a thòisicheas aig a `chlàr-innse a thug `valid_up_to()`.
    ///   Bu chòir an còdachadh ath-thòiseachadh às deidh an t-sreath sin (às deidh [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] a chuir a-steach) air eagal gun tèid còdachadh calltach.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Tha mearachd a chaidh a thilleadh nuair a chaidh `bool` a pharsadh a `cleachdadh [`from_str`] a` fàiligeadh
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}