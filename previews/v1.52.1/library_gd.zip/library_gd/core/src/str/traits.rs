//! Buileachadh Trait airson `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// A `toirt buaidh air òrdachadh sreathan.
///
/// Tha sreathan air an òrdachadh [lexicographically](Ord#lexicographical-comparison) a rèir an luachan byte.
/// Bidh seo ag òrdachadh puingean còd Unicode stèidhichte air an t-suidheachadh aca anns na clàran còd.
/// Chan eil seo ionann "alphabetical" òrdugh, a bhios ag atharrachadh a-rèir cànain agus locale.
/// A `rèiteach shreathan a rèir inbhean ris an deach gabhail gu cultarach feumaidh dàta a tha sònraichte do locale a tha taobh a-muigh raon an t-seòrsa `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// A `toirt buaidh air obair coimeas air sreangan.
///
/// Tha sreathan air an coimeas [lexicographically](Ord#lexicographical-comparison) a rèir an luachan byte.
/// Tha seo a `dèanamh coimeas eadar puingean còd Unicode stèidhichte air an t-suidheachadh aca anns na clàran còd.
/// Chan eil seo ionann "alphabetical" òrdugh, a bhios ag atharrachadh a-rèir cànain agus locale.
/// Tha a bhith a `dèanamh coimeas eadar sreathan a rèir inbhean ris an deach gabhail gu cultarach a` feumachdainn dàta a tha sònraichte do locale a tha taobh a-muigh raon an t-seòrsa `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Innealan substring slicing le sheantansan `&self[..]` no `&mut self[..]`.
///
/// Tilleadh sliseag air fad sreang, 'se sin, toradh a `&self` no `&mut self`.Co-ionann ri `&fèin [0 ..
/// Len] `no`&mut fèin [0 ..
/// len]`.
/// Eu-coltach ri gnìomhachd clàr-amais eile, chan urrainn dha seo a-riamh panic.
///
/// Is e an obrachadh seo *O*(1).
///
/// Ro 1.20.0, bha na h-obraichean clàr-amais sin fhathast a `faighinn taic bho bhuileachadh dìreach `Index` agus `IndexMut`.
///
/// Co-ionann ri `&self[0 .. len]` no `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// A `toirt buaidh air sliseag substring le co-chòrdadh `&self[begin .. end]` no `&mut self[begin .. end]`.
///
/// Tilleadh sliseag an sreang a thoirt bho raon Byte [`begin`, `end`).
///
/// Is e an obrachadh seo *O*(1).
///
/// Ro 1.20.0, bha na h-obraichean clàr-amais sin fhathast a `faighinn taic bho bhuileachadh dìreach `Index` agus `IndexMut`.
///
/// # Panics
///
/// Panics mura h-eil `begin` no `end` a `comharrachadh toiseach tòiseachaidh caractar (mar a chaidh a mhìneachadh le `is_char_boundary`), ma tha `begin > end`, no ma `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // bidh iad sin panic:
/// // tha byte 2 na laighe taobh a-staigh `ö`:
/// // &s [2 ..3];
///
/// // tha byte 8 na laighe taobh a-staigh `老`&s [1 ..
/// // 8];
///
/// // tha byte 100 taobh a-muigh an sreang&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SÀBHAILTEACHD: dìreach dèan cinnteach gu bheil `start` agus `end` air crìoch char,
            // agus tha sinn a `dol seachad ann an teisteanas sàbhailte, mar sin bidh an luach toraidh cuideachd mar aon.
            // Rinn sinn sgrùdadh cuideachd air crìochan char, mar sin tha seo dligheach UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SÀBHAILTEACHD: dìreach dèan cinnteach gu bheil `start` agus `end` air crìoch char.
            // Tha fios againn gu bheil am putan sònraichte oir fhuair sinn e bho `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SÀBHAILTEACHD: tha an neach-fios a `gealltainn gu bheil `self` ann an crìochan `slice`
        // a tha a `sàsachadh na cumhaichean uile airson `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SÀBHAILTEACHD: faic beachdan airson `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary a `dèanamh cinnteach gu bheil an clàr-amais ann an [0, chan urrainn do .len()] `get` ath-chleachdadh mar gu h-àrd, air sgàth trioblaid NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SÀBHAILTEACHD: dìreach dèan cinnteach gu bheil `start` agus `end` air crìoch char,
            // agus tha sinn a `dol seachad ann an teisteanas sàbhailte, mar sin bidh an luach toraidh cuideachd mar aon.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// A `toirt buaidh air sliseag substring le co-chòrdadh `&self[.. end]` no `&mut self[.. end]`.
///
/// A `tilleadh sliseag den sreang a chaidh a thoirt seachad bhon raon byte [` 0`, `end`).
/// Co-ionann ri `&self[0 .. end]` no `&mut self[0 .. end]`.
///
/// Is e an obrachadh seo *O*(1).
///
/// Ro 1.20.0, bha na h-obraichean clàr-amais sin fhathast a `faighinn taic bho bhuileachadh dìreach `Index` agus `IndexMut`.
///
/// # Panics
///
/// Panics mura h-eil `end` a `comharrachadh gu bheil toiseach tòiseachaidh a` toirt air falbh caractar (mar a tha e air a mhìneachadh le `is_char_boundary`), no ma tha `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SÀBHAILTEACHD: dìreach dèan cinnteach gu bheil `end` air crìoch char,
            // agus tha sinn a `dol seachad ann an teisteanas sàbhailte, mar sin bidh an luach toraidh cuideachd mar aon.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SÀBHAILTEACHD: dìreach dèan cinnteach gu bheil `end` air crìoch char,
            // agus tha sinn a `dol seachad ann an teisteanas sàbhailte, mar sin bidh an luach toraidh cuideachd mar aon.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SÀBHAILTEACHD: dìreach dèan cinnteach gu bheil `end` air crìoch char,
            // agus tha sinn a `dol seachad ann an teisteanas sàbhailte, mar sin bidh an luach toraidh cuideachd mar aon.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// A `toirt buaidh air sliseag substring le co-chòrdadh `&self[begin ..]` no `&mut self[begin ..]`.
///
/// A `tilleadh sliseag den t-sreang a chaidh a thoirt seachad bhon raon byte [` begin`, `len`).Co-ionann ri`&fèin [tòiseachadh ..
/// len] `no`&mut fèin [tòiseachadh ..
/// len]`.
///
/// Is e an obrachadh seo *O*(1).
///
/// Ro 1.20.0, bha na h-obraichean clàr-amais sin fhathast a `faighinn taic bho bhuileachadh dìreach `Index` agus `IndexMut`.
///
/// # Panics
///
/// Panics mura h-eil `begin` a `comharrachadh gu bheil toiseach tòiseachaidh a` toirt air falbh caractar (mar a tha `is_char_boundary` air a mhìneachadh), no ma tha `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SÀBHAILTEACHD: dìreach dèan cinnteach gu bheil `start` air crìoch char,
            // agus tha sinn a `dol seachad ann an teisteanas sàbhailte, mar sin bidh an luach toraidh cuideachd mar aon.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SÀBHAILTEACHD: dìreach dèan cinnteach gu bheil `start` air crìoch char,
            // agus tha sinn a `dol seachad ann an teisteanas sàbhailte, mar sin bidh an luach toraidh cuideachd mar aon.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SÀBHAILTEACHD: tha an neach-fios a `gealltainn gu bheil `self` ann an crìochan `slice`
        // a tha a `sàsachadh na cumhaichean uile airson `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SÀBHAILTEACHD: co-ionann ri `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SÀBHAILTEACHD: dìreach dèan cinnteach gu bheil `start` air crìoch char,
            // agus tha sinn a `dol seachad ann an teisteanas sàbhailte, mar sin bidh an luach toraidh cuideachd mar aon.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// A `toirt buaidh air sliseag substring le co-chòrdadh `&self[begin ..= end]` no `&mut self[begin ..= end]`.
///
/// TILLEADH sliseag an sreang a thoirt bho raon Byte [`begin`, `end`].Co-ionann ri `&self [begin .. end + 1]` no `&mut self[begin .. end + 1]`, ach a-mhàin ma tha an luach as motha aig `end` airson `usize`.
///
/// Is e an obrachadh seo *O*(1).
///
/// # Panics
///
/// Panics ma `begin` chan eil gu tòiseachadh Byte chothromachadh de charactar (mar a mhìnichear le `is_char_boundary`), ma `end` chan eil àite a 'crìochnachadh Byte chothromachadh de charactar (`end + 1` S e an dàrna cuid a 'tòiseachadh Byte chothromachadh no co-ionnan ri `len`), ma `begin > end`, no ma tha `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `get_unchecked` a chumail suas.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `get_unchecked_mut` a chumail suas.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Innealan substring slicing le sheantansan `&self[..= end]` no `&mut self[..= end]`.
///
/// A `tilleadh sliseag den sreang a chaidh a thoirt seachad bhon raon byte [0, `end`].
/// Co-ionann ri `&self [0 .. end + 1]`, ach a-mhàin ma tha an luach as motha aig `end` airson `usize`.
///
/// Is e an obrachadh seo *O*(1).
///
/// # Panics
///
/// Panics mura h-eil `end` a `comharrachadh gu bheil crìoch air a chuir air falbh le caractar (tha `end + 1` an dàrna cuid mar fhrith-thòiseachadh byte mar a chaidh a mhìneachadh le `is_char_boundary`, no co-ionann ri `len`), no ma tha `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `get_unchecked` a chumail suas.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `get_unchecked_mut` a chumail suas.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Parse luach bho sreang
///
/// `FromStr` aig [`from_str`] dòigh air a chleachdadh tric dhìreach, tro [`str`] 's [`parse`] dòigh.
/// Faic sgrìobhainnean [`parse`] airson eisimpleirean.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` chan eil paramadair fad-beatha ann, agus mar sin chan urrainn dhut ach seòrsaichean a pharsadh anns nach eil paramadair fad-beatha iad fhèin.
///
/// Ann am faclan eile, faodaidh tu `i32` a pharsadh le `FromStr`, ach chan e `&i32`.
/// Faodaidh tu structar a pharsadh anns a bheil `i32`, ach chan e fear anns a bheil `&i32`.
///
/// # Examples
///
/// Buileachadh bunaiteach de `FromStr` air eisimpleir seòrsa `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// A `mhearachd co-cheangailte ris a dh` fhaodar a thilleadh bho parsadh.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Parses sreang `s` gus luach den t-seòrsa seo a thilleadh.
    ///
    /// Ma shoirbhicheas le parsadh, till an luach taobh a-staigh [`Ok`], air dhòigh eile nuair a tha an sreang gun cruth air ais mearachd a tha sònraichte don [`Err`] a-staigh.
    /// Tha an seòrsa mearachd sònraichte airson buileachadh an trait.
    ///
    /// # Examples
    ///
    /// Basic cleachdadh le [`i32`], seòrsa sin innealan `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Parse `bool` bho sreang.
    ///
    /// Toradh `Result<bool, ParseBoolError>`, oir is dòcha gu bheil `s` parseable no nach eil.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Cuimhnich, ann an iomadh cùis, an `.parse()` dòigh air `str` e nas ceart.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}