//! A `mìneachadh an iterator seilbh `IntoIter` airson arrays.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// A iterator by-value [array].
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Is e seo an raon a tha sinn ag itealaich thairis.
    ///
    /// Tha eileamaidean le clàr-amais `i` far nach deach `alive.start <= i < alive.end` a thoirt seachad fhathast agus tha iad nan inntrigidhean dligheach dligheach.
    /// Chaidh eileamaidean le clàran-amais `i < alive.start` no `i >= alive.end` a thoirt a-mach mu thràth agus chan fhaodar faighinn thuca tuilleadh!Dh `fhaodadh na h-eileamaidean marbh sin a bhith eadhon ann an staid gu tur neo-aithnichte!
    ///
    ///
    /// Mar sin tha na h-invariants:
    /// - `data[alive]` beò (ie tha eileamaidean dligheach ann)
    /// - `data[..alive.start]` agus tha `data[alive.end..]` marbh (ie chaidh na h-eileamaidean a leughadh mu thràth agus chan fhaodar suathadh annta tuilleadh!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Na h-eileamaidean ann an `data` nach deach a thoirt seachad fhathast.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// A `cruthachadh iterator ùr thairis air an `array` a chaidh a thoirt seachad.
    ///
    /// *Nòta*: dh `fhaodadh an dòigh seo a bhith air a mholadh anns an future, às deidh [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Tha an seòrsa `value` S e `i32` an seo, an àite `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SÀBHAILTEACHD: Tha an transmute an seo sàbhailte gu dearbh.Na docaichean de `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` tha e cinnteach gum bi an aon mheud agus co-thaobhadh aige
        // > mar `T`.
        //
        // Tha na docaichean eadhon a `sealltainn transmute bho sreath de `MaybeUninit<T>` gu sreath de `T`.
        //
        //
        // Leis an sin, bidh an tòiseachadh seo a `sàsachadh nan invariants.

        // FIXME(LukasKalbertodt): cleachd `mem::transmute` an seo, aon uair'sgu bheil e ag obair le const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Gu ruige sin, is urrainn dhuinn `mem::transmute_copy` a chleachdadh gus leth-bhreac bitwise a chruthachadh mar sheòrsa eadar-dhealaichte, an uairsin dìochuimhneachadh `array` gus nach tèid a leigeil sìos.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// A `tilleadh sliseag so-ruigsinneach de na h-eileamaidean uile nach deach a thoirt seachad fhathast.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // Sàbhailteachd: Tha fios againn gu bheil a h-uile taobh a-staigh eileamaidean `alive` tha a thòiseachadh gu ceart.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// A `tilleadh sliseag gluasadach de na h-eileamaidean uile nach deach a thoirt seachad fhathast.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // Sàbhailteachd: Tha fios againn gu bheil a h-uile taobh a-staigh eileamaidean `alive` tha a thòiseachadh gu ceart.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Faigh an ath chlàr-amais bhon aghaidh.
        //
        // Tha àrdachadh `alive.start` le 1 a `cumail suas an ionnsaigh a thaobh `alive`.
        // Ach, air sgàth an atharrachaidh seo, airson ùine ghoirid, chan e `data[alive]` a th `anns a` chrios beò tuilleadh, ach `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Leugh an eileamaid bhon raon.
            // SÀBHAILTEACHD: Tha `idx` na chlàr-amais a-steach don t-seann roinn "alive" den
            // raon.Tha leughadh an eileamaid seo a `ciallachadh gu bheil `data[idx]` air a mheas marbh a-nis (ie na bi suathadh).
            // Mar `idx` a bha an toiseach na beò-sòn, beò an sòn tha a-nis `data[alive]` a-rithist, air ais a h-uile invariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Faigh an ath chlàr-amais bhon chùl.
        //
        // Tha ìsleachadh `alive.end` le 1 a `cumail suas an ionnsaigh a thaobh `alive`.
        // Ach, air sgàth an atharrachaidh seo, airson ùine ghoirid, chan e `data[alive]` a th `anns a` chrios beò tuilleadh, ach `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Leugh an eileamaid bhon raon.
            // SÀBHAILTEACHD: Tha `idx` na chlàr-amais a-steach don t-seann roinn "alive" den
            // raon.Tha leughadh an eileamaid seo a `ciallachadh gu bheil `data[idx]` air a mheas marbh a-nis (ie na bi suathadh).
            // Leis gur e `idx` deireadh na sòn beò, tha an sòn beò a-nis `data[alive]` a-rithist, ag ath-nuadhachadh a h-uile ionnsaigh.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SÀBHAILTEACHD: Tha seo sàbhailte: bidh `as_mut_slice` a `tilleadh dìreach an fho-slice
        // de eileamaidean nach deach a ghluasad a-mach fhathast agus a tha fhathast ri bhith air an leigeil sìos.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Cha tèid e a-steach gu bràth air sgàth an invariant `beò.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Bidh an iterator gu dearbh ag aithris an fhaid cheart.
// Is e an àireamh de eileamaidean "alive" (a thèid a thoirt a-mach fhathast) fad an raon `alive`.
// Tha an raon seo air a lughdachadh ann am fad ann an `next` no `next_back`.
// Tha e an-còmhnaidh air a lughdachadh le 1 anns na modhan sin, ach dìreach ma thèid `Some(_)` a thilleadh.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Thoir fa-near, cha leig sinn a leas a bhith a `maidseadh an aon raon beò, agus mar sin is urrainn dhuinn dìreach clone a chuir a-steach gu 0 a dh` aindeoin càite a bheil `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Clone gach eileamaid beò.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Sgrìobh clone a-steach don raon ùr, agus an uairsin ùraich an raon beò aige.
            // Ma tha thu a `cliogadh panics, leigidh sinn sìos na nithean a bh` ann roimhe gu ceart.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Na clò-bhuail ach na h-eileamaidean nach deach an toirt a-mach fhathast: chan urrainn dhuinn faighinn gu na h-eileamaidean toraidh tuilleadh.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}