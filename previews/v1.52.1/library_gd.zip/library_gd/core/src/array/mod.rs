//! Buileachadh rudan mar `Eq` airson arrays fad stèidhichte suas gu faid sònraichte.
//! Mu dheireadh, bu chòir dhuinn a bhith comasach air coitcheannachadh gu gach faid.
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// Bidh e ag atharrachadh iomradh air `T` gu bhith na iomradh air sreath de dh'fhaid 1 (gun a bhith a `dèanamh copaidh).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // SÀBHAILTEACHD: Tha tionndadh `&T` gu `&[T; 1]` fuaim.
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// Bidh e ag atharrachadh iomradh gluasadach gu `T` gu bhith na iomradh gluasadach air sreath de dh'fhaid 1 (gun a bhith a `dèanamh copaidh).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // SÀBHAILTEACHD: Tha tionndadh `&mut T` gu `&mut [T; 1]` fuaim.
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// Utility trait air a bhuileachadh a-mhàin air arrays de mheud stèidhichte
///
/// Faodar an trait seo a chleachdadh gus traits eile a chuir an gnìomh air arrays meud stèidhichte gun a bhith ag adhbhrachadh mòran de mheata-dàta bloat.
///
/// Tha an trait air a chomharrachadh neo-shàbhailte gus luchd-buileachaidh a chuingealachadh ri arrays meud stèidhichte.
/// Faodaidh neach-cleachdaidh an trait seo gabhail ris gu bheil an dearbh chruth aig luchd-buileachaidh mar chuimhneachan air sreath meud stèidhichte (mar eisimpleir, airson tòiseachadh neo-shàbhailte).
///
///
/// Thoir fa-near gu bheil an traits [`AsRef`] agus [`AsMut`] a `toirt seachad modhan coltach ri chèile airson seòrsachan nach dòcha a bhith nan arrays meud stèidhichte.
/// B `fheàrr le luchd-buileachaidh na traits sin nan àite.
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// Bidh e ag atharrachadh an raon gu sliseag so-ruigsinneach
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// Bidh e ag atharrachadh an raon gu sliseag gluasadach
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// Thill an seòrsa mearachd nuair a dh `fhailicheas tionndadh bho sliseag gu sreath.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // SÀBHAILTEACHD: ceart gu leòr oir rinn sinn cinnteach gu bheil an fhaid a `freagairt
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // SÀBHAILTEACHD: ceart gu leòr oir rinn sinn cinnteach gu bheil an fhaid a `freagairt
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: tha cuid de impls nach eil cho cudromach air an fàgail air falbh gus bloat còd a lughdachadh
// __impl_slice_eq2!{ [A; $N], &'b [B; $N] } __impl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// A `toirt buaidh air coimeas arrays [lexicographically](Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// Cha ghabh na h-innealan bunaiteach a dhèanamh le const generics oir chan eil `[T; 0]` ag iarraidh gun tèid Default a bhuileachadh, agus chan eil taic ri blocaichean impl eadar-dhealaichte airson àireamhan eadar-dhealaichte fhathast.
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// A `tilleadh sreath den aon mheud ri `self`, le gnìomh `f` air a chur an sàs anns gach eileamaid ann an òrdugh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // SÀBHAILTEACHD: tha fios againn gu cinnteach gun toir an iterator seo `N` dìreach
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// 'Zips up' dà arrays ann an aon sreath de chàraidean.
    ///
    /// `zip()` a `tilleadh sreath ùr far a bheil a h-uile eileamaid na tuple far a bheil a` chiad eileamaid a `tighinn bhon chiad sreath, agus an dàrna eileamaid a` tighinn bhon dàrna sreath.
    ///
    /// Ann am faclan eile, bidh e a `cuairteachadh dà arra còmhla, gu aon fhear.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // SÀBHAILTEACHD: tha fios againn gu cinnteach gun toir an iterator seo `N` dìreach
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// A `tilleadh sliseag anns a bheil an raon iomlan.Co-ionann ri `&s[..]`.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// A `tilleadh sliseag gluasadach anns a bheil an raon iomlan.
    /// Co-ionann ri `&mut s[..]`.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// A `faighinn iasad de gach eileamaid agus a` tilleadh sreath de dh `iomraidhean leis an aon mheud ri `self`.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// Tha an dòigh seo gu sònraichte feumail ma thèid a chur còmhla ri modhan eile, leithid [`map`](#method.map).
    /// San dòigh seo, faodaidh sibh a sheachnadh a 'gluasad a' chiad ordugh ma tha a h-eileamaidean nach eil `Copy`.
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // Faodaidh sinn fhathast faighinn chun t-sreath tùsail: cha deach a ghluasad.
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // SÀBHAILTEACHD: tha fios againn gu cinnteach gun toir an iterator seo `N` dìreach
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// A `faighinn iasad de gach eileamaid gu siùbhlach agus a` tilleadh sreath de dh `iomraidhean gluasadach leis an aon mheud ri `self`.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // SÀBHAILTEACHD: tha fios againn gu cinnteach gun toir an iterator seo `N` dìreach
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// A `tarraing nithean `N` bho `iter` agus gan toirt air ais mar sreath.
/// Ma bheir an iterator toradh nas lugha na nithean `N`, bidh an gnìomh seo a `nochdadh giùlan neo-mhìnichte.
///
///
/// Faic [`collect_into_array`] airson tuilleadh fiosrachaidh.
///
/// # Safety
///
/// Tha e an urra ris an neach-fòn gealltainn gum bi `iter` a `toirt a-mach co-dhiù nithean `N`.
/// Tha briseadh an t-suidheachaidh seo ag adhbhrachadh giùlan neo-mhìnichte.
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: Tha `TrustedLen` an seo beagan de dheuchainn.Chan eil an seo ach
    // gnìomh taobh a-staigh, mar sin faodaidh tu a thoirt air falbh ma tha an ceangal seo a `tionndadh a-mach mar dhroch bheachd.
    // Anns a `chùis sin, cuimhnich gun cuir thu air falbh an `debug_assert!` le ceangal ìosal gu h-ìosal!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // SÀBHAILTEACHD: air a chòmhdach leis a `chùmhnant gnìomh.
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// A `tarraing nithean `N` bho `iter` agus gan toirt air ais mar sreath.Ma bheir an iterator toradh nas lugha na nithean `N`, thèid `None` a thilleadh agus thèid a h-uile rud a chaidh a thoirt a-mach mu thràth a leigeil seachad.
///
/// Leis gu bheil an iterator air a thoirt seachad mar iomradh gluasadach agus gu bheil an gnìomh seo a `gairm `next` aig a` mhòr-chuid de amannan `N`, faodar an iterator a chleachdadh fhathast às deidh sin gus na nithean a tha air fhàgail fhaighinn air ais.
///
///
/// Ma bhriseas `iter.next()`, thèid a h-uile rud a thug an itealaiche a-mach mu thràth a leigeil seachad.
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // SÀBHAILTEACHD: Tha àite falamh an-còmhnaidh ann an raon falamh agus chan eil invariants dligheachd ann.
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // SÀBHAILTEACHD: cha bhi anns an t-sliseag amh seo ach nithean tùsail.
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // SÀBHAILTEACHD: Bidh `guard.initialized` a `tòiseachadh aig 0, air a mheudachadh le aon anns an
        // lùb agus thèid an lùb a ghearradh nuair a ruigeas e N (is e sin `array.len()`).
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // Thoir sùil air an deach an raon iomlan a thòiseachadh.
        if guard.initialized == N {
            mem::forget(guard);

            // SÀBHAILTEACHD: tha an suidheachadh gu h-àrd ag ràdh gu bheil na h-eileamaidean uile
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // Cha ruigear seo a-mhàin ma tha an iterator sgìth mus ruig `guard.initialized` `N`.
    //
    // Thoir fa-near cuideachd gu bheil `guard` air a leigeil sìos an seo, a `leigeil às na h-eileamaidean a chaidh a thòiseachadh mar-thà.
    None
}