//! Is e seo modal a-staigh air a chleachdadh leis an ifmt!runtime.Tha na structaran sin air an cur a-mach gu arrays statach gu sreangan cruth precompile air thoiseach air an àm.
//!
//! Tha iad seo na mìneachaidhean a tha coltach ri cuid `ct` co-ionnanachdan, ach eadar-dhealaichte ann a sin faodar statically riarachadh agus tha beagan nas freagarraiche dha na runtime
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Co-thaobhadh a dh `fhaodadh a bhith air iarraidh mar phàirt de stiùireadh cruth.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Chomharra a th 'ann a bu chòir a bhith air an làimh chlì-rèir a chèile.
    Left,
    /// Comharradh gum bu chòir susbaint a bhith air a cho-thaobhadh gu ceart.
    Right,
    /// Comharradh gum bu chòir susbaint a bhith sa mheadhan.
    Center,
    /// Cha deach co-thaobhadh sam bith iarraidh.
    Unknown,
}

/// Air a chleachdadh le luchd-sònrachaidh [width](https://doc.rust-lang.org/std/fmt/#width) agus [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Ainmichte le litireil àireamh, Stores an luach
    Is(usize),
    /// Air a shònrachadh le bhith a `cleachdadh co-aontaran `$` agus `*`, bidh e a` stòradh a `chlàr-amais gu `args`
    Param(usize),
    /// Gun sònrachadh
    Implied,
}