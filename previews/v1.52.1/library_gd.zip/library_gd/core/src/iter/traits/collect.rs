/// Conversion bho [`Iterator`].
///
/// Le buileachadh `FromIterator` airson seòrsa, tha thu a 'mìneachadh mar a thèid a chruthachadh bho iterator.
/// Tha seo cumanta airson seòrsachan a tha a `toirt cunntas air cruinneachadh de sheòrsa air choreigin.
///
/// [`FromIterator::from_iter()`] 'S e ainneamh a ghairm gu follaiseach, agus tha e air a chleachdadh an àite tro [`Iterator::collect()`] dòigh.
///
/// Faic sgrìobhainnean [`Iterator::collect()`]'s airson tuilleadh eisimpleirean.
///
/// Faic cuideachd: [`IntoIterator`].
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Cleachdadh [`Iterator::collect()`] a-dhìreach a 'cleachdadh `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Buileachadh `FromIterator` airson ur-seòrsa:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Cruinneachadh sampall, is e sin dìreach pasgain thairis air Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Bheir sinn beagan dhòighean dha gus an urrainn dhuinn aon a chruthachadh agus rudan a chur ris.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // agus bidh sinn a 'cur an gnìomh FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // A-nis is urrainn dhuinn iterator ùr a dhèanamh ...
/// let iter = (0..5).into_iter();
///
/// // ... agus a 'dèanamh a-mach às MyCollection
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // cruinnich obraichean cuideachd!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// A `cruthachadh luach bho iterator.
    ///
    /// Faic an [module-level documentation] airson tuilleadh.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Tionndadh a-steach don [`Iterator`].
///
/// Le bhith a `buileachadh `IntoIterator` airson seòrsa, bidh thu a` mìneachadh mar a thèid a thionndadh gu iterator.
/// Tha seo cumanta airson seòrsachan a tha a `toirt cunntas air cruinneachadh de sheòrsa air choreigin.
///
/// Is e aon bhuannachd de bhith a `buileachadh `IntoIterator` gum bi an seòrsa agad [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Faic cuideachd: [`FromIterator`].
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Buileachadh `IntoIterator` airson ur-seòrsa:
///
/// ```
/// // Cruinneachadh sampall, is e sin dìreach pasgain thairis air Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Bheir sinn beagan dhòighean dha gus an urrainn dhuinn aon a chruthachadh agus rudan a chur ris.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // agus bidh sinn a 'cur an gnìomh IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // A-nis faodaidh sinn ùr a dhèanamh chruinneachadh seo ...
/// let mut c = MyCollection::new();
///
/// // ... cuir beagan stuth ris ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... agus an uairsin tionndaidh gu Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Tha e cumanta a bhith a 'cleachdadh `IntoIterator` mar trait bound.Seo a 'leigeil an taic a chruinneachadh airson an seòrsa atharrachadh, cho fad' sa tha e fhathast an iterator.
/// Faodar crìochan a bharrachd a shònrachadh le bhith a `cuingealachadh
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// An seòrsa de na h-eileamaidean air an ath-aithris.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Dè an seòrsa iterator tha sinn a 'tionndadh seo a-steach?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// A 'cruthachadh an iterator bho luach.
    ///
    /// Faic an [module-level documentation] airson tuilleadh.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Leudachadh a chruinneachadh leis na th 'ann de iterator.
///
/// Iterators dèanamh sreath de luachan, agus cruinneachaidhean cuideachd a bhith a 'smaoineachadh mar shreath de luachan.
/// Tha `Extend` trait drochaidean beàrn seo, a 'leigeil thu a leudachadh le bhith a' cruinneachadh a 'gabhail a th' air a sin iterator.
/// Nuair a bha a 'leudachadh chruinneachadh le cheana key, a-steach ùrachadh no, ann an cùis-chruinneachaidhean a leigeas ioma-inntrigidhean le co-ionann iuchraichean, a tha inntrigeadh air a chur a-steach.
///
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// // Faodaidh tu a leudachadh String le cuid chars:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// A `buileachadh `Extend`:
///
/// ```
/// // Cruinneachadh sampall, is e sin dìreach pasgain thairis air Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Bheir sinn beagan dhòighean dha gus an urrainn dhuinn aon a chruthachadh agus rudan a chur ris.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // bho MyCollection tha liosta de i32s, tha sinn airson a chur an gnìomh Leudachadh i32
/// impl Extend<i32> for MyCollection {
///
///     // 'S e seo beagan nas sìmplidh le concrait seòrsa ainm-sgrìobhte: faodaidh sinn ghairm leudachadh air rud sam bith a dh'fhaodas a bhith thionndaidh an Iterator a tha a' toirt dhuinn i32s.
///     // Leis gu feum sinn i32an a chuir a-steach do MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Tha cur an gnìomh e glè neo-fhillte: lùb tro iterator, agus add() gach eileamaid fhìn.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // leig a 'leudachadh ar n-chruinneachadh le trì tuilleadh àireamhan
/// c.extend(vec![1, 2, 3]);
///
/// // tha sinn air na h-eileamaidean sin a chuir ris aig an deireadh
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// A `leudachadh cruinneachadh le susbaint iterator.
    ///
    /// Mar seo an aon dòigh a tha a dhìth airson seo trait, an [trait-level] Docs tha tuilleadh fiosrachaidh.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// // Faodaidh tu a leudachadh String le cuid chars:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// A 'sìneadh a chruinneachadh le dìreach aon eileamaid.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Tèarmainn comas ann a chruinneachadh airson a thoirt seachad grunn eileamaidean a bharrachd.
    ///
    /// The default buileachadh a 'dèanamh dad.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}