/// An iterator daonnan a 'leantainn a' geilleadh `None` nuair sgìth.
///
/// Calling ath air an suaineadh iterator a tha air a thill `None` aon uair a tha an urras gu tilleadh [`None`] a-rithist.
/// Tha seo a 'trait bu chòir a chur an gnìomh a rèir a h-uile iterators a ghiùlanas dòigh seo oir tha e a' toirt cothrom as [`Iterator::fuse()`].
///
///
/// Note: Anns a 'chumantas, cha bu chòir dhuibh a' cleachdadh `FusedIterator` ann coitcheann crìochan ma dh'fheumas tu a suaineadh iterator.
/// An àite sin, bu chòir dhut dìreach a ghairm [`Iterator::fuse()`] air an iterator.
/// Ma tha a 'suaineadh iterator mar-thà, a bharrachd [`Fuse`] còmhdach bi sam bith-op agus chan eil coileanadh peanais.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Reultair a bhios ag aithris faid cheart le bhith a `cleachdadh size_hint.
///
/// Tha iterator aithris mheud blasad far a bheil e an dara cuid dearbh (Lower cheangail a tha co-ionnan ri àrda cheangail), no na h-àrd a tha a 'dol [`None`].
///
/// Tha ceann shuas na ceangail a dh'fheumas a bhith ann ach ma [`None`] na fìor iterator dh'fhaid a tha nas motha na [`usize::MAX`].
/// Anns a `chùis sin, feumaidh an ceangal as ìsle a bhith [`usize::MAX`], a` leantainn gu [`Iterator::size_hint()`] de `(usize::MAX, None)`.
///
/// Feumaidh an iterator an dearbh àireamh de eileamaidean a rinn e aithris no a dhol air adhart mus ruig e an deireadh.
///
/// # Safety
///
/// Feumaidh seo trait a-mhàin a chur an gnìomh nuair a tha an cùmhnant a tha a 'cumail suas.
/// Feumaidh luchd-cleachdaidh an trait seo sgrùdadh a dhèanamh air [`Iterator::size_hint()`]’s àrd-cheangal.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Ath-aithrisiche nuair a bheir thu a-mach nì bidh e air co-dhiù aon eileamaid a thoirt bhon [`SourceIter`] bunaiteach aige.
///
/// Calling dòigh sam bith a tha ag adhartachadh iterator, me
/// [`next()`] no [`try_fold()`], barantasan sin airson gach ceum co-dhiù aon luach na iterator a 'bhun-tùs a bhith air a gluasad a-mach agus an thoradh air an iterator slabhraidh dh'fhaodadh a bhith air a chur na àite, gabhail ris structarail cuingealachaidhean an tùs leigeil le a leithid sin de insertion.
///
/// Ann am faclan eile tha an trait seo a `nochdadh gum faodar loidhne-phìoban iteachaidh a chruinneachadh na àite.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}