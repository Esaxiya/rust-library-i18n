use crate::ops::{ControlFlow, Try};

/// An iterator comasach air toradh eileamaidean bho gach ceann.
///
/// Tha rudeigin a tha a `cur an gnìomh `DoubleEndedIterator` le aon chomas a bharrachd air rudeigin a tha a` buileachadh [`Iterator`]: an comas cuideachd `Nì` a thoirt bhon chùl, a bharrachd air an aghaidh.
///
///
/// Tha e cudromach cuimhneachadh gu bheil an dà chuid air ais agus a mach air an aon raon, agus nach eil a 'chrois: chuairt e thairis nuair a bhios iad a' coinneachadh anns a 'mheadhan.
///
/// San aon dòigh ris a `phròtacal [`Iterator`], aon uair` s gu bheil `DoubleEndedIterator` a `tilleadh [`None`] bho [`next_back()`], le bhith ga ghairm a-rithist is dòcha nach till e [`Some`] a-rithist.
/// [`next()`] agus [`next_back()`] tha interchangeable airson an adhbhair seo.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Falbh agus a 'tilleadh an eileamaid bho cheann an iterator.
    ///
    /// TILLEADH `None` nuair nach eil tuilleadh eileamaidean.
    ///
    /// Tha [trait-level] Docs tha tuilleadh fiosrachaidh.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Tha eileamaidean a fhuair le `DoubleEndedIterator` aig Faodar dòighean eadar-dhealaichte bhon fheadhainn a fhuair le [`Iterator`] 's dhòighean:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Àrdaichidh an iterator bho ais le `n` eileamaidean.
    ///
    /// `advance_back_by` an dreach eile de [`advance_by`].Tha an dòigh seo bidh fiughair skip `n` eileamaidean a 'tòiseachadh bhon ais le bhith a' gairm [`next_back`] suas ri `n` amannan gus [`None`] Tha e a thachair.
    ///
    /// `advance_back_by(n)` tillidh [`Ok(())`] ma shoirbhicheas leis an itealaiche le eileamaidean `n`, no [`Err(k)`] ma thachras [`None`], far a bheil `k` mar an àireamh de eileamaidean a thèid an iterator air adhart mus ruith e a-mach à eileamaidean (ie.
    /// fad an iterator).
    /// Cuimhnich gur `k` e an-còmhnaidh nas lugha na `n`.
    ///
    /// Calling `advance_back_by(0)` Chan eil sgriosaidh sam bith eileamaidean agus an-còmhnaidh a 'tilleadh [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // Chaidh leum a-mhàin `&3`
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// A `tilleadh an eileamaid` n`th bho dheireadh an iterator.
    ///
    /// 'S e seo an ìre mhath an thionndadh dreach de [`Iterator::nth()`].
    /// Ged a tha e coltach ris a `mhòr-chuid de ghnìomhachd clàr-amais, bidh an cunntadh a` tòiseachadh bho neoni, agus mar sin bidh `nth_back(0)` a `tilleadh a` chiad luach bhon deireadh, `nth_back(1)` an dàrna fear, agus mar sin air adhart.
    ///
    ///
    /// Thoir fa-near gun tèid na h-eileamaidean uile eadar an deireadh agus an eileamaid a chaidh a thilleadh a chaitheamh, a `toirt a-steach an eileamaid a chaidh a thilleadh.
    /// Tha seo cuideachd a `ciallachadh gun till `nth_back(0)` iomadach uair air an aon iterator diofar eileamaidean.
    ///
    /// `nth_back()` Tillidh [`None`] ma `n` nas mò na, no co-ionnan ri fad an iterator.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Calling `nth_back()` ioma amannan Chan eil an ais iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// A `tilleadh `None` ma tha nas lugha na eileamaidean `n + 1` ann:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// 'S e seo cùlaibh de dreach [`Iterator::try_fold()`]: bheir e eileamaidean a' tòiseachadh bho cùl na iterator.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Seach gur e geàrr-circuited, air fhàgail-eileamaidean a tha fhathast ri fhaighinn tro iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// An iterator dòigh a lùghdaicheas a 'iterator aig eileamaidean gu aon, luach mu dheireadh, a' tòiseachadh bhon ais.
    ///
    /// 'S e seo cùlaibh de dreach [`Iterator::fold()`]: bheir e eileamaidean a' tòiseachadh bho cùl na iterator.
    ///
    /// `rfold()` a `gabhail dà argamaid: luach tùsail, agus dùnadh le dà argamaid: an 'accumulator', agus eileamaid.
    /// Bidh an dùnadh a `tilleadh an luach a bu chòir a bhith aig an cruinneadair airson an ath thionndadh.
    ///
    /// Tha a 'chiad luach an luach an cruinneachaidh a bhios air a' chiad ghairm.
    ///
    /// An dèidh cur a-steach seo a dhùnadh a h-uile eileamaid de iterator, `rfold()` thilleas cruinneachaidh.
    ///
    /// Tha an iomairt seo ris an canar uaireannan 'reduce' no 'inject'.
    ///
    /// Pasgadh a tha feumail nuair a tha thu a 'chruinneachadh de rudeigin, agus ag iarraidh a thoirt gu buil aon luach às.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // an t-sùim uile de na h-eileamaidean de
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// An eisimpleir seo a 'togail sreang, a' tòiseachadh leis a 'chiad luach agus a' cumail ri gach eileamaid bho ais gus am aghaidh:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// A `sireadh eileamaid de itealaiche bhon chùl a tha a` sàsachadh ro-innse.
    ///
    /// `rfind()` a 'gabhail a dhùnadh gun tilleadh `true` no `false`.
    /// Tha ea 'buntainn seo a dhùnadh do gach eileamaid de iterator, a' tòiseachadh aig an deireadh, agus ma tha gin dhiubh a 'tilleadh `true`, agus an uair sin a' tilleadh `rfind()` [`Some(element)`].
    /// Ma tha iad uile a 'tilleadh `false`, tha e a' tilleadh [`None`].
    ///
    /// `rfind()` tha geàrr-chuairteach;ann am faclan eile, bidh e stad a chur air a 'giollachd cho luath' sa 'dùnadh a' tilleadh `true`.
    ///
    /// Leis gu bheil `rfind()` a `toirt iomradh, agus gu bheil mòran de itealain ag itealaich thairis air iomraidhean, tha seo a` leantainn gu suidheachadh a dh `fhaodadh a bhith troimh-chèile far a bheil an argamaid na iomradh dùbailte.
    ///
    /// Chì thu a 'bhuaidh seo ann an eisimpleirean gu h-ìosal, le `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Stad aig a 'chiad `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // faodaidh sinn fhathast `iter` a chleachdadh, oir tha barrachd eileamaidean ann.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}