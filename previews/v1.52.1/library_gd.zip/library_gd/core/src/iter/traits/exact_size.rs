/// An iterator gu bheil fios aig a dearbh dh'fhaid.
///
/// Tha mòran [`Iterator`] s nach eil fios cia mheud uair a bhios iad ag itealaich, ach bidh cuid a` dèanamh.
/// Ma tha iterator fios cia mheud amannan faodaidh e iterate, a 'toirt cothrom air an fhiosrachadh sin a dh'fhaodas a bhith feumail.
/// Mar eisimpleir, ma bhios thu airson iterate ais, air tòiseachadh math a tha fios agad far an deireadh.
///
/// Nuair a chuireas tu `ExactSizeIterator` an gnìomh, feumaidh tu [`Iterator`] a chuir an gnìomh cuideachd.
/// Nuair a nì thu sin, feumaidh buileachadh [`Iterator::size_hint`]* * meud dìreach an iterator a thilleadh.
///
/// Tha [`len`] dòigh a tha bunaiteach a chur an gnìomh, mar sin, mar as trice cha bu chòir a chur an gnìomh.
/// Ach, dh `fhaodadh gum bi e comasach dhut buileachadh nas coileanta a thoirt seachad na an àbhaist, mar sin tha a bhith a` dol thairis air sa chùis seo a `dèanamh ciall.
///
///
/// Cuimhnich gur e seo trait sàbhailte trait agus mar sin a 'dèanamh cha * **agus nach urrainn* barantas gun thill dh'fhaid a tha ceart.
/// Tha seo a 'ciallachadh gu bheil `unsafe` code **Chan fhaod** crochadh air na ceart [`Iterator::size_hint`].
/// Tha neo-sheasmhach agus sàbhailte [`TrustedLen`](super::marker::TrustedLen) trait a 'toirt barantas a bharrachd seo.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// // a crìochnach raon fios le cinnt cia mheud uair a bhios e iterate
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Ann an [module-level docs], chuir sinn an gnìomh an [`Iterator`], `Counter`.
/// Feuch an cuir sinn `ExactSizeIterator` an gnìomh air a shon cuideachd:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Tha sinn a 'Is urrainn dhut obrachadh a-mach an àireamh de iterations fhàgail.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Agus a nis faodaidh sinn ga cleachdadh!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// A `tilleadh an fhìor fhaid a tha an iterator.
    ///
    /// Tha cur an gnìomh a 'dèanamh cinnteach gu bheil iterator till dìreach `len()` tuilleadh tursan [`Some(T)`] luach, mus do thill [`None`].
    ///
    /// Tha an dòigh seo a tha bunaiteach a chur an gnìomh, mar sin, mar as trice cha bu chòir a chur an gnìomh dìreach.
    /// Ach, mas urrainn dhut buileachadh nas èifeachdaiche a thoirt seachad, faodaidh tu sin a dhèanamh.
    /// Faic na docaichean [trait-level] mar eisimpleir.
    ///
    /// Tha a 'ghnìomh seo an aon sàbhailteachd bharantasan mar an [`Iterator::size_hint`] gnìomh.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// // a crìochnach raon fios le cinnt cia mheud uair a bhios e iterate
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Tha seo a 'tagradh' S e ro dìon, ach tha e a 'cumail sùil air invariant
        // a ghealltainn le trait.
        // Nam biodh an trait seo rust-a-staigh, dh `fhaodadh sinn debug_assert a chleachdadh!;assert_eq!Thèid sùil a h-uile neach-cleachdaidh Rust implementations cuideachd.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Tilleadh `true` ma tha an iterator falamh.
    ///
    /// Tha buileachadh bunaiteach aig an dòigh seo a `cleachdadh [`ExactSizeIterator::len()`], mar sin cha leig thu leas a chuir an gnìomh thu fhèin.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}