// leig seachad an-sgiobalta-filelength fhaidhle seo cha mhòr a-mhàin air a dhèanamh suas air a 'mhìneachadh `Iterator`.
// Chan urrainn dhuinn sin a roinn ann an grunn fhaidhlichean.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// An eadar-aghaidh airson dèiligeadh ri iterators.
///
/// Is e seo am prìomh iterator trait.
/// Airson tuilleadh fiosrachaidh mu na bun-bheachd iterators fharsaingeachd, faicibh an [module-level documentation].
/// Gu sònraichte, faodaidh sibh fios agad mar a [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// An seòrsa de na h-eileamaidean air an ath-aithris.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Àrdaichidh an iterator agus a 'tilleadh an ath luach.
    ///
    /// TILLEADH [`None`] chuairt nuair a tha deiseil.
    /// Fa leth iterator implementations Faodaidh cuairt air ais, agus mar sin a 'gairm a-rithist `next()` Dh'fhaodadh gun tèid no nach eil a' cheann thall a 'tòiseachadh a' tilleadh a-rithist [`Some(Item)`] aig àm air choreigin.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Bidh gairm gu next() a `tilleadh an ath luach ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... agus an uair sin aon uair None e thairis.
    /// assert_eq!(None, iter.next());
    ///
    /// // Is dòcha gun till barrachd ghairmean `None`.An seo, bidh iad an-còmhnaidh.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// TILLEADH crìochan air fhàgail fad an iterator.
    ///
    /// Gu sònraichte, bidh `size_hint()` a `tilleadh tuple far a bheil a` chiad eileamaid aig a `cheangal as ìsle, agus an dàrna eileamaid aig a` mhullach àrd.
    ///
    /// Tha an dàrna leth den tuple a tha a thill e an [`Option`]`<`[`usize`] `>`.
    /// A [`None`] seo a 'ciallachadh gu bheil an dara cuid nach eil aithnichte h-àrd a' dol, no na h-àrd a 'dol nas motha na [`usize`].
    ///
    /// # Notaichean buileachaidh
    ///
    /// Chan eil e air a chur an gnìomh gu bheil iterator buileachadh faighear an cèill grunn eileamaidean.A bugaidh iterator dòcha geilleadh nas lugha na b 'ìsle a' dol no barrachd de na h-àrd a 'dol eileamaidean.
    ///
    /// `size_hint()` motha a tha an dùil a chleachdadh airson optimizations mar àite airson a 'glèidheadh na h-eileamaidean de na iterator, ach feumaidh nach biodh earbsa gu me, a' fàgail às crìochan sgrùdaidhean ann an còd sàbhailte.
    /// An ceàrr a chur an gnìomh `size_hint()` Cha bu chòir leantainn air adhart gu memory sàbhailteachd bhrisidhean.
    ///
    /// Sin a ràdh, air cur an gnìomh a bu chòir a thoirt seachad ceart mheas, oir a chaochladh biodh e bhriseas an trait a 'ghnàths.
    ///
    /// The default buileachadh a 'tilleadh `(0,` [`None`]`)`a tha ceart airson sam bith iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Eisimpleir nas toinnte:
    ///
    /// ```
    /// // Tha fiù 's na h-àireamhan bho neoni gu deich.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Tha sinn a dh'fhaodadh iterate bho neoni gu deich uairean.
    /// // Bheir eòlas gu bheil e còig dìreach nach biodh e comasach gun a chur gu bàs filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Leigeamaid ris chòig tuilleadh àireamhan le chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // a-nis an dà chuid fàs air a mheudachadh le còig
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// A `tilleadh `None` airson àrd-cheangal:
    ///
    /// ```
    /// // chan eil ceangal àrd aig iterator gun chrìoch agus an ìre as ìsle as urrainn a bhith ann
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Ithe an iterator, a 'cunntadh an àireamh de iterations agus a' tilleadh e.
    ///
    /// Bidh an dòigh seo a `gairm [`next`] a-rithist is a-rithist gus an ruigear [`None`], a` tilleadh an àireamh de thursan a chunnaic e [`Some`].
    /// Cuimhnich gur [`next`] tha gu bhith air ainmeachadh co-dhiù aon uair, fiù 's ma tha an iterator Chan eil eileamaidean sam bith.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Overflow Giùlan
    ///
    /// Chan eil an dòigh seo a `dìon an aghaidh thar-shruth, agus mar sin bidh a bhith a` cunntadh eileamaidean de iterator le barrachd air eileamaidean [`usize::MAX`] an dàrna cuid a `toirt a-mach an toradh ceàrr no panics.
    ///
    /// Ma chanas debug tha an comas, a panic tha seachnadh.
    ///
    /// # Panics
    ///
    /// Dh `fhaodadh an gnìomh seo panic ma tha barrachd air eileamaidean [`usize::MAX`] aig an iterator.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// A `caitheamh an iterator, a` tilleadh an eileamaid mu dheireadh.
    ///
    /// Nì an dòigh seo measadh air an iterator gus an till e [`None`].
    /// Ged a bha a 'dèanamh sin, tha e a' cumail sùil a chumail an-dràsta eileamaid.
    /// An dèidh [`None`] a thilleadh, `last()` Tillidh an eileamaid mu dheireadh a chunnaic e.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// A `toirt air adhart an iterator le eileamaidean `n`.
    ///
    /// Bidh an dòigh seo gu deònach a `sgrìobadh eileamaidean `n` le bhith a` gairm [`next`] suas gu amannan `n` gus an ruigear [`None`].
    ///
    /// `advance_by(n)` tillidh [`Ok(())`][Ok] ma shoirbhicheas leis an itealaiche le eileamaidean `n`, no [`Err(k)`][Err] ma thachras [`None`], far a bheil `k` mar an àireamh de eileamaidean a thèid an iterator air adhart mus ruith e a-mach à eileamaidean (ie.
    /// fad an iterator).
    /// Cuimhnich gur `k` e an-còmhnaidh nas lugha na `n`.
    ///
    /// Calling `advance_by(0)` Chan eil sgriosaidh sam bith eileamaidean agus an-còmhnaidh a 'tilleadh [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // Chaidh leum a-mhàin `&4`
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Thilleas `n`th eileamaid de iterator.
    ///
    /// Coltach ris a 'mhòr chuid a' comharrachadh obair, bha an cunnt a 'tòiseachadh bho neoni, mar sin `nth(0)` a thilleas a' chiad luach, `nth(1)` an dara fear, agus mar sin air.
    ///
    /// Thoir fa-near gum bi na h-eileamaidean roimhe seo, a bharrachd air an eileamaid a chaidh a thilleadh, air an caitheamh bhon iterator.
    /// Tha sin a 'ciallachadh gu bheil an ro-eileamaidean a thèid a thilgeil, agus cuideachd a' gairm `nth(0)` ioma amannan air an aon iterator till diofar eileamaidean.
    ///
    ///
    /// `nth()` Tillidh [`None`] ma `n` nas mò na, no co-ionnan ri fad an iterator.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Cha bhith a `gairm `nth()` iomadach uair ag ath-thionndadh an iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// A `tilleadh `None` ma tha nas lugha na eileamaidean `n + 1` ann:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// A 'cruthachadh an iterator a' tòiseachadh aig an aon àite, ach àtha a thoirt seachad leis an t-suim aig gach cuairt.
    ///
    /// Nota 1: Tha a 'chiad eileamaid de iterator thèid an còmhnaidh a chur air ais, a dh'aindeoin an ceum a thoirt seachad.
    ///
    /// Nota 2: The àm aig a bheil a leigeil seachad eileamaidean a tha air an tarraing nach eil e stèidhichte.
    /// `StepBy` ghiùlan fhèin mar an t-sreath `next(), nth(step-1), nth(step-1),…`, ach tha e cuideachd saor gus iad fhèin a ghiùlan mar an t-sreath
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Dè an t-slighe a chleachdadh a dh'fhaodadh atharrachadh airson cuid iterators airson coileanadh adhbharan.
    /// Tha an dàrna slighe a thèid air adhart agus'sdòcha na bu tràithe iterator sgriosaidh tuilleadh ris.
    ///
    /// `advance_n_and_return_first` 'S e co-ionann:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Tha an dòigh a bhios panic a thoirt seachad ma tha an ceum `0`.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// A `gabhail dà itealaiche agus a` cruthachadh iterator ùr thairis air an dà chuid ann an òrdugh.
    ///
    /// `chain()` Tillidh ùr iterator a bhios a 'chiad iterate còrr is luachan bhon chiad iterator agus an uair sin thairis air luachan bhon dàrna iterator.
    ///
    /// Ann am faclan eile, tha e a `ceangal dà itealaiche còmhla, ann an sreath.🔗
    ///
    /// [`once`] air chleachdadh gu cumanta atharrachadh aon luach a-steach sreath de sheòrsa eile chuairt.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Bhon a chaidh an argamaid gu `chain()` cleachdadh [`IntoIterator`], faodaidh sinn seachad rud sam bith a dh'fhaodas a bhith air atharrachadh gu an [`Iterator`], chan e dìreach an [`Iterator`] fhèin.
    /// Mar eisimpleir, gabhaidh na slisean cur (`&[T]`) [`IntoIterator`] a chur an gnìomh, agus mar sin faodar a chur gu dìreach `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ma tha thu ag obair le Windows API, is dòcha gum bi thu airson [`OsStr`] a thionndadh gu `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips suas' dà iterators a-steach air aon iterator de càraidean.
    ///
    /// `zip()` a `tilleadh itealaiche ùr a bhios ag itealaich thairis air dà itealaiche eile, a` tilleadh tuple far a bheil a `chiad eileamaid a` tighinn bhon chiad itealaiche, agus an dàrna eileamaid a `tighinn bhon dàrna iterator.
    ///
    ///
    /// Ann am briathran eile, tha e zips iterators dithis còmhla, a-steach gu aon.
    ///
    /// Ma thilleas an dàrna itealaiche [`None`], tillidh [`next`] bhon iterator zipped [`None`].
    /// Ma 'chiad iterator tilleadh [`None`], `zip` Bidh geàrr-cuairt agus `next` cha tèid an t-ainm air an dara iterator.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Leis gu bheil an argamaid gu `zip()` a `cleachdadh [`IntoIterator`], is urrainn dhuinn a dhol seachad air rud sam bith a ghabhas atharrachadh gu [`Iterator`], chan e dìreach [`Iterator`] fhèin.
    /// Mar eisimpleir, bidh sliseagan (`&[T]`) a `buileachadh [`IntoIterator`], agus mar sin faodar an toirt seachad gu `zip()` gu dìreach:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` Tha e tric air a chleachdadh gu neo-chrìochnach an zip iterator gu crìochnach aon.
    /// Tha seo ag obrachadh a chionn 'crìochnach iterator a' cheann thall till [`None`], crìoch a zipper.Faodaidh zipping le `(0..)` a bhith a `coimhead gu math coltach ri [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// A 'cruthachadh ùr iterator tha a' cur lethbhreac den `separator` eadar ri taobh ris a 'chiad iterator.
    ///
    /// Ann an cùis a chur an gnìomh `separator` Chan eil [`Clone`] no feumalachdan a bhith air a thomhas a h-uile àm, a 'cleachdadh [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Tha a 'chiad eileamaid bho `a`.
    /// assert_eq!(a.next(), Some(&100)); // An dealaiche.
    /// assert_eq!(a.next(), Some(&1));   // An ath eileamaid bho `a`.
    /// assert_eq!(a.next(), Some(&100)); // An dealaiche.
    /// assert_eq!(a.next(), Some(&2));   // Tha an eileamaid mu dheireadh bho `a`.
    /// assert_eq!(a.next(), None);       // Tha an iterator deiseil.
    /// ```
    ///
    /// `intersperse` Faodaidh e bhith air leth feumail gus pàirt a ghabhail an iterator rudan a 'cleachdadh cumanta eileamaid:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// A 'cruthachadh ùr iterator a tha a' cur a 'phìos chruthachadh le eadar `separator` ri taobh ris a' chiad iterator.
    ///
    /// Thèid an dùnadh a ghairm dìreach aon uair gach uair a thèid nì a chuir eadar dà rud faisg air làimh bhon iterator bunaiteach;
    /// gu sònraichte, a 'dùnadh Chan eil ghairm ma tha am bun-iterator toradh nas lugha na dà nithean agus an dèidh a' phìos mu dheireadh tha Fhuaireadh.
    ///
    ///
    /// Ma tha an iterator a 'phìos innealan [`Clone`], dh'fhaodadh gum bi e nas fhasa a chleachdadh [`intersperse`].
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Tha a 'chiad eileamaid bho `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // An dealaiche.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // An ath eileamaid bho `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // An dealaiche.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Tha an eileamaid mu dheireadh bho `v`.
    /// assert_eq!(it.next(), None);               // Tha an iterator deiseil.
    /// ```
    ///
    /// `intersperse_with` Faodar a chleachdadh ann an suidheachaidhean far a bheil an SEPARATOR dh'fheumas a bhith air a thomhas:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Bidh an dùnadh a `faighinn iasad den cho-theacsa aige gus rud a ghineadh.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// A 'gabhail a dhùnadh agus a' cruthachadh an iterator a tha ag iarraidh gun dùnadh air gach eileamaid.
    ///
    /// `map()` chruth-atharrachadh aon iterator a-steach eile, le bhith a argamaid:
    /// rudeigin a tha a 'buileachadh [`FnMut`].Tha e a 'foillseachadh ùr iterator a tha ag iarraidh seo a dhùnadh air gach eileamaid de thùsail iterator.
    ///
    /// Ma tha sibh math aig a 'smaoineachadh ann an seòrsachan, faodaidh tu smaoineachadh air `map()` mar seo:
    /// Ma tha thu a 'toirt iterator eileamaidean cuid de seòrsa `A`, agus tha sibh ag iarraidh an cuid de iterator seòrsa `B` eile, faodaidh sibh a' cleachdadh `map()`, a 'dol a dhùnadh a bheir an `A` agus a thilleas a `B`.
    ///
    ///
    /// `map()` tha bun-bheachd coltach ri lùb [`for`].Ach, leis gu bheil `map()` leisg, tha e nas fheàrr a chleachdadh nuair a tha thu ag obair le itealain eile mu thràth.
    /// Ma tha thu a `dèanamh seòrsa de lùbadh airson taobh-bhuaidh, thathas den bheachd gu bheil e nas gnàthach [`for`] a chleachdadh na `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ma tha thu a `dèanamh seòrsa de bhuaidh taobh, is fheàrr leat [`for`] gu `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // na dèan seo:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // cha chuir e gu bàs e, oir tha e leisg.Rust a bhios a 'toirt rabhadh dhut mu dheidhinn seo.
    ///
    /// // An àite sin, cleachd airson:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Tha gairmean a dhùnadh air gach eileamaid de iterator.
    ///
    /// Tha seo co-ionnan ri bhith a `cleachdadh lùb [`for`] air an iterator, ged nach eil e comasach `break` agus `continue` a dhùnadh bho dhùnadh.
    /// Tha e trice nas gnàthasach a chleachdadh `for` lùib, ach `for_each` dòcha gum bi barrachd furasta a leughadh nuair a giollachd ris aig deireadh fhaide iterator slabhraidhean.
    ///
    /// Ann an cuid de chùisean `for_each` Dh'fhaodadh cuideachd gum bi e nas luaithe na lùib, oir bidh e a 'cleachdadh taobh a-staigh cuairt air adapters mar `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Airson eisimpleir cho beag, is dòcha gum bi lùb `for` nas glaine, ach is dòcha gum biodh e nas fheàrr `for_each` stoidhle gnìomh a chumail le itealain nas fhaide:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// A 'cruthachadh an iterator a tha a' cleachdadh a dhùnadh gus co-dhùnadh ma eileamaid bu chòir Fhuaireadh.
    ///
    /// Le eileamaid a `dùnadh feumaidh an dùnadh `true` no `false` a thilleadh.Tha thill iterator Bidh geilleadh a-mhàin na h-eileamaidean a tha a 'dùnadh a' tilleadh fìor.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Seach gu bheil a 'dùnadh a-null gu `filter()` a' toirt iomraidh, agus mòran iterators iterate thairis air iomraidhean seo, 's dòcha a' dol gu mì-shoilleireachd eadar-suidheachadh, far a bheil an t-seòrsa a 'dùnadh a tha dùbailte iomraidh air:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // feum air dà * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tha e cumanta a bhith a 'cleachdadh an àite destructuring air an argamaid a dh'fhaobhachadh air falbh aon:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // an dà chuid&agus *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// no an dà chuid:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // dà &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// de na fillidhean sin.
    ///
    /// Cuimhnich gur `iter.filter(f).next()` tha co-ionann ri `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// A 'cruthachadh an iterator sin an dà chuid na criathragan agus mapaichean.
    ///
    /// Tha thill iterator faighear ach an `value`s airson a thug dhùnadh tilleadh `Some(value)`.
    ///
    /// `filter_map` Faodar a chleachdadh gus slabhraidhean de [`filter`] agus [`map`] nas pongaile.
    /// Chaidh an eisimpleir gu h-ìosal a 'sealltainn mar a `map().filter().map()` Faodar a ghiorrachadh gu aon gairm gu `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Seo an aon eisimpleir, ach le [`filter`] agus [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// A 'cruthachadh an iterator a tha a' toirt seachad an-dràsta air chuairt cunntadh a thuilleadh air an ath luach.
    ///
    /// Tha iterator thill toradh càraidean `(i, val)`, far `i` an-dràsta Clàr-ìnnse de chuairt agus `val` an luach a thilleadh leis na iterator.
    ///
    ///
    /// `enumerate()` a `cumail a chunntadh mar [`usize`].
    /// Ma tha thu airson cunntadh le integer de dhiofar mheudan, tha an gnìomh [`zip`] a `toirt seachad gnìomh coltach ris.
    ///
    /// # Overflow Giùlan
    ///
    /// Tha an dòigh a nì sam bith a 'dìon an aghaidh overflows, mar sin, àireamhachd barrachd [`usize::MAX`] eileamaidean an dara cuid a' dèanamh an thoradh ceàrr no panics.
    /// Ma chanas debug tha an comas, a panic tha seachnadh.
    ///
    /// # Panics
    ///
    /// Tha thill iterator dh'fhaodadh panic ma tha an a-Be-thill Clàr-ìnnse bhiodh overflow a [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// A 'cruthachadh an iterator a dh'fhaodas a' cleachdadh [`peek`] gus sùil aig an ath eileamaid de iterator gun caitheamh e.
    ///
    /// A 'cur [`peek`] dòigh gus an iterator.Faic sgrìobhainnean aige airson tuilleadh fiosrachaidh.
    ///
    /// Thoir fa-near gu bheil an iterator bunaiteach fhathast adhartach nuair a thèid [`peek`] a ghairm airson a `chiad uair: Gus an ath eileamaid fhaighinn air ais, canar [`next`] ris an iterator bunaiteach, mar sin fo-bhuaidhean sam bith (ie
    ///
    /// rud sam bith eile seach a dh'iarraidh an ath luach) de [`next`] dòigh a bhios a 'tachairt.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() a 'leigeil fhaicinn dhuinn a-steach dhan future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // is urrainn dhuinn peek() iomadh uair, cha toir an iterator air adhart
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // às deidh an iterator a bhith deiseil, mar sin tha peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// A `cruthachadh itealaiche a bhios [` skip`] s eileamaidean stèidhichte air ro-innse.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` a `dùnadh mar argamaid.Bidh e a 'ghairm seo a dhùnadh air gach eileamaid de iterator, agus leig seachad gus eileamaidean e a' tilleadh `false`.
    ///
    /// An dèidh `false` a thilleadh, `skip_while()`'s Is e an obair thairis, agus an còrr de na h-eileamaidean a tha a fhuair.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Leis gu bheil an dùnadh a chaidh a thoirt do `skip_while()` a `toirt iomradh, agus gu bheil mòran de itealain ag itealaich thairis air iomraidhean, tha seo a` leantainn gu suidheachadh a dh `fhaodadh a bhith troimh-chèile, far a bheil seòrsa na h-argamaid dùnaidh na iomradh dùbailte:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // feum air dà * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// A `stad às deidh `false` tùsail:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Ged a bhiodh seo air a bhith meallta, bho fhuair sinn mar-thà meallta, skip_while() nach eil a chleachdadh tuilleadh
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// A 'cruthachadh an iterator a' meudachadh an toraidh eileamaidean stèidhichte air predicate.
    ///
    /// `take_while()` a 'gabhail a dhùnadh mar argamaid.Bidh e a 'ghairm seo a dhùnadh air gach eileamaid de iterator, agus geilleadh eileamaidean fhad' sa bha e a 'tilleadh `true`.
    ///
    /// An dèidh `false` a thilleadh, `take_while()`'s Is e an obair thairis, agus an còrr de na h-eileamaidean a tha a leigeil seachad.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Seach gu bheil a 'dùnadh a-null gu `take_while()` a' toirt iomraidh, agus mòran iterators iterate thairis air iomraidhean seo, 's dòcha a' dol gu mì-shoilleireachd eadar-suidheachadh, far a bheil an t-seòrsa a 'dùnadh a tha dùbailte iomraidh air:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // feum air dà * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// A `stad às deidh `false` tùsail:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Feumaidh sinn barrachd eileamaidean a tha nas lugha na neoni, ach bhon a fhuair sinn mar-thà meallta, take_while() nach eil a chleachdadh tuilleadh
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Leis gum feum `take_while()` sùil a thoirt air an luach gus faicinn am bu chòir a thoirt a-steach no nach bu chòir, chì luchd-iteachaidh caitheamh gun tèid a thoirt air falbh:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Chan eil an `3` ann tuilleadh, oir chaidh a chaitheamh gus faicinn am bu chòir don itealadh stad, ach cha deach a chuir air ais san iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// A `cruthachadh iterator a bheir an dà chuid eileamaidean stèidhichte air predicate agus mapaichean.
    ///
    /// `map_while()` a 'gabhail a dhùnadh mar argamaid.
    /// Bidh e a 'ghairm seo a dhùnadh air gach eileamaid de iterator, agus geilleadh eileamaidean fhad' sa bha e a 'tilleadh [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Seo an aon eisimpleir, ach le [`take_while`] agus [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Cur stad dèidh a 'chiad [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Tha barrachd eileamaidean againn a dh `fhaodadh a bhith a` freagairt ann an u32 (4, 5), ach thill `map_while` `None` airson `-3` (mar a thill an `predicate` `None`) agus stad `collect` aig a `chiad `None` ris an do thachair thu.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Seach `map_while()` Feumaidh a 'coimhead air an luach ann an òrdugh a dh'fhaicinn bu chòir a ghabhail a-steach no nach eil, bidh luchd-iterators fhaicinn gu bheil e air a thoirt às:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Tha `-3` chan eil an sin, oir chaidh a chaitheamh ann an òrdugh a dh'fhaicinn an cuairt bu chòir stad a chur air, ach cha deach a chur air ais dhan iterator.
    ///
    /// Cuimhnich gur eu-coltach [`take_while`] seo iterator e **nach 'eil** suaineadh.
    /// Chan eil e cuideachd air a shònrachadh dè an iterator seo a thilleas às deidh a `chiad [`None`] a thilleadh.
    /// Ma tha feum agad air iterator fuaichte, cleachd [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// A 'cruthachadh an iterator a skips a' chiad `n` eileamaidean.
    ///
    /// Às deidh dhaibh a bhith air an caitheamh, gheibhear an còrr de na h-eileamaidean.
    /// An àite a bhith a `toirt thairis air an dòigh seo gu dìreach, an àite sin a` dol thairis air an dòigh `nth`.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// A `cruthachadh iterator a bheir a-mach a chiad eileamaidean `n`.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` Tha e tric air a chleachdadh le neo-chrìochnach iterator, gus a dhèanamh crìochnach:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ma tha nas lugha na `n`-eileamaidean a tha ri fhaotainn, `take` bacadh fhèin ri meud na bhun-iterator:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// An iterator adapter coltach ri [`fold`] a cumail taobh a-staigh na stàite agus a 'dèanamh ùr iterator.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` a 'gabhail dà-argamaidean: an toiseach luach a tha a' sìol an taobh a-staigh na stàite, agus a 'dùnadh le dà-argamaidean, a' chiad a bhith mutable iomradh air an taobh a-staigh na stàite agus an dàrna iterator an eileamaid.
    ///
    /// Faodaidh dùnadh a shònrachadh taobh a-staigh na stàite gu stàite roinn eadar iterations.
    ///
    /// Nuair a thèid e a-rithist, thèid an dùnadh a chuir an sàs anns gach eileamaid den itealaiche agus gheibhear an luach toraidh bhon dùnadh, [`Option`], leis an iterator.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // gach ite, bidh sinn ag iomadachadh na stàite leis an eileamaid
    ///     *state = *state * x;
    ///
    ///     // an uair sin, bidh sinn a 'ciallachadh negation na stàite
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// A 'cruthachadh an iterator a tha ag obair mar map, ach flattens neadaichte structar.
    ///
    /// Tha [`map`] adapter gu math feumail, ach a-mhàin nuair a dhùin a 'dèanamh argamaid luachan.
    /// Ma tha e a 'foillseachadh an iterator àite a tha sin, a bharrachd còmhdach de indirection.
    /// `flat_map()` Thèid seo a thoirt às filleadh a bharrachd air fhèin.
    ///
    /// Faodaidh tu smaoineachadh air `flat_map(f)` mar an Semantic co-ionann aig [`map`] ping, agus an uair sin [`flatten`] ing mar ann `map(f).flatten()`.
    ///
    /// Another dòigh smaoineachaidh mu `flat_map()`: [`map`] 's air an dùnadh a thilleas aon chuspair airson gach eileamaid, agus `flat_map()`'s dhùnadh tilleadh an iterator airson gach eileamaid.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() a 'tilleadh an iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// A 'cruthachadh an iterator a flattens neadaichte structar.
    ///
    /// Tha seo feumail, nuair a tha agad an iterator de iterators no iterator de rudan a dh'fhaodas a bhith air thionndadh 'steach iterators agus tha sibh ag iarraidh a thoirt air falbh aon ìre indirection.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Mapadh agus an uair sin a 'spadadh:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() a 'tilleadh an iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Faodaidh tu cuideachd ath-sgrìobhadh seo a thaobh [`flat_map()`], a tha na b 'fheàrr sa chùis seo bho' cur an cèill gu soilleir barrachd rùn:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() a 'tilleadh an iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Spadadh a-mhàin air falbh, an aon ìre de neadachadh aig àm:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// An seo chì sinn nach eil `flatten()` a `coileanadh flat "deep".
    /// An àite sin, ach an aon ìre de neadachaidh a thoirt air falbh.'S e sin, ma tha thu `flatten()` trì-thaobhach ordugh, thoradh bidh dà-thaobhach agus nach aon-thaobhach.
    /// Airson faighinn a-aon-thaobhach structar, tha agad ri `flatten()` a-rithist.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// A 'cruthachadh an iterator a' crìochnachadh an dèidh a 'chiad [`None`].
    ///
    /// An dèidh an iterator tilleadh [`None`], future gairmean Dh'fhaodadh gun tèid no nach geilleadh [`Some(T)`] a-rithist.
    /// `fuse()` ag atharrachadh an iterator, dèanamh cinnteach gu bheil an dèidh [`None`] a thoirt seachad, bidh e an còmhnaidh a 'tilleadh [`None`] gu bràth.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// // iterator a bhios ag atharrachadh eadar cuid agus gin
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // ma tha e fiù 's, Some(i32), gin eile
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // chì sinn ar iterator a 'dol air ais agus a mach
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // Ach, aon uair 'tha sinn a leagh e ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // bidh e an-còmhnaidh a 'tilleadh `None` an dèidh a' chiad uair.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// A bheil rudeigin le gach eileamaid de iterator, a 'dol seachad air an luach air.
    ///
    /// Nuair a chleachdas iterators, bidh tu gu tric Chain grunn dhiubh còmhla.
    /// Nuair a bhios tu ag obair air a leithid de chòd, is dòcha gum bi thu airson faighinn a-mach dè a tha a `tachairt aig diofar phàirtean den loidhne-phìoban.Gus sin a dhèanamh, cuir a-steach a ghairm gu `inspect()`.
    ///
    /// Tha e nas cumanta gum bi `inspect()` air a chleachdadh mar inneal deasbaid na bhith anns a `chòd mu dheireadh agad, ach dh` fhaodadh gum biodh e feumail do thagraidhean ann an suidheachaidhean sònraichte nuair a dh `fheumar mearachdan a chlàradh mus tèid an leigeil seachad.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // seo iterator an òrdugh iom-fhillte.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // leig dhuinn cuid de ghlaodhan inspect() a chuir ris gus sgrùdadh a dhèanamh air na tha a `tachairt
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Thèid seo a chlò-bhualadh:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Logadh mearachdan a 'tilgeil às dhaibh mus:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Thèid seo a chlò-bhualadh:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Iasad an iterator, seach a bhith a 'caitheamh e.
    ///
    /// Tha seo feumail gus leigeil le bhith a 'cur iterator adapters fhad' sa bha fhathast a 'gleidheadh sealbh air a' chiad iterator.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // ma tha sinn a 'feuchainn ri cleachdadh iter a-rithist, cha toir e ag obair.
    /// // Tha na leanas a 'toirt loidhne "Mearachd: cleachdadh na ghluais luach: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // feuchaidh sinn sin a-rithist
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // an àite sin, tha sinn a 'cuir ann an .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // a-nis tha seo dìreach breagha:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Bidh e ag atharrachadh iterator gu cruinneachadh.
    ///
    /// `collect()` rud sam bith a ghabhail iterable, agus ga thionndadh a-steach do chruinneachadh iomchaidh.
    /// Is e seo aon de na dòighean as cumhachdaiche anns an leabharlann àbhaisteach, air a chleachdadh ann an grunn cho-theacsan.
    ///
    /// Is e am pàtran as bunaitiche anns a bheil `collect()` air a chleachdadh tionndadh aon chruinneachadh gu cruinneachadh eile.
    /// Tha thu a 'chruinneachadh, fòn [`iter`] air, a dhèanamh bad-atharrachaidhean, agus an uair sin `collect()` aig an deireadh.
    ///
    /// `collect()` faodaidh iad cuideachd suidheachaidhean a chruthachadh nach eil nan cruinneachaidhean àbhaisteach.
    /// Mar eisimpleir, [`String`] a ghabhas a thogail bho [`char`] s, agus an iterator de [`Result<T, E>`][`Result`] nithean faodar a chruinneachadh a-steach `Result<Collection<T>, E>`.
    ///
    /// Faicibh na h-eisimpleirean gu h-ìosal airson tuilleadh.
    ///
    /// Seach `collect()` tha cho coitcheann, faodaidh duilgheadasan adhbhrachadh le seòrsa inference.
    /// Mar sin, `collect()` S e aon de na beagan amannan chì thu na sheantansan gràdhach ris an canar 'turbofish': `::<>`.
    /// Tha seo a 'cuideachadh a' tuigsinn inference algairim sònraichte a chruinneachadh sibh a 'feuchainn a' cruinneachadh a-steach.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Cuimhnich gum feum againne air an `: Vec<i32>` air an làimh chlì.Tha seo air sgàth gum faodadh sinn a 'cruinneachadh a-steach, mar eisimpleir, a [`VecDeque<T>`] àite:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Cleachdadh an 'turbofish' an àite annotating `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Leis nach eil `collect()` a `gabhail cùram ach mu na tha thu a` tional a-steach, faodaidh tu fhathast sanas pàirt den t-seòrsa, `_`, a chleachdadh leis an turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Cleachdadh `collect()` a dhèanamh [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Ma tha liosta agad de [`Toradh<T, E>`][`Result`] s, faodaidh sibh a 'cleachdadh `collect()` fhaicinn ma tha gin dhiubh Dh'fhàillig:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // a 'toirt dhuinn a' chiad mearachd
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // a `toirt dhuinn liosta nam freagairtean
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Iterator an ithe, a 'cruthachadh dà chruinneachaidhean às e.
    ///
    /// Tha predicate seachad gu `partition()` urrainn till `true`, no `false`.
    /// `partition()` a `tilleadh paidhir, na h-eileamaidean air fad airson an do thill e `true`, agus na h-eileamaidean air fad airson an do thill e `false`.
    ///
    ///
    /// Faic cuideachd [`is_partitioned()`] agus [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// A `òrdachadh eileamaidean an iterator seo *nan àite* a rèir an ro-innse a chaidh a thoirt seachad, gus am bi a h-uile duine a thilleas `true` a` dol seachad air an fheadhainn a thilleas `false`.
    ///
    /// Tilleadh an àireamh de `true` eileamaidean a lorg.
    ///
    /// Tha buntainneach òrdugh partitioned nithean nach eil air an cumail suas.
    ///
    /// Faic cuideachd [`is_partitioned()`] agus [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Balla-dealachaidh ann an àite eadar-evens agus aghaidh
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: am bu chòir dhuinn dragh a bhith againn mun chunntas a `cur thairis?Tha an aon dòigh air a bheil barrachd na
        // `usize::MAX` mutable iomraidhean a tha maille ZSTs, nach eil feumail gus balla-dealachaidh ...

        // Tha na gnìomhan dùnaidh "factory" seo ann gus gnèitheachd ann an `Self` a sheachnadh.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Lorg a-rithist a `chiad `false` agus iomlaid e leis an `true` mu dheireadh.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Seicichean ma tha na h-eileamaidean seo iterator tha partitioned a rèir a 'predicate, leithid gum bi daoine a' tilleadh a h-uile `true` ron fheadhainn a tha a 'tilleadh `false`.
    ///
    ///
    /// Faic cuideachd [`partition()`] agus [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // An dàrna cuid na h-uile nithean a dhearbhadh `true`, no 'chiad clàs stad aig `false` agus tha sinn dèanamh cinnteach nach eil tuilleadh `true` nithean às dèidh sin.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// An iterator dòigh a 'buntainn obair cho fada' sa tha e a 'tilleadh gu soirbheachail, a' dèanamh aon chuairt mu dheireadh luach.
    ///
    /// `try_fold()` a `gabhail dà argamaid: luach tùsail, agus dùnadh le dà argamaid: an 'accumulator', agus eileamaid.
    /// Bidh an dùnadh an dàrna cuid a `tilleadh gu soirbheachail, leis an luach a bu chòir a bhith aig an cruinneadair airson an ath ath-thionndadh, no bidh e a` tilleadh fàilligeadh, le luach mearachd a thèid a chuir air ais chun neach-fios sa bhad (short-circuiting).
    ///
    ///
    /// Tha a 'chiad luach an luach an cruinneachaidh a bhios air a' chiad ghairm.Ma tha cur a-steach a 'dùnadh a' chùis an aghaidh a h-uile eileamaid de iterator, `try_fold()` a thilleas a 'chuairt dheireannach cruinneachaidh mar soirbheachail.
    ///
    /// Pasgadh a tha feumail nuair a tha thu a 'chruinneachadh de rudeigin, agus ag iarraidh a thoirt gu buil aon luach às.
    ///
    /// # Nòta do Luchd-buileachaidh
    ///
    /// Tha buileachadh bunaiteach aig grunn de na dòighean (forward) eile a thaobh an fhear seo, mar sin feuch ri seo a chuir an gnìomh gu follaiseach mas urrainn dha rudeigin a dhèanamh nas fheàrr na buileachadh bunaiteach lùb `for`.
    ///
    /// Gu sònraichte, tha seo a 'feuchainn ri gairm `try_fold()` air an taobh a-staigh phàirtean bho seo a iterator a dhèanamh.
    /// Ma tha feum air grunn ghairmean, is dòcha gum bi an gnìomhaiche `?` goireasach airson a bhith a `slaodadh luach an cruinneachaidh, ach thoir an aire do luchd-ionnsaigh sam bith a dh` fheumar a chumail suas mus till na toraidhean tràth sin.
    /// Is e modh `&mut self` a tha seo, agus mar sin feumar ath-thòiseachadh an dèidh mearachd a bhualadh an seo.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // an t-suim sgrùdaichte de na h-eileamaidean uile den raon
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Seo an t-suim overflows nuair a cur an eileamaid 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Seach gur e geàrr-circuited, air fhàgail-eileamaidean a tha fhathast ri fhaighinn tro iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// An iterator dòigh a 'buntainn a fallible gnìomh gus gach nì ann an iterator, a' stad aig a 'chiad mearachd agus a' tilleadh gun mhearachd.
    ///
    ///
    /// Faodar smaoineachadh air seo cuideachd mar an cruth fallible de [`for_each()`] no mar an dreach gun stàit de [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Tha e a 'gheàrr-circuited, agus mar sin air fhàgail nithean a tha fhathast ann an iterator:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Paisg a h-uile eileamaid gu cruinneadair le bhith a `cur gnìomhachd an sàs, a` tilleadh an toradh deireannach.
    ///
    /// `fold()` a `gabhail dà argamaid: luach tùsail, agus dùnadh le dà argamaid: an 'accumulator', agus eileamaid.
    /// Bidh an dùnadh a `tilleadh an luach a bu chòir a bhith aig an cruinneadair airson an ath thionndadh.
    ///
    /// Tha a 'chiad luach an luach an cruinneachaidh a bhios air a' chiad ghairm.
    ///
    /// An dèidh cur a-steach seo a dhùnadh a h-uile eileamaid de iterator, `fold()` thilleas cruinneachaidh.
    ///
    /// Tha an iomairt seo ris an canar uaireannan 'reduce' no 'inject'.
    ///
    /// Pasgadh a tha feumail nuair a tha thu a 'chruinneachadh de rudeigin, agus ag iarraidh a thoirt gu buil aon luach às.
    ///
    /// Note: `fold()`, agus coltach dòighean a 'dol thairis air fad iterator, faodaidh nach eil crìoch a chur air iterators airson neo-chrìochnach, eadhon air traits airson a thoradh e crìochnach determinable ann an àm.
    ///
    /// Note: [`reduce()`] faodar a cleachdadh gus a 'cleachdadh a' chiad eileamaid mar a 'chiad luach, ma tha an cruinneachaidh seòrsa agus a' phìos seòrsa an aon rud.
    ///
    /// # Nòta do Luchd-buileachaidh
    ///
    /// Tha buileachadh bunaiteach aig grunn de na dòighean (forward) eile a thaobh an fhear seo, mar sin feuch ri seo a chuir an gnìomh gu follaiseach mas urrainn dha rudeigin a dhèanamh nas fheàrr na buileachadh bunaiteach lùb `for`.
    ///
    ///
    /// Gu sònraichte, tha seo a 'feuchainn ri gairm `fold()` air an taobh a-staigh phàirtean bho seo a iterator a dhèanamh.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // an t-sùim uile de na h-eileamaidean de na ordugh
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Let cuairt tro gach ceum den chuairt seo:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Agus mar sin, an toradh deireannach againn, `6`.
    ///
    /// Tha e cumanta do dhaoine nach eil air a chleachdadh iterators tòrr a 'cleachdadh `for` lùb le liosta de rudan a thogail suas thoradh.Faodaidh an fheadhainn a thionndadh gu `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // airson lùb:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // tha iad mar an ceudna
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// A 'lùghdachadh na h-eileamaidean gu aon, le bhith a' cleachdadh tric a 'lùghdachadh obrachadh.
    ///
    /// Ma tha an iterator falamh, a 'tilleadh [`None`];a chaochladh, a 'tilleadh an thoradh air an lùghdachadh.
    ///
    /// Airson itealain le co-dhiù aon eileamaid, tha seo an aon rud ri [`fold()`] leis a `chiad eileamaid den iterator mar an luach tùsail, a` pasgadh a h-uile eileamaid às deidh sin a-steach.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Lorg an luach as motha:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Deuchainnean ma tha gach eileamaid de iterator matches a predicate.
    ///
    /// `all()` a 'gabhail a dhùnadh gun tilleadh `true` no `false`.Tha ea 'buntainn seo a dhùnadh do gach eileamaid de iterator, agus ma tha iad uile a' tilleadh `true`, an uair sin mar sin a 'dèanamh `all()`.
    /// Ma tha gin dhiubh a 'tilleadh `false`, tha e a' tilleadh `false`.
    ///
    /// `all()` tha geàrr-chuairteach;ann am faclan eile, cuiridh e stad air a bhith a `giullachd cho luath` s a lorgas e `false`, leis nach bi e gu diofar dè thachras, `false` cuideachd.
    ///
    ///
    /// Bidh iterator falamh a `tilleadh `true`.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// A `stad aig a` chiad `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // faodaidh sinn fhathast `iter` a chleachdadh, oir tha barrachd eileamaidean ann.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Deuchainnean ma tha eileamaid sam bith den iterator a `maidseadh ro-innse.
    ///
    /// `any()` a 'gabhail a dhùnadh gun tilleadh `true` no `false`.Tha ea 'buntainn seo a dhùnadh do gach eileamaid de iterator, agus ma sam bith dhiubh till `true`, an uair sin mar sin a' dèanamh `any()`.
    /// Ma thilleas iad uile `false`, tillidh e `false`.
    ///
    /// `any()` tha geàrr-chuairteach;ann am faclan eile, bidh e stad a chur air a 'giollachd cho luath' sa lorgaidh e `true`, a thoirt seachad ge-bith dè eile a 'tachairt, mar thoradh bhios cuideachd a' `true`.
    ///
    ///
    /// An falamh iterator tilleadh `false`.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Stad aig a 'chiad `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // faodaidh sinn fhathast `iter` a chleachdadh, oir tha barrachd eileamaidean ann.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Rannsachaidhean airson eileamaid de an iterator a tharruing a predicate.
    ///
    /// `find()` a 'gabhail a dhùnadh gun tilleadh `true` no `false`.
    /// Bidh e a `buntainn an dùnadh seo ri gach eileamaid den iterator, agus ma thilleas gin dhiubh `true`, bidh `find()` a` tilleadh [`Some(element)`].
    /// Ma tha iad uile a 'tilleadh `false`, tha e a' tilleadh [`None`].
    ///
    /// `find()` tha geàrr-chuairteach;ann am faclan eile, bidh e stad a chur air a 'giollachd cho luath' sa 'dùnadh a' tilleadh `true`.
    ///
    /// Leis gu bheil `find()` a `toirt iomradh, agus gu bheil mòran de itealain ag itealaich thairis air iomraidhean, tha seo a` leantainn gu suidheachadh a dh `fhaodadh a bhith troimh-chèile far a bheil an argamaid na iomradh dùbailte.
    ///
    /// Chì thu a 'bhuaidh seo ann an eisimpleirean gu h-ìosal, le `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Stad aig a 'chiad `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // faodaidh sinn fhathast `iter` a chleachdadh, oir tha barrachd eileamaidean ann.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Cuimhnich gur `iter.find(f)` tha co-ionann ri `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Buntainn ri gnìomh eileamaidean de na iterator agus a thilleas a 'chiad neo-gin thoradh.
    ///
    ///
    /// `iter.find_map(f)` tha e co-ionann ri `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Buntainn ri gnìomh eileamaidean de na iterator agus a thilleas a 'chiad fìor thoradh air a' chiad no mearachd.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Rannsachaidhean airson an eileamaid ann an iterator, a 'tilleadh a-amais.
    ///
    /// `position()` a 'gabhail a dhùnadh gun tilleadh `true` no `false`.
    /// Bidh e a `buntainn an dùnadh seo ri gach eileamaid den iterator, agus ma thilleas aon dhiubh `true`, an uairsin tillidh `position()` [`Some(index)`].
    /// Ma tha a h-uile dhiubh till `false`, tha e a 'tilleadh [`None`].
    ///
    /// `position()` tha geàrr-chuairteach;ann am faclan eile, cuiridh e stad air giullachd cho luath `s a lorgas e `true`.
    ///
    /// # Overflow Giùlan
    ///
    /// Chan eil an dòigh-obrach a `dìon an aghaidh thar-shruth, mar sin ma tha barrachd air eileamaidean neo-fhreagarrach [`usize::MAX`] ann, bidh e an dàrna cuid a` toirt a-mach an toradh ceàrr no panics.
    ///
    /// Ma chanas debug tha an comas, a panic tha seachnadh.
    ///
    /// # Panics
    ///
    /// A 'ghnìomh seo a dh' fhaodadh panic ma tha an iterator Tha barrachd `usize::MAX` neo-eileamaidean a fhreagras air.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Stad aig a 'chiad `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // faodaidh sinn fhathast `iter` a chleachdadh, oir tha barrachd eileamaidean ann.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Tha an clàr-amais a thill an crochadh air iterator stàite
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Rannsachaidhean airson an eileamaid ann an iterator bhon làimh dheis, a 'tilleadh a-amais.
    ///
    /// `rposition()` a 'gabhail a dhùnadh gun tilleadh `true` no `false`.
    /// Bidh e a `buntainn an dùnadh seo ri gach eileamaid den iterator, a` tòiseachadh bhon deireadh, agus ma thilleas aon dhiubh `true`, an uairsin tillidh `rposition()` [`Some(index)`].
    ///
    /// Ma tha a h-uile dhiubh till `false`, tha e a 'tilleadh [`None`].
    ///
    /// `rposition()` tha geàrr-chuairteach;ann am faclan eile, cuiridh e stad air giullachd cho luath `s a lorgas e `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Stad aig a 'chiad `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // faodaidh sinn fhathast `iter` a chleachdadh, oir tha barrachd eileamaidean ann.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Chan eil feum air an overflow sùil air an seo, oir `ExactSizeIterator` 'ciallachadh gu bheil an àireamh de eileamaidean freagradh air a `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// A 'tilleadh as àirde eileamaid de iterator.
    ///
    /// Ma tha grunn eileamaidean a tha a cheart cho 'char as àirde, an eileamaid mu dheireadh a thilleadh.
    /// Ma tha an iterator falamh, thèid [`None`] a thilleadh.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// A 'tilleadh as ìsle eileamaid de iterator.
    ///
    /// Ma tha grunn eileamaidean a cheart cho ìosal, thèid a `chiad eileamaid a thilleadh.
    /// Ma tha an iterator falamh, thèid [`None`] a thilleadh.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// A `tilleadh an eileamaid a bheir an luach as motha bhon ghnìomh ainmichte.
    ///
    ///
    /// Ma tha grunn eileamaidean a tha a cheart cho 'char as àirde, an eileamaid mu dheireadh a thilleadh.
    /// Ma tha an iterator falamh, thèid [`None`] a thilleadh.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Thilleas eileamaid a 'toirt seachad an luach as motha a thaobh comharraichte coimeas gnìomh.
    ///
    ///
    /// Ma tha grunn eileamaidean a tha a cheart cho 'char as àirde, an eileamaid mu dheireadh a thilleadh.
    /// Ma tha an iterator falamh, thèid [`None`] a thilleadh.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// A `tilleadh an eileamaid a bheir an luach as lugha bhon ghnìomh ainmichte.
    ///
    ///
    /// Ma tha grunn eileamaidean a cheart cho ìosal, thèid a `chiad eileamaid a thilleadh.
    /// Ma tha an iterator falamh, thèid [`None`] a thilleadh.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Thilleas eileamaid a 'toirt seachad an luach as lugha a thaobh comharraichte coimeas gnìomh.
    ///
    ///
    /// Ma tha grunn eileamaidean a cheart cho ìosal, thèid a `chiad eileamaid a thilleadh.
    /// Ma tha an iterator falamh, thèid [`None`] a thilleadh.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// A `dol air ais stiùireadh iterator.
    ///
    /// Mar as trice, iterators iterate bho chlì gu deas.
    /// An dèidh a bhith `rev()`, an iterator bidh àite iterate o dheas gu clì.
    ///
    /// 'S e seo a-mhàin a ghabhas ma bhios an iterator Tha an ceann, agus mar sin a-mhàin `rev()` ag obair air [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Converts an iterator na càraidean a-steach paidhir crogain.
    ///
    /// `unzip()` ithe fad iterator de càraidean, a 'dèanamh dà chruinneachaidhean: fear bhon làimh chlì eileamaidean an càraidean, agus aon air an làimh dheis bho eileamaidean.
    ///
    ///
    /// Tha seo a dhreuchd, ann an cuid de mhothachadh, an taobh thall de [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// A 'cruthachadh an iterator a lethbhreacan a h-uile h-eileamaidean.
    ///
    /// Tha seo feumail, nuair a tha agad an iterator thairis `&T`, ach feumaidh tu an còrr iterator `T`.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // lethbhreacadh an aon rud mar a .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// A 'cruthachadh an iterator a [`clone`] s a h-uile h-eileamaidean.
    ///
    /// Tha seo feumail, nuair a tha agad an iterator thairis `&T`, ach feumaidh tu an còrr iterator `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // tha clonadh an aon rud ri .map(|&x| x), airson integers
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Ath-aithris an iterator gun sguir.
    ///
    /// An àite a bhith a 'stad aig [`None`], an iterator Bidh an àite tòiseachadh a-rithist, bhon toiseach.An dèidh a bhith ag itealaich a-rithist, tòisichidh e aig an toiseach a-rithist.Agus a-rithist.
    /// Agus a-rithist.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Th'aig na h-eileamaidean de iterator.
    ///
    /// A 'gabhail gach eileamaid, a' cur còmhla riutha, agus a thilleas an toradh.
    ///
    /// An falamh iterator thilleas neoni luach an t-seòrsa.
    ///
    /// # Panics
    ///
    /// Nuair a gairm `sum()` agus prìomhadail integer-seòrsa a thathar a 'tilleadh, an dòigh seo bidh panic ma tha an coimpiutadh overflows agus debug chanas comas.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates thairis air fad iterator, iomadachaidh h-uile eileamaid
    ///
    /// An falamh iterator thilleas aon luach an t-seòrsa.
    ///
    /// # Panics
    ///
    /// Nuair a gairm `product()` agus prìomhadail integer-seòrsa a thathar a 'tilleadh, an dòigh a bhios panic ma tha an coimpiutadh overflows agus debug chanas comas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) dèanamh coimeas eadar na h-eileamaidean seo [`Iterator`] ris an fheadhainn eile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) dèanamh coimeas eadar na h-eileamaidean seo [`Iterator`] ris an fheadhainn eile a thaobh comharraichte coimeas gnìomh.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) dèanamh coimeas eadar na h-eileamaidean seo [`Iterator`] ris an fheadhainn eile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) dèanamh coimeas eadar na h-eileamaidean seo [`Iterator`] ris an fheadhainn eile a thaobh comharraichte coimeas gnìomh.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Ma cho-dhùineas na h-eileamaidean seo [`Iterator`] tha co-ionann ris an fheadhainn eile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Ma cho-dhùineas na h-eileamaidean seo [`Iterator`] tha co-ionann ris an fheadhainn eile a thaobh co-ionannachd comharraichte gnìomh.
    ///
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Ma cho-dhùineas na h-eileamaidean seo [`Iterator`] tha co-ionann ris an fheadhainn eile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// A `dearbhadh a bheil na h-eileamaidean den [`Iterator`] seo [lexicographically](Ord#lexicographical-comparison) nas lugha na eileamaidean fear eile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// A `dearbhadh a bheil na h-eileamaidean den [`Iterator`] seo [lexicographically](Ord#lexicographical-comparison) nas lugha no co-ionann ri feadhainn eile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Ma cho-dhùineas na h-eileamaidean seo [`Iterator`] [lexicographically](Ord#lexicographical-comparison) tha nas motha na an fheadhainn eile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// A `dearbhadh a bheil na h-eileamaidean den [`Iterator`] seo [lexicographically](Ord#lexicographical-comparison) nas motha na no co-ionann ri feadhainn eile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// A `dèanamh cinnteach a bheil na h-eileamaidean den iterator seo air an rèiteachadh.
    ///
    /// 'S e sin, airson gach eileamaid `a` agus a leanas eileamaid `b`, `a <= b` Feumaidh chumail.Ma tha an iterator faighear neoni no dìreach aon eileamaid, `true` a thilleadh.
    ///
    /// Thoir fa-near, mura h-eil `Self::Item` ach `PartialOrd`, ach chan e `Ord`, tha am mìneachadh gu h-àrd a `ciallachadh gum bi an gnìomh seo a` tilleadh `false` mura h-eil dà rud leantainneach an coimeas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Seicichean ma tha na h-eileamaidean seo iterator tha a 'cleachdadh an cur ann an ordugh a thoirt coimeis gnìomh.
    ///
    /// An àite a bhith a `cleachdadh `PartialOrd::partial_cmp`, bidh an gnìomh seo a` cleachdadh a `ghnìomh `compare` a chaidh a thoirt seachad gus òrdachadh dà eileamaid a dhearbhadh.
    /// A bharrachd air sin, tha e co-ionann ri [`is_sorted`];faic na sgrìobhainnean aige airson tuilleadh fiosrachaidh.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// A `dèanamh cinnteach a bheil na h-eileamaidean den iterator seo air an rèiteachadh le bhith a` cleachdadh a `phrìomh ghnìomh às-tharraing a chaidh a thoirt seachad.
    ///
    /// An àite a bhith a `dèanamh coimeas dìreach eadar eileamaidean an iterator, tha an gnìomh seo a` dèanamh coimeas eadar iuchraichean nan eileamaidean, mar a chaidh a dhearbhadh le `f`.
    /// A bharrachd air sin, tha e co-ionann ri [`is_sorted`];faic na sgrìobhainnean aige airson tuilleadh fiosrachaidh.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// See [TrustedRandomAccess]
    // Tha an t-ainm annasach a tha a sheachnadh ainm thubaistean ann an dòigh rùn fhaicinn #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}