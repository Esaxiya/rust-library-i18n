//! Composable taobh a-muigh cuairt.
//!
//! Ma tha thu fhèin a lorg le cruinneachadh de choireigin, agus dh'fheumadh a 'coileanadh obrachadh air na h-eileamaidean de Thuirt chruinneachadh, bidh tu a-steach gu luath a' ruith 'iterators'.
//! Tha luchd-deasachaidh air an cleachdadh gu mòr ann an còd gnàthaichte Rust, mar sin is fhiach a bhith eòlach orra.
//!
//! Mus deach a 'mìneachadh tuilleadh, leig a' bruidhinn mu dheidhinn mar a modal seo structar:
//!
//! # Organization
//!
//! Tha am modal seo air a eagrachadh gu ìre mhòr a rèir seòrsa:
//!
//! * [Traits] Tha am prìomh earrann: traits sin a 'mìneachadh dè an seòrsa iterators ann agus dè dh'fhaodas tu a dhèanamh còmhla riutha.Tha na dòighean sin traits tha luach a bharrachd a 'cur cuid de sgrùdadh an àm a-steach.
//! * [Functions] a 'toirt seachad an cuid de dhòighean cuideachail ann a bhith a' cruthachadh an cuid de bunaiteach iterators.
//! * [Structs] gu tric is iad na seòrsaichean tilleadh de na diofar dhòighean air traits a `mhodal seo.Mar as trice bidh thu airson sùil a thoirt air an dòigh a chruthaicheas an `struct`, seach an `struct` fhèin.
//! Airson tuilleadh fiosrachaidh mu carson, faic '[Gnìomhachadh Iterator](#buileachadh-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Sin e!Nach cladhach sinn a-steach do itealain.
//!
//! # Iterator
//!
//! Is e cridhe agus anam a `mhodal seo an [`Iterator`] trait.Tha cridhe na [`Iterator`] a 'coimhead mar seo:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! An iterator Tha dòigh air, [`next`], nuair a ghairm, a 'tilleadh an [`Option`]`<Item>`.
//! [`next`] tillidh [`Some(Item)`] fhad `s a tha eileamaidean ann, agus aon uair` s gu bheil iad uile air an leigeil a-mach, tillidh iad `None` gus sealltainn gu bheil itealadh deiseil.
//! Faodaidh itealain fa leth roghnachadh itealain ath-thòiseachadh, agus mar sin is dòcha gun tòisich [`next`] a-rithist a `tilleadh [`Some(Item)`] a-rithist aig àm air choreigin (mar eisimpleir, faic [`TryIter`]).
//!
//!
//! Tha làn mhìneachadh [`Iterator`] a` toirt a-steach grunn dhòighean eile cuideachd, ach tha iad nan dòighean bunaiteach, air an togail air mullach [`next`], agus mar sin gheibh thu iad an-asgaidh.
//!
//! Iterators tha cuideachd composable, agus tha e cumanta do chain iad còmhla gus a dhèanamh nas iom-fhillte na foirmean giollachd.Faic an earrann [Adapters](#adapters) gu h-ìosal airson tuilleadh fiosrachaidh.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Na trì cruthan iteachaidh
//!
//! Tha trì dòighean cumanta ann a chruthaicheas itealain bho chruinneachadh:
//!
//! * `iter()`, a iterates thairis `&T`.
//! * `iter_mut()`, a iterates thairis `&mut T`.
//! * `into_iter()`, a iterates thairis `T`.
//!
//! Diofar rudan ann an inbhe leabharlainn dòcha a chur an gnìomh air aon no barrachd de na trì, far a bheil sin iomchaidh.
//!
//! # Iterator buileachaidh
//!
//! Cruthachadh an iterator agad fhèin gabhail a-steach dà cheum: a 'cruthachadh `struct` a chumail iterator stàite, agus an uair sin a' cur an gnìomh [`Iterator`] airson a `struct`.
//! Sin as coireach gu bheil uimhir de `structair 'sa mhodal seo: tha aon ann airson gach iterator agus adapter iterator.
//!
//! Nach dhèanamh iterator ainmeachadh `Counter` a tha a 'cunntadh bho `1` gu `5`:
//!
//! ```
//! // A 'chiad, an struct:
//!
//! /// An iterator a tha a 'cunntadh bho aon gu còig
//! struct Counter {
//!     count: usize,
//! }
//!
//! // tha sinn ag iarraidh ar cunntadh gus tòiseachadh aig aon, mar sin, leig a 'Cuir new() dòigh gus cuideachadh.
//! // Chan eil seo buileach riatanach, ach tha e goireasach.
//! // Thoir fa-near gum bi sinn a `tòiseachadh `count` aig neoni, chì sinn carson ann am buileachadh `next()`'s gu h-ìosal.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // An uairsin, bidh sinn a `cur `Iterator` an gnìomh airson an `Counter` againn:
//!
//! impl Iterator for Counter {
//!     // bidh sinn a 'cunntadh le usize
//!     type Item = usize;
//!
//!     // next() an aon dòigh riatanach
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Ceum ar cunntadh.'S e seo carson a thòisich sinn aig neoni.
//!         self.count += 1;
//!
//!         // Lorg fhaicinn ma tha sinn deiseil cunntaidh no nach eil.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Agus a nis faodaidh sinn ga cleachdadh!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Calling [`next`] dòigh seo gheibh ath.Rust tha a thogail a bhios a 'fòn [`next`] air do iterator, gus an ruig i `None`.Rachamaid thairis air an sin an ath.
//!
//! Cuideachd mothachail gun robh `Iterator` a 'toirt default buileachadh dhòighean leithid `nth` agus `fold` a ghairm `next`-staigh.
//! Ach, tha e comasach cuideachd buileachadh gnàthaichte a sgrìobhadh de mhodhan mar `nth` agus `fold` mas urrainn do iterator an dèanamh nas èifeachdaiche gun a bhith a `gairm `next`.
//!
//! # `for` lùban agus `IntoIterator`
//!
//! Is e siùcar airson itealain a th `ann an co-chòrdadh lùb `for` Rust.Seo eisimpleir de bunaiteach `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Bidh seo a 'clò-bhualadh na h-àireamhan aon tro chòig, gach aon aca fhèin air-loidhne.Ach chì thu rudeigin an seo: cha do ghairm sinn dad a-riamh air an vector againn gus iterator a dhèanamh.Dè a bheir seachad?
//!
//! Tha trait ann an inbhe leabharlainn airson atharrachadh rudeigin ann an iterator: [`IntoIterator`].
//! Tha seo a 'trait Tha aon dòigh, [`into_iter`], a tha a' cur an gnìomh an ni converts [`IntoIterator`] a-steach an iterator.
//! Nach toir sùil air a `for` lùb a-rithist, agus dè an compiler ga thionndadh gu:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Bidh Rust a `toirt a-mach seo gu:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! An toiseach, canaidh sinn `into_iter()` air an luach.An uair sin, tha sinn a 'maidseadh air an iterator a' tilleadh, a 'gairm [`next`] thairis agus thairis gus an deach sinn a' faicinn `None`.
//! Aig an ìre sin, tha sinn `break`-mach às an lùib, agus tha sinn a Deiseil iterating.
//!
//! Tha aon beagan nas seòlta an seo: an ìre leabharlainn anns inntinneach a chur an gnìomh [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Ann am briathran eile, a h-uile [`Iterator`] s [`IntoIterator`] a chur an gnìomh, le dìreach a 'tilleadh fhèin.Tha seo a `ciallachadh dà rud:
//!
//! 1. Ma tha thu a 'sgrìobhadh [`Iterator`], faodaidh sibh ga cleachdadh le `for` lùb.
//! 2. Ma tha thu a 'cruthachadh chruinneachadh, a bhuileachadh [`IntoIterator`] airson a bheir e cead do chruinneachadh a bhith air a chleachdadh leis a' `for` lùb.
//!
//! # Iterating le iomradh
//!
//! Leis gu bheil [`into_iter()`] a `toirt `self` a rèir luach, bidh a bhith a` cleachdadh lùb `for` gus a dhol thairis air cruinneachadh a `caitheamh a` chruinneachaidh sin.Gu tric, is dòcha gum bi thu airson ath-aithris a dhèanamh air cruinneachadh gun a bhith ga ithe.
//! Tha mòran de na cruinneachaidhean a 'tabhann dhòighean-obrach a thoirt seachad iterators thairis air iomraidhean, trice canar `iter()` agus `iter_mut()` fa leth:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` Tha e fhathast le 'ghnìomh seo.
//! ```
//!
//! Ma chruinneachadh seòrsa `C` toirt `iter()`, tha e mar as trice cuideachd a 'buileachadh `IntoIterator` airson `&C`, le buileachadh sin dìreach ag iarraidh `iter()`.
//! Mar an ceudna, a chruinneachadh `C` a 'toirt `iter_mut()` san fharsaingeachd a' buileachadh `IntoIterator` airson `&mut C` le thiomnadh gu `iter_mut()`.Tha seo a `comasachadh làmh-ghoirid goireasach:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // an aon rud ri `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // mar aon `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Ged a tha mòran chruinneachaidhean a `tabhann `iter()`, chan eil iad uile a` tabhann `iter_mut()`.
//! Mar eisimpleir, mutating iuchraichean de [`HashSet<T>`] no [`HashMap<K, V>`] a chur an cruinneachadh a-steach an staid neo-chunbhalach ma tha na prìomh hashes atharrachadh, mar sin, na cruinneachaidhean sin a-mhàin a 'tabhann `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Canar 'iterator adapters' gu tric ri gnìomhan a bheir [`Iterator`] agus a thilleas [`Iterator`] eile, oir tha iad mar sheòrsa den 'adapter'
//! pattern'.
//!
//! Common iterator adapters gabhail a-steach [`map`], [`take`], agus [`filter`].
//! Airson barrachd, faic aca sgrìobhainnean.
//!
//! Ma tha adapter iterator panics, bidh an iterator ann an staid neo-ainmichte (ach sàbhailte le cuimhne).
//! Chan eilear a `gealltainn gum fuirich an stàit seo mar an ceudna thar dreachan de Rust, mar sin bu chòir dhut a bhith an urra ri na dearbh luachan a th` air an toirt air ais le itealaiche a chaidh troimhe-chèile.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Tha luchd-deasachaidh (agus iterator [adapters](#adapters))*leisg*. Tha seo a `ciallachadh nach bi dìreach a` cruthachadh iterator _do_ gu h-iomlan. Chan eil dad a `tachairt gus an cuir thu fios gu [`next`].
//! Tha seo uaireannan na adhbhar troimh-chèile nuair a chruthaicheas tu iterator a-mhàin airson na fo-bhuaidhean aige.
//! Mar eisimpleir, an dòigh [`map`] ag iarraidh a dhùnadh air gach eileamaid e iterates thairis:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Cha chlò-bhuail seo luachan sam bith, oir cha do chruthaich sinn ach iterator, seach a bhith ga chleachdadh.Tha a chur ri chèile a bhios a 'toirt rabhadh dhuinn mu dheidhinn seo an seòrsa giùlan:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Tha gnàthasach dòigh a sgrìobhadh [`map`] airson a bhuaidhean a tha a 'cleachdadh `for` lùb no fòn an dòigh [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Is e dòigh cumanta eile air iterator a mheasadh a bhith a `cleachdadh an dòigh [`collect`] gus cruinneachadh ùr a thoirt gu buil.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Chan fheum luchd-deasachaidh a bhith crìochnaichte.Mar eisimpleir, tha raon fosgailte mar itealaiche gun chrìoch:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Tha e cumanta a bhith a 'cleachdadh an [`take`] iterator adapter tionndadh an neo-chrìochnach crìochnach iterator a-steach air aon:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Clò-bhualaidh seo na h-àireamhan `0` tro `4`, gach fear air an loidhne aca fhèin.
//!
//! Bear an aire gum bi dòighean air neo-chrìochnach iterators, fiù 's an fheadhainn airson a thoradh faodar co-dhùnadh ann an seagh mhatamataigeach crìochnach àm, faodaidh nach eil crìoch a chur air.
//! Gu sònraichte, tha dòighean leithid [`min`], a tha sa chumantas a `feumachdainn a dhol thairis air gach eileamaid den iterator, dualtach gun a bhith a` tilleadh gu soirbheachail airson itealain neo-chrìochnach sam bith.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh No!An lùib neo-chrìochnach!
//! // `ones.min()` ag adhbhrachadh an lùib neo-chrìochnach, mar sin, cha bhi sinn a 'ruigsinn a' phuing seo!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;