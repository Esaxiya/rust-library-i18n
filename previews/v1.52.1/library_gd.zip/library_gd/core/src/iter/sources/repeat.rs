use crate::iter::{FusedIterator, TrustedLen};

/// A 'cruthachadh ùr iterator a nochdas a rithist gun stad aon eileamaid.
///
/// Tha `repeat()` gnìomh ath-aithris an aon luach thairis agus thairis a-rithist.
///
/// Infinite iterators `repeat()` mar a tha tric air a chleachdadh le adapters mar [`Iterator::take()`], gus an dèan iad crìochnach.
///
/// Mura h-eil an seòrsa eileamaid den iterator a dh `fheumas tu a` buileachadh `Clone`, no mura h-eil thu airson an eileamaid ath-aithris a chumail nad chuimhne, faodaidh tu an gnìomh [`repeat_with()`] a chleachdadh.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// use std::iter;
///
/// // an àireamh ceithir 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, fhathast ceithir
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Going crìochnach le [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // gun mu dheireadh eisimpleir bha cus fours.Leig a-mhàin gu bheil ceithir fours.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... agus a-nis tha sinn air a dhèanamh
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// An iterator a nochdas a rithist eileamaid gun sguir.
///
/// `struct` seo a chruthachadh le [`repeat()`] gnìomh.Faic na sgrìobhainnean aige airson tuilleadh.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}