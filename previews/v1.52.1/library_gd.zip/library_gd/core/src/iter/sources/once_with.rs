use crate::iter::{FusedIterator, TrustedLen};

/// A 'cruthachadh an iterator lazily a gineadh luach dìreach aon uair le invoking an dùnadh a thoirt seachad.
///
/// Tha seo air a chleachdadh gu cumanta airson atharrachadh aon luach gineadair a-steach [`chain()`] eile sheòrsa cuairt.
/// 'S dòcha agad a tha a' còmhdach iterator cha mhòr a h-uile rud, ach feumaidh sibh leth sònraichte a 'chùis.
/// 'S dòcha tha thu a' ghnìomh a tha ag obair air iterators, ach a-mhàin a dh'fheumas làimhseachadh aon luach.
///
/// Eu-coltach ri [`once()`], a 'ghnìomh seo bidh lazily gineadh luach air iarrtas.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// use std::iter;
///
/// // is e aon an àireamh as fhaide
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // dìreach aon, 'se sin uile a gheibh sinn
/// assert_eq!(None, one.next());
/// ```
///
/// Chaining còmhla ri iterator eile.
/// Nach can gu bheil sinn ag iarraidh a iterate thar gach faidhl an `.foo` eòlaire, ach cuideachd faidhle rèiteachaidh,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // feumaidh sinn iompachadh bho iterator de DirEntry-s gu iterator de PathBufs, mar sin tha sinn a 'cleachdadh map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // a-nis, ar iterator dìreach airson ar Rèiteachadh faidhle
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // Chain an dà iterators còmhla ann an aon mòr iterator
/// let files = dirs.chain(config);
///
/// // bidh seo a 'toirt dhuinn a h-uile faidhlichean ann .foo thuilleadh .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Iterator a bheir a-mach aon eileamaid de sheòrsa `A` le bhith a `cur a-steach an dùnadh a chaidh a thoirt seachad `F: FnOnce() -> A`.
///
///
/// `struct` seo a chruthachadh le [`once_with()`] gnìomh.
/// Faic na sgrìobhainnean aige airson tuilleadh.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}