use crate::fmt;

/// A 'cruthachadh ùr iterator far a bheil gach cuairt ag iarraidh an toirt seachad dùnadh `F: FnMut() -> Option<T>`.
///
/// Leigidh seo le bhith a `cruthachadh itealaiche àbhaisteach le giùlan sam bith gun a bhith a` cleachdadh an co-chòrdadh nas gnìomhair de bhith a `cruthachadh seòrsa sònraichte agus a` buileachadh an [`Iterator`] trait air a shon.
///
/// Thoir fa-near nach bi an iterator `FromFn` a `dèanamh barailean mu ghiùlan an dùnaidh, agus mar sin gu coimeádach chan eil e a` cur an gnìomh [`FusedIterator`], no a `dol thairis air [`Iterator::size_hint()`] bhon `(0, None)` àbhaisteach aige.
///
///
/// Tha a 'dùnadh a' cleachdadh a 'glacadh agus a h-àrainneachd gus sùil a chumail air feadh na stàite iterations.A rèir mar a thèid an iterator a chleachdadh, is dòcha gu feum seo sònrachadh prìomh fhacal [`move`] air an dùnadh.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Let ath-chur an gnìomh a 'chunntair iterator bho [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Ceum ar cunntadh.'S e seo carson a thòisich sinn aig neoni.
///     count += 1;
///
///     // Lorg fhaicinn ma tha sinn deiseil cunntaidh no nach eil.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// An iterator far a bheil gach cuairt ag iarraidh an toirt seachad dùnadh `F: FnMut() -> Option<T>`.
///
/// `struct` seo a chruthachadh le [`iter::from_fn()`] gnìomh.
/// Faic na sgrìobhainnean aige airson tuilleadh.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}