use crate::iter::{FusedIterator, TrustedLen};

/// A `cruthachadh iterator ùr a bhios ag ath-aithris eileamaidean de sheòrsa `A` gun stad le bhith a` cur a-steach an dùnadh a chaidh a thoirt seachad, an ath-chraoladh, `F: FnMut() -> A`.
///
/// Bidh gnìomh `repeat_with()` a `gairm an ath-chraoladh a-rithist agus a-rithist.
///
/// Infinite iterators `repeat_with()` mar a tha tric air a chleachdadh le adapters mar [`Iterator::take()`], gus an dèan iad crìochnach.
///
/// Ma tha an eileamaid seòrsa de iterator feumaidh tu innealan [`Clone`], agus tha e ceart gu leòr a chumail an tùs eileamaid ann an cuimhne, bu chòir dhut an àite a 'cleachdadh na [`repeat()`] gnìomh.
///
///
/// An iterator a chruthachadh le `repeat_with()` Chan eil [`DoubleEndedIterator`].
/// Ma dh'fheumas sibh `repeat_with()` tilleadh a [`DoubleEndedIterator`], cuiribh fhosgladh GitHub chùis a 'mìneachadh do chleachdadh chùis.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// use std::iter;
///
/// // gabhamaid ris gu bheil luach air choireigin againn de sheòrsa nach eil `Clone` no nach eil airson a bhith nad chuimhne dìreach air sgàth gu bheil e daor:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // sònraichte luach gu bràth:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Mutation 'cleachdadh agus a' dol crìochnach:
///
/// ```rust
/// use std::iter;
///
/// // Bho zeroth gu an treas cumhachd dhà:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... agus a-nis tha sinn air a dhèanamh
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Ath-aithrisiche a bhios ag ath-aithris eileamaidean de sheòrsa `A` gun stad le bhith a `cur a-steach an dùnadh a chaidh a thoirt seachad `F: FnMut() -> A`.
///
///
/// `struct` seo a chruthachadh le [`repeat_with()`] gnìomh.
/// Faic na sgrìobhainnean aige airson tuilleadh.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}