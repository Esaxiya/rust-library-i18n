use crate::iter::{FusedIterator, TrustedLen};

/// A 'cruthachadh an iterator gum faighear an eileamaid dìreach aon turas.
///
/// Tha seo air a chleachdadh gu cumanta airson atharrachadh aon luach a-steach [`chain()`] eile sheòrsa cuairt.
/// 'S dòcha agad a tha a' còmhdach iterator cha mhòr a h-uile rud, ach feumaidh sibh leth sònraichte a 'chùis.
/// 'S dòcha tha thu a' ghnìomh a tha ag obair air iterators, ach a-mhàin a dh'fheumas làimhseachadh aon luach.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// use std::iter;
///
/// // is e aon an àireamh as fhaide
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // dìreach aon, 'se sin uile a gheibh sinn
/// assert_eq!(None, one.next());
/// ```
///
/// Chaining còmhla ri iterator eile.
/// Nach can gu bheil sinn ag iarraidh a iterate thar gach faidhl an `.foo` eòlaire, ach cuideachd faidhle rèiteachaidh,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // feumaidh sinn iompachadh bho iterator de DirEntry-s gu iterator de PathBufs, mar sin tha sinn a 'cleachdadh map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // a-nis, ar iterator dìreach airson ar Rèiteachadh faidhle
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // Chain an dà iterators còmhla ann an aon mòr iterator
/// let files = dirs.chain(config);
///
/// // bidh seo a 'toirt dhuinn a h-uile faidhlichean ann .foo thuilleadh .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Iterator a bheir a-mach eileamaid dìreach aon uair.
///
/// `struct` seo a chruthachadh le [`once()`] gnìomh.Faic na sgrìobhainnean aige airson tuilleadh.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}