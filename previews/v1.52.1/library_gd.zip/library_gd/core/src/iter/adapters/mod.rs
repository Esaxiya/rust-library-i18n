use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Tha an trait seo a `toirt cothrom eadar-ghluasadach air ìre stòr ann an loidhne-phìoban interator-adapter fo na cumhaichean a tha
/// * iterator an tùs `S` fhèin a 'buileachadh `SourceIter<Source = S>`
/// * tha a thiomnadh a chur an gnìomh seo trait airson gach adapter ann an loidhne-phìoban eadar an tobar agus an loidhne-phìoban luchd-cleachdaidh.
///
/// Nuair a tha an tobar 'S e an robh iterator struct (trice canar `IntoIter`) an uair sin faodaidh seo a bhith feumail airson a' speisealachadh [`FromIterator`] implementations no slànachadh an eileamaidean air fhàgail an dèidh a bhith air a iterator pàirt sgìth.
///
///
/// Thoir fa-near nach fheum gnìomhachadh ruigsinneachd a thoirt don stòr a-staigh as motha de loidhne-phìoban.A stateful eadar-mheadhanach adapter dh'fhaodadh fiughair measadh a dhèanamh na pàirt de loidhne-phìoban agus ana taobh a-staigh stòradh mar thobar.
///
/// Tha an trait cunnartach oir feumaidh luchd-gnìomh togalaichean sàbhailteachd a bharrachd a chumail suas.
/// Faic [`as_inner`] airson mion-fhiosrachadh.
///
/// # Examples
///
/// A 'faighinn stòr air a chaitheamh gu ìre:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Ìre stòr ann an loidhne-phìob iterator.
    type Source: Iterator;

    /// Fhaighinn air ais air tùs na iterator an loidhne-phìoban.
    ///
    /// # Safety
    ///
    /// Feumaidh buileachadh an aon iomradh so-atharraichte a thilleadh fad am beatha, mura h-eil neach eile a `gabhail àite.
    /// Gairmean fòn ach a-mhàin an àite an iomraidh cuin a sguir iad cuairt agus leig às na loidhne-phìoban iterator às dèidh an tobar.
    ///
    /// Tha seo a `ciallachadh gum faod luchd-atharrachaidh itealain a bhith an urra ris an stòr gun a bhith ag atharrachadh aig àm iteachaidh ach chan urrainn dhaibh a bhith an urra ris anns na buileachaidhean drop aca.
    ///
    /// Buileachadh an dòigh seo a 'ciallachadh adapters prìobhaideach leigeil seachad a-mhàin cothruim air an tobar agus chan urrainn dhaibh ach an crochadh air barrantas a dhèanamh stèidhichte air modh-obrach trusaidh seòrsa.
    /// Tha dìth cothrom cuingichte cuideachd ag iarraidh gum bi adapters Feumaidh seas an tùs poblach API fiù 's nuair a tha iad air a bheil cothrom aca internals.
    ///
    /// Gairmean fòn ann feumaidh an dùil an tobar a bhith ann an stàit sam bith a tha co-chòrdail ris a 'phoball aige API bho adapters shuidhe eadar e agus an tobar tha an aon cothrom.
    /// Gu sònraichte an adapter dòcha gun loisg tuilleadh eileamaidean na teann riatanach.
    ///
    /// Is e amas iomlan nan riatanasan sin leigeil le neach-cleachdaidh loidhne-phìoban a chleachdadh
    /// * ge bith dè a tha air fhàgail ann an stòr dèidh cuairt air stad
    /// * a `chuimhne a tha air fàs gun chleachdadh le bhith ag adhartachadh itealaiche caitheamh
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Bidh adapter iterator a bheir toradh a-mach fhad `s a bhios an iterator bunaiteach a` toirt a-mach luachan `Result::Ok`.
///
///
/// Ma mearachd a tha a 'tachairt, a' iterator-stad agus a 'mhearachd a stòradh.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Pròiseas an iterator a chaidh a thoirt seachad mar gum biodh e a `toirt a-mach `T` an àite `Result<T, _>`.
/// Mearachdan sam bith a thèid stad a chur a-staigh iterator agus iomlan thoradh bi mearachd.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}