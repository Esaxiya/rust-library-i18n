use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Rudan a bheil smuain de dèidh * **agus ro-theachdaiche* obraichean.
///
/// * * Tha an ionaid obrachaidh a 'gluasad a dh'ionnsaigh luachan sin coimeas a dhèanamh nas motha.
/// Tha an ro-theachdaiche * * gluasad a dh'ionnsaigh obrachadh na luachan sin coimeas a dhèanamh nas lugha.
///
/// # Safety
///
/// Is e `unsafe` an trait seo oir feumaidh a bhuileachadh a bhith ceart airson sàbhailteachd buileachadh `unsafe trait TrustedLen`, agus faodar toraidhean cleachdadh an trait seo earbsa ann an còd `unsafe` gus a bhith ceart agus na dleastanasan clàraichte a choileanadh.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Tilleadh an àireamh de * * dèidh ceumannan a dh'fheumar fhaighinn bho `start` gu `end`.
    ///
    /// A `tilleadh `None` nam biodh an àireamh de cheumannan a` dol thairis air `usize` (no neo-chrìochnach, no mura ruigeadh `end` a-riamh).
    ///
    ///
    /// # Invariants
    ///
    /// Airson `a`, `b`, agus `n` sam bith:
    ///
    /// * `steps_between(&a, &b) == Some(n)` ma `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` ma tha agus dìreach ma `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` a-mhàin ma `a <= b`
    ///   * Co-chnuasachd: `steps_between(&a, &b) == Some(0)` ma tha agus dìreach ma `a == b`
    ///   * Cuimhnich gur `a <= b` Chan _not_ ciallachadh `steps_between(&a, &b) != None`;
    ///     is e seo a `chùis nuair a dh` fheumadh e barrachd air ceumannan `usize::MAX` gus faighinn gu `b`
    /// * `steps_between(&a, &b) == None` ma `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// A 'tilleadh air an luach a bhiodh fhaighinn le bhith a' gabhail an dèidh * * de `self` `count` turas.
    ///
    /// Nam biodh seo a `dol thairis air an raon de luachan le taic bho `Self`, tillidh `None`.
    ///
    /// # Invariants
    ///
    /// Airson sam bith `a`, `n`, agus `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Airson `a`, `n`, agus `m` sam bith far nach eil `n + m` a `cur thairis:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Airson sam bith `a` agus `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// A 'tilleadh air an luach a bhiodh fhaighinn le bhith a' gabhail an dèidh * * de `self` `count` turas.
    ///
    /// Ma bhiodh seo overflow an raon luachan le taic `Self`, a 'ghnìomh seo tha cead ga thoirt panic, Wrap, no saturate.
    ///
    /// Is e an giùlan a thathar a `moladh gu panic nuair a tha dearbhaidhean deasbaid air an comasachadh, agus a bhith a` fighe no a `sùghadh a-mach air dhòigh eile.
    ///
    /// Sàbhailte code cha bu chòir earbsa a chur an ceart giùlan an dèidh overflow.
    ///
    /// # Invariants
    ///
    /// Airson sam bith `a`, `n`, agus `m`, far nach eil overflow a 'tachairt:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Airson sam bith `a` agus `n`, far nach eil overflow a 'tachairt:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// A 'tilleadh air an luach a bhiodh fhaighinn le bhith a' gabhail an dèidh * * de `self` `count` turas.
    ///
    /// # Safety
    ///
    /// Tha e undefined giùlan airson seo obrachadh a overflow an raon luachan le taic `Self`.
    /// Mur urrainn dhut an urras gun chan eil seo overflow, cleachdadh `forward` no `forward_checked` àite.
    ///
    /// # Invariants
    ///
    /// Airson `a` sam bith:
    ///
    /// * ma tha `b` ann mar sin `b > a`, tha e sàbhailte `Step::forward_unchecked(a, 1)` a ghairm
    /// * ma tha ann `b`, `n` leithid a `steps_between(&a, &b) == Some(n)`, tha e sàbhailte a ghairm `Step::forward_unchecked(a, m)` airson sam bith `m <= n`.
    ///
    ///
    /// Airson sam bith `a` agus `n`, far nach eil overflow a 'tachairt:
    ///
    /// * `Step::forward_unchecked(a, n)` 'S e co-ionann ri `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// A 'tilleadh air an luach a bhiodh fhaighinn le bhith a' gabhail na *a bh* de `self` `count` turas.
    ///
    /// Nam biodh seo a `dol thairis air an raon de luachan le taic bho `Self`, tillidh `None`.
    ///
    /// # Invariants
    ///
    /// Airson sam bith `a`, `n`, agus `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Airson sam bith `a` agus `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// A 'tilleadh air an luach a bhiodh fhaighinn le bhith a' gabhail na *a bh* de `self` `count` turas.
    ///
    /// Ma bhiodh seo overflow an raon luachan le taic `Self`, a 'ghnìomh seo tha cead ga thoirt panic, Wrap, no saturate.
    ///
    /// Is e an giùlan a thathar a `moladh gu panic nuair a tha dearbhaidhean deasbaid air an comasachadh, agus a bhith a` fighe no a `sùghadh a-mach air dhòigh eile.
    ///
    /// Sàbhailte code cha bu chòir earbsa a chur an ceart giùlan an dèidh overflow.
    ///
    /// # Invariants
    ///
    /// Airson sam bith `a`, `n`, agus `m`, far nach eil overflow a 'tachairt:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Airson sam bith `a` agus `n`, far nach eil overflow a 'tachairt:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// A 'tilleadh air an luach a bhiodh fhaighinn le bhith a' gabhail na *a bh* de `self` `count` turas.
    ///
    /// # Safety
    ///
    /// Tha e undefined giùlan airson seo obrachadh a overflow an raon luachan le taic `Self`.
    /// Mur urrainn dhut an urras gun chan eil seo overflow, cleachdadh `backward` no `backward_checked` àite.
    ///
    /// # Invariants
    ///
    /// Airson `a` sam bith:
    ///
    /// * ma tha a leithid ann `b` `b < a`, tha e sàbhailte a ghairm `Step::backward_unchecked(a, 1)`
    /// * ma tha ann `b`, `n` leithid a `steps_between(&b, &a) == Some(n)`, tha e sàbhailte a ghairm `Step::backward_unchecked(a, m)` airson sam bith `m <= n`.
    ///
    ///
    /// Airson sam bith `a` agus `n`, far nach eil overflow a 'tachairt:
    ///
    /// * `Step::backward_unchecked(a, n)` tha e co-ionann ri `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Tha iad sin fhathast air an gineadh le macro seach gu bheil na litrichean integer a `fuasgladh gu diofar sheòrsaichean.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn nach bi `start + n` a `cur thairis.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // Sàbhailteachd: an neach-conaltraidh a tha air barantas gun `start - n` chan eil overflow.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Ann an togail deasbaid, brosnaich panic air tar-sruthadh.
            // Bu chòir seo a bharrachadh tur a-mach ann an naidheachd a 'togail.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Do wrapping math gus cothrom a thoirt me `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Ann an togail deasbaid, brosnaich panic air tar-sruthadh.
            // Bu chòir seo a bharrachadh tur a-mach ann an naidheachd a 'togail.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Do wrapping math gus cothrom a thoirt me `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Tha seo a 'crochadh air $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // ma tha n a-mach à raon, tha `unsigned_start + n` cuideachd
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // ma tha e 'n a-mach à raon, `unsigned_start - n` e ro
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Tha seo a 'crochadh air $i_narrower <=usize
                        //
                        // Casting isize a 'sìneadh a leud ach a' gleidheadh an t-soidhne.
                        // Cleachdaidh wrapping_sub isize ann an rùm agus an leagh gu usize a thomhas an diofar a dh'fhaodadh nach eil e freagarrach taobh a-staigh an raon de isize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Wrapping làmhan cùisean mar `Step::forward(-120_i8, 200) == Some(80_i8)`, ged a tha 200 a-mach à raon airson i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Cur thairis
                            }
                        }
                        // Ma tha n a-mach à raon me
                        // u8, an uairsin tha e nas motha na tha an raon iomlan airson i8 farsaing agus mar sin is dòcha gu bheil `any_i8 + n` a `dol thairis air i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Wrapping làmhan cùisean mar `Step::forward(-120_i8, 200) == Some(80_i8)`, ged a tha 200 a-mach à raon airson i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Toirt air falbh cus
                            }
                        }
                        // Ma tha n a-mach à raon me
                        // u8, an uairsin tha e nas motha na tha an raon iomlan airson i8 farsaing agus mar sin is dòcha gu bheil `any_i8 - n` a `dol thairis air i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Ma tha eadar-dhealachadh ro mhòr airson me
                            // i128, tha e cuideachd a 'gonna a bhith ro mhòr airson usize le nas lugha de na pìosan.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // Sàbhailteachd: Dreuchdan RES tha dligheach Unicode scalar
            // (Gu h-ìosal 0x110000 agus chan ann 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // Sàbhailteachd: Dreuchdan RES tha dligheach Unicode scalar
        // (Gu h-ìosal 0x110000 agus chan ann 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // Sàbhailteachd: Feumaidh an neach-conaltraidh barantachadh nach eil seo a overflow
        // an raon de luachan airson char.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // Sàbhailteachd: Feumaidh an neach-conaltraidh barantachadh nach eil seo a overflow
            // an raon de luachan airson char.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // Sàbhailteachd: a chionn an cùmhnant roimhe, tha seo a ghealltainn
        // leis an neach-conaltraidh a bhith dligheach char.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // Sàbhailteachd: Feumaidh an neach-conaltraidh barantachadh nach eil seo a overflow
        // an raon de luachan airson char.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // Sàbhailteachd: Feumaidh an neach-conaltraidh barantachadh nach eil seo a overflow
            // an raon de luachan airson char.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // Sàbhailteachd: a chionn an cùmhnant roimhe, tha seo a ghealltainn
        // leis an neach-conaltraidh a bhith dligheach char.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // SÀBHAILTEACHD: dìreach Cheartaich precondition
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // SÀBHAILTEACHD: dìreach Cheartaich precondition
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Tha iad sin a ghineadh macros `ExactSizeIterator` impls airson diofar sheòrsaichean raon.
//
// * `ExactSizeIterator::len` Tha feum an-còmhnaidh a 'tilleadh dhachaigh an dearbh `usize`, mar sin chan eil an raon faodaidh e bhith nas fhaide na `usize::MAX`.
//
// * Airson sheòrsaichean integer ann `Range<_>` e seo a 'chùis airson na seòrsachan chumhainge no mar farsaing mar `usize`.
//   Airson sheòrsaichean integer ann `RangeInclusive<_>` e seo a 'chùis airson seòrsaichean *teann chumhainge* na `usize` bho me
//   `(0..=u64::MAX).len()` bhiodh `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Tha iad seo a 'incorect gach reusanachadh gu h-àrd, ach a' toirt air falbh iad a bhiodh a bhrisear atharrachadh mar a bha iad a 'crìonadh ann an Rust 1.0.0.
    // Mar sin me
    // `(0..66_000_u32).len()` Mar eisimpleir, bidh a chur ri chèile gun mhearachd no rabhaidhean air 16-bit àrd-chabhsair, ach a 'cumail oirnn a thoirt thoradh ceàrr.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Tha iad sin neo-sheasmhach a rèir an reusanachaidh gu h-àrd, ach bhiodh toirt air falbh iad mar atharrachadh briseadh oir bha iad air an dèanamh seasmhach ann an Rust 1.26.0.
    // Mar sin me
    // `(0..=u16::MAX).len()` Mar eisimpleir, bidh a chur ri chèile gun mhearachd no rabhaidhean air 16-bit àrd-chabhsair, ach a 'cumail oirnn a thoirt thoradh ceàrr.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // SÀBHAILTEACHD: dìreach Cheartaich precondition
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // SÀBHAILTEACHD: dìreach Cheartaich precondition
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SÀBHAILTEACHD: dìreach Cheartaich precondition
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SÀBHAILTEACHD: dìreach Cheartaich precondition
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SÀBHAILTEACHD: dìreach Cheartaich precondition
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SÀBHAILTEACHD: dìreach Cheartaich precondition
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}