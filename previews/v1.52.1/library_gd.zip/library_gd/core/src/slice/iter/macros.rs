//! Macros air an cleachdadh le itealain de sliseag.

// Tha inlines is_empty agus len a `dèanamh eadar-dhealachadh mòr ann an coileanadh
macro_rules! is_empty {
    // An dòigh anns a bheil sinn a `còdachadh fad itealaiche ZST, bidh seo ag obair an dà chuid airson ZST agus neo-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Gus faighinn cuidhteas cuid de sgrùdaidhean crìochan (faic `position`), bidh sinn a `tomhas an fhaid ann an dòigh rudeigin ris nach robh dùil.
// (Deuchainn le `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // bidh sinn uaireannan air an cleachdadh taobh a-staigh bloc neo-shàbhailte

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Bidh an _cannot_ seo a `cleachdadh `unchecked_sub` oir tha sinn an urra ri pasgadh gus fad itealain sliseag ZST fada a riochdachadh.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Tha fios againn gum faod `start <= end`, mar sin dèanamh nas fheàrr na `offset_from`, a dh `fheumas dèiligeadh ann an soidhnigeadh.
            // Le bhith a `suidheachadh brataichean iomchaidh an seo is urrainn dhuinn seo innse do LLVM, a chuidicheas e le bhith a` toirt air falbh sgrùdaidhean crìochan.
            // SÀBHAILTEACHD: A rèir an seòrsa invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Le bhith ag innse do LLVM cuideachd gu bheil na h-iomlaidean air leth le iomadachadh ceart de mheud an t-seòrsa, faodaidh e `len() == 0` a bharrachadh sìos gu `start == end` an àite `(end - start) < size`.
            //
            // SÀBHAILTEACHD: A rèir an seòrsa invariant, tha na comharran air an aon rèir gus am bi an
            //         feumaidh an astar eatarra a bhith iomadach de mheud puing
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Am mìneachadh co-roinnte de na itealain `Iter` agus `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // A `tilleadh a` chiad eileamaid agus a `gluasad toiseach an iterator air adhart le 1.
        // A `leasachadh coileanadh gu mòr an taca ri gnìomh le loidhne.
        // Chan fhaod an iterator a bhith falamh.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // A `tilleadh an eileamaid mu dheireadh agus a` gluasad deireadh an iterator air ais le 1.
        // A `leasachadh coileanadh gu mòr an taca ri gnìomh le loidhne.
        // Chan fhaod an iterator a bhith falamh.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // A `crìonadh an iterator nuair a tha T na ZST, le bhith a` gluasad deireadh an iterator air ais le `n`.
        // `n` chan fhaod e a bhith nas àirde na `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Gnìomh cuideachaidh airson a bhith a `cruthachadh sliseag bhon iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SÀBHAILTEACHD: chaidh an iterator a chruthachadh bho sliseag le stiùireadh
                // `self.ptr` agus fad `len!(self)`.
                // Tha seo a `barantachadh gum bi na ro-ghoireasan airson `from_raw_parts` air an coileanadh.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Gnìomh cuideachaidh airson toiseach an iterator a ghluasad air adhart le eileamaidean `offset`, a `tilleadh an t-seann thòiseachadh.
            //
            // Neo-shàbhailte oir chan fhaod an fhrith-thionndadh a bhith nas àirde na `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SÀBHAILTEACHD: tha an neach-fios a `gealltainn nach bi `offset` nas àirde na `self.len()`,
                    // mar sin tha am puing ùr seo taobh a-staigh `self` agus mar sin tha e cinnteach gum bi e neo-null.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Gnìomh cuideachaidh airson deireadh an iterator a ghluasad air ais le eileamaidean `offset`, a `tilleadh an deireadh ùr.
            //
            // Neo-shàbhailte oir chan fhaod an fhrith-thionndadh a bhith nas àirde na `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SÀBHAILTEACHD: tha an neach-fios a `gealltainn nach bi `offset` nas àirde na `self.len()`,
                    // a tha cinnteach nach cuir thu thairis air `isize`.
                    // Cuideachd, tha am puing mar thoradh air sin ann an crìochan `slice`, a choileanas na riatanasan eile airson `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // dh'fhaodadh a bhith air a bhuileachadh le sliseagan, ach bidh seo a `seachnadh sgrùdaidhean mu chrìochan

                // SÀBHAILTEACHD: Tha gairmean `assume` sàbhailte bho chomharradh tòiseachaidh sliseag
                // feumaidh iad a bhith neo-null, agus feumaidh comharraiche deireadh neo-null a bhith aig sliseagan thairis air neo-ZST.
                // Tha an gairm gu `next_unchecked!` sàbhailte bhon a nì sinn sgrùdadh a bheil an iterator falamh an-toiseach.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Tha an iterator seo a-nis falamh.
                    if mem::size_of::<T>() == 0 {
                        // Feumaidh sinn a bhith ga dhèanamh air an dòigh seo mar `ptr` dh'fhaodadh a bhith a riamh mar 0, ach a dh'fhaodadh a bhith `end` (sgàth wrapping).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SÀBHAILTEACHD: chan urrainn deireadh a bhith 0 mura h-eil T ZST oir chan eil ptr 0 agus deireadh>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SÀBHAILTEACHD: Tha sinn ann an crìochan.Bidh `post_inc_start` a `dèanamh an rud ceart eadhon airson ZSTs.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Bidh sinn a `dol thairis air a` bhuileachadh bunaiteach, a bhios a `cleachdadh `try_fold`, seach gu bheil am buileachadh sìmplidh seo a` gineadh nas lugha de LLVM IR agus nas luaithe a chur ri chèile.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Bidh sinn a `dol thairis air a` bhuileachadh bunaiteach, a bhios a `cleachdadh `try_fold`, seach gu bheil am buileachadh sìmplidh seo a` gineadh nas lugha de LLVM IR agus nas luaithe a chur ri chèile.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Bidh sinn a `dol thairis air a` bhuileachadh bunaiteach, a bhios a `cleachdadh `try_fold`, seach gu bheil am buileachadh sìmplidh seo a` gineadh nas lugha de LLVM IR agus nas luaithe a chur ri chèile.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Bidh sinn a `dol thairis air a` bhuileachadh bunaiteach, a bhios a `cleachdadh `try_fold`, seach gu bheil am buileachadh sìmplidh seo a` gineadh nas lugha de LLVM IR agus nas luaithe a chur ri chèile.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Bidh sinn a `dol thairis air a` bhuileachadh bunaiteach, a bhios a `cleachdadh `try_fold`, seach gu bheil am buileachadh sìmplidh seo a` gineadh nas lugha de LLVM IR agus nas luaithe a chur ri chèile.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Bidh sinn a `dol thairis air a` bhuileachadh bunaiteach, a bhios a `cleachdadh `try_fold`, seach gu bheil am buileachadh sìmplidh seo a` gineadh nas lugha de LLVM IR agus nas luaithe a chur ri chèile.
            // Cuideachd, bidh an `assume` a `seachnadh sgrùdadh crìochan.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SÀBHAILTEACHD: tha sinn cinnteach gum bi sinn ann an crìochan leis an lùb invariant:
                        // nuair a thilleas `i >= n`, `self.next()` `None` agus a bhriseas an lùb.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Bidh sinn a `dol thairis air a` bhuileachadh bunaiteach, a bhios a `cleachdadh `try_fold`, seach gu bheil am buileachadh sìmplidh seo a` gineadh nas lugha de LLVM IR agus nas luaithe a chur ri chèile.
            // Cuideachd, bidh an `assume` a `seachnadh sgrùdadh crìochan.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SÀBHAILTEACHD: Feumaidh `i` a bhith nas ìsle na `n` bhon a thòisicheas e aig `n`
                        // agus chan eil e ach a `lughdachadh.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gu bheil `i` ann an crìochan
                // an sliseag a tha na bhroinn, agus mar sin chan urrainn do `i` `isize` a thoirt thairis, agus tha cinnt gum bi na h-iomraidhean a chaidh a thilleadh a `toirt iomradh air eileamaid den t-sliseag agus mar sin tha e cinnteach gum bi e dligheach.
                //
                // Thoir fa-near cuideachd gu bheil an neach-fòn cuideachd a `gealltainn nach bi sinn a-riamh air an gairm leis an aon chlàr-amais a-rithist, agus nach eilear a` gairm dòighean sam bith eile a gheibh cothrom air an fho-sgrìobhadh seo, agus mar sin tha e dligheach gum bi an t-iomradh a chaidh a thilleadh so-atharraichte a thaobh
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // dh'fhaodadh a bhith air a bhuileachadh le sliseagan, ach bidh seo a `seachnadh sgrùdaidhean mu chrìochan

                // SÀBHAILTEACHD: Tha gairmean `assume` sàbhailte oir feumaidh comharradh tòiseachaidh sliseag a bhith neo-null,
                // agus feumaidh puing deireadh neo-null a bhith aig sliseagan thairis air neo-ZST.
                // Tha a 'ghairm gu `next_back_unchecked!` e sàbhailte on a tha sinn a' dèanamh cinnteach ma tha an iterator falamh toiseach.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Tha an iterator seo a-nis falamh.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SÀBHAILTEACHD: Tha sinn ann an crìochan.Bidh `pre_dec_end` a `dèanamh an rud ceart eadhon airson ZSTs.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}