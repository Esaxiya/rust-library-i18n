//! Obrachaidhean air ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Dèan cinnteach a bheil a h-uile bytes san t-slice seo taobh a-staigh raon ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// A `dèanamh cinnteach gu bheil dà shliseag mar mhaids cùis-neo-mhothachail ASCII.
    ///
    /// Co-ionann ri `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ach gun a bhith a `riarachadh agus a` dèanamh copaidh de temporaries.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Bidh e ag atharrachadh an t-slice seo chun a `chùis àrd ASCII co-ionnan na àite.
    ///
    /// Tha litrichean ASCII 'a' gu 'z' air am mapadh gu 'A' gu 'Z', ach tha litrichean neo-ASCII gun atharrachadh.
    ///
    /// Gus luach àrd ùr a thilleadh gun a bhith ag atharrachadh an fhear a th `ann, cleachd [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Bidh e ag atharrachadh an t-slice seo chun a `chùis as ìsle aige ASCII.
    ///
    /// Tha litrichean ASCII 'A' gu 'Z' air am mapadh gu 'a' gu 'z', ach tha litrichean neo-ASCII gun atharrachadh.
    ///
    /// Gus luach ùr le ìsleachadh a thoirt air ais gun a bhith ag atharrachadh an fhear a th `ann, cleachd [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// A `tilleadh `true` ma tha byte sam bith san fhacal `v` nonascii (>=128).
/// Snarfed bho `../str/mod.rs`, a tha a `dèanamh rudeigin coltach ri dearbhadh utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Freagarraiche ASCII deuchainn a bhios a 'cleachdadh aig usize-- a-àm obraichean an àite aig Byte-- a-àm obrachaidhean (nuair a ghabhas).
///
/// Tha an algorithm a chleachdas sinn an seo gu math sìmplidh.Ma tha `s` ro ghoirid, bidh sinn dìreach a `sgrùdadh gach byte agus a bhith air a dhèanamh leis.Rud eile:
///
/// - Leugh a `chiad fhacal le luchd gun ainm.
/// - Co-thaobhadh ris a `phuing, leugh faclan às deidh sin gu deireadh le luchdan co-thaobhach.
/// - Leugh an `usize` mu dheireadh bho `s` le luchd gun chomharradh.
///
/// Ma tha gin de na luchdan sin a `toirt a-mach rudeigin a tha `contains_nonascii` (above) a` tilleadh fìor, tha fios againn gu bheil am freagairt meallta.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Mura faigheadh sinn dad bhon bhuileachadh facal-air-àm, tuit air ais gu lùb sgairteil.
    //
    // Bidh sinn cuideachd a `dèanamh seo airson ailtireachd far nach eil `size_of::<usize>()` co-thaobhadh gu leòr airson `usize`, oir is e cùis neònach edge a th` ann.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Bidh sinn an-còmhnaidh a `leughadh a` chiad fhacal gun ainm, a tha a `ciallachadh gu bheil `align_offset`
    // 0, bhiodh sinn air an aon luach a leughadh a-rithist airson an leughadh co-thaobhach.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SÀBHAILTEACHD: Bidh sinn a `dearbhadh `len < USIZE_SIZE` gu h-àrd.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Rinn sinn sgrùdadh air an seo gu h-àrd, gu ìre mhòr.
    // Thoir fa-near gu bheil `offset_to_aligned` an dàrna cuid `align_offset` no `USIZE_SIZE`, tha an dà chuid air an sgrùdadh gu h-àrd.
    //
    debug_assert!(offset_to_aligned <= len);

    // SÀBHAILTEACHD: is e word_ptr am ptr usize (air a cho-thaobhadh gu ceart) a bhios sinn a `cleachdadh airson an
    // pìos meadhain den t-sliseag.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` an clàr-amais byte de `word_ptr`, air a chleachdadh airson sgrùdaidhean deireadh lùb.
    let mut byte_pos = offset_to_aligned;

    // Thoir sùil air Paranoia mu cho-thaobhadh, oir tha sinn gu bhith a `dèanamh dòrlach de luchdan gun ainm.
    // Ann an cleachdadh bu chòir seo a bhith do-dhèanta casg a chuir air biast ann an `align_offset` ge-tà.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Leugh faclan às deidh sin gus am bi am facal mu dheireadh co-thaobhach, ach a-mhàin am facal mu dheireadh air a cho-thaobhadh leis fhèin ri dhèanamh ann an sgrùdadh earball nas fhaide air adhart, gus dèanamh cinnteach gu bheil earball an-còmhnaidh mar aon `usize` aig a `char as motha gu branch `byte_pos == len` a bharrachd.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Dèan cinnteach gu bheil an leughadh ann an crìochan
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Agus gu bheil na barailean againn mu `byte_pos` a `cumail.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SÀBHAILTEACHD: Tha fios againn gu bheil `word_ptr` air a cho-thaobhadh gu ceart (air sgàth
        // `align_offset`), agus tha fios againn gu bheil gu leòr bytes againn eadar `word_ptr` agus an deireadh
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SÀBHAILTEACHD: Tha fios againn gu bheil `byte_pos <= len - USIZE_SIZE`, a tha a `ciallachadh sin
        // às deidh an `add` seo, bidh `word_ptr` aig a `char as motha aon-uair-an-deireadh.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Sgrùdadh slàintealachd gus dèanamh cinnteach nach eil ach aon `usize` air fhàgail.
    // Bu chòir seo a bhith cinnteach le ar suidheachadh lùb.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SÀBHAILTEACHD: Tha seo an urra ri `len >= USIZE_SIZE`, a bhios sinn a `sgrùdadh aig an toiseach.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}