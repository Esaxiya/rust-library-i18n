//! Dreuchdan an-asgaidh gus `&[T]` agus `&mut [T]` a chruthachadh.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// A `cruthachadh sliseag bho stiùireadh agus faid.
///
/// Is e an argamaid `len` an àireamh de **eileamaidean**, chan e an àireamh de bytes.
///
/// # Safety
///
/// Giùlan undefined ma tha gin de na cumhaichean a leanas a tha air an truailleadh:
///
/// * `data` feumaidh [valid] a bhith ann airson leughaidhean airson `len * mem::size_of::<T>()` mòran bytes, agus feumaidh e a bhith air a cho-thaobhadh gu ceart.Tha seo a `ciallachadh gu sònraichte:
///
///     * Feumaidh an raon cuimhne gu lèir den t-slice seo a bhith taobh a-staigh aon nì a chaidh a riarachadh!
///       Chan urrainn dha sliseagan a dhol thairis air iomadh rud a chaidh a riarachadh.Faic [below](#incorrect-usage) airson eisimpleir gu ceàrr gun a bhith a `toirt aire don seo.
///     * `data` feumaidh iad a bhith neo-null agus co-thaobhach eadhon airson sliseagan de dh'fhaid neoni.
///     Is e aon adhbhar airson seo gum faod optimachadh cruth enum a bhith an urra ri iomraidhean (a `toirt a-steach sliseagan de dh` fhaid sam bith) a bhith air an aon rèir agus neo-null gus an eadar-dhealachadh bho dàta eile.
///     Gheibh thu stiùireadh a ghabhas cleachdadh mar `data` airson sliseagan de dh'fhaid neoni a `cleachdadh [`NonNull::dangling()`].
///
/// * `data` feumaidh iad a bhith a `comharrachadh luachan leantainneach `len` leantainneach de sheòrsa `T`.
///
/// * Chan fhaodar a `chuimhne a tha air a chomharrachadh leis an t-sliseag a thilleadh a bhith air a thionndadh fad beatha `'a`, ach taobh a-staigh `UnsafeCell`.
///
/// * Chan fhaod meud iomlan `len * mem::size_of::<T>()` an t-sliseag a bhith nas motha na `isize::MAX`.
///   Faic sgrìobhainnean sàbhailteachd [`pointer::offset`].
///
/// # Caveat
///
/// Tha beatha an t-sliseag a chaidh a thilleadh air a chleachdadh bho bhith ga chleachdadh.
/// Gus casg a chuir air mì-chleachdadh gun fhiosta, thathas a `moladh a bhith a` ceangal fad-beatha ri ge bith dè an tùs stòr a tha sàbhailte sa cho-theacsa, mar eisimpleir le bhith a `toirt seachad gnìomh neach-cuideachaidh a` toirt fad beatha luach aoigheachd airson an t-sliseag, no le bhith a `mothachadh gu soilleir.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // nochdadh sliseag airson aon eileamaid
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Cleachdadh ceàrr
///
/// Tha an gnìomh `join_slices` a leanas **mì-chinnteach** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Tha an dearbhadh gu h-àrd a `dèanamh cinnteach gu bheil `fst` agus `snd` ceangailte ri chèile, ach dh` fhaodadh iad a bhith fhathast taobh a-staigh _different allocated objects_, agus sa chùis seo tha cruthachadh an t-sliseag seo na ghiùlan neo-mhìnichte.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` agus `b` nan diofar nithean air an riarachadh ...
///     let a = 42;
///     let b = 27;
///     // ... a dh `fhaodadh sin a bhith air a chuir a-mach faisg air làimh mar chuimhneachan: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `from_raw_parts` a chumail suas.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// A `dèanamh an aon seòrsa gnìomh ri [`from_raw_parts`], ach a-mhàin gu bheil sliseag gluasadach air a thilleadh.
///
/// # Safety
///
/// Giùlan undefined ma tha gin de na cumhaichean a leanas a tha air an truailleadh:
///
/// * `data` feumaidh iad a bhith [valid] airson an dà chuid leughadh agus a sgrìobhadh airson `len * mem::size_of::<T>()` mòran bytes, agus feumaidh e bhith gu ceart a rèir a chèile.Tha seo a `ciallachadh gu sònraichte:
///
///     * Feumaidh an raon cuimhne gu lèir den t-slice seo a bhith taobh a-staigh aon nì a chaidh a riarachadh!
///       Chan urrainn dha sliseagan a dhol thairis air iomadh rud a chaidh a riarachadh.
///     * `data` feumaidh iad a bhith neo-null agus co-thaobhach eadhon airson sliseagan de dh'fhaid neoni.
///     Is e aon adhbhar airson seo gum faod optimachadh cruth enum a bhith an urra ri iomraidhean (a `toirt a-steach sliseagan de dh` fhaid sam bith) a bhith air an aon rèir agus neo-null gus an eadar-dhealachadh bho dàta eile.
///
///     Gheibh thu stiùireadh a ghabhas cleachdadh mar `data` airson sliseagan de dh'fhaid neoni a `cleachdadh [`NonNull::dangling()`].
///
/// * `data` feumaidh iad a bhith a `comharrachadh luachan leantainneach `len` leantainneach de sheòrsa `T`.
///
/// * Chan fhaodar faighinn a-steach don chuimhne air a bheil iomradh aig an t-sliseag a chaidh a thilleadh tro chomharradh sam bith eile (nach eil a `tighinn bhon luach toraidh) fad beatha `'a`.
///   Tha an dà chuid leughadh agus sgrìobhadh toirmisgte.
///
/// * Chan fhaod meud iomlan `len * mem::size_of::<T>()` an t-sliseag a bhith nas motha na `isize::MAX`.
///   Faic sgrìobhainnean sàbhailteachd [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `from_raw_parts_mut` a chumail suas.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Bidh e ag atharrachadh iomradh air T gu sliseag de dh'fhaid 1 (gun a bhith a `dèanamh copaidh).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Bidh e ag atharrachadh iomradh air T gu sliseag de dh'fhaid 1 (gun a bhith a `dèanamh copaidh).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}