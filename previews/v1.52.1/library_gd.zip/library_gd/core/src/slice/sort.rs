//! A `rèiteach sliseagan
//!
//! Anns a `mhodal seo tha algorithm seòrsachaidh stèidhichte air quicksort a` chùis air pàtran Orson Peters, a chaidh fhoillseachadh aig: <https://github.com/orlp/pdqsort>
//!
//!
//! Tha rèiteachadh neo-sheasmhach co-chòrdail ri libcore oir chan eil e a `riarachadh cuimhne, eu-coltach ris a` bhuileachadh seòrsachaidh seasmhach againn.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Nuair a thuit e, dèan lethbhric bho `src` a-steach do `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SÀBHAILTEACHD: Seo clas cuideachaidh.
        //          Thoir sùil air an cleachdadh airson ceart.
        //          Gu dearbh, feumaidh aon a bhith cinnteach nach eil `src` agus `dst` a `dol thairis air mar a tha riatanach le `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Gnothaichean a 'gluasad a' chiad eileamaid air an làimh dheis gus an theannas barrachd eileamaid no co-ionnan.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SÀBHAILTEACHD: Tha na h-obraichean neo-shàbhailte gu h-ìosal a `toirt a-steach clàr-amais gun sgrùdadh ceangailte (`get_unchecked` agus `get_unchecked_mut`)
    // agus a `dèanamh lethbhreac de chuimhne (`ptr::copy_nonoverlapping`).
    //
    // a.Inneacsadh:
    //  1. Rinn sinn sgrùdadh air meud an raon gu>=2.
    //  2. A h-uile comharrachadh a nì sinn e daonnan eadar {0 <= index < len} aig a 'chuid as motha.
    //
    // b.Copaidh cuimhne
    //  1. Tha sinn a `faighinn stiùireadh airson teisteanasan a tha cinnteach a bhith dligheach.
    //  2. Chan urrainn dhaibh a dhol thairis air a chèile leis gu bheil sinn a `faighinn stiùireadh gu clàran eadar-dhealachaidh den t-slice.
    //     Gu dearbh, `i` agus `i-1`.
    //  3. Ma tha an sliseag air a cho-thaobhadh gu ceart, tha na h-eileamaidean air an co-thaobhadh gu ceart.
    //     Tha e an urra ris an neach-fòn dèanamh cinnteach gu bheil an sliseag air a cho-thaobhadh gu ceart.
    //
    // Faic na beachdan gu h-ìosal airson tuilleadh fiosrachaidh.
    unsafe {
        // Ma tha a 'chiad dà-eileamaidean a tha a-mach às an òrdugh ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Leugh a `chiad eileamaid ann an caochladair air a riarachadh le stac.
            // Ma leanas coimeas obrachadh panics, `hole` gum faigh a 'tuiteam agus gu fèin-obrachail a' sgrìobhadh an eileamaid ais dhan sliseag.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Gluais `i`-th eileamaid aon àite air an taobh chlì, agus mar sin a 'gluasad an toll air dheas.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` a `tuiteam agus mar sin a` dèanamh leth-bhreac de `tmp` a-steach don toll a tha air fhàgail ann an `v`.
        }
    }
}

/// Gluais an eileamaid mu dheireadh air an taobh chlì gus an coinnich e ri eileamaid nas lugha no co-ionann.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SÀBHAILTEACHD: Tha na h-obraichean neo-shàbhailte gu h-ìosal a `toirt a-steach clàr-amais gun sgrùdadh ceangailte (`get_unchecked` agus `get_unchecked_mut`)
    // agus a `dèanamh lethbhreac de chuimhne (`ptr::copy_nonoverlapping`).
    //
    // a.Inneacsadh:
    //  1. Rinn sinn sgrùdadh air meud an raon gu>=2.
    //  2. Tha a h-uile clàr-amais a nì sinn an-còmhnaidh eadar `0 <= index < len-1` aig a `char as motha.
    //
    // b.Copaidh cuimhne
    //  1. Tha sinn a `faighinn stiùireadh airson teisteanasan a tha cinnteach a bhith dligheach.
    //  2. Chan urrainn dhaibh a dhol thairis air a chèile leis gu bheil sinn a `faighinn stiùireadh gu clàran eadar-dhealachaidh den t-slice.
    //     Gu dearbh, `i` agus `i+1`.
    //  3. Ma tha an sliseag air a cho-thaobhadh gu ceart, tha na h-eileamaidean air an co-thaobhadh gu ceart.
    //     Tha e an urra ris an neach-fòn dèanamh cinnteach gu bheil an sliseag air a cho-thaobhadh gu ceart.
    //
    // Faic na beachdan gu h-ìosal airson tuilleadh fiosrachaidh.
    unsafe {
        // Ma tha an dà eileamaid mu dheireadh a-mach à òrdugh ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Leugh an eileamaid mu dheireadh ann an caochladair air a riarachadh le stac.
            // Ma leanas coimeas obrachadh panics, `hole` gum faigh a 'tuiteam agus gu fèin-obrachail a' sgrìobhadh an eileamaid ais dhan sliseag.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Gluais `i`-mh eileamaid aon àite air an làimh dheis, mar sin a 'gluasad dhan toll airson an làimh chlì.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` a `tuiteam agus mar sin a` dèanamh leth-bhreac de `tmp` a-steach don toll a tha air fhàgail ann an `v`.
        }
    }
}

/// Gu ìre a `rèiteachadh sliseag le bhith a` gluasad grunn eileamaidean a-mach à òrdugh timcheall.
///
/// A `tilleadh `true` ma thèid an sliseag a sheòrsachadh aig an deireadh.Tha seo a dhreuchd *O*(*n*) a bu mhiosa a-chùis.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // An àireamh as motha de chàraidean taobh a-muigh òrdugh a thèid a ghluasad.
    const MAX_STEPS: usize = 5;
    // Ma tha an sliseag nas giorra na seo, na gluais eileamaidean sam bith.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SÀBHAILTEACHD: Rinn sinn an sgrùdadh ceangailte le `i < len` mu thràth.
        // Chan eil a h-uile clàr-amais às deidh sin ach anns an raon `0 <= index < len`
        unsafe {
            // Lorg an ath phaidhir de eileamaidean taobh a-muigh òrdugh.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // A bheil sinn air a dhèanamh?
        if i == len {
            return true;
        }

        // Na gluais eileamaidean air arrays goirid, tha cosgais coileanaidh ann.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Swap am paidhir eileamaidean a chaidh a lorg.Tha seo gan cur ann an òrdugh cheart.
        v.swap(i - 1, i);

        // Gluais an eileamaid nas lugha air chlì.
        shift_tail(&mut v[..i], is_less);
        // Gluais an eileamaid as motha chun taobh cheart.
        shift_head(&mut v[i..], is_less);
    }

    // Cha deach againn air an sliseag a rèiteach anns an àireamh bheag de cheumannan.
    false
}

/// Deasaich sliseag le bhith a `cleachdadh seòrsa cuir a-steach, agus sin an cùis as miosa *O*(*n*^ 2).
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Deasaich `v` a `cleachdadh heapsort, a tha a` gealltainn *O*(*n*\*log(* n*)) cùis as miosa.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Tha an dùn binary seo a `toirt urram don invariant `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Clann `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Tagh am pàiste as motha.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Stad ma chumas an invariant aig `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Inns `node` le barrachd na leanabh, a 'gluasad aon cheum sìos, agus a' leantainn a 'criathradh.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Tog an dùn ann an ùine shreathach.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop eileamaidean as àirde bhon tiùrr.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Pàirtean `v` gu eileamaidean nas lugha na `pivot`, air a leantainn le eileamaidean nas motha na no co-ionann ri `pivot`.
///
///
/// A `tilleadh an àireamh de eileamaidean nas lugha na `pivot`.
///
/// Tha roinneadh air a dhèanamh bloc-às-bloc gus cosgais obair branrach a lughdachadh.
/// Tha am beachd seo air a thaisbeanadh sa phàipear [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Àireamh de eileamaidean ann am bloc àbhaisteach.
    const BLOCK: usize = 128;

    // Bidh an algorithm sgaradh a `dèanamh na ceumannan a leanas a-rithist gus an tèid a chrìochnachadh:
    //
    // 1. Lorg bloc bhon taobh chlì gus eileamaidean nas motha na no co-ionann ris a `pivot a chomharrachadh.
    // 2. Lorg bloc bhon taobh cheart gus eileamaidean nas lugha na am pivot a chomharrachadh.
    // 3. Dèan iomlaid air na h-eileamaidean comharraichte eadar an taobh chlì agus an taobh cheart.
    //
    // Bidh sinn a `cumail na caochladairean a leanas airson bloc de eileamaidean:
    //
    // 1. `block` - Àireamh de eileamaidean anns a `bhloc.
    // 2. `start` - Tòisich a `stiùireadh a-steach don raon `offsets`.
    // 3. `end` - Cuir crìoch air a `phuing a-steach don raon `offsets`.
    // 4. `cuir dheth, Clàr-amais de eileamaidean taobh a-muigh òrdugh taobh a-staigh a` bhloc.

    // Am bloc gnàthach air an taobh chlì (bho `l` gu `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Am bloc gnàthach air an taobh cheart (bho `r.sub(block_r)` to `r`).
    // SÀBHAILTEACHD: Tha na sgrìobhainnean airson .add() ag ainmeachadh gu sònraichte gu bheil `vec.as_ptr().add(vec.len())` an-còmhnaidh sàbhailte`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Nuair a gheibh sinn VLAn, feuch ri aon sreath de dh'fhaid `min(v.len(), 2 * BLOCK) a chruthachadh
    // na dà eagar meud stèidhichte de dh'fhaid `BLOCK`.Is dòcha gum bi VLAn nas èifeachdaiche le tasgadan.

    // A `tilleadh an àireamh de eileamaidean eadar molaidhean `l` (inclusive) agus `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Tha sinn air a dhèanamh le bhith a `roinneadh bloc-by-block nuair a thig `l` agus `r` gu math faisg.
        // An uairsin bidh sinn a `dèanamh beagan obair glacaidh gus na h-eileamaidean a tha air fhàgail a roinn.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Àireamh fhàgail eileamaidean (fhathast nach eil an coimeas ris a 'lùbadh air lùdag).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Atharraich meudan blocaichean gus nach bi am bloc clì is deas a `dol an lùib a chèile, ach gum faigh iad co-thaobhadh gu foirfe gus am beàrn iomlan a tha air fhàgail a chòmhdach.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Trace `block_l` eileamaidean bhon taobh chlì.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SÀBHAILTEACHD: Tha na h-obraichean neo-shàbhailteachd gu h-ìosal a `toirt a-steach cleachdadh an `offset`.
                //         A rèir nan cumhachan a tha riatanach leis a `ghnìomh, bidh sinn gan sàsachadh air sgàth:
                //         1. `offsets_l` air a riarachadh le stac, agus mar sin air a mheas mar nì air leth.
                //         2. Bidh an gnìomh `is_less` a `tilleadh `bool`.
                //            Cha tilgeadh `bool` a-riamh thairis air `isize`.
                //         3. Tha sinn air gealltainn gum bi `block_l` mar `<= BLOCK`.
                //            A bharrachd air an sin, chaidh `end_l` a shuidheachadh an toiseach gu comharradh tòiseachaidh `offsets_` a chaidh ainmeachadh air a `chruach.
                //            Mar sin, tha fios againn, eadhon anns a `chùis as miosa (bidh a h-uile cuireadh de `is_less` a` tilleadh meallta) nach bi sinn ach aig a `char as motha 1 byte a` dol seachad air an deireadh.
                //        Another unsafety obrachadh a tha seo dereferencing `elem`.
                //        Ach, b `e `elem` an toiseach a` phuing tòiseachaidh don t-sliseag a tha an-còmhnaidh dligheach.
                unsafe {
                    // Branchless coimeas.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Lorg eileamaidean `block_r` bhon taobh cheart.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SÀBHAILTEACHD: Tha na h-obraichean neo-shàbhailteachd gu h-ìosal a `toirt a-steach cleachdadh an `offset`.
                //         A rèir nan cumhachan a tha riatanach leis a `ghnìomh, bidh sinn gan sàsachadh air sgàth:
                //         1. `offsets_r` air a riarachadh le stac, agus mar sin air a mheas mar nì air leth.
                //         2. Bidh an gnìomh `is_less` a `tilleadh `bool`.
                //            Cha tilgeadh `bool` a-riamh thairis air `isize`.
                //         3. Tha sinn air gealltainn gum bi `block_r` mar `<= BLOCK`.
                //            A bharrachd air an sin, chaidh `end_r` a shuidheachadh an toiseach gu comharradh tòiseachaidh `offsets_` a chaidh ainmeachadh air a `chruach.
                //            Mar sin, tha fios againn gur fiù 's ann as miosa ceangailte (a h-uile orrthachan de `is_less` tilleadh fìor) bidh sinn a-mhàin a bhith aig a' mhòr chuid 1 Byte seachad an deireadh.
                //        Another unsafety obrachadh a tha seo dereferencing `elem`.
                //        Ach, bha `elem` an toiseach `1 *sizeof(T)` seachad air an deireadh agus bidh sinn ga lughdachadh le `1* sizeof(T)` mus faigh thu cothrom air.
                //        A bharrachd air an sin, chaidh a ràdh gu robh `block_r` nas lugha na `BLOCK` agus mar sin bidh `elem` aig a `char as motha a` comharrachadh toiseach an t-sliseag.
                unsafe {
                    // Branchless coimeas.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Àireamh de eileamaidean a-mach à òrdugh airson gluasad eadar an taobh chlì agus an taobh cheart.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // An àite a bhith ag atharrachadh aon phaidhir aig an àm, tha e nas èifeachdaiche permutation cearcallach a dhèanamh.
            // Chan eil seo gu tur co-ionann ri iomlaid, ach tha e a `toirt toradh coltach ris a` cleachdadh nas lugha de ghnìomhachd cuimhne.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Chaidh a h-uile eileamaid taobh a-muigh òrdugh anns a `bhloc chlì a ghluasad.Gluais chun ath bhloc.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Na h-uile a-mach às an òrdugh na h-eileamaidean ann an làimh dheis an loga bacaidh a ghluasad.Gluais chun bhloc roimhe.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Na h-uile a tha air fhàgail a-nis aig a 'chuid as motha aon bhloc (an dara cuid an taobh clì no deas) le mach-à-òrdugh eileamaidean a dh'fheumas a bhith air a ghluasad.
    // Faodar na h-eileamaidean a tha air fhàgail a ghluasad dìreach chun deireadh taobh a-staigh am bloc aca.
    //

    if start_l < end_l {
        // Tha am bloc clì fhathast.
        // Gluais na h-eileamaidean taobh a-muigh òrdugh aige chun fhìor làimh dheis.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Tha am bloc ceart fhathast.
        // Gluais na h-eileamaidean a-mach à òrdugh chun taobh chlì.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Chan eil dad eile ri dhèanamh, tha sinn air a dhèanamh.
        width(v.as_mut_ptr(), l)
    }
}

/// Ballachan-tarsainn `v` a-steach eileamaidean nas lugha na `v[pivot]`, air a leantainn le eileamaidean nas mò na, no co-ionnan ri `v[pivot]`.
///
///
/// A 'tilleadh a tuple air:
///
/// 1. Àireamh de eileamaidean nas lugha na `v[pivot]`.
/// 2. Fìor ma chaidh `v` a sgaradh mu thràth.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Cuir am pivot aig toiseach sliseag.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Leugh am pivot gu caochladair air a riarachadh le stac airson èifeachdas.
        // Ma tha gnìomhachd coimeas a leanas panics, thèid am pivot a sgrìobhadh air ais gu fèin-ghluasadach san t-sliseag.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Lorg a `chiad paidhir de eileamaidean a-mach à òrdugh.
        let mut l = 0;
        let mut r = v.len();

        // SÀBHAILTEACHD: Tha an neo-shàbhailteachd gu h-ìosal a `toirt a-steach clàr-amais a dhèanamh.
        // Airson a `chiad fhear: Bidh sinn mu thràth a` dèanamh sgrùdadh air an seo le `l < r`.
        // Airson an dàrna fear: Tha `l == 0` agus `r == v.len()` againn an toiseach agus rinn sinn sgrùdadh air an `l < r` sin aig a h-uile gnìomhachd clàr-amais.
        //                     Às an seo tha fios againn gum feum `r` a bhith co-dhiù `r == l` a chaidh a dhearbhadh gu robh e dligheach bhon chiad fhear.
        unsafe {
            // Lorg a `chiad eileamaid nas motha na no co-ionann ris a` pivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Lorg an eileamaid mu dheireadh nas lugha na am pivot.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` a `dol a-mach à farsaingeachd agus a` sgrìobhadh am pivot (a tha na chaochlaidiche air a riarachadh le cruachan) air ais don t-sliseag far an robh e bho thùs.
        // Tha an ceum seo deatamach ann a bhith a `dèanamh cinnteach à sàbhailteachd!
        //
    };

    // Cuir am pivot eadar an dà sgaradh.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Pàirtean `v` gu eileamaidean co-ionann ri `v[pivot]` agus an uairsin eileamaidean nas motha na `v[pivot]`.
///
/// A `tilleadh àireamh nan eileamaidean a tha co-ionann ris a` pivot.
/// Thathas a `gabhail ris nach eil eileamaidean nas lugha na am pivot ann an `v`.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Cuir am pivot aig toiseach sliseag.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Leugh am pivot gu caochladair air a riarachadh le stac airson èifeachdas.
    // Ma tha gnìomhachd coimeas a leanas panics, thèid am pivot a sgrìobhadh air ais gu fèin-ghluasadach san t-sliseag.
    // SÀBHAILTEACHD: Tha am puing an seo dligheach oir gheibhear e bho iomradh air sliseag.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // A-nis sgaradh an slice.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SÀBHAILTEACHD: Tha an neo-shàbhailteachd gu h-ìosal a `toirt a-steach clàr-amais a dhèanamh.
        // Airson a `chiad fhear: Bidh sinn mu thràth a` dèanamh sgrùdadh air an seo le `l < r`.
        // Airson an dàrna fear: Tha `l == 0` agus `r == v.len()` againn an toiseach agus rinn sinn sgrùdadh air an `l < r` sin aig a h-uile gnìomhachd clàr-amais.
        //                     Às an seo tha fios againn gum feum `r` a bhith co-dhiù `r == l` a chaidh a dhearbhadh gu robh e dligheach bhon chiad fhear.
        unsafe {
            // Lorg a `chiad eileamaid nas motha na am pivot.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Lorg an eileamaid mu dheireadh co-ionann ris a 'lùbadh air lùdag.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // A bheil sinn air a dhèanamh?
            if l >= r {
                break;
            }

            // Inns 'an lorg paidhir a-mach às an òrdugh eileamaidean.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Lorg sinn eileamaidean `l` co-ionann ris a `pivot.Cuir 1 ris airson a`pivot fhèin.
    l + 1

    // `_pivot_guard` a `dol a-mach à farsaingeachd agus a` sgrìobhadh am pivot (a tha na chaochlaidiche air a riarachadh le cruachan) air ais don t-sliseag far an robh e bho thùs.
    // Tha an ceum seo deatamach ann a bhith a `dèanamh cinnteach à sàbhailteachd!
}

/// A `sgapadh cuid de na h-eileamaidean timcheall ann an oidhirp pàtranan a bhriseadh a dh` fhaodadh a bhith ag adhbhrachadh sgaradh mì-chothromach ann an quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Gineadair àireamh pseudorandom bhon phàipear "Xorshift RNGs" le George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Gabh modulo àireamhan air thuaiream an àireamh seo.
        // Tha an àireamh a `freagairt ri `usize` oir chan eil `len` nas motha na `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Bidh cuid de thagraichean pivot faisg air a `chlàr-innse seo.Bheir sinn air thuaiream iad.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Cruthaich modulo àireamh air thuaiream `len`.
            // Ach, gus obrachaidhean cosgail a sheachnadh bidh sinn an toiseach a `toirt cumhachd de dhà dha modulo, agus an uairsin a` lughdachadh le `len` gus am bi e a `freagairt a-steach don raon `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` tha e cinnteach gum bi e nas ìsle na `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// A `taghadh pivot ann an `v` agus a` tilleadh an clàr-amais agus `true` ma tha coltas ann gu bheil an sliseag air a sheòrsachadh mu thràth.
///
/// Faodar eileamaidean ann an `v` ath-òrdachadh sa phròiseas.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // An fhad as lugha airson an dòigh meadhan-mheadhain a thaghadh.
    // Bidh sliseagan nas giorra a `cleachdadh an dòigh meadhan-trì sìmplidh.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // An àireamh as motha de suaipichean a ghabhas dèanamh san ghnìomh seo.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Trì clàran-amais faisg air a bheil sinn a `dol a thaghadh pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // A `cunntadh an àireamh iomlan de suaipean a tha sinn an dùil a dhèanamh fhad` s a bhios sinn a `rèiteach chlàran.
    let mut swaps = 0;

    if len >= 8 {
        // Ag atharrachadh clàran-amais gus am bi `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Ag atharrachadh clàran-amais gus am bi `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // A `lorg meadhan `v[a - 1], v[a], v[a + 1]` agus a` stòradh a `chlàr-amais gu `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Lorg meadhan-aoisean ann an nàbachdan `a`, `b`, agus `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Lorg am meadhan am measg `a`, `b`, agus `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Chaidh an àireamh as motha de iomlaid a dhèanamh.
        // Cothroman a tha an slios tha 'teàrnadh no' mhòr-chuid a 'teàrnadh, mar sin bidh' s dòcha an ath-thilleadh a 'cuideachadh seòrsa e nas luaithe.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Seòrsaichean `v` gu ath-chuairteachail.
///
/// Ma bha ro-shealladh aig an t-slice san t-sreath thùsail, tha e air a chomharrachadh mar `pred`.
///
/// `limit` 'S e an àireamh de cead imbalanced ballachan-tarsainn mus atharrachadh gu `heapsort`.
/// Ma neoni, a 'ghnìomh seo a' bhad atharrachadh gu heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Thèid sliseagan suas ris an fhad seo a sheòrsachadh le bhith a `cleachdadh seòrsa cuir a-steach.
    const MAX_INSERTION: usize = 20;

    // Fìor ma bha an sgaradh mu dheireadh air a chothromachadh gu reusanta.
    let mut was_balanced = true;
    // Fìor mura h-eil an sgaradh mu dheireadh a `crathadh eileamaidean (bha an sliseag air a sgaradh mu thràth).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Bidh sliseagan glè ghoirid gan rèiteachadh le bhith a `cleachdadh seòrsa cuir a-steach.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Nam biodh cus de dhroch roghainnean pivot air an dèanamh, dìreach tuiteam air ais gu heapsort gus barrantas a thoirt don chùis as miosa de `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Nam biodh an sgaradh mu dheireadh air a chothromachadh, feuch pàtranan a bhriseadh san t-sliseag le bhith a `cur cuid de na h-eileamaidean timcheall.
        // Tha sinn an dòchas gun tagh sinn pivot nas fheàrr an turas seo.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Tagh pivot agus feuch ri tomhas a bheil an sliseag air a sheòrsachadh mu thràth.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Nam biodh an sgaradh mu dheireadh air a chothromachadh gu cothromach agus nach do shuidhich e eileamaidean, agus ma tha taghadh pivot a `dèanamh a-mach tha e coltach gum bi an sliseag air a sheòrsachadh mar-thà ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Feuch ri grunn eileamaidean a-mach à òrdugh a chomharrachadh agus an gluasad gu suidheachaidhean ceart.
            // Ma thig an sliseag gu crìch le bhith air a sheòrsachadh gu tur, bidh sinn air a dhèanamh.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Ma tha am pivot a chaidh a thaghadh co-ionann ris an ro-shealladh, is e sin an eileamaid as lugha san t-sliseag.
        // Roinneadh an sliseag gu eileamaidean co-ionann ri agus eileamaidean nas motha na am pivot.
        // Mar as trice bidh a `chùis seo air a bhualadh nuair a tha mòran eileamaidean dùblaichte anns an t-slice.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Lean air adhart a `rèiteach eileamaidean nas motha na am pivot.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Dealaich an sliseag.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Roinn an sliseag a-steach do `left`, `pivot`, agus `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Gabh air ais chun taobh as giorra a-mhàin gus an àireamh iomlan de ghlaodhan ath-chuairteach a lughdachadh agus nas lugha de rùm cruachan ithe.
        // Sin dìreach cumail orra le na b 'fhaide air an taobh (tha seo a tha coltach ri earball recursion).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Deasaich `v` a `cleachdadh quicksort a tha a` dìon pàtran, agus is e sin *O*(*n*\*log(* n*)) a `chùis as miosa.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Chan eil giùlan brìgheil aig seòrsan meud neoni.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Cuir crìoch air an àireamh de sgaradh neo-chothromaichte gu `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Airson sliseagan suas ris an fhad seo is dòcha gu bheil e nas luaithe dìreach an rèiteachadh.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Tagh pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Ma tha am pivot a chaidh a thaghadh co-ionann ris an ro-shealladh, is e sin an eileamaid as lugha san t-sliseag.
        // Roinneadh an sliseag gu eileamaidean co-ionann ri agus eileamaidean nas motha na am pivot.
        // Mar as trice bidh a `chùis seo air a bhualadh nuair a tha mòran eileamaidean dùblaichte anns an t-slice.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Ma tha sinn air a dhol seachad air ar clàr-amais, tha sinn math.
                if mid > index {
                    return;
                }

                // Rud eile, lean air adhart a `rèiteach eileamaidean nas motha na am pivot.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Roinn an sliseag a-steach do `left`, `pivot`, agus `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Ma tha meadhan==clàr-amais, tha sinn air a dhèanamh, oir bha partition() a `gealltainn gu bheil a h-uile eileamaid às deidh meadhan nas motha na no co-ionann ri meadhan.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Chan eil giùlan brìgheil aig seòrsan meud neoni.Na dèan dad.
    } else if index == v.len() - 1 {
        // Lorg an eileamaid max agus cuir e san t-suidheachadh mu dheireadh den raon.
        // Tha sinn saor airson `unwrap()` a chleachdadh an seo oir tha fios againn nach fheum v a bhith falamh.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Lorg mion eileamaid agus cuir e anns a `chiad suidheachadh den raon.
        // Tha sinn saor airson `unwrap()` a chleachdadh an seo oir tha fios againn nach fheum v a bhith falamh.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}