// Buileachadh tùsail air a thoirt bho rust-memchr.
// Còraichean 2015 Andrew Gallant, bluss agus Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Cleachd truncation.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// A `tilleadh `true` ma tha byte neoni ann an `x`.
///
/// Bho *Cùisean Coimpiutaireachd*, J. Arndt:
///
/// `Is e a` bheachd a th `ann fear a thoirt air falbh bho gach fear de na bytes agus an uairsin coimhead airson bytes far an robh an iasad a` sgaoileadh fad na slighe chun an fheadhainn as cudromaiche
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// A `tilleadh a` chiad chlàr-amais a tha a `maidseadh byte `x` ann an `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Slighe luath airson sliseagan beaga
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // SCAN airson aon Byte luach le bhith leughadh dà `usize` faclan aig an àm.
    //
    // Roinn `text` ann an trì pàirtean
    // - pàirt tùsail gun ainm, ron chiad fhacal air a cho-thaobhadh ann an teacsa
    // - bodhaig, scan le 2 fhacal aig an aon àm
    // - am pàirt mu dheireadh a tha air fhàgail, <2 meud facal

    // rannsaich suas gu crìoch co-thaobhach
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // lorg air corp an teacsa
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // Sàbhailteachd: a 'fhad' sa bha a 'barrantachadh predicate astar co-dhiù 2 * usize_bytes
        // eadar an fhrith-thionndadh agus deireadh an t-sliseag.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // briseadh ma tha byte co-ionnan ann
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Lorg am byte às deidh a `phuing a stad lùb a` chuirp.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// A `tilleadh an clàr-amais mu dheireadh a tha a` maidseadh byte `x` ann an `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // SCAN airson aon Byte luach le bhith leughadh dà `usize` faclan aig an àm.
    //
    // Roinn `text` ann an trì pàirtean:
    // - earball gun ainm, às deidh an t-seòladh facal mu dheireadh ann an teacsa,
    // - bodhaig, air a sganadh le 2 fhacal aig an aon àm,
    // - a `chiad bytes a tha air fhàgail, <2 facal meud.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Canaidh sinn seo dìreach gus fad an ro-leasachan agus an iar-leasachan fhaighinn.
        // Anns a `mheadhan bidh sinn an-còmhnaidh a` giullachd dà chnap aig an aon àm.
        // SÀBHAILTEACHD: tha transmuting `[u8]` gu `[usize]` sàbhailte ach a-mhàin eadar-dhealachaidhean meud a tha `align_to` a `làimhseachadh.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Rannsaich a 'bhuidheann na teacsa, a' dèanamh cinnteach nach eil sinn a 'dèanamh crois min_aligned_offset.
    // tha an fhrith-thionndadh an-còmhnaidh air a cho-thaobhadh, agus mar sin tha dìreach deuchainn `>` gu leòr agus a `seachnadh cus sruthadh.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SÀBHAILTEACHD: bidh frith-bhualadh a `tòiseachadh aig len, suffix.len(), fhad` s a tha e nas motha na
        // min_aligned_offset (prefix.len()) tha an astar air fhàgail co-dhiù 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Dèan briseadh ma tha byte co-ionnan ann.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Lorg am byte mus stad an lùb corp.
    text[..offset].iter().rposition(|elt| *elt == x)
}