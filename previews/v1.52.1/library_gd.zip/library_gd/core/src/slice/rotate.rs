// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// A `cuairteachadh an raon `[mid-left, mid+right)` gus am bi an eileamaid aig `mid` mar a` chiad eileamaid.Equivalently, rotates an raon `left` eileamaidean air an làimh chlì no `right` eileamaidean air an làimh dheis.
///
/// # Safety
///
/// Feumaidh an raon ainmichte a bhith dligheach airson leughadh agus sgrìobhadh.
///
/// # Algorithm
///
/// Tha algorithm 1 air a chleachdadh airson luachan beaga `left + right` no airson `T` mòr.
/// Tha na h-eileamaidean air an gluasad a-steach do na dreuchdan deireannach aca aon aig aon àm a `tòiseachadh aig `mid - left` agus a` tighinn air adhart le ceumannan `right` modulo `left + right`, gus nach bi feum air ach aon sealach.
/// Mu dheireadh, ruigidh sinn air ais aig `mid - left`.
/// Ach, mura h-eil `gcd(left + right, right)` 1, leum na ceumannan gu h-àrd thairis air eileamaidean.
/// Mar eisimpleir:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Gu fortanach, tha an àireamh de leum thairis eileamaidean eadar chrìochnachadh eileamaidean a tha daonnan co-ionann, mar sin faodaidh sinn dìreach a 'tòiseachadh a chothromachadh ar suidheachadh is barrachd a dhèanamh cuairtean (an àireamh iomlan de na cuairtean a tha `gcd(left + right, right)` value).
///
/// Is e an toradh deireannach gu bheil na h-eileamaidean uile air an crìochnachadh aon uair agus dìreach aon uair.
///
/// Tha algorithm 2 air a chleachdadh ma tha `left + right` mòr ach tha `min(left, right)` beag gu leòr airson a chuir air bufair cruachan.
/// Tha `min(left, right)` eileamaidean a tha a lethbhreacadh air an bufair, `memmove` thathar a 'cur ri an cuid eile, agus tha an fheadhainn air an bufair air an gluasad air ais dhan toll air an taobh thall far a bheil iad bho thùs.
///
/// Bidh algorithm a dh `fhaodar a sgrùdadh nas fheàrr na tha gu h-àrd aon uair` s gum bi `left + right` a `fàs mòr gu leòr.
/// Faodar algorithm 1 a bhith air a vectar le bhith a `tulgadh agus a` coileanadh mòran chuairtean aig an aon àm, ach tha ro bheag de chuairtean cuibheasach gus am bi `left + right` gu math mòr, agus tha a `chùis as miosa de aon chuairt an-còmhnaidh ann.
/// An àite sin, bidh algorithm 3 a `cleachdadh iomlaid de eileamaidean `min(left, right)` a-rithist gus am bi duilgheadas rothlach nas lugha air fhàgail.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// nuair a `left < right` an iomlaideachadh thachras bhon taobh chlì na àite.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. faodaidh na h-algorithms gu h-ìosal fàilligeadh mura tèid na cùisean sin a sgrùdadh
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorithm 1 Tha meanbh-chomharran a `nochdadh gu bheil an coileanadh cuibheasach airson gluasadan air thuaiream nas fheàrr fad na slighe gu timcheall air `left + right == 32`, ach tha coileanadh na cùise as miosa a` briseadh eadhon timcheall air 16.
            // Chaidh 24 a thaghadh mar thalamh meadhanach.
            // Ma tha meud `T` nas motha na 4 `usize`s, tha an algorithm seo cuideachd a` coileanadh nas fheàrr na algorithm eile.
            //
            //
            let x = unsafe { mid.sub(left) };
            // toiseach a `chiad chuairt
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` Gheibhear ro-làimh le bhith a `tomhas `gcd(left + right, right)`, ach tha e nas luaithe aon lùb a dhèanamh a bhios a` tomhas a `chd mar bhuaidh taobh, agus an uairsin a` dèanamh a `chòrr den chnap
            //
            //
            let mut gcd = right;
            // tha slatan-tomhais a `nochdadh gu bheil e nas luaithe temporaries atharrachadh fad na slighe an àite a bhith a` leughadh aon sealach aon uair, a `dèanamh copaidh air ais, agus an uairsin a` sgrìobhadh sin sealach aig an fhìor dheireadh.
            // Is dòcha gu bheil seo air sgàth gu bheil iomlaid no ath-shuidheachadh temporaries a `cleachdadh dìreach aon seòladh cuimhne anns an lùb an àite a bhith feumach air dhà a riaghladh.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // an àite `i` a mheudachadh agus an uairsin sgrùdadh a bheil e taobh a-muigh nan crìochan, nì sinn sgrùdadh an tèid `i` taobh a-muigh nan crìochan air an ath àrdachadh.
                // Tha seo a `cur casg air còmhdach sam bith de chomharran no `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // deireadh a `chiad chuairt
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // feumaidh an cumha seo a bhith an seo ma tha `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // cuir crìoch air a `chnap le barrachd chuairtean
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` chan e seòrsa de mheud neoni a th `ann, agus mar sin tha e ceart gu leòr a roinn a rèir a mheud.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorithm 2 Tha an `[T; 0]` an seo gus dèanamh cinnteach gu bheil seo air a cho-thaobhadh gu h-iomchaidh airson T.
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithm 3 Tha dòigh eile ann airson iomlaid a tha a `toirt a-steach a bhith a` lorg càite am biodh an iomlaid mu dheireadh den algorithm seo, agus ag atharrachadh le bhith a `cleachdadh a` phìos mu dheireadh sin an àite a bhith ag atharrachadh cnapan faisg air làimh mar a tha an algorithm seo a `dèanamh, ach tha an dòigh seo fhathast nas luaithe.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorithm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}