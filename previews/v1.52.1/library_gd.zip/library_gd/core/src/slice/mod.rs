// ignore-tidy-filelength

//! Stiùireadh agus làimhseachadh sliseagan.
//!
//! Airson tuilleadh fiosrachaidh faic [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Buileachadh Pure rust memchr, air a thoirt bho rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Tha an gnìomh seo poblach a-mhàin seach nach eil dòigh eile ann air heapsort deuchainn aonad.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// A `tilleadh àireamh nan eileamaidean san t-sliseag.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SÀBHAILTEACHD: fuaim seasmhach oir bidh sinn a `gluasad a-mach an raon faid mar usize (feumaidh seo a bhith)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SÀBHAILTEACHD: tha seo sàbhailte oir tha an aon dreach aig `&[T]` agus `FatPtr<T>`.
            // Chan urrainn ach `std` an gealladh seo a thoirt seachad.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Cuir `crate::ptr::metadata(self)` na àite nuair a tha sin seasmhach.
            // Mar a tha an sgrìobhadh seo ag adhbhrachadh mearachd "Const-stable functions can only call other const-stable functions".
            //

            // SÀBHAILTEACHD: Tha faighinn chun luach bhon aonadh `PtrRepr` sàbhailte bho * const T.
            // agus PtrComponents<T>tha an aon chuimhneachan cruth.
            // Chan urrainn ach std an gealladh seo a thoirt seachad.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// A `tilleadh `true` ma tha fad 0 aig an sliseag.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// A `tilleadh a` chiad eileamaid den t-slice, no `None` ma tha e falamh.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// A `tilleadh stiùireadh gluasadach chun chiad eileamaid den t-sliseag, no `None` ma tha e falamh.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// A `tilleadh a` chiad agus a h-uile càil de na h-eileamaidean den t-slice, no `None` ma tha e falamh.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// A `tilleadh a` chiad agus a h-uile càil de na h-eileamaidean den t-slice, no `None` ma tha e falamh.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// A `tilleadh an fheadhainn mu dheireadh agus a h-uile càil de na h-eileamaidean den t-slice, no `None` ma tha e falamh.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// A `tilleadh an fheadhainn mu dheireadh agus a h-uile càil de na h-eileamaidean den t-slice, no `None` ma tha e falamh.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Tillidh e an eileamaid mu dheireadh den sliseag, no `None` ma tha e falamh.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// A `tilleadh stiùireadh gluasadach chun rud mu dheireadh san t-sliseag.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// A `tilleadh iomradh air eileamaid no subslice a rèir an seòrsa clàr-amais.
    ///
    /// - Ma thèid suidheachadh a thoirt dhut, till air ais iomradh air an eileamaid aig an t-suidheachadh sin no `None` ma tha e a-mach à crìochan.
    ///
    /// - Ma thèid raon a thoirt seachad, tillidh e an fho-sgrìobhadh a tha a `freagairt ris an raon sin, no `None` ma tha e a-mach à crìochan.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// A `tilleadh iomradh gluasadach air eileamaid no subslice a rèir an seòrsa clàr-amais (faic [`get`]) no `None` ma tha an clàr-amais a-mach à crìochan.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// A `tilleadh iomradh air eileamaid no subslice, gun a bhith a` dèanamh sgrùdadh crìochnachaidh.
    ///
    /// Airson roghainn sàbhailte eile faic [`get`].
    ///
    /// # Safety
    ///
    /// Is e a bhith a `gairm an dòigh seo le clàr-amais taobh a-muigh crìochan *[giùlan neo-mhìnichte]* eadhon ged nach eilear a` cleachdadh an t-iomradh a thig às.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh cumail ris a `mhòr-chuid de na riatanasan sàbhailteachd airson `get_unchecked`;
        // tha an sliseag dereferencable oir tha `self` na iomradh sàbhailte.
        // Tha am puing a chaidh a thilleadh sàbhailte oir feumaidh impilean `SliceIndex` gealltainn gu bheil e.
        unsafe { &*index.get_unchecked(self) }
    }

    /// A `tilleadh iomradh gluasadach air eileamaid no subslice, gun a bhith a` dèanamh sgrùdadh crìochan.
    ///
    /// Airson roghainn sàbhailte eile faic [`get_mut`].
    ///
    /// # Safety
    ///
    /// Is e a bhith a `gairm an dòigh seo le clàr-amais taobh a-muigh crìochan *[giùlan neo-mhìnichte]* eadhon ged nach eilear a` cleachdadh an t-iomradh a thig às.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh na riatanasan sàbhailteachd airson `get_unchecked_mut` a chumail suas;
        // tha an sliseag dereferencable oir tha `self` na iomradh sàbhailte.
        // Tha am puing a chaidh a thilleadh sàbhailte oir feumaidh impilean `SliceIndex` gealltainn gu bheil e.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// A `tilleadh stiùireadh amh gu bufair an t-sliseag.
    ///
    /// Feumaidh an neach-fòn dèanamh cinnteach gu bheil an sliseag a `toirt a-mach a` phuing a thilleas an gnìomh seo, no air an làimh eile thig e gu bhith a `comharrachadh sgudal.
    ///
    /// Feumaidh an neach-fios cuideachd dèanamh cinnteach nach tèid a `chuimhne a tha am puing (non-transitively) a` sgrìobhadh thuige (ach taobh a-staigh `UnsafeCell`) a `cleachdadh a` phuing seo no puing sam bith a thig às.
    /// Ma dh `fheumas tu susbaint na sliseag a mhùchadh, cleachd [`as_mut_ptr`].
    ///
    /// Dh `fhaodadh atharrachadh a dhèanamh air a` chnap-starra air a bheil an sliseag seo ag adhbhrachadh gun tèid am bufair aige ath-riarachadh, rud a dhèanadh comharran sam bith neo-dhligheach.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// A `tilleadh stiùireadh gluasadach neo-shàbhailte gu bufair an t-sliseag.
    ///
    /// Feumaidh an neach-fòn dèanamh cinnteach gu bheil an sliseag a `toirt a-mach a` phuing a thilleas an gnìomh seo, no air an làimh eile thig e gu bhith a `comharrachadh sgudal.
    ///
    /// Dh `fhaodadh atharrachadh a dhèanamh air a` chnap-starra air a bheil an sliseag seo ag adhbhrachadh gun tèid am bufair aige ath-riarachadh, rud a dhèanadh comharran sam bith neo-dhligheach.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// A `tilleadh an dà chomharra amh a` spangachadh an t-sliseag.
    ///
    /// Tha an raon a chaidh a thilleadh leth-fhosgailte, agus tha sin a `ciallachadh gu bheil am puing deireadh a` comharrachadh *aon seachad air* an eileamaid mu dheireadh den t-sliseag.
    /// San dòigh seo, tha sliseag falamh air a riochdachadh le dà chomharra co-ionnan, agus tha an eadar-dhealachadh eadar an dà phuing a `riochdachadh meud an t-sliseag.
    ///
    /// Faic [`as_ptr`] airson rabhaidhean mu bhith a `cleachdadh na molaidhean seo.Feumaidh am puing deireadh a bhith faiceallach a bharrachd, leis nach eil e a`comharrachadh eileamaid dhligheach san t-sliseag.
    ///
    /// Tha an gnìomh seo feumail airson eadar-obrachadh le eadar-aghaidh cèin a bhios a `cleachdadh dà chomharra airson iomradh a thoirt air raon de eileamaidean mar chuimhneachan, mar a tha cumanta ann an C++ .
    ///
    ///
    /// Faodaidh e cuideachd a bhith feumail dèanamh cinnteach a bheil stiùireadh airson eileamaid a `toirt iomradh air eileamaid den t-sliseag seo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SÀBHAILTEACHD: Tha an `add` an seo sàbhailte, oir:
        //
        //   - Tha an dà chomharra mar phàirt den aon rud, oir tha a bhith a `comharrachadh dìreach seachad air an nì cuideachd a` cunntadh.
        //
        //   - Chan eil meud an t-slice a-riamh nas motha na isize::MAX bytes, mar a chaidh a chomharrachadh an seo:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Chan eil pasgadh timcheall an sàs, oir cha bhith sliseagan a `dol seachad air deireadh an àite seòlaidh.
        //
        // Faic an sgrìobhainnean de pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// A `tilleadh an dà phuing mì-shàbhailte a tha a` spangachadh an t-sliseag.
    ///
    /// Tha an raon a chaidh a thilleadh leth-fhosgailte, agus tha sin a `ciallachadh gu bheil am puing deireadh a` comharrachadh *aon seachad air* an eileamaid mu dheireadh den t-sliseag.
    /// San dòigh seo, tha sliseag falamh air a riochdachadh le dà chomharra co-ionnan, agus tha an eadar-dhealachadh eadar an dà phuing a `riochdachadh meud an t-sliseag.
    ///
    /// Faic [`as_mut_ptr`] airson rabhaidhean mu bhith a `cleachdadh na molaidhean seo.
    /// Feumaidh am puing deireadh a bhith faiceallach a bharrachd, leis nach eil e a `comharrachadh eileamaid dhligheach san t-sliseag.
    ///
    /// Tha an gnìomh seo feumail airson eadar-obrachadh le eadar-aghaidh cèin a bhios a `cleachdadh dà chomharra airson iomradh a thoirt air raon de eileamaidean mar chuimhneachan, mar a tha cumanta ann an C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // Sàbhailteachd: See as_ptr_range() h-àrd airson carson a `add` seo sàbhailte.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Malairt dà eileamaid san t-sliseag.
    ///
    /// # Arguments
    ///
    /// * a, Clàr-amais a `chiad eileamaid
    /// * b, Clàr-amais an dàrna eileamaid
    ///
    /// # Panics
    ///
    /// Panics ma tha `a` no `b` a-mach à crìochan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Cha ghabh dà iasad gluasadach a thoirt bho aon vector, mar sin an àite sin cleachd molaidhean amh.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SÀBHAILTEACHD: Chaidh `pa` agus `pb` a chruthachadh bho iomraidhean sàbhailte mutable agus iomradh
        // ri eileamaidean san t-sliseag agus mar sin tha iad cinnteach gum bi iad dligheach agus co-thaobhach.
        // Thoir fa-near gu bheilear a `sgrùdadh faighinn gu na h-eileamaidean air cùl `a` agus `b` agus bidh panic ann nuair a thèid iad a-mach à crìochan.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// A `tilleadh òrdugh nan eileamaidean san t-sliseag, na àite.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Airson seòrsachan glè bheag, bidh na leughaidhean fa leth anns an t-slighe àbhaisteach a `coileanadh gu dona.
        // Is urrainn dhuinn a dhèanamh nas fheàrr, le load/store neo-chomharraichte èifeachdach, le bhith a `luchdachadh pìos nas motha agus a` tilleadh clàr.
        //

        // Bu LLVM bhiodh seo a dhèanamh dhuinn, mar a tha e aig a tha fios nas fheàrr na tha sinn a 'dèanamh co-dhiù a tha èifeachdach unaligned leughadh (bhon gu bheil atharrachaidhean eadar diofar dreachan ARM, mar eisimpleir) agus dè an dòigh as fheàrr Thuit pìos meud bhiodh.
        // Gu mì-fhortanach, mar a thaobh LLVM 4.0 (2017-05) chan eil e a `clàradh ach an lùb, agus mar sin feumaidh sinn seo a dhèanamh sinn fhèin.
        // (Hypothesis: tha cùl trioblaideach oir is urrainnear na taobhan a cho-thaobhadh gu eadar-dhealaichte-bidh, nuair a tha an fhaid neònach-mar sin chan eil dòigh ann a bhith a `leigeil a-mach ro-agus postludes gus SIMD làn-thaobhach a chleachdadh sa mheadhan.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Cleachd an llvm.bswap gnèitheach gus u8s a thionndadh air ais ann an cleachdadh
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SÀBHAILTEACHD: Tha grunn rudan ri sgrùdadh an seo:
                //
                // - Thoir fa-near gu bheil `chunk` an dàrna cuid 4 no 8 mar thoradh air an sgrùdadh cfg gu h-àrd.Mar sin tha `chunk - 1` deimhinneach.
                // - Tha clàr-amais le clàr-amais `i` gu math mar a tha an sgrùdadh lùb a `gealltainn
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Tha clàr-amais le clàr-amais `ln - i - chunk = ln - (i + chunk)` gu math:
                //   - `i + chunk > 0` gu fìrinneach.
                //   - Tha an sgrùdadh lùb a `gealltainn:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, mar sin chan eil toirt air falbh a `sruthadh.
                // - Tha na gairmean `read_unaligned` agus `write_unaligned` gu math:
                //   - `pa` puingean gu clàr-amais `i` far a bheil `i < ln / 2 - (chunk - 1)` (faic gu h-àrd) agus `pb` a `comharrachadh clàr-amais `ln - i - chunk`, mar sin tha an dà chuid co-dhiù `chunk` mòran bytes air falbh bho dheireadh `self`.
                //
                //   - Tha cuimhne tòiseachaidh sam bith dligheach `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Cleachd rotate-by-16 gus tilleadh u16s ann an u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SÀBHAILTEACHD: Faodar u32 gun ainm a leughadh bho `i` ma `i + 1 < ln`
                // (agus gu dearbh `i < ln`), leis gu bheil gach eileamaid 2 bytes agus tha sinn a `leughadh 4.
                //
                // `i + chunk - 1 < ln / 2` # fhad 'sa tha staid
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Leis gu bheil e nas lugha na an fhaid a tha air a roinn le 2, feumaidh e a bhith ann an crìochan.
                //
                // Tha seo cuideachd a `ciallachadh gu bheilear an-còmhnaidh a` toirt urram do chumha `0 < i + chunk <= ln`, a `dèanamh cinnteach gun gabh am puing `pb` a chleachdadh gu sàbhailte.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SÀBHAILTEACHD: Tha `i` nas ìsle na leth faid na sliseag mar sin
            // tha faighinn gu `i` agus `ln - i - 1` sàbhailte (tòisichidh `i` aig 0 agus cha tèid e nas fhaide na `ln / 2 - 1`).
            // Mar sin tha na comharran `pa` agus `pb` a tha mar thoradh air sin dligheach agus co-thaobhach, agus faodar an leughadh bho agus sgrìobhadh thuca.
            //
            //
            unsafe {
                // Swap mì-shàbhailte gus na crìochan a sheachnadh thoir sùil a-steach ann an suaip sàbhailte.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// A 'tilleadh an iterator thairis air an sliseag.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// A `tilleadh itealaiche a leigeas le gach luach atharrachadh.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// A `tilleadh itealaiche thairis air a h-uile windows co-shìnte de dh'fhaid `size`.
    /// Tha windows dùblachadh.
    /// Ma tha an sliseag nas giorra na `size`, cha till an iterator luachan sam bith.
    ///
    /// # Panics
    ///
    /// Panics ma tha `size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ma tha an slice nas giorra na `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// A 'tilleadh thar an iterator `chunk_size` eileamaidean de na sliseag aig an aon àm, a' tòiseachadh aig toiseach an t-sliseag.
    ///
    /// Is e sliseagan a th `anns na cnapan agus chan eil iad a` dol an lùib a chèile.Mura h-eil `chunk_size` a `roinn fad an t-sliseag, cha bhi fad `chunk_size` aig a` phìos mu dheireadh.
    ///
    /// Faic [`chunks_exact`] airson caochladh den iterator seo a thilleas cnapan de eileamaidean `chunk_size` an-còmhnaidh, agus [`rchunks`] airson an aon iterator ach a `tòiseachadh aig deireadh an t-sliseag.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma tha `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// A 'tilleadh thar an iterator `chunk_size` eileamaidean de na sliseag aig an aon àm, a' tòiseachadh aig toiseach an t-sliseag.
    ///
    /// Tha na cnapan nan sliseagan gluasadach, agus chan eil iad a `dol an lùib a chèile.Ma `chunk_size` Chan eil roinn fad an sliseag, an uair sin mu dheireadh Thuit pìos nach bi fad `chunk_size`.
    ///
    /// Faic [`chunks_exact_mut`] airson caochladh den iterator seo a thilleas cnapan de eileamaidean `chunk_size` an-còmhnaidh, agus [`rchunks_mut`] airson an aon iterator ach a `tòiseachadh aig deireadh an t-sliseag.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma tha `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// A 'tilleadh thar an iterator `chunk_size` eileamaidean de na sliseag aig an aon àm, a' tòiseachadh aig toiseach an t-sliseag.
    ///
    /// Tha na cnapan nan sliseagan agus chan eil iad a `dol an lùib a chèile.
    /// Mura h-eil `chunk_size` a `roinn fad an t-sliseag, thèid an fheadhainn mu dheireadh suas gu na h-eileamaidean `chunk_size-1` fhàgail air falbh agus gheibhear iad air ais bho ghnìomh `remainder` an iterator.
    ///
    ///
    /// Leis gu bheil na h-eileamaidean `chunk_size` aig gach cnap, faodaidh an trusaiche gu tric an còd a thig às a leasachadh nas fheàrr na ann an cùis [`chunks`].
    ///
    /// Faic [`chunks`] airson tionndadh den iterator seo a bhios cuideachd a `tilleadh a` chòrr mar phìos nas lugha, agus [`rchunks_exact`] airson an aon iterator ach a `tòiseachadh aig deireadh an t-sliseag.
    ///
    /// # Panics
    ///
    /// Panics ma tha `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// A 'tilleadh thar an iterator `chunk_size` eileamaidean de na sliseag aig an aon àm, a' tòiseachadh aig toiseach an t-sliseag.
    ///
    /// Tha na cnapan nan sliseagan gluasadach, agus chan eil iad a `dol an lùib a chèile.
    /// Mura h-eil `chunk_size` a `roinn fad an t-sliseag, thèid an fheadhainn mu dheireadh suas gu na h-eileamaidean `chunk_size-1` fhàgail air falbh agus gheibhear iad air ais bho ghnìomh `into_remainder` an iterator.
    ///
    ///
    /// Leis gu bheil na h-eileamaidean `chunk_size` aig gach cnap, faodaidh an trusaiche an còd a thig às a chleachdadh nas fheàrr na ann an cùis [`chunks_mut`].
    ///
    /// Faic [`chunks_mut`] airson tionndadh den iterator seo a bhios cuideachd a `tilleadh a` chòrr mar phìos nas lugha, agus [`rchunks_exact_mut`] airson an aon iterator ach a `tòiseachadh aig deireadh an t-sliseag.
    ///
    /// # Panics
    ///
    /// Panics ma tha `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Sgaoil an sliseag a-steach do sliseag de arrays `N`-element, a` gabhail ris nach eil an còrr ann.
    ///
    ///
    /// # Safety
    ///
    /// Is dòcha nach tèid seo a ghairm ach nuair a
    /// - Bidh an sliseag a `cuairteachadh gu dìreach ann am pocannan` N`-element (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SÀBHAILTEACHD: Cha bhi fuigheall 1-eileamaid a-riamh
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SÀBHAILTEACHD: Tha fad an sliseag (6) iomadach de 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Bhiodh iad sin mì-chinnteach:
    /// // leig cnapan: &[[_;5]]= slice.as_chunks_unchecked()//Chan eil fad an t-sliseag na iomadachadh de 5 cnapan:&[[_;0]]= slice.as_chunks_unchecked()//Cha cheadaichear cnapan de dh'fhaid idir
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SÀBHAILTEACHD: Is e an ro-aithris againn dìreach na tha a dhìth gus seo a ghairm
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SÀBHAILTEACHD: Bidh sinn a `tilgeil sliseag de eileamaidean `new_len * N` a-steach
        // sliseag de `new_len` mòran de eileamaidean `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// A `sgoltadh an t-sliseag a-steach do sliseag de arrays` N`-element, a`tòiseachadh aig toiseach an t-sliseag, agus sliseag eile le faid dìreach nas lugha na `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma tha `N` aig 0. Is dòcha gun atharraich an sgrùdadh seo gu mearachd ùine cur ri chèile mus tèid an dòigh seo a dhèanamh seasmhach.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SÀBHAILTEACHD: Bha sinn mu thràth a `clisgeadh airson neoni, agus a` dèanamh cinnteach à togail
        // gu bheil fad an fho-sgrìobhaidh iomadach de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// A `sgoltadh an t-sliseag a-steach do sliseag de arrays` N`-element, a`tòiseachadh aig deireadh an t-sliseag, agus sliseag eile le faid dìreach nas lugha na `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma tha `N` aig 0. Is dòcha gun atharraich an sgrùdadh seo gu mearachd ùine cur ri chèile mus tèid an dòigh seo a dhèanamh seasmhach.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SÀBHAILTEACHD: Bha sinn mu thràth a `clisgeadh airson neoni, agus a` dèanamh cinnteach à togail
        // gu bheil fad an fho-sgrìobhaidh iomadach de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// A `tilleadh itealaiche thairis air eileamaidean `N` den t-sliseag aig aon àm, a` tòiseachadh aig toiseach an t-sliseag.
    ///
    /// Tha na cnapan ann an iomraidhean eagar agus chan eil iad a `dol an lùib a chèile.
    /// Mura h-eil `N` a `roinn fad an t-sliseag, thèid an fheadhainn mu dheireadh suas gu na h-eileamaidean `N-1` fhàgail air falbh agus gheibhear iad air ais bho ghnìomh `remainder` an iterator.
    ///
    ///
    /// Tha an dòigh seo mar an aon ghnè coitcheann de [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics ma tha `N` aig 0. Is dòcha gun atharraich an sgrùdadh seo gu mearachd ùine cur ri chèile mus tèid an dòigh seo a dhèanamh seasmhach.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Sgaoil an sliseag a-steach do sliseag de arrays `N`-element, a` gabhail ris nach eil an còrr ann.
    ///
    ///
    /// # Safety
    ///
    /// Is dòcha nach tèid seo a ghairm ach nuair a
    /// - Bidh an sliseag a `cuairteachadh gu dìreach ann am pocannan` N`-element (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SÀBHAILTEACHD: Cha bhi fuigheall 1-eileamaid a-riamh
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SÀBHAILTEACHD: Tha fad an sliseag (6) iomadach de 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Bhiodh iad sin mì-chinnteach:
    /// // leig cnapan: &[[_;5]]= slice.as_chunks_unchecked_mut()//Tha sliseag dh'fhaid nach eil iomad de 5 Let cnapan: is [[_;0]]= slice.as_chunks_unchecked_mut()//Cha cheadaichear cnapan de dh'fhaid idir
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SÀBHAILTEACHD: Is e an ro-aithris againn dìreach na tha a dhìth gus seo a ghairm
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SÀBHAILTEACHD: Bidh sinn a `tilgeil sliseag de eileamaidean `new_len * N` a-steach
        // sliseag de `new_len` mòran de eileamaidean `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// A `sgoltadh an t-sliseag a-steach do sliseag de arrays` N`-element, a`tòiseachadh aig toiseach an t-sliseag, agus sliseag eile le faid dìreach nas lugha na `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma tha `N` aig 0. Is dòcha gun atharraich an sgrùdadh seo gu mearachd ùine cur ri chèile mus tèid an dòigh seo a dhèanamh seasmhach.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SÀBHAILTEACHD: Bha sinn mu thràth a `clisgeadh airson neoni, agus a` dèanamh cinnteach à togail
        // gu bheil fad an fho-sgrìobhaidh iomadach de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// A `sgoltadh an t-sliseag a-steach do sliseag de arrays` N`-element, a`tòiseachadh aig deireadh an t-sliseag, agus sliseag eile le faid dìreach nas lugha na `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma tha `N` aig 0. Is dòcha gun atharraich an sgrùdadh seo gu mearachd ùine cur ri chèile mus tèid an dòigh seo a dhèanamh seasmhach.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SÀBHAILTEACHD: Bha sinn mu thràth a `clisgeadh airson neoni, agus a` dèanamh cinnteach à togail
        // gu bheil fad an fho-sgrìobhaidh iomadach de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// A `tilleadh itealaiche thairis air eileamaidean `N` den t-sliseag aig aon àm, a` tòiseachadh aig toiseach an t-sliseag.
    ///
    /// Tha na cnapan nan iomraidhean eagar gluasadach agus chan eil iad a `dol an lùib a chèile.
    /// Mura h-eil `N` a `roinn fad an t-sliseag, thèid an fheadhainn mu dheireadh suas gu na h-eileamaidean `N-1` fhàgail air falbh agus gheibhear iad air ais bho ghnìomh `into_remainder` an iterator.
    ///
    ///
    /// Tha an dòigh seo mar an aon ghnè coitcheann de [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics ma tha `N` aig 0. Is dòcha gun atharraich an sgrùdadh seo gu mearachd ùine cur ri chèile mus tèid an dòigh seo a dhèanamh seasmhach.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// A `tilleadh itealaiche thairis air a bhith a` dol thairis air eileamaidean windows de `N` de sliseag, a `tòiseachadh aig toiseach an t-sliseag.
    ///
    ///
    /// Is e seo an const generic co-ionann ri [`windows`].
    ///
    /// Ma tha `N` nas motha na meud an t-sliseag, cha till e windows idir.
    ///
    /// # Panics
    ///
    /// Panics ma tha `N` 0.
    /// Is dòcha gun atharraich an sgrùdadh seo gu mearachd ùine cur ri chèile mus tèid an dòigh seo a dhèanamh seasmhach.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// A 'tilleadh thar an iterator `chunk_size` eileamaidean de na sliseag aig an aon àm, a' tòiseachadh aig deireadh an t-sliseag.
    ///
    /// Is e sliseagan a th `anns na cnapan agus chan eil iad a` dol an lùib a chèile.Mura h-eil `chunk_size` a `roinn fad an t-sliseag, cha bhi fad `chunk_size` aig a` phìos mu dheireadh.
    ///
    /// Faic [`rchunks_exact`] airson caochladh den iterator seo a thilleas cnapan de eileamaidean `chunk_size` an-còmhnaidh, agus [`chunks`] airson an aon iterator ach a `tòiseachadh aig toiseach an t-sliseag.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma tha `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// A 'tilleadh thar an iterator `chunk_size` eileamaidean de na sliseag aig an aon àm, a' tòiseachadh aig deireadh an t-sliseag.
    ///
    /// Tha na cnapan nan sliseagan gluasadach, agus chan eil iad a `dol an lùib a chèile.Ma `chunk_size` Chan eil roinn fad an sliseag, an uair sin mu dheireadh Thuit pìos nach bi fad `chunk_size`.
    ///
    /// Faic [`rchunks_exact_mut`] airson caochladh den iterator seo a thilleas cnapan de eileamaidean `chunk_size` an-còmhnaidh, agus [`chunks_mut`] airson an aon iterator ach a `tòiseachadh aig toiseach an t-sliseag.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma tha `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// A 'tilleadh thar an iterator `chunk_size` eileamaidean de na sliseag aig an aon àm, a' tòiseachadh aig deireadh an t-sliseag.
    ///
    /// Tha na cnapan nan sliseagan agus chan eil iad a `dol an lùib a chèile.
    /// Mura h-eil `chunk_size` a `roinn fad an t-sliseag, thèid an fheadhainn mu dheireadh suas gu na h-eileamaidean `chunk_size-1` fhàgail air falbh agus gheibhear iad air ais bho ghnìomh `remainder` an iterator.
    ///
    /// Leis gu bheil na h-eileamaidean `chunk_size` aig gach cnap, faodaidh an trusaiche gu tric an còd a thig às a leasachadh nas fheàrr na ann an cùis [`chunks`].
    ///
    /// Faic [`rchunks`] airson caochladh den iterator seo a bhios cuideachd a `tilleadh a` chòrr mar phìos nas lugha, agus [`chunks_exact`] airson an aon iterator ach a `tòiseachadh aig toiseach na sliseag.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma tha `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// A 'tilleadh thar an iterator `chunk_size` eileamaidean de na sliseag aig an aon àm, a' tòiseachadh aig deireadh an t-sliseag.
    ///
    /// Tha na cnapan nan sliseagan gluasadach, agus chan eil iad a `dol an lùib a chèile.
    /// Mura h-eil `chunk_size` a `roinn fad an t-sliseag, thèid an fheadhainn mu dheireadh suas gu na h-eileamaidean `chunk_size-1` fhàgail air falbh agus gheibhear iad air ais bho ghnìomh `into_remainder` an iterator.
    ///
    /// Leis gu bheil na h-eileamaidean `chunk_size` aig gach cnap, faodaidh an trusaiche an còd a thig às a chleachdadh nas fheàrr na ann an cùis [`chunks_mut`].
    ///
    /// Faic [`rchunks_mut`] airson caochladh den iterator seo a bhios cuideachd a `tilleadh a` chòrr mar phìos nas lugha, agus [`chunks_exact_mut`] airson an aon iterator ach a `tòiseachadh aig toiseach na sliseag.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma tha `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// A `tilleadh itealaiche thairis air an t-sliseag a` toirt a-mach ruith de eileamaidean nach eil a `dol thairis air a` cleachdadh an predicate gus an sgaradh.
    ///
    /// Canar an predicate air dà eileamaid gan leantainn fhèin, tha e a `ciallachadh gu bheil an predicate air a ghairm air `slice[0]` agus `slice[1]` an uairsin air `slice[1]` agus `slice[2]` agus mar sin air adhart.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Faodar an dòigh seo a chleachdadh gus na fo-stuthan a chaidh a sheòrsachadh a thoirt a-mach:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// A `tilleadh itealaiche thairis air an t-sliseag a` toirt a-mach sgrìoban neo-cheangailte de eileamaidean a `cleachdadh an predicate gus an dealachadh.
    ///
    /// Canar an predicate air dà eileamaid gan leantainn fhèin, tha e a `ciallachadh gu bheil an predicate air a ghairm air `slice[0]` agus `slice[1]` an uairsin air `slice[1]` agus `slice[2]` agus mar sin air adhart.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Faodar an dòigh seo a chleachdadh gus na fo-stuthan a chaidh a sheòrsachadh a thoirt a-mach:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Roinn aon slice ann an dà aig clàr-amais.
    ///
    /// Tha a 'chiad bidh a h-uile Indices bho `[0, mid)` (ach a-mhàin an clàr-amais `mid` fhèin) agus an dàrna fear a bhios anns a h-uile Indices bho `[mid, len)` (ach a-mhàin an clàr-amais `len` fhèin).
    ///
    ///
    /// # Panics
    ///
    /// Panics ma tha `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SÀBHAILTEACHD: Tha `[ptr; mid]` agus `[mid; len]` taobh a-staigh `self`, a tha
        // a `coileanadh riatanasan `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// A `roinn aon sliseag mutable ann an dà aig clàr-amais.
    ///
    /// Tha a 'chiad bidh a h-uile Indices bho `[0, mid)` (ach a-mhàin an clàr-amais `mid` fhèin) agus an dàrna fear a bhios anns a h-uile Indices bho `[mid, len)` (ach a-mhàin an clàr-amais `len` fhèin).
    ///
    ///
    /// # Panics
    ///
    /// Panics ma tha `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SÀBHAILTEACHD: Tha `[ptr; mid]` agus `[mid; len]` taobh a-staigh `self`, a tha
        // a `coileanadh riatanasan `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Roinn aon slice ann an dà aig clàr-amais, gun a bhith a `dèanamh sgrùdadh crìochnachaidh.
    ///
    /// Tha a 'chiad bidh a h-uile Indices bho `[0, mid)` (ach a-mhàin an clàr-amais `mid` fhèin) agus an dàrna fear a bhios anns a h-uile Indices bho `[mid, len)` (ach a-mhàin an clàr-amais `len` fhèin).
    ///
    ///
    /// Airson roghainn sàbhailte eile faic [`split_at`].
    ///
    /// # Safety
    ///
    /// Is e a bhith a `gairm an dòigh seo le clàr-amais taobh a-muigh crìochan *[giùlan neo-mhìnichte]* eadhon ged nach eilear a` cleachdadh an t-iomradh a thig às.Tha an neach-conaltraidh a bhith a 'dèanamh cinnteach gu bheil `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SÀBHAILTEACHD: Feumaidh an neach-conaltraidh sùil a thoirt air an `0 <= mid <= self.len()` sin
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// A `roinn aon sliseag shiùbhlach ann an dà aig clàr-amais, gun a bhith a` dèanamh sgrùdadh air crìochan.
    ///
    /// Tha a 'chiad bidh a h-uile Indices bho `[0, mid)` (ach a-mhàin an clàr-amais `mid` fhèin) agus an dàrna fear a bhios anns a h-uile Indices bho `[mid, len)` (ach a-mhàin an clàr-amais `len` fhèin).
    ///
    ///
    /// Airson roghainn sàbhailte eile faic [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Is e a bhith a `gairm an dòigh seo le clàr-amais taobh a-muigh crìochan *[giùlan neo-mhìnichte]* eadhon ged nach eilear a` cleachdadh an t-iomradh a thig às.Tha an neach-conaltraidh a bhith a 'dèanamh cinnteach gu bheil `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SÀBHAILTEACHD: Feumaidh an neach-conaltraidh sùil a thoirt air an `0 <= mid <= self.len()` sin.
        //
        // `[ptr; mid]` agus chan eil `[mid; len]` a `dol an lùib a chèile, agus mar sin tha tilleadh iomradh gluasadach gu math.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// A `tilleadh itealaiche thairis air fo-stuthan air an sgaradh le eileamaidean a tha a` maidseadh `pred`.
    /// Chan eil an eileamaid mhaidsichte anns na fo-sgrìobhaidhean.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ma tha a `chiad eileamaid air a mhaidseadh, is e sliseag falamh a` chiad rud a thilleas an iterator.
    /// San aon dòigh, ma tha an eileamaid mu dheireadh san t-sliseag air a mhaidseadh, is e sliseag falamh an rud mu dheireadh a thilleas an iterator:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ma tha dà eileamaid fhreagarrach faisg air làimh, bidh sliseag falamh eatorra:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// A 'tilleadh thar an iterator mutable subslices an dealachadh le na h-eileamaidean a tha a rèir `pred`.
    /// Chan eil an eileamaid mhaidsichte anns na fo-sgrìobhaidhean.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// A `tilleadh itealaiche thairis air fo-stuthan air an sgaradh le eileamaidean a tha a` maidseadh `pred`.
    /// Tha an eileamaid mhaidsichte ri fhaighinn aig deireadh an fho-sgrìobhaidh roimhe mar inneal-crìche.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ma tha an eileamaid mu dheireadh den t-sliseag air a mhaidseadh, thèid an eileamaid sin a mheas mar chrìochnaiche na sliseag roimhe.
    ///
    /// Is e an sliseag sin an rud mu dheireadh a thill an iterator.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// A 'tilleadh thar an iterator mutable subslices an dealachadh le na h-eileamaidean a tha a rèir `pred`.
    /// Tha an eileamaid mhaidsichte anns an fho-sgrìobhadh roimhe mar inneal-crìche.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// A 'tilleadh thar an iterator subslices an dealachadh le na h-eileamaidean a tha a rèir `pred`, a' tòiseachadh aig deireadh an t-sliseag agus ag obair an comhair a chùil.
    /// Chan eil an eileamaid mhaidsichte anns na fo-sgrìobhaidhean.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Coltach ri `split()`, ma tha a `chiad eileamaid no an eileamaid mu dheireadh air a mhaidseadh, is e sliseag falamh a` chiad rud (no an rud mu dheireadh) a thilleas an iterator.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// A `tilleadh itealaiche thairis air fo-stuthan gluasadach air an sgaradh le eileamaidean a tha a` maidseadh `pred`, a `tòiseachadh aig deireadh an t-sliseag agus ag obair air ais.
    /// Chan eil an eileamaid mhaidsichte anns na fo-sgrìobhaidhean.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// A `tilleadh itealaiche thairis air fo-stuthan air an sgaradh le eileamaidean a tha a` maidseadh `pred`, cuingealaichte ri bhith a `tilleadh aig a` mhòr-chuid de nithean `n`.
    /// Chan eil an eileamaid mhaidsichte anns na fo-sgrìobhaidhean.
    ///
    /// Anns an eileamaid mu dheireadh a chaidh a thilleadh, ma tha gin ann, bidh an còrr den t-slice.
    ///
    /// # Examples
    ///
    /// Clò-bhuail an sgaradh sliseag aon uair le àireamhan a tha air an roinn le 3 (ie, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// A `tilleadh itealaiche thairis air fo-stuthan air an sgaradh le eileamaidean a tha a` maidseadh `pred`, cuingealaichte ri bhith a `tilleadh aig a` mhòr-chuid de nithean `n`.
    /// Chan eil an eileamaid mhaidsichte anns na fo-sgrìobhaidhean.
    ///
    /// Anns an eileamaid mu dheireadh a chaidh a thilleadh, ma tha gin ann, bidh an còrr den t-slice.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// A `tilleadh itealaiche thairis air fo-stuthan air an sgaradh le eileamaidean a tha a` maidseadh `pred` cuibhrichte ri bhith a `tilleadh aig a` mhòr-chuid de nithean `n`.
    /// Bidh seo a `tòiseachadh aig deireadh an t-sliseag agus ag obair air ais.
    /// Chan eil an eileamaid mhaidsichte anns na fo-sgrìobhaidhean.
    ///
    /// Anns an eileamaid mu dheireadh a chaidh a thilleadh, ma tha gin ann, bidh an còrr den t-slice.
    ///
    /// # Examples
    ///
    /// Clò-bhuail an sgaradh sliseag aon uair, a `tòiseachadh bhon deireadh, a rèir àireamhan a tha air an roinn le 3 (ie, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// A `tilleadh itealaiche thairis air fo-stuthan air an sgaradh le eileamaidean a tha a` maidseadh `pred` cuibhrichte ri bhith a `tilleadh aig a` mhòr-chuid de nithean `n`.
    /// Bidh seo a `tòiseachadh aig deireadh an t-sliseag agus ag obair air ais.
    /// Chan eil an eileamaid mhaidsichte anns na fo-sgrìobhaidhean.
    ///
    /// Anns an eileamaid mu dheireadh a chaidh a thilleadh, ma tha gin ann, bidh an còrr den t-slice.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// A `tilleadh `true` ma tha eileamaid anns an t-slice leis an luach a chaidh a thoirt seachad.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Mura h-eil `&T` agad, ach dìreach `&U` mar sin `T: Borrow<U>` (me
    /// `String: Iasad<str>`), faodaidh tu `iter().any` a chleachdadh:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // sliseag de `String`
    /// assert!(v.iter().any(|e| e == "hello")); // rannsachadh le `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// A `tilleadh `true` ma tha `needle` na ro-leasachan den t-slice.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Tillidh `true` an-còmhnaidh ma tha `needle` na sliseag falamh:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// A `tilleadh `true` ma tha `needle` na iar-leasachan den t-sliseag.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Tillidh `true` an-còmhnaidh ma tha `needle` na sliseag falamh:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// A `tilleadh fo-sgrìobhadh leis an ro-leasachan air a thoirt air falbh.
    ///
    /// Ma thòisicheas an sliseag le `prefix`, tillidh e an fho-sgrìobhadh às deidh an ro-leasachan, air a phasgadh ann an `Some`.
    /// Ma tha `prefix` falamh, dìreach till an sliseag tùsail.
    ///
    /// Mura tòisich an sliseag le `prefix`, tillidh `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Feumaidh an gnìomh seo ath-sgrìobhadh ma tha agus nuair a thig SlicePattern nas ionnsaichte.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// A `tilleadh subslice leis an iar-leasachan air a thoirt air falbh.
    ///
    /// Ma thig an sliseag gu crìch le `suffix`, tillidh e an t-subslice ron iar-leasachan, air a phasgadh ann an `Some`.
    /// Ma tha `suffix` falamh, dìreach till an sliseag tùsail.
    ///
    /// Mura h-eil an sliseag a `crìochnachadh le `suffix`, tillidh `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Feumaidh an gnìomh seo ath-sgrìobhadh ma tha agus nuair a thig SlicePattern nas ionnsaichte.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Bidh Binary a `dèanamh sgrùdadh air an t-sliseag seo airson seòrsa sònraichte.
    ///
    /// Ma lorgar an luach tha [`Result::Ok`] air a thilleadh, anns a bheil clàr-amais an eileamaid maidsidh.
    /// Ma tha grunn gheamannan ann, dh `fhaodadh aon de na maidsean a thilleadh.
    /// Mura lorgar an luach tha [`Result::Err`] air a thilleadh, anns a bheil an clàr-amais far an gabhadh eileamaid maidsidh a chuir a-steach fhad `s a bha e a` cumail òrdugh ann an òrdugh.
    ///
    ///
    /// Faic cuideachd [`binary_search_by`], [`binary_search_by_key`], agus [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// A `coimhead suas sreath de cheithir eileamaidean.
    /// Lorgar a `chiad fhear, le suidheachadh air a dhearbhadh gu sònraichte;cha lorgar an dàrna agus an treas fear;dh'fhaodadh an ceathramh suidheachadh sam bith a cho-fhreagairt ann an `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Ma tha thu airson rud a chuir a-steach gu vector air a sheòrsachadh, fhad `s a chumas tu òrdugh òrdugh:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Bidh Binary a `dèanamh sgrùdadh air an t-sliseag seo le òrdugh coimeasach.
    ///
    /// Bu chòir don ghnìomh coimeasach òrdugh a chuir an gnìomh a tha a rèir òrdugh seòrsa na sliseag a tha foidhe, a `tilleadh còd òrduigh a tha a` nochdadh an e an argamaid aige `Less`, `Equal` no `Greater` an targaid a tha thu ag iarraidh.
    ///
    ///
    /// Ma lorgar an luach tha [`Result::Ok`] air a thilleadh, anns a bheil clàr-amais an eileamaid maidsidh.Ma tha grunn gheamannan ann, dh `fhaodadh aon de na maidsean a thilleadh.
    /// Mura lorgar an luach tha [`Result::Err`] air a thilleadh, anns a bheil an clàr-amais far an gabhadh eileamaid maidsidh a chuir a-steach fhad `s a bha e a` cumail òrdugh ann an òrdugh.
    ///
    /// Faic cuideachd [`binary_search`], [`binary_search_by_key`], agus [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// A `coimhead suas sreath de cheithir eileamaidean.Lorgar a`chiad fhear, le suidheachadh air a dhearbhadh gu sònraichte;cha lorgar an dàrna agus an treas fear;dh'fhaodadh an ceathramh suidheachadh sam bith a cho-fhreagairt ann an `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SÀBHAILTEACHD: thèid an gairm a dhèanamh sàbhailte leis na h-invariants a leanas:
            // - `mid >= 0`
            // - `mid < size`: Tha `mid` air a chuingealachadh le `[left; right)` air a cheangal.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Is e an adhbhar gu bheil sinn a `cleachdadh sruth smachd if/else seach maids seach gu bheil maids ag ath-òrdachadh obrachaidhean coimeas, a tha gu math mothachail.
            //
            // Is e seo x86 asm airson u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Bidh Binary a `dèanamh sgrùdadh air an t-sliseag seo le prìomh obair às-tharraing.
    ///
    /// A 'gabhail ris gu bheil an cur ann an ordugh le slios tha na prìomh àite, mar eisimpleir le bhith a' cleachdadh an aon [`sort_by_key`] prìomh dhleastanas a tharraing.
    ///
    /// Ma lorgar an luach tha [`Result::Ok`] air a thilleadh, anns a bheil clàr-amais an eileamaid maidsidh.
    /// Ma tha grunn gheamannan ann, dh `fhaodadh aon de na maidsean a thilleadh.
    /// Mura lorgar an luach tha [`Result::Err`] air a thilleadh, anns a bheil an clàr-amais far an gabhadh eileamaid maidsidh a chuir a-steach fhad `s a bha e a` cumail òrdugh ann an òrdugh.
    ///
    ///
    /// Faic cuideachd [`binary_search`], [`binary_search_by`], agus [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// A `coimhead suas sreath de cheithir eileamaidean ann an sliseag de chàraidean air an òrdachadh leis na dàrna eileamaidean aca.
    /// Lorgar a `chiad fhear, le suidheachadh air a dhearbhadh gu sònraichte;cha lorgar an dàrna agus an treas fear;dh'fhaodadh an ceathramh suidheachadh sam bith a cho-fhreagairt ann an `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Tha Lint rustdoc::broken_intra_doc_links ceadaichte oir tha `slice::sort_by_key` ann an crate `alloc`, agus mar sin chan eil e ann fhathast nuair a thathas a `togail `core`.
    //
    // ceanglaichean gu crate sìos an abhainn: #74481.Leis nach eil prìomhairean air an clàradh ach ann an libstd (#73423), cha bhi seo a-riamh a `leantainn gu ceanglaichean briste ann an cleachdadh.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Deasaich an sliseag, ach is dòcha nach glèidh e òrdugh nan eileamaidean co-ionnan.
    ///
    /// Tha an seòrsa seo neo-sheasmhach (ie, dh `fhaodadh e eileamaidean co-ionnan ath-òrdachadh), na àite (ie, chan eil e a` riarachadh), agus *O*(*n*\*log(* n*)) anns a `chùis as miosa.
    ///
    /// # Buileachadh gnàthach
    ///
    /// Tha an algorithm gnàthach stèidhichte air [pattern-defeating quicksort][pdqsort] le Orson Peters, a tha a `cothlamadh a` chùis cuibheasach luath de quicksort air thuaiream leis a `chùis as luaithe as luaithe de heapsort, agus aig an aon àm a` coileanadh ùine shreathach air sliseagan le pàtrain sònraichte.
    /// Bidh e a `cleachdadh cuid de thuaiream gus cùisean degenerate a sheachnadh, ach le seed stèidhichte gus giùlan deimhinnte a thoirt seachad an-còmhnaidh.
    ///
    /// Tha e mar as trice nas luaithe na bhith a `rèiteach seasmhach, ach a-mhàin ann am beagan chùisean sònraichte, me, nuair a tha grunn shreathan co-chruinnichte ann an sliseag.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Deasaich an sliseag le gnìomh coimeasach, ach is dòcha nach glèidh e òrdugh nan eileamaidean co-ionnan.
    ///
    /// Tha an seòrsa seo neo-sheasmhach (ie, dh `fhaodadh e eileamaidean co-ionnan ath-òrdachadh), na àite (ie, chan eil e a` riarachadh), agus *O*(*n*\*log(* n*)) anns a `chùis as miosa.
    ///
    /// Feumaidh an gnìomh coimeasach òrdugh iomlan a mhìneachadh airson na h-eileamaidean san t-slice.Mura h-eil an òrdachadh gu h-iomlan, tha òrdugh nan eileamaidean neo-ainmichte.Is e òrdugh òrdugh iomlan ma tha e (airson a h-uile `a`, `b` agus `c`):
    ///
    /// * iomlan agus antisymmetric: tha dìreach aon de `a < b`, `a == b` no `a > b` fìor, agus
    /// * tar-ghluasadach, tha `a < b` agus `b < c` a `ciallachadh `a < c`.Feumaidh an aon rud a bhith ann airson an dà chuid `==` agus `>`.
    ///
    /// Mar eisimpleir, ged nach eil [`f64`] a `buileachadh [`Ord`] air sgàth `NaN != NaN`, is urrainn dhuinn `partial_cmp` a chleachdadh mar ar gnìomh seòrsa nuair a tha fios againn nach eil `NaN` anns an t-sliseag.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Buileachadh gnàthach
    ///
    /// Tha an algorithm gnàthach stèidhichte air [pattern-defeating quicksort][pdqsort] le Orson Peters, a tha a `cothlamadh a` chùis cuibheasach luath de quicksort air thuaiream leis a `chùis as luaithe as luaithe de heapsort, agus aig an aon àm a` coileanadh ùine shreathach air sliseagan le pàtrain sònraichte.
    /// Bidh e a `cleachdadh cuid de thuaiream gus cùisean degenerate a sheachnadh, ach le seed stèidhichte gus giùlan deimhinnte a thoirt seachad an-còmhnaidh.
    ///
    /// Tha e mar as trice nas luaithe na bhith a `rèiteach seasmhach, ach a-mhàin ann am beagan chùisean sònraichte, me, nuair a tha grunn shreathan co-chruinnichte ann an sliseag.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // cùl-sheòrsachadh
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Deasaich an sliseag le prìomh obair às-tharraing, ach is dòcha nach glèidh e òrdugh nan eileamaidean co-ionnan.
    ///
    /// Tha an seòrsa seo neo-sheasmhach (ie, dh `fhaodadh e eileamaidean co-ionnan ath-òrdachadh), na àite (ie, chan eil e a` riarachadh), agus *O*(m\* * n *\* log(*n*)) anns a `chùis as miosa, far a bheil a` phrìomh ghnìomh *O*(*m*).
    ///
    /// # Buileachadh gnàthach
    ///
    /// Tha an algorithm gnàthach stèidhichte air [pattern-defeating quicksort][pdqsort] le Orson Peters, a tha a `cothlamadh a` chùis cuibheasach luath de quicksort air thuaiream leis a `chùis as luaithe as luaithe de heapsort, agus aig an aon àm a` coileanadh ùine shreathach air sliseagan le pàtrain sònraichte.
    /// Bidh e a `cleachdadh cuid de thuaiream gus cùisean degenerate a sheachnadh, ach le seed stèidhichte gus giùlan deimhinnte a thoirt seachad an-còmhnaidh.
    ///
    /// Air sgàth a phrìomh ro-innleachd gairm, tha coltas ann gum bi [`sort_unstable_by_key`](#method.sort_unstable_by_key) nas slaodaiche na [`sort_by_cached_key`](#method.sort_by_cached_key) ann an cùisean far a bheil am prìomh ghnìomh daor.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Dèan ath-òrdachadh air an t-sliseag gus am bi an eileamaid aig `index` aig a shuidheachadh deireannach.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Dèan ath-òrdachadh air an t-sliseag le gnìomh coimeasach gus am bi an eileamaid aig `index` aig a shuidheachadh deireannach.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Dèan ath-òrdachadh air an t-sliseag le prìomh obair às-tharraing gus am bi an eileamaid aig `index` aig a shuidheachadh deireannach.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Dèan ath-òrdachadh air an t-sliseag gus am bi an eileamaid aig `index` aig a shuidheachadh deireannach.
    ///
    /// Tha an seilbh a bharrachd aig an ath-òrdachadh seo gum bi luach sam bith aig suidheachadh `i < index` nas lugha na no co-ionann ri luach sam bith aig suidheachadh `j > index`.
    /// A bharrachd air an sin, tha an ath-òrdachadh seo neo-sheasmhach (ie
    /// faodaidh àireamh sam bith de na h-eileamaidean co-ionnan crìoch a chuir air suidheachadh `index`), na àite (ie
    /// chan eil e a `riarachadh), agus *O*(*n*) cùis as miosa.
    /// Canar "kth element" ris a `ghnìomh seo ann an leabharlannan eile.
    /// Bidh e a `tilleadh triple de na luachan a leanas: gach eileamaid nas lugha na am fear aig a` chlàr-innse a chaidh a thoirt seachad, an luach aig a `chlàr-innse a chaidh a thoirt seachad, agus gach eileamaid nas motha na am fear aig a` chlàr-innse a chaidh a thoirt seachad.
    ///
    ///
    /// # Buileachadh gnàthach
    ///
    /// Tha an algorithm gnàthach stèidhichte air a `chuibhreann quickselect den aon algorithm quicksort a chaidh a chleachdadh airson [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics nuair `index >= len()`, a `ciallachadh gu bheil e an-còmhnaidh panics air sliseagan falamh.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Lorg am meadhan
    /// v.select_nth_unstable(2);
    ///
    /// // Chan eil sinn ach a `gealltainn gum bi an sliseag mar aon de na leanas, stèidhichte air an dòigh a bhios sinn a` rèiteach mun chlàr-amais ainmichte.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Dèan ath-òrdachadh air an t-sliseag le gnìomh coimeasach gus am bi an eileamaid aig `index` aig a shuidheachadh deireannach.
    ///
    /// Tha an seilbh a bharrachd aig an ath-òrdachadh seo gum bi luach sam bith aig suidheachadh `i < index` nas lugha na no co-ionann ri luach sam bith aig suidheachadh `j > index` a `cleachdadh a` ghnìomh choimeasach.
    /// A bharrachd air an sin, tha an ath-òrdachadh seo neo-sheasmhach (ie faodaidh àireamh sam bith de na h-eileamaidean co-ionnan crìochnachadh aig suidheachadh `index`), na àite (ie nach eil a `riarachadh), agus *O*(*n*) anns a` chùis as miosa.
    /// Canar "kth element" ris a `ghnìomh seo ann an leabharlannan eile.
    /// Bidh e a `tilleadh triple de na luachan a leanas: gach eileamaid nas lugha na am fear aig a` chlàr-innse a chaidh a thoirt seachad, an luach aig a `chlàr-innse a chaidh a thoirt seachad, agus gach eileamaid nas motha na am fear aig a` chlàr-innse a chaidh a thoirt seachad, a `cleachdadh a` ghnìomh coimeasair a chaidh a thoirt seachad.
    ///
    ///
    /// # Buileachadh gnàthach
    ///
    /// Tha an algorithm gnàthach stèidhichte air a `chuibhreann quickselect den aon algorithm quicksort a chaidh a chleachdadh airson [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics nuair `index >= len()`, a `ciallachadh gu bheil e an-còmhnaidh panics air sliseagan falamh.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Lorg am meadhan mar gum biodh an sliseag air a sheòrsachadh ann an òrdugh teàrnaidh.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Chan eil sinn ach a `gealltainn gum bi an sliseag mar aon de na leanas, stèidhichte air an dòigh a bhios sinn a` rèiteach mun chlàr-amais ainmichte.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Dèan ath-òrdachadh air an t-sliseag le prìomh obair às-tharraing gus am bi an eileamaid aig `index` aig a shuidheachadh deireannach.
    ///
    /// Tha an seilbh a bharrachd aig an ath-òrdachadh seo gum bi luach sam bith aig suidheachadh `i < index` nas lugha na no co-ionann ri luach sam bith aig suidheachadh `j > index` a `cleachdadh a` phrìomh ghnìomh às-tharraing.
    /// A bharrachd air an sin, tha an ath-òrdachadh seo neo-sheasmhach (ie faodaidh àireamh sam bith de na h-eileamaidean co-ionnan crìochnachadh aig suidheachadh `index`), na àite (ie nach eil a `riarachadh), agus *O*(*n*) anns a` chùis as miosa.
    /// Canar "kth element" ris a `ghnìomh seo ann an leabharlannan eile.
    /// Bidh e a `tilleadh trì uimhir de na luachan a leanas: gach eileamaid nas lugha na am fear aig a` chlàr-innse a chaidh a thoirt seachad, an luach aig a `chlàr-innse a chaidh a thoirt seachad, agus gach eileamaid nas motha na am fear aig a` chlàr-innse a chaidh a thoirt seachad, a `cleachdadh a` phrìomh ghnìomh às-tharraing a chaidh a thoirt seachad.
    ///
    ///
    /// # Buileachadh gnàthach
    ///
    /// Tha an algorithm gnàthach stèidhichte air a `chuibhreann quickselect den aon algorithm quicksort a chaidh a chleachdadh airson [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics nuair `index >= len()`, a `ciallachadh gu bheil e an-còmhnaidh panics air sliseagan falamh.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Thoir air ais am meadhan mar gum biodh an raon air a sheòrsachadh a rèir luach iomlan.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Chan eil sinn ach a `gealltainn gum bi an sliseag mar aon de na leanas, stèidhichte air an dòigh a bhios sinn a` rèiteach mun chlàr-amais ainmichte.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Gluais a h-uile eileamaid leantainneach leantainneach gu deireadh an t-sliseag a rèir buileachadh [`PartialEq`] trait.
    ///
    ///
    /// A `tilleadh dà shliseag.Anns a`chiad fhear chan eil eileamaidean leantainneach ann.
    /// Anns an dàrna fear tha na dùblaidhean uile ann an òrdugh sònraichte.
    ///
    /// Ma thèid an sliseag a sheòrsachadh, chan eil dùblachadh anns a `chiad sliseag a chaidh a thilleadh.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Gluais a h-uile ach a `chiad de na h-eileamaidean leantainneach gu deireadh an t-sliseag a` sàsachadh dàimh co-ionannachd sònraichte.
    ///
    /// A `tilleadh dà shliseag.Anns a`chiad fhear chan eil eileamaidean leantainneach ann.
    /// Anns an dàrna fear tha na dùblaidhean uile ann an òrdugh sònraichte.
    ///
    /// Tha `same_bucket` gnìomh ga thoirt seachad iomraidhean air dà eileamaid bho sliseag agus feumaidh co-dhùnadh ma tha na h-eileamaidean coimeas a dhèanamh eadar co-ionnan.
    /// Tha na h-eileamaidean air an toirt seachad ann an òrdugh eile bhon òrdugh aca san t-sliseag, mar sin ma thilleas `same_bucket(a, b)` `true`, thèid `a` a ghluasad aig deireadh na sliseag.
    ///
    ///
    /// Ma thèid an sliseag a sheòrsachadh, chan eil dùblachadh anns a `chiad sliseag a chaidh a thilleadh.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Ged a tha iomradh gluasadach againn air `self`, chan urrainn dhuinn atharrachaidhean *neo-riaghailteach* a dhèanamh.Tha `same_bucket` gairmean panic b 'urrainn, mar sin, feumaidh sinn dèanamh cinnteach gu bheil an slios tha dligheach ann an staid aig a h-uile turas.
        //
        // Is ann le bhith a `cleachdadh suaipean a tha sinn a` làimhseachadh seo;bidh sinn ag itealaich thairis air na h-eileamaidean gu lèir, ag atharrachadh mar a thèid sinn air adhart gus am bi aig an deireadh na h-eileamaidean a tha sinn airson a chumail air beulaibh, agus an fheadhainn a tha sinn airson a dhiùltadh aig a `chùl.
        // Faodaidh sinn an uairsin an sliseag a sgaradh.
        // Tha an obrachadh seo fhathast `O(n)`.
        //
        // Eisimpleir: Bidh sinn a `tòiseachadh anns an stàit seo, far a bheil `r` a` riochdachadh `ath
        // leugh "agus tha `w` a` riochdachadh "next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // A `dèanamh coimeas eadar self[r] an aghaidh fèin [w-1], chan e dùblachadh a tha seo, agus mar sin bidh sinn ag iomlaid self[r] agus self[w] (gun èifeachd mar r==w) agus an uairsin a` meudachadh an dà chuid r agus w, a `fàgail sinn le:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // A `dèanamh coimeas eadar self[r] an aghaidh fèin [w-1], tha an luach seo dà-fhillte, mar sin bidh sinn a` meudachadh `r` ach a `fàgail a h-uile càil eile gun atharrachadh:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // A `dèanamh coimeas eadar self[r] an aghaidh fèin [w-1], chan e dùblachadh a tha seo, mar sin dèan iomlaid air self[r] agus self[w] agus adhartachadh r agus w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Chan e dùblachadh, ath-aithris:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Dùblachadh, advance r. End de slice.Air a sgaradh aig w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SÀBHAILTEACHD: tha suidheachadh `while` a `gealltainn `next_read` agus `next_write`
        // nas lugha na `len`, mar sin tha iad taobh a-staigh `self`.
        // `prev_ptr_write` phuingean aon eileamaid mus `ptr_write`, ach `next_write` a 'tòiseachadh aig 1, mar sin `prev_ptr_write` e riamh na bu lugha na 0 agus tha e taobh a-staigh na sliseag.
        // Bidh seo a `coileanadh nan riatanasan airson a bhith a` dì-chlàradh `ptr_read`, `prev_ptr_write` agus `ptr_write`, agus airson a bhith a `cleachdadh `ptr.add(next_read)`, `ptr.add(next_write - 1)` agus `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` tha e cuideachd air àrdachadh aig a `char as motha aon uair gach lùb aig a` char as motha a `ciallachadh nach eilear a` leum air eileamaid nuair a dh `fhaodadh a bhith air atharrachadh.
        //
        // `ptr_read` agus chan eil `prev_ptr_write` a-riamh a `comharrachadh an aon eileamaid.Feumar seo airson `&mut *ptr_read`, `&mut* prev_ptr_write` a bhith sàbhailte.
        // Is e am mìneachadh gu sìmplidh gu bheil `next_read >= next_write` an-còmhnaidh fìor, mar sin tha `next_read > next_write - 1` cuideachd.
        //
        //
        //
        //
        //
        unsafe {
            // Seachain sgrùdaidhean crìochan le bhith a `cleachdadh molaidhean amh.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Gluais a h-uile ach a `chiad de na h-eileamaidean leantainneach gu deireadh an t-sliseag a dh` fhuasgladh chun an aon iuchair.
    ///
    ///
    /// A `tilleadh dà shliseag.Anns a`chiad fhear chan eil eileamaidean leantainneach ann.
    /// Anns an dàrna fear tha na dùblaidhean uile ann an òrdugh sònraichte.
    ///
    /// Ma thèid an sliseag a sheòrsachadh, chan eil dùblachadh anns a `chiad sliseag a chaidh a thilleadh.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// A `cuairteachadh an t-sliseag na àite gus am bi a` chiad eileamaidean `mid` den t-slice a `gluasad chun deireadh fhad` s a bhios na h-eileamaidean `self.len() - mid` mu dheireadh a `gluasad chun bheulaibh.
    /// An dèidh a 'gairm `rotate_left`, an eileamaid roimhe aig index `mid` bi a' chiad eileamaid ann an sliseag.
    ///
    /// # Panics
    ///
    /// Bidh an gnìomh seo panic ma tha `mid` nas motha na fad an sliseag.Thoir fa-near gu bheil `mid == self.len()` a `dèanamh _not_ panic agus gur e cuairteachadh no-op a th` ann.
    ///
    /// # Complexity
    ///
    /// A `gabhail sreathach (ann an ùine `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// A `cuairteachadh subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SÀBHAILTEACHD: Tha an raon `[p.add(mid) - mid, p.add(mid) + k)` gu beag
        // dligheach airson leughadh agus sgrìobhadh, mar a dh `fheumar le `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// A `cuairteachadh an t-sliseag na àite gus am bi a` chiad eileamaidean `self.len() - k` den t-slice a `gluasad chun deireadh fhad` s a bhios na h-eileamaidean `k` mu dheireadh a `gluasad chun bheulaibh.
    /// An dèidh a 'gairm `rotate_right`, an eileamaid roimhe aig index `self.len() - k` bi a' chiad eileamaid ann an sliseag.
    ///
    /// # Panics
    ///
    /// Bidh an gnìomh seo panic ma tha `k` nas motha na fad an sliseag.Cuimhnich gur `k == self.len()` dèanamh _not_ panic agus tha e cha-op mun cuairt.
    ///
    /// # Complexity
    ///
    /// A `gabhail sreathach (ann an ùine `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Rothairich subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SÀBHAILTEACHD: Tha an raon `[p.add(mid) - mid, p.add(mid) + k)` gu beag
        // dligheach airson leughadh agus sgrìobhadh, mar a dh `fheumar le `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// A `lìonadh `self` le eileamaidean le bhith a` cliogadh `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// `self` lìonadh le eileamaidean a thilleadh le fòn a dhùnadh tric.
    ///
    /// Bidh an dòigh seo a `cleachdadh dùnadh gus luachan ùra a chruthachadh.Nam b`fheàrr leat [`Clone`] luach sònraichte, cleachd [`fill`].
    /// Ma tha thu airson an [`Default`] trait a chleachdadh gus luachan a ghineadh, faodaidh tu [`Default::default`] a thoirt seachad mar an argamaid.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Dèan lethbhreac de na h-eileamaidean bho `src` gu `self`.
    ///
    /// Feumaidh fad `src` a bhith co-ionann ri `self`.
    ///
    /// Ma chuireas `T` `Copy` an gnìomh, faodaidh e a bhith nas gnìomhaiche [`copy_from_slice`] a chleachdadh.
    ///
    /// # Panics
    ///
    /// Bidh an gnìomh seo panic ma tha faid eadar-dhealaichte aig an dà shliseag.
    ///
    /// # Examples
    ///
    /// A `gleusadh dà eileamaid bho sliseag gu fear eile:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Leis gum feum na claisean a bhith den aon fhaid, sliseagaidh sinn an sliseag stòr bho cheithir eileamaidean gu dhà.
    /// // Nì e panic mura dèan sinn seo.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Tha Rust a `daingneachadh nach urrainn ach aon iomradh gluasadach a bhith ann gun iomradh so-ruigsinneach air pìos dàta sònraichte ann an raon sònraichte.
    /// Air sgàth seo, a 'feuchainn ri cleachdadh `clone_from_slice` air aon sliseag Leanaidh ri chèile fàilligeadh:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Gus obrachadh timcheall air an seo, is urrainn dhuinn [`split_at_mut`] a chleachdadh gus dà fho-sliseag àraid a chruthachadh bho sliseag:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Dèan lethbhreac den h-uile eileamaid bho `src` gu `self`, a `cleachdadh cuimhneachan.
    ///
    /// Feumaidh fad `src` a bhith co-ionann ri `self`.
    ///
    /// Mura cuir `T` an gnìomh `Copy`, cleachd [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Bidh an gnìomh seo panic ma tha faid eadar-dhealaichte aig an dà shliseag.
    ///
    /// # Examples
    ///
    /// A `dèanamh leth-bhreac de dhà eileamaid bho sliseag a-steach do fhear eile:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Leis gum feum na claisean a bhith den aon fhaid, sliseagaidh sinn an sliseag stòr bho cheithir eileamaidean gu dhà.
    /// // Nì e panic mura dèan sinn seo.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Tha Rust a `daingneachadh nach urrainn ach aon iomradh gluasadach a bhith ann gun iomradh so-ruigsinneach air pìos dàta sònraichte ann an raon sònraichte.
    /// Air sgàth seo, ma dh `fheuchas tu ri `copy_from_slice` a chleachdadh air aon sliseag thig fàiligeadh ri chèile:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Gus obrachadh timcheall air an seo, is urrainn dhuinn [`split_at_mut`] a chleachdadh gus dà fho-sliseag àraid a chruthachadh bho sliseag:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Chaidh slighe còd panic a chuir ann an gnìomh fuar gus nach blàthaich e an làrach gairm.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SÀBHAILTEACHD: Tha `self` dligheach airson eileamaidean `self.len()` a rèir mìneachadh, agus bha `src`
        // dèanamh cinnteach gu bheil an aon fhaid aca.
        // Chan urrainn dha na sliseagan a dhol thairis air sgàth gu bheil iomraidhean gluasadach sònraichte.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Dèan lethbhreac de eileamaidean bho aon phàirt den t-slice gu pàirt eile dheth fhèin, a `cleachdadh memmove.
    ///
    /// `src` a bheil an raon taobh a-staigh `self` airson lethbhreac a dhèanamh dheth.
    /// `dest` an clàr-amais tòiseachaidh den raon taobh a-staigh `self` airson lethbhreac a dhèanamh dheth, aig am bi an aon fhaid ri `src`.
    /// Faodaidh an dà raon a dhol thairis air a chèile.
    /// Bha cinn nan dà raointean a dh'fheumas a bhith nas lugha na no co-ionnan ri `self.len()`.
    ///
    /// # Panics
    ///
    /// Bidh an gnìomh seo panic ma tha an dàrna cuid a `dol thairis air deireadh na sliseag, no ma tha deireadh `src` ro thoiseach.
    ///
    ///
    /// # Examples
    ///
    /// A `dèanamh lethbhreac de cheithir bytes taobh a-staigh sliseag:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SÀBHAILTEACHD: chaidh na cumhaichean airson `ptr::copy` uile a sgrùdadh gu h-àrd,
        // mar a tha an fheadhainn airson `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Ag atharrachadh a h-uile eileamaid ann an `self` leis an fheadhainn ann an `other`.
    ///
    /// Feumaidh fad `other` a bhith co-ionann ri `self`.
    ///
    /// # Panics
    ///
    /// Bidh an gnìomh seo panic ma tha faid eadar-dhealaichte aig an dà shliseag.
    ///
    /// # Example
    ///
    /// Ag atharrachadh dà eileamaid thar sliseagan:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Tha Rust a `daingneachadh nach urrainn ach aon iomradh gluasadach a bhith ann air pìos dàta sònraichte ann an raon sònraichte.
    ///
    /// Air sgàth seo, ma dh `fheuchas tu ri `swap_with_slice` a chleachdadh air aon sliseag thig fàiligeadh ri chèile:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Gus obrachadh timcheall air an seo, is urrainn dhuinn [`split_at_mut`] a chleachdadh gus dà fho-sliseag mutable àraid a chruthachadh bho sliseag:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SÀBHAILTEACHD: Tha `self` dligheach airson eileamaidean `self.len()` a rèir mìneachadh, agus bha `src`
        // dèanamh cinnteach gu bheil an aon fhaid aca.
        // Chan urrainn dha na sliseagan a dhol thairis air sgàth gu bheil iomraidhean gluasadach sònraichte.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Dreuchd gus obrachadh a-mach faid na sliseag meadhain agus slaodadh airson `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Is e na tha sinn a `dèanamh mu `rest` a bhith a` faighinn a-mach dè an àireamh de`U`s as urrainn dhuinn a chuir anns an àireamh as ìsle de`T`s.
        //
        // Agus cia mheud `T` a tha a dhìth oirnn airson gach "multiple" mar sin.
        //
        // Beachdaich air mar eisimpleir T=u8 U=u16.An uairsin is urrainn dhuinn 1 U a chuir ann an 2 Ts.Gu sìmplidh.
        // A-nis, smaoinich mar eisimpleir air cùis far a bheil meud_of: :<T>=16, size_of::<U>=24.</u>
        // Faodaidh sinn 2 Us a chuir an àite gach 3 Ts san t-sliseag `rest`.
        // Beagan nas iom-fhillte.
        //
        // Is e an fhoirmle airson seo a thomhas:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Leudaichte agus nas sìmplidhe:
        //
        // Us=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) TS=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Gu fortanach, bho na h-uile a tha seo cunbhalach-measadh coileanaidh seo ... cùisean nach eil!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // algorithm itealain iteagach Bu chòir dhuinn an `const fn` seo a dhèanamh fhathast (agus a dhol air ais gu algorithm ath-chuairteach ma nì sinn sin) oir tha a bhith an urra ri llvm gus a h-uile càil a tha seo ... uill, tha e gam fhàgail mì-chofhurtail.
            //
            //

            // SÀBHAILTEACHD: Thathas a `sgrùdadh `a` agus `b` mar luachan neo-neoni.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // thoir air falbh a h-uile feart de 2 bho b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SÀBHAILTEACHD: Thathas a `sgrùdadh `b` gu bhith neo-neoni.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Armaichte le eòlas seo, gheibh sinn cia mheud `U`s urrainn dhuinn freagarrach!
        let us_len = self.len() / ts * us;
        // Agus cia mheud `T` a bhios anns an t-sliseag tralaidh!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmute an slice gu slice de sheòrsa eile, a `dèanamh cinnteach gu bheil co-thaobhadh de na seòrsaichean air a chumail suas.
    ///
    /// Tha an dòigh seo a 'sgaradh an sliseag a-steach trì sliseagan: ro-leasachan, ceart a rèir a chèile meadhan sliseag seòrsa ùr, agus an leasachan sliseag.
    /// Dh `fhaodadh gum bi an dòigh-obrach a` dèanamh an sliseag mheadhain an fhad as motha a tha comasach airson seòrsa sònraichte agus sliseag a-steach, ach cha bu chòir ach coileanadh an algairim agad a bhith an urra ri sin, chan e cho ceart.
    ///
    /// Tha e ceadaichte gun tèid an dàta inntrigidh uile a thilleadh mar an ro-leasachan no an iar-leasachan.
    ///
    /// Chan eil adhbhar sam bith aig an dòigh seo nuair a tha an dàrna cuid eileamaid `T` no eileamaid toraidh `U` de mheud neoni agus tillidh iad an t-sliseag tùsail gun a bhith a `sgoltadh dad.
    ///
    /// # Safety
    ///
    /// Tha an dòigh seo gu ìre mhòr na `transmute` a thaobh nan eileamaidean anns an t-sliseag mheadhain a chaidh a thilleadh, agus mar sin tha a h-uile clàr àbhaisteach a bhuineas do `transmute::<T, U>` cuideachd a `buntainn an seo.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Thoir fa-near gum bi a `mhòr-chuid den ghnìomh seo air a mheasadh gu cunbhalach,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // làimhseachadh ZSTn gu sònraichte, is e sin-na bi gan làimhseachadh idir.
            return (self, &[], &[]);
        }

        // An toiseach, lorg dè an ìre aig am bi sinn a `sgaradh eadar a` chiad agus an 2na sliseag.
        // Furasta le ptr.align_offset.
        let ptr = self.as_ptr();
        // SÀBHAILTEACHD: Faic an dòigh `align_to_mut` airson a `bheachd sàbhailteachd mionaideach.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SÀBHAILTEACHD: a-nis tha `rest` air a cho-thaobhadh gu cinnteach, agus mar sin tha `from_raw_parts` gu h-ìosal ceart gu leòr,
            // seach gu bheil an neach-fòn a `gealltainn gun urrainn dhuinn `T` a ghluasad gu `U` gu sàbhailte.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmute an slice gu slice de sheòrsa eile, a `dèanamh cinnteach gu bheil co-thaobhadh de na seòrsaichean air a chumail suas.
    ///
    /// Tha an dòigh seo a 'sgaradh an sliseag a-steach trì sliseagan: ro-leasachan, ceart a rèir a chèile meadhan sliseag seòrsa ùr, agus an leasachan sliseag.
    /// Dh `fhaodadh gum bi an dòigh-obrach a` dèanamh an sliseag mheadhain an fhad as motha a tha comasach airson seòrsa sònraichte agus sliseag a-steach, ach cha bu chòir ach coileanadh an algairim agad a bhith an urra ri sin, chan e cho ceart.
    ///
    /// Tha e ceadaichte gun tèid an dàta inntrigidh uile a thilleadh mar an ro-leasachan no an iar-leasachan.
    ///
    /// Chan eil adhbhar sam bith aig an dòigh seo nuair a tha an dàrna cuid eileamaid `T` no eileamaid toraidh `U` de mheud neoni agus tillidh iad an t-sliseag tùsail gun a bhith a `sgoltadh dad.
    ///
    /// # Safety
    ///
    /// Tha an dòigh seo gu ìre mhòr na `transmute` a thaobh nan eileamaidean anns an t-sliseag mheadhain a chaidh a thilleadh, agus mar sin tha a h-uile clàr àbhaisteach a bhuineas do `transmute::<T, U>` cuideachd a `buntainn an seo.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Thoir fa-near gum bi a `mhòr-chuid den ghnìomh seo air a mheasadh gu cunbhalach,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // làimhseachadh ZSTn gu sònraichte, is e sin-na bi gan làimhseachadh idir.
            return (self, &mut [], &mut []);
        }

        // An toiseach, lorg dè an ìre aig am bi sinn a `sgaradh eadar a` chiad agus an 2na sliseag.
        // Furasta le ptr.align_offset.
        let ptr = self.as_ptr();
        // SÀBHAILTEACHD: An seo tha sinn a `dèanamh cinnteach gun cleachd sinn molaidhean co-thaobhach airson U airson na
        // an còrr den dòigh.Tha seo air a dhèanamh le bhith a `dol seachad air puing gu&[T] le co-thaobhadh air a chuimseachadh airson U.
        // `crate::ptr::align_offset` ris an canar le comharradh `ptr` dligheach agus dligheach (tha e a `tighinn bho iomradh air `self`) agus le meud a tha na chumhachd de dhà (leis gu bheil e a` tighinn bhon alignement airson U), a `sàsachadh a chuingealachaidhean sàbhailteachd.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Chan urrainn dhuinn `rest` a chleachdadh a-rithist às deidh seo, chuireadh sin an ailias `mut_ptr` aige gu neo-dhligheach!SÀBHAILTEACHD: faic beachdan airson `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Dèan cinnteach a bheil na h-eileamaidean den t-slice seo air an rèiteachadh.
    ///
    /// Is e sin, airson gach eileamaid `a` agus an eileamaid `b` a leanas, feumaidh `a <= b` a chumail.Ma bheir an sliseag toradh dìreach neoni no aon eileamaid, thèid `true` a thilleadh.
    ///
    /// Thoir fa-near, mura h-eil `Self::Item` ach `PartialOrd`, ach chan e `Ord`, tha am mìneachadh gu h-àrd a `ciallachadh gum bi an gnìomh seo a` tilleadh `false` mura h-eil dà rud leantainneach an coimeas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Dèan cinnteach a bheil na h-eileamaidean den t-slice seo air an rèiteachadh le bhith a `cleachdadh a` ghnìomh coimeas a chaidh a thoirt seachad.
    ///
    /// An àite a bhith a `cleachdadh `PartialOrd::partial_cmp`, bidh an gnìomh seo a` cleachdadh a `ghnìomh `compare` a chaidh a thoirt seachad gus òrdachadh dà eileamaid a dhearbhadh.
    /// A bharrachd air sin, tha e co-ionann ri [`is_sorted`];faic na sgrìobhainnean aige airson tuilleadh fiosrachaidh.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Dèan cinnteach a bheil na h-eileamaidean den t-slice seo air an rèiteachadh le bhith a `cleachdadh a` phrìomh ghnìomh às-tharraing a chaidh a thoirt seachad.
    ///
    /// An àite a bhith a `dèanamh coimeas dìreach eadar eileamaidean an t-sliseag, tha an gnìomh seo a` dèanamh coimeas eadar iuchraichean nan eileamaidean, mar a chaidh a dhearbhadh le `f`.
    /// A bharrachd air sin, tha e co-ionann ri [`is_sorted`];faic na sgrìobhainnean aige airson tuilleadh fiosrachaidh.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// A `tilleadh clàr-amais a` phuing sgaradh a rèir na ro-innse a chaidh a thoirt seachad (clàr-amais a `chiad eileamaid den dàrna sgaradh).
    ///
    /// Thathas a `dèanamh dheth gu bheil an sliseag air a sgaradh a rèir na ro-innse a chaidh a thoirt seachad.
    /// Tha seo a `ciallachadh gu bheil a h-uile eileamaid dha bheil an toradh predicate fìor aig toiseach an t-sliseag agus tha na h-eileamaidean air fad a tha an toradh predicate meallta aig an deireadh.
    ///
    /// Mar eisimpleir, tha [7, 15, 3, 5, 4, 12, 6] air a sgaradh fon ro-innse x% 2!=0 (tha na h-àireamhan neònach uile aig an toiseach, eadhon aig an deireadh).
    ///
    /// Mura h-eil an sliseag seo air a sgaradh, tha an toradh a chaidh a thilleadh neo-shònraichte agus gun bhrìgh, oir tha an dòigh seo a `dèanamh seòrsa de sgrùdadh binary.
    ///
    /// Faic cuideachd [`binary_search`], [`binary_search_by`], agus [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SÀBHAILTEACHD: Nuair a bhios `left < right`, `left <= mid < right`.
            // Mar sin bidh `left` an-còmhnaidh a `meudachadh agus bidh `right` an-còmhnaidh a` lùghdachadh, agus thèid aon seach aon dhiubh a thaghadh.Anns gach cùis tha `left <= right` riaraichte.Mar sin ma tha `left < right` ann an ceum, tha `left <= right` riaraichte san ath cheum.
            //
            // Mar sin, cho fad `s a tha `left != right`, tha `0 <= left < right <= len` riaraichte agus ma tha a` chùis seo `0 <= mid < len` riaraichte cuideachd.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Feumaidh sinn follaiseach sliseadh iad gus an aon fhaid
        // gus a dhèanamh nas fhasa don optimizer cuir às do sgrùdadh crìochan.
        // Ach bho nach urrainnear earbsa a bhith againn tha speisealachadh sònraichte againn airson T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// A `cruthachadh sliseag falamh.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// A `cruthachadh sliseag falamh mutable.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Pàtranan ann an sliseagan, an-dràsta, air an cleachdadh le `strip_prefix` agus `strip_suffix` a-mhàin.
/// Aig puing future, tha sinn an dòchas `core::str::Pattern` a dhèanamh coitcheann (a tha aig àm sgrìobhaidh cuingealaichte ri `str`) gu sliseagan, agus an uairsin thèid an trait seo a chuir an àite no a chuir às.
///
pub trait SlicePattern {
    /// Tha an eileamaid seòrsa sliseag an deach a sheisich air.
    type Item;

    /// An-dràsta, feumaidh luchd-cleachdaidh `SlicePattern` sliseag.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}