//! # Tha Rust Prìomh Leabharlann
//!
//! Tha Rust Prìomh Leabharlann e an eisimeil saor-[^-asgaidh] bunait [The Rust Standard Library](../std/index.html).
//! Is e an glaodh so-ghiùlain eadar an cànan agus na leabharlannan aige, a `mìneachadh nam blocaichean togail bunaiteach agus prìomhadail de chòd Rust gu lèir.
//!
//! Tha ea 'ceangal sam bith shuas leabharlannan, chan eil siostam leabharlannan, agus cha libc.
//!
//! [^free]: Strictly labhairt, tha cuid de na samhlaidhean a tha a dhìth ach
//!          chan eil iad an-còmhnaidh a dhìth.
//!
//! Tha an leabharlann bunaiteach *glè bheag*: chan eil e eadhon mothachail mu riarachadh cruachan, agus chan eil e a `toirt seachad concurrency no I/O.
//! Na rudan seo ma tha feum agaibh àrd-chabhsair amalachadh, agus tha an àrd-chabhsair seo leabharlainn-agnostic.
//!
//! # Mar a chleachdas prìomh leabharlainn
//!
//! Thoiribh fa-near gu bheil a h-uile fiosrachadh sin tha an-dràsta a 'beachdachadh eil stàball.
//!
//!
//!
// FIXME: Lìon mi a-steach le barrachd mionaideachd nuair a shocraicheas an eadar-aghaidh
//! Tha seo a 'leabharlainn air a thogail air a' bharail beagan de na samhlaidhean a th 'ann:
//!
//! * `memcpy`, `memcmp`, `memset`, Is iad seo prìomh chleachdaidhean cuimhne a bhios gu tric air an gineadh le LLVM.
//! A bharrachd air an sin, faodaidh an leabharlann seo gairmean sònraichte a dhèanamh air na gnìomhan sin.
//! Ainm-sgrìobhte aca a tha an aon rud ri lorg ann C.
//!   Tha na dleastanasan sin gu tric a tha air an solarachadh le siostam libc, ach faodar cuideachd a 'toirt seachad leis an [compiler-builtins crate](https://crates.io/crates/compiler_builtins).
//!
//!
//! * `rust_begin_panic` - A 'ghnìomh seo a' gabhail ceithir argamaidean, a `fmt::Arguments`, a `&'static str`, agus dà `u32` aig.
//! Tha na ceithir argamaidean òrdachadh panic an teachdaireachd, aig am faidhle a chaidh a panic invoked, agus an loidhne agus colbh a-staigh am faidhle.
//! Tha e suas ri luchd-cleachdaidh seo air prìomh leabharlainn airson mìneachadh seo panic ghnìomh;chan eil e ach a dhìth gus cha till.
//! Feumaidh seo feart `lang` ainmichte `panic_impl`.
//!
//! * `rust_eh_personality` - air a chleachdadh le fàilligeadh uidheamachdan an compiler.
//! Tha seo gu tric a 'mapadh a GCC pearsa gnìomh, ach crates nach eil a' piobrachadh a panic urrainn a bhith cinnteach gu bheil seo a 'ghnìomh cha bhi e ris an canar.
//! Tha `lang` buadha a ghairm `eh_personality`.
//!
//!
//!

// Bho libcore a 'mìneachadh mòran nithean bunaiteach lang, a h-uile deuchainnean a' fuireach ann leth a crate, libcoretest, a sheachnadh neònach cùisean.
//
// An seo tha sinn follaiseach#[cfg]-out seo fad crate nuair a 'dèanamh deuchainn.
// Ma chan eil sinn a 'dèanamh seo, an dà chuid a chruthachadh deuchainn artifact agus an libtest ceangailte (a tha a' gabhail a-steach transitively libcore) Bidh an dà chuid mìneachadh an aon seata de nithean lang, agus bidh seo ag adhbhrachadh an E0152 "found duplicate lang item" mhearachd.
//
// Faic an deasbad ann an #50466 airson mion-fhiosrachadh.
//
// Tha seo a 'cfg cha toir e buaidh doc deuchainnean.
//
//
#![cfg(not(test))]
#![stable(feature = "core", since = "1.6.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![no_core]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(asm)]
#![feature(cfg_target_has_atomic)]
#![feature(const_heap)]
#![feature(const_alloc_layout)]
#![feature(const_assert_type)]
#![feature(const_discriminant)]
#![feature(const_cell_into_inner)]
#![feature(const_intrinsic_copy)]
#![feature(const_intrinsic_forget)]
#![feature(const_float_classify)]
#![feature(const_float_bits_conv)]
#![feature(const_int_unchecked_arith)]
#![feature(const_mut_refs)]
#![feature(const_refs_to_cell)]
#![feature(const_cttz)]
#![feature(const_panic)]
#![feature(const_pin)]
#![feature(const_fn)]
#![feature(const_fn_union)]
#![feature(const_impl_trait)]
#![feature(const_fn_floating_point_arithmetic)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(const_option)]
#![feature(const_precise_live_drops)]
#![feature(const_ptr_offset)]
#![feature(const_ptr_offset_from)]
#![feature(const_ptr_read)]
#![feature(const_ptr_write)]
#![feature(const_raw_ptr_comparison)]
#![feature(const_raw_ptr_deref)]
#![feature(const_slice_from_raw_parts)]
#![feature(const_slice_ptr_len)]
#![feature(const_size_of_val)]
#![feature(const_swap)]
#![feature(const_align_of_val)]
#![feature(const_type_id)]
#![feature(const_type_name)]
#![feature(const_likely)]
#![feature(const_unreachable_unchecked)]
#![feature(const_maybe_uninit_assume_init)]
#![feature(const_maybe_uninit_as_ptr)]
#![feature(custom_inner_attributes)]
#![feature(decl_macro)]
#![feature(doc_cfg)]
#![feature(doc_spotlight)]
#![feature(duration_consts_2)]
#![feature(duration_saturating_ops)]
#![feature(extended_key_value_attributes)]
#![feature(extern_types)]
#![feature(fundamental)]
#![feature(intra_doc_pointers)]
#![feature(intrinsics)]
#![feature(lang_items)]
#![feature(link_llvm_intrinsics)]
#![feature(llvm_asm)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(exhaustive_patterns)]
#![feature(no_core)]
#![feature(auto_traits)]
#![feature(or_patterns)]
#![feature(prelude_import)]
#![cfg_attr(not(bootstrap), feature(ptr_metadata))]
#![feature(repr_simd, platform_intrinsics)]
#![feature(rustc_attrs)]
#![feature(simd_ffi)]
#![feature(min_specialization)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(stmt_expr_attributes)]
#![feature(str_split_as_str)]
#![feature(str_split_inclusive_as_str)]
#![feature(trait_alias)]
#![feature(transparent_unions)]
#![feature(try_blocks)]
#![feature(unboxed_closures)]
#![feature(unsized_fn_params)]
#![feature(unwind_attributes)]
#![feature(variant_count)]
#![feature(tbm_target_feature)]
#![feature(sse4a_target_feature)]
#![feature(arm_target_feature)]
#![feature(powerpc_target_feature)]
#![feature(mips_target_feature)]
#![feature(aarch64_target_feature)]
#![feature(wasm_target_feature)]
#![feature(avx512_target_feature)]
#![feature(cmpxchg16b_target_feature)]
#![feature(rtm_target_feature)]
#![feature(f16c_target_feature)]
#![feature(hexagon_target_feature)]
#![feature(const_fn_transmute)]
#![feature(abi_unadjusted)]
#![feature(adx_target_feature)]
#![feature(external_doc)]
#![feature(associated_type_bounds)]
#![feature(const_caller_location)]
#![feature(slice_ptr_get)]
#![feature(no_niche)] // rust-lang/rust#68303
#![feature(int_error_matching)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![deny(unsafe_op_in_unsafe_fn)]

#[prelude_import]
#[allow(unused)]
use prelude::v1::*;

#[cfg(not(test))] // Faic #65860
#[macro_use]
mod macros;

#[macro_use]
mod internal_macros;

#[path = "num/shells/int_macros.rs"]
#[macro_use]
mod int_macros;

#[path = "num/shells/i128.rs"]
pub mod i128;
#[path = "num/shells/i16.rs"]
pub mod i16;
#[path = "num/shells/i32.rs"]
pub mod i32;
#[path = "num/shells/i64.rs"]
pub mod i64;
#[path = "num/shells/i8.rs"]
pub mod i8;
#[path = "num/shells/isize.rs"]
pub mod isize;

#[path = "num/shells/u128.rs"]
pub mod u128;
#[path = "num/shells/u16.rs"]
pub mod u16;
#[path = "num/shells/u32.rs"]
pub mod u32;
#[path = "num/shells/u64.rs"]
pub mod u64;
#[path = "num/shells/u8.rs"]
pub mod u8;
#[path = "num/shells/usize.rs"]
pub mod usize;

#[path = "num/f32.rs"]
pub mod f32;
#[path = "num/f64.rs"]
pub mod f64;

#[macro_use]
pub mod num;

/* The libcore prelude, not as all-encompassing as the libstd prelude */

pub mod prelude;

/* Core modules for ownership management */

pub mod hint;
pub mod intrinsics;
pub mod mem;
pub mod ptr;

/* Core language traits */

pub mod borrow;
pub mod clone;
pub mod cmp;
pub mod convert;
pub mod default;
pub mod marker;
pub mod ops;

/* Core types and methods on primitives */

pub mod any;
pub mod array;
pub mod ascii;
pub mod cell;
pub mod char;
pub mod ffi;
pub mod iter;
#[unstable(feature = "once_cell", issue = "74465")]
pub mod lazy;
pub mod option;
pub mod panic;
pub mod panicking;
pub mod pin;
pub mod raw;
pub mod result;
#[unstable(feature = "async_stream", issue = "79024")]
pub mod stream;
pub mod sync;

pub mod fmt;
pub mod hash;
pub mod slice;
pub mod str;
pub mod time;

pub mod unicode;

/* Async */
pub mod future;
pub mod task;

/* Heap memory allocator trait */
#[allow(missing_docs)]
pub mod alloc;

// note: Chan eil feum a bhith a 'phobaill
mod bool;
mod tuple;
mod unit;

#[stable(feature = "core_primitive", since = "1.43.0")]
pub mod primitive;

// Pull ann an `core_arch` crate dìreach a-steach libcore.Tha susbaint na `core_arch` ann an diofar repository: rust-lang/stdarch.
//
// `core_arch` an urra ri libcore, ach tha susbaint a `mhodal seo air a stèidheachadh ann an dòigh a tha ga tharraing gu dìreach an seo ag obair gus am bi an crate a` cleachdadh an crate seo mar a libcore.
//
//
//
#[path = "../../stdarch/crates/core_arch/src/mod.rs"]
#[allow(
    missing_docs,
    missing_debug_implementations,
    dead_code,
    unused_imports,
    unsafe_op_in_unsafe_fn
)]
#[cfg_attr(bootstrap, allow(non_autolinks))]
#[cfg_attr(not(bootstrap), allow(rustdoc::non_autolinks))]
// FIXME: An nota seo a bu chòir a bhith gluasad a-steach rust-lang/stdarch dèidh clashing_extern_declarations tha
// aonadh.Tha e an-dràsta chan urrainn oir bootstrap fàilligeadh mar an lint nach deach a mhìneachadh fhathast.
#[allow(clashing_extern_declarations)]
#[unstable(feature = "stdsimd", issue = "48556")]
mod core_arch;

#[stable(feature = "simd_arch", since = "1.27.0")]
pub use core_arch::arch;