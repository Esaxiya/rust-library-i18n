//! Stuthan cruinneachaidh.
//!
//! Tha an co-fhreagarrach na mìneachaidhean a tha ann an `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Tha na buileachadh const co-fhreagarrach ann an `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrinsics
//!
//! Note: bu chòir bruidhinn ri sgioba cànain mu atharrachaidhean sam bith ann an doimhneachd gnè.
//! Tha seo a `toirt a-steach atharrachaidhean ann an seasmhachd na seasmhachd.
//!
//! Gus am bi e comasach a chleachdadh aig àm cur ri chèile, feumaidh aon lethbhreac a dhèanamh den bhuileachadh bho <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> gu `compiler/rustc_mir/src/interpret/intrinsics.rs` agus `#[rustc_const_unstable(feature = "foo", issue = "01234")]` a chur ris a `bhroinn.
//!
//!
//! Ma ghnèitheach tha e coltach gu bhith air a chleachdadh bho `const fn` le `rustc_const_stable` buadha, an t-ghnèitheach a buadha a dh'fheumas a bhith `rustc_const_stable`, cuideachd.
//! Cha bu chòir atharrachadh mar sin a bhith air a dhèanamh às aonais co-chomhairle T-lang, oir tha e a `toirt feart a-steach don chànan nach gabh ath-aithris ann an còd luchd-cleachdaidh gun taic co-chruinneachaidh.
//!
//! # Volatiles
//!
//! Tha sradagach intrinsics a 'toirt obraichean an dùil a bhith air I/O cuimhne, a tha air a ghealltainn gus nach bi reordered le compiler eile air feadh sradagach intrinsics.Faic na sgrìobhainnean LLVM air [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Bidh an gnè atamach a `toirt seachad obair atamach cumanta air faclan innealan, le iomadh òrdugh cuimhne a dh` fhaodadh a bhith ann.Bidh iad a `gèilleadh ris na h-aon semantics ri C++ 11.Faic na sgrìobhainnean LLVM air [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Ùrachadh sgiobalta air òrdachadh cuimhne:
//!
//! * Faighinn, cnap-starra airson glas fhaighinn.Bidh leughadh agus sgrìobhadh às deidh sin a `tachairt às deidh a` chnap-starra.
//! * Fuasgail, cnap-starra airson glas a leigeil ma sgaoil.Bidh preceding a `leughadh agus a` sgrìobhadh a `tachairt ron chnap-starra.
//! * Bithear a `gealltainn gun tachair obrachaidhean cunbhalach cunbhalach, leantainneach ann an òrdugh.Is e seo am modh àbhaisteach airson a bhith ag obair le seòrsachan atamach agus tha e co-ionann ri Java's `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Tha na in-mhalairt sin air an cleachdadh airson ceanglaichean taobh a-staigh doc a dhèanamh nas sìmplidhe
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SÀBHAILTEACHD: faic `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, bidh na bun-bheachdan sin a `toirt stiùiridhean amh oir bidh iad a` mùchadh cuimhne aliased, nach eil dligheach airson an dàrna cuid `&` no `&mut`.
    //

    /// Stores a luach an-dràsta ma tha luach an aon rud a `old` luach.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsaichean [`atomic`] tron dòigh `compare_exchange` le bhith a `dol seachad air [`Ordering::SeqCst`] mar gach cuid paramadairean `success` agus `failure`.
    ///
    /// Mar eisimpleir, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a luach an-dràsta ma tha luach an aon rud a `old` luach.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsaichean [`atomic`] tron dòigh `compare_exchange` le bhith a `dol seachad air [`Ordering::Acquire`] mar gach cuid paramadairean `success` agus `failure`.
    ///
    /// Mar eisimpleir, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a luach an-dràsta ma tha luach an aon rud a `old` luach.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `compare_exchange` dòigh le bhith a 'dol seachad [`Ordering::Release`] mar an `success` agus [`Ordering::Relaxed`] mar an `failure` crìochan.
    /// Mar eisimpleir, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a luach an-dràsta ma tha luach an aon rud a `old` luach.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `compare_exchange` dòigh le bhith a 'dol seachad [`Ordering::AcqRel`] mar an `success` agus [`Ordering::Acquire`] mar an `failure` crìochan.
    /// Mar eisimpleir, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a luach an-dràsta ma tha luach an aon rud a `old` luach.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsaichean [`atomic`] tron dòigh `compare_exchange` le bhith a `dol seachad air [`Ordering::Relaxed`] mar gach cuid paramadairean `success` agus `failure`.
    ///
    /// Mar eisimpleir, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a luach an-dràsta ma tha luach an aon rud a `old` luach.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `compare_exchange` le bhith a `dol seachad air [`Ordering::SeqCst`] mar an `success` agus [`Ordering::Relaxed`] mar pharamadairean `failure`.
    /// Mar eisimpleir, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a luach an-dràsta ma tha luach an aon rud a `old` luach.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `compare_exchange` le bhith a `dol seachad air [`Ordering::SeqCst`] mar an `success` agus [`Ordering::Acquire`] mar pharamadairean `failure`.
    /// Mar eisimpleir, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a luach an-dràsta ma tha luach an aon rud a `old` luach.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `compare_exchange` dòigh le bhith a 'dol seachad [`Ordering::Acquire`] mar an `success` agus [`Ordering::Relaxed`] mar an `failure` crìochan.
    /// Mar eisimpleir, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a luach an-dràsta ma tha luach an aon rud a `old` luach.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `compare_exchange` le bhith a `dol seachad air [`Ordering::AcqRel`] mar an `success` agus [`Ordering::Relaxed`] mar pharamadairean `failure`.
    /// Mar eisimpleir, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Stores a luach an-dràsta ma tha luach an aon rud a `old` luach.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsaichean [`atomic`] tron dòigh `compare_exchange_weak` le bhith a `dol seachad air [`Ordering::SeqCst`] mar gach cuid paramadairean `success` agus `failure`.
    ///
    /// Mar eisimpleir, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a luach an-dràsta ma tha luach an aon rud a `old` luach.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsaichean [`atomic`] tron dòigh `compare_exchange_weak` le bhith a `dol seachad air [`Ordering::Acquire`] mar gach cuid paramadairean `success` agus `failure`.
    ///
    /// Mar eisimpleir, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a luach an-dràsta ma tha luach an aon rud a `old` luach.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `compare_exchange_weak` le bhith a `dol seachad air [`Ordering::Release`] mar an `success` agus [`Ordering::Relaxed`] mar pharamadairean `failure`.
    /// Mar eisimpleir, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a luach an-dràsta ma tha luach an aon rud a `old` luach.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `compare_exchange_weak` le bhith a `dol seachad air [`Ordering::AcqRel`] mar an `success` agus [`Ordering::Acquire`] mar pharamadairean `failure`.
    /// Mar eisimpleir, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a luach an-dràsta ma tha luach an aon rud a `old` luach.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsaichean [`atomic`] tron dòigh `compare_exchange_weak` le bhith a `dol seachad air [`Ordering::Relaxed`] mar gach cuid paramadairean `success` agus `failure`.
    ///
    /// Mar eisimpleir, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a luach an-dràsta ma tha luach an aon rud a `old` luach.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `compare_exchange_weak` dòigh le bhith a 'dol seachad [`Ordering::SeqCst`] mar an `success` agus [`Ordering::Relaxed`] mar an `failure` crìochan.
    /// Mar eisimpleir, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a luach an-dràsta ma tha luach an aon rud a `old` luach.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `compare_exchange_weak` dòigh le bhith a 'dol seachad [`Ordering::SeqCst`] mar an `success` agus [`Ordering::Acquire`] mar an `failure` crìochan.
    /// Mar eisimpleir, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a luach an-dràsta ma tha luach an aon rud a `old` luach.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `compare_exchange_weak` le bhith a `dol seachad air [`Ordering::Acquire`] mar an `success` agus [`Ordering::Relaxed`] mar pharamadairean `failure`.
    /// Mar eisimpleir, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a luach an-dràsta ma tha luach an aon rud a `old` luach.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `compare_exchange_weak` le bhith a `dol seachad air [`Ordering::AcqRel`] mar an `success` agus [`Ordering::Relaxed`] mar pharamadairean `failure`.
    /// Mar eisimpleir, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// A `luchdachadh luach làithreach a` phuing.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `load` le bhith a `dol seachad air [`Ordering::SeqCst`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// A `luchdachadh luach làithreach a` phuing.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `load` le bhith a `dol seachad air [`Ordering::Acquire`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// A `luchdachadh luach làithreach a` phuing.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `load` le bhith a `dol seachad air [`Ordering::Relaxed`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Stores an luach aig an comharraichte memory location.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `store` dòigh le bhith a 'dol seachad [`Ordering::SeqCst`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Stores an luach aig an comharraichte memory location.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `store` le bhith a `dol seachad air [`Ordering::Release`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Stores an luach aig an comharraichte memory location.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `store` le bhith a `dol seachad air [`Ordering::Relaxed`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// A `stòradh an luach aig an àite cuimhne ainmichte, a` tilleadh an t-seann luach.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `swap` dòigh le bhith a 'dol seachad [`Ordering::SeqCst`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// A `stòradh an luach aig an àite cuimhne ainmichte, a` tilleadh an t-seann luach.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `swap` dòigh le bhith a 'dol seachad [`Ordering::Acquire`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// A `stòradh an luach aig an àite cuimhne ainmichte, a` tilleadh an t-seann luach.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `swap` le bhith a `dol seachad air [`Ordering::Release`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// A `stòradh an luach aig an àite cuimhne ainmichte, a` tilleadh an t-seann luach.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsaichean [`atomic`] tron dòigh `swap` le bhith a `dol seachad air [`Ordering::AcqRel`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// A `stòradh an luach aig an àite cuimhne ainmichte, a` tilleadh an t-seann luach.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `swap` dòigh le bhith a 'dol seachad [`Ordering::Relaxed`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// A `cur ris an luach làithreach, a` tilleadh an luach a bh `ann roimhe.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `fetch_add` le bhith a `dol seachad air [`Ordering::SeqCst`] mar an `order`.
    /// Mar eisimpleir, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// A `cur ris an luach làithreach, a` tilleadh an luach a bh `ann roimhe.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `fetch_add` le bhith a `dol seachad air [`Ordering::Acquire`] mar an `order`.
    /// Mar eisimpleir, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// A `cur ris an luach làithreach, a` tilleadh an luach a bh `ann roimhe.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `fetch_add` dòigh le bhith a 'dol seachad [`Ordering::Release`] mar an `order`.
    /// Mar eisimpleir, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// A `cur ris an luach làithreach, a` tilleadh an luach a bh `ann roimhe.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `fetch_add` dòigh le bhith a 'dol seachad [`Ordering::AcqRel`] mar an `order`.
    /// Mar eisimpleir, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// A `cur ris an luach làithreach, a` tilleadh an luach a bh `ann roimhe.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `fetch_add` dòigh le bhith a 'dol seachad [`Ordering::Relaxed`] mar an `order`.
    /// Mar eisimpleir, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Thoir air falbh bho an-dràsta a 'cur luach, a' tilleadh roimhe luach.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `fetch_sub` dòigh le bhith a 'dol seachad [`Ordering::SeqCst`] mar an `order`.
    /// Mar eisimpleir, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Thoir air falbh bho an-dràsta a 'cur luach, a' tilleadh roimhe luach.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `fetch_sub` le bhith a `dol seachad air [`Ordering::Acquire`] mar an `order`.
    /// Mar eisimpleir, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Thoir air falbh bho an-dràsta a 'cur luach, a' tilleadh roimhe luach.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `fetch_sub` le bhith a `dol seachad air [`Ordering::Release`] mar an `order`.
    /// Mar eisimpleir, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Thoir air falbh bho an-dràsta a 'cur luach, a' tilleadh roimhe luach.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `fetch_sub` le bhith a `dol seachad air [`Ordering::AcqRel`] mar an `order`.
    /// Mar eisimpleir, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Thoir air falbh bho an-dràsta a 'cur luach, a' tilleadh roimhe luach.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `fetch_sub` dòigh le bhith a 'dol seachad [`Ordering::Relaxed`] mar an `order`.
    /// Mar eisimpleir, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise agus leis an luach làithreach, a `tilleadh an luach a bh` ann roimhe.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `fetch_and` dòigh le bhith a 'dol seachad [`Ordering::SeqCst`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise agus leis an luach làithreach, a `tilleadh an luach a bh` ann roimhe.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `fetch_and` le bhith a `dol seachad air [`Ordering::Acquire`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise agus leis an luach làithreach, a `tilleadh an luach a bh` ann roimhe.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `fetch_and` le bhith a `dol seachad air [`Ordering::Release`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise agus leis an luach làithreach, a `tilleadh an luach a bh` ann roimhe.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `fetch_and` le bhith a `dol seachad air [`Ordering::AcqRel`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise agus leis an luach làithreach, a `tilleadh an luach a bh` ann roimhe.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `fetch_and` dòigh le bhith a 'dol seachad [`Ordering::Relaxed`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand leis an luach làithreach, a `tilleadh an luach roimhe.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air an t-seòrsa [`AtomicBool`] tron dòigh `fetch_nand` le bhith a `dol seachad air [`Ordering::SeqCst`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand leis an luach làithreach, a `tilleadh an luach roimhe.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air an t-seòrsa [`AtomicBool`] tron dòigh `fetch_nand` le bhith a `dol seachad air [`Ordering::Acquire`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand leis an luach làithreach, a `tilleadh an luach roimhe.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`AtomicBool`] tro `fetch_nand` dòigh le bhith a 'dol seachad [`Ordering::Release`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand leis an luach làithreach, a `tilleadh an luach roimhe.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air an t-seòrsa [`AtomicBool`] tron dòigh `fetch_nand` le bhith a `dol seachad air [`Ordering::AcqRel`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand leis an luach làithreach, a `tilleadh an luach roimhe.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air an t-seòrsa [`AtomicBool`] tron dòigh `fetch_nand` le bhith a `dol seachad air [`Ordering::Relaxed`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Gu ceart no leis an luach làithreach, a `tilleadh an luach a bh` ann roimhe.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `fetch_or` le bhith a `dol seachad air [`Ordering::SeqCst`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gu ceart no leis an luach làithreach, a `tilleadh an luach a bh` ann roimhe.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `fetch_or` le bhith a `dol seachad air [`Ordering::Acquire`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gu ceart no leis an luach làithreach, a `tilleadh an luach a bh` ann roimhe.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `fetch_or` dòigh le bhith a 'dol seachad [`Ordering::Release`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gu ceart no leis an luach làithreach, a `tilleadh an luach a bh` ann roimhe.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `fetch_or` le bhith a `dol seachad air [`Ordering::AcqRel`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gu ceart no leis an luach làithreach, a `tilleadh an luach a bh` ann roimhe.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `fetch_or` dòigh le bhith a 'dol seachad [`Ordering::Relaxed`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor leis an luach làithreach, a `tilleadh an luach roimhe.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `fetch_xor` le bhith a `dol seachad air [`Ordering::SeqCst`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor leis an luach làithreach, a `tilleadh an luach roimhe.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `fetch_xor` le bhith a `dol seachad air [`Ordering::Acquire`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor leis an luach làithreach, a `tilleadh an luach roimhe.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaighinn air an seòrsa [`atomic`] tro `fetch_xor` dòigh le bhith a 'dol seachad [`Ordering::Release`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor leis an luach làithreach, a `tilleadh an luach roimhe.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `fetch_xor` le bhith a `dol seachad air [`Ordering::AcqRel`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor leis an luach làithreach, a `tilleadh an luach roimhe.
    ///
    /// Gheibhear an dreach seasmhach den bhroinn seo air na seòrsachan [`atomic`] tron dòigh `fetch_xor` le bhith a `dol seachad air [`Ordering::Relaxed`] mar an `order`.
    /// Mar eisimpleir, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// As àirde leis an luach làithreach a `cleachdadh coimeas soidhnichte.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaotainn air an [`atomic`] shoidhnigeadh integer seòrsa tro `fetch_max` dòigh le bhith a 'dol seachad [`Ordering::SeqCst`] mar an `order`.
    /// Mar eisimpleir, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// As àirde leis an luach làithreach a `cleachdadh coimeas soidhnichte.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaotainn air an [`atomic`] shoidhnigeadh integer seòrsa tro `fetch_max` dòigh le bhith a 'dol seachad [`Ordering::Acquire`] mar an `order`.
    /// Mar eisimpleir, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// As àirde leis an luach làithreach a `cleachdadh coimeas soidhnichte.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsachan integer soidhnichte [`atomic`] tron dòigh `fetch_max` le bhith a `dol seachad air [`Ordering::Release`] mar an `order`.
    /// Mar eisimpleir, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// As àirde leis an luach làithreach a `cleachdadh coimeas soidhnichte.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaotainn air an [`atomic`] shoidhnigeadh integer seòrsa tro `fetch_max` dòigh le bhith a 'dol seachad [`Ordering::AcqRel`] mar an `order`.
    /// Mar eisimpleir, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// As àirde leis an luach làithreach.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsachan integer soidhnichte [`atomic`] tron dòigh `fetch_max` le bhith a `dol seachad air [`Ordering::Relaxed`] mar an `order`.
    /// Mar eisimpleir, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Co-dhiù leis an luach làithreach a `cleachdadh coimeas soidhnichte.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsachan integer soidhnichte [`atomic`] tron dòigh `fetch_min` le bhith a `dol seachad air [`Ordering::SeqCst`] mar an `order`.
    /// Mar eisimpleir, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Co-dhiù leis an luach làithreach a `cleachdadh coimeas soidhnichte.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaotainn air an [`atomic`] shoidhnigeadh integer seòrsa tro `fetch_min` dòigh le bhith a 'dol seachad [`Ordering::Acquire`] mar an `order`.
    /// Mar eisimpleir, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Co-dhiù leis an luach làithreach a `cleachdadh coimeas soidhnichte.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsachan integer soidhnichte [`atomic`] tron dòigh `fetch_min` le bhith a `dol seachad air [`Ordering::Release`] mar an `order`.
    /// Mar eisimpleir, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Co-dhiù leis an luach làithreach a `cleachdadh coimeas soidhnichte.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsachan integer soidhnichte [`atomic`] tron dòigh `fetch_min` le bhith a `dol seachad air [`Ordering::AcqRel`] mar an `order`.
    /// Mar eisimpleir, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Co-dhiù leis an luach làithreach a `cleachdadh coimeas soidhnichte.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaotainn air an [`atomic`] shoidhnigeadh integer seòrsa tro `fetch_min` dòigh le bhith a 'dol seachad [`Ordering::Relaxed`] mar an `order`.
    /// Mar eisimpleir, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// As ìsle tron leis an luach a 'cleachdadh an soidhnigeadh coimeas.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsachan integer gun ainm [`atomic`] tron dòigh `fetch_min` le bhith a `dol seachad air [`Ordering::SeqCst`] mar an `order`.
    /// Mar eisimpleir, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// As ìsle tron leis an luach a 'cleachdadh an soidhnigeadh coimeas.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsachan integer gun ainm [`atomic`] tron dòigh `fetch_min` le bhith a `dol seachad air [`Ordering::Acquire`] mar an `order`.
    /// Mar eisimpleir, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// As ìsle tron leis an luach a 'cleachdadh an soidhnigeadh coimeas.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsachan integer gun ainm [`atomic`] tron dòigh `fetch_min` le bhith a `dol seachad air [`Ordering::Release`] mar an `order`.
    /// Mar eisimpleir, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// As ìsle tron leis an luach a 'cleachdadh an soidhnigeadh coimeas.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsachan integer gun ainm [`atomic`] tron dòigh `fetch_min` le bhith a `dol seachad air [`Ordering::AcqRel`] mar an `order`.
    /// Mar eisimpleir, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// As ìsle tron leis an luach a 'cleachdadh an soidhnigeadh coimeas.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsachan integer gun ainm [`atomic`] tron dòigh `fetch_min` le bhith a `dol seachad air [`Ordering::Relaxed`] mar an `order`.
    /// Mar eisimpleir, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Teòthachd as àirde tron leis an luach a 'cleachdadh an soidhnigeadh coimeas.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsachan integer gun ainm [`atomic`] tron dòigh `fetch_max` le bhith a `dol seachad air [`Ordering::SeqCst`] mar an `order`.
    /// Mar eisimpleir, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Teòthachd as àirde tron leis an luach a 'cleachdadh an soidhnigeadh coimeas.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaotainn air an soidhnigeadh [`atomic`] integer seòrsa tro `fetch_max` dòigh le bhith a 'dol seachad [`Ordering::Acquire`] mar an `order`.
    /// Mar eisimpleir, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Teòthachd as àirde tron leis an luach a 'cleachdadh an soidhnigeadh coimeas.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsachan integer gun ainm [`atomic`] tron dòigh `fetch_max` le bhith a `dol seachad air [`Ordering::Release`] mar an `order`.
    /// Mar eisimpleir, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Teòthachd as àirde tron leis an luach a 'cleachdadh an soidhnigeadh coimeas.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn air na seòrsachan integer gun ainm [`atomic`] tron dòigh `fetch_max` le bhith a `dol seachad air [`Ordering::AcqRel`] mar an `order`.
    /// Mar eisimpleir, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Teòthachd as àirde tron leis an luach a 'cleachdadh an soidhnigeadh coimeas.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaotainn air an soidhnigeadh [`atomic`] integer seòrsa tro `fetch_max` dòigh le bhith a 'dol seachad [`Ordering::Relaxed`] mar an `order`.
    /// Mar eisimpleir, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Tha an gnèitheach `prefetch` mar mholadh don ghineadair còd gus stiùireadh ro-làimh a chuir a-steach ma tha taic ann;air dhòigh eile, is e neo-op a th `ann.
    /// Chan eil buaidh sam bith aig ro-aithrisean air giùlan a `phrògraim ach faodaidh iad na feartan coileanaidh aige atharrachadh.
    ///
    /// Feumaidh an argamaid `locality` a bhith gu h-iomlan seasmhach agus tha e na shònraiche sgìreil ùineail bho (0), gun sgìre, gu (3), glè ionadail airson a chumail ann an tasgadan.
    ///
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Tha an gnèitheach `prefetch` mar mholadh don ghineadair còd gus stiùireadh ro-làimh a chuir a-steach ma tha taic ann;air dhòigh eile, is e neo-op a th `ann.
    /// Chan eil buaidh sam bith aig ro-aithrisean air giùlan a `phrògraim ach faodaidh iad na feartan coileanaidh aige atharrachadh.
    ///
    /// Feumaidh an argamaid `locality` a bhith gu h-iomlan seasmhach agus tha e na shònraiche sgìreil ùineail bho (0), gun sgìre, gu (3), glè ionadail airson a chumail ann an tasgadan.
    ///
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Tha an gnèitheach `prefetch` mar mholadh don ghineadair còd gus stiùireadh ro-làimh a chuir a-steach ma tha taic ann;air dhòigh eile, is e neo-op a th `ann.
    /// Chan eil buaidh sam bith aig ro-aithrisean air giùlan a `phrògraim ach faodaidh iad na feartan coileanaidh aige atharrachadh.
    ///
    /// Feumaidh an argamaid `locality` a bhith gu h-iomlan seasmhach agus tha e na shònraiche sgìreil ùineail bho (0), gun sgìre, gu (3), glè ionadail airson a chumail ann an tasgadan.
    ///
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Tha an gnèitheach `prefetch` mar mholadh don ghineadair còd gus stiùireadh ro-làimh a chuir a-steach ma tha taic ann;air dhòigh eile, is e neo-op a th `ann.
    /// Chan eil buaidh sam bith aig ro-aithrisean air giùlan a `phrògraim ach faodaidh iad na feartan coileanaidh aige atharrachadh.
    ///
    /// Feumaidh an argamaid `locality` a bhith gu h-iomlan seasmhach agus tha e na shònraiche sgìreil ùineail bho (0), gun sgìre, gu (3), glè ionadail airson a chumail ann an tasgadan.
    ///
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Feansa atamach.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaotainn ann an [`atomic::fence`] le bhith a 'dol seachad [`Ordering::SeqCst`] mar an `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Feansa atamach.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn ann an [`atomic::fence`] le bhith a `dol seachad air [`Ordering::Acquire`] mar an `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Feansa atamach.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn ann an [`atomic::fence`] le bhith a `dol seachad air [`Ordering::Release`] mar an `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Feansa atamach.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaotainn ann an [`atomic::fence`] le bhith a 'dol seachad [`Ordering::AcqRel`] mar an `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Cnap-starra cuimhne a-mhàin.
    ///
    /// Cha tèid slighean cuimhne a-riamh ath-òrdachadh thairis air a `chnap-starra seo leis an t-inneal-cruinneachaidh, ach cha tèid stiùireadh sam bith a sgaoileadh air a shon.
    /// Tha seo freagarrach airson obraichean air an aon snàithlean a dh'fhaodadh a bhith preempted, leithid nuair a eadar-obrachadh le chomharran-treòrachaidh.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn ann an [`atomic::compiler_fence`] le bhith a `dol seachad air [`Ordering::SeqCst`] mar an `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Cnap-starra cuimhne a-mhàin.
    ///
    /// Cha tèid slighean cuimhne a-riamh ath-òrdachadh thairis air a `chnap-starra seo leis an t-inneal-cruinneachaidh, ach cha tèid stiùireadh sam bith a sgaoileadh air a shon.
    /// Tha seo freagarrach airson obraichean air an aon snàithlean a dh'fhaodadh a bhith preempted, leithid nuair a eadar-obrachadh le chomharran-treòrachaidh.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn ann an [`atomic::compiler_fence`] le bhith a `dol seachad air [`Ordering::Acquire`] mar an `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Cnap-starra cuimhne a-mhàin.
    ///
    /// Cha tèid slighean cuimhne a-riamh ath-òrdachadh thairis air a `chnap-starra seo leis an t-inneal-cruinneachaidh, ach cha tèid stiùireadh sam bith a sgaoileadh air a shon.
    /// Tha seo freagarrach airson obraichean air an aon snàithlean a dh'fhaodadh a bhith preempted, leithid nuair a eadar-obrachadh le chomharran-treòrachaidh.
    ///
    /// Tha an dreach seasmhach den bhroinn seo ri fhaighinn ann an [`atomic::compiler_fence`] le bhith a `dol seachad air [`Ordering::Release`] mar an `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Cnap-starra cuimhne a-mhàin.
    ///
    /// Cha tèid slighean cuimhne a-riamh ath-òrdachadh thairis air a `chnap-starra seo leis an t-inneal-cruinneachaidh, ach cha tèid stiùireadh sam bith a sgaoileadh air a shon.
    /// Tha seo freagarrach airson obraichean air an aon snàithlean a dh'fhaodadh a bhith preempted, leithid nuair a eadar-obrachadh le chomharran-treòrachaidh.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha ri fhaotainn ann an [`atomic::compiler_fence`] le bhith a 'dol seachad [`Ordering::AcqRel`] mar an `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Draoidheachd ghnèitheach a gheibh a bhrìgh bho bhuadhan a tha ceangailte ris a `ghnìomh.
    ///
    /// Mar eisimpleir, bidh dataflow a `cleachdadh seo gus dearbhaidhean statach a stealladh gus am biodh `rustc_peek(potentially_uninitialized)` a` dèanamh sgrùdadh dùbailte gun robh dataflow gu dearbh a `tomhas gu bheil e neo-aithnichte aig an ìre sin den t-sruth smachd.
    ///
    ///
    /// Cha bu chòir an gnèitheach seo a chleachdadh taobh a-muigh an trusaiche.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Aborts bàs a 'phròiseas.
    ///
    /// Is e dreach nas fhasa a chleachdadh agus seasmhach den obair seo [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// A `toirt fios don optimizer nach gabh ruigsinn air a` phuing seo sa chòd, a `comasachadh tuilleadh optimizations.
    ///
    /// NB, tha seo gu math eadar-dhealaichte bhon macro `unreachable!()`: Eu-coltach ris an macro, a tha panics nuair a thèid a chur gu bàs, tha e *giùlan neo-mhìnichte* gus còd a tha air a chomharrachadh leis a `ghnìomh seo a ruighinn.
    ///
    ///
    /// Is e an dreach seasmhach den bhroinn seo [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// A `toirt fios don optimizer gu bheil suidheachadh an-còmhnaidh fìor.
    /// Ma bhios an staid a tha ceàrr, a 'giùlan a tha undefined.
    ///
    /// Chan eil còd sam bith air a chruthachadh airson an gnèitheach seo, ach feuchaidh an optimizer ri a ghlèidheadh (agus a staid) eadar pasan, a dh `fhaodadh a bhith a` cur bacadh air optimachadh a `chòd mun cuairt agus a` lughdachadh coileanadh.
    /// Cha bu chòir a chleachdadh ma thèid an invariant a lorg leis an optimizer leis fhèin, no mura h-eil e a `comasachadh optimizations cudromach sam bith.
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Beachdan don neach-cruinneachaidh gu bheil coltas ann gu bheil suidheachadh branch fìor.
    /// A `tilleadh an luach a chaidh a thoirt dha.
    ///
    /// Is dòcha nach bi buaidh aig cleachdadh sam bith ach le aithrisean `if`.
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Taic gus an cruinneachadh a branch staid a tha buailteach a bhith meallta.
    /// A `tilleadh an luach a chaidh a thoirt dha.
    ///
    /// Is dòcha nach bi buaidh aig cleachdadh sam bith ach le aithrisean `if`.
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// A `cur an gnìomh ribe brisidh, airson sgrùdadh le dì-bhugadair.
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    pub fn breakpoint();

    /// Meud seòrsa ann am bytes.
    ///
    /// Gu sònraichte, is e seo an cothromachadh ann am bytes eadar nithean leantainneach den aon sheòrsa, a `gabhail a-steach pleadhachadh co-thaobhadh.
    ///
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// An co-thaobhadh as lugha de sheòrsa.
    ///
    /// Is e an dreach seasmhach den bhroinn seo [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// An co-thaobhadh as fheàrr le seòrsa.
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Meud an luach ainmichte ann am bytes.
    ///
    /// Is e an dreach seasmhach den bhroinn seo [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Tha feum air co-thaobhadh de na iomradh a luach.
    ///
    /// Is e an dreach seasmhach den bhroinn seo [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Faigh sliseag sreang statach anns a bheil ainm seòrsa.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// A `faighinn aithnichear a tha gun samhail air feadh na cruinne don t-seòrsa ainmichte.
    /// A 'ghnìomh seo bidh till an aon luach airson a dh'aindeoin seòrsa crate ge brith dè a tha e invoked ann.
    ///
    ///
    /// Is e an dreach seasmhach den bhroinn seo [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// A fhreiceadain sàbhailte airson gnìomhan nach urrainn a bhith air a chur gu bàs ma `T` fuireach:
    /// Bidh seo gu statach an dàrna cuid panic, no gun dad a dhèanamh.
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// A fhreiceadain sàbhailte airson gnìomhan nach urrainn a bhith air a chur gu bàs ma `T` Chan eil cead neoni-initialization: bidh seo a statically an dara cuid panic, no càil a dhèanamh.
    ///
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    pub fn assert_zero_valid<T>();

    /// Geàrd airson gnìomhan neo-shàbhailte nach gabh a chuir gu bàs a-riamh ma tha pàtrain bit neo-dhligheach aig `T`: Nì seo gu statach an dàrna cuid panic, no cha dèan e dad.
    ///
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    pub fn assert_uninit_valid<T>();

    /// A `faighinn iomradh air `Location` statach a` nochdadh far an deach a ghairm.
    ///
    /// Beachdaich air a bhith a `cleachdadh [`core::panic::Location::caller`](crate::panic::Location::caller) na àite.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Gluais luach a-mach à farsaingeachd gun a bhith a `ruith glaodh drop.
    ///
    /// Tha seo ann dìreach airson [`mem::forget_unsized`];bidh `forget` àbhaisteach a `cleachdadh `ManuallyDrop` na àite.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterprets na pìosan de luach aon seòrsa mar sheòrsa eile.
    ///
    /// Feumaidh an aon sheòrsa a bhith den aon mheud.
    /// Chan fhaod an [invalid value](../../nomicon/what-unsafe-does.html) tùsail, no an toradh tùsail a bhith.
    ///
    /// `transmute` tha semantically co-ionann ri gluasad bitwise de aon sheòrsa a-steach do sheòrsa eile.Bidh e a `dèanamh lethbhreac de na pìosan bhon luach stòr a-steach don luach ceann-uidhe, agus an uairsin a` dìochuimhneachadh na tùsail.
    /// Tha e co-ionann ri C's `memcpy` fon chochall, dìreach mar `transmute_copy`.
    ///
    /// Seach `transmute` 'S e le luach-obrachadh, a' co-thaobhadh *transmuted luachan fhèin* Chan eil uallach.
    /// Coltach ri gnìomh sam bith eile, tha an trusaiche mu thràth a `dèanamh cinnteach gu bheil an dà chuid `T` agus `U` air an aon rèir gu ceart.
    /// Ach, nuair a tha e ag atharrachadh luachan a tha *a `comharrachadh ann an àiteachan eile*(leithid molaidhean, iomraidhean, bogsaichean…), feumaidh an neach-fòn dèanamh cinnteach gu bheil na luachan comharraichte a` co-thaobhadh gu ceart.
    ///
    /// `transmute` tha **iongantach** cunnartach.Tha grunn dhòighean ann airson [undefined behavior][ub] adhbhrachadh leis a `ghnìomh seo.Bu chòir `transmute` a bhith mar an roghainn mu dheireadh.
    ///
    /// Tha sgrìobhainnean a bharrachd aig an [nomicon](../../nomicon/transmutes.html).
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Tha beagan rudan a `transmute` tha air leth feumail don.
    ///
    /// A `tionndadh stiùireadh gu stiùireadh gnìomh.Chan eil seo * so-ghiùlain gu innealan far a bheil comharran gnìomh agus comharran dàta de dhiofar mheudan.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// A `leudachadh beatha, no a` giorrachadh beatha invariant.Tha seo adhartach, gu math mì-shàbhailte Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Na bi eu-dòchas: gabhaidh mòran chleachdadh de `transmute` a choileanadh tro dhòighean eile.
    /// Gu h-ìosal tha tagraidhean cumanta de `transmute` a ghabhas togail nas sàbhailte a chur nan àite.
    ///
    /// A `tionndadh bytes(`&[u8]`) amh gu `u32`, `f64`, msaa .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // cleachdadh `u32::from_ne_bytes` àite
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // no cleachd `u32::from_le_bytes` no `u32::from_be_bytes` gus an seasmhachd a shònrachadh
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// A `tionndadh stiùireadh gu `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Cleachd tilgeadh `as` na àite
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// A `tionndadh `*mut T` gu `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Cleachd reborrow na àite
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// A `tionndadh `&mut T` gu `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // A-nis, cuir `as` ri chèile agus ath-chuairteachadh, thoir fa-near nach eil slabhraidh `as` `as` gluasadach
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// A `tionndadh `&str` gu `&[u8]`:
    ///
    /// ```
    /// // chan e seo dòigh mhath air seo a dhèanamh.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // B `urrainn dhut `str::as_bytes` a chleachdadh
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Air neo, dìreach cleachd sreang byte, ma tha smachd agad air an t-sreang litireil
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// A `tionndadh `Vec<&T>` gu `Vec<Option<&T>>`.
    ///
    /// Gus an seòrsa susbaint a-staigh de stuth-giùlain a thionndadh thairis, feumaidh tu dèanamh cinnteach nach bris thu gin de na h-invariants an container.
    /// Airson `Vec`, tha seo a `ciallachadh gum feum an dà chuid meud *agus co-thaobhadh* de na seòrsaichean a-staigh a bhith a` maidseadh.
    /// Dh `fhaodadh gum biodh soithichean eile an urra ri meud an t-seòrsa, co-thaobhadh, no eadhon an `TypeId`, agus sa chùis seo cha bhiodh e comasach transmuting a dhèanamh gun a bhith a` dol an aghaidh ionnsaigh nan soithichean.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // clone an vector oir cleachdaidh sinn iad a-rithist
    /// let v_clone = v_orig.clone();
    ///
    /// // A `cleachdadh transmute: tha seo an urra ri cruth dàta neo-ainmichte `Vec`, a tha na dhroch bheachd agus a dh` fhaodadh giùlan neo-mhìnichte adhbhrachadh.
    /////
    /// // Ach, chan eil e leth-bhreac.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Is e seo an dòigh sàbhailte a thathar a `moladh.
    /// // Bidh e a `dèanamh lethbhreac den vector gu lèir, ge-tà, gu sreath ùr.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Is e seo an dòigh neo-chopaidh, neo-shàbhailte ceart de "transmuting" a `Vec`, gun a bhith an urra ri cruth an dàta.
    /// // An àite a bhith a 'gairm `transmute` litireil, tha sinn a' coileanadh na chomharra cumte, ach a thaobh atharrachadh thùsail taobh a-staigh an seòrsa (`&i32`) dhan an tè ùir (`Option<&i32>`) seo, tha a h-uile aon cùmhnantan.
    /////
    /// // A bharrachd air an fhiosrachadh gu h-àrd, thoir sùil cuideachd air sgrìobhainnean [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Ùraich seo nuair a thèid vec_into_raw_parts a dhèanamh seasmhach.
    ///     // Dèan cinnteach nach tèid an vector tùsail a leigeil sìos.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Buileachadh `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Tha iomadh dòighean gus seo a dhèanamh, agus tha iomadh duilgheadasan le na leanas (transmute) slighe.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // an toiseach: chan eil transmute seòrsa sàbhailte;is e a h-uile sgrùdadh gu bheil T agus
    ///         // Tha U den aon mheud.
    ///         // San dàrna àite, an seo, tha dà iomradh gluasadach agad a tha a `comharrachadh an aon chuimhne.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Bidh seo a `faighinn cuidhteas na duilgheadasan sàbhailteachd seòrsa;Cha toir `&mut *`* ach *dhut `&mut T` bho `&mut T` no `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // ge-tà, tha dà iomradh gluasadach agad fhathast a tha a `comharrachadh an aon chuimhne.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Seo mar a bhios an leabharlann àbhaisteach ga dhèanamh.
    /// // Is e seo an dòigh as fheàrr, ma dh `fheumas tu rudeigin mar seo a dhèanamh
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Tha seo a-nis tha trì mutable iomraidhean 'comharrachadh aig an aon chuimhne.`slice`, an rvalue ret.0, agus an rvalue ret.1.
    ///         // `slice` Tha e a-riamh air a chleachdadh an dèidh `let ptr = ...`, agus mar sin aon urrainn a làimhseachadh mar "dead", agus uime sin, tha thu a mhàin tha dà-rìribh mutable sliseagan.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Ged a bha seo a 'dèanamh an ghnèitheach const seasmhach, a tha beagan custom code ann const fn
    // sgrùdaidhean a chuireas casg air a chleachdadh taobh a-staigh `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// `true` ma thilleas na fìor-seòrsa a thoirt seachad mar `T` Feumaidh drop glaodh;a `tilleadh `false` ma tha an fhìor sheòrsa a chaidh a thoirt seachad airson `T` a` buileachadh `Copy`.
    ///
    ///
    /// Mura h-eil an seòrsa fhèin a `feumachdainn glaodh drop no a` buileachadh `Copy`, tha luach tilleadh na gnìomh seo neo-shònraichte.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Obraich a-mach an fhrith-thionndadh bho stiùireadh.
    ///
    /// Tha seo air a chuir an gnìomh mar dhòigh bunaiteach gus atharrachadh gu agus bho integer a sheachnadh, leis gum biodh an tionndadh a `tilgeil air falbh fiosrachadh co-cheangailte.
    ///
    /// # Safety
    ///
    /// Tha an dà chuid a 'tòiseachadh agus mar thoradh air na chomharra feumaidh gur ann aon chuid ann an crìochan no aon Byte seachad air an deireadh an riarachadh nì.
    /// Ma tha an dàrna cuid na chomharra a-mach à crìochan no àireamhachd overflow sam bith a 'tachairt an uair sin a' toirt barrachd feum de na thill luach Leanaidh undefined giùlan.
    ///
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// A 'cunntadh a' chothromachadh bho na chomharra, a dh'fhaodadh a bhith wrapping.
    ///
    /// Tha seo a 'cur an gnìomh mar ghnèitheach a sheachnadh atharrachadh gu agus bhon an integer, bhon a' cur bacadh air atharrachadh sònraichte optimizations.
    ///
    /// # Safety
    ///
    /// Eu-coltach ris an `offset` gnèitheach, chan eil an gnèitheach seo a `cuingealachadh a` phuing a tha mar thoradh air a bhith a `comharrachadh a-steach no aon bhit seachad air deireadh nì a chaidh a riarachadh, agus bidh e a` pasgadh le àireamhachd lìonaidh dithis.
    /// Tha an luach a th 'dòcha nach eil dligheach a thèid a chleachdadh gus cothrom dha-rìribh chuimhne.
    ///
    /// Is e an dreach seasmhach den bhroinn seo [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Co-ionann ri iomchaidh `llvm.memcpy.p0i8.0i8.*` gnèitheach, le meud `count`*`size_of::<T>()` agus co-thaobhadh
    ///
    /// `min_align_of::<T>()`
    ///
    /// Tha am paramadair luaineach air a shuidheachadh gu `true`, mar sin cha tèid a chuir a-mach mura h-eil meud co-ionann ri neoni.
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Co-ionann ri iomchaidh `llvm.memmove.p0i8.0i8.*` gnèitheach, le meud `count* size_of::<T>()` agus co-thaobhadh
    ///
    /// `min_align_of::<T>()`
    ///
    /// Tha am paramadair luaineach air a shuidheachadh gu `true`, mar sin cha tèid a chuir a-mach mura h-eil meud co-ionann ri neoni.
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Co-ionann ris an gnè iomchaidh `llvm.memset.p0i8.*`, le meud `count* size_of::<T>()` agus co-thaobhadh de `min_align_of::<T>()`.
    ///
    ///
    /// Tha am paramadair luaineach air a shuidheachadh gu `true`, mar sin cha tèid a chuir a-mach mura h-eil meud co-ionann ri neoni.
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Performs chugallach luchd bhon `src` chomharra.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Performs chugallach stòr gu `dst` chomharra.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Gabhail sradagach luchd bhon `src` chomharra Tha na chomharra nach eil feum air a bhith air an co-thaobhadh.
    ///
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Performs chugallach stòr gu `dst` chomharra.
    /// Chan eil feum air a `phuing a cho-thaobhadh.
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// A `tilleadh freumh ceàrnagach `f32`
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// A `tilleadh freumh ceàrnagach `f64`
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// A 'togail an `f32` gu integer cumhachd.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// A `togail `f64` gu cumhachd integer.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// A `tilleadh sine `f32`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Thilleas sine de `f64`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// A `tilleadh cosine an `f32`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// A `tilleadh cosine an `f64`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// A 'togail an `f32` gu `f32` cumhachd.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// A `togail `f64` gu cumhachd `f64`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Thilleas exponential de `f32`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Thilleas exponential de `f64`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Tilleadh 2 àrdachadh gu cumhachd an `f32`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Tilleadh 2 air a thogail gu cumhachd `f64`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// A `tilleadh logarithm nàdurrach `f32`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// A `tilleadh logarithm nàdurrach `f64`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// TILLEADH bonn 10 logarithm de `f32`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// A `tilleadh logarithm bonn 10 de `f64`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// A `tilleadh logarithm bonn 2 de `f32`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// A `tilleadh logarithm bonn 2 de `f64`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// A `tilleadh `a * b + c` airson luachan `f32`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// A `tilleadh `a * b + c` airson luachan `f64`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// A `tilleadh luach iomlan `f32`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// A `tilleadh luach iomlan `f64`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// A `tilleadh dà luach `f32` aig a` char as lugha.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Thilleas dhiù dà `f64` luachan.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// A `tilleadh dà luach `f32` aig a` char as àirde.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// A `tilleadh dà luach `f64` aig a` char as àirde.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Dèan lethbhreac den t-soidhne bho `y` gu `x` airson luachan `f32`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Dèan lethbhreac den t-soidhne bho `y` gu `x` airson luachan `f64`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// A `tilleadh an integer as motha nas lugha na no co-ionann ri `f32`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// A `tilleadh an integer as motha nas lugha na no co-ionann ri `f64`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// A `tilleadh an integer as lugha nas motha na no co-ionann ri `f32`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// A `tilleadh an integer as lugha nas motha na no co-ionann ri `f64`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// A `tilleadh am pàirt slàn de `f32`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// A `tilleadh am pàirt slàn de `f64`.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// A 'tilleadh as fhaisge integer gu `f32`.
    /// Dh `fhaodadh gun togadh seo eisgeachd neo-ghnìomhach far nach eil an argamaid gu h-iomlan.
    pub fn rintf32(x: f32) -> f32;
    /// A 'tilleadh as fhaisge integer gu `f64`.
    /// Dh `fhaodadh gun togadh seo eisgeachd neo-ghnìomhach far nach eil an argamaid gu h-iomlan.
    pub fn rintf64(x: f64) -> f64;

    /// A 'tilleadh as fhaisge integer gu `f32`.
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    pub fn nearbyintf32(x: f32) -> f32;
    /// A 'tilleadh as fhaisge integer gu `f64`.
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    pub fn nearbyintf64(x: f64) -> f64;

    /// A `tilleadh an integer as fhaisge air `f32`.Cuairtean cùisean letheach slighe air falbh bho neoni.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// A `tilleadh an integer as fhaisge air `f64`.Cuairtean cùisean letheach slighe air falbh bho neoni.
    ///
    /// Tha an dreach seasmhach den bhroinn seo
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Cur-ris air bhog a leigeas le optimizations stèidhichte air riaghailtean ailseabra.
    /// Faodaidh gabhail ris gu bheil inntrigidhean crìochnaichte.
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Toirt air falbh fleòdradh a leigeas le optimizations stèidhichte air riaghailtean ailseabra.
    /// Faodaidh gabhail ris gu bheil inntrigidhean crìochnaichte.
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Iomadachadh flot a leigeas le optimizations stèidhichte air riaghailtean ailseabra.
    /// Faodaidh gabhail ris gu bheil inntrigidhean crìochnaichte.
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Roinn flot a leigeas le optimizations stèidhichte air riaghailtean ailseabra.
    /// Faodaidh gabhail ris gu bheil inntrigidhean crìochnaichte.
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Float còrr a leigeas optimizations stèidhichte air ailseabra riaghailtean.
    /// Faodaidh gabhail ris gu bheil inntrigidhean crìochnaichte.
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Convert le LLVM aig fptoui/fptosi, a dh'fhaodadh till undef airson luachan a-mach à raon
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Crìonadh mar [`f32::to_int_unchecked`] agus [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// A `tilleadh an àireamh de bhuillean a chaidh a shuidheachadh ann an seòrsa integer `T`
    ///
    /// Tha na dreachan seasmhach den bhroinn seo rim faighinn air na prìomhairean iomlan tron dòigh `count_ones`.
    /// Mar eisimpleir,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// A `tilleadh an àireamh de phrìomh bhuillean neo-shuidhichte (zeroes) ann an seòrsa integer `T`.
    ///
    /// Tha crìonadh tionndaidhean de seo gnèitheach a tha ri fhaotainn air an integer primitives tro `leading_zeros` dòigh.
    /// Mar eisimpleir,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Tillidh an `x` le luach `0` an leud beagan de `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Like `ctlz`, ach taobh a-sàbhailte mar a tha e nuair a thilleas `undef` thoirt `x` le luach `0`.
    ///
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// A 'tilleadh an àireamh de slaodadh unset pìosan (zeroes) ann an integer seòrsa `T`.
    ///
    /// Tha na dreachan seasmhach den bhroinn seo rim faighinn air na prìomhairean iomlan tron dòigh `trailing_zeros`.
    /// Mar eisimpleir,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Tillidh an `x` le luach `0` an leud beagan `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Like `cttz`, ach taobh a-sàbhailte mar a tha e nuair a thilleas `undef` thoirt `x` le luach `0`.
    ///
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// A `dol air ais na bytes ann an seòrsa integer `T`.
    ///
    /// Tha na dreachan seasmhach den bhroinn seo rim faighinn air na prìomhairean iomlan tron dòigh `swap_bytes`.
    /// Mar eisimpleir,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Reverses na pìosan ann an integer seòrsa `T`.
    ///
    /// Tha na dreachan seasmhach den bhroinn seo rim faighinn air na prìomhairean iomlan tron dòigh `reverse_bits`.
    /// Mar eisimpleir,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// A `dèanamh sgrùdadh air cuir-ris iomlan.
    ///
    /// Tha crìonadh tionndaidhean de seo gnèitheach a tha ri fhaotainn air an integer primitives tro `overflowing_add` dòigh.
    /// Mar eisimpleir,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// A `dèanamh toirt air falbh sgrùdadh integer air a sgrùdadh
    ///
    /// Tha crìonadh tionndaidhean de seo gnèitheach a tha ri fhaotainn air an integer primitives tro `overflowing_sub` dòigh.
    /// Mar eisimpleir,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// A `dèanamh iomadachadh integer sgrùdaichte
    ///
    /// Tha na dreachan seasmhach den bhroinn seo rim faighinn air na prìomhairean iomlan tron dòigh `overflowing_mul`.
    /// Mar eisimpleir,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// A 'coileanadh an dearbh sgaradh, a' toradh ann undefined giùlan far `x % y != 0` no `y == 0` no `x == T::MIN && y == -1`
    ///
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// A `dèanamh sgaradh gun sgrùdadh, a` leantainn gu giùlan neo-mhìnichte far a bheil `y == 0` no `x == T::MIN && y == -1`
    ///
    ///
    /// Gheibhear pasgain sàbhailte airson an gnè seo air na prìomhairean iomlan tron dòigh `checked_div`.
    /// Mar eisimpleir,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// A 'tilleadh an còrr de unchecked roinneadh, a' toradh ann undefined giùlan nuair a `y == 0` no `x == T::MIN && y == -1`
    ///
    ///
    /// Gheibhear pasgain sàbhailte airson an gnè seo air na prìomhairean iomlan tron dòigh `checked_rem`.
    /// Mar eisimpleir,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// A `dèanamh gluasad clì gun sgrùdadh, a` leantainn gu giùlan neo-mhìnichte nuair a tha `y < 0` no `y >= N`, far a bheil N mar leud T ann am pìosan.
    ///
    ///
    /// Sàbhailte wrappers airson seo gnèitheach a tha ri fhaotainn air an integer primitives tro `checked_shl` dòigh.
    /// Mar eisimpleir,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Cluiche unchecked ceart shift, a 'toradh ann undefined giùlan nuair a `y < 0` no `y >= N`, far N e an leud ann an T pìosan.
    ///
    ///
    /// Sàbhailte wrappers airson seo gnèitheach a tha ri fhaotainn air an integer primitives tro `checked_shr` dòigh.
    /// Mar eisimpleir,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// A `tilleadh toradh cur-ris neo-sgrùdaichte, a` leantainn gu giùlan neo-mhìnichte nuair a `x + y > T::MAX` no `x + y < T::MIN`.
    ///
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// A `tilleadh toradh toirt air falbh gun sgrùdadh, a` leantainn gu giùlan neo-mhìnichte nuair a tha `x - y > T::MAX` no `x - y < T::MIN`.
    ///
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// A `tilleadh toradh iomadachadh neo-sgrùdaichte, a` leantainn gu giùlan neo-mhìnichte nuair a tha `x *y > T::MAX` no `x* y < T::MIN`.
    ///
    ///
    /// Chan eil companach seasmhach aig an gnè seo.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Performs Cuairteachaidh fhàgail.
    ///
    /// Tha crìonadh tionndaidhean de seo gnèitheach a tha ri fhaotainn air an integer primitives tro `rotate_left` dòigh.
    /// Mar eisimpleir,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// A `coileanadh cuairteachadh ceart.
    ///
    /// Tha crìonadh tionndaidhean de seo gnèitheach a tha ri fhaotainn air an integer primitives tro `rotate_right` dòigh.
    /// Mar eisimpleir,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Tilleadh (a + b) mod 2 <sup>N</sup>, far a bheil N an leud T ann am pìosan.
    ///
    /// Tha crìonadh tionndaidhean de seo gnèitheach a tha ri fhaotainn air an integer primitives tro `wrapping_add` dòigh.
    /// Mar eisimpleir,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Tilleadh (a, b) mod 2 <sup>N</sup>, far a bheil N mar leud T ann am pìosan.
    ///
    /// Tha na dreachan seasmhach den bhroinn seo rim faighinn air na prìomhairean iomlan tron dòigh `wrapping_sub`.
    /// Mar eisimpleir,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Tilleadh (a * b) mod 2 <sup>N</sup>, far a bheil N an leud T ann am pìosan.
    ///
    /// Tha na dreachan seasmhach den bhroinn seo rim faighinn air na prìomhairean iomlan tron dòigh `wrapping_mul`.
    /// Mar eisimpleir,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Computes `a + b`, saturating aig àireamhach crìochan.
    ///
    /// Tha crìonadh tionndaidhean de seo gnèitheach a tha ri fhaotainn air an integer primitives tro `saturating_add` dòigh.
    /// Mar eisimpleir,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Computes `a - b`, sùghaidh aig crìochan àireamhach.
    ///
    /// Tha crìonadh tionndaidhean de seo gnèitheach a tha ri fhaotainn air an integer primitives tro `saturating_sub` dòigh.
    /// Mar eisimpleir,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// A `tilleadh luach an neach a tha a` dèanamh leth-bhreith airson an caochladh ann an 'v';
    /// ma `T` Chan eil discriminant, a 'tilleadh `0`.
    ///
    /// Tha crìonadh dreach seo gnèitheach a tha [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// A `tilleadh an àireamh de dh` atharrachaidhean den t-seòrsa `T` a chaidh an cur gu `usize`;
    /// mura h-eil atharrachaidhean ann an `T`, tillidh `0`.Fàs Tionndaidhean thèid a chunntadh.
    ///
    /// Is e an dreach a tha ri dhèanamh seasmhach den ghnè ghnèitheach seo [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Togail `data` Rust a bheir ionnsaigh air a `phuing gnìomh `try_fn` leis a` phuing dàta `data`.
    ///
    /// Is e an treas argamaid gnìomh ris an canar ma thachras panic.
    /// Bidh an gnìomh seo a `toirt a` phuing dàta agus comharradh don nì eisgeachd sònraichte a chaidh a ghlacadh.
    ///
    /// Airson tuilleadh fiosrachaidh faic compiler aig tùs a thuilleadh std a ghlac chur an gnìomh.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// A `sgaoileadh stòr `!nontemporal` a rèir LLVM (faic na docaichean aca).
    /// 'S dòcha nach fàs seasmhach.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Faic sgrìobhainnean de `<*const T>::offset_from` airson mion-fhiosrachadh.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Faic sgrìobhainnean de `<*const T>::guaranteed_eq` airson mion-fhiosrachadh.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Faic sgrìobhainnean `<*const T>::guaranteed_ne` airson mion-fhiosrachadh.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Riarachadh aig àm cur ri chèile.Cha bu chòir a ghairm aig runtime.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Tha cuid de dhleastanasan air am mìneachadh an seo leis gu robh iad gun fhiosta rim faighinn sa mhodal seo air stàball.
// Faic <https://github.com/rust-lang/rust/issues/15702>.
// (Tha `transmute` cuideachd san roinn seo, ach chan urrainnear a phasgadh air sgàth an sgrùdadh gu bheil an aon mheud aig `T` agus `U`.)
//

/// A `dèanamh cinnteach a bheil `ptr` air a cho-thaobhadh gu ceart a thaobh `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Lethbhric `count *size_of::<T>()` bytes bho `src` gu `dst`.Feumaidh an stòr agus an ceann-uidhe* gun * a dhol thairis air.
///
/// Airson roinnean de chuimhne a dh `fhaodadh a dhol thairis air, cleachd [`copy`] na àite.
///
/// `copy_nonoverlapping` 'S e co-ionann ri semantically C [`memcpy`], ach leis an argamaid òrdugh a dhol.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Giùlan undefined ma tha gin de na cumhaichean a leanas a tha air an truailleadh:
///
/// * `src` feumaidh iad a bhith a 'leughadh airson [valid] de `count * size_of::<T>()` bytes.
///
/// * `dst` feumaidh iad a bhith [valid] airson sgrìobhadh `count * size_of::<T>()` bytes.
///
/// * Tha an dà `src` agus `dst` feumar ceart a rèir a chèile.
///
/// * An sgìre de chuimhne a `tòiseachadh aig `src` le meud de` cunntadh *
///   meud_of: :<T>() Feumaidh `bytes * gun a bhith a` dol thairis air an roinn cuimhne a `tòiseachadh aig `dst` leis an aon mheud.
///
/// Coltach ri [`read`], bidh `copy_nonoverlapping` a `cruthachadh leth-bhreac dòigheil de `T`, ge bith an e `T` [`Copy`].
/// Mura h-eil `T` [`Copy`], a `cleachdadh *an dà chuid* faodaidh na luachan san roinn a` tòiseachadh aig `*src` agus an roinn a `tòiseachadh aig `* dst` [violate memory safety][read-ownership].
///
///
/// Cuimhnich gur fiù 's ma tha na h-èifeachdach a lethbhreacadh meud (`cunntadh * size_of: :<T>()`) is `0`, feumaidh na comharran a bhith neo-NULL agus air an co-thaobhadh gu ceart.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] làimh a chur an gnìomh:
///
/// ```
/// use std::ptr;
///
/// /// Moves h-uile eileamaid de `src` `dst` a-steach, a 'fàgail `src` falamh.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Dèanamh cinnteach gu bheil gu leòr `dst` Tha comas a bhith a 'cumail a h-uile `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Tha an gairm airson cuir an-aghaidh an-còmhnaidh sàbhailte oir cha toir `Vec` a-riamh barrachd air `isize::MAX` bytes.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` gun a bhith a `leigeil às na tha ann.
///         // Tha sinn seo a dhèanamh an toiseach, gus nach bi duilgheadasan ann a 'chùis rudeigin nas fhaide sìos panics.
///         src.set_len(0);
///
///         // Chan urrainn an dà roinn a dhol an lùib a chèile leis nach eil iomraidhean iomraiteach eile, agus chan urrainn an aon chuimhne a bhith aig dà vectors eadar-dhealaichte.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Cuir fios gu `dst` gu bheil e a-nis a `cumail susbaint `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Dèan na sgrùdaidhean sin a-mhàin aig àm ruith
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Gun a bhith a `clisgeadh gus buaidh codegen a chumail nas lugha.
        abort();
    }*/

    // Sàbhailteachd: a 'chùmhnant airson sàbhailteachd `copy_nonoverlapping` dh'fheumas a bhith
    // air a dhearbhadh leis an neach-fios.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Lethbhric `count * size_of::<T>()` bytes bho `src` gu `dst`.Tha an tobar agus an ceann-uidhe a dh'fhaodadh a chèile.
///
/// Ma tha an tobar agus an ceann-uidhe a bhios * * riamh dùblachadh, [`copy_nonoverlapping`] faodar a chleachdadh na àite.
///
/// `copy` 'S e co-ionann ri semantically C [`memmove`], ach leis an argamaid òrdugh a dhol.
/// Bidh copaidh a `tachairt mar gum biodh na bytes air an lethbhreacadh bho `src` gu sreath sealach agus an uairsin air an lethbhreacadh bhon raon gu `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Giùlan undefined ma tha gin de na cumhaichean a leanas a tha air an truailleadh:
///
/// * `src` feumaidh iad a bhith a 'leughadh airson [valid] de `count * size_of::<T>()` bytes.
///
/// * `dst` feumaidh iad a bhith [valid] airson sgrìobhadh `count * size_of::<T>()` bytes.
///
/// * Tha an dà `src` agus `dst` feumar ceart a rèir a chèile.
///
/// Like [`read`], `copy` 'cruthachadh bitwise lethbhreac den `T`, a dh'aindeoin co dhiubh a tha `T` [`Copy`].
/// Ma `T` Chan eil [`Copy`], a 'cleachdadh an dà chuid air na luachan ann an sgìre a' tòiseachadh aig `*src` agus tha an sgìre a 'tòiseachadh aig `* dst` urrainn [violate memory safety][read-ownership].
///
///
/// Cuimhnich gur fiù 's ma tha na h-èifeachdach a lethbhreacadh meud (`cunntadh * size_of: :<T>()`) is `0`, feumaidh na comharran a bhith neo-NULL agus air an co-thaobhadh gu ceart.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Èifeachdach a chruthachadh Rust vector bho sàbhailte bufair:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` feumar a cho-thaobhadh gu ceart airson an seòrsa agus neo-neoni.
/// /// * `ptr` feumaidh iad a bhith dligheach airson leughaidhean de eileamaidean co-shìnte `elts` de sheòrsa `T`.
/// /// * Chan fhaodar na h-eileamaidean sin a chleachdadh às deidh an gnìomh seo a ghairm mura `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // Sàbhailteachd: a 'dèanamh cinnteach againn a precondition an tùs thaobhadh is dligheach,
///     // agus `Vec::with_capacity` a 'dèanamh cinnteach gu bheil sinn ri fhaodainn rùm a sgrìobhadh orra.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SÀBHAILTEACHD: Tha sinn a chruthaich e le mòran comas seo na bu tràithe,
///     // agus tha an `copy` roimhe air na h-eileamaidean sin a thòiseachadh.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Dèan na sgrùdaidhean sin a-mhàin aig àm ruith
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Gun a bhith a `clisgeadh gus buaidh codegen a chumail nas lugha.
        abort();
    }*/

    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `copy` a chumail suas.
    unsafe { copy(src, dst, count) }
}

/// A `suidheachadh bytes cuimhne `count * size_of::<T>()` a` tòiseachadh aig `dst` gu `val`.
///
/// `write_bytes` tha e coltach ri C's [`memset`], ach a `suidheachadh bytes `count * size_of::<T>()` gu `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Giùlan undefined ma tha gin de na cumhaichean a leanas a tha air an truailleadh:
///
/// * `dst` feumaidh iad a bhith [valid] airson sgrìobhadh `count * size_of::<T>()` bytes.
///
/// * `dst` feumar a cho-thaobhadh gu ceart.
///
/// A bharrachd air an sin, feumaidh an neach-fòn dèanamh cinnteach gu bheil luach dligheach de `T` ann an sgrìobhadh `count * size_of::<T>()` bytes chun roinn cuimhne a chaidh a thoirt seachad.
/// A 'cleachdadh sgìre cuimhne clò-sgrìobhte mar `T` anns a bheil mì-dhligheach luach `T` tha undefined giùlan.
///
/// Thoir fa-near, eadhon ged a chaidh am meud a chopaigeadh gu h-èifeachdach (`cunnt * size_of: :<T>()`) A tha `0`, na chomharra feumaidh iad a bhith neo-null gu ceart agus a rèir a chèile.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// A `cruthachadh luach neo-dhligheach:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // A `leigeil às an luach a bh` ann roimhe le bhith a `sgrìobhadh thairis air an `Box<T>` le stiùireadh null.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Aig an ìre seo, bidh cleachdadh no leigeil às `v` a `leantainn gu giùlan neo-mhìnichte.
/// // drop(v); // ERROR
///
/// // Fiù `s ag aoidion `v` "uses" e, agus mar sin giùlan neo-mhìnichte.
/// // mem::forget(v); // ERROR
///
/// // Gu dearbh, tha `v` neo-dhligheach a rèir invariants cruth seòrsa bunaiteach, mar sin tha *gnìomhachd* sam bith a tha a `beantainn ris na ghiùlan neo-mhìnichte.
/////
/// // leig v2 =v;//MEARACHD
///
/// unsafe {
///     // An àite sin cuir sinn a-steach luach dligheach
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // A-nis tha am bogsa gu math
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `write_bytes` a chumail suas.
    unsafe { write_bytes(dst, val, count) }
}