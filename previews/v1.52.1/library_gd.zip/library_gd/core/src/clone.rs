//! An `Clone` trait airson seòrsachan nach gabh a chopaigeadh gu h-obann.
//!
//! Ann an Rust, is e "implicitly copyable" cuid de na seòrsaichean sìmplidh agus nuair a bhios tu gan sònrachadh no gan toirt seachad mar argamaidean, gheibh an cuidhteas leth-bhreac, a `fàgail an luach tùsail na àite.
//! Chan fheum na seòrsachan sin riarachadh gus a chopaigeadh agus chan eil innealan-crìochnachaidh aca (ie, chan eil bogsaichean seilbh annta no [`Drop`] a chuir an gnìomh), agus mar sin tha an t-inneal-cruinneachaidh gam meas saor agus sàbhailte airson a chopaigeadh.
//!
//! Airson seòrsachan eile feumar lethbhric a dhèanamh gu follaiseach, le gnàthachas a `buileachadh an [`Clone`] trait agus a` gairm modh [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Eisimpleir cleachdaidh bunaiteach:
//!
//! ```
//! let s = String::new(); // Seòrsa sreatha a `cur an gnìomh Clone
//! let copy = s.clone(); // gus an urrainn dhuinn a clònadh
//! ```
//!
//! Gus an Clone trait a chuir an gnìomh gu furasta, faodaidh tu `#[derive(Clone)]` a chleachdadh cuideachd.Eisimpleir:
//!
//! ```
//! #[derive(Clone)] // bidh sinn a `cur an Clone trait ri structar Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // agus a-nis is urrainn dhuinn a clònadh!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait cumanta airson comas stuth a dhùblachadh gu follaiseach.
///
/// Tha eadar-dhealachadh bho [`Copy`] leis gu bheil [`Copy`] so-thuigsinn agus gu math saor, fhad `s a tha `Clone` an-còmhnaidh follaiseach agus dh` fhaodadh no dh `fhaodadh e a bhith daor.
/// Gus na feartan sin a chuir an gnìomh, cha leig Rust leat [`Copy`] ath-chleachdadh, ach faodaidh tu `Clone` ath-chleachdadh agus còd rèiteachaidh a ruith.
///
/// Leis gu bheil `Clone` nas coitcheann na [`Copy`], faodaidh tu rud sam bith [`Copy`] a bhith `Clone` gu fèin-ghluasadach cuideachd.
///
/// ## Derivable
///
/// Faodar an trait seo a chleachdadh le `#[derive]` ma tha na raointean uile `Clone`.Tha buileachadh `derive`d de [`Clone`] a` gairm [`clone`] air gach raon.
///
/// [`clone`]: Clone::clone
///
/// Airson structar gnèitheach, bidh `#[derive]` a `buileachadh `Clone` le cumhachan le bhith a` cur `Clone` ceangailte air paramadairean coitcheann.
///
/// ```
/// // `derive` a `cur an gnìomh Clone airson Leughadh<T>nuair a tha T Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Ciamar as urrainn dhomh `Clone` a bhuileachadh?
///
/// Bu chòir na seòrsaichean a tha [`Copy`] a bhith a `buileachadh gu ìre bheag de `Clone`.Nas foirmeile:
/// ma tha `T: Copy`, `x: T`, agus `y: &T`, an uairsin tha `let x = y.clone();` co-ionann ri `let x = *y;`.
/// Bu chòir buileachadh làimhe a bhith faiceallach taic a thoirt don ionnsaigh seo;ge-tà, sàbhailte code Chan fhaod an crochadh air dèanamh cinnteach gu memory sàbhailteachd.
///
/// Is e eisimpleir eisimpleir structar coitcheann a `cumail stiùireadh gnìomh.Anns a`chùis seo, chan urrainnear buileachadh `Clone` a bhith`derive`d, ach faodar a bhuileachadh mar:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Luchd-buileachaidh a bharrachd
///
/// A bharrachd air an [implementors listed below][impls], tha na seòrsachan a leanas cuideachd a `buileachadh `Clone`:
///
/// * Seòrsaichean gnìomh gnìomh (ie, na seòrsachan sònraichte a tha air am mìneachadh airson gach gnìomh)
/// * Seòrsaichean puing gnìomh (me, `fn() -> i32`)
/// * Seòrsaichean eagar, airson gach meud, ma tha an seòrsa rud cuideachd a `buileachadh `Clone` (me, `[i32; 123456]`)
/// * Seòrsaichean teann, ma tha gach co-phàirt cuideachd a `buileachadh `Clone` (me, `()`, `(i32, bool)`)
/// * Seòrsaichean dùnaidh, mura glac iad luach sam bith bhon àrainneachd no ma tha a h-uile luach a chaidh a ghlacadh a `cur `Clone` an gnìomh iad fhèin.
///   Thoir fa-near gum bi caochladairean a thèid an glacadh le iomradh co-roinnte an-còmhnaidh a `buileachadh `Clone` (eadhon mura dèan an tagraiche), fhad` s nach bi caochladairean a thèid an glacadh le iomradh mutable a `cur `Clone` an gnìomh.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// A `tilleadh leth-bhreac den luach.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str a `buileachadh Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// A `dèanamh leth-bhreac de `source`.
    ///
    /// `a.clone_from(&b)` tha e co-ionann ri `a = b.clone()` ann an comas-gnìomh, ach faodar a thoirt thairis gus goireasan `a` ath-chleachdadh gus cuibhreannan neo-riatanach a sheachnadh.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Faigh macro a `gineadh impl den trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): tha na structaran sin air an cleachdadh le#[derive] a-mhàin gus dearbhadh gu bheil a h-uile pàirt de sheòrsa a `cur an gnìomh Clone no Copy.
//
//
// Cha bu chòir na structaran sin a-riamh nochdadh ann an còd neach-cleachdaidh.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Buileachadh `Clone` airson seòrsachan prìomhadail.
///
/// Implementations nach urrainn a bhith air a mhìneachadh ann an Rust a chur an gnìomh ann an `traits::SelectionContext::copy_clone_conditions()` ann `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Faodar iomraidhean co-roinnte a bhith air an clònadh, ach chan urrainn dha iomraidhean mutable *!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Faodar iomraidhean co-roinnte a bhith air an clònadh, ach chan urrainn dha iomraidhean mutable *!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}