#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Tha future a `riochdachadh àireamhachadh asyncronach.
///
/// Is e luach a th `ann an future a dh` fhaodadh nach eil crìoch air coimpiutaireachd fhathast.
/// Tha an seòrsa "asynchronous value" seo ga dhèanamh comasach dha snàithlean cumail orra a `dèanamh obair fheumail fhad` s a tha e a `feitheamh ris an luach a bhith ri fhaighinn.
///
///
/// # An dòigh `poll`
///
/// Tha prìomh dhòigh future, `poll`,*a `feuchainn* gus an future fhuasgladh gu luach deireannach.
/// Cha bhith an dòigh seo a `bacadh mura h-eil an luach deiseil.
/// An àite sin, tha dùil gum bi an obair làithreach air a dùsgadh nuair a tha e comasach tuilleadh adhartais a dhèanamh le bhith a `bhòtadh a-rithist.
/// Faodaidh an `context` a chaidh a thoirt seachad don dòigh `poll` [`Waker`] a thoirt seachad, a tha na làimhseachadh airson a bhith a `dùsgadh a` ghnìomh làithreach.
///
/// Nuair a bhios tu a `cleachdadh future, mar as trice cha bhith thu a` gairm `poll` gu dìreach, ach an àite sin `.await` an luach.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// An seòrsa luach a thèid a thoirt gu buil nuair a bhios e deiseil.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Feuch ri fuasgladh fhaighinn air an future gu deireannach luach, a 'clàradh an-dràsta airson obair wakeup ma luach Chan eil e fhathast ri fhaotainn.
    ///
    /// # Luach tillidh
    ///
    /// Bidh an gnìomh seo a `tilleadh:
    ///
    /// - [`Poll::Pending`] mura h-eil an future deiseil fhathast
    /// - [`Poll::Ready(val)`] leis an toradh `val` den future seo ma chrìochnaich e gu soirbheachail.
    ///
    /// Aon uair `s gu bheil future deiseil, cha bu chòir do luchd-dèiligidh `poll` a dhèanamh a-rithist.
    ///
    /// Nuair nach eil future deiseil fhathast, bidh `poll` a `tilleadh `Poll::Pending` agus a` stòradh clone den [`Waker`] a chaidh a chopaigeadh bhon [`Context`] gnàthach.
    /// Tha an [`Waker`] seo an uairsin air a dhùsgadh aon uair `s gun urrainn don future adhartas a dhèanamh.
    /// Mar eisimpleir, bhiodh future a `feitheamh ri socaid a bhith furasta a leughadh a` gairm `.clone()` air an [`Waker`] agus ga stòradh.
    /// Nuair a thig comharra gu àite eile a `sealltainn gu bheil an socaid ri leughadh, canar [`Waker::wake`] ris agus tha gnìomh an t-socaid future air a dhùsgadh.
    /// Aon uair `s gu bheil gnìomh air a dhùsgadh, bu chòir dha feuchainn ri `poll` an future a-rithist, a dh` fhaodadh no nach toir luach deireannach a-mach.
    ///
    /// Thoir fa-near, air grunn ghairmean gu `poll`, nach bu chòir ach an [`Waker`] bhon [`Context`] a chaidh a thoirt don ghairm as ùire a bhith air a chlàradh gus dùsgadh fhaighinn.
    ///
    /// # Feartan Runtime
    ///
    /// Tha Futures leotha fhèin *inert*;feumaidh iad a bhith *gu gnìomhach*`poll`ed gus adhartas a dhèanamh, a`ciallachadh gum bu chòir dha a h-uile uair a dhùisgeas a`ghnìomh làithreach ath-`poll` a` feitheamh ri futures anns a bheil ùidh aice fhathast.
    ///
    /// Chan eilear a `gairm gnìomh `poll` a-rithist ann an lùb teann-an àite sin, cha bu chòir a bhith air a ghairm ach nuair a tha an future a` nochdadh gu bheil e deiseil airson adhartas a dhèanamh (le bhith a `gairm `wake()`).
    /// Ma tha thu eòlach air na siostaman `poll(2)` no `select(2)` air Unix is fhiach a bhith mothachail nach bi futures mar as trice a `fulang * na h-aon dhuilgheadasan de "all wakeups must poll all events";tha iad tuilleadh mar `epoll(4)`.
    ///
    /// Bu chòir do bhuileachadh `poll` feuchainn ri tilleadh gu sgiobalta, agus cha bu chòir dha bacadh a chuir air.Bidh tilleadh gu sgiobalta a `cur casg air snàithleanan no lùban tachartais gun fheum.
    /// Ma tha fios ro-làimh gum faodadh gairm gu `poll` a thighinn gu crìch, bu chòir an obair a luchdachadh sìos gu amar snàithlean (no rudeigin coltach ris) gus dèanamh cinnteach gun urrainn dha `poll` tilleadh gu sgiobalta.
    ///
    /// # Panics
    ///
    /// Aon uair 'future air a chrìochnachadh (Thill `Ready` bho `poll`), a' gairm a `poll` dòigh a-rithist faodaidh panic, a bhacadh gu bràth, no adhbhar eile seòrsa duilgheadasan;chan eil an `Future` trait a `cur riatanasan sam bith a thaobh buaidh gairm mar sin.
    /// Ach, mar a `poll` an dòigh nach eil a 'comharrachadh `unsafe`, Rust riaghailtean àbhaisteach a' buntainn: gairmean Feumaidh riamh adhbharachadh undefined giùlan (memory coirbeachd, mearachdach cleachdadh `unsafe` dleastanasan, no a leithid), a dh'aindeoin an future stàite.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}