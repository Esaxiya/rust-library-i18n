use crate::future::Future;

/// Tionndadh a-steach do `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// An toradh a bheir an future gu buil nuair a bhios e deiseil.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Dè an seòrsa future anns a bheil sinn a `tionndadh seo?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// A `cruthachadh future bho luach.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}