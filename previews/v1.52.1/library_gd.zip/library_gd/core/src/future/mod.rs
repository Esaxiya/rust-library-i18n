#![stable(feature = "futures_api", since = "1.36.0")]

//! Asynchronous luachan.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Tha feum air an seòrsa seo air sgàth:
///
/// a) Chan urrainn do ghineadairean `for<'a, 'b> Generator<&'a mut Context<'b>>` a chuir an gnìomh, agus mar sin feumaidh sinn a dhol seachad air comharra amh (faic <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Chan e molaidhean amh agus `NonNull` `Send` no `Sync`, mar sin dhèanadh sin a h-uile future non-Send/Sync cuideachd, agus chan eil sinn ag iarraidh sin.
///
/// Bidh e cuideachd a `sìmpleachadh lughdachadh HIR de `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Paisg gineadair ann an future.
///
/// Bidh an gnìomh seo a `tilleadh `GenFuture` gu h-ìosal, ach ga fhalach ann an `impl Trait` gus teachdaireachdan mearachd nas fheàrr a thoirt seachad (`impl Future` seach `GenFuture<[closure.....]>`).
///
// Is e seo `const` gus mearachdan a bharrachd a sheachnadh às deidh dhuinn faighinn air ais bho `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Tha sinn an urra ris gu bheil async/await futures do-sheachanta gus iasadan fèin-iomraidh a chruthachadh anns a `ghineadair a tha mar bhunait.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SÀBHAILTEACHD: Sàbhailte oir tha sinn !Unpin + !Drop, agus chan eil an seo ach ro-mheasadh achaidh.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Ath-thòisich an gineadair, a `tionndadh an `&mut Context` gu bhith na chomharradh amh `NonNull`.
            // Bidh an ìsleachadh `.await` a `tilgeil sin air ais gu `&mut Context` gu sàbhailte.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gu bheil `cx.0` na chomharraiche dligheach
    // a choileanas na riatanasan gu lèir airson iomradh gluasadach.
    unsafe { &mut *cx.0.as_ptr().cast() }
}