//! Atomic seòrsa
//!
//! Atomic seòrsachan prìomhadail a thoirt seachad co-roinnte-cuimhne conaltradh eadar ceangal a-nall, agus tha an togalach blocaichean eile co-cheumnaichte seòrsa.
//!
//! Tha am modal seo a `mìneachadh dreachan atamach de àireamh taghte de sheòrsaichean prìomhadail, nam measg [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], msaa.
//! Bidh seòrsaichean atamach a `taisbeanadh obrachaidhean a bhios, nuair a thèid an cleachdadh gu ceart, a` sioncronadh ùrachaidhean eadar snàithleanan.
//!
//! Tha gach dòigh 'gabhail [`Ordering`] tha a' riochdachadh an neart an cuimhne na chnap-starra airson sin obrachadh.Tha na h-òrdughan sin an aon rud ris an [C++20 atomic orderings][1].Airson tuilleadh fiosrachaidh faic [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Tha caochladairean atamach sàbhailte a roinn eadar snàithleanan (bidh iad a `cur an gnìomh [`Sync`]) ach chan eil iad fhèin a` toirt seachad an dòigh airson a bhith a `roinneadh agus a` leantainn an [threading model](../../../std/thread/index.html#the-threading-model) de Rust.
//!
//! Is e an dòigh as cumanta air caochladair atamach a cho-roinn a chuir ann an [`Arc`][arc] (comharradh co-roinnte le cunntas atamach).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Faodar seòrsaichean atamach a stòradh ann an caochladairean statach, air an tòiseachadh le bhith a `cleachdadh na innealan tòiseachaidh seasmhach mar [`AtomicBool::new`].Bidh ìomhaighean atamach gu tric air an cleachdadh airson tòiseachadh cruinneil leisg.
//!
//! # Portability
//!
//! Bithear a `gealltainn gum bi a h-uile seòrsa atamach sa mhodal seo [lock-free] ma tha iad rim faighinn.Tha seo a`ciallachadh nach bi iad a`faighinn taobh a-staigh mutex cruinneil.Chan eilear a`gealltainn gum bi seòrsaichean agus obrachaidhean atamach saor bho feitheamh.
//! Tha seo a `ciallachadh gum faodar gnìomhachd mar `fetch_or` a chuir an gnìomh le lùb coimeas-agus-suaip.
//!
//! Atomic obrachaidhean a dh'fhaodadh a bhith air an cur an gnìomh aig a 'stiùireadh le còmhdach nas motha-mheud atomics.Mar eisimpleir, cuid de àrd-chabhsairean a 'cleachdadh 4-Byte atamach stiùireadh a chur an gnìomh `AtomicI8`.
//! Thoir fa-near nach bu chòir don aithris seo buaidh a thoirt air ceartachd còd, is e dìreach rudeigin a bhith mothachail.
//!
//! Tha atamach seòrsa seo modal dòcha nach bi e ri fhaotainn air a h-uile àrd-chabhsairean.Tha atamach seòrsa seo uile rim faotainn gu farsaing, ge-tà, agus'surrainn fharsaingeachd bhith an urra riutha mar-thà.Nithean ainmeil ach a-mhàin a tha:
//!
//! * PowerPC agus chan eil seòrsaichean `AtomicU64` no `AtomicI64` aig àrd-ùrlaran MIPS le comharran 32-bit.
//! * ARM chan eil àrd-ùrlaran mar `armv5te` nach eil airson Linux a `toirt ach obrachaidhean `load` agus `store`, agus chan eil iad a` toirt taic do ghnìomhachd Compare agus Swap (CAS), leithid `swap`, `fetch_add`, msaa.
//! A bharrachd air Linux, tha na h-obraichean CAS seo air an cur an gnìomh tro [operating system support], a dh `fhaodadh tighinn le peanas coileanaidh.
//! * ARM le targaidean `thumbv6m` a-mhàin a thoirt seachad `load` agus `store` obair, agus chan eil na coimeasan agus taic a thoirt do Inns (CAS) obraichean, leithid `swap`, `fetch_add`, etc.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Thoir fa-near gum faodar àrd-ùrlaran future a chur ris nach eil taic ann cuideachd airson cuid de dh `obraichean atamach.Bidh còd so-ghiùlain as motha ag iarraidh a bhith faiceallach dè na seòrsaichean atamach a thathas a`cleachdadh.
//! `AtomicUsize` agus `AtomicIsize` mar as trice an fheadhainn as so-ghiùlain, ach eadhon an uairsin chan eil iad rim faighinn anns a h-uile àite.
//! Airson fiosrachadh, tha leabharlann `std` a `feumachdainn atomics meud puing, ged nach eil `core`.
//!
//! An-dràsta feumaidh tu `#[cfg(target_arch)]` a chleachdadh sa chiad àite gus còd a chuir ri chèile le atomics.Tha neo-sheasmhach `#[cfg(target_has_atomic)]` a bharrachd a dh'fhaodadh a bhith air a dhèanamh sàbhailte ann an future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! A spinlock sìmplidh:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Fuirich airson an t-snàthainn eile gus a `ghlas a leigeil ma sgaoil
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Cùm cunntas cruinneil de snàithleanan beò:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Seòrsa boolean a ghabhas a roinn gu sàbhailte eadar snàithleanan.
///
/// Tha an seòrsa a tha na h-aon-cuimhne ann an riochdachadh mar [`bool`].
///
/// **Nòta**: Chan fhaighear an seòrsa seo ach air àrd-ùrlaran a bheir taic do luchdan atamach agus stòran `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// A `cruthachadh `AtomicBool` a chaidh a thòiseachadh gu `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Tha Send air a bhuileachadh gu h-obann airson AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Seòrsa puing amh a ghabhas a roinn gu sàbhailte eadar snàithleanan.
///
/// Tha an aon riochdachadh in-cuimhne aig an seòrsa seo ri `*mut T`.
///
/// **Nòta**: Chan fhaighear an seòrsa seo ach air àrd-ùrlaran a bheir taic do luchdan atamach agus stòran de chomharran.
/// Tha a mheud an urra ri meud a `phuing targaid.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// A `cruthachadh null `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Atomic memory orderings
///
/// Bidh òrdughan cuimhne a `sònrachadh an dòigh anns a bheil gnìomhachd atamach a` sioncronadh cuimhne.
/// Anns an [`Ordering::Relaxed`] as laige aige, chan eil ach an cuimhne air a bheil an obair a `bualadh gu dìreach air a shioncronachadh.
/// Air an làimh eile, bidh paidhir stòr-obrach de [`Ordering::SeqCst`] a `sioncronadh cuimhne eile fhad` s a tha iad a `gleidheadh òrdugh iomlan de dh` obraichean mar sin thar gach snàithlean.
///
///
/// Is e òrdughan cuimhne Rust [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Airson tuilleadh fiosrachaidh faic an [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Gun chuingealachaidhean òrdachaidh, dìreach obrachaidhean atamach.
    ///
    /// A `freagairt ri [`memory_order_relaxed`] ann an C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Nuair a thèid an cur còmhla ri stòr, thèid a h-uile gnìomhachd a bh `ann roimhe òrdachadh mus tèid luchdan sam bith den luach seo le òrdugh [`Acquire`] (no nas làidire).
    ///
    /// Gu sònraichte, bidh a h-uile sgrìobhadh roimhe seo ri fhaicinn leis na snàithleanan uile a bhios a `coileanadh luchd [`Acquire`] (no nas làidire) den luach seo.
    ///
    /// Sanas a 'cleachdadh seo airson rian a chur an obrachadh a cothlamadh de luchdan is bùithean a' dol gu [`Relaxed`] luchd obrachadh!
    ///
    /// Chan eil an òrdachadh seo buntainneach ach airson obrachaidhean as urrainn stòr a dhèanamh.
    ///
    /// A `freagairt ri [`memory_order_release`] ann an C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Nuair còmhla ri eallach, ma tha an luach a luchdachadh a sgrìobhadh le stòr obrachadh le [`Release`] (no nas làidire) ag òrdachadh, an uair sin a h-uile obraichean an dèidh sin a bhith air an òrdachadh an dèidh a 'bhùth.
    /// Gu sònraichte, chì a h-uile luchd a thig às deidh sin dàta a chaidh a sgrìobhadh ron stòr.
    ///
    /// Sanas a 'cleachdadh seo airson rian a chur an obrachadh a cothlamadh de luchdan is bùithean a' dol gu [`Relaxed`] stòr obrachadh!
    ///
    /// Chan eil an òrdachadh seo buntainneach ach airson obrachaidhean as urrainn luchdan a choileanadh.
    ///
    /// A `freagairt ri [`memory_order_acquire`] ann an C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Tha a 'bhuaidh an dà chuid [`Acquire`] agus [`Release`] còmhla:
    /// Airson luchdan bidh e a `cleachdadh òrdachadh [`Acquire`].Airson stòran bidh e a`cleachdadh òrdachadh [`Release`].
    ///
    /// Thoir fa-near, a thaobh `compare_and_swap`, gu bheil e comasach gu bheil an obrachadh a `tighinn gu crìch gun a bhith a` coileanadh stòr sam bith agus mar sin tha dìreach òrdugh [`Acquire`] aige.
    ///
    /// Ach, cha dèan `AcqRel` ruigsinneachd [`Relaxed`] a-riamh.
    ///
    /// Chan eil an òrdachadh seo buntainneach ach airson obraichean a tha a `cothlamadh an dà chuid luchdan agus stòran.
    ///
    /// Co-ionann ris [`memory_order_acq_rel`] ann C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Coltach ri [`Acquire`]/[`Release`]/[`AcqRel`](airson obair luchdan, stòr, agus load-with-store, fa leth) leis a` ghealladh a bharrachd gum faic na snàithleanan a h-uile gnìomhachd cunbhalach a rèir òrdugh san aon òrdugh .
    ///
    ///
    /// Co-ionann ris [`memory_order_seq_cst`] ann C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// Thòisich an [`AtomicBool`] gu `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// A `cruthachadh `AtomicBool` ùr.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// A `tilleadh iomradh gluasadach air an [`bool`] bunaiteach.
    ///
    /// Tha seo sàbhailte oir tha an iomradh gluasadach a `gealltainn nach eil snàithleanan eile a` faighinn cothrom air an dàta atamach aig an aon àm.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SÀBHAILTEACHD: tha an iomradh gluasadach a `gealltainn seilbh gun samhail.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Faigh ruigsinneachd atamach air `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SÀBHAILTEACHD: tha an iomradh mutable a `gealltainn seilbh gun samhail, agus
        // tha co-thaobhadh an dà chuid `bool` agus `Self` aig 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// A `caitheamh an atamach agus a` tilleadh an luach a tha na bhroinn.
    ///
    /// Tha seo sàbhailte oir tha a bhith a `dol seachad air `self` a rèir luach a` gealltainn nach eil snàithleanan eile a `faighinn cothrom air an dàta atamach aig an aon àm.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// A `luchdachadh luach bhon bool.
    ///
    /// `load` a `gabhail argamaid [`Ordering`] a tha a` toirt cunntas air òrdugh cuimhne na h-obrach seo.
    /// Is e luachan comasach [`SeqCst`], [`Acquire`] agus [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ma tha `order` [`Release`] no [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // Sàbhailteachd: dàta sam bith a tha rèisean a 'cur stad le atamach intrinsics agus an amh
        // tha an comharradh a chaidh a thoirt a-steach dligheach oir fhuair sinn e bho iomradh.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// A `stòradh luach a-steach don bool.
    ///
    /// `store` a `gabhail argamaid [`Ordering`] a tha a` toirt cunntas air òrdugh cuimhne na h-obrach seo.
    /// Is e luachan comasach [`SeqCst`], [`Release`] agus [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ma tha `order` [`Acquire`] no [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // Sàbhailteachd: dàta sam bith a tha rèisean a 'cur stad le atamach intrinsics agus an amh
        // tha an comharradh a chaidh a thoirt a-steach dligheach oir fhuair sinn e bho iomradh.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// A `stòradh luach a-steach don bool, a` tilleadh an luach a bh `ann roimhe.
    ///
    /// `swap` a 'gabhail an [`Ordering`] argamaid a tha a' toirt iomradh air an memory rian-obrach seo.Tha a h-uile modh òrdachaidh comasach.
    /// Thoir fa-near gu bheil a bhith a `cleachdadh [`Acquire`] a` dèanamh a `bhùth mar phàirt den obair seo [`Relaxed`], agus a` cleachdadh [`Release`] a `dèanamh a` phàirt luchdan [`Relaxed`].
    ///
    ///
    /// **Note:** Chan eil an dòigh seo ri fhaighinn ach air àrd-ùrlaran a bheir taic do ghnìomhachd atamach air `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// A `stòradh luach a-steach don [`bool`] ma tha an luach làithreach co-ionann ri luach `current`.
    ///
    /// Is e an luach toraidh an-còmhnaidh an luach a bh `ann roimhe.Ma tha e co-ionann ris `current`, an sin air an luach a chaidh ùrachadh.
    ///
    /// `compare_and_swap` cuideachd a `gabhail argamaid [`Ordering`] a tha a` toirt cunntas air òrdachadh cuimhne na h-obrach seo.
    /// Thoir fa-near, eadhon nuair a bhios tu a `cleachdadh [`AcqRel`], gum faodadh an obrachadh fàiligeadh agus mar sin dìreach a` coileanadh luchd `Acquire`, ach nach eil semantics `Release` agad.
    /// Le bhith a `cleachdadh [`Acquire`] bidh an stòr mar phàirt den obair seo [`Relaxed`] ma thachras e, agus le bhith a` cleachdadh [`Release`] bidh e a `dèanamh a` phàirt luchdaidh [`Relaxed`].
    ///
    /// **Note:** Chan eil an dòigh seo ri fhaighinn ach air àrd-ùrlaran a bheir taic do ghnìomhachd atamach air `u8`.
    ///
    /// # A `dèanamh imrich gu `compare_exchange` agus `compare_exchange_weak`
    ///
    /// `compare_and_swap` 'S e co-ionann ri `compare_exchange` le na leanas airson memory mapadh orderings:
    ///
    /// Tùsail |Soirbheachas |Fàilligeadh
    /// -------- | ------- | -------
    /// Relaxed |Relaxed |Togail fois |Faighinn |A thogail Release |Saoradh |Relaxed AcqRel |AcqRel |Faighinn SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` tha e ceadaichte fàiligeadh gu spùtach eadhon nuair a shoirbhicheas leis a `choimeas, a leigeas leis an trusaiche còd cruinneachaidh nas fheàrr a ghineadh nuair a thèid an coimeas agus an suaip a chleachdadh ann an lùb.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// A `stòradh luach a-steach don [`bool`] ma tha an luach làithreach co-ionann ri luach `current`.
    ///
    /// Tha an luach toraidh mar thoradh a `sealltainn an deach an luach ùr a sgrìobhadh agus anns a bheil an luach roimhe.
    /// Ma shoirbhicheas leis tha an luach seo cinnteach gum bi e co-ionann ri `current`.
    ///
    /// `compare_exchange` a 'gabhail dà [`Ordering`] argamaidean airson cunntas a thoirt an cuimhne rian-obrach seo.
    /// `success` a `toirt cunntas air an òrdachadh a tha a dhìth airson an obair leughaidh-atharrachaidh-sgrìobhaidh a tha a` tachairt ma shoirbhicheas leis a `choimeas le `current`.
    /// `failure` a `toirt cunntas air an òrdachadh a dh` fheumar airson obrachadh luchdan a bhios a `tachairt nuair a dh` fhailicheas an coimeas.
    /// Le bhith a `cleachdadh [`Acquire`] mar òrdachadh soirbheachais tha an stòr mar phàirt den obair seo [`Relaxed`], agus le bhith a` cleachdadh [`Release`] bidh an luchd soirbheachail [`Relaxed`].
    ///
    /// Faodaidh an òrdugh fàilligeadh a bhith dìreach [`SeqCst`], [`Acquire`] no [`Relaxed`] agus feumaidh e a bhith co-ionann no nas laige na an t-òrdugh soirbheachaidh.
    ///
    /// **Note:** Chan eil an dòigh seo ri fhaighinn ach air àrd-ùrlaran a bheir taic do ghnìomhachd atamach air `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// A `stòradh luach a-steach don [`bool`] ma tha an luach làithreach co-ionann ri luach `current`.
    ///
    /// Eu-coltach ri [`AtomicBool::compare_exchange`], tha cead aig a `ghnìomh seo fàiligeadh gu spùtach eadhon nuair a shoirbhicheas leis a` choimeas, a dh `fhaodadh còd nas èifeachdaiche a thoirt air cuid de àrd-ùrlaran.
    ///
    /// Tha an luach toraidh mar thoradh a `sealltainn an deach an luach ùr a sgrìobhadh agus anns a bheil an luach roimhe.
    ///
    /// `compare_exchange_weak` a 'gabhail dà [`Ordering`] argamaidean airson cunntas a thoirt an cuimhne rian-obrach seo.
    /// `success` a `toirt cunntas air an òrdachadh a tha a dhìth airson an obair leughaidh-atharrachaidh-sgrìobhaidh a tha a` tachairt ma shoirbhicheas leis a `choimeas le `current`.
    /// `failure` a `toirt cunntas air an òrdachadh a dh` fheumar airson obrachadh luchdan a bhios a `tachairt nuair a dh` fhailicheas an coimeas.
    /// Le bhith a `cleachdadh [`Acquire`] mar òrdachadh soirbheachais tha an stòr mar phàirt den obair seo [`Relaxed`], agus le bhith a` cleachdadh [`Release`] bidh an luchd soirbheachail [`Relaxed`].
    /// Faodaidh an òrdugh fàilligeadh a bhith dìreach [`SeqCst`], [`Acquire`] no [`Relaxed`] agus feumaidh e a bhith co-ionann no nas laige na an t-òrdugh soirbheachaidh.
    ///
    /// **Note:** Chan eil an dòigh seo ri fhaighinn ach air àrd-ùrlaran a bheir taic do ghnìomhachd atamach air `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Loidsigeach "and" le luach boole.
    ///
    /// A `dèanamh gnìomhachd loidsigeach "and" air an luach làithreach agus an argamaid `val`, agus a` suidheachadh an luach ùr ris an toradh.
    ///
    /// A `tilleadh an luach a bh` ann roimhe.
    ///
    /// `fetch_and` a 'gabhail an [`Ordering`] argamaid a tha a' toirt iomradh air an memory rian-obrach seo.Tha a h-uile modh òrdachaidh comasach.
    /// Thoir fa-near gu bheil a bhith a `cleachdadh [`Acquire`] a` dèanamh a `bhùth mar phàirt den obair seo [`Relaxed`], agus a` cleachdadh [`Release`] a `dèanamh a` phàirt luchdan [`Relaxed`].
    ///
    ///
    /// **Note:** Chan eil an dòigh seo ri fhaighinn ach air àrd-ùrlaran a bheir taic do ghnìomhachd atamach air `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Loidsigeach "nand" le luach boole.
    ///
    /// A `dèanamh gnìomhachd loidsigeach "nand" air an luach làithreach agus an argamaid `val`, agus a` suidheachadh an luach ùr ris an toradh.
    ///
    /// A `tilleadh an luach a bh` ann roimhe.
    ///
    /// `fetch_nand` a 'gabhail an [`Ordering`] argamaid a tha a' toirt iomradh air an memory rian-obrach seo.Tha a h-uile modh òrdachaidh comasach.
    /// Thoir fa-near gu bheil a bhith a `cleachdadh [`Acquire`] a` dèanamh a `bhùth mar phàirt den obair seo [`Relaxed`], agus a` cleachdadh [`Release`] a `dèanamh a` phàirt luchdan [`Relaxed`].
    ///
    ///
    /// **Note:** Chan eil an dòigh seo ri fhaighinn ach air àrd-ùrlaran a bheir taic do ghnìomhachd atamach air `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Chan urrainn dhuinn a 'cleachdadh atomic_nand an seo oir tha e a dh'fhaodadh e bool le luach mì-dhligheach.
        // Tha seo a 'tachairt oir tha an atamach obrachadh a dhèanamh le 8-bit integer a-staigh, a bhiodh a' cur na h-àrd 7 pìosan.
        //
        // Mar sin bidh sinn dìreach a `cleachdadh fetch_xor no suaip an àite sin.
        if val {
            // ! (X&fìor)== !x Feumaidh sinn invert an bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&meallta)==fìor Feumaidh sinn an bool a shuidheachadh gu fìor.
            //
            self.swap(true, order)
        }
    }

    /// Loidsigeach "or" le luach boole.
    ///
    /// A `dèanamh gnìomhachd loidsigeach "or" air an luach làithreach agus an argamaid `val`, agus a` suidheachadh an luach ùr ris an toradh.
    ///
    /// A `tilleadh an luach a bh` ann roimhe.
    ///
    /// `fetch_or` a 'gabhail an [`Ordering`] argamaid a tha a' toirt iomradh air an memory rian-obrach seo.Tha a h-uile modh òrdachaidh comasach.
    /// Thoir fa-near gu bheil a bhith a `cleachdadh [`Acquire`] a` dèanamh a `bhùth mar phàirt den obair seo [`Relaxed`], agus a` cleachdadh [`Release`] a `dèanamh a` phàirt luchdan [`Relaxed`].
    ///
    ///
    /// **Note:** Chan eil an dòigh seo ri fhaighinn ach air àrd-ùrlaran a bheir taic do ghnìomhachd atamach air `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Loidsigeach "xor" le boolean a luach.
    ///
    /// A `dèanamh gnìomhachd loidsigeach "xor" air an luach làithreach agus an argamaid `val`, agus a` suidheachadh an luach ùr ris an toradh.
    ///
    /// A `tilleadh an luach a bh` ann roimhe.
    ///
    /// `fetch_xor` a 'gabhail an [`Ordering`] argamaid a tha a' toirt iomradh air an memory rian-obrach seo.Tha a h-uile modh òrdachaidh comasach.
    /// Thoir fa-near gu bheil a bhith a `cleachdadh [`Acquire`] a` dèanamh a `bhùth mar phàirt den obair seo [`Relaxed`], agus a` cleachdadh [`Release`] a `dèanamh a` phàirt luchdan [`Relaxed`].
    ///
    ///
    /// **Note:** Chan eil an dòigh seo ri fhaighinn ach air àrd-ùrlaran a bheir taic do ghnìomhachd atamach air `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// A `tilleadh stiùireadh gluasadach chun [`bool`] bunaiteach.
    ///
    /// Faodaidh a bhith a `dèanamh leughaidhean neo-atamach agus a` sgrìobhadh air an integer a thig às a bhith na rèis dàta.
    /// Tha an dòigh seo feumail sa mhòr-chuid airson FFI, far am faod ainm-sgrìobhte an gnìomh `*mut bool` a chleachdadh an àite `&AtomicBool`.
    ///
    /// Tha tilleadh puing `*mut` bho iomradh co-roinnte air an atamach seo sàbhailte oir tha na seòrsaichean atamach ag obair le mutability taobh a-staigh.
    /// A h-uile mion-atharrachaidhean de atamach atharrachadh luach tro cho-roinnte iomradh, agus'surrainn sin a dhèanamh gu sàbhailte cho fad' sa tha iad a 'cleachdadh atamach obraichean.
    /// Sam bith air cleachdadh na thill amh chomharra Feumaidh an `unsafe` bacaidh agus fhathast gus an seas aon bacadh: obraichean air feumaidh e bhith atamach.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Fetches a 'cur luach air, agus a' buntainn ri obair a tha e a 'tilleadh roghainneil ùr luach.A 'tilleadh a `Result` de `Ok(previous_value)` ma' ghnìomh a thill `Some(_)`, `Err(previous_value)` eile.
    ///
    /// Note: Dh'fhaodadh seo a ghairm a 'ghnìomh ioma ma amannan air an luach a tha air a bhith air atharrachadh bho innealan eile san eadar-ama, cho fad' a 'ghnìomh a thilleas `Some(_)`, ach Thèid an dreuchd a chur an sàs a-mhàin aon uair do stòradh luach.
    ///
    ///
    /// `fetch_update` a 'gabhail dà [`Ordering`] argamaidean airson cunntas a thoirt an cuimhne rian-obrach seo.
    /// Tha a `chiad fhear a` toirt cunntas air an òrdachadh a tha riatanach airson cuin a bhios an obair a `soirbheachadh mu dheireadh fhad` s a tha an dàrna fear a `toirt cunntas air an òrdachadh a tha a dhìth airson luchdan.
    /// Tha iad sin a 'conaltradh ris a' soirbheachadh agus a 'fàilligeadh orderings de [`AtomicBool::compare_exchange`] fa leth.
    ///
    /// Cleachdadh [`Acquire`] mar soirbheachadh ag òrdachadh a 'dèanamh an stòr phàirt de seo obrachadh [`Relaxed`], agus a' cleachdadh [`Release`] a 'dèanamh a' chuairt dheireannach soirbheachail luchd [`Relaxed`].
    /// Chan urrainn don òrdachadh luchdan (failed) a bhith ach [`SeqCst`], [`Acquire`] no [`Relaxed`] agus feumaidh e a bhith co-ionann no nas laige na òrdachadh soirbheachaidh.
    ///
    /// **Note:** Chan eil an dòigh seo ri fhaighinn ach air àrd-ùrlaran a bheir taic do ghnìomhachd atamach air `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// A `cruthachadh `AtomicPtr` ùr.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// A 'tilleadh a mutable iomradh air a' bhun-chomharra.
    ///
    /// Tha seo sàbhailte oir tha an iomradh gluasadach a `gealltainn nach eil snàithleanan eile a` faighinn cothrom air an dàta atamach aig an aon àm.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Faigh ruigsinneachd atamach gu stiùireadh.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - tha an iomradh mutable a `gealltainn seilbh gun samhail.
        //  - a 'co-thaobhadh `*mut T` `Self` agus tha an aon àrd-chabhsairean air a h-uile taic bho rust, mar a dhearbhadh gu h-àrd.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// A `caitheamh an atamach agus a` tilleadh an luach a tha na bhroinn.
    ///
    /// Tha seo sàbhailte oir tha a bhith a `dol seachad air `self` a rèir luach a` gealltainn nach eil snàithleanan eile a `faighinn cothrom air an dàta atamach aig an aon àm.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// A `luchdachadh luach bhon phuing.
    ///
    /// `load` a `gabhail argamaid [`Ordering`] a tha a` toirt cunntas air òrdugh cuimhne na h-obrach seo.
    /// Is e luachan comasach [`SeqCst`], [`Acquire`] agus [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ma tha `order` [`Release`] no [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// A `stòradh luach a-steach don phuing.
    ///
    /// `store` a `gabhail argamaid [`Ordering`] a tha a` toirt cunntas air òrdugh cuimhne na h-obrach seo.
    /// Is e luachan comasach [`SeqCst`], [`Release`] agus [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ma tha `order` [`Acquire`] no [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// A `stòradh luach a-steach don phuing, a` tilleadh an luach a bh `ann roimhe.
    ///
    /// `swap` a 'gabhail an [`Ordering`] argamaid a tha a' toirt iomradh air an memory rian-obrach seo.Tha a h-uile modh òrdachaidh comasach.
    /// Thoir fa-near gu bheil a bhith a `cleachdadh [`Acquire`] a` dèanamh a `bhùth mar phàirt den obair seo [`Relaxed`], agus a` cleachdadh [`Release`] a `dèanamh a` phàirt luchdan [`Relaxed`].
    ///
    ///
    /// **Note:** Chan eil an dòigh seo ri fhaighinn ach air àrd-ùrlaran a bheir taic do ghnìomhachd atamach air molaidhean.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// A `stòradh luach a-steach don phuing ma tha an luach làithreach co-ionann ri luach `current`.
    ///
    /// Is e an luach toraidh an-còmhnaidh an luach a bh `ann roimhe.Ma tha e co-ionann ris `current`, an sin air an luach a chaidh ùrachadh.
    ///
    /// `compare_and_swap` cuideachd a `gabhail argamaid [`Ordering`] a tha a` toirt cunntas air òrdachadh cuimhne na h-obrach seo.
    /// Thoir fa-near, eadhon nuair a bhios tu a `cleachdadh [`AcqRel`], gum faodadh an obrachadh fàiligeadh agus mar sin dìreach a` coileanadh luchd `Acquire`, ach nach eil semantics `Release` agad.
    /// Le bhith a `cleachdadh [`Acquire`] bidh an stòr mar phàirt den obair seo [`Relaxed`] ma thachras e, agus le bhith a` cleachdadh [`Release`] bidh e a `dèanamh a` phàirt luchdaidh [`Relaxed`].
    ///
    /// **Note:** Chan eil an dòigh seo ri fhaighinn ach air àrd-ùrlaran a bheir taic do ghnìomhachd atamach air molaidhean.
    ///
    /// # A `dèanamh imrich gu `compare_exchange` agus `compare_exchange_weak`
    ///
    /// `compare_and_swap` 'S e co-ionann ri `compare_exchange` le na leanas airson memory mapadh orderings:
    ///
    /// Tùsail |Soirbheachas |Fàilligeadh
    /// -------- | ------- | -------
    /// Relaxed |Relaxed |Togail fois |Faighinn |A thogail Release |Saoradh |Relaxed AcqRel |AcqRel |Faighinn SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` tha e ceadaichte fàiligeadh gu spùtach eadhon nuair a shoirbhicheas leis a `choimeas, a leigeas leis an trusaiche còd cruinneachaidh nas fheàrr a ghineadh nuair a thèid an coimeas agus an suaip a chleachdadh ann an lùb.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// A `stòradh luach a-steach don phuing ma tha an luach làithreach co-ionann ri luach `current`.
    ///
    /// Tha an luach toraidh mar thoradh a `sealltainn an deach an luach ùr a sgrìobhadh agus anns a bheil an luach roimhe.
    /// Ma shoirbhicheas leis tha an luach seo cinnteach gum bi e co-ionann ri `current`.
    ///
    /// `compare_exchange` a 'gabhail dà [`Ordering`] argamaidean airson cunntas a thoirt an cuimhne rian-obrach seo.
    /// `success` a `toirt cunntas air an òrdachadh a tha a dhìth airson an obair leughaidh-atharrachaidh-sgrìobhaidh a tha a` tachairt ma shoirbhicheas leis a `choimeas le `current`.
    /// `failure` a `toirt cunntas air an òrdachadh a dh` fheumar airson obrachadh luchdan a bhios a `tachairt nuair a dh` fhailicheas an coimeas.
    /// Le bhith a `cleachdadh [`Acquire`] mar òrdachadh soirbheachais tha an stòr mar phàirt den obair seo [`Relaxed`], agus le bhith a` cleachdadh [`Release`] bidh an luchd soirbheachail [`Relaxed`].
    ///
    /// Faodaidh an òrdugh fàilligeadh a bhith dìreach [`SeqCst`], [`Acquire`] no [`Relaxed`] agus feumaidh e a bhith co-ionann no nas laige na an t-òrdugh soirbheachaidh.
    ///
    /// **Note:** Chan eil an dòigh seo ri fhaighinn ach air àrd-ùrlaran a bheir taic do ghnìomhachd atamach air molaidhean.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// A `stòradh luach a-steach don phuing ma tha an luach làithreach co-ionann ri luach `current`.
    ///
    /// Eu-coltach ri [`AtomicPtr::compare_exchange`], a 'ghnìomh seo tha cead ga thoirt spuriously fail fiù' s nuair a tha an coimeas soirbheachail, a dh'fhaodas toradh ann nas èifeachdaiche code air cuid de mheadhanan.
    ///
    /// Tha an luach toraidh mar thoradh a `sealltainn an deach an luach ùr a sgrìobhadh agus anns a bheil an luach roimhe.
    ///
    /// `compare_exchange_weak` a 'gabhail dà [`Ordering`] argamaidean airson cunntas a thoirt an cuimhne rian-obrach seo.
    /// `success` a `toirt cunntas air an òrdachadh a tha a dhìth airson an obair leughaidh-atharrachaidh-sgrìobhaidh a tha a` tachairt ma shoirbhicheas leis a `choimeas le `current`.
    /// `failure` a `toirt cunntas air an òrdachadh a dh` fheumar airson obrachadh luchdan a bhios a `tachairt nuair a dh` fhailicheas an coimeas.
    /// Le bhith a `cleachdadh [`Acquire`] mar òrdachadh soirbheachais tha an stòr mar phàirt den obair seo [`Relaxed`], agus le bhith a` cleachdadh [`Release`] bidh an luchd soirbheachail [`Relaxed`].
    /// Faodaidh an òrdugh fàilligeadh a bhith dìreach [`SeqCst`], [`Acquire`] no [`Relaxed`] agus feumaidh e a bhith co-ionann no nas laige na an t-òrdugh soirbheachaidh.
    ///
    /// **Note:** Chan eil an dòigh seo ri fhaighinn ach air àrd-ùrlaran a bheir taic do ghnìomhachd atamach air molaidhean.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SÀBHAILTEACHD: Tha an gnèitheach seo cunnartach oir tha e ag obair air stiùireadh amh
        // ach tha fios againn airson cinnteach gu bheil na chomharra dligheach (sinn dìreach a fhuair e bho `UnsafeCell` gu bheil sinn le iomradh) agus atamach obrachaidh fhèin a 'toirt cothrom dhuinn gu sàbhailte mutate na th' `UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Fetches a 'cur luach air, agus a' buntainn ri obair a tha e a 'tilleadh roghainneil ùr luach.A 'tilleadh a `Result` de `Ok(previous_value)` ma' ghnìomh a thill `Some(_)`, `Err(previous_value)` eile.
    ///
    /// Note: Dh'fhaodadh seo a ghairm a 'ghnìomh ioma ma amannan air an luach a tha air a bhith air atharrachadh bho innealan eile san eadar-ama, cho fad' a 'ghnìomh a thilleas `Some(_)`, ach Thèid an dreuchd a chur an sàs a-mhàin aon uair do stòradh luach.
    ///
    ///
    /// `fetch_update` a 'gabhail dà [`Ordering`] argamaidean airson cunntas a thoirt an cuimhne rian-obrach seo.
    /// Tha a `chiad fhear a` toirt cunntas air an òrdachadh a tha riatanach airson cuin a bhios an obair a `soirbheachadh mu dheireadh fhad` s a tha an dàrna fear a `toirt cunntas air an òrdachadh a tha a dhìth airson luchdan.
    /// Tha iad sin a 'conaltradh ris a' soirbheachadh agus a 'fàilligeadh orderings de [`AtomicPtr::compare_exchange`] fa leth.
    ///
    /// Cleachdadh [`Acquire`] mar soirbheachadh ag òrdachadh a 'dèanamh an stòr phàirt de seo obrachadh [`Relaxed`], agus a' cleachdadh [`Release`] a 'dèanamh a' chuairt dheireannach soirbheachail luchd [`Relaxed`].
    /// Chan urrainn don òrdachadh luchdan (failed) a bhith ach [`SeqCst`], [`Acquire`] no [`Relaxed`] agus feumaidh e a bhith co-ionann no nas laige na òrdachadh soirbheachaidh.
    ///
    /// **Note:** Chan eil an dòigh seo ri fhaighinn ach air àrd-ùrlaran a bheir taic do ghnìomhachd atamach air molaidhean.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Bidh e ag atharrachadh `bool` gu `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Bidh am macro seo a `tighinn gu crìch gun a bhith air a chleachdadh air cuid de ailtireachd.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Seòrsa integer a ghabhas a roinn gu sàbhailte eadar snàithleanan.
        ///
        /// Tha an seòrsa a tha na h-aon-cuimhne ann an riochdachadh mar an cùl integer seòrsa, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Airson tuilleadh fiosrachaidh mu na seòrsachan eadar-dhealachaidhean eadar atamach agus neo-atamach seòrsa cho math ri fiosrachadh mu dheidhinn a 'portability seòrsa seo, faicibh an [module-level documentation].
        ///
        ///
        /// **Note:** Chan eil an seòrsa seo ri fhaighinn ach air àrd-ùrlaran a bheir taic do luchdan atamach agus stòran de [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Chaidh integer atamach a thòiseachadh gu `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Tha cuir air a chuir an gnìomh gu h-obann.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// A `cruthachadh integer atamach ùr.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// A 'tilleadh a mutable iomradh air a' bhun-integer.
            ///
            /// Tha seo sàbhailte oir tha an iomradh gluasadach a `gealltainn nach eil snàithleanan eile a` faighinn cothrom air an dàta atamach aig an aon àm.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// leig mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - tha an iomradh mutable a `gealltainn seilbh gun samhail.
                //  - tha co-thaobhadh `$int_type` agus `Self` mar an ceudna, mar a chaidh a ghealltainn le $cfg_align agus air a dhearbhadh gu h-àrd.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// A `caitheamh an atamach agus a` tilleadh an luach a tha na bhroinn.
            ///
            /// Tha seo sàbhailte oir tha a bhith a `dol seachad air `self` a rèir luach a` gealltainn nach eil snàithleanan eile a `faighinn cothrom air an dàta atamach aig an aon àm.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// A `luchdachadh luach bhon integer atamach.
            ///
            /// `load` a `gabhail argamaid [`Ordering`] a tha a` toirt cunntas air òrdugh cuimhne na h-obrach seo.
            /// Is e luachan comasach [`SeqCst`], [`Acquire`] agus [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics ma tha `order` [`Release`] no [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Stores luach a-steach atamach integer.
            ///
            /// `store` a `gabhail argamaid [`Ordering`] a tha a` toirt cunntas air òrdugh cuimhne na h-obrach seo.
            ///  Is e luachan comasach [`SeqCst`], [`Release`] agus [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics ma tha `order` [`Acquire`] no [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// A `stòradh luach a-steach don integer atamach, a` tilleadh an luach a bh `ann roimhe.
            ///
            /// `swap` a 'gabhail an [`Ordering`] argamaid a tha a' toirt iomradh air an memory rian-obrach seo.Tha a h-uile modh òrdachaidh comasach.
            /// Thoir fa-near gu bheil a bhith a `cleachdadh [`Acquire`] a` dèanamh a `bhùth mar phàirt den obair seo [`Relaxed`], agus a` cleachdadh [`Release`] a `dèanamh a` phàirt luchdan [`Relaxed`].
            ///
            ///
            /// ** ** Nota: Tha an dòigh seo ri fhaotainn ach air àrd-chabhsairean a 'toirt taic do atamach air obraichean
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// A `stòradh luach a-steach don integer atamach ma tha an luach làithreach co-ionann ri luach `current`.
            ///
            /// Is e an luach toraidh an-còmhnaidh an luach a bh `ann roimhe.Ma tha e co-ionann ris `current`, an sin air an luach a chaidh ùrachadh.
            ///
            /// `compare_and_swap` cuideachd a `gabhail argamaid [`Ordering`] a tha a` toirt cunntas air òrdachadh cuimhne na h-obrach seo.
            /// Thoir fa-near, eadhon nuair a bhios tu a `cleachdadh [`AcqRel`], gum faodadh an obrachadh fàiligeadh agus mar sin dìreach a` coileanadh luchd `Acquire`, ach nach eil semantics `Release` agad.
            ///
            /// Le bhith a `cleachdadh [`Acquire`] bidh an stòr mar phàirt den obair seo [`Relaxed`] ma thachras e, agus le bhith a` cleachdadh [`Release`] bidh e a `dèanamh a` phàirt luchdaidh [`Relaxed`].
            ///
            /// ** ** Nota: Tha an dòigh seo ri fhaotainn ach air àrd-chabhsairean a 'toirt taic do atamach air obraichean
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # A `dèanamh imrich gu `compare_exchange` agus `compare_exchange_weak`
            ///
            /// `compare_and_swap` 'S e co-ionann ri `compare_exchange` le na leanas airson memory mapadh orderings:
            ///
            /// Tùsail |Soirbheachas |Fàilligeadh
            /// -------- | ------- | -------
            /// Relaxed |Relaxed |Togail fois |Faighinn |A thogail Release |Saoradh |Relaxed AcqRel |AcqRel |Faighinn SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` tha e ceadaichte fàiligeadh gu spùtach eadhon nuair a shoirbhicheas leis a `choimeas, a leigeas leis an trusaiche còd cruinneachaidh nas fheàrr a ghineadh nuair a thèid an coimeas agus an suaip a chleachdadh ann an lùb.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// A `stòradh luach a-steach don integer atamach ma tha an luach làithreach co-ionann ri luach `current`.
            ///
            /// Tha an luach toraidh mar thoradh a `sealltainn an deach an luach ùr a sgrìobhadh agus anns a bheil an luach roimhe.
            /// Ma shoirbhicheas leis tha an luach seo cinnteach gum bi e co-ionann ri `current`.
            ///
            /// `compare_exchange` a 'gabhail dà [`Ordering`] argamaidean airson cunntas a thoirt an cuimhne rian-obrach seo.
            /// `success` a `toirt cunntas air an òrdachadh a tha a dhìth airson an obair leughaidh-atharrachaidh-sgrìobhaidh a tha a` tachairt ma shoirbhicheas leis a `choimeas le `current`.
            /// `failure` a `toirt cunntas air an òrdachadh a dh` fheumar airson obrachadh luchdan a bhios a `tachairt nuair a dh` fhailicheas an coimeas.
            /// Le bhith a `cleachdadh [`Acquire`] mar òrdachadh soirbheachais tha an stòr mar phàirt den obair seo [`Relaxed`], agus le bhith a` cleachdadh [`Release`] bidh an luchd soirbheachail [`Relaxed`].
            ///
            /// Faodaidh an òrdugh fàilligeadh a bhith dìreach [`SeqCst`], [`Acquire`] no [`Relaxed`] agus feumaidh e a bhith co-ionann no nas laige na an t-òrdugh soirbheachaidh.
            ///
            /// ** ** Nota: Tha an dòigh seo ri fhaotainn ach air àrd-chabhsairean a 'toirt taic do atamach air obraichean
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// A `stòradh luach a-steach don integer atamach ma tha an luach làithreach co-ionann ri luach `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// ghnìomh seo tha cead ga thoirt spuriously fail fiù 's nuair a tha an coimeas soirbheachail, a dh'fhaodas toradh ann nas èifeachdaiche code air cuid de mheadhanan.
            /// Tha an luach toraidh mar thoradh a `sealltainn an deach an luach ùr a sgrìobhadh agus anns a bheil an luach roimhe.
            ///
            /// `compare_exchange_weak` a 'gabhail dà [`Ordering`] argamaidean airson cunntas a thoirt an cuimhne rian-obrach seo.
            /// `success` a `toirt cunntas air an òrdachadh a tha a dhìth airson an obair leughaidh-atharrachaidh-sgrìobhaidh a tha a` tachairt ma shoirbhicheas leis a `choimeas le `current`.
            /// `failure` a `toirt cunntas air an òrdachadh a dh` fheumar airson obrachadh luchdan a bhios a `tachairt nuair a dh` fhailicheas an coimeas.
            /// Le bhith a `cleachdadh [`Acquire`] mar òrdachadh soirbheachais tha an stòr mar phàirt den obair seo [`Relaxed`], agus le bhith a` cleachdadh [`Release`] bidh an luchd soirbheachail [`Relaxed`].
            ///
            /// Faodaidh an òrdugh fàilligeadh a bhith dìreach [`SeqCst`], [`Acquire`] no [`Relaxed`] agus feumaidh e a bhith co-ionann no nas laige na an t-òrdugh soirbheachaidh.
            ///
            /// ** ** Nota: Tha an dòigh seo ri fhaotainn ach air àrd-chabhsairean a 'toirt taic do atamach air obraichean
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// leig mut old= val.load(Ordering::Relaxed);
            /// lùb {leig ùr=seann * 2;
            ///     maids val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// A `cur ris an luach làithreach, a` tilleadh an luach a bh `ann roimhe.
            ///
            /// Bidh an obrachadh seo a `cuairteachadh timcheall air cus-shruth.
            ///
            /// `fetch_add` a 'gabhail an [`Ordering`] argamaid a tha a' toirt iomradh air an memory rian-obrach seo.Tha a h-uile modh òrdachaidh comasach.
            /// Thoir fa-near gu bheil a bhith a `cleachdadh [`Acquire`] a` dèanamh a `bhùth mar phàirt den obair seo [`Relaxed`], agus a` cleachdadh [`Release`] a `dèanamh a` phàirt luchdan [`Relaxed`].
            ///
            ///
            /// ** ** Nota: Tha an dòigh seo ri fhaotainn ach air àrd-chabhsairean a 'toirt taic do atamach air obraichean
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// A `toirt air falbh bhon luach làithreach, a` tilleadh an luach a bh `ann roimhe.
            ///
            /// Bidh an obrachadh seo a `cuairteachadh timcheall air cus-shruth.
            ///
            /// `fetch_sub` a 'gabhail an [`Ordering`] argamaid a tha a' toirt iomradh air an memory rian-obrach seo.Tha a h-uile modh òrdachaidh comasach.
            /// Thoir fa-near gu bheil a bhith a `cleachdadh [`Acquire`] a` dèanamh a `bhùth mar phàirt den obair seo [`Relaxed`], agus a` cleachdadh [`Release`] a `dèanamh a` phàirt luchdan [`Relaxed`].
            ///
            ///
            /// ** ** Nota: Tha an dòigh seo ri fhaotainn ach air àrd-chabhsairean a 'toirt taic do atamach air obraichean
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" leis an luach làithreach.
            ///
            /// A `dèanamh gnìomh beagan "and" air an luach làithreach agus an argamaid `val`, agus a` suidheachadh an luach ùr ris an toradh.
            ///
            /// A `tilleadh an luach a bh` ann roimhe.
            ///
            /// `fetch_and` a 'gabhail an [`Ordering`] argamaid a tha a' toirt iomradh air an memory rian-obrach seo.Tha a h-uile modh òrdachaidh comasach.
            /// Thoir fa-near gu bheil a bhith a `cleachdadh [`Acquire`] a` dèanamh a `bhùth mar phàirt den obair seo [`Relaxed`], agus a` cleachdadh [`Release`] a `dèanamh a` phàirt luchdan [`Relaxed`].
            ///
            ///
            /// ** ** Nota: Tha an dòigh seo ri fhaotainn ach air àrd-chabhsairean a 'toirt taic do atamach air obraichean
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" an-dràsta luach.
            ///
            /// A `dèanamh gnìomh beagan "nand" air an luach làithreach agus an argamaid `val`, agus a` suidheachadh an luach ùr ris an toradh.
            ///
            /// A `tilleadh an luach a bh` ann roimhe.
            ///
            /// `fetch_nand` a 'gabhail an [`Ordering`] argamaid a tha a' toirt iomradh air an memory rian-obrach seo.Tha a h-uile modh òrdachaidh comasach.
            /// Thoir fa-near gu bheil a bhith a `cleachdadh [`Acquire`] a` dèanamh a `bhùth mar phàirt den obair seo [`Relaxed`], agus a` cleachdadh [`Release`] a `dèanamh a` phàirt luchdan [`Relaxed`].
            ///
            ///
            /// ** ** Nota: Tha an dòigh seo ri fhaotainn ach air àrd-chabhsairean a 'toirt taic do atamach air obraichean
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" leis an luach làithreach.
            ///
            /// A `dèanamh gnìomh beagan "or" air an luach làithreach agus an argamaid `val`, agus a` suidheachadh an luach ùr ris an toradh.
            ///
            /// A `tilleadh an luach a bh` ann roimhe.
            ///
            /// `fetch_or` a 'gabhail an [`Ordering`] argamaid a tha a' toirt iomradh air an memory rian-obrach seo.Tha a h-uile modh òrdachaidh comasach.
            /// Thoir fa-near gu bheil a bhith a `cleachdadh [`Acquire`] a` dèanamh a `bhùth mar phàirt den obair seo [`Relaxed`], agus a` cleachdadh [`Release`] a `dèanamh a` phàirt luchdan [`Relaxed`].
            ///
            ///
            /// ** ** Nota: Tha an dòigh seo ri fhaotainn ach air àrd-chabhsairean a 'toirt taic do atamach air obraichean
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" leis an luach làithreach.
            ///
            /// Gabhail bitwise "xor" obrachadh air an luach agus an argamaid `val`, agus seataichean ùr luach a chur air an toradh.
            ///
            /// A `tilleadh an luach a bh` ann roimhe.
            ///
            /// `fetch_xor` a 'gabhail an [`Ordering`] argamaid a tha a' toirt iomradh air an memory rian-obrach seo.Tha a h-uile modh òrdachaidh comasach.
            /// Thoir fa-near gu bheil a bhith a `cleachdadh [`Acquire`] a` dèanamh a `bhùth mar phàirt den obair seo [`Relaxed`], agus a` cleachdadh [`Release`] a `dèanamh a` phàirt luchdan [`Relaxed`].
            ///
            ///
            /// ** ** Nota: Tha an dòigh seo ri fhaotainn ach air àrd-chabhsairean a 'toirt taic do atamach air obraichean
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Fetches a 'cur luach air, agus a' buntainn ri obair a tha e a 'tilleadh roghainneil ùr luach.A 'tilleadh a `Result` de `Ok(previous_value)` ma' ghnìomh a thill `Some(_)`, `Err(previous_value)` eile.
            ///
            /// Note: Dh'fhaodadh seo a ghairm a 'ghnìomh ioma ma amannan air an luach a tha air a bhith air atharrachadh bho innealan eile san eadar-ama, cho fad' a 'ghnìomh a thilleas `Some(_)`, ach Thèid an dreuchd a chur an sàs a-mhàin aon uair do stòradh luach.
            ///
            ///
            /// `fetch_update` a 'gabhail dà [`Ordering`] argamaidean airson cunntas a thoirt an cuimhne rian-obrach seo.
            /// Tha a `chiad fhear a` toirt cunntas air an òrdachadh a tha riatanach airson cuin a bhios an obair a `soirbheachadh mu dheireadh fhad` s a tha an dàrna fear a `toirt cunntas air an òrdachadh a tha a dhìth airson luchdan.Tha iad sin a rèir òrdughan soirbheachais is fàilligeadh
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Cleachdadh [`Acquire`] mar soirbheachadh ag òrdachadh a 'dèanamh an stòr phàirt de seo obrachadh [`Relaxed`], agus a' cleachdadh [`Release`] a 'dèanamh a' chuairt dheireannach soirbheachail luchd [`Relaxed`].
            /// Chan urrainn don òrdachadh luchdan (failed) a bhith ach [`SeqCst`], [`Acquire`] no [`Relaxed`] agus feumaidh e a bhith co-ionann no nas laige na òrdachadh soirbheachaidh.
            ///
            /// ** ** Nota: Tha an dòigh seo ri fhaotainn ach air àrd-chabhsairean a 'toirt taic do atamach air obraichean
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Ag òrdachadh: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Ag òrdachadh: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// As àirde leis an luach làithreach.
            ///
            /// A `lorg an luach as àirde agus an argamaid `val`, agus a` suidheachadh an luach ùr ris an toradh.
            ///
            /// A `tilleadh an luach a bh` ann roimhe.
            ///
            /// `fetch_max` a 'gabhail an [`Ordering`] argamaid a tha a' toirt iomradh air an memory rian-obrach seo.Tha a h-uile modh òrdachaidh comasach.
            /// Thoir fa-near gu bheil a bhith a `cleachdadh [`Acquire`] a` dèanamh a `bhùth mar phàirt den obair seo [`Relaxed`], agus a` cleachdadh [`Release`] a `dèanamh a` phàirt luchdan [`Relaxed`].
            ///
            ///
            /// ** ** Nota: Tha an dòigh seo ri fhaotainn ach air àrd-chabhsairean a 'toirt taic do atamach air obraichean
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// leig bàr=42;
            /// leig max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// dearbhte! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// As ìsle leis an luach làithreach.
            ///
            /// Lorgan a 'char as lugha an-dràsta luach agus argamaid `val`, agus a' cur luach ùr a thoradh.
            ///
            /// A `tilleadh an luach a bh` ann roimhe.
            ///
            /// `fetch_min` a 'gabhail an [`Ordering`] argamaid a tha a' toirt iomradh air an memory rian-obrach seo.Tha a h-uile modh òrdachaidh comasach.
            /// Thoir fa-near gu bheil a bhith a `cleachdadh [`Acquire`] a` dèanamh a `bhùth mar phàirt den obair seo [`Relaxed`], agus a` cleachdadh [`Release`] a `dèanamh a` phàirt luchdan [`Relaxed`].
            ///
            ///
            /// ** ** Nota: Tha an dòigh seo ri fhaotainn ach air àrd-chabhsairean a 'toirt taic do atamach air obraichean
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// leig bàr=12;
            /// leig min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÀBHAILTEACHD: tha rèisean dàta air an casg le inneach atamach.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// A `tilleadh stiùireadh gluasadach chun t-sùim iomlan.
            ///
            /// Faodaidh a bhith a `dèanamh leughaidhean neo-atamach agus a` sgrìobhadh air an integer a thig às a bhith na rèis dàta.
            /// Tha an dòigh seo feumail sa mhòr-chuid airson FFI, far am faod ainm-sgrìobhte na gnìomh a chleachdadh
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Tha tilleadh puing `*mut` bho iomradh co-roinnte air an atamach seo sàbhailte oir tha na seòrsaichean atamach ag obair le mutability taobh a-staigh.
            /// A h-uile mion-atharrachaidhean de atamach atharrachadh luach tro cho-roinnte iomradh, agus'surrainn sin a dhèanamh gu sàbhailte cho fad' sa tha iad a 'cleachdadh atamach obraichean.
            /// Sam bith air cleachdadh na thill amh chomharra Feumaidh an `unsafe` bacaidh agus fhathast gus an seas aon bacadh: obraichean air feumaidh e bhith atamach.
            ///
            ///
            /// # Examples
            ///
            /// `` `leig seachad (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// taobh a-muigh "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SÀBHAILTEACHD: Sàbhailte fhad `s a tha `my_atomic_op` atamach.
            /// cunnartach {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `atomic_store` a chumail suas.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `atomic_load` a chumail suas.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `atomic_swap` a chumail suas.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// TILLEADH roimhe luach (mar __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `atomic_add` a chumail suas.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// A `tilleadh an luach a bh` ann roimhe (mar __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `atomic_sub` a chumail suas.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `atomic_compare_exchange` a chumail suas.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `atomic_compare_exchange_weak` a chumail suas.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `atomic_and` a chumail suas
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `atomic_nand` a chumail suas
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `atomic_or` a chumail suas
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `atomic_xor` a chumail suas
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// a `tilleadh an luach as motha (coimeas soidhnichte)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Sàbhailteachd: Feumaidh an neach-conaltraidh a chumail suas sàbhailteachd cùmhnant airson `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// a `tilleadh an luach min (coimeas soidhnichte)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Sàbhailteachd: Feumaidh an neach-conaltraidh a chumail suas sàbhailteachd cùmhnant airson `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// a `tilleadh an luach as motha (coimeas gun ainm)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `atomic_umax` a chumail suas
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// a `tilleadh an luach min (coimeas gun ainm)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Sàbhailteachd: Feumaidh an neach-conaltraidh a chumail suas sàbhailteachd cùmhnant airson `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Feansa atamach.
///
/// A rèir an òrdugh ainmichte, tha feansa a `cur casg air an inneal-cruinneachaidh agus CPU bho bhith ag ath-òrdachadh seòrsan sònraichte de dh` obraichean cuimhne timcheall air.
/// Bidh sin a `cruthachadh sioncronaich-le dàimhean eadar e agus obair atamach no feansaichean ann an snàithleanan eile.
///
/// Tha feansa 'A' aig a bheil (co-dhiù) [`Release`] ag òrdachadh semantics, a `sioncronadh le feansa 'B' le (co-dhiù) [`Acquire`] semantics, ma tha agus dìreach ma tha obrachaidhean X agus Y ann, an dà chuid ag obair air cuid de nì atamach 'M' gus am bi A air a chuir an òrdugh roimhe Tha X, Y air a shioncronadh mus faic B agus Y an t-atharrachadh gu M.
/// Tha seo a `toirt seachad eisimeileachd a thachras ro-làimh eadar A agus B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Faodaidh gnìomhachd atamach le semantics [`Release`] no [`Acquire`] cuideachd sioncronadh le feansa.
///
/// Feansa a bheil [`SeqCst`] ag òrdachadh, a bharrachd air a bhith an dà chuid [`Acquire`] agus [`Release`] semeantaig, a 'gabhail pàirt ann an cruinne prògram òrdugh eile [`SeqCst`] obair agus/no feansaichean.
///
/// A `gabhail ri òrdughan [`Acquire`], [`Release`], [`AcqRel`] agus [`SeqCst`].
///
/// # Panics
///
/// Panics mas e `order` [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Prìomhachd toirmeasg dha chèile stèidhichte air spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Fuirich gus am bi an seann luach `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Bidh an fheansa seo a `sioncronadh-le stòr ann an `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SÀBHAILTEACHD: tha cleachdadh feansa atamach sàbhailte.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Feansa cuimhne co-chruinneachaidh.
///
/// `compiler_fence` chan eil e a `leigeil a-mach còd inneal sam bith, ach a` cuingealachadh na seòrsachan cuimhne a tha ag ath-òrdachadh a tha ceadaichte don neach-cruinneachaidh a dhèanamh.Gu sònraichte, a rèir na semantics [`Ordering`] a chaidh a thoirt seachad, faodar an neach-cruinneachaidh a dhì-cheadachadh bho bhith a `gluasad leughaidhean no sgrìobhadh bho ro no às deidh a` ghairm gu taobh eile a `ghairm gu `compiler_fence`.Thoir fa-near nach eil e **a`cur casg air a` bhathar-cruaidh* bho bhith ag ath-òrdachadh mar sin.
///
/// Chan eil seo na dhuilgheadas ann an aon-shnìomh, a chur gu bàs cho-theacsa, ach nuair a innealan eile a dh'fhaodadh atharrachadh cuimhne aig an aon àm, nas làidire synchronization primitives leithid [`fence`] tha a dhìth.
///
/// Tha an ath-òrdachadh le bhith a 'cur stad air an eadar-dhealaichte òrdachadh semeantaig tha:
///
///  - le [`SeqCst`], cha ath-òrdachadh a 'leughadh agus a sgrìobhadh thar a' phuing seo tha ceadaichte.
///  - le [`Release`], cha ghabh leughaidhean is sgrìobhaidhean roimhe a ghluasad seachad air sgrìobhaidhean eile.
///  - le [`Acquire`], cha ghabh leughaidhean agus sgrìobhaidhean eile a ghluasad air thoiseach air leughaidhean roimhe.
///  - le [`AcqRel`], tha an dà riaghailt gu h-àrd air an cur an gnìomh.
///
/// `compiler_fence` mar as trice chan eil e feumail ach airson casg a chuir air snàithlean bho rèiseadh *leis fhèin*.'S e sin, ma tha snàithlean a thoirt gu bàs aon pìos code, agus tha e an uair sin a stad, agus a' tòiseachadh a chur gu bàs code àiteachan eile (fhad 'sa bha fhathast anns an aon snàithlean, agus conceptually fhathast air an aon bunaiteach).Ann traidiseanta prògraman, faodaidh seo a-mhàin a 'tachairt nuair a chomharran an cìobair a chlàradh.
/// Ann an còd ìre nas ìsle, faodaidh suidheachaidhean mar sin èirigh cuideachd nuair a bhios iad a `làimhseachadh brisidhean, nuair a bhios iad a` cur an gnìomh snàithleanan uaine le ro-chasg, msaa.
/// Thathas a `brosnachadh leughadairean neònach a bhith a` leughadh deasbad an Linux kernel air [memory barriers].
///
/// # Panics
///
/// Panics mas e `order` [`Relaxed`].
///
/// # Examples
///
/// Às aonais `compiler_fence`, chan eil an `assert_eq!` ann an còd a leanas *cinnteach* gun soirbhich e, a dh `aindeoin gu bheil a h-uile dad a` tachairt ann an aon snàithlean.
/// Airson a 'faicinn carson, cuimhnich gun robh an compiler tha saor gus iomlaid na stòran gu `IMPORTANT_VARIABLE` `IS_READ` agus bhon a tha iad an dà chuid `Ordering::Relaxed`.Ma nì e, agus gu bheil an neach-làimhseachaidh comharran air a ghairm ceart às deidh `IS_READY` ùrachadh, an uairsin chì an neach-làimhseachaidh comharran `IS_READY=1`, ach `IMPORTANT_VARIABLE=0`.
/// Le bhith a `cleachdadh `compiler_fence` a` leigheas an t-suidheachaidh seo.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // cuir casg air sgrìobhaidhean nas tràithe bho bhith air an gluasad nas fhaide na a `phuing seo
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SÀBHAILTEACHD: tha cleachdadh feansa atamach sàbhailte.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// A `comharrachadh a` phròiseasair gu bheil e taobh a-staigh lùb-feitheamh trang (`glas glaiste`).
///
/// Chan eil an gnìomh seo air a mholadh airson fàbhar [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}