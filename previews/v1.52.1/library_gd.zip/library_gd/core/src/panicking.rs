//! Taic Panic airson libcore
//!
//! Chan urrainn don phrìomh leabharlann panicking a mhìneachadh, ach bidh e *a `foillseachadh* panicking.
//! Tha seo a `ciallachadh gu bheil cead aig panic na gnìomhan taobh a-staigh libcore, ach airson a bhith feumail feumaidh crate suas an abhainn mìneachadh a dhèanamh air clisgeadh airson libcore a chleachdadh.
//! Is e an eadar-aghaidh gnàthach airson panicking:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Tha am mìneachadh seo a `ceadachadh panicking le teachdaireachd coitcheann sam bith, ach chan eil e a` ceadachadh fàiligeadh le luach `Box<Any>`.
//! (Tha `&(dyn Any + Send)` dìreach ann an `&(dyn Any + Send)`, airson am bi sinn a `lìonadh luach beag ann an` PanicInfo: : internal_constructor`.) Is e an adhbhar airson seo nach eil cead aig libcore a riarachadh.
//!
//!
//! Anns a `mhodal seo tha beagan dhleastanasan panic eile, ach is iad sin dìreach na rudan lang riatanach airson an trusaiche.Tha a h-uile panics air a mhaoineachadh tron aon ghnìomh seo.
//! Tha an fhìor ìomhaigh air ainmeachadh tron fheart `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Buileachadh bunaiteach macro `panic!` libcore nuair nach eilear a `cleachdadh cruth sam bith.
#[cold]
// na gabh a-steach uair sam bith mura h-eil panic_immediate_abort gus còd a sheachnadh aig na làraichean gairm cho mòr 'sa ghabhas
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // a dh `fheumas codegen airson panic air thar-shruth agus luchd-crìochnachaidh `Assert` MIR eile
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Cleachd Arguments::new_v1 an àite format_args! ("{}", Expr) gus meud os cionn a lùghdachadh.
    // An cruth_args!bidh macro a `cleachdadh Taisbeanadh trait airson sgrìobhadh expr, ris an canar Formatter::pad, a dh` fheumas a bhith a `gabhail a-steach sreangan agus pleadhag (eadhon ged nach eilear a` cleachdadh an seo).
    //
    // Le bhith a `cleachdadh Arguments::new_v1 is dòcha gun leig an neach-cruinneachaidh Formatter::pad fhàgail a-mach às an toradh binary, a` sàbhaladh suas ri beagan kilobytes.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // a dh `fheumar airson panics const-mheasadh
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // a dh `fheumas codegen airson panic air ruigsinneachd OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Tha buileachadh bunaiteach macro `panic!` libcore nuair a thèid cruth a chleachdadh.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // NOTA Chan eil an gnìomh seo a-riamh a `dol thairis air crìoch FFI;is e gairm Rust-to-Rust a th`ann a gheibh fuasgladh air gnìomh `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SÀBHAILTEACHD: Tha `panic_impl` air a mhìneachadh ann an còd Rust sàbhailte agus mar sin tha e sàbhailte gairm.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Dreuchd a-staigh airson macros `assert_eq!` agus `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}