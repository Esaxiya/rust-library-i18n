//! Prìomhadail traits agus seòrsachan a 'riochdachadh feartan bunaiteach de sheòrsachan.
//!
//! Rust seòrsa Faodar an seòrsachadh ann an diofar dhòighean feumail a rèir an ghnèitheach lotaichean.
//! Tha iad sin a 'seòrsachadh air an riochdachadh mar traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Seòrsan a ghabhas gluasad thairis air crìochan snàithlean.
///
/// Tha an trait seo air a bhuileachadh gu fèin-ghluasadach nuair a cho-dhùineas an trusaiche gu bheil e iomchaidh.
///
/// Tha eisimpleir de neo-`Send` seòrsa a tha an iomradh-cunntadh chomharra [`rc::Rc`][`Rc`].
/// Ma dh `fheuchas dà snàithlean ri clònadh [` Rc`] s a tha a`comharrachadh an aon luach cunntais iomraidh, is dòcha gum feuchaidh iad ris a`chunntas iomraidh ùrachadh aig an aon àm, is e sin [undefined behavior][ub] oir cha bhith [`Rc`] a`cleachdadh gnìomhachd atamach.
///
/// Bidh a cho-ogha [`sync::Arc`][arc] a `cleachdadh obrachaidhean atamach (a` tighinn a-steach beagan os an cionn) agus mar sin tha `Send`.
///
/// Faic [the Nomicon](../../nomicon/send-and-sync.html) airson an tuilleadh fiosrachaidh.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Seòrsachan le daonnan meud ainmeil ri chèile aig an àm.
///
/// A h-uile seòrsa crìochan a tha fillte a-staigh a 'dol air `Sized`.Faodar an co-chòrdadh sònraichte `?Sized` a chleachdadh gus an ceangal seo a thoirt air falbh mura h-eil e iomchaidh.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // structar FooUse(Foo<[i32]>);//-mhearachd: meud nach eil a chur an gnìomh airson [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Tha an aon eisgeachd a tha fillte a-staigh na `Self` seòrsa de trait.
/// Chan eil X0trait0Z ceangailte ri `Sized` so-thuigsinn oir tha seo mì-fhreagarrach le [trait object] s far am feum, le mìneachadh, an trait a bhith ag obair leis a h-uile inneal-gnìomh a tha comasach, agus mar sin dh `fhaodadh e a bhith de mheud sam bith.
///
///
/// Ged Rust leigidh tu cheangal `Sized` gu trait, tha thu cha bhi e comasach a bhith ga cleachdadh a chruthachadh trait nì an dèidh sin:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // leig y: &dyn Bar= &Impl;//mearachd: chan urrainnear an trait `Bar` a dhèanamh na rud
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // airson bunaiteach, mar eisimpleir, a dh `fheumas measadh a dhèanamh air `[T]: !Default`
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Seòrsachan urrainn a bhith "unsized" gu dynamically meud-seòrsa.
///
/// Mar eisimpleir, meud an ordugh seòrsa `[i8; 2]` buileachadh `Unsize<[i8]>` agus `Unsize<dyn fmt::Debug>`.
///
/// All implementations de `Unsize` air a thoirt seachad gu fèin-obrachail leis a 'chur ri chèile.
///
/// `Unsize` air a bhuileachadh airson:
///
/// - `[T; N]` 'S e `Unsize<[T]>`
/// - `T` tha `Unsize<dyn Trait>` nuair `T: Trait`
/// - `Foo<..., T, ...>` 'S e `Unsize<Foo<..., U, ...>>` ma tha:
///   - `T: Unsize<U>`
///   - Tha Foo na structar
///   - Chan eil ach an raon mu dheireadh de `Foo` aig a bheil seòrsa a `toirt a-steach `T`
///   - `T` Chan eil e na phàirt den t-seòrsa sam bith eile achaidhean
///   - `Bar<T>: Unsize<Bar<U>>`, ma tha seòrsa `Bar<T>` anns an raon mu dheireadh de `Foo`
///
/// `Unsize` air a chleachdadh còmhla ri [`ops::CoerceUnsized`] gus cothrom a thoirt "user-defined" crogain a leithid [`Rc`] a tha dynamically meud-seòrsa.
/// Faic an [DST coercion RFC][RFC982] agus [the nomicon entry on coercion][nomicon-coerce] airson an tuilleadh fiosrachaidh.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Dhìth trait airson cunbhalachdan a chleachdadh ann an pàtran matches.
///
/// Bidh seòrsa sam bith a thig bho `PartialEq` gu fèin-obrachail a `buileachadh an trait seo,*ge bith* a bheil na paramadairean seòrsa aige a` buileachadh `Eq`.
///
/// Ma `const` Notaichean a tha cuid seòrsa nach eil seo a bhuileachadh trait, an uair sin a-seòrsa sin an dara cuid (1.) Chan eil chur an gnìomh `PartialEq` (a tha a 'ciallachadh daonnan Cha toir a' dèanamh coimeas eadar an dòigh, a tha an còd ghinealach a 'gabhail ris tha e ri fhaotainn), no (2.) e innealan *aca fhèin* dreach de `PartialEq` (a tha sinn a 'gabhail ris nach eil a' cumail ri co-ionannachd-structarail coimeas).
///
///
/// Anns an dara cuid an dà shuidheachadh gu h-àrd, tha sinn a dhiùltadh cleachdadh a leithid de cunbhalach ann an pàtran gèam.
///
/// Faic cuideachd [structural match RFC][RFC1445], agus [issue 63438] a-bhrosnaichte imrich bho buadha stèidhichte air dealbhadh ri seo trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Dhìth trait airson cunbhalachdan a chleachdadh ann an pàtran matches.
///
/// Seòrsa sam bith a tha a 'tighinn `Eq` fèin-obrachail a' buileachadh seo trait,* * a dh'aindeoin co dhiubh a-seòrsa `Eq` crìochan a chur an gnìomh.
///
/// Is e seo hack airson obrachadh timcheall air cuingealachadh san t-siostam seòrsa againn.
///
/// # Background
///
/// Tha sinn ag iarraidh feum a sheòrsa consts a chleachdadh ann an pàtran matches bheil an buadha `#[derive(PartialEq, Eq)]`.
///
/// Ann an saoghal nas freagarraiche, b `urrainn dhuinn sùil a thoirt air an riatanas sin le bhith dìreach a` dèanamh cinnteach gu bheil an seòrsa a chaidh a thoirt seachad a `buileachadh an dà chuid an `StructuralPartialEq` trait *agus* an `Eq` trait.
/// Ach, faodaidh tu a bhith ADTs a dhèanamh * *`derive(PartialEq, Eq)`, agus a bhith a 'chùis a tha sinn ag iarraidh an compiler gabhail ris, agus fhathast a' sìor-seòrsa fàilligeadh a chur an gnìomh `Eq`.
///
/// 'Se sin, a' chùis mar seo:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Is e an duilgheadas anns a `chòd gu h-àrd nach eil `Wrap<fn(&())>` a` buileachadh `PartialEq`, no `Eq`, oir tha` airson <'a> fn(&'a _)` does not implement those traits.)
///
/// Mar sin, chan urrainn dhuinn a bhith an urra ri sgrùdadh naive airson `StructuralPartialEq` agus dìreach `Eq`.
///
/// Mar Hack gu obair timcheall air seo, bidh sinn a 'cleachdadh dà traits stealladh le gach aon de na dà tighinn (`#[derive(PartialEq)]` agus `#[derive(Eq)]`) agus seic gu bheil an dà dhiubh a tha an-diugh mar phàirt de structarail-gèam sgrùdadh.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Seòrsan a dh `fhaodar na luachan aca a dhùblachadh dìreach le bhith a` dèanamh copaidhean de bhuillean.
///
/// Le bhith a 'default, caochlaideach bindings tha' gluasad semeantaig. 'Ann am faclan eile:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` air gluasad a-steach `y`, agus mar sin chan urrainnear a chleachdadh
///
/// // println! ("{: ?}", x);//mearachd: cleachdadh luach gluasadach
/// ```
///
/// Ach, ma tha seòrsa a `buileachadh `Copy`, an àite sin tha` copy semantics `aige:
///
/// ```
/// // Faodaidh sinn buileachadh `Copy` fhaighinn.
/// // `Clone` tha feum air cuideachd, oir is e sàr-shealladh de `Copy` a th `ann.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` 'S e leth-bhreac de `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Tha e cudromach toirt fa-near, anns an dà eisimpleir sin, gur e an aon eadar-dhealachadh a bheil cead agad faighinn gu `x` às deidh an sònrachadh.
/// Fo currachd, an dà chuid lethbhreac agus gluasad a dh'fhaodadh pìosan deach a lethbhreacadh ann an cuimhne, ged a tha seo uaireannan làn bhrath a ghabhail air falbh.
///
/// ## Ciamar a gheibh mi a chur an gnìomh `Copy`?
///
/// Tha dà dhòigh air `Copy` a chuir an gnìomh air do sheòrsa.Is e an rud as sìmplidh `derive` a chleachdadh:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Faodaidh tu cuideachd a chur an gnìomh agus `Copy` `Clone` làimh:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Tha eadar-dhealachadh beag eadar an dà rud: cuiridh an ro-innleachd `derive` cuideachd `Copy` ceangailte air paramadairean seòrsa, nach eilear an-còmhnaidh ag iarraidh.
///
/// ## Dè an diofar eadar `Copy` agus `Clone`?
///
/// Lethbhric tachairt dhìreach, mar eisimpleir mar phàirt de obrach `y = x`.Chan eil giùlan `Copy` air a luchdachadh cus;Tha e an còmhnaidh sìmplidh-bit glic lethbhreac.
///
/// Cloning tha soilleir gnìomh, `x.clone()`.Tha cur an gnìomh [`Clone`] urrainn sam bith a thoirt-seòrsa sònraichte giùlan riatanach gus dùblachadh luachan gu sàbhailte.
/// Mar eisimpleir, a chur an gnìomh airson [`Clone`] [`String`] feum a chopaigeadh-bhiorach a string bufair anns a 'charn.
/// Cha dèanadh leth-bhreac sìmplidh de luachan [`String`] ach leth-bhreac den phuing, a `leantainn gu dùbailte an-asgaidh sìos an loidhne.
/// Airson an adhbhar seo, tha [`String`] [`Clone`] ach cha `Copy`.
///
/// [`Clone`] 'S e supertrait de `Copy`, cho-uile càil a tha `Copy` feumar cuideachd a chur an gnìomh [`Clone`].
/// Mas e seòrsa `Copy` a th `ann chan fheum a bhuileachadh [`Clone`] ach `*self` a thilleadh (faic an eisimpleir gu h-àrd).
///
/// ## Cuin a dh'fhaodas mo sheòrsa a bhith `Copy`?
///
/// Faodaidh seòrsa `Copy` a chuir an gnìomh ma tha na pàirtean gu lèir aige a `buileachadh `Copy`.Mar eisimpleir, faodaidh seo a bhith struct `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// A struct `Copy` urrainn a bhith, agus tha [`i32`] `Copy`, `Point` mar sin a tha airidh air a bhith `Copy`.
/// Air an làimh eile, beachdaich
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Chan urrainn don structar `PointList` `Copy` a bhuileachadh, oir chan e `Copy` a th `ann an [`Vec<T>`].Ma tha sinn a 'feuchainn ri faighinn `Copy` cur an gnìomh, bidh sinn a' faighinn an-mhearachd:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Co-roinnte iomraidhean (`&T`) tha cuideachd `Copy` agus mar sin, faodar an seòrsa `Copy`, fiù 's nuair a tha e a' cumail co-roinnte iomraidhean de sheòrsaichean `T` a tha *Cha*`Copy`.
/// Beachdaich air na leanas struct, a dh'fhaodas a chur an gnìomh `Copy`, oir tha e a-mhàin a 'cumail co-roinnte * * iomradh gu ar neo-`Copy` seòrsa `PointList` bho gu h-àrd:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Nuair nach urrainn * mo sheòrsa a bhith `Copy`?
///
/// Chan urrainnear cuid de sheòrsan a chopaigeadh gu sàbhailte.Mar eisimpleir, le bhith a `dèanamh copaidh de `&mut T` chruthaicheadh e iomradh gluasadach eile.
/// Bhiodh leth-bhreac [`String`] a `dùblachadh uallach airson a bhith a` riaghladh bufair [`String`], a` leantainn gu dùbailte an-asgaidh.
///
/// A `toirt fa-near don chùis mu dheireadh, chan urrainn dha `Copy` a bhith aig seòrsa sam bith a` cur an gnìomh [`Drop`], oir tha e a `riaghladh cuid de ghoireas a bharrachd air na bytes [`size_of::<T>`] aige fhèin.
///
/// Ma dh'fheuchas tu ri `Copy` a chuir an gnìomh air structar no enum anns a bheil dàta neo-`Copy`, gheibh thu a `mhearachd [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Cuin *am bu chòir* mo sheòrsa a bhith `Copy`?
///
/// San fharsaingeachd, ma tha an seòrsa _can_ agad a `buileachadh `Copy`, bu chòir dha.
/// Cùm ann an inntinn, ge-tà, a 'cur an gnìomh `Copy` tha na phàirt den phoball API agad seòrsa.
/// Ma tha an t-seòrsa a dh'fhaodadh a bhith neo-`Copy` ann an future, dh'fhaodadh ea bhith glic a 'fàgail às an `Copy` a chur an gnìomh a-nis, a sheachnadh briseadh API atharrachadh.
///
/// ## Luchd-buileachaidh a bharrachd
///
/// A bharrachd air an [implementors listed below][impls], tha na seòrsachan a leanas cuideachd a `buileachadh `Copy`:
///
/// * Seòrsaichean gnìomh gnìomh (ie, na seòrsachan sònraichte a tha air am mìneachadh airson gach gnìomh)
/// * Seòrsaichean puing gnìomh (me, `fn() -> i32`)
/// * Ordugh seòrsa, airson gach meud, ma 'phìos seòrsa cuideachd a' buileachadh `Copy` (me, `[i32; 123456]`)
/// * Tuple seòrsa, ma tha gach pàirt cuideachd a 'buileachadh `Copy` (me, `()`, `(i32, bool)`)
/// * Seòrsaichean dùnaidh, mura h-eil iad a `glacadh luach sam bith bhon àrainneachd no ma tha na luachan sin air an glacadh a` cur `Copy` an gnìomh iad fhèin.
///   Thoir fa-near gum bi caochladairean a thèid an glacadh le iomradh co-roinnte an-còmhnaidh a `cur `Copy` an gnìomh (eadhon mura dèan an tagraiche), fhad` s nach bi caochladairean a thèid an glacadh le iomradh mutable a `cur `Copy` an gnìomh.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Ag ath-sgrìobhadh seo a 'leigeil a-seòrsa nach eil a' cur an gnìomh `Copy` air sgàth mì-riaraichte beatha crìochan (ag ath-sgrìobhadh `A<'_>` a-mhàin nuair a `A<'static>: Copy` agus `A<'_>: Clone`).
// Tha am feart seo againn an seo airson a-nis a-mhàin seach gu bheil grunn rudan sònraichte ann mu thràth air `Copy` a tha ann mar-thà anns an leabharlann àbhaisteach, agus chan eil dòigh ann an giùlan seo a dhèanamh gu sàbhailte an-dràsta.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Mòra a 'tighinn a' gineadh an impl an trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Seòrsachan airson a bheil e sàbhailte roinn thobraichean eadar-innealan.
///
/// Tha an trait seo air a bhuileachadh gu fèin-ghluasadach nuair a cho-dhùineas an trusaiche gu bheil e iomchaidh.
///
/// Tha mìneachadh mionaideach a tha: a-seòrsa `T` tha [`Sync`] ma tha `&T` [`Send`].
/// Ann am briathran eile, mura h-eil comas air [undefined behavior][ub] (gabhail a-steach dàta rèisean) a 'dol seachad nuair a `&T` thobraichean eadar-innealan.
///
/// Mar a bhiodh dùil, tha seòrsan prìomhach mar [`u8`] agus [`f64`] uile [`Sync`], agus mar sin tha seòrsan iomlan sìmplidh annta, leithid tuples, structairean agus enums.
/// Tha barrachd eisimpleirean de sheòrsan bunaiteach [`Sync`] a `toirt a-steach seòrsaichean "immutable" mar `&T`, agus an fheadhainn le mutability sìmplidh le dìleab, leithid [`Box<T>`][box], [`Vec<T>`][vec] agus a` mhòr-chuid de sheòrsan cruinneachaidh eile.
///
/// (Feumaidh paramadairean gnèitheach a bhith [`Sync`] airson an soitheach aca a bhith [`Sync`].)
///
/// Is e toradh rudeigin iongantach den mhìneachadh gur e `Sync` `Sync` (mas e `T` `Sync`) ged a tha e coltach gum faodadh sin a bhith a `toirt seachad mùthadh neo-shioncronach.
/// Tha an cleas gu bheil mutable iomradh air cùlaibh co-roinnte iomradh (is e sin, `& &mut T`) gu bhith a 'leughadh a-mhàin, mar gun robh e a `& &T`.
/// Mar sin chan eil cunnart ann gum bi rèis dàta ann.
///
/// Seòrsachan nach eil `Sync` tha an fheadhainn a tha "interior mutability" ann an neo-snàthainn sàbhailte-riochd, mar [`Cell`][cell] agus [`RefCell`][refcell].
/// Seòrsa seo cothrom a thoirt do mutation de na th 'aca fiù' s tro immutable, co-roinn fiosrachaidh.
/// Mar eisimpleir tha an dòigh air a `set` [`Cell<T>`][cell] gabhail `&self`, mar sin tha e a 'cur feum a-mhàin co-roinnte iomradh [`&Cell<T>`][cell].
/// Chan eil an dòigh seo a `dèanamh sioncronadh sam bith, mar sin chan urrainn [`Cell`][cell] a bhith `Sync`.
///
/// Mar eisimpleir eile de neo-`Sync` seòrsa a tha an iomradh-cunntadh chomharra [`Rc`][rc].
/// Leis sam bith iomradh [`&Rc<T>`][rc], faodaidh sibh clone ùr [`Rc<T>`][rc], a 'gleusadh an t-iomradh a' cunntadh ann an dòigh neo-atamach.
///
/// Airson cùisean nuair a bhios aon a 'dèanamh feum snàithlean-mutability sàbhailte taobh a-staigh, a' toirt Rust [atomic data types], cho math soilleir 'sabaid len tro [`sync::Mutex`][mutex] agus [`sync::RwLock`][rwlock].
/// Seòrsa seo cinnteach gum bi mutation sam bith nach urrainn aobhar dàta rèisean, sin an seòrsa a tha `Sync`.
/// Mar an ceudna, [`sync::Arc`][arc] a 'toirt snàithlean-sàbhailte analogue de [`Rc`][rc].
///
/// Seòrsa sam bith taobh a-staigh le mutability feumar cuideachd a 'cleachdadh an [`cell::UnsafeCell`][unsafecell] còmhdach timcheall air a' value(s) a ghabhas mùthaidh tro cho-roinn fiosrachaidh.
/// Gun a bhith a 'dèanamh seo tha [undefined behavior][ub].
/// Mar eisimpleir, [`transmute`][transmute]-ing bho `&T` `&mut T` a tha mì-dhligheach.
///
/// Faic [the Nomicon][nomicon-send-and-sync] airson tuilleadh fiosrachaidh mu `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): aon uair taic gus notaichean a chuir ann an fearann `rustc_on_unimplemented` ann am beta, agus chaidh a leudachadh gus dèanamh cinnteach a bheil dùnadh an àite sam bith san t-sèine riatanasan, leudaich e mar sin (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Zero-seòrsa meud a chleachdadh gus rudan a chomharrachadh "act like" iad fhèin a `T`.
///
/// Ma chuireas tu raon `PhantomData<T>` ris an t-seòrsa agad, innsidh an neach-cruinneachaidh gu bheil an seòrsa agad ag obair mar gum biodh e a `stòradh luach de sheòrsa `T`, eadhon ged nach eil e dha-rìribh.
/// Tha am fiosrachadh seo a chleachdadh nuair a coimpiutaireachd sònraichte feartan sàbhailteachd.
///
/// Airson mìneachadh nas doimhne air mar a chleachdas tu `PhantomData<T>`, faic [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Nòta uamhasach 👻👻👻
///
/// Ged a tha ainmean eagallach orra le chèile, tha `PhantomData` agus `seòrsaichean phantom` càirdeach, ach chan eil iad co-ionann.Is e dìreach paramadair seòrsa phantom dìreach paramadair seòrsa nach eilear a `cleachdadh a-riamh.
/// Ann Rust, gu tric tha seo ag adhbhrachadh an compiler airson casaid a thogail, agus a 'fuasgladh Cuir a "dummy" a chleachdadh le dòigh-`PhantomData`.
///
/// # Examples
///
/// ## Paramadairean beatha gun chleachdadh
///
/// 'S dòcha as cumanta a' cleachdadh a 'chùis airson `PhantomData` S e struct a tha cleachdte beatha paramadair, mar as trice mar phàirt den cuid sàbhailte còd.
/// Mar eisimpleir, tha seo struct `Slice` bheil dà Pointers an seòrsa a `*const T`, a rèir coltais a 'comharrachadh a-steach an ordugh àiteigin:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Is e an rùn nach eil an dàta bunaiteach dligheach ach airson fad-beatha `'a`, mar sin cha bu chòir `Slice` a bhith fada os cionn `'a`.
/// Ach, chan eil an rùn seo air a chuir an cèill anns a `chòd, leis nach eil feum sam bith ann de bheatha `'a` agus mar sin chan eil e soilleir dè an dàta a tha e a` buntainn.
/// Faodaidh sinn seo a cheartachadh le bhith ag iarraidh air an trusaiche obrachadh *mar gum biodh*`&'a T` anns an structar `Slice`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Tha seo cuideachd ann Feumaidh an nota `T: 'a`, a 'sealltainn gu bheil iomraidhean sam bith ann `T` tha dligheach thar beatha `'a`.
///
/// Nuair a thòisicheas tu `Slice` tha thu dìreach a `toirt seachad an luach `PhantomData` airson an raon `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Cleachdte seòrsa crìochan
///
/// Tha e uaireannan a 'tachairt gu bheil cleachdte seòrsa crìochan tha a' sealltainn dè an seòrsa dàta a tha struct "tied" ri, ged a tha an dàta idir a lorg ann an struct fhèin.
/// Seo eisimpleir far a bheil seo a dh'èireas le [FFI].
/// Tha an cèin eadar-aghaidh cleachdaidhean a làmhan de seòrsa `*mut ()` iomradh a thoirt air Rust luachan de dhiofar sheòrsaichean.
/// Bidh sinn a `cumail sùil air an t-seòrsa Rust a` cleachdadh paramadair seòrsa phantom air an structar `ExternalResource` a bhios a `pasgadh cas.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Seilbh agus a 'bhoinne-seic
///
/// Le bhith a `cur raon den t-seòrsa `PhantomData<T>` ris tha sin a` sealltainn gu bheil dàta den t-seòrsa `T` aig an t-seòrsa agad.Tha seo an uair sin a `ciallachadh nuair a thèid an seòrsa agad a leigeil sìos, gum faodadh e tuiteam aon no barrachd eisimpleirean den t-seòrsa `T`.
/// Tha seo air buaidh mhòr air an Rust compiler aig [drop check] mion-sgrùdadh.
///
/// Ma tha do struct chan eil gu dearbh fhèin * * an dàta de seòrsa `T`, tha e nas fheàrr a bhith a 'cleachdadh iomradh seòrsa, mar `PhantomData<&'a T>` (ideally) no `PhantomData<*const T>` (ma eil beatha a' buntainn), gus nach 'sealltainn sealbh.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler-a-staigh trait air a chleachdadh gus an seòrsa de enum discriminants a chomharrachadh.
///
/// Tha seo a 'trait tha fèin-obrachail a chur an gnìomh airson gach seòrsa agus chan eil Cuir sam bith bharantasan a [`mem::Discriminant`].
/// Is e **giùlan neo-mhìnichte** gluasad eadar `DiscriminantKind::Discriminant` agus `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// An seòrsa de lethbhreith, a dh `fheumas a bhith a` sàsachadh an trait bounds a dh `fheumas `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-a-staigh trait air a chleachdadh gus faighinn a-mach a bheil seòrsa a `toirt a-steach `UnsafeCell` sam bith taobh a-staigh, ach chan ann tro indirection.
///
/// Tha seo a 'toirt buaidh air, mar eisimpleir, co-dhiù a `static` den t-seòrsa sin a chur ann an leughadh a-mhàin socrach memory no writable socrach chuimhne.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Seòrsan a ghabhas gluasad gu sàbhailte às deidh dhaibh a bhith air am pronnadh.
///
/// Rust tha i fhèin 'eil smuain de immovable seòrsa, agus a' beachdachadh air gluasad (me, tro obrach no [`mem::replace`])-còmhnaidh a bhith sàbhailte.
///
/// Tha an seòrsa [`Pin`][Pin] air a chleachdadh na àite gus casg a chuir air gluasadan tron t-siostam seòrsa.Chan urrainnear comharran `P<T>` a tha air am pasgadh ann am pasgan [`Pin<P<T>>`][Pin] a ghluasad a-mach.
/// Faic an [`pin` module] sgrìobhainnean airson barrachd fiosrachaidh air pinning.
///
/// Le bhith a `cur an `Unpin` trait airson `T` a` togail na cuingealachaidhean bho bhith a `putadh far an t-seòrsa, a leigeas an uairsin `T` a ghluasad a-mach à [`Pin<P<T>>`][Pin] le gnìomhan leithid [`mem::replace`].
///
///
/// `Unpin` chan eil buaidh sam bith aige air dàta neo-phinn.
/// Gu sònraichte, [`mem::replace`] sòlas a 'gluasad `!Unpin` dàta (tha e ag obair airson sam bith `&mut T`, chan ann dìreach nuair `T: Unpin`).
/// Ach, chan urrainn dhut a 'cleachdadh [`mem::replace`] air dàta a phasgadh broinn [`Pin<P<T>>`][Pin] oir chan urrainn dhut fhaighinn an `&mut T` a dh'fheumas tu airson sin, agus *a*' S e tha a 'dèanamh obair-siostam seo.
///
/// So seo, mar eisimpleir, ach a mhàin a dhèanamh air cur an gnìomh `Unpin` seòrsa:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Feumaidh sinn a mutable iomradh a ghairm `mem::replace`.
/// // Faodaidh sinn fhaighinn leithid iomradh le (implicitly) invoking `Pin::deref_mut`, ach tha sin a-mhàin a ghabhas a chionn `String` innealan `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Tha an trait seo air a bhuileachadh gu fèin-ghluasadach airson cha mhòr a h-uile seòrsa.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// A 'comharradh-seòrsa nach eil a' cur an gnìomh `Unpin`.
///
/// Ma tha `PhantomPinned` ann an seòrsa, cha chuir e `Unpin` an gnìomh gu bunaiteach.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementations de `Copy` airson seòrsachan prìomhadail.
///
/// Implementations nach urrainn a bhith air a mhìneachadh ann an Rust a chur an gnìomh ann an `traits::SelectionContext::copy_clone_conditions()` ann `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Co-roinnte iomraidhean Faodar lethbhreac a dhèanamh, ach mutable iomraidhean *nach urrainn*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}