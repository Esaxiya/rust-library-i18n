//! Riarachadh cuimhne APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Tha mearachd `AllocError` a `nochdadh fàilligeadh riarachaidh a dh` fhaodadh a bhith mar thoradh air sàrachadh ghoireasan no rudeigin ceàrr nuair a thèid na h-argamaidean inntrigidh a chaidh a thoirt seachad leis an riaraiche seo a thoirt còmhla.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (feumaidh sinn seo airson impl sìos de mhearachd trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Faodaidh buileachadh `Allocator` a bhith a `riarachadh, a` fàs, a `crìonadh, agus a` tuigsinn blocaichean rèiteachaidh dàta a chaidh a mhìneachadh tro [`Layout`][].
///
/// `Allocator` air a dhealbhadh airson a bhith air a bhuileachadh air ZSTn, iomraidhean, no comharran snasail oir chan urrainnear inneal-sgaoilidh mar `MyAlloc([u8; N])` a ghluasad, gun a bhith ag ùrachadh na comharran chun chuimhne a chaidh a thoirt seachad.
///
/// Eu-coltach ri [`GlobalAlloc`][], tha cuibhreannan meud neoni ceadaichte ann an `Allocator`.
/// Mura h-eil neach-riarachaidh bunaiteach a `toirt taic dha seo (mar jemalloc) no a` tilleadh comharradh null (leithid `libc::malloc`), feumar seo a ghlacadh leis a `bhuileachadh.
///
/// ### Cuimhne air a riarachadh an-dràsta
///
/// Tha cuid de na modhan ag iarraidh gum bi bloc cuimhne *air a riarachadh an-dràsta* tro neach-sònrachaidh.Tha seo a `ciallachadh:
///
/// * chaidh an seòladh tòiseachaidh airson a `bhloc cuimhne sin a thilleadh roimhe le [`allocate`], [`grow`], no [`shrink`], agus
///
/// * cha deach am bloc cuimhne a thuigsinn às deidh sin, far a bheil blocaichean an dàrna cuid air an tuigsinn gu dìreach le bhith air an toirt seachad gu [`deallocate`] no air an atharrachadh le bhith air an toirt seachad gu [`grow`] no [`shrink`] a thilleas `Ok`.
///
/// Ma tha `grow` no `shrink` air `Err` a thilleadh, bidh am fiosaiche a chaidh seachad dligheach.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Suidheachadh cuimhne
///
/// Tha cuid de na modhan ag iarraidh gum bi cruth *a `freagairt* bloc cuimhne.
/// Is e a tha e a `ciallachadh airson cruth gu "fit" a tha bloc cuimhne a` ciallachadh (no co-ionann, airson bloca cuimhne gu "fit" cruth) gum feum na cumhaichean a leanas a bhith:
///
/// * Feumar am bloc a riarachadh leis an aon cho-thaobhadh ri [`layout.align()`], agus
///
/// * Feumaidh an [`layout.size()`] a chaidh a thoirt seachad tuiteam anns an raon `min ..= max`, far:
///   - `min` a bheil meud an cruth a chaidh a chleachdadh o chionn ghoirid gus am bloc a riarachadh, agus
///   - `max` an fhìor mheud as ùire a chaidh a thilleadh bho [`allocate`], [`grow`], no [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Feumaidh blocaichean cuimhne a th `air an tilleadh bho neach-sònrachaidh a bhith a` comharrachadh cuimhne dhligheach agus an dligheachd a chumail gus an tèid an t-eisimpleir agus na clones aige gu lèir a leigeil sìos,
///
/// * chan fhaod clonadh no gluasad an neach-sònrachaidh blocaichean cuimhne a thilleadh bhon riaraiche seo a dhligheachadh.Feumaidh neach-sònrachaidh clonaichte a bhith gad ghiùlan fhèin mar an aon neach-sgaoilidh, agus
///
/// * faodar comharradh sam bith gu bloc cuimhne a tha [*currently allocated*] a thoirt do dhòigh sam bith eile den neach-sònrachaidh.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// A `feuchainn ri bloc cuimhne a riarachadh.
    ///
    /// Air soirbheachas, a `tilleadh coinneamh [`NonNull<[u8]>`][NonNull] a` coinneachadh ri barantas meud is co-thaobhadh `layout`.
    ///
    /// Is dòcha gu bheil meud nas motha aig a `bhloc a chaidh a thilleadh na tha air a shònrachadh le `layout.size()`, agus dh` fhaodadh no nach bi na susbaint aige air a thòiseachadh.
    ///
    /// # Errors
    ///
    /// Taghaidh `Err` 'sealltainn gu bheil an dàrna cuid memory tha claoidhte `layout` no nach eil a' coinneachadh allocator meud no co-thaobhadh na bacaidhean.
    ///
    /// Thathas a `brosnachadh bhuileachadh gus `Err` a thilleadh air sàrachadh cuimhne seach a bhith a` clisgeadh no a `sgurradh, ach chan eil seo na riatanas teann.
    /// (Gu sònraichte: tha e *laghail* an trait seo a chuir an gnìomh aig mullach leabharlann riarachaidh dùthchasach a bhios a `lughdachadh air sàrachadh cuimhne.)
    ///
    /// Thathas a `brosnachadh luchd-dèiligidh a tha airson casg a chuir air co-fhreagairt mar fhreagairt do mhearachd riarachaidh gnìomh [`handle_alloc_error`] a ghairm, seach a bhith a` toirt ionnsaigh dhìreach air `panic!` no a leithid.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// A `giùlan mar `allocate`, ach bidh e cuideachd a` dèanamh cinnteach gu bheil an cuimhne a th `air a thilleadh neoni-tòiseachaidh.
    ///
    /// # Errors
    ///
    /// Taghaidh `Err` 'sealltainn gu bheil an dàrna cuid memory tha claoidhte `layout` no nach eil a' coinneachadh allocator meud no co-thaobhadh na bacaidhean.
    ///
    /// Thathas a `brosnachadh bhuileachadh gus `Err` a thilleadh air sàrachadh cuimhne seach a bhith a` clisgeadh no a `sgurradh, ach chan eil seo na riatanas teann.
    /// (Gu sònraichte: tha e *laghail* an trait seo a chuir an gnìomh aig mullach leabharlann riarachaidh dùthchasach a bhios a `lughdachadh air sàrachadh cuimhne.)
    ///
    /// Thathas a `brosnachadh luchd-dèiligidh a tha airson casg a chuir air co-fhreagairt mar fhreagairt do mhearachd riarachaidh gnìomh [`handle_alloc_error`] a ghairm, seach a bhith a` toirt ionnsaigh dhìreach air `panic!` no a leithid.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SÀBHAILTEACHD: Bidh `alloc` a `tilleadh bloc cuimhne dligheach
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// A `riarachadh a` chuimhne air a bheil `ptr` a `toirt iomradh.
    ///
    /// # Safety
    ///
    /// * `ptr` Feumaidh denote bloc memory [*currently allocated*] via seo allocator, agus
    /// * `layout` feumaidh [*fit*] am bloc cuimhne sin.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Oidhirpean gus am bloc cuimhne a leudachadh.
    ///
    /// A `tilleadh [`NonNull<[u8]>`][NonNull] ùr anns a bheil stiùireadh agus meud fìor na cuimhne a chaidh a thoirt seachad.Tha am fiosaiche freagarrach airson dàta a chumail air a mhìneachadh le `new_layout`.
    /// Gus seo a choileanadh, faodaidh an neach-riarachaidh an riarachadh air a bheil `ptr` a `leudachadh a rèir an dreach ùr.
    ///
    /// Ma thilleas seo `Ok`, tha seilbh air a `bhloc cuimhne air a bheil `ptr` air a ghluasad chun neach-riarachaidh seo.
    /// Dh `fhaodadh gun deach a` chuimhne a shaoradh, agus bu chòir a mheas nach gabhadh a chleachdadh mura deach a ghluasad air ais chun neach-fios a-rithist tro luach tilleadh an dòigh seo.
    ///
    /// Ma thilleas an dòigh seo `Err`, cha deach seilbh a `bhloc cuimhne a ghluasad chun an riaraiche seo, agus chan eil susbaint a` bhloc cuimhne gun atharrachadh.
    ///
    /// # Safety
    ///
    /// * `ptr` feumaidh e bloc cuimhne [*currently allocated*] a chomharrachadh tron riaraiche seo.
    /// * `old_layout` feumaidh [*fit*] am bloc cuimhne sin (Chan fheum argamaid `new_layout` a bhith iomchaidh.).
    /// * `new_layout.size()` feumaidh e a bhith nas motha na no co-ionann ri `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// A `tilleadh `Err` mura h-eil an cruth ùr a` coinneachadh ri meud agus cuibhreachadh co-thaobhadh an neach-sònrachaidh, no ma dh `fhàsas a chaochladh a` fàiligeadh.
    ///
    /// Thathas a `brosnachadh bhuileachadh gus `Err` a thilleadh air sàrachadh cuimhne seach a bhith a` clisgeadh no a `sgurradh, ach chan eil seo na riatanas teann.
    /// (Gu sònraichte: tha e *laghail* an trait seo a chuir an gnìomh aig mullach leabharlann riarachaidh dùthchasach a bhios a `lughdachadh air sàrachadh cuimhne.)
    ///
    /// Thathas a `brosnachadh luchd-dèiligidh a tha airson casg a chuir air co-fhreagairt mar fhreagairt do mhearachd riarachaidh gnìomh [`handle_alloc_error`] a ghairm, seach a bhith a` toirt ionnsaigh dhìreach air `panic!` no a leithid.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SÀBHAILTEACHD: oir feumaidh `new_layout.size()` a bhith nas motha na no co-ionann ris
        // `old_layout.size()`, tha an dà chuid an riarachadh cuimhne sean is ùr dligheach airson leughaidhean agus sgrìobhadh airson `old_layout.size()` bytes.
        // Cuideachd, leis nach deach an seann riarachadh a thuigsinn fhathast, chan urrainn dha a dhol thairis air `new_ptr`.
        // Mar sin, tha an gairm gu `copy_nonoverlapping` sàbhailte.
        // Feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `dealloc` a chumail suas.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// A `giùlan mar `grow`, ach bidh e cuideachd a` dèanamh cinnteach gu bheil na susbaint ùr air an suidheachadh gu neoni mus tèid an toirt air ais.
    ///
    /// Bidh na leanas anns a `bhloc cuimhne às deidh gairm soirbheachail gu
    /// `grow_zeroed`:
    ///   * Tha Bytes `0..old_layout.size()` air an gleidheadh bhon riarachadh tùsail.
    ///   * Thèid Bytes `old_layout.size()..old_size` a ghlèidheadh no a neoni, a rèir buileachadh an riaraiche.
    ///   `old_size` a `toirt iomradh air meud a` bhloc cuimhne ron ghairm `grow_zeroed`, a dh `fhaodadh a bhith nas motha na a` mheud a chaidh iarraidh an toiseach nuair a chaidh a riarachadh.
    ///   * Tha Bytes `old_size..new_size` air an neoni.Tha `new_size` a `toirt iomradh air meud a` bhloc cuimhne a thill a `ghairm `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` feumaidh e bloc cuimhne [*currently allocated*] a chomharrachadh tron riaraiche seo.
    /// * `old_layout` feumaidh [*fit*] am bloc cuimhne sin (Chan fheum argamaid `new_layout` a bhith iomchaidh.).
    /// * `new_layout.size()` feumaidh e a bhith nas motha na no co-ionann ri `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// A `tilleadh `Err` mura h-eil an cruth ùr a` coinneachadh ri meud agus cuibhreachadh co-thaobhadh an neach-sònrachaidh, no ma dh `fhàsas a chaochladh a` fàiligeadh.
    ///
    /// Thathas a `brosnachadh bhuileachadh gus `Err` a thilleadh air sàrachadh cuimhne seach a bhith a` clisgeadh no a `sgurradh, ach chan eil seo na riatanas teann.
    /// (Gu sònraichte: tha e *laghail* an trait seo a chuir an gnìomh aig mullach leabharlann riarachaidh dùthchasach a bhios a `lughdachadh air sàrachadh cuimhne.)
    ///
    /// Thathas a `brosnachadh luchd-dèiligidh a tha airson casg a chuir air co-fhreagairt mar fhreagairt do mhearachd riarachaidh gnìomh [`handle_alloc_error`] a ghairm, seach a bhith a` toirt ionnsaigh dhìreach air `panic!` no a leithid.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SÀBHAILTEACHD: oir feumaidh `new_layout.size()` a bhith nas motha na no co-ionann ris
        // `old_layout.size()`, tha an dà chuid an riarachadh cuimhne sean is ùr dligheach airson leughaidhean agus sgrìobhadh airson `old_layout.size()` bytes.
        // Cuideachd, leis nach deach an seann riarachadh a thuigsinn fhathast, chan urrainn dha a dhol thairis air `new_ptr`.
        // Mar sin, tha an gairm gu `copy_nonoverlapping` sàbhailte.
        // Feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `dealloc` a chumail suas.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// A `feuchainn ris a` bhloc cuimhne a lughdachadh.
    ///
    /// A `tilleadh [`NonNull<[u8]>`][NonNull] ùr anns a bheil stiùireadh agus meud fìor na cuimhne a chaidh a thoirt seachad.Tha am fiosaiche freagarrach airson dàta a chumail air a mhìneachadh le `new_layout`.
    /// Gus seo a choileanadh, faodaidh an neach-riarachaidh an riarachadh air a bheil `ptr` a `lughdachadh a rèir an dreach ùr.
    ///
    /// Ma thilleas seo `Ok`, tha seilbh air a `bhloc cuimhne air a bheil `ptr` air a ghluasad chun neach-riarachaidh seo.
    /// Dh `fhaodadh gun deach a` chuimhne a shaoradh, agus bu chòir a mheas nach gabhadh a chleachdadh mura deach a ghluasad air ais chun neach-fios a-rithist tro luach tilleadh an dòigh seo.
    ///
    /// Ma thilleas an dòigh seo `Err`, cha deach seilbh a `bhloc cuimhne a ghluasad chun an riaraiche seo, agus chan eil susbaint a` bhloc cuimhne gun atharrachadh.
    ///
    /// # Safety
    ///
    /// * `ptr` feumaidh e bloc cuimhne [*currently allocated*] a chomharrachadh tron riaraiche seo.
    /// * `old_layout` feumaidh [*fit*] am bloc cuimhne sin (Chan fheum argamaid `new_layout` a bhith iomchaidh.).
    /// * `new_layout.size()` feumaidh e a bhith nas lugha na no co-ionann ri `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// A `tilleadh `Err` mura h-eil an cruth ùr a` coinneachadh ri meud agus cuibhreachadh co-thaobhadh an neach-sònrachaidh, no ma dh `fhailicheas an crìonadh.
    ///
    /// Thathas a `brosnachadh bhuileachadh gus `Err` a thilleadh air sàrachadh cuimhne seach a bhith a` clisgeadh no a `sgurradh, ach chan eil seo na riatanas teann.
    /// (Gu sònraichte: tha e *laghail* an trait seo a chuir an gnìomh aig mullach leabharlann riarachaidh dùthchasach a bhios a `lughdachadh air sàrachadh cuimhne.)
    ///
    /// Thathas a `brosnachadh luchd-dèiligidh a tha airson casg a chuir air co-fhreagairt mar fhreagairt do mhearachd riarachaidh gnìomh [`handle_alloc_error`] a ghairm, seach a bhith a` toirt ionnsaigh dhìreach air `panic!` no a leithid.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SÀBHAILTEACHD: oir feumaidh `new_layout.size()` a bhith nas ìsle na no co-ionann ris
        // `old_layout.size()`, an dà chuid an sean agus ùr chuimhne riarachadh a tha dligheach airson a 'leughadh agus a' sgrìobhadh airson `new_layout.size()` bytes.
        // Cuideachd, leis nach deach an seann riarachadh a thuigsinn fhathast, chan urrainn dha a dhol thairis air `new_ptr`.
        // Mar sin, tha an gairm gu `copy_nonoverlapping` sàbhailte.
        // Feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `dealloc` a chumail suas.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// A `cruthachadh inneal-atharrachaidh "by reference" airson an eisimpleir seo de `Allocator`.
    ///
    /// Bidh an adapter a chaidh a thilleadh cuideachd a `buileachadh `Allocator` agus gheibh e air iasad e.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd a chumail suas
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd a chumail suas
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd a chumail suas
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd a chumail suas
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}