use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Sònraiche cuimhne a dh `fhaodar a chlàradh mar thùs àbhaisteach an leabharlainn tron fheart `#[global_allocator]`.
///
/// Tha cuid de na modhan ag iarraidh gum bi bloc cuimhne *air a riarachadh an-dràsta* tro neach-sònrachaidh.Tha seo a `ciallachadh:
///
/// * chaidh an seòladh tòiseachaidh airson a `bhloc cuimhne sin a thilleadh roimhe le gairm roimhe gu modh riarachaidh leithid `alloc`, agus
///
/// * cha deach am bloc cuimhne a thuigsinn às deidh sin, far a bheil blocaichean air an tuigsinn an dàrna cuid le bhith air an toirt seachad gu modh tuigseocation mar `dealloc` no le bhith air an toirt seachad gu modh ath-riarachadh a thilleas comharradh neo-null.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// Is e an `GlobalAlloc` trait an `unsafe` trait airson grunn adhbharan, agus feumaidh luchd-buileachaidh dèanamh cinnteach gu bheil iad a `cumail ris na cùmhnantan sin:
///
/// * Is e giùlan neo-mhìnichte a th `ann ma dh` iarras luchd-riarachaidh cruinneil.Faodar an cuingeachadh seo a thogail anns an future, ach an-dràsta dh `fhaodadh panic bho gin de na gnìomhan sin leantainn gu mì-shàbhailteachd cuimhne.
///
/// * `Layout` feumaidh ceistean agus àireamhachadh san fharsaingeachd a bhith ceart.Tha cead aig luchd-gairm an trait seo a bhith an urra ris na cùmhnantan a tha air am mìneachadh air gach dòigh, agus feumaidh luchd-buileachaidh dèanamh cinnteach gu bheil na cùmhnantan sin fhathast fìor.
///
/// * Is dòcha nach eil thu an urra ri riarachadh a `tachairt, eadhon ged a tha riarachadh tiùrran follaiseach san stòr.
/// Is dòcha gu bheil an optimizer a `lorg cuibhreannan nach deach an cleachdadh gum faod e cuir às gu tur no gluasad chun stac agus mar sin gun a bhith a` toirt ionnsaigh air an neach-sònrachaidh.
/// Faodaidh an optimizer gabhail ris gu bheil riarachadh neo-mhearachdach, agus mar sin is dòcha gum bi còd a b `àbhaist a bhith a` fàilligeadh air sgàth fàilligeadh riarachaidh ag obair gu h-obann oir dh `obraich an optimizer timcheall air an fheum airson riarachadh.
/// Nas cinntiche, tha an eisimpleir còd a leanas mì-chinnteach, ge bith a bheil an neach-sònrachaidh àbhaisteach agad a `ceadachadh cunntadh cia mheud riarachadh a thachair.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Thoir fa-near nach e na optimizations a chaidh ainmeachadh gu h-àrd an aon optimization a ghabhas a chuir an sàs.Mar as trice is dòcha nach bi thu an urra ri riarachadh tiùrr ma thèid an toirt air falbh gun a bhith ag atharrachadh giùlan a `phrògraim.
///   Chan eil co-dhiù a bhios cuibhreannan a `tachairt no nach eil mar phàirt de ghiùlan a` phrògraim, eadhon ged a dh `fhaodar a lorg tro neach-riarachaidh a bhios a` cumail sùil air riarachadh le clò-bhualadh no fo-bhuaidhean eile.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Riarachadh mar chuimhneachan air a mhìneachadh leis a 'thoirt `layout`.
    ///
    /// A `tilleadh stiùireadh gu cuimhne ùr-riaraichte, no null gus comharrachadh fàilligeadh riarachaidh.
    ///
    /// # Safety
    ///
    /// Tha an gnìomh seo cunnartach oir faodaidh giùlan neo-mhìnichte leantainn mura h-eil an neach-fios a `dèanamh cinnteach gu bheil meud neo-neoni aig `layout`.
    ///
    /// (Dh `fhaodadh fo-sgrìobhaidhean leudachaidh crìochan nas sònraichte a thoirt air giùlan, me, gealltainn seòladh sentinel no stiùireadh null mar fhreagairt air iarrtas riarachadh meud neoni.)
    ///
    /// Is dòcha gun tèid am bloc cuimhne a chaidh a riarachadh a thòiseachadh.
    ///
    /// # Errors
    ///
    /// Tha tilleadh puing null a `nochdadh gu bheil an dàrna cuid cuimhne air a shaoradh no nach eil `layout` a` coinneachadh ri meud no cuibhreachadh co-thaobhadh an riaraiche seo.
    ///
    /// Thathas a `brosnachadh bhuileachadh gus tilleadh null air sàrachadh cuimhne seach a bhith a` sgur, ach chan eil seo na riatanas teann.
    /// (Gu sònraichte: tha e *laghail* an trait seo a chuir an gnìomh aig mullach leabharlann riarachaidh dùthchasach a bhios a `lughdachadh air sàrachadh cuimhne.)
    ///
    /// Thathas a `brosnachadh luchd-dèiligidh a tha airson casg a chuir air co-fhreagairt mar fhreagairt do mhearachd riarachaidh gnìomh [`handle_alloc_error`] a ghairm, seach a bhith a` toirt ionnsaigh dhìreach air `panic!` no a leithid.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Dealloc a `bhloc cuimhne aig a` phuing `ptr` a chaidh a thoirt seachad leis an `layout` a chaidh a thoirt seachad.
    ///
    /// # Safety
    ///
    /// Tha an gnìomh seo neo-shàbhailte oir faodaidh giùlan neo-mhìnichte leantainn mura h-eil an neach-fòn a `dèanamh cinnteach gu bheil na leanas:
    ///
    ///
    /// * `ptr` feumaidh iad a bhith a `comharrachadh bloc cuimhne a tha air a riarachadh an-dràsta tron riaraiche seo,
    ///
    /// * `layout` feumaidh gur e an aon chruth a chaidh a chleachdadh gus am bloc cuimhne sin a riarachadh.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// A `giùlan mar `alloc`, ach bidh e cuideachd a` dèanamh cinnteach gu bheil na tha ann gu neoni mus tèid a thilleadh.
    ///
    /// # Safety
    ///
    /// Tha an gnìomh seo cunnartach airson na h-aon adhbharan a tha `alloc`.
    /// Ach tha e cinnteach gun tèid am bloc cuimhne a chaidh a riarachadh a thòiseachadh.
    ///
    /// # Errors
    ///
    /// Tha tilleadh puing null a `nochdadh gu bheil an dàrna cuid cuimhne air a shaoradh no nach eil `layout` a` coinneachadh ri meud no cuibhreachadh co-thaobhadh, dìreach mar ann an `alloc`.
    ///
    /// Thathas a `brosnachadh luchd-dèiligidh a tha airson casg a chuir air co-fhreagairt mar fhreagairt do mhearachd riarachaidh gnìomh [`handle_alloc_error`] a ghairm, seach a bhith a` toirt ionnsaigh dhìreach air `panic!` no a leithid.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `alloc` a chumail suas.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SÀBHAILTEACHD: mar a shoirbhich leis an riarachadh, an roinn bho `ptr`
            // de mheud `size` tha e cinnteach gum bi e dligheach airson sgrìobhaidhean.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Dèan crìonadh no fàs bloc cuimhne chun `new_size` a chaidh a thoirt seachad.
    /// Tha am bloc air a mhìneachadh leis a `phuing `ptr` a chaidh a thoirt seachad agus `layout`.
    ///
    /// Ma thilleas seo comharradh neo-null, tha seilbh air a `bhloc cuimhne air a bheil `ptr` air a ghluasad chun neach-riarachaidh seo.
    /// Is dòcha gu bheil no nach deach an cuimhne a thuigsinn, agus bu chòir a bhith air a mheas nach gabhadh a chleachdadh (mura deach a ghluasad air ais chun neach-fios a-rithist tro luach tilleadh an dòigh seo).
    /// Tha am bloc cuimhne ùr air a riarachadh le `layout`, ach leis an `size` air ùrachadh gu `new_size`.
    /// Bu chòir an cruth ùr seo a chleachdadh nuair a thathas a `tuigsinn a` bhloc cuimhne ùr le `dealloc`.
    /// Tha an raon `0..min(layout.size(), new_size) `den bhloc cuimhne ùr cinnteach gu bheil na h-aon luachan aig a` bhloc tùsail.
    ///
    /// Ma thilleas an dòigh seo null, cha deach seilbh a `bhloc cuimhne a ghluasad chun neach-riarachaidh seo, agus chan eil susbaint a` bhloc cuimhne gun atharrachadh.
    ///
    /// # Safety
    ///
    /// Tha an gnìomh seo neo-shàbhailte oir faodaidh giùlan neo-mhìnichte leantainn mura h-eil an neach-fòn a `dèanamh cinnteach gu bheil na leanas:
    ///
    /// * `ptr` feumar a riarachadh an-dràsta tron riaraiche seo,
    ///
    /// * `layout` feumaidh gur e an aon chruth a chaidh a chleachdadh gus am bloc cuimhne sin a riarachadh,
    ///
    /// * `new_size` feumaidh e a bhith nas àirde na neoni.
    ///
    /// * `new_size`, nuair a thèid a chuairteachadh suas chun an àireamh as fhaisge de `layout.align()`, chan fhaod e a dhol thairis (ie, feumaidh an luach cruinn a bhith nas lugha na `usize::MAX`).
    ///
    /// (Dh `fhaodadh fo-sgrìobhaidhean leudachaidh crìochan nas sònraichte a thoirt air giùlan, me, gealltainn seòladh sentinel no stiùireadh null mar fhreagairt air iarrtas riarachadh meud neoni.)
    ///
    /// # Errors
    ///
    /// A `tilleadh null mura h-eil an cruth ùr a` coinneachadh ri meud agus cuingealachaidhean co-thaobhadh an neach-sònrachaidh, no ma dh `fhailicheas ath-riarachadh a chaochladh.
    ///
    /// Thathas a `brosnachadh bhuileachadh gus tilleadh null air sàrachadh cuimhne seach a bhith a` clisgeadh no a `sgurradh, ach chan eil seo na riatanas teann.
    /// (Gu sònraichte: tha e *laghail* an trait seo a chuir an gnìomh aig mullach leabharlann riarachaidh dùthchasach a bhios a `lughdachadh air sàrachadh cuimhne.)
    ///
    /// Thathas a `brosnachadh luchd-dèiligidh a tha airson casg a chuir air co-fhreagairt mar fhreagairt do mhearachd ath-riarachadh gnìomh [`handle_alloc_error`] a ghairm, seach a bhith a` toirt ionnsaigh dhìreach air `panic!` no a leithid.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SÀBHAILTEACHD: feumaidh an neach-fòn dèanamh cinnteach nach cuir an `new_size` thairis.
        // `layout.align()` a `tighinn bho `Layout` agus mar sin tha e cinnteach gum bi e dligheach.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SÀBHAILTEACHD: feumaidh an neach-fòn dèanamh cinnteach gu bheil `new_layout` nas motha na neoni.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SÀBHAILTEACHD: chan urrainn don bhloc a chaidh a riarachadh roimhe a dhol thairis air a `bhloc a chaidh a riarachadh às ùr.
            // Feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `dealloc` a chumail suas.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}