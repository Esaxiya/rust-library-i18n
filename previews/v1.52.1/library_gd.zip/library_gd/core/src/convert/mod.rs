//! Traits airson atharrachaidhean eadar seòrsan.
//!
//! Tha an traits sa mhodal seo a `toirt seachad dòigh airson tionndadh bho aon sheòrsa gu seòrsa eile.
//! Tha gach trait a `frithealadh adhbhar eadar-dhealaichte:
//!
//! - Cuir an [`AsRef`] trait an gnìomh airson atharrachaidhean iomraidh saor airson iomradh
//! - Cuir an [`AsMut`] trait an gnìomh airson atharrachaidhean saor mutable-to-mutable
//! - Cuir an [`From`] trait an gnìomh airson a bhith ag ithe atharrachaidhean luach gu luach
//! - Cuir an [`Into`] trait an gnìomh airson a bhith ag ithe atharrachaidhean luach gu luach gu seòrsaichean taobh a-muigh an crate gnàthach
//! - Bidh an [`TryFrom`] agus [`TryInto`] traits gan giùlan fhèin mar [`From`] agus [`Into`], ach bu chòir an cur an gnìomh nuair a dh `fhaodas an tionndadh fàiligeadh.
//!
//! Tha an traits sa mhodal seo gu tric air an cleachdadh mar trait bounds airson gnìomhan gnèitheach gus taic a thoirt do dh `argumaidean de iomadh seòrsa.Faic sgrìobhainnean gach trait airson eisimpleirean.
//!
//! Mar ùghdar leabharlainn, bu chòir dhut an-còmhnaidh a bhith a `cur an gnìomh [`From<T>`][`From`] no [`TryFrom<T>`][`TryFrom`] seach [`Into<U>`][`Into`] no [`TryInto<U>`][`TryInto`], oir tha [`From`] agus [`TryFrom`] a` toirt seachad barrachd sùbailteachd agus a `tabhann buileachaidhean [`Into`] no [`TryInto`] co-ionann an-asgaidh, le taing do bhuileachadh plaide san leabharlann àbhaisteach.
//! Nuair a bhios tu a `cuimseachadh air dreach ro Rust 1.41, is dòcha gum feumar [`Into`] no [`TryInto`] a chuir an gnìomh gu dìreach nuair a thèid atharrachadh gu seòrsa taobh a-muigh an crate gnàthach.
//!
//! # Buileachadh gnèitheach
//!
//! - [`AsRef`] agus fèin-thaobhadh [`AsMut`] ma tha an seòrsa a-staigh na iomradh
//! - Tha [`bho`]`<U>airson T` a `ciallachadh [` Into`]`</u><T><U>airson U`</u>
//! - Tha [`TryFrom`]`<U>airson T` a `ciallachadh [` TryInto`]`</u><T><U>airson U`</u>
//! - [`From`] agus [`Into`] reflexive, a `ciallachadh gum faod gach seòrsa `into` iad fhèin agus `from` iad fhèin
//!
//! Faic gach trait airson eisimpleirean cleachdaidh.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// An gnìomh dearbh-aithne.
///
/// Tha dà rud cudromach ri thoirt fa-near mun ghnìomh seo:
///
/// - Chan eil e an-còmhnaidh co-ionnan ri dùnadh mar `|x| x`, oir dh `fhaodadh an dùnadh a bhith a` coiteachadh `x` gu seòrsa eadar-dhealaichte.
///
/// - Bidh e a `gluasad an cur-a-steach `x` a chaidh a thoirt don ghnìomh.
///
/// Ged a dh `fhaodadh gum biodh e neònach gnìomh a bhith agad a thilleas air ais an cur-a-steach, tha cuid de chleachdaidhean inntinneach ann.
///
///
/// # Examples
///
/// A `cleachdadh `identity` gun dad a dhèanamh ann an sreath de dhleastanasan inntinneach eile:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Leigeamaid oirnn gur e gnìomh inntinneach a th `ann a bhith a` cur aon ris.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// A `cleachdadh `identity` mar chùis bun "do nothing" ann an cumhachan:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Dèan stuth nas inntinniche ...
///
/// let _results = do_stuff(42);
/// ```
///
/// A `cleachdadh `identity` gus na tionndaidhean `Some` de iterator de `Option<T>` a chumail:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// A chleachdadh gus a dhèanamh saor iomradh-gu-iomradh air iompachadh.
///
/// Tha an trait seo coltach ri [`AsMut`] a tha air a chleachdadh airson tionndadh eadar iomraidhean gluasadach.
/// Ma dh `fheumas tu tionndadh cosgail a dhèanamh tha e nas fheàrr [`From`] a chuir an gnìomh le seòrsa `&T` no gnìomh gnàthaichte a sgrìobhadh.
///
/// `AsRef` tha an aon ainm-sgrìobhte ri [`Borrow`], ach tha [`Borrow`] eadar-dhealaichte ann am beagan thaobhan:
///
/// - Eu-coltach ri `AsRef`, tha impl plaide aig [`Borrow`] airson `T` sam bith, agus faodar a chleachdadh gus gabhail ri teisteanas no luach.
/// - [`Borrow`] cuideachd ag iarraidh gum bi [`Hash`], [`Eq`] agus [`Ord`] airson luach air iasad co-ionann ris an fheadhainn aig a bheil luach seilbh.
/// Air an adhbhar seo, ma tha thu airson iasad fhaighinn air dìreach aon raon de structar faodaidh tu `AsRef` a chuir an gnìomh, ach chan e [`Borrow`].
///
/// **Note: Chan fhaod an trait seo fàiligeadh **.Ma dh `fhaodas an tionndadh fàiligeadh, cleachd modh sònraichte a thilleas [`Option<T>`] no [`Result<T, E>`].
///
/// # Buileachadh gnèitheach
///
/// - `AsRef` fèin-ghluasadach ma tha an seòrsa a-staigh na iomradh no na iomradh gluasadach (me: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Le bhith a `cleachdadh trait bounds faodaidh sinn gabhail ri argamaidean de dhiofar sheòrsaichean cho fad` s gun gabh an atharrachadh chun t-seòrsa ainmichte `T`.
///
/// Mar eisimpleir: Le bhith a `cruthachadh gnìomh coitcheann a bheir `AsRef<str>` tha sinn a` cur an cèill gu bheil sinn airson gabhail ris a h-uile iomradh a ghabhas atharrachadh gu [`&str`] mar argamaid.
/// Leis gu bheil an dà chuid [`String`] agus [`&str`] a `buileachadh `AsRef<str>` faodaidh sinn gabhail ris an dà chuid mar argamaid inntrigidh.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// A 'coileanadh an iompachadh.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Air a chleachdadh gus tionndadh iomraidh saor mutable-to-mutable a dhèanamh.
///
/// Tha an trait seo coltach ri [`AsRef`] ach air a chleachdadh airson tionndadh eadar iomraidhean gluasadach.
/// Ma dh `fheumas tu tionndadh cosgail a dhèanamh tha e nas fheàrr [`From`] a chuir an gnìomh le seòrsa `&mut T` no gnìomh gnàthaichte a sgrìobhadh.
///
/// **Note: Chan fhaod an trait seo fàiligeadh **.Ma dh `fhaodas an tionndadh fàiligeadh, cleachd modh sònraichte a thilleas [`Option<T>`] no [`Result<T, E>`].
///
/// # Buileachadh gnèitheach
///
/// - `AsMut` fèin-ghluasadach ma tha an seòrsa a-staigh na iomradh gluasadach (me: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// A `cleachdadh `AsMut` mar trait bound airson gnìomh gnèitheach faodaidh sinn gabhail ris a h-uile iomradh gluasadach a ghabhas atharrachadh gu seòrsa `&mut T`.
/// Leis gu bheil [`Box<T>`] a `buileachadh `AsMut<T>` is urrainn dhuinn gnìomh `add_one` a sgrìobhadh a bheir a h-uile argamaid a ghabhas atharrachadh gu `&mut u64`.
/// Leis gu bheil [`Box<T>`] a `buileachadh `AsMut<T>`, tha `add_one` a` gabhail ri argamaidean de sheòrsa `&mut Box<u64>` cuideachd:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// A 'coileanadh an iompachadh.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Tionndadh luach gu luach a bhios a `caitheamh luach an in-chuir.An taobh eile de [`From`].
///
/// Bu chòir aon a bhith a `seachnadh [`Into`] a bhuileachadh agus [`From`] a chuir an gnìomh na àite.
/// Bidh a bhith a `buileachadh [`From`] gu fèin-ghluasadach a` toirt seachad [`Into`] le aon bhuileachadh le taing dha buileachadh plaide san leabharlann àbhaisteach.
///
/// Is fheàrr le bhith a `cleachdadh [`Into`] thairis air [`From`] nuair a bhios tu a` sònrachadh trait bounds air gnìomh coitcheann gus dèanamh cinnteach gun gabh seòrsaichean nach cuir an gnìomh ach [`Into`] a chleachdadh cuideachd.
///
/// **Note: Chan fhaod an trait seo fàiligeadh **.Ma iompachadh urrainn fail, a 'cleachdadh [`TryInto`].
///
/// # Buileachadh gnèitheach
///
/// - [`Bho`]`<T>oir tha U` a `ciallachadh `Into<U> for T`
/// - [`Into`] 'S e reflexive, a tha a' ciallachadh gu bheil `Into<T> for T` a chur an gnìomh
///
/// # Buileachadh [`Into`] airson iompachadh taobh a-muigh sheòrsa ann an seann dreachan Rust
///
/// Ro Rust 1.41, mura robh an seòrsa ceann-uidhe na phàirt den crate gnàthach cha b `urrainn dhut [`From`] a chuir an gnìomh gu dìreach.
/// Mar eisimpleir, gabh an còd seo:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Bidh seo a `fàiligeadh ri chèile ann an dreachan nas sine den chànan oir b` àbhaist dha riaghailtean dìlleachdan Rust a bhith beagan nas cruaidhe.
/// Airson seach-rathad seo, dh'fhaodadh tu a chur an gnìomh dìreach [`Into`]:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Tha e cudromach tuigsinn gu bheil [`Into`] Chan eil [`From`] a thoirt seachad a chur an gnìomh (mar a [`From`] dèanamh le [`Into`]).
/// Mar sin, bu chòir dhut an-còmhnaidh feuchainn ri [`From`] a bhuileachadh agus an uairsin tuiteam air ais gu [`Into`] mura h-urrainnear [`From`] a bhuileachadh.
///
/// # Examples
///
/// [`String`] innealan [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Gus a chuir an cèill gu bheil sinn ag iarraidh gnìomh coitcheann a h-uile argamaid a ghabhas atharrachadh gu seòrsa `T` ainmichte, faodaidh sinn trait bound de [`Into`]`a chleachdadh<T>`.
///
/// Mar eisimpleir: Tha an gnìomh `is_hello` a `gabhail a h-uile argamaid a ghabhas atharrachadh gu bhith na [` Vec`]`<`[`u8`]`> `.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// A 'coileanadh an iompachadh.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Air a chleachdadh gus atharrachaidhean luach-gu-luach a dhèanamh fhad `s a bhios iad a` caitheamh luach an in-chuir.Is e an co-ainm [`Into`].
///
/// Bu chòir aon a bhith an-còmhnaidh nas fheàrr a bhith a `buileachadh `From` thairis air [`Into`] oir tha buileachadh `From` gu fèin-ghluasadach a` toirt seachad [`Into`] le buileachadh le taing dha buileachadh plaide san leabharlann àbhaisteach.
///
///
/// Na cuir an gnìomh [`Into`] ach nuair a bhios tu a `cuimseachadh air dreach ro Rust 1.41 agus ag atharrachadh gu seòrsa taobh a-muigh an crate gnàthach.
/// `From` cha robh e comasach dha na seòrsaichean atharrachaidhean sin a dhèanamh ann an dreachan na bu thràithe air sgàth riaghailtean dìlleachdan Rust.
/// Faic [`Into`] airson tuilleadh fiosrachaidh.
///
/// Is fheàrr le bhith a `cleachdadh [`Into`] thairis air a bhith a` cleachdadh `From` nuair a bhios tu a `sònrachadh trait bounds air gnìomh coitcheann.
/// San dòigh seo, faodar seòrsaichean a chuireas an gnìomh [`Into`] gu dìreach a chleachdadh mar argamaidean cuideachd.
///
/// Tha `From` e cuideachd glè fheumail nuair coileanadh mearachd a làimhseachadh.Nuair a bhios tu a `togail gnìomh a tha comasach air fàiligeadh, mar as trice bidh an seòrsa tilleadh den fhoirm `Result<T, E>`.
/// Tha an `From` trait a `sìmpleachadh làimhseachadh mhearachdan le bhith a` leigeil le gnìomh aon seòrsa mearachd a thilleadh a tha a `gabhail a-steach iomadh seòrsa mearachd.Faicibh an earrann "Examples" agus [the book][book] airson an tuilleadh fiosrachaidh.
///
/// **Note: Chan fhaod an trait seo fàiligeadh **.Ma dh `fhaodas an tionndadh fàiligeadh, cleachd [`TryFrom`].
///
/// # Buileachadh gnèitheach
///
/// - `From<T> for U` a `ciallachadh [` Into`]` <U>airson T`</u>
/// - `From` tha reflexive, a `ciallachadh gu bheil `From<T> for T` air a bhuileachadh
///
/// # Examples
///
/// [`String`] a `buileachadh `From<&str>`:
///
/// Tha tionndadh sònraichte bho `&str` gu String air a dhèanamh mar a leanas:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Fhad `s a tha thu a` coileanadh làimhseachadh mhearachdan tha e feumail gu tric `From` a chuir an gnìomh airson an seòrsa mearachd agad fhèin.
/// Le bhith ag atharrachadh seòrsachan mearachd bunaiteach chun t-seòrsa mearachd àbhaisteach againn fhèin a tha a `toirt a-steach an seòrsa mearachd bunaiteach, is urrainn dhuinn aon seòrsa mearachd a thilleadh gun a bhith a` call fiosrachadh mun bhun-adhbhar.
/// Bidh an gnìomhaiche '?' gu fèin-ghluasadach ag atharrachadh an seòrsa mearachd bunaiteach chun t-seòrsa mearachd àbhaisteach againn le bhith a `gairm `Into<CliError>::into` a thèid a thoirt seachad gu fèin-ghluasadach nuair a bhios tu a` buileachadh `From`.
/// Bidh an trusaiche an uairsin a `dearbhadh dè buileachadh `Into` a bu chòir a chleachdadh.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// A 'coileanadh an iompachadh.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Tionndadh oidhirp a dh `itheas `self`, a dh` fhaodadh no nach eil daor.
///
/// Leabharlann ùghdaran mar as trice cha bu chòir a chur an gnìomh dìreach trait seo, ach bu chòir a b 'fheàrr a chur an gnìomh an [`TryFrom`] trait, a' toirt barrachd sùbailteachd agus a 'toirt seachad co-ionann `TryInto` buileachadh saor an-asgaidh, taing do plaide chur an gnìomh ann an inbhe leabharlainn.
/// Airson tuilleadh fiosrachaidh air seo, faic na sgrìobhainnean airson [`Into`].
///
/// # buileachadh `TryInto`
///
/// Tha seo a `fulang na h-aon chuingealachaidhean agus reusanachadh ri bhith a` buileachadh [`Into`], faic an sin airson mion-fhiosrachadh.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Thill an seòrsa air ais ma tha mearachd tionndaidh ann.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// A 'coileanadh an iompachadh.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Tionndaidhean seòrsa sìmplidh is sàbhailte a dh `fhaodadh a bhith a` fàiligeadh ann an dòigh fo smachd ann an cuid de shuidheachaidhean.Is e an co-ainm [`TryInto`].
///
/// Tha seo feumail nuair a tha thu a `dèanamh tionndadh seòrsa a dh` fhaodadh soirbheachadh gu beag ach a dh `fhaodadh a bhith feumach air làimhseachadh sònraichte.
/// Mar eisimpleir, chan eil dòigh ann air [`i64`] a thionndadh gu [`i32`] a `cleachdadh an [`From`] trait, oir is dòcha gu bheil luach ann an [`i64`] nach urrainn don [`i32`] a riochdachadh agus mar sin chailleadh an tionndadh dàta.
///
/// Faodar seo a làimhseachadh le bhith a `tilgeil an [`i64`] gu [`i32`] (gu riatanach a` toirt luach modulo [`i32::MAX`] [`i64`]) no dìreach le bhith a` tilleadh [`i32::MAX`], no le dòigh eile.
/// Tha an [`From`] trait an dùil airson atharrachaidhean foirfe, agus mar sin tha an `TryFrom` trait ag innse don phrogramaiche nuair a dh `fhaodadh tionndadh seòrsa a dhol dona agus a` leigeil leotha co-dhùnadh ciamar a làimhsicheas iad e.
///
/// # Buileachadh gnèitheach
///
/// - `TryFrom<T> for U` a `ciallachadh [` TryInto`]` <U>airson T`</u>
/// - [`try_from`] tha e reflexive, a `ciallachadh gu bheil `TryFrom<T> for T` air a bhuileachadh agus nach urrainn dha fàiligeadh-is e an seòrsa `Error` co-cheangailte airson `T::try_from()` a ghairm air luach seòrsa `T` [`Infallible`].
/// Nuair a thèid an seòrsa [`!`] a dhèanamh seasmhach bidh [`Infallible`] agus [`!`] co-ionann.
///
/// `TryFrom<T>` Faodar a bhuileachadh mar a leanas:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Mar a chaidh a mhìneachadh, tha [`i32`] a `buileachadh` TryFrom <`[` i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Bidh sàmhchair a `briseadh `big_number`, a` feumachdainn a bhith a `lorg agus a` làimhseachadh a `chlàir às deidh na fìrinn.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // A `tilleadh mearachd leis gu bheil `big_number` ro mhòr airson a dhol a-steach do `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // A `tilleadh `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Thill an seòrsa air ais ma tha mearachd tionndaidh ann.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// A 'coileanadh an iompachadh.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// BEACHDAN COITCHEANN
////////////////////////////////////////////////////////////////////////////////

// Mar lioft thairis&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Mar lioft os cionn &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): cuir na h-impls gu h-àrd an àite&/&mut leis an fhear nas coitcheann a leanas:
// // Mar lioft thairis air Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U :? Sized> AsRef <U>airson D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// Bidh AsMut a `togail thairis air &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): cuir an impl gu h-àrd an àite &mut leis an fhear nas coitcheann a leanas:
// // Bidh AsMut a `togail thairis air DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U :? Sized> AsMut <U>airson D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Bho a `ciallachadh Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Tha bho (agus mar sin a-steach) sùbailte
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Nota seasmhachd:** Chan eil an impl seo ann fhathast, ach tha sinn "reserving space" airson a chuir ris anns an future.
/// Faic [rust-lang/rust#64715][#64715] airson mion-fhiosrachadh.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): dèan socrachadh prionnsapal na àite.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom ciallachadh TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Tha atharrachaidhean do-chreidsinneach co-ionann gu semantically ri atharrachaidhean fallible le seòrsa mearachd neo-àitichte.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// concrait IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// AN T-EILEAN ERROR ERROR
////////////////////////////////////////////////////////////////////////////////

/// An seòrsa mearachd airson mearachdan nach urrainn tachairt gu bràth.
///
/// Leis nach eil atharrachadh sam bith aig an enum seo, chan urrainn dha luach den t-seòrsa seo a bhith ann idir.
/// Faodaidh seo a bhith feumail airson APIan gnèitheach a bhios a `cleachdadh [`Result`] agus a` paramarachadh an seòrsa mearachd, gus sealltainn gu bheil an toradh an-còmhnaidh [`Ok`].
///
/// Mar eisimpleir, tha buileachadh plaide aig an [`TryFrom`] trait (tionndadh a thilleas [`Result`]) airson a h-uile seòrsa far a bheil buileachadh [`Into`] air ais.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Co-chòrdalachd Future
///
/// Tha an aon dhleastanas aig an enum seo ri [the `!`“never”type][never], a tha neo-sheasmhach san dreach seo de Rust.
/// Nuair a `!` tha crìonadh, tha sinn an dùil a dhèanamh `Infallible` seòrsa alias e:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Agus mu dheireadh ìsleachadh `Infallible`.
///
/// Ach tha aon chùis ann far an urrainnear co-aonta `!` a chleachdadh mus tèid `!` a dhèanamh seasmhach mar sheòrsa làn-chuimseach: ann an suidheachadh seòrsa tilleadh gnìomh.
/// Gu sònraichte, tha e comasach buileachadh airson dà sheòrsa puing gnìomh eadar-dhealaichte:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Le `Infallible` na enum, tha an còd seo dligheach.
/// Ach, nuair a dh'fhàsas an `Infallible` alias airson an never type, an dà `impl`s tòisichidh an tar-iadhadh agus mar sin thèid tadhal a thoirt seachad le bhith a 'chànain trait co-leanailt riaghailtean.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}