use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// A còmhdach gus bacadh a chur ri chèile bho fèin-obrachail a 'gairm `T` aig destructor.
/// Tha am pasgan seo 0-chosgais.
///
/// `ManuallyDrop<T>` 'S e cuspair an aon cruth optimizations mar `T`.
/// Mar thoradh air, tha e *eil a 'bhuaidh* air na barailean a chur ri chèile a' dèanamh mu dheidhinn a th 'ann.
/// Mar eisimpleir, initializing a `ManuallyDrop<&mut T>` le [`mem::zeroed`] tha undefined giùlan.
/// Ma dh'fheumas tu uninitialized làimhseachadh dàta, a 'cleachdadh [`MaybeUninit<T>`] àite.
///
/// Thoir an aire gum faighinn cothrom air luach am broinn `ManuallyDrop<T>` e sàbhailte.
/// Tha seo a 'ciallachadh gu bheil `ManuallyDrop<T>` aig a bheil susbaint air a bhith a' tuiteam, chan fhaod a bhith fosgailte tro poblach sàbhailte API.
/// A rèir seo, `ManuallyDrop::drop` e sàbhailte.
///
/// # `ManuallyDrop` agus òrdugh tuiteam.
///
/// Tha [drop order] de luachan soilleir aig Rust.
/// Gus dèanamh cinnteach gu bheil raointean no muinntir an àite air an leigeil sìos ann an òrdugh sònraichte, ath-òrdanachadh na dearbhaidhean gus am bi an òrdugh tuiteam so-thuigsinn ceart.
///
/// Tha e comasach `ManuallyDrop` cleachdadh gus smachd a chumail drop òrdugh, ach feumaidh sàbhailte code agus tha e doirbh a dhèanamh gu ceart ann an làthair unwinding.
///
///
/// Mar eisimpleir, ma tha thu airson dèanamh cinnteach gu bheil sònraichte achadh air a leigeil às dèidh an cuid eile, a dhèanamh mu dheireadh air achadh de struct:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` thèid a leigeil às an dèidh `children`.
///     // Tha Rust a `gealltainn gun tèid raointean a leigeil sìos anns an òrdugh dearbhaidh.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Paisg luach airson a leigeil sìos le làimh.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Faodaidh tu fhathast obrachadh gu sàbhailte air an luach
    /// assert_eq!(*x, "Hello");
    /// // Ach cha tèid `Drop` a ruith an seo
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Earrannan luach bho `ManuallyDrop` container.
    ///
    /// Tha seo a 'leigeil leis an luach gu bhith a' tuiteam a-rithist.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Tha seo a `leigeil sìos an `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// A 'toirt an luach bho `ManuallyDrop<T>` container-mach.
    ///
    /// Tha an dòigh seo air a dèanamh airson a 'gluasad a-mach luachan ann an drop.
    /// An àite a bhith a 'cleachdadh [`ManuallyDrop::drop`] làimh a leig às an luach, faodaidh sibh a' cleachdadh an dòigh seo a ghabhail agus luach ga chleachdadh ge-tà leat.
    ///
    /// Nuair a tha e comasach, tha e nas fheàrr [`into_inner`][`ManuallyDrop::into_inner`] a chleachdadh na àite, a chuireas casg air dùblachadh susbaint an `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Bidh an gnìomh seo gu semantically a `gluasad a-mach an luach a th` ann gun a bhith a `cur casg air tuilleadh cleachdaidh, a` fàgail staid a `chiste seo gun atharrachadh.
    /// Tha e an urra riut dèanamh cinnteach nach tèid an `ManuallyDrop` seo a chleachdadh a-rithist.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // Sàbhailteachd: tha sinn a 'leughadh bhon iomradh, a tha air a ghealltainn
        // a bhith dligheach airson leughaidhean.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Le tuiteam an luach a tha na bhroinn.'S e seo co-ionann ris a' gairm [`ptr::drop_in_place`] le na chomharra air an luach a tha.
    /// Mar sin, mur an luach a tha e loma-làn struct, a 'destructor thèid a ghairm ann an àite gun a bhith a' gluasad an luach, agus mar sin faodar a chleachdadh gu sàbhailte leig [pinned] dàta.
    ///
    /// Ma tha sibh an sealbh air luach, faodaidh sibh a 'cleachdadh [`ManuallyDrop::into_inner`] àite.
    ///
    /// # Safety
    ///
    /// A 'ghnìomh seo a' ruith a 'destructor de na tha luach.
    /// A bharrachd air atharrachaidhean a rinn an inneal-sgrios fhèin, tha an cuimhne air fhàgail gun atharrachadh, agus a thaobh an t-inneal-cruinneachaidh fhathast tha pàtran beag aige a tha dligheach airson an seòrsa `T`.
    ///
    ///
    /// Ach, cha bu chòir an luach "zombie" seo a bhith fosgailte do chòd sàbhailte, agus cha bu chòir an gnìomh seo a bhith air a ghairm barrachd air aon uair.
    /// Faodaidh luach a chleachdadh às deidh dha a bhith air a leigeil sìos, no luach a lughdachadh grunn thursan, giùlan neo-mhìnichte adhbhrachadh (a rèir dè a bhios `drop` a `dèanamh).
    /// Mar as trice bidh seo air a chasg leis an t-siostam seòrsa, ach feumaidh luchd-cleachdaidh `ManuallyDrop` na geallaidhean sin a chumail suas gun chuideachadh bhon inneal-cruinneachaidh.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // Sàbhailteachd: tha sinn a 'leigeil an luach a chorrag le iomradh mutable
        // a tha cinnteach gum bi e dligheach airson sgrìobhaidhean.
        // Tha e an urra ris an neach-fòn dèanamh cinnteach nach tèid `slot` a leigeil sìos a-rithist.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}