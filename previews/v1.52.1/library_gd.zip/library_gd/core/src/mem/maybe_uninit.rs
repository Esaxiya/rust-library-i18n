use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// A còmhdach-seòrsa a thogail uninitialized ionstans `T`.
///
/// # Tòiseachd invariant
///
/// Tha an trusaiche, sa chumantas, a `gabhail ris gu bheil caochladair air a thòiseachadh gu ceart a rèir riatanasan seòrsa an caochladair.Mar eisimpleir, caochlaideach iomraidh seòrsa feumar co-thaobhadh agus neo-null.
/// 'S e seo an invariant a dh'fheumas * * daonnan a bhith air an cumail suas, fiù' s ann an còd sàbhailte.
/// Mar thoradh air an sin, bidh neoni-tòiseachadh caochlaideach de sheòrsa iomraidh ag adhbhrachadh [undefined behavior][ub] sa bhad, ge bith a bheil an t-iomradh sin a-riamh air a chleachdadh gus faighinn gu cuimhne:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // giùlan neo-mhìnichte!⚠️
/// // Tha co-ionann ri còd-`MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // giùlan neo-mhìnichte!⚠️
/// ```
///
/// Bidh an t-inneal-cruinneachaidh a `gabhail brath air seo airson grunn optimizations, leithid a bhith a` cuir às do sgrùdaidhean ùine-ruith agus a `dèanamh an fheum as fheàrr de chruth `enum`.
///
/// San aon dòigh, faodaidh susbaint gu tur a bhith aig cuimhne gu tur neo-aithnichte, agus feumaidh `bool` a bhith an-còmhnaidh `true` no `false`.Uime sin, a 'cruthachadh uninitialized `bool` tha undefined giùlan:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // giùlan neo-mhìnichte!⚠️
/// // An còd co-ionnan le `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // giùlan neo-mhìnichte!⚠️
/// ```
///
/// A bharrachd air an sin, tha cuimhne neo-aithnichte sònraichte leis nach eil luach stèidhichte aige ("fixed" a `ciallachadh "it won't change without being written to").Faodaidh leughadh an aon bhit neo-aithnichte iomadach uair toraidhean eadar-dhealaichte a thoirt seachad.
/// Tha seo ga undefined giùlan gu bheil uninitialized dàta ann an caochladair fiù 's ma tha caochlaideach tha integer seòrsa, a' chaochladh air a chumail sam bith * * bit stèidhichte pàtran:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // giùlan neo-mhìnichte!⚠️
/// // Tha co-ionann ri còd-`MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // giùlan neo-mhìnichte!⚠️
/// ```
/// (Fios gu bheil na riaghailtean mu thimcheall uninitialized integers nach eil a chrìochnachadh fhathast, ach gus am bi iad, tha e glic dhaibh a sheachnadh.)
///
/// A bharrachd air sin, cuimhnich gun robh a 'mhòr chuid seòrsa a bharrachd invariants taobh a-muigh a-mhàin a thathar a' beachdachadh air a thòiseachadh aig an t-seòrsa ìre.
/// Mar eisimpleir, `1`-thòiseachadh [`Vec<T>`] thathar a 'beachdachadh a thòiseachadh (fo an-dràsta a chur an gnìomh; chan eil seo a' dèanamh suas an stàball barantas) a chionn an aon fheumalachd a 'cruinneachadh aig a tha fios mu dheidhinn a tha e gu bheil an dàta a dh'fheumas a bhith na chomharra neo-null.
/// Chan eil a bhith a `cruthachadh leithid de `Vec<T>` ag adhbhrachadh giùlan *gun mhìneachadh* sa bhad, ach bidh e ag adhbhrachadh giùlan neo-mhìnichte leis a` mhòr-chuid de dh `obraichean sàbhailte (a` toirt a-steach a leigeil às).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` frithealadh gus cothrom a thoirt sàbhailte code gus dèiligeadh ri uninitialized dàta.
/// Tha e na chomharradh don neach-cruinneachaidh a `sealltainn gur dòcha nach deach an dàta an seo a thòiseachadh *:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Cruthaich follaiseach uninitialized iomradh.
/// // Tha fios aig an trusaiche gum faodadh dàta taobh a-staigh `MaybeUninit<T>` a bhith neo-dhligheach, agus mar sin chan eil seo UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Suidhich e gu luach dligheach.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Earrann an dàta a thòiseachadh-tha seo air a leigeil a-mhàin an dèidh * * ceart initializing `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Tha fios aig an uair sin a chur ri chèile gus nach dèan sam bith ceàrr no barailean optimizations air a 'Chòd seo.
///
/// Faodaidh tu smaoineachadh air `MaybeUninit<T>` mar a bhith caran coltach `Option<T>` ach gun sam bith de na ruith-ùine a 'tracadh agus gun sam bith de na deuchainnean sàbhailteachd.
///
/// ## out-pointers
///
/// Faodaidh tu `MaybeUninit<T>` a chleachdadh gus "out-pointers" a chuir an gnìomh: an àite dàta a thilleadh bho ghnìomh, cuir air adhart e gu cuid de chuimhne (uninitialized) gus an toradh a chuir a-steach.
/// Faodaidh seo a bhith feumail nuair a tha e cudromach don neach-fios smachd a chumail air mar a thèid an cuimhne a tha an toradh air a stòradh a riarachadh, agus tha thu airson gluasadan neo-riatanach a sheachnadh.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` nach leig às na seann shusbaint, rud a tha cudromach.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // A-nis tha fios againn `v` tha a thòiseachadh!Tha seo cuideachd a 'dèanamh cinnteach gu bheil an vector ag ceart thuit.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Initializing an ordugh eileamaid-by-eileamaid
///
/// `MaybeUninit<T>` Faodar a chleachdadh gus tòiseachadh mòr ordugh eileamaid-by-eileamaid:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Cruthaich sreath neo-aithnichte de `MaybeUninit`.
///     // Tha an `assume_init` sàbhailte oir is e an seòrsa a tha sinn ag ràdh a thòisich an seo cnap de `MaybeUninit`s, nach eil feumach air tòiseachadh.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Nunn `MaybeUninit` a 'dèanamh dad.
///     // Mar so a 'cleachdadh amh chomharra-obrach an àite `ptr::write` Chan eil adhbharachadh an t-seann uninitialized luach gu bhith a' tuiteam.
/////
///     // Cuideachd, ma tha panic aig an àm seo lùib, tha cuimhne aodion a stad, ach chan eil cuimhne sàbhailteachd chùis.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Tha a h-uile dad air a thòiseachadh.
///     // Transmute an raon chun t-seòrsa tùsail.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Faodaidh tu cuideachd obrachadh le arrays a chaidh a thòiseachadh gu ìre, a lorgadh ann an dàta ìosal.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Cruthaich sreath neo-aithnichte de `MaybeUninit`.
/// // Tha an `assume_init` sàbhailte oir is e an seòrsa a tha sinn ag ràdh a thòisich an seo cnap de `MaybeUninit`s, nach eil feumach air tòiseachadh.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Cunnt àireamh nan eileamaidean a shònraich sinn.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Airson gach nì ann an ordugh, a leigeil ma tha sinn a riarachadh e.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## A `tòiseachadh structar achadh-air-achadh
///
/// Faodaidh tu `MaybeUninit<T>`, agus am macro [`std::ptr::addr_of_mut`] a chleachdadh, gus structaran a thòiseachadh a rèir achadh:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Initializing `name` an achadh
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // A `tòiseachadh an raon `list` Ma tha panic an seo, bidh an `String` anns an raon `name` ag aoidion.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Tha na raointean uile air an tòiseachadh, agus mar sin bidh sinn a `gairm `assume_init` gus Foo tòiseachaidh fhaighinn.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` Tha an urras gu bheil an aon mheud, co-thaobhadh, agus Abi mar `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Ach cuimhnich nach eil seòrsa *anns a bheil* a `MaybeUninit<T>` an-còmhnaidh an aon chruth;Chan eil Rust sa chumantas a `gealltainn gu bheil raointean `Foo<T>` aig an aon òrdugh ri `Foo<U>` eadhon ged a tha an aon mheud agus co-thaobhadh aig `T` agus `U`.
///
/// A bharrachd sam bith a chionn beagan luach dligheach airson `MaybeUninit<T>` an compiler nach urrainn cur a-steach non-zero/niche-filling optimizations, a dh'fhaodadh a bhith a 'toradh ann nas motha:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Ma tha `T` FFI-sàbhailte, sin mar a tha `MaybeUninit<T>`.
///
/// Ged is e `#[repr(transparent)]` `MaybeUninit` (a `nochdadh gu bheil e a` gealltainn an aon mheud, co-thaobhadh, agus ABI ri `T`), chan eil seo * ag atharrachadh gin de na caitean a bh `ann roimhe.
/// `Option<T>` agus dh `fhaodadh gum bi meudan eadar-dhealaichte aig `Option<MaybeUninit<T>>` fhathast, agus faodaidh seòrsaichean anns a bheil raon de sheòrsa `T` a bhith air an cur a-mach (agus meud) ann an dòigh eadar-dhealaichte seach nam biodh an raon sin `MaybeUninit<T>`.
/// `MaybeUninit` 'S e aonadh-seòrsa, agus `#[repr(transparent)]` air aonaidhean a tha neo-sheasmhach (faic [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Thar ùine, tha na dearbh bharantasan de `#[repr(transparent)]` air aonaidhean dòcha gu bith, agus `MaybeUninit` Dh'fhaodadh gun tèid no nach eil fhathast `#[repr(transparent)]`.
/// Thuirt sin, bidh `MaybeUninit<T>`*an-còmhnaidh* a `gealltainn gu bheil an aon mheud, co-thaobhadh, agus ABI aige ri `T`;tha e dìreach gun an t-slighe `MaybeUninit`-innleachdan a dh'fhaodadh barantas bith.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Nì Lang gus an urrainn dhuinn seòrsachan eile a phasgadh ann.Tha seo feumail airson gineadairean.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Gun a bhith a `gairm `T::clone()`, chan urrainn dhuinn fios a bheil sinn a` tòiseachadh gu leòr airson sin.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// A 'cruthachadh `MaybeUninit<T>` ùr a thòiseachadh leis a' thoirt seachad luach.
    /// Tha e sàbhailte a ghairm [`assume_init`] air an tilleadh luach a 'ghnìomh seo.
    ///
    /// Cuimhnich gur nunn `MaybeUninit<T>` bràth fòn `T` Drop còd.
    /// Tha e an urra riut dèanamh cinnteach gun tèid `T` a leigeil ma chaidh a thòiseachadh.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// A 'cruthachadh ùr `MaybeUninit<T>` ann an uninitialized stàite.
    ///
    /// Cuimhnich gur nunn `MaybeUninit<T>` bràth fòn `T` Drop còd.
    /// Tha e an urra riut dèanamh cinnteach gun tèid `T` a leigeil ma chaidh a thòiseachadh.
    ///
    /// Faic an [type-level documentation][MaybeUninit] airson eisimpleirean.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Cruthaich ùr ordugh na nithean `MaybeUninit<T>`, ann an uninitialized stàite.
    ///
    /// Note: ann future Rust dreach dòigh seo a dh'fhaodadh a bhith neo-riatanach nuair ordugh litireil sheantansan a 'leigeil [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Chaidh an eisimpleir gu h-ìosal a dh'fhaodadh an uair sin a 'cleachdadh `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// A 'tilleadh a (' s dòcha nas lugha) sliseag dàta a chaidh a leughadh
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SÀBHAILTEACHD: Tha `[MaybeUninit<_>; LEN]` neo-aithnichte dligheach.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// A `cruthachadh `MaybeUninit<T>` ùr ann an staid neo-aithnichte, leis a` chuimhne air a lìonadh le bytes `0`.Tha e an urra ri `T` a bheil sin mar-thà a `dèanamh airson tòiseachadh ceart.
    ///
    /// Mar eisimpleir, tha `MaybeUninit<usize>::zeroed()` air a thòiseachadh, ach chan eil `MaybeUninit<&'static i32>::zeroed()` oir chan fheum iomraidhean a bhith null.
    ///
    /// Cuimhnich gur nunn `MaybeUninit<T>` bràth fòn `T` Drop còd.
    /// Tha e an urra riut dèanamh cinnteach gun tèid `T` a leigeil ma chaidh a thòiseachadh.
    ///
    /// # Example
    ///
    /// Correct cleachdadh a 'ghnìomh seo: initializing a struct le neoni, far a bheil a h-uile h-achaidhean an struct urrainn a chumail an-bit 0 pàtran mar dligheach luach.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Cleachdadh ceàrr* den ghnìomh seo: a `gairm `x.zeroed().assume_init()` nuair nach eil `0` na phàtran bit dligheach airson an seòrsa:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Taobh a-staigh paidhir, tha sinn a chruthachadh `NotZero` chan eil sin a tha dligheach discriminant.
    /// // Is e giùlan neo-mhìnichte a tha seo.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // Sàbhailteachd: `u.as_mut_ptr()` Puingean a riarachadh chuimhne.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// A 'cur luach na `MaybeUninit<T>`.
    /// Bidh seo a `dol thairis air luach sam bith roimhe gun a bhith ga leigeil sìos, mar sin bi faiceallach gun a bhith a` cleachdadh seo dà uair mura h-eil thu airson sgiobadh a `ruith an inneal-sgrios.
    ///
    /// Airson do ghoireasachd, bidh seo cuideachd a `tilleadh iomradh gluasadach air susbaint (a-nis air a thòiseachadh gu sàbhailte) de `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SÀBHAILTEACHD: Tha sinn dìreach air an luach seo a thòiseachadh.
        unsafe { self.assume_init_mut() }
    }

    /// Gets a tha na chomharra air an luach.
    /// Leughadh bho seo na chomharra no tionndadh e a-steach iomradh a tha undefined giùlan mur eil an `MaybeUninit<T>` Tha e a thòiseachadh.
    /// A `sgrìobhadh gu cuimhne gu bheil am puing (non-transitively) seo a` comharrachadh giùlan neo-mhìnichte (ach a-mhàin taobh a-staigh `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Cleachdadh ceart air an dòigh seo:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Cruthaich iomradh a-steach don `MaybeUninit<T>`.Tha seo ceart gu leòr seach sinn a thòiseachadh e.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// Cleachdadh *ceàrr* den dòigh seo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Tha sinn air a chruthachadh iomradh air an uninitialized vector!Is e giùlan neo-mhìnichte a tha seo.⚠️
    /// ```
    ///
    /// (Fios gu bheil na riaghailtean mu thimcheall iomraidhean uninitialized tha dàta air nach eil air a chrìochnachadh fhathast, ach gus am bi iad, tha e glic dhaibh a sheachnadh.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` agus tha an dà chuid `ManuallyDrop` `repr(transparent)` sin is urrainn dhuinn a thilgeadh a 'chomharra.
        self as *const _ as *const T
    }

    /// Gets a mutable a tha na chomharra air an luach.
    /// Leughadh bho seo na chomharra no tionndadh e a-steach iomradh a tha undefined giùlan mur eil an `MaybeUninit<T>` Tha e a thòiseachadh.
    ///
    /// # Examples
    ///
    /// Cleachdadh ceart air an dòigh seo:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Cruthaich iomradh a-steach don `MaybeUninit<Vec<u32>>`.
    /// // Tha seo ceart gu leòr oir thòisich sinn air.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// Cleachdadh *ceàrr* den dòigh seo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Tha sinn air a chruthachadh iomradh air an uninitialized vector!Is e giùlan neo-mhìnichte a tha seo.⚠️
    /// ```
    ///
    /// (Fios gu bheil na riaghailtean mu thimcheall iomraidhean uninitialized tha dàta air nach eil air a chrìochnachadh fhathast, ach gus am bi iad, tha e glic dhaibh a sheachnadh.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` agus tha an dà chuid `ManuallyDrop` `repr(transparent)` sin is urrainn dhuinn a thilgeadh a 'chomharra.
        self as *mut _ as *mut T
    }

    /// A `toirt a-mach an luach bhon inneal `MaybeUninit<T>`.Tha seo na dhòigh math air dèanamh cinnteach gun tèid an dàta a leigeil sìos, seach gu bheil an `T` a tha mar thoradh air an urra ris an làimhseachadh tuiteam àbhaisteach.
    ///
    /// # Safety
    ///
    /// Tha e an urra ris an neach-fòn gealltainn gu bheil an `MaybeUninit<T>` ann an staid tòiseachaidh.Le bhith a `gairm seo nuair nach eil an susbaint air a làn thòiseachadh fhathast ag adhbhrachadh giùlan neo-mhìnichte sa bhad.
    /// Tha [type-level documentation][inv] Tha tuilleadh fiosrachaidh mu dheidhinn seo initialization invariant.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// A bharrachd air sin, cuimhnich gun robh a 'mhòr chuid seòrsa a bharrachd invariants taobh a-muigh a-mhàin a thathar a' beachdachadh air a thòiseachadh aig an t-seòrsa ìre.
    /// Mar eisimpleir, `1`-thòiseachadh [`Vec<T>`] thathar a 'beachdachadh a thòiseachadh (fo an-dràsta a chur an gnìomh; chan eil seo a' dèanamh suas an stàball barantas) a chionn an aon fheumalachd a 'cruinneachadh aig a tha fios mu dheidhinn a tha e gu bheil an dàta a dh'fheumas a bhith na chomharra neo-null.
    ///
    /// Chan eil a bhith a `cruthachadh leithid de `Vec<T>` ag adhbhrachadh giùlan *gun mhìneachadh* sa bhad, ach bidh e ag adhbhrachadh giùlan neo-mhìnichte leis a` mhòr-chuid de dh `obraichean sàbhailte (a` toirt a-steach a leigeil às).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Cleachdadh ceart air an dòigh seo:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// Cleachdadh *ceàrr* den dòigh seo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` cha deach a thòiseachadh fhathast, agus mar sin dh `adhbhraich an loidhne mu dheireadh seo giùlan neo-mhìnichte.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gum bi `self` air a thòiseachadh.
        // Tha seo cuideachd a `ciallachadh gum feum `self` a bhith na eadar-dhealachadh `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Leugh an luach bhon inneal `MaybeUninit<T>`.Tha an `T` a tha mar thoradh air an urra ris an làimhseachadh tuiteam àbhaisteach.
    ///
    /// Nuair a tha e comasach, tha e nas fheàrr [`assume_init`] a chleachdadh na àite, a chuireas casg air dùblachadh susbaint an `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Tha e an urra ris an neach-fios gealltainn gu bheil an `MaybeUninit<T>` ann an staid tòiseachaidh.Le bhith a `gairm seo nuair nach eil an susbaint air a làn thòiseachadh fhathast ag adhbhrachadh giùlan neo-mhìnichte.
    /// Tha [type-level documentation][inv] Tha tuilleadh fiosrachaidh mu dheidhinn seo initialization invariant.
    ///
    /// A bharrachd air sin, seo a 'fàgail lethbhreac den aon dàta air cùl ann an `MaybeUninit<T>`.
    /// Nuair a bhios tu a `cleachdadh iomadh leth-bhreac den dàta (le bhith a` gairm `assume_init_read` iomadh uair, no an toiseach a `gairm `assume_init_read` agus an uairsin [`assume_init`]), tha e an urra riut dèanamh cinnteach gum faodar an dàta sin a dhùblachadh.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Cleachdadh ceart air an dòigh seo:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` is `Copy`, mar sin is dòcha gun leugh sinn iomadh uair.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Duplicating a `None` luach ceart gu leòr, agus mar sin faodaidh sinn a 'leughadh iomadh turas.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// Cleachdadh *ceàrr* den dòigh seo:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Chruthaich sinn a-nis dà leth-bhreac den aon vector, a `leantainn gu ⚠️ gun dùbailte nuair a thèid an dithis aca sìos!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gum bi `self` air a thòiseachadh.
        // Tha leughadh bho `self.as_ptr()` sàbhailte oir bu chòir `self` a thòiseachadh.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Drops an luach a tha ann an àite.
    ///
    /// Ma tha seilbh agad air an `MaybeUninit`, faodaidh tu [`assume_init`] a chleachdadh na àite.
    ///
    /// # Safety
    ///
    /// Tha e an urra ris an neach-fios gealltainn gu bheil an `MaybeUninit<T>` ann an staid tòiseachaidh.Le bhith a `gairm seo nuair nach eil an susbaint air a làn thòiseachadh fhathast ag adhbhrachadh giùlan neo-mhìnichte.
    ///
    /// A bharrachd air an sin, feumar a h-uile ionnsaigh a bharrachd den t-seòrsa `T` a bhith riaraichte, oir dh `fhaodadh gum bi gnìomhachadh `Drop` de `T` (no a bhuill) an urra ri seo.
    /// Mar eisimpleir, `1`-thòiseachadh [`Vec<T>`] thathar a 'beachdachadh a thòiseachadh (fo an-dràsta a chur an gnìomh; chan eil seo a' dèanamh suas an stàball barantas) a chionn an aon fheumalachd a 'cruinneachadh aig a tha fios mu dheidhinn a tha e gu bheil an dàta a dh'fheumas a bhith na chomharra neo-null.
    ///
    /// Ma thèid an leithid de `Vec<T>` a leigeil seachad, bidh giùlan neo-mhìnichte ann.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SÀBHAILTEACHD: feumaidh an neach-fios gealltainn gu bheil `self` air a thòiseachadh agus
        // a `sàsachadh gach ionnsaigh de `T`.
        // Tha a bhith a `leigeil às an luach na àite sàbhailte ma tha sin mar sin.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Gets co-roinnte a tha iomradh air an luach.
    ///
    /// Faodaidh seo a bhith feumail nuair a tha sinn airson faighinn gu `MaybeUninit` a chaidh a thòiseachadh ach nach eil seilbh againn air an `MaybeUninit` (a `cur casg air cleachdadh `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Le bhith a `gairm seo nuair nach eil an susbaint air a làn thòiseachadh fhathast ag adhbhrachadh giùlan neo-mhìnichte: tha e an urra ris an neach-fios a bhith a` gealltainn gu bheil an `MaybeUninit<T>` ann an staid tòiseachaidh.
    ///
    ///
    /// # Examples
    ///
    /// ### Cleachdadh ceart air an dòigh seo:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Tòisich `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // A-nis gu bheil fios gu bheil an `MaybeUninit<_>` againn air a thòiseachadh, tha e ceart gu leòr iomradh coitcheann a chruthachadh air:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // Sàbhailteachd: `x` air a bhith a thòiseachadh.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Cleachdaidhean *ceàrr* den dòigh seo:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Tha sinn air a chruthachadh iomradh air an uninitialized vector!Is e giùlan neo-mhìnichte a tha seo.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Tòisich an `MaybeUninit` a `cleachdadh `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Iomradh air `Cell<bool>` neo-aithnichte: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gum bi `self` air a thòiseachadh.
        // Tha seo cuideachd a `ciallachadh gum feum `self` a bhith na eadar-dhealachadh `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// A `faighinn iomradh (unique) mutable air an luach a tha na bhroinn.
    ///
    /// Faodaidh seo a bhith feumail nuair a tha sinn airson faighinn gu `MaybeUninit` a chaidh a thòiseachadh ach nach eil seilbh againn air an `MaybeUninit` (a `cur casg air cleachdadh `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Le bhith a `gairm seo nuair nach eil an susbaint air a làn thòiseachadh fhathast ag adhbhrachadh giùlan neo-mhìnichte: tha e an urra ris an neach-fios a bhith a` gealltainn gu bheil an `MaybeUninit<T>` ann an staid tòiseachaidh.
    /// Mar eisimpleir, chan urrainnear `.assume_init_mut()` a chleachdadh gus `MaybeUninit` a thòiseachadh.
    ///
    /// # Examples
    ///
    /// ### Cleachdadh ceart air an dòigh seo:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initializes *h-uile* an byte an taic bufair.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Tòisich `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // A-nis tha fios againn gu bheil `buf` air a thòiseachadh, agus mar sin b `urrainn dhuinn `.assume_init()` a dhèanamh air.
    /// // Ach, le bhith a `cleachdadh `.assume_init()` faodaidh e `memcpy` de na 2048 bytes a bhrosnachadh.
    /// // Gus dearbhadh gu bheil am bufair againn air a thòiseachadh gun a chopaigeadh, bidh sinn ag ùrachadh an `&mut MaybeUninit<[u8; 2048]>` gu `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // Sàbhailteachd: `buf` air a bhith a thòiseachadh.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // A-nis faodaidh sinn a 'cleachdadh `buf` mar àbhaisteach sliseag:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Cleachdaidhean *ceàrr* den dòigh seo:
    ///
    /// Chan urrainn dhut `.assume_init_mut()` a chleachdadh gus luach a thòiseachadh:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Tha sinn air iomradh (mutable) a chruthachadh airson `bool` neo-aithnichte!
    ///     // Is e giùlan neo-mhìnichte a tha seo.⚠️
    /// }
    /// ```
    ///
    /// Mar eisimpleir, chan urrainn dhut [`Read`] a thoirt a-steach do bhufair neo-aithnichte:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) iomradh air uninitialized chuimhneachan!
    ///                             // Is e giùlan neo-mhìnichte a tha seo.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Chan urrainn dhut an dàrna cuid ruigsinneachd dìreach a chleachdadh gus tùsachadh mean air mhean a dhèanamh:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) iomradh air uninitialized chuimhneachan!
    ///                  // Is e giùlan neo-mhìnichte a tha seo.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) iomradh air uninitialized chuimhneachan!
    ///                  // Is e giùlan neo-mhìnichte a tha seo.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Tha sinn an-dràsta an urra ris na tha gu h-àrd ceàrr, ie, tha iomraidhean againn air dàta neo-aithnichte (me, ann an `libcore/fmt/float.rs`).
    // Bu chòir dhuinn co-dhùnadh deireannach a dhèanamh mu na riaghailtean mus bi iad seasmhach.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gum bi `self` air a thòiseachadh.
        // Tha seo cuideachd a `ciallachadh gum feum `self` a bhith na eadar-dhealachadh `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Earrannan luachan bho iomadh `MaybeUninit` crogain.
    ///
    /// # Safety
    ///
    /// Tha e an urra ris an neach-fios a bhith a `gealltainn gu bheil a h-uile eileamaid den raon ann an staid tòiseachaidh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SÀBHAILTEACHD: A-nis sàbhailte mar a thòisich sinn a h-uile eileamaid
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Tha an neach-conaltraidh bharantasan a h-uile eileamaid de na ordugh tha thòiseachadh
        // * `MaybeUninit<T>` agus T cinnteach gu bheil an aon cruth
        // * Cha bhith MayUnint a `tuiteam, agus mar sin chan eil freiceadan dùbailte ann agus mar sin tha an tionndadh sàbhailte
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Ma tha a h-uile eileamaid a thòiseachadh, a 'faighinn sliseag dhaibh.
    ///
    /// # Safety
    ///
    /// Tha e an urra ris an neach-fios gealltainn gu bheil na h-eileamaidean `MaybeUninit<T>` ann an staid tòiseachaidh.
    ///
    /// Calling seo nuair a tha an t-susbaint nach eil e gu tur fhathast thòiseachadh adhbharan undefined giùlan.
    ///
    /// Faic [`assume_init_ref`] airson tuilleadh fiosrachaidh agus eisimpleirean.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SÀBHAILTEACHD: tha a bhith a `tilgeil sliseag gu `*const [T]` sàbhailte leis gu bheil an neach-fòn a` gealltainn sin
        // `slice` air a thòiseachadh, agus tha barantas aig`MaybeUninit` gum bi an aon dreach ri `T`.
        // Tha a 'chomharra fhaighinn dligheach bhon a' toirt iomradh air chuimhne ann le `slice` a tha iomradh air a ghealltainn agus mar sin a bhith dligheach airson a 'leughadh.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Ma tha a h-uile eileamaid a thòiseachadh, a 'faighinn mutable sliseag dhaibh.
    ///
    /// # Safety
    ///
    /// Tha e an urra ris an neach-fios gealltainn gu bheil na h-eileamaidean `MaybeUninit<T>` ann an staid tòiseachaidh.
    ///
    /// Calling seo nuair a tha an t-susbaint nach eil e gu tur fhathast thòiseachadh adhbharan undefined giùlan.
    ///
    /// Faic [`assume_init_mut`] airson tuilleadh fiosrachaidh agus eisimpleirean.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // Sàbhailteachd: coltach ri sàbhailteachd notaichean airson `slice_get_ref`, ach tha
        // mutable iomradh a tha cuideachd air a ghealltainn a bhith dligheach airson sgrìobhadh.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Gets a chomharra air a 'chiad eileamaid de ordugh.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// A `faighinn stiùireadh gluasadach chun chiad eileamaid den raon.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Dèan lethbhreac de na h-eileamaidean bho `src` gu `this`, a `tilleadh iomradh gluasadach air na tha `this` a-nis neo-sheasmhach.
    ///
    /// Ma `T` Chan eil `Copy` a chur an gnìomh, a 'cleachdadh [`write_slice_cloned`]
    ///
    /// Tha seo coltach ri [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Bidh an gnìomh seo panic ma tha faid eadar-dhealaichte aig an dà shliseag.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // Sàbhailteachd: tha sinn dìreach air a lethbhreacadh h-uile eileamaid de Len a-steach an comas a bharrachd
    /// // tha a `chiad eileamaidean src.len() den vec dligheach a-nis.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // Sàbhailteachd: &[T] agus&[MaybeUninit<T>] tha an aon chruth aca
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // Sàbhailteachd: Dligheach eileamaidean a tha dìreach air a bhith a chopaigeadh gu `this` mar sin a tha e initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clones na h-eileamaidean bho `src` gu `this`, a `tilleadh iomradh gluasadach air na tha `this` a-nis neo-sheasmhach.
    /// Sam bith mar-thà initalized eileamaidean nach bi a 'tuiteam.
    ///
    /// Ma `T` innealan `Copy`, cleachdadh [`write_slice`]
    ///
    /// Tha seo coltach ri [`slice::clone_from_slice`] ach chan eil e a `leigeil às na h-eileamaidean a th` ann.
    ///
    /// # Panics
    ///
    /// A 'ghnìomh seo bidh an dà panic ma sliseagan bheil faid eadar-dhealaichte, no ma' cur an gnìomh `Clone` panics.
    ///
    /// Ma tha panic, an t-thà cloned eileamaidean thèid a thuit.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // Sàbhailteachd: tha sinn dìreach air cloned h-uile eileamaid de Len a-steach an comas a bharrachd
    /// // tha a `chiad eileamaidean src.len() den vec dligheach a-nis.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // eu-coltach ri copy_from_slice chan eil seo a `gairm clone_from_slice air an t-slice tha seo air sgàth nach eil `MaybeUninit<T: Clone>` a` buileachadh Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // Sàbhailteachd: a seo amh sliseag bi ach thòiseachadh nithean
                // air an adhbhar sin, tha e ceadaichte do leig e.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Feumaidh sinn follaiseach sliseadh iad gus an aon fhaid
        // airson crìochan a 'sgrùdadh a bhith air a elided, agus bidh optimizer ghineadh memcpy airson cùisean sìmplidh (mar eisimpleir T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // tha feum air freiceadan Dh `fhaodadh b/c panic tachairt aig àm clone
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // Sàbhailteachd: Dligheach eileamaidean a tha dìreach air a bhith a 'sgrìobhadh a-steach `this` mar sin a tha e initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}