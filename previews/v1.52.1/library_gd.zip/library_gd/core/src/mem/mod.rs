//! Gnìomhan bunaiteach airson dèiligeadh ri cuimhne.
//!
//! Tha am modal seo tha gnìomhan airson querying meud agus co-thaobhadh de sheòrsaichean, initializing agus a 'gluasad cuimhne.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// A `gabhail seilbh agus "forgets" mun luach **gun a bhith a` ruith a destructor**.
///
/// Goireasan sam bith air an luach a 'stiùireadh, leithid chàrn cuimhne no faidhle a làmh, bidh milis gu bràth ann an unreachable stàite.Ach, chan eil e a `gealltainn gum bi comharran airson a` chuimhne seo dligheach.
///
/// * Ma tha thu airson aoidion memory, faic [`Box::leak`].
/// * Ma tha thu airson comharradh amh fhaighinn don chuimhne, faic [`Box::into_raw`].
/// * Ma tha thu airson cur às de luach ceart, a 'ruith a destructor, faic [`mem::drop`].
///
/// # Safety
///
/// `forget` chan eil e air a chomharrachadh mar `unsafe`, oir chan eil geallaidhean sàbhailteachd Rust a `toirt a-steach gealltanas gum bi luchd-sgrios a` ruith an-còmhnaidh.
/// Mar eisimpleir, faodaidh prògram cearcall iomraidh a chruthachadh a `cleachdadh [`Rc`][rc], no cuir fòn gu [`process::exit`][exit] gus fàgail gun a bhith a` ruith innealan-sgrios.
/// Mar sin, a 'leigeil `mem::forget` bho sàbhailte code Chan eil bunaiteach atharrachadh Rust sàbhailteachd urras.
///
/// Sin a ràdh, ag aodion goireasan mar chuimhneachan no I/O rudan as trice tha mì-chàilear.
/// Tha an fheum a `tighinn suas ann an cuid de chùisean cleachdaidh sònraichte airson FFI no còd neo-shàbhailte, ach eadhon an uairsin, is fheàrr le [`ManuallyDrop`] mar as trice.
///
/// Leis gu bheil thu a `dìochuimhneachadh luach, feumaidh còd `unsafe` sam bith a sgrìobhas tu cead a thoirt don chomas seo.Chan urrainn dhut a thilleadh luach agus an dùil gum bi an neach-conaltraidh a bhios an-còmhnaidh a 'ruith air an luach a destructor.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Is e cleachdadh sàbhailte canonical `mem::forget` a bhith a `dol timcheall air inneal-sgrios luach a chaidh a chuir an gnìomh leis an `Drop` trait.Mar eisimpleir, bidh seo ag aoidion a `File`, ie
/// fhaighinn air ais an àite a ghabhail le na caochlaideach ach cha faisg air a 'bhun-siostam goireas:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Tha seo feumail, nuair a tha an sealbh an cùl Chaidh an goireas roimhe ghluasad gu code taobh a-muigh Rust, mar eisimpleir le bhith a 'toirt a' amh faidhl tuairisgeul gu C còd.
///
/// # Dàimh le `ManuallyDrop`
///
/// Ged a dh `fhaodar `mem::forget` a chleachdadh cuideachd gus seilbh *cuimhne* a ghluasad, tha sin buailteach do mhearachd.
/// [`ManuallyDrop`] bu chòir a chleachdadh na àite.Beachdaich air, mar eisimpleir, an còd seo:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Tog `String` bhith a 'cleachdadh na `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // aoidion `v` oir a tha a chuimhne a-nis air a stiùireadh le `s`
/// mem::forget(v);  // Mearachd, v neo-dhligheach agus chan fhaodar a thoirt seachad don obair
/// assert_eq!(s, "Az");
/// // `s` Tha e a-dhìreach a 'tuiteam agus a memory deallocated.
/// ```
///
/// Tha dà cùisean leis na h-àrd mar eisimpleir:
///
/// * Nam biodh barrachd còd air a chur ris eadar togail `String` agus ionnsaigh `mem::forget()`, bhiodh panic taobh a-staigh ag adhbhrachadh saor an-asgaidh oir tha an aon chuimhne air a làimhseachadh leis an dà chuid `v` agus `s`.
/// * An dèidh dha `v.as_mut_ptr()` a ghairm agus seilbh an dàta a chuir air adhart gu `s`, tha luach `v` neo-dhligheach.
/// Fiù 's nuair a luach a tha dìreach air gluasad gu `mem::forget` (a bhios cha sgrùd e), cuid de sheòrsaichean teann aig na riatanasan air an luachan a tha gan dèanamh mì-dhligheach nuair crochte no nach eil sealbh.
/// Tha a bhith a `cleachdadh luachan neo-dhligheach ann an dòigh sam bith, a` toirt a-steach a bhith gan toirt air ais no gan toirt air ais bho ghnìomhan, a `dèanamh suas giùlan neo-mhìnichte agus faodaidh e na barailean a rinn an trusaiche a bhriseadh.
///
/// Bidh atharrachadh gu `ManuallyDrop` a `seachnadh an dà chùis:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Mus do rinn sinn disassemble `v` a-steach pàirtean amh, dèan cinnteach nach eil ea 'faighinn a' tuiteam!
/////
/// let mut v = ManuallyDrop::new(v);
/// // A-nis disassemble `v`.Obair sin chan urrainn panic, mar sin chan urrainn a bhith aodion a stad.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Mu dheireadh, tog `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` Tha e a-dhìreach a 'tuiteam agus a memory deallocated.
/// ```
///
/// `ManuallyDrop` gu làidir a `cur casg air saor-dùbailte oir bidh sinn a` dì-chomasachadh inneal-sgrios `v` mus dèan sinn dad sam bith eile.
/// `mem::forget()` cha leig seo leis gu bheil e ag ithe na h-argamaid aige, a `toirt oirnn a bhith ga ghairm dìreach às deidh dhuinn rud sam bith a tha a dhìth oirnn a thoirt a-mach à `v`.
/// Fiù `s nan deidheadh panic a thoirt a-steach eadar togail `ManuallyDrop` agus togail an sreang (nach urrainn tachairt anns a` chòd mar a tha air a shealltainn), bheireadh sin a-mach aodion agus chan e dùbailte an-asgaidh.
/// Ann am faclan eile, tha `ManuallyDrop` a `mearachd air taobh a bhith ag aodion an àite a bhith a` mearachdachadh air taobh tuiteam (dùbailte-).
///
/// Cuideachd, tha `ManuallyDrop` a `cur casg oirnn bho bhith a` feumachdainn "touch" `v` às deidh dhuinn an seilbh a ghluasad gu `s`-tha an ceum mu dheireadh de bhith ag eadar-obrachadh le `v` gus faighinn cuidhteas e gun a bhith a `ruith a destructor air a sheachnadh gu tur.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Coltach ri [`forget`], ach cuideachd a `gabhail ri luachan gun tomhas.
///
/// Tha an gnìomh seo dìreach mar shim a thathar an dùil a thoirt air falbh nuair a thèid am feart `unsized_locals` a dhèanamh seasmhach.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// A `tilleadh meud seòrsa ann am bytes.
///
/// Gu sònraichte, is e seo an cothromachadh ann am bytes eadar eileamaidean leantainneach ann an sreath leis an t-seòrsa rud sin a `toirt a-steach pleadhachadh co-thaobhadh.
///
/// Mar sin, airson seòrsa `T` sam bith agus fad `n`, tha meud `n * size_of::<T>()` aig `[T; n]`.
///
/// San fharsaingeachd, chan eil meud seòrsa seasmhach thar cruinneachaidhean, ach tha seòrsan sònraichte leithid prìomhairean.
///
/// Tha an clàr a leanas a `toirt seachad meud airson prìomhairean.
///
/// Seòrsa |meud_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// A bharrachd air an sin, tha an aon mheud aig `usize` agus `isize`.
///
/// Tha na seòrsaichean `*const T`, `&T`, `Box<T>`, `Option<&T>`, agus `Option<Box<T>>` uile den aon mheud.
/// Ma tha `T` air a mheudachadh, tha na meudan sin uile aig an aon mheud ri `usize`.
///
/// Chan eil an comasachd puing ag atharrachadh a mheud.Mar sin, tha an aon mheud aig `&T` agus `&mut T`.
/// Mar an ceudna airson `*const T` agus `* mut T`.
///
/// # Meud nithean `#[repr(C)]`
///
/// Tha cruth sònraichte aig an riochdachadh `C` airson nithean.
/// Leis an dealbhadh seo, tha meud nithean seasmhach cuideachd fhad `s a tha meud seasmhach aig gach raon.
///
/// ## Meud nan Structaran
///
/// Airson `structs`, tha am meud air a dhearbhadh leis an algorithm a leanas.
///
/// Airson gach raon san structar a chaidh òrdachadh le òrdugh dearbhaidh:
///
/// 1. Cuir meud an achaidh ris.
/// 2. Cuir suas am meud gnàthach chun an iomad as fhaisge air an ath raon [alignment].
///
/// Mu dheireadh, timcheall meud an structair chun an iomad as fhaisge den [alignment] aige.
/// Mar as trice is e co-thaobhadh an structair an co-thaobhadh as motha de na raointean aige;faodar seo atharrachadh le bhith a `cleachdadh `repr(align(N))`.
///
/// Eu-coltach ri `C`, chan eil structaran meud neoni air an cruinneachadh suas gu aon byte ann am meud.
///
/// ## Meud Enums
///
/// Tha enums nach eil a `giùlan dàta sam bith ach an neach leth-bhreith an aon mheud ri enums C air an àrd-ùrlar a tha iad air a chur ri chèile.
///
/// ## Meud nan Aonaidhean
///
/// Tha meud aonaidh meud an raoin as motha aige.
///
/// Eu-coltach ri `C`, chan eil aonaidhean de mheud neoni air an cruinneachadh suas gu aon bheart ann am meud.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Cuid de phrìomhairean
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Nithean arrays
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Co-ionannachd meud puing
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// A `cleachdadh `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Is e meud a `chiad raon 1, mar sin cuir 1 ris a` mheud.Is e meud 1.
/// // Tha an co-thaobhadh an dàrna achadh 2, cho Cuir 1 gu meud airson padding.Is e meud 2.
/// // Is e meud an dàrna raon 2, mar sin cuir 2 ris a `mheud.Is e meud 4.
/// // Tha co-thaobhadh an treas raon aig 1, mar sin cuir 0 ris a `mheud airson pleadhag.Is e meud 4.
/// // Tha meud an treas achadh 1, mar sin Cuir 1 gu meud.Meud 5.
/// // Mu dheireadh, is e 2 co-thaobhadh an structair (oir is e 2 an co-thaobhadh as motha am measg nan raointean aige), mar sin cuir 1 ris a `mheud airson pleadhag.
/// // Is e meud 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Bidh structaran Tuple a `leantainn na h-aon riaghailtean.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Cuimhnich gur reordering na h-achaidhean urrainn lughdaich meud.
/// // Faodaidh sinn an dà bheart pleadhaig a thoirt air falbh le bhith a `cur `third` ro `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Is e meud an aonaidh meud an raoin as motha.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// A `tilleadh meud an luach comharraichte gu bytes.
///
/// Mar as trice tha seo an aon rud ri `size_of::<T>()`.
/// Ach, nuair nach eil *meud statach aig `T`*, me, sliseag [`[T]`][slice] no [trait object], faodar `size_of_val` a chleachdadh gus am meud a tha aithnichte gu dinimigeach fhaighinn.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SÀBHAILTEACHD: Tha `val` na iomradh, mar sin tha e na chomharraiche amh dligheach
    unsafe { intrinsics::size_of_val(val) }
}

/// A `tilleadh meud an luach comharraichte gu bytes.
///
/// Mar as trice tha seo an aon rud ri `size_of::<T>()`.Ach, nuair nach eil *meud statach aig `T`*, me, sliseag [`[T]`][slice] no [trait object], faodar `size_of_val_raw` a chleachdadh gus am meud a tha aithnichte gu dinimigeach fhaighinn.
///
/// # Safety
///
/// Chan eil an gnìomh seo sàbhailte ach ma tha na cumhaichean a leanas ann:
///
/// - Mas e `T` `Sized`, tha an gnìomh seo an-còmhnaidh sàbhailte a ghairm.
/// - Ma tha an earball gun tomhas de `T`:
///     - a [slice], an uairsin feumaidh fad an earbaill sliseag a bhith na integer tòiseachaidh, agus feumaidh meud an *luach iomlan*(fad earball fiùghantach + ro-leasachan meud statach) a bhith iomchaidh ann an `isize`.
///     - a [trait object], an uairsin feumaidh am pàirt so-ruigsinneach den phuing a bhith a `comharrachadh so-dhligheach dligheach a fhuair co-èigneachadh mì-chàilear, agus feumaidh meud an *luach iomlan*(fad earball fiùghantach + ro-leasachan meud statach) a bhith iomchaidh ann an `isize`.
///
///     - an (unstable) [extern type], an uairsin tha an gnìomh seo an-còmhnaidh sàbhailte a ghairm, ach faodaidh panic no an luach ceàrr a thilleadh air dhòigh eile, oir chan eil fios air cruth an t-seòrsa a-muigh.
///     Is e seo an aon ghiùlan ri [`size_of_val`] air iomradh air seòrsa le earball seòrsa taobh a-muigh.
///     - air dhòigh eile, chan eil e ceadaichte dha an gnìomh seo a ghairm.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh comharra amh dligheach a thoirt seachad
    unsafe { intrinsics::size_of_val(val) }
}

/// A `tilleadh an co-thaobhadh as ìsle de sheòrsa [ABI].
///
/// Feumaidh a h-uile iomradh air luach den t-seòrsa `T` a bhith ioma-àireamh den àireamh seo.
///
/// Is e seo an co-thaobhadh a thathar a `cleachdadh airson raointean structair.Is dòcha gum bi e nas lugha na an co-thaobhadh as fheàrr leat.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// A `tilleadh an co-thaobhadh as ìsle a tha a dhìth [ABI] den t-seòrsa luach a tha `val` a` comharrachadh.
///
/// Feumaidh a h-uile iomradh air luach den t-seòrsa `T` a bhith ioma-àireamh den àireamh seo.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SÀBHAILTEACHD: tha val na iomradh, mar sin tha e na chomharraiche amh dligheach
    unsafe { intrinsics::min_align_of_val(val) }
}

/// A `tilleadh an co-thaobhadh as ìsle de sheòrsa [ABI].
///
/// Feumaidh a h-uile iomradh air luach den t-seòrsa `T` a bhith ioma-àireamh den àireamh seo.
///
/// Is e seo an co-thaobhadh a thathar a `cleachdadh airson raointean structair.Is dòcha gum bi e nas lugha na an co-thaobhadh as fheàrr leat.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// A `tilleadh an co-thaobhadh as ìsle a tha a dhìth [ABI] den t-seòrsa luach a tha `val` a` comharrachadh.
///
/// Feumaidh a h-uile iomradh air luach den t-seòrsa `T` a bhith ioma-àireamh den àireamh seo.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SÀBHAILTEACHD: tha val na iomradh, mar sin tha e na chomharraiche amh dligheach
    unsafe { intrinsics::min_align_of_val(val) }
}

/// A `tilleadh an co-thaobhadh as ìsle a tha a dhìth [ABI] den t-seòrsa luach a tha `val` a` comharrachadh.
///
/// Feumaidh a h-uile iomradh air luach den t-seòrsa `T` a bhith ioma-àireamh den àireamh seo.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Chan eil an gnìomh seo sàbhailte ach ma tha na cumhaichean a leanas ann:
///
/// - Mas e `T` `Sized`, tha an gnìomh seo an-còmhnaidh sàbhailte a ghairm.
/// - Ma tha an earball gun tomhas de `T`:
///     - a [slice], an uairsin feumaidh fad an earbaill sliseag a bhith na integer tòiseachaidh, agus feumaidh meud an *luach iomlan*(fad earball fiùghantach + ro-leasachan meud statach) a bhith iomchaidh ann an `isize`.
///     - a [trait object], an uairsin feumaidh am pàirt so-ruigsinneach den phuing a bhith a `comharrachadh so-dhligheach dligheach a fhuair co-èigneachadh mì-chàilear, agus feumaidh meud an *luach iomlan*(fad earball fiùghantach + ro-leasachan meud statach) a bhith iomchaidh ann an `isize`.
///
///     - an (unstable) [extern type], an uairsin tha an gnìomh seo an-còmhnaidh sàbhailte a ghairm, ach faodaidh panic no an luach ceàrr a thilleadh air dhòigh eile, oir chan eil fios air cruth an t-seòrsa a-muigh.
///     Is e seo an aon ghiùlan ri [`align_of_val`] air iomradh air seòrsa le earball seòrsa taobh a-muigh.
///     - air dhòigh eile, chan eil e ceadaichte dha an gnìomh seo a ghairm.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh comharra amh dligheach a thoirt seachad
    unsafe { intrinsics::min_align_of_val(val) }
}

/// A `tilleadh `true` ma tha lughdachadh luachan de sheòrsa `T` cudromach.
///
/// Chan eil an seo ach moladh optimization, agus faodar a chuir an gnìomh gu glèidhteachail:
/// faodaidh e `true` a thilleadh airson seòrsachan nach fheumar an leigeil seachad.
/// Mar sin an-còmhnaidh bhiodh tilleadh `true` na bhuileachadh dligheach den ghnìomh seo.Ach ma tha an gnìomh seo a `tilleadh `false` gu dearbh, faodaidh tu a bhith cinnteach nach eil droch bhuaidh sam bith aig tuiteam `T`.
///
/// Bu chòir buileachadh ìre ìosal de rudan mar chruinneachaidhean, a dh `fheumas an dàta aca a leigeil seachad le làimh, an gnìomh seo a chleachdadh gus nach bi iad a` feuchainn ris na tha annta a leigeil seachad nuair a thèid an sgrios.
///
/// Is dòcha nach dèan seo eadar-dhealachadh ann an togail fuasglaidh (far a bheil lùb aig nach eil frith-bhuaidhean furasta a lorg agus air a chuir às), ach gu tric tha e na bhuannachadh mòr airson togail deasbaid.
///
/// Thoir fa-near gu bheil [`drop_in_place`] mu thràth a `dèanamh an sgrùdaidh seo, mar sin ma dh` fhaodar an t-uallach obrach agad a lughdachadh gu cuid de ghlaodhan [`drop_in_place`], chan eil feum air seo.
/// Thoir fa-near gu sònraichte gun urrainn dhut [`drop_in_place`] sliseag a dhèanamh, agus nì sin aon sgrùdadh need_drop airson na luachan uile.
///
/// Seòrsan mar Vec mar sin dìreach `drop_in_place(&mut self[..])` gun a bhith a `cleachdadh `needs_drop` gu follaiseach.
/// Feumaidh seòrsaichean mar [`HashMap`], air an làimh eile, luachan a leigeil sìos aon aig aon àm agus bu chòir dhaibh an API seo a chleachdadh.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Seo eisimpleir de mar a dh `fhaodadh cruinneachadh feum a dhèanamh de `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // leig às an dàta
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// A `tilleadh luach seòrsa `T` air a riochdachadh leis a` phàtran byte uile-neoni.
///
/// Tha seo a `ciallachadh, mar eisimpleir, nach eil am bata pleadhaig ann an `(u8, u16)` riatanach gu neoni.
///
/// Chan eil gealladh sam bith ann gu bheil pàtran byte uile-neoni a `riochdachadh luach dligheach de chuid de sheòrsa `T`.
/// Mar eisimpleir, chan eil am pàtran byte uile-neoni mar luach dligheach airson seòrsachan iomraidh (`&T`, `&mut T`) agus molaidhean gnìomhan.
/// Tha a bhith a `cleachdadh `zeroed` air an leithid de sheòrsan ag adhbhrachadh [undefined behavior][ub] sa bhad oir [the Rust compiler assumes][inv] gu bheil luach dligheach ann an caochladair a tha e a` meas a chaidh a thòiseachadh.
///
///
/// Tha an aon bhuaidh aig seo ri [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Tha e feumail airson FFI uaireannan, ach sa chumantas bu chòir a sheachnadh.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Cleachdadh ceart air a `ghnìomh seo: a` tòiseachadh integer le neoni.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Cleachdadh ceàrr* den ghnìomh seo: a `tòiseachadh iomradh le neoni.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Giùlan neo-mhìnichte!
/// let _y: fn() = unsafe { mem::zeroed() }; // Agus a-rithist!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gu bheil luach uile-neoni dligheach airson `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// A `dol seachad air sgrùdaidhean tòiseachaidh-cuimhne àbhaisteach Rust le bhith a` leigeil orra luach de sheòrsa `T` a thoirt gu buil, fhad `s nach dèan iad dad idir.
///
/// **Chan eil an gnìomh seo air a mholadh.** Cleachd [`MaybeUninit<T>`] na àite.
///
/// Is e an adhbhar airson ìsleachadh nach urrainnear an gnìomh a chleachdadh gu ceart: tha an aon bhuaidh aige ri [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Mar a tha an [`assume_init` documentation][assume_init] a `mìneachadh, [the Rust compiler assumes][inv] gu bheil luachan air an tòiseachadh gu ceart.
/// Mar thoradh air an sin, a `gairm me
/// `mem::uninitialized::<bool>()` ag adhbhrachadh giùlan neo-mhìnichte sa bhad airson `bool` a thilleadh nach eil gu cinnteach an dàrna cuid `true` no `false`.
/// Tha cuimhne nas miosa, dha-rìribh neo-aithnichte mar a gheibh thu air ais an seo sònraichte leis gu bheil fios aig an neach-cruinneachaidh nach eil luach stèidhichte aige.
/// Tha seo ga dhèanamh na ghiùlan neo-mhìnichte gu bheil dàta neo-aithnichte ann an caochladair eadhon ged a tha seòrsa integer aig an caochladair sin.
/// (Fios gu bheil na riaghailtean mu thimcheall uninitialized integers nach eil a chrìochnachadh fhathast, ach gus am bi iad, tha e glic dhaibh a sheachnadh.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gu bheil luach aonadach dligheach airson `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Ag atharrachadh na luachan aig dà àite gluasadach, gun a bhith a `dì-mheadhanachadh aon seach aon.
///
/// * Ma tha thu airson suaip le luach bunaiteach no dummy, faic [`take`].
/// * Ma tha thu airson suaip le luach a chaidh seachad, a `tilleadh an t-seann luach, faic [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SÀBHAILTEACHD: chaidh na comharran amh a chruthachadh bho iomraidhean sàbhailte mutable a `sàsachadh a h-uile càil
    // cuingealachaidhean air `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// A `dol an àite `dest` leis an luach bunaiteach de `T`, a` tilleadh an luach `dest` a bh `ann roimhe.
///
/// * Ma tha thu airson luachan dà chaochladair a chur an àite, faic [`swap`].
/// * Ma tha thu airson luach a chaidh seachad a chuir na àite an àite an luach bunaiteach, faic [`replace`].
///
/// # Examples
///
/// Eisimpleir sìmplidh:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` a `ceadachadh seilbh a ghabhail air raon structair le bhith a` cur luach "empty" na àite.
/// Às aonais `take` faodaidh tu ruith a-steach do chùisean mar seo:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Thoir fa-near nach eil `T` gu riatanach a `buileachadh [`Clone`], mar sin chan urrainn dha eadhon cloneadh agus ath-shuidheachadh `self.buf`.
/// Ach faodar `take` a chleachdadh gus luach tùsail `self.buf` a sgaradh bho `self`, a `leigeil leis a thilleadh:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Gluais `src` a-steach don `dest` air a bheil iomradh, a `tilleadh an luach `dest` a bh` ann roimhe.
///
/// Chan eilear a `lughdachadh luach.
///
/// * Ma tha thu airson luachan dà chaochladair a chur an àite, faic [`swap`].
/// * Ma tha thu airson luach bunaiteach a chuir na àite, faic [`take`].
///
/// # Examples
///
/// Eisimpleir sìmplidh:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` a `ceadachadh raon structair a chaitheamh le bhith a` cur luach eile na àite.
/// Às aonais `replace` faodaidh tu ruith a-steach do chùisean mar seo:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Thoir fa-near nach eil `T` gu riatanach a `buileachadh [`Clone`], agus mar sin chan urrainn dhuinn eadhon clonadh `self.buf[i]` gus an gluasad a sheachnadh.
/// Ach faodar `replace` a chleachdadh gus an luach tùsail aig a `chlàr-amais sin a sgaradh bho `self`, a` leigeil leis a thilleadh:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SÀBHAILTEACHD: Leugh sinn bho `dest` ach sgrìobh sinn `src` gu dìreach a-steach às deidh sin,
    // gus nach bi an seann luach air a dhùblachadh.
    // Chan eil dad air a leigeil seachad agus chan urrainn dad an seo panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// A `faighinn cuidhteas luach.
///
/// Bidh seo a `dèanamh le bhith a` gairm buileachadh na h-argamaid air [`Drop`][drop].
///
/// Chan eil seo gu h-èifeachdach a `dèanamh dad airson seòrsachan a tha a` buileachadh `Copy`, me
/// integers.
/// Thathas a `dèanamh lethbhreac de luachan mar sin agus _then_ air a ghluasad a-steach don ghnìomh, agus mar sin tha an luach a` leantainn às deidh a `ghairm gnìomh seo.
///
///
/// Chan eil an gnìomh seo draoidheil;tha e air a mhìneachadh gu litireil mar
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Leis gu bheil `_x` air a ghluasad a-steach don ghnìomh, thèid a leigeil sìos gu fèin-ghluasadach mus till an gnìomh.
///
/// [drop]: Drop
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // leig às an vector gu follaiseach
/// ```
///
/// Leis gu bheil [`RefCell`] a `cur an gnìomh riaghailtean iasaid aig àm-ruith, faodaidh `drop` iasad [`RefCell`] a leigeil ma sgaoil:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // mutable 'leigeil seachad an iasaid air seo sliotan
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Chan eil buaidh aig `drop` air integers agus seòrsachan eile a tha a `buileachadh [`Copy`].
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // lethbhreac de `x` a ghluasad agus thuit
/// drop(y); // tha leth-bhreac de `y` air a ghluasad agus air a leigeil sìos
///
/// println!("x: {}, y: {}", x, y.0); // fhathast ri fhaighinn
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// A `mìneachadh `src` mar gum biodh seòrsa `&U` aige, agus an uairsin a` leughadh `src` gun a bhith a `gluasad an luach a tha na bhroinn.
///
/// Bidh an gnìomh seo a `gabhail ris gu mì-shàbhailte gu bheil am puing `src` dligheach airson bytes [`size_of::<U>`][size_of] le bhith a` tar-chuir `&T` gu `&U` agus an uairsin a `leughadh an `&U` (ach a-mhàin gu bheil seo air a dhèanamh ann an dòigh a tha ceart eadhon nuair a nì `&U` riatanasan co-thaobhadh nas cruaidhe na `&T`).
/// Cruthaichidh e cuideachd leth-bhreac den luach a tha na bhroinn an àite gluasad a-mach à `src`.
///
/// Chan e mearachd ùine-cruinneachaidh a th `ann ma tha meudan eadar-dhealaichte aig `T` agus `U`, ach tha e air a bhrosnachadh gu mòr a bhith a` toirt a-steach a `ghnìomh seo far a bheil `T` agus `U` den aon mheud.Bidh an gnìomh seo a`piobrachadh [undefined behavior][ub] ma tha `U` nas motha na `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Dèan lethbhreac den dàta bho 'foo_array' agus làimhsich e mar 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Atharraich an dàta a chaidh a chopaigeadh
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Tha susbaint na 'foo_array' Cha bu chòir a bhith air atharrachadh
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Ma tha riatanas co-thaobhadh nas àirde aig U, is dòcha nach bi src air a cho-thaobhadh gu h-iomchaidh.
    if align_of::<U>() > align_of::<T>() {
        // SÀBHAILTEACHD: Tha `src` na iomradh a tha cinnteach a bhith dligheach airson leughaidhean.
        // Feumaidh an neach-fòn gealltainn gu bheil an tar-ghluasad fhèin sàbhailte.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SÀBHAILTEACHD: Tha `src` na iomradh a tha cinnteach a bhith dligheach airson leughaidhean.
        // Rinn sinn dìreach sgrùdadh gu robh `src as *const U` air a cho-thaobhadh gu ceart.
        // Feumaidh an neach-fòn gealltainn gu bheil an tar-ghluasad fhèin sàbhailte.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Seòrsa neo-shoilleir a `riochdachadh leth-bhreith enum.
///
/// Faic an [`discriminant`] gnìomh ann am modal seo airson tuilleadh fiosrachaidh.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Chan urrainnear na buileachadh trait seo a thoirt a-mach oir chan eil sinn ag iarraidh crìochan sam bith air T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// A `tilleadh luach gun samhail a` comharrachadh an caochladh enum ann an `v`.
///
/// Mura h-e `T` a th `ann an enum, cha toir giùlan an gnìomh seo giùlan neo-mhìnichte, ach tha an luach toraidh neo-shònraichte.
///
///
/// # Stability
///
/// Faodaidh an neach a tha a `dèanamh eadar-dhealachadh de enum caochlaideach ma dh` atharraicheas mìneachadh enum.
/// Cha atharraich leth-bhreith de chuid de dh `eadar-dhealachadh eadar coimeasgaidhean leis an aon trusaiche.
///
/// # Examples
///
/// Faodar seo a chleachdadh gus coimeas a dhèanamh eadar enums a tha a `giùlan dàta, fhad` s a tha iad a `dèanamh dìmeas air an dàta fhèin:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// A `tilleadh an àireamh de dh` atharrachaidhean anns an t-seòrsa enum `T`.
///
/// Mura h-e `T` a th `ann an enum, cha toir giùlan an gnìomh seo giùlan neo-mhìnichte, ach tha an luach toraidh neo-shònraichte.
/// San aon dòigh, ma tha `T` na enum le barrachd atharrachaidhean na `usize::MAX` tha an luach toraidh neo-ainmichte.
/// Thèid atharrachaidhean neo-àitichte a chunntadh.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}