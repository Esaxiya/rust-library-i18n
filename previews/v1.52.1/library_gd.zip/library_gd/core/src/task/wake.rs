#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// Tha `RawWaker` a `leigeil le gnìomhaiche gnìomh gnìomh [`Waker`] a chruthachadh a bheir seachad giùlan dùsgadh àbhaisteach.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Tha e a 'gabhail a-steach dàta a chomharra agus a [virtual function pointer table (vtable)][vtable] a customizes giùlan an `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// A dàta chomharra, a dh'fhaodas a bhith air a chleachdadh gus dàta a stòradh neo mar a tha air iarraidh le neach-tiomnaidh.
    /// Dh `fhaodadh seo a bhith me
    /// comharraiche air a dhubhadh às gu `Arc` a tha co-cheangailte ris a `ghnìomh.
    /// Bidh luach an raoin seo a `faighinn seachad air a h-uile gnìomh a tha mar phàirt den vtable mar a` chiad paramadair.
    ///
    data: *const (),
    /// Clàr puing gnìomh brìgheil a bhios a `gnàthachadh giùlan an neach-glacaidh seo.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// A 'cruthachadh ùr `RawWaker` bho `data` chomharra a thoirt seachad agus `vtable`.
    ///
    /// Faodar an comharradh `data` a chleachdadh gus dàta rèiteachaidh a stòradh mar a dh `fheumas an neach-cùraim an tiomnaidh.Dh'fhaodadh seo a bhith me
    /// comharraiche air a dhubhadh às gu `Arc` a tha co-cheangailte ris a `ghnìomh.
    /// Thèid luach a `phuing seo a thoirt do gach gnìomh a tha mar phàirt den `vtable` mar a` chiad paramadair.
    ///
    /// Tha an `vtable` a `gnàthachadh giùlan `Waker` a thèid a chruthachadh bho `RawWaker`.
    /// Airson gach obrachadh air an `Waker`, canar an gnìomh co-cheangailte ris anns an `vtable` den `RawWaker` bunaiteach.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// A mas-fhìor chomharra gnìomh Clàr (vtable) a 'sònrachadh a' giùlan a [`RawWaker`].
///
/// Is e am puing a chaidh a thoirt don h-uile gnìomh taobh a-staigh an fhùirneis am puing `data` bhon nì [`RawWaker`] a tha a `cuairteachadh.
///
/// Chan eilear ag amas air na gnìomhan taobh a-staigh an structair seo a bhith air an gairm air comharradh `data` de nì [`RawWaker`] a chaidh a thogail gu ceart bhon taobh a-staigh de bhuileachadh [`RawWaker`].
/// Le bhith a `gairm aon de na gnìomhan a th` ann a `cleachdadh stiùireadh `data` sam bith eile bidh giùlan neo-mhìnichte ann.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Thèid an gnìomh seo a ghairm nuair a thèid an [`RawWaker`] a clònadh, me nuair a thèid an [`Waker`] anns a bheil an [`RawWaker`] a stòradh a `glaodh.
    ///
    /// Tha cur an gnìomh a 'ghnìomh seo, feumaidh a chumail a h-uile goireasan a tha a dhìth airson seo a bharrachd eisimpleir de [`RawWaker`] agus obair co-cheangailte riutha.
    /// Le bhith a `gairm `wake` air an [`RawWaker`] a thig às a sin bu chòir dùsgadh den aon ghnìomh a bhiodh air a dhùsgadh leis an [`RawWaker`] tùsail.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Canar an gnìomh seo nuair a thèid `wake` a ghairm air an [`Waker`].
    /// Feumaidh e an gnìomh co-cheangailte ris an [`RawWaker`] seo a dhùsgadh.
    ///
    /// Feumaidh buileachadh na gnìomh seo dèanamh cinnteach gun tèid goireasan sam bith co-cheangailte ris an eisimpleir seo de [`RawWaker`] agus gnìomh co-cheangailte ris a leigeil ma sgaoil.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// A 'ghnìomh seo bidh an t-ainm nuair a `wake_by_ref` a ghairm air an [`Waker`].
    /// Feumaidh e an gnìomh co-cheangailte ris an [`RawWaker`] seo a dhùsgadh.
    ///
    /// Tha seo a 'ghnìomh coltach ri `wake`, ach feumaidh nach loisgeadh an dàta chomharra a thoirt seachad.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Canar an gnìomh seo nuair a thèid [`RawWaker`] a leigeil sìos.
    ///
    /// Feumaidh buileachadh na gnìomh seo dèanamh cinnteach gun tèid goireasan sam bith co-cheangailte ris an eisimpleir seo de [`RawWaker`] agus gnìomh co-cheangailte ris a leigeil ma sgaoil.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// A `cruthachadh `RawWakerVTable` ùr bho na gnìomhan `clone`, `wake`, `wake_by_ref`, agus `drop` a chaidh a thoirt seachad.
    ///
    /// # `clone`
    ///
    /// Thèid an gnìomh seo a ghairm nuair a thèid an [`RawWaker`] a clònadh, me nuair a thèid an [`Waker`] anns a bheil an [`RawWaker`] a stòradh a `glaodh.
    ///
    /// Tha cur an gnìomh a 'ghnìomh seo, feumaidh a chumail a h-uile goireasan a tha a dhìth airson seo a bharrachd eisimpleir de [`RawWaker`] agus obair co-cheangailte riutha.
    /// Le bhith a `gairm `wake` air an [`RawWaker`] a thig às a sin bu chòir dùsgadh den aon ghnìomh a bhiodh air a dhùsgadh leis an [`RawWaker`] tùsail.
    ///
    /// # `wake`
    ///
    /// Canar an gnìomh seo nuair a thèid `wake` a ghairm air an [`Waker`].
    /// Feumaidh e an gnìomh co-cheangailte ris an [`RawWaker`] seo a dhùsgadh.
    ///
    /// Feumaidh buileachadh na gnìomh seo dèanamh cinnteach gun tèid goireasan sam bith co-cheangailte ris an eisimpleir seo de [`RawWaker`] agus gnìomh co-cheangailte ris a leigeil ma sgaoil.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// A 'ghnìomh seo bidh an t-ainm nuair a `wake_by_ref` a ghairm air an [`Waker`].
    /// Feumaidh e an gnìomh co-cheangailte ris an [`RawWaker`] seo a dhùsgadh.
    ///
    /// Tha seo a 'ghnìomh coltach ri `wake`, ach feumaidh nach loisgeadh an dàta chomharra a thoirt seachad.
    ///
    /// # `drop`
    ///
    /// Canar an gnìomh seo nuair a thèid [`RawWaker`] a leigeil sìos.
    ///
    /// Feumaidh buileachadh na gnìomh seo dèanamh cinnteach gun tèid goireasan sam bith co-cheangailte ris an eisimpleir seo de [`RawWaker`] agus gnìomh co-cheangailte ris a leigeil ma sgaoil.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// An `Context` de ghnìomh asyncronach.
///
/// An-dràsta, chan eil `Context` ach a `toirt cothrom air `&Waker` a dh` fhaodar a chleachdadh gus a `ghnìomh làithreach a dhùsgadh.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Dèan cinnteach gu bheil sinn future-proof an aghaidh atharrachaidhean caochlaideachd le bhith a `toirt air a` bheatha a bhith neo-fhoghainteach (tha amannan suidheachadh argamaid an aghaidh na h-ùine fhad `s a tha amannan suidheachaidh co-sheasmhach).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Cruthaich `Context` ùr bho `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// A `tilleadh iomradh air an `Waker` airson a` ghnìomh làithreach.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// A `Waker` 'S e cas airson dusgadh suas le dubhlan bho toirear a-tiomnaidh gu bheil e deiseil airson a bhith a' ruith.
///
/// Tha an làimhseachadh seo a `toirt a-steach eisimpleir [`RawWaker`], a tha a` mìneachadh giùlan caithris sònraichte an neach-tiomnaidh.
///
///
/// A `toirt buaidh air [`Clone`], [`Send`], agus [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Dùisg an gnìomh co-cheangailte ris an `Waker` seo.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Tha fìor wakeup gairm tha tiomnaichte tro virtual gairm gu gnìomh a chur an gnìomh a tha air a mhìneachadh le cùraim an tiomnaidh.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Na cuir fòn gu `drop`-thèid an waker a chaitheamh le `wake`.
        crate::mem::forget(self);

        // Sàbhailteachd: 'S e seo sàbhailte `Waker::from_raw` oir' se an aon dòigh
        // gus `wake` agus `data` a thòiseachadh ag iarraidh air an neach-cleachdaidh aideachadh gu bheil an cùmhnant `RawWaker` air a chumail suas.
        //
        unsafe { (wake)(data) };
    }

    /// Dùisg an gnìomh co-cheangailte ris an `Waker` seo gun a bhith ag ithe an `Waker`.
    ///
    /// Tha seo coltach ri `wake`, ach dh `fhaodadh gum bi e beagan nas lugha èifeachdach anns a` chùis far a bheil `Waker` seilbh ri fhaighinn.
    /// Bu chòir an dòigh seo a bhith nas fheàrr na bhith a `gairm `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Tha fìor wakeup gairm tha tiomnaichte tro virtual gairm gu gnìomh a chur an gnìomh a tha air a mhìneachadh le cùraim an tiomnaidh.
        //

        // SÀBHAILTEACHD: faic `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// A `tilleadh `true` ma tha an `Waker` seo agus `Waker` eile air an aon ghnìomh a dhùsgadh.
    ///
    /// Ghnìomh seo ag obair air an oidhirp as fheàrr a-stèidh, agus'sdòcha fiù' s nuair a thilleadh meallta an `Waker`s bhiodh dhùisg an aon obair.
    /// Ach, ma thilleas an gnìomh seo `true`, tha e cinnteach gun dùisg na `Waker 'an aon ghnìomh.
    ///
    /// Tha an gnìomh seo air a chleachdadh sa chiad àite airson adhbharan optimization.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// A `cruthachadh `Waker` ùr bho [`RawWaker`].
    ///
    /// Giùlan thill `Waker` undefined ma tha an cùmhnant a tha air a mhìneachadh ann an [`RawWaker`] 's is [`RawWakerVTable`]' s sgrìobhainnean nach eil an cumail suas.
    ///
    /// Uime sin an dòigh seo a tha sàbhailte.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // Sàbhailteachd: 'S e seo sàbhailte `Waker::from_raw` oir' se an aon dòigh
            // tòiseachadh `clone` agus `data` a dh'fheumas an neach-cleachdaidh ag aideachadh gu bheil an cùmhnant [`RawWaker`] Tha an cumail suas.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // Sàbhailteachd: 'S e seo sàbhailte `Waker::from_raw` oir' se an aon dòigh
        // gus `drop` agus `data` a thòiseachadh ag iarraidh air an neach-cleachdaidh aideachadh gu bheil an cùmhnant `RawWaker` air a chumail suas.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}