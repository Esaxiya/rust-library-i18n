macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// An luach as lugha as urrainn a riochdachadh leis an t-seòrsa integer seo.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// An luach as motha as urrainn a riochdachadh leis an t-seòrsa integer seo.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Tha meud an t-seòrsa integer seo ann am pìosan.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Bidh e ag atharrachadh sliseag sreang ann am bonn sònraichte gu integer.
        ///
        /// Tha dùil gum bi an sreang mar shoidhne roghainneil `+` air a leantainn le àireamhan.
        ///
        /// Tha àite-fànais luaidhe is slaodadh a `riochdachadh mearachd.
        /// Tha àireamhan nam fo-sheata de na caractaran sin, a rèir `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Tha an gnìomh seo panics mura h-eil `radix` anns an raon bho 2 gu 36.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// A `tilleadh an àireamh de fheadhainn anns an riochdachadh binary de `self`.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// A `tilleadh an àireamh de neoni ann an riochdachadh binary `self`.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// A `tilleadh an àireamh de phrìomh zeros ann an riochdachadh binary `self`.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// A `tilleadh an àireamh de neoni sgrìobach ann an riochdachadh binary `self`.
        ///
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// A `tilleadh an àireamh de phrìomh fheadhainn ann an riochdachadh binary `self`.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// A `tilleadh an àireamh de fheadhainn slaodadh ann an riochdachadh binary `self`.
        ///
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Gluais na buillean air an taobh chlì le sùim ainmichte, `n`, a `pasgadh na pìosan teasachaidh gu deireadh an t-integer a thig às.
        ///
        ///
        /// Thoir an aire nach e seo an aon obair ris a `ghnìomhaiche gluasad `<<`!
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Gluais na buillean air an taobh cheart le sùim ainmichte, `n`, a `pasgadh na pìosan teasairginn gu toiseach an t-sùim iomlan a thig às.
        ///
        ///
        /// Thoir an aire nach e seo an aon obair ris a `ghnìomhaiche gluasad `>>`!
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// A `tilleadh òrdugh byte an integer.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// leig m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// A `tilleadh òrdugh nam pìosan anns an integer.
        /// Bidh am pìos as lugha gu bhith na rud as cudromaiche, bidh an dàrna pìos as lugha a `fàs mar an dàrna pìos as cudromaiche, msaa.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// leig m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Bidh e ag atharrachadh integer bho endian mòr gu deireadh an targaid.
        ///
        /// Air endian mòr is e seo neo-op.
        /// Air beagan endian thèid na bytes atharrachadh.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ma tha cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } eile {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Bidh e ag atharrachadh integer bho beag endian gu deireadh an targaid.
        ///
        /// Air endian beag is e seo neo-op.
        /// Air endian mòr thèid na bytes atharrachadh.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ma tha cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } eile {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Bidh e ag atharrachadh `self` gu endian mòr bho sheasmhachd an targaid.
        ///
        /// Air endian mòr is e seo neo-op.
        /// Air beagan endian thèid na bytes atharrachadh.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ma tha cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } eile { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // no gun a bhith?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Bidh e ag atharrachadh `self` gu beag endian bho neo-sheasmhachd an targaid.
        ///
        /// Air endian beag is e seo neo-op.
        /// Air endian mòr thèid na bytes atharrachadh.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ma tha cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } eile { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Thoir sùil air cur-ris integer.
        /// Computes `self + rhs`, a `tilleadh `None` ma thachair cus.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Cuir ris integer neo-sgrùdaichte.Computes `self + rhs`, a `gabhail ris nach urrainn cus sruthadh tachairt.
        /// Bidh seo a `leantainn gu giùlan neo-mhìnichte cuin
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `unchecked_add` a chumail suas.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Rang integer toirt air falbh.
        /// Computes `self - rhs`, a `tilleadh `None` ma thachair cus.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Toirt air falbh neo-sgrùdaichte integer.Computes `self - rhs`, a `gabhail ris nach urrainn cus sruthadh tachairt.
        /// Bidh seo a `leantainn gu giùlan neo-mhìnichte cuin
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `unchecked_sub` a chumail suas.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Sgrùdadh air iomadachadh integer.
        /// Computes `self * rhs`, a `tilleadh `None` ma thachair cus.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Iomadachadh integer neo-sgrùdaichte.Computes `self * rhs`, a `gabhail ris nach urrainn cus sruthadh tachairt.
        /// Bidh seo a `leantainn gu giùlan neo-mhìnichte cuin
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `unchecked_mul` a chumail suas.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Sgrùdadh air sgrùdadh integer.
        /// Computes `self / rhs`, a `tilleadh `None` ma tha `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SÀBHAILTEACHD: chaidh div le neoni a sgrùdadh gu h-àrd agus chan eil gin eile gun ainm
                // modhan fàilligeadh airson roinneadh
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Sgrùdadh air roinn Euclidean.
        /// A `dèanamh coimeas eadar `self.div_euclid(rhs)`, a` tilleadh `None` ma tha `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Dèan sgrùdadh air fuigheall integer.
        /// A `dèanamh coimeas eadar `self % rhs`, a` tilleadh `None` ma tha `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SÀBHAILTEACHD: chaidh div le neoni a sgrùdadh gu h-àrd agus chan eil gin eile gun ainm
                // modhan fàilligeadh airson roinneadh
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Sgrùdadh modulo Euclidean.
        /// A `dèanamh coimeas eadar `self.rem_euclid(rhs)`, a` tilleadh `None` ma tha `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Thoir sùil air dearmad.A `dèanamh coimeas eadar `-self`, a` tilleadh `None` mura h-eil `fèin==
        /// 0`.
        ///
        /// Thoir fa-near gum bi dearmad air integer adhartach sam bith a `dol thairis.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Gluasad seic air fhàgail.
        /// A `dèanamh coimeas eadar `self << rhs`, a` tilleadh `None` ma tha `rhs` nas motha na no co-ionann ris an àireamh de bhuillean ann an `self`.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Sgrùdadh gluasad ceart.
        /// A `dèanamh coimeas eadar `self >> rhs`, a` tilleadh `None` ma tha `rhs` nas motha na no co-ionann ris an àireamh de bhuillean ann an `self`.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Sgrùdadh exponentiation.
        /// Computes `self.pow(exp)`, a `tilleadh `None` ma thachair cus.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // bho exp!=0, mu dheireadh feumaidh an exp a bhith 1.
            // Dèilig ris a `phàirt mu dheireadh den neach-nochdaidh air leth, oir chan eil feum air a bhith a` sgùradh a `bhunait às deidh sin agus dh` fhaodadh e cus sruthadh gun fheum.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Saturating integer cuir ris.
        /// A `dèanamh coimeas eadar `self + rhs`, a` sùghadh aig na crìochan àireamhach an àite a bhith a `cur thairis.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Toirt air falbh integer integer.
        /// A `dèanamh coimeas eadar `self - rhs`, a` sùghadh aig na crìochan àireamhach an àite a bhith a `cur thairis.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Iomadachadh integer shàthaichte.
        /// A `dèanamh coimeas eadar `self * rhs`, a` sùghadh aig na crìochan àireamhach an àite a bhith a `cur thairis.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Saturating integer exponentiation.
        /// A `dèanamh coimeas eadar `self.pow(exp)`, a` sùghadh aig na crìochan àireamhach an àite a bhith a `cur thairis.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// A `cuairteachadh cur-ris (modular).
        /// Computes `self + rhs`, a `pasgadh timcheall aig crìoch an t-seòrsa.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// A `cuairteachadh toirt air falbh (modular).
        /// Computes `self - rhs`, a `pasgadh timcheall aig crìoch an t-seòrsa.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// A `cuairteachadh iomadachadh (modular).
        /// Computes `self * rhs`, a `pasgadh timcheall aig crìoch an t-seòrsa.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// Thoir fa-near gu bheil an eisimpleir seo air a roinn eadar seòrsachan integer.
        /// A tha a `mìneachadh carson a thathas a` cleachdadh `u8` an seo.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// A `cuairteachadh roinn (modular).Computes `self / rhs`.
        /// Is e dìreach roinn àbhaisteach a th `ann an sgaradh fillte air seòrsachan gun ainm.
        /// Chan eil dòigh sam bith ann gum faodadh pasgadh tachairt.
        /// Tha an gnìomh seo ann, gus am bi cunntas air a h-uile gnìomhachd anns na h-obraichean fillte.
        ///
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// A `cuairteachadh roinn Euclidean.Computes `self.div_euclid(rhs)`.
        /// Is e dìreach roinn àbhaisteach a th `ann an sgaradh fillte air seòrsachan gun ainm.
        /// Chan eil dòigh sam bith ann gum faodadh pasgadh tachairt.
        /// Tha an gnìomh seo ann, gus am bi cunntas air a h-uile gnìomhachd anns na h-obraichean fillte.
        /// Bho, airson na integers adhartach, tha a h-uile mìneachadh coitcheann de roinn co-ionann, tha seo dìreach co-ionann ri `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// A `cuairteachadh fuigheall (modular).Computes `self % rhs`.
        /// Is e dìreach an àireamhachadh ath-fhilleadh air seòrsachan neo-ainmichte dìreach an ath-thomhas cunbhalach.
        ///
        /// Chan eil dòigh sam bith ann gum faodadh pasgadh tachairt.
        /// Tha an gnìomh seo ann, gus am bi cunntas air a h-uile gnìomhachd anns na h-obraichean fillte.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// A `cuairteachadh modulo Euclidean.Computes `self.rem_euclid(rhs)`.
        /// Is e dìreach an àireamhachadh ath-fhilleadh cunbhalach a th `ann an àireamhachadh modulo fillte air seòrsachan gun ainm.
        /// Chan eil dòigh sam bith ann gum faodadh pasgadh tachairt.
        /// Tha an gnìomh seo ann, gus am bi cunntas air a h-uile gnìomhachd anns na h-obraichean fillte.
        /// Bho, airson na integers adhartach, tha a h-uile mìneachadh coitcheann de roinn co-ionann, tha seo dìreach co-ionann ri `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// A `cuairteachadh dearmad (modular).
        /// Computes `-self`, a `pasgadh timcheall aig crìoch an t-seòrsa.
        ///
        /// Leis nach eil co-ionnanachdan àicheil aig seòrsaichean gun ainm, bidh gach tagradh den ghnìomh seo a `fighe (ach a-mhàin `-0`).
        /// Airson luachan nas lugha na an ìre as àirde de sheòrsa ainmichte tha an toradh co-ionann ri bhith a `tilgeil an luach ainmichte co-fhreagarrach.
        ///
        /// Tha luachan nas motha co-ionann ri `MAX + 1 - (val - MAX - 1)` far a bheil `MAX` mar an ìre as àirde a tha ainmichte.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// Thoir fa-near gu bheil an eisimpleir seo air a roinn eadar seòrsachan integer.
        /// A tha a `mìneachadh carson a thathas a` cleachdadh `i8` an seo.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-saor bitwise shift-chlì;
        /// a `toirt a-mach `self << mask(rhs)`, far am bi `mask` a` toirt air falbh pìosan àrd-òrdugh de `rhs` a bheireadh air a `ghluasad a bhith nas àirde na leud an t-seòrsa.
        ///
        /// Thoir fa-near nach eil seo * co-ionann ri taobh clì rothlach;tha an RHS de ghluasad-clì fillte air a chuingealachadh ris an raon den t-seòrsa, seach na pìosan a chaidh a ghluasad a-mach às an LHS a thilleadh chun cheann eile.
        /// Bidh na seòrsachan integer prìomhach uile a `buileachadh gnìomh [`rotate_left`](Self::rotate_left), is dòcha gur e sin a tha thu ag iarraidh na àite.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SÀBHAILTEACHD: tha an fasgachadh leis an t-seòrsa bitsize a `dèanamh cinnteach nach gluais sinn
            // a-mach à crìochan
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-free bitwise shift-right;
        /// a `toirt a-mach `self >> mask(rhs)`, far am bi `mask` a` toirt air falbh pìosan àrd-òrdugh de `rhs` a bheireadh air a `ghluasad a bhith nas àirde na leud an t-seòrsa.
        ///
        /// Thoir fa-near nach e seo * an aon rud ri taobh rothlach;tha an RHS de ghluasad-deas fillte air a chuingealachadh ris an raon den t-seòrsa, seach na pìosan a chaidh a ghluasad a-mach às an LHS a thilleadh chun cheann eile.
        /// Bidh na seòrsachan integer prìomhach uile a `buileachadh gnìomh [`rotate_right`](Self::rotate_right), is dòcha gur e sin a tha thu ag iarraidh na àite.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SÀBHAILTEACHD: tha an fasgachadh leis an t-seòrsa bitsize a `dèanamh cinnteach nach gluais sinn
            // a-mach à crìochan
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// A `cuairteachadh (modular) exponentiation.
        /// Computes `self.pow(exp)`, a `pasgadh timcheall aig crìoch an t-seòrsa.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // bho exp!=0, mu dheireadh feumaidh an exp a bhith 1.
            // Dèilig ris a `phàirt mu dheireadh den neach-nochdaidh air leth, oir chan eil feum air a bhith a` sgùradh a `bhunait às deidh sin agus dh` fhaodadh e cus sruthadh gun fheum.
            //
            //
            acc.wrapping_mul(base)
        }

        /// A `tomhas `self` + `rhs`
        ///
        /// A `tilleadh tiùb den chur-ris còmhla ri boolean a` sealltainn an tachradh thar-shruth àireamhachd.
        /// Nam biodh tar-sruthadh air tachairt tha an luach fillte air a thilleadh.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// A `tomhas `self`, `rhs`
        ///
        /// A `tilleadh tiùb den toirt air falbh còmhla ri boolean a` nochdadh an tachradh thar-shruth àireamhachd.
        /// Nam biodh tar-sruthadh air tachairt tha an luach fillte air a thilleadh.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// A `tomhas iomadachadh `self` agus `rhs`.
        ///
        /// A `tilleadh tiùb den iomadachadh còmhla ri boolean a` sealltainn an tachradh thar-shruth àireamhachd.
        /// Nam biodh tar-sruthadh air tachairt tha an luach fillte air a thilleadh.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// Thoir fa-near gu bheil an eisimpleir seo air a roinn eadar seòrsachan integer.
        /// A tha a `mìneachadh carson a thathas a` cleachdadh `u32` an seo.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Obraich a-mach an roinniche nuair a tha `self` air a roinn le `rhs`.
        ///
        /// A `tilleadh tiùb den roinniche còmhla ri boolean a` sealltainn an tachradh thar-shruth àireamhachd.
        /// Thoir fa-near nach tachair thar-shruth integers gun ainm a-riamh, agus mar sin is e an dàrna luach an-còmhnaidh `false`.
        ///
        /// # Panics
        ///
        /// Bidh an gnìomh seo panic ma tha `rhs` 0.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Obraich a-mach co-roinn roinn Euclidean `self.div_euclid(rhs)`.
        ///
        /// A `tilleadh tiùb den roinniche còmhla ri boolean a` sealltainn an tachradh thar-shruth àireamhachd.
        /// Thoir fa-near nach tachair thar-shruth integers gun ainm a-riamh, agus mar sin is e an dàrna luach an-còmhnaidh `false`.
        /// Bho, airson na integers adhartach, tha a h-uile mìneachadh coitcheann de roinn co-ionann, tha seo dìreach co-ionann ri `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Bidh an gnìomh seo panic ma tha `rhs` 0.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Obraich a-mach an còrr nuair a thèid `self` a roinn le `rhs`.
        ///
        /// A `tilleadh tiùb den chòrr às deidh a bhith a` roinn còmhla ri boolean a `sealltainn an tachradh thar-shruth àireamhachd.
        /// Thoir fa-near nach tachair thar-shruth integers gun ainm a-riamh, agus mar sin is e an dàrna luach an-còmhnaidh `false`.
        ///
        /// # Panics
        ///
        /// Bidh an gnìomh seo panic ma tha `rhs` 0.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Obraich a-mach an còrr `self.rem_euclid(rhs)` mar gum biodh a rèir roinn Euclidean.
        ///
        /// A `tilleadh tiùb den mhodulo às deidh dha sgaradh còmhla ri boolean a` nochdadh an tachradh thar-shruth àireamhachd.
        /// Thoir fa-near nach tachair thar-shruth integers gun ainm a-riamh, agus mar sin is e an dàrna luach an-còmhnaidh `false`.
        /// Bho, airson na integers adhartach, tha a h-uile mìneachadh coitcheann de roinn co-ionann, tha an obrachadh seo co-ionann ri `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Bidh an gnìomh seo panic ma tha `rhs` 0.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Negates fhèin ann an dòigh a tha a `ruith thairis.
        ///
        /// A `tilleadh `!self + 1` a` cleachdadh obair fillte gus an luach a thilleadh a tha a `riochdachadh dearmad air an luach neo-ainmichte seo.
        /// Thoir fa-near gum bi thar-shruth an-còmhnaidh a `tachairt airson luachan adhartach gun ainm, ach chan eil dearmad 0 a` dol thairis.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// A `gluasad fèin air fhàgail le buillean `rhs`.
        ///
        /// A `tilleadh tiùb den dreach gluasadach de fhèin còmhla ri boolean a` sealltainn an robh an luach gluasaid nas motha na no co-ionann ris an àireamh de bhuillean.
        /// Ma tha luach a `ghluasaid ro mhòr, tha luach air a chìreadh (N-1) far a bheil N na àireamh de bhuillean, agus tha an luach seo an uairsin air a chleachdadh gus an gluasad a dhèanamh.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// A `gluasad fèin ceart le pìosan `rhs`.
        ///
        /// A `tilleadh tiùb den dreach gluasadach de fhèin còmhla ri boolean a` sealltainn an robh an luach gluasaid nas motha na no co-ionann ris an àireamh de bhuillean.
        /// Ma tha luach a `ghluasaid ro mhòr, tha luach air a chìreadh (N-1) far a bheil N na àireamh de bhuillean, agus tha an luach seo an uairsin air a chleachdadh gus an gluasad a dhèanamh.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Bidh e ga thogail fhèin gu cumhachd `exp`, a `cleachdadh exponentiation le squaring.
        ///
        /// A `tilleadh tiùb den mhìneachadh còmhla ri bool a` nochdadh an do thachair cus sruthadh.
        ///
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, fìor));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // A `sgrìobadh àite airson toraidhean de overflowing_mul a stòradh.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // bho exp!=0, mu dheireadh feumaidh an exp a bhith 1.
            // Dèilig ris a `phàirt mu dheireadh den neach-nochdaidh air leth, oir chan eil feum air a bhith a` sgùradh a `bhunait às deidh sin agus dh` fhaodadh e cus sruthadh gun fheum.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Bidh e ga thogail fhèin gu cumhachd `exp`, a `cleachdadh exponentiation le squaring.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // bho exp!=0, mu dheireadh feumaidh an exp a bhith 1.
            // Dèilig ris a `phàirt mu dheireadh den neach-nochdaidh air leth, oir chan eil feum air a bhith a` sgùradh a `bhunait às deidh sin agus dh` fhaodadh e cus sruthadh gun fheum.
            //
            //
            acc * base
        }

        /// A `dèanamh roinn Euclidean.
        ///
        /// Bho, airson na integers adhartach, tha a h-uile mìneachadh coitcheann de roinn co-ionann, tha seo dìreach co-ionann ri `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Bidh an gnìomh seo panic ma tha `rhs` 0.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Obraich a-mach an còrr as lugha de `self (mod rhs)`.
        ///
        /// Bho, airson na integers adhartach, tha a h-uile mìneachadh coitcheann de roinn co-ionann, tha seo dìreach co-ionann ri `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Bidh an gnìomh seo panic ma tha `rhs` 0.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// A `tilleadh `true` ma tha agus dìreach ma tha `self == 2^k` airson cuid de `k`.
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // A `tilleadh aon nas lugha na an ath chumhachd de dhà.
        // (Airson 8u8 is e 8u8 an ath chumhachd de dhà agus airson 6u8 tha e 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Chan urrainn don dòigh seo a dhol thairis air, oir ann an cùisean thar-shruth `next_power_of_two` bidh e an àite a bhith a `tilleadh an luach as motha den t-seòrsa, agus faodaidh e 0 a thilleadh airson 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SÀBHAILTEACHD: Leis gu bheil `p > 0`, chan urrainn dha a bhith gu tur a `toirt a-steach neoni.
            // Tha sin a `ciallachadh gu bheil an gluasad an-còmhnaidh taobh a-staigh, agus tha intrins ctlz nas èifeachdaiche aig cuid de luchd-giullachd (leithid intel pre-haswell) nuair a tha an argamaid neo-neoni.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// A `tilleadh an cumhachd as lugha de dhà nas motha na no co-ionann ri `self`.
        ///
        /// Nuair a bhios luach toraidh a `dol thairis (ie, `self > (1 << (N-1))` airson seòrsa `uN`), tha e panics ann am modh deasbaid agus luach toraidh air a phasgadh gu 0 ann am modh fuasglaidh (an aon suidheachadh anns am faod modh tilleadh 0).
        ///
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// A `tilleadh an cumhachd as lugha de dhà nas motha na no co-ionann ri `n`.
        /// Ma tha an ath chumhachd de dhà nas motha na luach as motha an t-seòrsa, thèid `None` a thilleadh, air dhòigh eile tha cumhachd dithis air a phasgadh ann an `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// A `tilleadh an cumhachd as lugha de dhà nas motha na no co-ionann ri `n`.
        /// Ma tha an ath chumhachd de dhà nas motha na luach as motha an t-seòrsa, tha an luach toraidh air a phasgadh gu `0`.
        ///
        ///
        /// # Examples
        ///
        /// Cleachdadh bunaiteach:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Thoir air ais riochdachadh cuimhne an integer seo mar sreath byte ann an òrdugh byte (network) mòr-endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Thoir air ais riochdachadh cuimhne an integer seo mar sreath byte ann an òrdugh byte beag-endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Thoir air ais riochdachadh cuimhne an integer seo mar sreath byte ann an òrdugh byte dùthchasach.
        ///
        /// Leis gu bheil seasmhachd dùthchasach an àrd-ùrlar targaid air a chleachdadh, bu chòir còd so-ghiùlain [`to_be_bytes`] no [`to_le_bytes`] a chleachdadh, mar a bhios iomchaidh, na àite.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, ma tha cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } eile {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SÀBHAILTEACHD: fuaim seasmhach oir tha integers nan seann datatypes sìmplidh gus an urrainn dhuinn an-còmhnaidh
        // transmute iad gu arrays of bytes
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SÀBHAILTEACHD: tha integers nan seann datatypes sìmplidh gus an urrainn dhuinn an gluasad gu
            // arrays of bytes
            unsafe { mem::transmute(self) }
        }

        /// Thoir air ais riochdachadh cuimhne an integer seo mar sreath byte ann an òrdugh byte dùthchasach.
        ///
        ///
        /// [`to_ne_bytes`] bu chòir seo a bhith nas fheàrr na seo far a bheil sin comasach.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// leig bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, ma tha cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } eile {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SÀBHAILTEACHD: tha integers nan seann datatypes sìmplidh gus an urrainn dhuinn an gluasad gu
            // arrays of bytes
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Cruthaich luach dùthchasach endian dùthchasach bhon riochdachadh aige mar raon byte ann an endian mòr.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// cleachd std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * cuir a-steach=fois;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Cruthaich luach dùthchasach endian dùthchasach bhon riochdachadh aige mar raon byte ann an glè bheag de endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// cleachd std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * cuir a-steach=fois;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Cruthaich luach dùthchasach endian dùthchasach bho riochdachadh a `chuimhne mar raon byte ann an seasmhachd dùthchasach.
        ///
        /// Leis gu bheil seasmhachd dùthchasach an àrd-ùrlar targaid air a chleachdadh, tha coltas ann gu bheil còd so-ghiùlain ag iarraidh [`from_be_bytes`] no [`from_le_bytes`] a chleachdadh, mar a bhios iomchaidh.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } eile {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// cleachd std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * cuir a-steach=fois;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SÀBHAILTEACHD: fuaim seasmhach oir tha integers nan seann datatypes sìmplidh gus an urrainn dhuinn an-còmhnaidh
        // transmute thuca
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SÀBHAILTEACHD: tha integers nan seann datatypes sìmplidh gus an urrainn dhuinn an-còmhnaidh gluasad thuca
            unsafe { mem::transmute(bytes) }
        }

        /// B `fheàrr le còd ùr a chleachdadh
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// A `tilleadh an luach as lugha as urrainn a riochdachadh leis an t-seòrsa integer seo.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// B `fheàrr le còd ùr a chleachdadh
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// A `tilleadh an luach as motha as urrainn a riochdachadh leis an t-seòrsa integer seo.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}