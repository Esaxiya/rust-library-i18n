//! Seòrsaichean mearachd airson an atharrachadh gu seòrsachan riatanach.

use crate::convert::Infallible;
use crate::fmt;

/// Thill an seòrsa mearachd nuair a dh `fhailicheas tionndadh seòrsa bunaiteach a chaidh a sgrùdadh.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Dèan maids seach coerce gus dèanamh cinnteach gum bi còd mar `From<Infallible> for TryFromIntError` gu h-àrd a `cumail ag obair nuair a thig `Infallible` gu bhith na ailias ri `!`.
        //
        //
        match never {}
    }
}

/// Mearachd a dh `fhaodar a thilleadh nuair a thathar a` parsadh integer.
///
/// Tha a `mhearachd seo air a chleachdadh mar an seòrsa mearachd airson gnìomhan `from_str_radix()` air na seòrsachan prìomhaideach integer, leithid [`i8::from_str_radix`].
///
/// # Adhbharan comasach
///
/// Am measg adhbharan eile, faodar `ParseIntError` a thilgeil air sgàth a bhith a `stiùireadh no a` slaodadh àite-geal san t-sreang me, nuair a gheibhear e bhon chur-a-steach àbhaisteach.
///
/// Tha a bhith a `cleachdadh an dòigh [`str::trim()`] a` dèanamh cinnteach nach bi àite geal ann mus parsadh e.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum gus na diofar sheòrsaichean mearachdan a stòradh a dh `fhaodadh a bhith ag adhbhrachadh parsadh integer a bhith a` fàilligeadh.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Tha an luach a thathar a `parsadh falamh.
    ///
    /// Am measg adhbharan eile, thèid an caochladh seo a thogail nuair a thèid sreang falamh a pharsadh.
    Empty,
    /// Tha digit neo-dhligheach na cho-theacsa.
    ///
    /// Am measg adhbharan eile, thèid an caochladh seo a thogail nuair a thèid sreang a pharsadh anns a bheil car neo-ASCII.
    ///
    /// Tha an caochladh seo cuideachd air a thogail nuair a thèid `+` no `-` a thoirt a-mach à sreang ann an sreang leotha fhèin no ann am meadhan àireamh.
    ///
    ///
    InvalidDigit,
    /// Tha integer ro mhòr airson a stòradh ann an seòrsa integer targaid.
    PosOverflow,
    /// Tha integer ro bheag airson a stòradh ann an seòrsa integer targaid.
    NegOverflow,
    /// B `e luach Zero
    ///
    /// Thèid an caochladh seo a thoirt a-mach nuair a tha luach neoni aig an t-sreang parsaidh, a bhiodh mì-laghail airson seòrsachan neo-neoni.
    ///
    Zero,
}

impl ParseIntError {
    /// A `toirt a-mach an adhbhar mionaideach airson parsadh integer a` fàiligeadh.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}