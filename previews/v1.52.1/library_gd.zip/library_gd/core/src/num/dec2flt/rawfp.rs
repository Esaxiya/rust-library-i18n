//! Bit fiddling air flotaichean adhartach IEEE 754.Chan eil agus chan fheumar àireamhan àicheil a làimhseachadh.
//! Tha riochdachadh canonical aig àireamhan puing fleodraidh àbhaisteach mar (frac, exp) gus am bi an luach 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) far a bheil N na àireamh de bhuillean.
//!
//! Tha subnormals beagan eadar-dhealaichte agus neònach, ach tha an aon phrionnsapal a `buntainn.
//!
//! An seo, ge-tà, tha sinn gan riochdachadh mar (sig, k) le f deimhinneach, gus am bi an luach f *
//! 2 <sup>e</sup> .A bharrachd air an "hidden bit" a dhèanamh follaiseach, bidh seo ag atharrachadh an taisbeanair leis an gluasad mantissa ris an canar.
//!
//! Cuir dòigh eile, mar as trice thèid flotaichean a sgrìobhadh mar (1) ach an seo tha iad air an sgrìobhadh mar (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Is e (1) a chanas sinn ris an **riochdachadh bloighteach** agus (2) an **riochdachadh iomlan**.
//!
//! Bidh mòran de dhleastanasan sa mhodal seo a `làimhseachadh àireamhan àbhaisteach a-mhàin.Bidh na cleachdaidhean dec2flt gu glèidhteachail a`gabhail an t-slighe slaodach a tha ceart gu h-uile-choitcheann (Algorithm M) airson àireamhan glè bheag agus glè mhòr.
//! Chan fheum an algorithm sin ach next_float() a bhios a `làimhseachadh subnormals agus zeros.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Neach-cuideachaidh trait gus a bhith a `dùblachadh gu bunaiteach a h-uile còd tionndaidh airson `f32` agus `f64`.
///
/// Faic beachd doc a `mhodal phàrant airson carson a tha seo riatanach.
///
/// Cha bu chòir **a-riamh** a bhith air a bhuileachadh airson seòrsachan eile no a chleachdadh taobh a-muigh modal dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Seòrsa air a chleachdadh le `to_bits` agus `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// A `dèanamh transmutation amh gu integer.
    fn to_bits(self) -> Self::Bits;

    /// A `dèanamh transmutation amh bho integer.
    fn from_bits(v: Self::Bits) -> Self;

    /// A `tilleadh an roinn anns a bheil an àireamh seo.
    fn classify(self) -> FpCategory;

    /// A `tilleadh an mantissa, exponent agus a` soidhneadh mar integers.
    fn integer_decode(self) -> (u64, i16, i8);

    /// A `cò-dhùnadh an seòladh.
    fn unpack(self) -> Unpacked;

    /// Casts bho integer beag as urrainn a riochdachadh gu dìreach.
    /// Panic mura h-urrainnear an integer a riochdachadh, bidh an còd eile sa mhodal seo a `dèanamh cinnteach nach leig e le sin tachairt.
    fn from_int(x: u64) -> Self;

    /// Faigh an luach 10 <sup>e</sup> bho chlàr ro-shuidhichte.
    /// Panics airson `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Na tha an t-ainm ag ràdh.
    /// Tha e nas fhasa còd cruaidh a dhèanamh na juggling intrinsics agus an dòchas gum bi LLVM seasmhach ga phasgadh.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Neach-gleidhidh ceangailte ri àireamhan deicheach cuir-a-steach nach urrainn a bhith a `dèanamh thar-shruth no neoni no
    /// subnormals.Is dòcha gur e an taisbeanaiche deicheach den luach àbhaisteach as àirde, mar sin an t-ainm.
    const MAX_NORMAL_DIGITS: usize;

    /// Nuair a tha luach àite nas motha na seo aig an fhigear deicheach as cudromaiche, tha an àireamh gu cinnteach cruinn gu Infinity.
    ///
    const INF_CUTOFF: i64;

    /// Nuair a tha luach àite aig an àireamh deicheach as cudromaiche na seo, tha an àireamh gu cinnteach cruinn gu neoni.
    ///
    const ZERO_CUTOFF: i64;

    /// An àireamh de bhuillean anns an exponent.
    const EXP_BITS: u8;

    /// An àireamh de bhuillean anns an suntasand,*a `toirt a-steach* am pìos falaichte.
    const SIG_BITS: u8;

    /// An àireamh de bhuillean anns an suntasand,*às aonais* am pìos falaichte.
    const EXPLICIT_SIG_BITS: u8;

    /// An neach-taisbeanaidh laghail as motha ann an riochdachadh bloighteach.
    const MAX_EXP: i16;

    /// An neach-taisbeanaidh laghail as ìsle ann an riochdachadh bloighteach, ach a-mhàin subnormals.
    const MIN_EXP: i16;

    /// `MAX_EXP` airson riochdachadh bunaiteach, ie, leis a `ghluasad air a chuir an gnìomh.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` air a chòdachadh (ie, le claonadh air a chothromachadh)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` airson riochdachadh bunaiteach, ie, leis a `ghluasad air a chuir an gnìomh.
    const MIN_EXP_INT: i16;

    /// An cudrom àbhaisteach àbhaisteach ann an riochdachadh iomlan.
    const MAX_SIG: u64;

    /// An ìre as ìsle àbhaisteach ann an riochdachadh iomlan.
    const MIN_SIG: u64;
}

// Sa mhòr-chuid sruth-obrach airson #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// A `tilleadh an mantissa, exponent agus a` soidhneadh mar integers.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Claonadh taisbeanaidh + gluasad mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // tha rkruppe mì-chinnteach a bheil `as` a `cuairteachadh gu ceart air gach àrd-ùrlar.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// A `tilleadh an mantissa, exponent agus a` soidhneadh mar integers.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Claonadh taisbeanaidh + gluasad mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // tha rkruppe mì-chinnteach a bheil `as` a `cuairteachadh gu ceart air gach àrd-ùrlar.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Bidh e ag atharrachadh `Fp` chun t-seòrsa flot inneal as fhaisge.
/// Cha bhith a `làimhseachadh toraidhean subnormal.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f tha 64 bit, mar sin tha gluasad mantissa de 63 aig xe
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Cuir timcheall na pìosan 64-bit gu T::SIG_BITS le leth-gu-eadhon.
/// Cha bhith a `làimhseachadh thar-shruth exponent.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Atharraich gluasad mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Inverse de `RawFloat::unpack()` airson àireamhan àbhaisteach.
/// Panics mura h-eil an comharradh no an taisbeanair dligheach airson àireamhan àbhaisteach.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Thoir air falbh am pìos falaichte
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Atharraich an taisbeanair airson bias eas-chruthach agus gluasad mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Fàg pìos soidhne aig 0 ("+"), tha na h-àireamhan againn uile adhartach
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Tog subnormal.Tha mantissa de 0 ceadaichte agus a `togail neoni.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Is e 0 an taisbeanaiche encoded, is e 0 am pìos soidhne, agus mar sin feumaidh sinn na pìosan ath-mhìneachadh.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Tomhais bignum le Fp.Cuairtean taobh a-staigh 0.5 ULP le leth-eadhon.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Bidh sinn a `gearradh dheth a h-uile pìos ron chlàr-amais `start`, ie, bidh sinn gu h-èifeachdach a` gluasad gu ceart le tomhas de `start`, agus mar sin is e seo cuideachd an taisbeanair a dh `fheumas sinn.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Cruinn (half-to-even) a rèir na pìosan teasairginn.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Lorg an àireamh puing fleodraidh as motha gu math nas lugha na an argamaid.
/// Cha bhith a `làimhseachadh subnormals, neoni, no fo-shruth exponent.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Lorg an àireamh puing fleòdraidh as lugha gu mòr nas motha na an argamaid.
// Tha an obrachadh seo sùghaidh, ie, next_float(inf) ==inf.
// Eu-coltach ris a `mhòr-chuid de chòd sa mhodal seo, bidh an gnìomh seo a` làimhseachadh neoni, subnormals, agus infinities.
// Ach, mar a h-uile còd eile an seo, chan eil e a `dèiligeadh ri NaN agus àireamhan àicheil.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Tha e coltach gu bheil seo ro mhath airson a bhith fìor, ach tha e ag obair.
        // 0.0 air a chòdachadh mar am facal uile-neoni.Tha subnormals 0x000m ... m far a bheil m am mantissa.
        // Gu sònraichte, is e an subnormal as lugha 0x0 ... 01 agus am fear as motha 0x000F ... F.
        // Is e an àireamh àbhaisteach as lugha 0x0010 ... 0, agus mar sin tha a `chùis oisean seo ag obair cuideachd.
        // Ma tha an àrdachadh a `dol thairis air an mantissa, bidh am pìos giùlain a` meudachadh an taisbeanair mar a tha sinn ag iarraidh, agus bidh na pìosan mantissa a `fàs neoni.
        // Air sgàth a `chùmhnaint rudeigin falaichte, is e seo cuideachd a tha sinn ag iarraidh!
        // Mu dheireadh, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}