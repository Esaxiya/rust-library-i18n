//! A `dearbhadh agus a` lobhadh sreang deicheach den fhoirm:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Ann am faclan eile, co-chòrdadh puing fleodraidh àbhaisteach, le dà eisgeachd: Gun soidhne, agus gun làimhseachadh "inf" agus "NaN".Tha iad sin air an làimhseachadh le gnìomh dràibhear (super::dec2flt).
//!
//! Ged a tha e furasta aithneachadh inntrigidhean dligheach, feumaidh am modal seo cuideachd na h-atharrachaidhean neo-dhligheach gun àireamh a dhiùltadh, gun panic a-riamh, agus grunn sgrùdaidhean a dhèanamh air a bheil na modalan eile an urra ri panic (no thar-shruth) ann an tionndadh.
//!
//! Gus cùisean a dhèanamh nas miosa, thèid a h-uile càil a thachras ann an aon pas thairis air an fhiosrachadh a-steach.
//! Mar sin, bi faiceallach nuair a bhios tu ag atharrachadh dad, agus dèan sgrùdadh dùbailte leis na modalan eile.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Na pàirtean inntinneach de sreang deicheach.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// An taisbeanair deicheach, le cinnt gum bi nas lugha na 18 deicheach deicheach ann.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Dèan cinnteach a bheil an sreang inntrigidh na àireamh puing fleòdraidh dligheach agus ma tha, lorg am pàirt riatanach, am pàirt bloighteach, agus an taisbeanair a tha ann.
/// Cha bhith a `làimhseachadh shoidhnichean.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Gun àireamhan ro 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Feumaidh sinn co-dhiù aon fhigear ro no às deidh a `phuing.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // A `slaodadh sgudal às deidh pàirt bloighteach
            }
        }
        _ => Invalid, // A `slaodadh sgudal às deidh a` chiad sreang de dhigit
    }
}

/// A `snaidheadh àireamhan deicheach suas chun chiad charactar neo-dhigitach.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Tarraing às-shealladh agus sgrùdadh mearachd.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // A `slaodadh sgudail às deidh exponent
    }
    if number.is_empty() {
        return Invalid; // Taisbeanair falamh
    }
    // Aig an ìre seo, gu cinnteach tha sreath de dh `àireamhan dligheach againn.Is dòcha gu bheil e ro fhada airson a chuir a-steach do `i64`, ach ma tha e cho mòr, tha an cur-a-steach gu cinnteach neoni no Infinity.
    // Leis gu bheil gach neoni anns na h-àireamhan deicheach dìreach ag atharrachadh an taisbeanair le +/-1, aig exp=10 ^ 18 dh'fheumadh an cur a-steach a bhith 17 exabyte (!) de zeros gus faighinn faisg air làimh faisg air a bhith crìochnaichte.
    //
    // Chan e seo dìreach cùis cleachdaidh a dh `fheumas sinn frithealadh air.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}