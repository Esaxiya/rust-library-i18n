//! Na diofar algorithms bhon phàipear.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Àireamh de bhuillean cudromach ann am Fp
const P: u32 = 64;

// Bidh sinn dìreach a `stòradh an tuairmseachadh as fheàrr airson *a h-uile* taisbeanair, agus mar sin faodar an caochlaideach "h" agus na cumhaichean co-cheangailte ris fhàgail air falbh.
// Bidh seo a `malairt coileanadh airson kilobytes càraid de dh` àite.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Anns a `mhòr-chuid de dh` ailtireachd, tha meud puing sònraichte aig obraichean puing fleòdraidh, mar sin tha cruinneas an àireamhachaidh air a dhearbhadh a rèir gach gnìomh.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Air x86, tha an x87 FPU air a chleachdadh airson obair flot mura h-eil na leudachain SSE/SSE2 rim faighinn.
// Bidh an x87 FPU ag obair le 80 buillean de mhearachd a rèir coltais, a tha a `ciallachadh gum bi gnìomhachd a` dol timcheall air 80 buillean ag adhbhrachadh gun tachair cuairteachadh dùbailte nuair a thèid luachan a riochdachadh aig a `cheann thall mar
//
// 32/64 luachan beagan air bhog.Gus faighinn thairis air an seo, faodar am facal smachd FPU a shuidheachadh gus am bi na coimpiutairean air an coileanadh anns an cruinneas a tha thu ag iarraidh.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Structar a chaidh a chleachdadh gus luach tùsail an fhacail smachd FPU a ghleidheadh, gus an urrainnear a thoirt air ais nuair a thèid an structar a leigeil sìos.
    ///
    ///
    /// Tha an x87 FPU na chlàr 16-bit le na raointean mar a leanas:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Tha na sgrìobhainnean airson na raointean uile rim faighinn ann an Leabhar-làimhe Leasaiche Bathar-bog Ailtireachd IA-32 (Leabhar 1).
    ///
    /// Is e an aon raon a tha buntainneach airson a `chòd a leanas PC, Precision Control.
    /// Bidh an raon seo a `dearbhadh dè cho mionaideach sa tha na h-obraichean a nì an FPU.
    /// Faodar a shuidheachadh gu:
    ///  - 0b00, mionaideachd singilte ie, 32-buillean
    ///  - 0b10, mionaideachd dùbailte ie, 64-bits
    ///  - 0b11, mionaideachd leudaichte dùbailte ie, 80-buillean (staid àbhaisteach) Tha an luach 0b01 glèidhte agus cha bu chòir a chleachdadh.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SÀBHAILTEACHD: chaidh an stiùireadh `fldcw` a sgrùdadh gus obrachadh gu ceart leis
        // `u16` sam bith
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Tha sinn a `cleachdadh criathradh ATT gus taic a thoirt do LLVM 8 agus LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// A `suidheachadh raon mionaideachd an FPU gu `T` agus a` tilleadh `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Obraich a-mach an luach airson an raon Smachd Precision a tha iomchaidh airson `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 buillean
            8 => 0x0200, // 64 buillean
            _ => 0x0300, // àbhaisteach, 80 buillean
        };

        // Faigh luach tùsail an fhacail smachd gus a thoirt air ais nas fhaide air adhart, nuair a thèid structar `FPUControlWord` a leigeil sìos SÀBHAILTEACHD: chaidh an stiùireadh `fnstcw` a sgrùdadh gus a bhith comasach air obrachadh gu ceart le `u16` sam bith.
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Tha sinn a `cleachdadh criathradh ATT gus taic a thoirt do LLVM 8 agus LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Suidhich am facal smachd chun mionaideachd a tha thu ag iarraidh.
        // Tha seo air a choileanadh le bhith a `falach air falbh an t-seann chruinneas (buillean 8 agus 9, 0x300) agus a` cur na brataich mionaideachd gu h-àrd na àite.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Slighe luath Bellerophon a `cleachdadh integers meud-inneal agus flotaichean.
///
/// Tha seo air a thoirt a-mach gu gnìomh air leth gus an urrainnear feuchainn mus tog thu bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Bidh sinn a `dèanamh coimeas eadar an fhìor luach ri MAX_SIG faisg air an deireadh, chan eil an seo ach diùltadh luath, saor (agus bidh e cuideachd a` saoradh a `chòrr den chòd bho bhith a` gabhail dragh mu dheidhinn fo-shruth).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Tha an t-slighe luath gu mòr an urra ri àireamhachd a bhith air a chuairteachadh chun an àireamh cheart de bhuillean gun cruinneachadh meadhanach sam bith.
    // Air x86 (às aonais SSE no SSE2) tha seo ag iarraidh gun tèid cruinneas an stac x87 FPU atharrachadh gus am bi e a `cuairteachadh gu dìreach gu pìos 64/32.
    // Tha gnìomh `set_precision` a `gabhail cùram mu bhith a` suidheachadh mionaideachd air ailtireachd a dh `fheumas a shuidheachadh le bhith ag atharrachadh staid na cruinne (mar am facal smachd an x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Chan urrainnear a `chùis e <0 a phasgadh a-steach don branch eile.
    // Bidh cumhachdan àicheil a `leantainn gu pàirt bloigh ath-aithris ann am binary, a tha cruinn, a dh` adhbhraicheas mearachdan fìor (agus uaireannan gu math cudromach!) Anns an toradh deireannach.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Is e còd trivial a th `ann an algorithm Bellerophon air a dhearbhadh le mion-sgrùdadh àireamhach neo-thrioblaideach.
///
/// Bidh e a `cuairteachadh` `f`` gu flot le 64 bit suntasand agus ga iomadachadh leis an tuairmseachadh as fheàrr de `10^e` (san aon chruth puing fleòdraidh).Gu tric bidh seo gu leòr gus an toradh ceart fhaighinn.
/// Ach, nuair a tha an toradh faisg air letheach slighe eadar dà flot (ordinary) a tha faisg air làimh, tha an mearachd cruinneachaidh toinnte bho bhith ag iomadachadh dà thuairmeas a `ciallachadh gum faodadh an toradh a bhith dheth le beagan bhuillean.
/// Nuair a thachras seo, bidh an Algorithm R itealach a `rèiteach chùisean.
///
/// Tha an "close to halfway" làmh-làimhe air a dhèanamh mionaideach leis an anailis àireamhach sa phàipear.
/// Ann am faclan Clinger:
///
/// > Tha bruthach, air a chuir an cèill ann an aonadan den ìre as lugha, na cheangal in-ghabhaltach airson a `mhearachd
/// > air a chruinneachadh aig àm àireamhachadh puing fleòdraidh an tuairmseachadh gu f * 10 ^ e.(Tha bruthach
/// > chan ann mar cheangal airson an fhìor mhearachd, ach tha e a `cuartachadh an eadar-dhealachaidh eadar an tuairmseach z agus
/// > an tuairmseachadh as fheàrr a tha comasach a `cleachdadh pìosan p de chudromand.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Tha na cùisean abs(e) <log5(2^N) ann an fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // A bheil an leathad mòr gu leòr airson eadar-dhealachadh a dhèanamh nuair a tha e cruinn gu pìosan?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Algairim iteagach a leasaicheas tuairmseachadh puing fleòdraidh de `f * 10^e`.
///
/// Bidh gach itealadh a `faighinn aon aonad san àite mu dheireadh nas fhaisge, agus tha sin gu dearbh a` toirt uamhasach fada a bhith a `tighinn còmhla ma tha `z0` eadhon beagan dheth.
/// Gu fortanach, nuair a thèid a chleachdadh mar chùl-taic airson Bellerophon, tha an tuairmseachadh tòiseachaidh air falbh le co-dhiù aon ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Lorg integers adhartach `x`, `y` gus am bi `x / y` dìreach `(f *10^e) / (m* 2^k)`.
        // Tha seo chan e a-mhàin a `seachnadh dèiligeadh ri soidhnichean `e` agus `k`, bidh sinn cuideachd a` cur às do chumhachd dà rud a tha cumanta do `10^e` agus `2^k` gus na h-àireamhan a dhèanamh nas lugha.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Tha seo sgrìobhte beagan neònach oir chan eil na bignums againn a `toirt taic do àireamhan àicheil, mar sin bidh sinn a` cleachdadh an luach iomlan + fiosrachadh soidhnidh.
        // Chan urrainn an iomadachadh le m_digits a dhol thairis.
        // Ma tha `x` no `y` mòr gu leòr gum feum sinn dragh a ghabhail mu bhith a `cur thairis, tha iad cuideachd mòr gu leòr gu bheil `make_ratio` air am bloigh a lughdachadh le factar 2 ^ 64 no barrachd.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Na bi feumach air x tuilleadh, sàbhail clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Fhathast feumach air y, dèan leth-bhreac.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Le bhith a `toirt seachad `x = f` agus `y = m` far a bheil `f` a` riochdachadh àireamhan deicheach cuir a-steach mar as àbhaist agus `m` mar chomharradh air puing puing fleòdraidh, dèan an co-mheas `x / y` co-ionann ri `(f *10^e) / (m* 2^k)`, is dòcha air a lughdachadh le cumhachd a dhà an dà chuid gu cumanta.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, ach gu bheil sinn a `lughdachadh na bloigh le cuid de chumhachd dhà.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Chan urrainn dha seo a dhol thairis air sgàth gu feum e `e` adhartach agus `k` àicheil, nach urrainn tachairt ach airson luachan gu math faisg air 1, a tha a `ciallachadh gum bi `e` agus `k` an ìre mhath beag.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Chan urrainn seo a dhol thairis air an dàrna cuid, faic gu h-àrd.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), a-rithist a `lughdachadh le cumhachd cumanta de dhà.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Gu ciallach, is e Algorithm M an dòigh as sìmplidh air deicheach a thionndadh gu flot.
///
/// Bidh sinn a `dèanamh co-mheas a tha co-ionann ri `f * 10^e`, an uairsin a` tilgeil a-steach cumhachdan de dhithis gus an toir e flot dligheach cudromach agus.
/// Is e an taisbeanair binary `k` an àireamh de thursan a rinn sinn iomadachadh àireamhaiche no ainmiche le dhà, ie, aig a h-uile àm tha `f *10^e` co-ionann ri `(u / v)* 2^k`.
/// Nuair a tha sinn air faighinn a-mach brìgh cudromach, cha leig sinn a leas ach cruinneachadh le bhith a `sgrùdadh a` chòrr den roinn, a tha air a dhèanamh ann an gnìomhan luchd-cuideachaidh nas fhaide gu h-ìosal.
///
///
/// Tha an algorithm seo gu math slaodach, eadhon leis an optimization a chaidh a mhìneachadh ann an `quick_start()`.
/// Ach, is e seo an algorithm as sìmplidh airson atharrachadh airson toraidhean thar-shruth, fo-shruth agus fo-nàdurrach.
/// Bidh am buileachadh seo a `gabhail thairis nuair a thèid Bellerophon agus Algorithm R thairis.
/// Tha e furasta a bhith a `lorg fo-shruth agus thar-shruth: Chan eil an co-mheas fhathast na chudromachd taobh a-staigh, ach chaidh an taisbeanair minimum/maximum a ruighinn.
/// Ann an cùis thar-shruth, bidh sinn dìreach a `tilleadh Infinity.
///
/// Tha e nas duilghe a bhith a `làimhseachadh fo-shruth agus subnormals.
/// Is e aon dhuilgheadas mòr a th `ann, leis an ìre as lugha de mhìneachadh, gum faodadh an co-mheas a bhith fhathast ro mhòr airson brìgh.
/// Faic underflow() airson mion-fhiosrachadh.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME optimization a dh `fhaodadh: coitcheann big_to_fp gus an urrainn dhuinn an aon rud ri fp_to_float(big_to_fp(u)) a dhèanamh an seo, dìreach às aonais an cuairteachadh dùbailte.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Feumaidh sinn stad aig a `char as lugha, ma dh` fheitheas sinn gu `k < T::MIN_EXP_INT`, bhiodh sinn dheth le factar a dhà.
            // Gu mì-fhortanach, tha seo a `ciallachadh gum feum sinn àireamhan àbhaisteach a chuir gu sònraichte leis an ìre as lugha de mhìneachadh.
            // Lorg FIXME cumadh nas eireachdail, ach ruith an deuchainn `tiny-pow10` gus dèanamh cinnteach gu bheil e ceart gu dearbh!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Thoir leum thairis air a `mhòr-chuid de itealain Algorithm M le bhith a` sgrùdadh an fhaid.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Tha an fhad bit na thuairmse den logarithm bonn a dhà, agus log(u / v) = log(u), log(v).
    // Tha an tuairmse dheth aig 1 aig a `char as motha, ach an-còmhnaidh fo-thuairmse, agus mar sin tha a` mhearachd air log(u) agus log(v) den aon shoidhne agus cuir dheth (ma tha an dà chuid mòr).
    // Mar sin tha a `mhearachd airson log(u / v) aig a` char as motha cuideachd.
    // Is e an co-mheas targaid aon far a bheil u/v ann an raon sònraichte taobh a-staigh.Mar sin is e an suidheachadh crìochnachaidh againn gur e log2(u / v) na pìosan cudromach, plus/minus aon.
    // FIXME Dh `fhaodadh a bhith a` coimhead air an dàrna pìos piseach a thoirt air an tuairmse agus beagan roinnean a bharrachd a sheachnadh.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Fo-shruth no subnormal.Fàg e chun phrìomh ghnìomh.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Thar-shruth.Fàg e chun phrìomh ghnìomh.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Chan eil co-mheas eadar-dhealaichte ann an raon agus leis an ìre as lugha de mhìneachadh, agus mar sin feumaidh sinn cus bhuillean a thoirt gu crìch agus an taisbeanair atharrachadh a rèir sin.
    // Tha an fhìor luach a-nis a `coimhead mar seo:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(air a riochdachadh le rem)
    //
    // Mar sin, nuair a tha na pìosan cruinn!= 0.5 ULP, bidh iad a `co-dhùnadh an cruinneachadh leotha fhèin.
    // Nuair a tha iad co-ionann agus an còrr neo-neoni, feumar an luach a chruinneachadh fhathast.
    // Is ann dìreach nuair a tha na pìosan cruinn cruinn 1/2 agus an còrr neoni, tha suidheachadh leth-chothromach againn.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Cuairt-gu-àbhaisteach àbhaisteach, air a ghiorrachadh le bhith a `cruinneachadh timcheall air a` chòrr de roinn.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}