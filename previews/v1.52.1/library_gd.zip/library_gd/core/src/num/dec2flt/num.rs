//! Gnìomhan cleachdaidh airson bignums nach eil a `dèanamh cus ciall tionndadh gu modhan.

// FIXME Tha ainm a `mhodal seo beagan mì-fhortanach, leis gu bheil modalan eile a` toirt a-steach `core::num` cuideachd.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Dèan deuchainn a bheil a bhith a `briseadh a h-uile pìos nach eil cho cudromach na `ones_place` a` toirt a-steach mearachd dàimheach nas lugha, co-ionann no nas motha na 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Ma tha a h-uile pìos a tha air fhàgail neoni, tha e= 0.5 ULP, air dhòigh eile> 0.5 Mura h-eil barrachd bhuillean ann (half_bit==0), bidh an fheadhainn gu h-ìosal cuideachd a `tilleadh gu ceart Co-ionann.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Bidh e ag atharrachadh sreang ASCII anns nach eil ach àireamhan deicheach gu `u64`.
///
/// Cha bhith e a `dèanamh sgrùdaidhean airson caractaran thar-shruth no neo-dhligheach, mar sin mura h-eil an neach-fios faiceallach, tha an toradh bog agus faodaidh e panic (ged nach e `unsafe` a bhios ann).
/// A bharrachd air an sin, thathas a `làimhseachadh sreangan falamh mar neoni.
/// Tha an gnìomh seo ann air sgàth
///
/// 1. a `cleachdadh `FromStr` air `&[u8]` feumar `from_utf8_unchecked`, a tha dona, agus
/// 2. tha a bhith a `cur toraidhean `integral.parse()` agus `fractional.parse()` còmhla nas toinnte na an gnìomh iomlan seo.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Bidh e ag atharrachadh sreath de dh `àireamhan ASCII gu bhith na bignum.
///
/// Coltach ri `from_str_unchecked`, tha an gnìomh seo an urra ris a `parser gus fighe a-mach neo-àireamhan.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Unwraps bignum a-steach do integer 64 bit.Panics ma tha an àireamh ro mhòr.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// A `toirt a-mach raon de bhuillean.

/// Is e Clàr-amais 0 am pìos as lugha a tha cudromach agus tha an raon leth-fhosgailte mar as àbhaist.
/// Panics ma thèid iarraidh ort barrachd bhuillean a thoirt a-mach na bhiodh iomchaidh don t-seòrsa tilleadh.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}