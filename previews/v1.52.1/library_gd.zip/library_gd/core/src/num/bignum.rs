//! Gnìomhachadh gnàthaichte-mionaideachd àireamh (bignum).
//!
//! Tha seo air a dhealbhadh gus riarachadh nan cruachan a sheachnadh aig cosgais cuimhne cruachan.
//! Tha an seòrsa bignum as motha a chleachdar, `Big32x40`, air a chuingealachadh le 32 × 40=1,280 buillean agus gabhaidh e aig a `char as motha 160 bytes de chuimhne stac.
//! Tha seo nas motha na gu leòr airson a bhith a `dol timcheall a h-uile luach `f64` crìochnaichte a dh` fhaodadh.
//!
//! Ann am prionnsapal tha e comasach grunn sheòrsaichean bignum a bhith ann airson diofar chuir-a-steach, ach cha bhith sinn a `dèanamh sin gus an còd a sheachnadh.
//!
//! Thathas a `cumail sùil air gach bignum fhathast airson na fìor chleachdaidhean, mar sin mar as trice chan eil e gu diofar.
//!

// Chan eil am modal seo ach airson dec2flt agus flt2dec, agus dìreach poblach air sgàth prìomh cheistean.
// Chan eilear an dùil a bhith seasmhach a-riamh.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// Obair àireamhachd a dh `fheumas bignums.
pub trait FullOps: Sized {
    /// A `tilleadh `(carry', v')` gus am bi `carry' * 2^W + v' = self + other + carry`, far a bheil `W` an àireamh de bhuillean ann an `Self`.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// A `tilleadh `(carry', v')` gus am bi `carry'*2^W + v' = self* other + carry`, far a bheil `W` an àireamh de bhuillean ann an `Self`.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// A `tilleadh `(carry', v')` gus am bi `carry'*2^W + v' = self* other + other2 + carry`, far a bheil `W` an àireamh de bhuillean ann an `Self`.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// A `tilleadh `(quo, rem)` gus am bi `borrow *2^W + self = quo* other + rem` agus `0 <= rem < other`, far a bheil `W` mar an àireamh de bhuillean ann an `Self`.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // Chan urrainn seo cur thairis;tha an toradh eadar `0` agus `2 * 2^nbits - 1`.
                    // FIXME: an toir LLVM an fheum as fheàrr a-steach do ADC no a leithid?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // Chan urrainn seo cur thairis;
                    // tha an toradh eadar `0` agus `2^nbits * (2^nbits - 1)`.
                    // FIXME: an toir LLVM an fheum as fheàrr a-steach do ADC no a leithid?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // Chan urrainn seo cur thairis;
                    // tha an toradh eadar `0` agus `2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // Chan urrainn seo cur thairis;tha an toradh eadar `0` agus `other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // Faic RFC #521 airson seo a chomasachadh.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// Clàr de chumhachdan 5 a ghabhas riochdachadh ann an àireamhan.Gu sònraichte, is e an luach {u8, u16, u32} as motha a tha na chumhachd de chòig, a bharrachd air an taisbeanair co-fhreagarrach.
/// Air a chleachdadh ann an `mul_pow5`.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// Stack-riarachadh rèiteachaidh-mionaideachd (suas gu ìre sònraichte) integer.
        ///
        /// Tha seo a `faighinn taic bho sreath de mheud stèidhichte de sheòrsa ("digit") a chaidh a thoirt seachad.
        /// Ged nach eil an raon eagrachaidh glè mhòr (mar as trice cuid de cheudan bytes), ma dh `fhaodar a chopaigeadh gu neo-chùramach dh` fhaodadh sin leantainn gu buil.
        ///
        /// Mar sin chan e `Copy` a tha seo.
        ///
        /// A h-uile gnìomhachd ri fhaighinn le bignums panic ann an cùis tar-chuir.
        /// Tha e an urra ris an neach-fòn seòrsan bignum mòr gu leòr a chleachdadh.
        pub struct $name {
            /// Aon a bharrachd air an fhrith-thionndadh chun an "digit" as motha a thathas a `cleachdadh.
            /// Chan eil seo a `lughdachadh, mar sin bi mothachail mun òrdugh coimpiutaireachd.
            /// `base[size..]` bu chòir a bhith neoni.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` a `riochdachadh `a + b *2^W + c* 2^(2W) + ...` far a bheil `W` mar an àireamh de bhuillean san t-seòrsa digit.
            base: [$ty; $n],
        }

        impl $name {
            /// A `dèanamh bignum bho aon dhigit.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// A `dèanamh bignum bho luach `u64`.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// A `tilleadh nan àireamhan a-staigh mar sliseag `[a, b, c, ...]` gus am bi an luach àireamhach `a + b *2^W + c* 2^(2W) + ...` far a bheil `W` mar an àireamh de bhuillean anns an t-seòrsa digit.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// A `tilleadh am pìos` i`-th far a bheil bit 0 am fear as lugha.
            /// Ann am faclan eile, am pìos le cuideam `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// A `tilleadh `true` ma tha am bignum neoni.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// A `tilleadh an àireamh de bhuillean a tha riatanach gus an luach seo a riochdachadh.
            /// Thoir fa-near gu bheilear den bheachd gu feum neoni 0 buillean.
            pub fn bit_length(&self) -> usize {
                // Thoir leum thairis air na h-àireamhan as cudromaiche a tha neoni.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // Chan eil àireamhan neo-neoni ann, ie, tha an àireamh neoni.
                    return 0;
                }
                // Dh `fhaodadh seo a bhith air a bharrachadh le leading_zeros() agus gluasadan beaga, ach is dòcha nach fhiach sin a dhèanamh.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// Cuir `other` ris fhèin agus tillidh e an iomradh gluasadach fhèin.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// A `toirt air falbh `other` bhuaithe fhèin agus a` tilleadh a iomradh gluasadach fhèin.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// Ag iomadachadh fhèin le `other` de mheud didseatach agus a `tilleadh an iomradh gluasadach fhèin.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// Ag iomadachadh fhèin le `2^bits` agus a `tilleadh an iomradh gluasadach fhèin.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // gluasad le pìosan `digits * digitbits`
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // gluasad le pìosan `bits`
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // tha self.base [.. àireamhan] neoni, chan eil feum air gluasad
                }

                self.size = sz;
                self
            }

            /// Ag iomadachadh fhèin le `5^e` agus a `tilleadh an iomradh gluasadach fhèin.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // Tha dìreach neros trailing air 2 ^ n, agus is e na h-aon mheudan digit buntainneach cumhachdan leantainneach de dhà, agus mar sin tha seo na chlàr-amais freagarrach airson a `chlàr.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // Dèan iomadachadh leis a `chumhachd aon-fhigearach as motha cho fad` s a ghabhas ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... an uairsin cuir crìoch air a `chòrr.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// Ag iomadachadh fhèin le àireamh a chaidh a mhìneachadh le `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (far a bheil `W` mar an àireamh de bhuillean san t-seòrsa digit) agus a `tilleadh an iomradh gluasadach fhèin.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // an cleachdadh a-staigh.ag obair as fheàrr nuair a tha aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// A `roinn e fhèin le `other` de mheud didseatach agus a` tilleadh a iomradh gluasadach fhèin *agus* an còrr.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// Roinn fèin le bignum eile, a `sgrìobhadh thairis `q` leis a` choinnlear agus `r` leis a `chòrr.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // Roinn fhada slaodach base-2 air a thoirt bho
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME a `cleachdadh bunait nas motha ($ty) airson an roinn fhada.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Suidhich pìos `i` de q gu 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// An seòrsa digit airson `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// tha am fear seo air a chleachdadh airson deuchainn a-mhàin.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}