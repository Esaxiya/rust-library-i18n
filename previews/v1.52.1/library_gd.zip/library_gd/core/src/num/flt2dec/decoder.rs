//! A `còdachadh luach puing fleòdraidh gu pàirtean fa leth agus raointean mearachd.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Luach crìochnaichte gun ainm air a chòdachadh, mar sin:
///
/// - Tha an luach tùsail co-ionann ri `mant * 2^exp`.
///
/// - Cruinnichidh àireamh sam bith bho `(mant - minus)*2^exp` gu `(mant + plus)* 2^exp` chun luach tùsail.
/// Tha an raon in-ghabhaltach a-mhàin nuair a tha `inclusive` `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// An mantissa sgèile.
    pub mant: u64,
    /// An raon mearachd as ìsle.
    pub minus: u64,
    /// An raon mearachd àrd.
    pub plus: u64,
    /// An taisbeanair co-roinnte ann am bonn 2.
    pub exp: i16,
    /// Fìor nuair a tha an raon mearachd in-ghabhalach.
    ///
    /// Ann an IEEE 754, tha seo fìor nuair a bha am mantissa tùsail eadhon.
    pub inclusive: bool,
}

/// Luach gun chòd air a chòdachadh.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinities, an dara cuid adhartach no àicheil.
    Infinite,
    /// Zero, an dara cuid adhartach no àicheil.
    Zero,
    /// Àireamhan crìochnaichte le tuilleadh raointean air an còdachadh.
    Finite(Decoded),
}

/// Seòrsa puing fleòdraidh a dh `fhaodas a bhith` decode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// An luach àbhaisteach àbhaisteach as ìsle.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// A `tilleadh soidhne (fìor nuair a tha e àicheil) agus luach `FullDecoded` bho àireamh puing fleòdraidh a chaidh a thoirt seachad.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // nàbaidhean: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode an-còmhnaidh a `gleidheadh an taisbeanair, agus mar sin tha am mantissa air a sgèileachadh airson subnormals.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // nàbaidhean: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // far a bheil maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // nàbaidhean: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}