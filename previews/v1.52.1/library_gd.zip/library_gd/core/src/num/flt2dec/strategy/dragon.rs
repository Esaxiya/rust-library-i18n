//! Eadar-theangachadh Rust cha mhòr dìreach (ach beagan leasaichte) de Figear 3 de "Clò-bhualadh Àireamhan Puing-fleòdraidh gu sgiobalta agus gu pongail" [^ 1].
//!
//!
//! [^1]: Burger, RG agus Dybvig, RK 1996. Clò-bhualadh àireamhan àite-fleòdraidh
//!   gu sgiobalta agus gu ceart.SIGPLAN Chan eil.31, 5 (Cèitean. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// arrays precalculated de `Digit`s airson 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// nach gabh a chleachdadh ach nuair a tha `x < 16 * scale`;Bu chòir `scaleN` a bhith `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// An gnìomh modh as giorra airson Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // tha fios gu bheil an àireamh `v` gu cruth:
    // - co-ionann ri `mant * 2^exp`;
    // - roimhe le `(mant - 2 *minus)* 2^exp` anns an t-seòrsa tùsail;agus
    // - air a leantainn le `(mant + 2 *plus)* 2^exp` anns an t-seòrsa tùsail.
    //
    // gu follaiseach, chan urrainn `minus` agus `plus` a bhith neoni.(airson neo-bhuadhan, bidh sinn a `cleachdadh luachan taobh a-muigh raon.) cuideachd tha sinn a` gabhail ris gu bheil co-dhiù aon digit air a chruthachadh, ie, chan urrainn dha `mant` a bhith neoni cuideachd.
    //
    // tha seo cuideachd a `ciallachadh gum bi àireamh sam bith eadar `low = (mant - minus)*2^exp` agus `high = (mant + plus)* 2^exp` a` mapadh chun dearbh àireamh puing fleòdraidh seo, le crìochan air an toirt a-steach nuair a bha am mantissa tùsail eadhon (ie, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` tha `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // dèan tuairmse air `k_0` bho chuir a-steach tùsail a `sàsachadh `10^(k_0-1) < high <= 10^(k_0+1)`.
    // tha an `k` ceangailte teann a `sàsachadh `10^(k-1) < high <= 10^k` air a thomhas nas fhaide air adhart.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // tionndaidh `{mant, plus, minus} * 2^exp` gu cruth bloighteach gus:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // roinn `mant` le `10^k`.a-nis `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // fixup nuair `mant + plus > scale` (no `>=`).
    // chan eil sinn gu dearbh ag atharrachadh `scale`, oir is urrainn dhuinn an iomadachadh tùsail a sgiobadh na àite.
    // a-nis `scale < mant + plus <= scale * 10` agus tha sinn deiseil airson àireamhan a ghineadh.
    //
    // toirt fa-near gum faod `d[0]` * a bhith neoni, nuair a `scale - plus < mant < scale`.
    // anns a `chùis seo thèid suidheachadh cruinneachaidh (`up` gu h-ìosal) a bhrosnachadh sa bhad.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // co-ionann ri sgèileadh `scale` ro 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // tasgadan `(2, 4, 8) * scale` airson gineadh digit.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariants, far a bheil `d[0..n-1]` nan àireamhan air an gineadh gu ruige seo:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (mar sin `mant / scale < 10`) far a bheil `d[i..j]` na làmh-ghoirid airson `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // cruthaich aon dhigit: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // is e seo tuairisgeul nas sìmplidhe den algorithm Dragon atharraichte.
        // tha mòran argamaidean eadar-mheadhanach agus iomlanachd air an fàgail air falbh airson goireasachd.
        //
        // tòiseachadh le invariants atharraichte, mar a tha sinn air `n` ùrachadh:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // a `gabhail ris gur e `d[0..n-1]` an riochdachadh as giorra eadar `low` agus `high`, ie, tha `d[0..n-1]` a` sàsachadh an dà rud a leanas ach chan eil `d[0..n-2]`:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: àireamhan timcheall gu `v`);agus
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (tha an digit mu dheireadh ceart).
        //
        // tha an dàrna suidheachadh a `sìmpleachadh gu `2 * mant <= scale`.
        // tha fuasgladh invariants a thaobh `mant`, `low` agus `high` a `toirt a-mach dreach nas sìmplidh den chiad chumha: `-plus < mant < minus`.
        // bho `-plus < 0 <= mant`, tha an riochdachadh as giorra ceart againn nuair a tha `mant < minus` agus `2 * mant <= scale`.
        // (bidh an tè mu dheireadh a `fàs `mant <= minus` nuair a bhios am mantissa tùsail eadhon.)
        //
        // nuair nach eil an dàrna fear (`2 * mant> scale`), feumaidh sinn an àireamh mu dheireadh a mheudachadh.
        // tha seo gu leòr airson a `chumha sin ath-nuadhachadh: tha fios againn mu thràth gu bheil an ginealach digit a` gealltainn `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // anns a `chùis seo, thig a` chiad chumha gu bhith `-plus < mant - scale < minus`.
        // bho `mant < scale` às deidh a `ghinealaich, tha `scale < mant + plus` againn.
        // (a-rithist, thig seo gu bhith `scale <= mant + plus` nuair a bhios an mantissa tùsail eadhon.)
        //
        // ann an ùine ghoirid:
        // - stad agus timcheall `down` (cùm àireamhan mar a tha) nuair a `mant < minus` (no `<=`).
        // - stad agus timcheall `up` (àrdaich an àireamh mu dheireadh) nuair a bhios `scale < mant + plus` (no `<=`).
        // - cùm a `gineadh a chaochladh.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // tha an riochdachadh as giorra againn, lean air adhart chun chuairteachadh

        // cuir air ais na h-invariants.
        // bidh seo a `dèanamh an algairim an-còmhnaidh a` tighinn gu crìch: tha `minus` agus `plus` an-còmhnaidh a `meudachadh, ach tha `mant` air a bhearradh modulo `scale` agus `scale` stèidhichte.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // bidh cruinneachadh a `tachairt nuair a bhios i) dìreach an suidheachadh cruinneachaidh air a phiobrachadh, no ii) chaidh an dà shuidheachadh a phiobrachadh agus is fheàrr le briseadh ceangail a bhith cruinn.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // ma tha an cruinneachadh cruinn ag atharrachadh an fhaid, bu chòir don neach-nochdaidh atharrachadh cuideachd.
        // tha e coltach gu bheil an suidheachadh seo gu math duilich a shàsachadh (is dòcha do-dhèanta), ach tha sinn dìreach a bhith sàbhailte agus cunbhalach an seo.
        //
        // SÀBHAILTEACHD: thòisich sinn a `chuimhne sin gu h-àrd.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // SÀBHAILTEACHD: thòisich sinn a `chuimhne sin gu h-àrd.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Gnìomhachadh modh mionaideach agus stèidhichte airson Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // dèan tuairmse air `k_0` bho chuir a-steach tùsail a `sàsachadh `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // roinn `mant` le `10^k`.a-nis `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // fixup nuair `mant + plus >= scale`, far a bheil `plus / scale = 10^-buf.len() / 2`.
    // gus am bignum meud stèidhichte a chumail, bidh sinn a `cleachdadh `mant + floor(plus) >= scale`.
    // chan eil sinn gu dearbh ag atharrachadh `scale`, oir is urrainn dhuinn an iomadachadh tùsail a sgiobadh na àite.
    // a-rithist leis an algorithm as giorra, faodaidh `d[0]` a bhith neoni ach thèid a thoirt gu crìch mu dheireadh.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // co-ionann ri sgèileadh `scale` ro 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // ma tha sinn ag obair leis a `chuingealachadh mu dheireadh de dhidseat, feumaidh sinn am bufair a ghiorrachadh mus tèid an toirt seachad fhèin gus a bhith a` seachnadh cuairteachadh dùbailte.
    //
    // thoir an aire gum feum sinn am bufair a leudachadh a-rithist nuair a bhios an cruinneachadh cruinn!
    let mut len = if k < limit {
        // oops, chan urrainn dhuinn eadhon *aon* digit a thoirt a-mach.
        // tha seo comasach nuair, can, tha rudeigin mar 9.5 againn agus thathas ga chuairteachadh gu 10.
        // bidh sinn a `tilleadh bufair falamh, ach a-mhàin an cùis cruinneachaidh nas fhaide air adhart a bhios a` tachairt nuair a bhios `k == limit` agus a dh `fheumas a bhith a` dèanamh dìreach aon dhigit.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // tasgadan `(2, 4, 8) * scale` airson gineadh digit.
        // (faodaidh seo a bhith daor, mar sin na dèan cunntas orra nuair a tha am bufair falamh.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // is e neoni a th `ann an àireamhan a leanas, bidh sinn a` stad an seo na dèan *cha bhith* a `feuchainn ri cruinneachadh!an àite, lìon na h-àireamhan a tha air fhàgail.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // SÀBHAILTEACHD: thòisich sinn a `chuimhne sin gu h-àrd.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // a `cruinneachadh ma stadas sinn ann am meadhan àireamhan ma tha na h-àireamhan a leanas dìreach 5000 ..., thoir sùil air a` dhigit roimhe agus feuch ri cruinneachadh gu eadhon (ie, seachain cruinneachadh nuair a tha an digit roimhe eadhon).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // SÀBHAILTEACHD: Tha `buf[len-1]` air a thòiseachadh.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // ma tha an cruinneachadh cruinn ag atharrachadh an fhaid, bu chòir don neach-nochdaidh atharrachadh cuideachd.
        // ach chaidh àireamh shuidhichte de dh `àireamhan iarraidh oirnn, mar sin na atharraich am bufair ...
        // SÀBHAILTEACHD: thòisich sinn a `chuimhne sin gu h-àrd.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... mura h-iarr sinn an mionaideachd stèidhichte na àite.
            // feumaidh sinn cuideachd dèanamh cinnteach, ma bha am bufair tùsail falamh, nach gabh an digit a bharrachd a chur ris ach nuair a tha `k == limit` (cùis edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // SÀBHAILTEACHD: thòisich sinn a `chuimhne sin gu h-àrd.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}