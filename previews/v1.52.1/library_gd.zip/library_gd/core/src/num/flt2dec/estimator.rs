//! An neach-tomhais tuairmseach.

/// A `lorg `k_0` leithid `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)`.
///
/// Tha seo air a chleachdadh gus tuairmseach `k = ceil(log_10 (mant * 2^exp))`;
/// is e an fhìor `k` an dàrna cuid `k_0` no `k_0+1`.
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <mant <=2 ^ nbits ma mant> 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2) mar sin tha seo an-còmhnaidh a `dèanamh dì-meas (no dìreach), ach chan eil mòran.
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}