//! Constants a tha sònraichte don t-seòrsa puing fleòdraidh dà-chruinneas `f64`.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! Gheibhear àireamhan a tha cudromach gu matamataigeach anns an fho-mhodal `consts`.
//!
//! Airson na h-ìmpirean a tha air am mìneachadh gu dìreach anns a `mhodal seo (seach eadar-dhealaichte bhon fheadhainn a tha air am mìneachadh ann am fo-mhodal `consts`), bu chòir còd ùr a bhith a` cleachdadh na h-ìmpirean co-cheangailte a tha air am mìneachadh gu dìreach air an t-seòrsa `f64`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Radix no bonn an riochdachadh a-staigh de `f64`.
/// Cleachd [`f64::RADIX`] na àite.
///
/// # Examples
///
/// ```rust
/// // dòigh air a mholadh
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // dòigh san amharc
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// Àireamh de dh `àireamhan mòra ann am bonn 2.
/// Cleachd [`f64::MANTISSA_DIGITS`] na àite.
///
/// # Examples
///
/// ```rust
/// // dòigh air a mholadh
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // dòigh san amharc
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// Àireamh tuairmseach de dh `àireamhan mòra ann am bonn 10.
/// Cleachd [`f64::DIGITS`] na àite.
///
/// # Examples
///
/// ```rust
/// // dòigh air a mholadh
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // dòigh san amharc
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] luach airson `f64`.
/// Cleachd [`f64::EPSILON`] na àite.
///
/// Is e seo an eadar-dhealachadh eadar `1.0` agus an ath àireamh riochdachail nas motha.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // dòigh air a mholadh
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // dòigh san amharc
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// Luach `f64` crìochnaichte as lugha.
/// Cleachd [`f64::MIN`] na àite.
///
/// # Examples
///
/// ```rust
/// // dòigh air a mholadh
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // dòigh san amharc
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// An luach `f64` àbhaisteach as lugha dearbhach.
/// Cleachd [`f64::MIN_POSITIVE`] na àite.
///
/// # Examples
///
/// ```rust
/// // dòigh air a mholadh
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // dòigh san amharc
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// An luach crìochnachaidh `f64` as motha.
/// Cleachd [`f64::MAX`] na àite.
///
/// # Examples
///
/// ```rust
/// // dòigh air a mholadh
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // dòigh san amharc
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// Aon nas motha na an cumhachd àbhaisteach as ìsle as urrainn 2 neach-taisbeanaidh.
/// Cleachd [`f64::MIN_EXP`] na àite.
///
/// # Examples
///
/// ```rust
/// // dòigh air a mholadh
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // dòigh san amharc
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// Cumhachd as àirde as urrainn 2 neach-taisbeanaidh.
/// Cleachd [`f64::MAX_EXP`] na àite.
///
/// # Examples
///
/// ```rust
/// // dòigh air a mholadh
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // dòigh san amharc
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// Cumhachd àbhaisteach as ìsle a ghabhas dèanamh de 10 exponent.
/// Cleachd [`f64::MIN_10_EXP`] na àite.
///
/// # Examples
///
/// ```rust
/// // dòigh air a mholadh
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // dòigh san amharc
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// Cumhachd as àirde a ghabhas a thoirt seachad de 10 exponent.
/// Cleachd [`f64::MAX_10_EXP`] na àite.
///
/// # Examples
///
/// ```rust
/// // dòigh air a mholadh
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // dòigh san amharc
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// Chan e Àireamh (NaN).
/// Cleachd [`f64::NAN`] na àite.
///
/// # Examples
///
/// ```rust
/// // dòigh air a mholadh
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // dòigh san amharc
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infinity (∞).
/// Cleachd [`f64::INFINITY`] na àite.
///
/// # Examples
///
/// ```rust
/// // dòigh air a mholadh
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // dòigh san amharc
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// Infinity àicheil (−∞).
/// Cleachd [`f64::NEG_INFINITY`] na àite.
///
/// # Examples
///
/// ```rust
/// // dòigh air a mholadh
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // dòigh san amharc
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// Ìrean matamataigeach bunaiteach.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: cuir a-steach stuth seasmhach matamataigeach bho cmath.

    /// Seasmhach (π) aig Archimedes
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// An cearcall làn seasmhach (τ)
    ///
    /// Co-ionann ri 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// Àireamh Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// Radix no bonn an riochdachadh a-staigh de `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Àireamh de dh `àireamhan mòra ann am bonn 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// Àireamh tuairmseach de dh `àireamhan mòra ann am bonn 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] luach airson `f64`.
    ///
    /// Is e seo an eadar-dhealachadh eadar `1.0` agus an ath àireamh riochdachail nas motha.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// Luach `f64` crìochnaichte as lugha.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// An luach `f64` àbhaisteach as lugha dearbhach.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// An luach crìochnachaidh `f64` as motha.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// Aon nas motha na an cumhachd àbhaisteach as ìsle as urrainn 2 neach-taisbeanaidh.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// Cumhachd as àirde as urrainn 2 neach-taisbeanaidh.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// Cumhachd àbhaisteach as ìsle a ghabhas dèanamh de 10 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// Cumhachd as àirde a ghabhas a thoirt seachad de 10 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// Chan e Àireamh (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// Infinity àicheil (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// A `tilleadh `true` mas e an luach seo `NaN`.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): Chan eil `abs` ri fhaighinn gu poblach ann an libcore air sgàth draghan mu dheidhinn comas giùlain, mar sin tha am buileachadh seo airson cleachdadh prìobhaideach air an taobh a-staigh.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// A `tilleadh `true` ma tha an luach seo mar in-ghabhaltachd adhartach no in-fhilleadh àicheil, agus `false` air dhòigh eile.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// A `tilleadh `true` mura h-eil an àireamh seo neo-chrìochnach no `NaN`.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Cha bhith feum air NaN a làimhseachadh air leth: mas e NaN a th `annad fhèin, chan eil an coimeas fìor, dìreach mar a thathar ag iarraidh.
        //
        self.abs_private() < Self::INFINITY
    }

    /// A `tilleadh `true` mas e an àireamh [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // Tha luachan eadar `0` agus `min` neo-àbhaisteach.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// A `tilleadh `true` mura h-eil an àireamh neoni, neo-chrìochnach, [subnormal], no `NaN`.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // Tha luachan eadar `0` agus `min` neo-àbhaisteach.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// A `tilleadh roinn puing fleòdraidh na h-àireimh.
    /// Mura h-eil ach aon togalach gu bhith air a dhearbhadh, mar as trice tha e nas luaithe an predicate sònraichte a chleachdadh na àite.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// A `tilleadh `true` ma tha soidhne adhartach aig `self`, a` toirt a-steach `+0.0`, `NaN`s le pìos soidhne adhartach agus in-ghnè adhartach.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// A `tilleadh `true` ma tha soidhne àicheil aig `self`, a` toirt a-steach `-0.0`, `NaN`s le pìos soidhne àicheil agus Infinity àicheil.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// A `toirt an (inverse) cómhalach de àireamh, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// Bidh e ag atharrachadh radian gu ìrean.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // Tha an sgaradh an seo air a chuairteachadh gu ceart a thaobh fìor luach 180/π.
        // (Tha seo eadar-dhealaichte bho f32, far am feumar seasmhach a chleachdadh gus dèanamh cinnteach à toradh cruinn.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// Bidh e ag atharrachadh ìrean gu radian.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// A `tilleadh an dà àireamh as àirde.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Mas e NaN aon de na h-argamaidean, thèid an argamaid eile a thilleadh.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// A `tilleadh an ìre as lugha den dà àireamh.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Mas e NaN aon de na h-argamaidean, thèid an argamaid eile a thilleadh.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// A `dol a dh` ionnsaigh neoni agus ag atharrachadh gu seòrsa iomlan prìomhaideach, a `gabhail ris gu bheil an luach crìochnaichte agus a` freagairt san t-seòrsa sin.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Feumaidh an luach:
    ///
    /// * Na bi `NaN`
    /// * Na bi neo-chrìochnach
    /// * A bhith riochdachail anns an t-seòrsa tilleadh `Int`, às deidh a bhith a `briseadh dheth a` phàirt bhloigh aige
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `FloatToInt::to_int_unchecked` a chumail suas.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Transmutation amh gu `u64`.
    ///
    /// Tha seo an-dràsta co-ionann ri `transmute::<f64, u64>(self)` air gach àrd-ùrlar.
    ///
    /// Faic `from_bits` airson beagan deasbaid mu dheidhinn comas giùlain na h-obrach seo (cha mhòr nach eil cùisean ann).
    ///
    /// Thoir fa-near gu bheil an gnìomh seo eadar-dhealaichte bho thilgeadh `as`, a bhios a `feuchainn ris an luach *àireamhach* a ghleidheadh, agus chan e an luach bitwise.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() nach tilgeadh!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // SÀBHAILTEACHD: Tha `u64` na sheann datatype sìmplidh gus an urrainn dhuinn daonnan gluasad thuige
        unsafe { mem::transmute(self) }
    }

    /// Transmutation amh bho `u64`.
    ///
    /// Tha seo an-dràsta co-ionann ri `transmute::<u64, f64>(v)` air gach àrd-ùrlar.
    /// Tha e coltach gu bheil seo so-ghiùlain, airson dà adhbhar:
    ///
    /// * Tha an aon chrìoch aig Floats and Ints air gach àrd-ùrlar le taic.
    /// * Tha IEEE-754 gu mionaideach a `sònrachadh cruth beagan fhlùraichean.
    ///
    /// Ach tha aon caveat ann: ron dreach 2008 de IEEE-754, cha deach mar a mhìnicheadh tu am pìos soidhne NaN.
    /// Thagh a `mhòr-chuid de àrd-ùrlaran (gu sònraichte x86 agus ARM) am mìneachadh a chaidh a riaghailteachadh aig a` cheann thall ann an 2008, ach cha do rinn cuid (gu sònraichte MIPS).
    /// Mar thoradh air an sin, tha a h-uile NaN a tha a `comharrachadh air MIPS nan NaNan sàmhach air x86, agus a chaochladh.
    ///
    /// An àite a bhith a `feuchainn ri tar-àrd-ùrlar soidhne-ness a ghlèidheadh, is fheàrr leis a` bhuileachadh seo na dearbh bhuillean a ghleidheadh.
    /// Tha seo a `ciallachadh gun tèid luchdan pàighidh sam bith a chaidh a chòdachadh ann an NaN a ghleidheadh eadhon ged a thèid toradh an dòigh seo a chuir thairis air an lìonra bho inneal x86 gu fear MIPS.
    ///
    ///
    /// Mura h-eil toraidhean an dòigh seo air an làimhseachadh ach leis an aon ailtireachd a thug gu buil iad, chan eil dragh sam bith ann mu dheidhinn comas giùlain.
    ///
    /// Mura h-eil NaN air a chuir a-steach, chan eil dragh sam bith ann mu dheidhinn comas giùlain.
    ///
    /// Mura h-eil thu coma mu dheidhinn soidhneadh (glè choltach), chan eil dragh sam bith ann mu dheidhinn comas giùlain.
    ///
    /// Thoir fa-near gu bheil an gnìomh seo eadar-dhealaichte bho thilgeadh `as`, a bhios a `feuchainn ris an luach *àireamhach* a ghleidheadh, agus chan e an luach bitwise.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // SÀBHAILTEACHD: Tha `u64` na sheann datatype sìmplidh gus an urrainn dhuinn daonnan gluasad bhuaithe
        // Tha e a `tionndadh a-mach gun robh na cùisean sàbhailteachd le sNaN air an toirt thairis!Hooray!
        unsafe { mem::transmute(v) }
    }

    /// Thoir air ais riochdachadh cuimhne na h-àireimh puing fleòdraidh seo mar raon byte ann an òrdugh byte (network) mòr-endian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// Thoir air ais riochdachadh cuimhne na h-àireimh puing fleòdraidh seo mar raon byte ann an òrdugh byte beag-endian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// Thoir air ais riochdachadh cuimhne na h-àireimh puing fleòdraidh seo mar raon byte ann an òrdugh byte dùthchasach.
    ///
    /// Leis gu bheil seasmhachd dùthchasach an àrd-ùrlar targaid air a chleachdadh, bu chòir còd so-ghiùlain [`to_be_bytes`] no [`to_le_bytes`] a chleachdadh, mar a bhios iomchaidh, na àite.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// Thoir air ais riochdachadh cuimhne na h-àireimh puing fleòdraidh seo mar raon byte ann an òrdugh byte dùthchasach.
    ///
    ///
    /// [`to_ne_bytes`] bu chòir seo a bhith nas fheàrr na seo far a bheil sin comasach.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // SÀBHAILTEACHD: Tha `f64` na sheann datatype sìmplidh gus an urrainn dhuinn daonnan gluasad thuige
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Cruthaich luach puing fleòdraidh bhon riochdachadh aige mar raon byte ann an endian mòr.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// Cruthaich luach puing fleòdraidh bhon riochdachadh aige mar raon byte ann an glè bheag de endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// Cruthaich luach puing fleòdraidh bhon riochdachadh aige mar raon byte ann an endian dùthchasach.
    ///
    /// Leis gu bheil seasmhachd dùthchasach an àrd-ùrlar targaid air a chleachdadh, tha coltas ann gu bheil còd so-ghiùlain ag iarraidh [`from_be_bytes`] no [`from_le_bytes`] a chleachdadh, mar a bhios iomchaidh.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// A `tilleadh òrdugh eadar thu fhèin agus luachan eile.
    /// Eu-coltach ris a `choimeas pàirt àbhaisteach eadar àireamhan puing fleòdraidh, bidh an coimeas seo an-còmhnaidh a` toirt a-mach òrdugh a rèir ro-aithris totalOrder mar a tha air a mhìneachadh ann an inbhe puing fleòdraidh IEEE 754 (ath-sgrùdadh 2008).
    /// Tha na luachan air an òrdachadh anns an òrdugh a leanas:
    /// - NaN sàmhach àicheil
    /// - Comharradh àicheil NaN
    /// - Infinity àicheil
    /// - Àireamhan àicheil
    /// - Àireamhan subnormal àicheil
    /// - Neoni àicheil
    /// - Neoni adhartach
    /// - Àireamhan adhartach subnormal
    /// - Àireamhan adhartach
    /// - Inbheachd adhartach
    /// - Comharradh adhartach NaN
    /// - NaN sàmhach adhartach
    ///
    /// Thoir fa-near nach eil an gnìomh seo an-còmhnaidh ag aontachadh le buileachadh [`PartialOrd`] agus [`PartialEq`] de `f64`.Gu sònraichte, tha iad a `faicinn neoni àicheil is deimhinneach co-ionann, ged nach eil `total_cmp` idir.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // Ann an cùis àicheil, flip air na buillean gu lèir ach a-mhàin an soidhne gus cruth coltach ri chèile a choileanadh mar integers lìonaidh dithis
        //
        // Carson a tha seo ag obair?Tha trì raointean ann am flotaichean IEEE 754:
        // Cuir a-steach pìos, exponent agus mantissa.Tha seilbh aig an t-seata de raointean exponent agus mantissa gu h-iomlan gu bheil an òrdugh bitwise aca co-ionann ris an meud àireamhach far a bheil am meud air a mhìneachadh.
        // Mar as trice chan eil am meud air a mhìneachadh air luachan NaN, ach tha IEEE 754 totalOrder a `mìneachadh luachan NaN cuideachd gus an òrdugh bitwise a leantainn.Bidh seo a`leantainn gu òrdugh a chaidh a mhìneachadh anns a` bheachd doc.
        // Ach, tha riochdachadh meudachd an aon rud airson àireamhan àicheil is adhartach-chan eil ach am pìos soidhne eadar-dhealaichte.
        // Gus coimeas a dhèanamh eadar na flotaichean gu furasta mar integers soidhnichte, feumaidh sinn na pìosan exponent agus mantissa a thionndadh gun fhios nach bi àireamhan àicheil ann.
        // Bidh sinn gu h-èifeachdach a `tionndadh na h-àireamhan gu cruth "two's complement".
        //
        // Gus am flipping a dhèanamh, bidh sinn a `togail masg agus XOR na aghaidh.
        // Bidh sinn gun mheur a `tomhas masg "all-ones except for the sign bit" bho luachan le soidhne àicheil: soidhne gluasad ceart-a` leudachadh an integer, agus mar sin bidh sinn "fill" an masg le buillean soidhne, agus an uairsin ag atharrachadh gu gun ainm gus aon bhuille neoni eile a phutadh.
        //
        // Air luachan adhartach, is e neoni a th `anns a` masg, mar sin is e neo-op a th `ann.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// Cuir luach sìos gu àm sònraichte mura h-e NaN a th `ann.
    ///
    /// TILLEADH `max` ma `self` nas motha na `max`, agus `min` `self` ma tha nas lugha na `min`.
    /// Air neo bidh seo a `tilleadh `self`.
    ///
    /// Thoir fa-near gu bheil an gnìomh seo a `tilleadh NaN nam b` e NaN an luach tùsail cuideachd.
    ///
    /// # Panics
    ///
    /// Panics ma tha `min > max`, `min` naN, no `max` na NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}