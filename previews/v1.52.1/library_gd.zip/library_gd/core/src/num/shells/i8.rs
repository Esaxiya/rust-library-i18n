//! Constants airson an seòrsa integer soidhnichte 8-bit.
//!
//! *[See also the `i8` primitive type][i8].*
//!
//! Bu chòir do chòd ùr na cungaidhean co-cheangailte a chleachdadh gu dìreach air an t-seòrsa prìomhadail.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i8`"
)]

int_module! { i8 }