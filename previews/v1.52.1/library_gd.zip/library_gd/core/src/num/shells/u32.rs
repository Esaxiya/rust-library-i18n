//! Constants airson an seòrsa integer 32-bit gun ainm.
//!
//! *[See also the `u32` primitive type][u32].*
//!
//! Bu chòir do chòd ùr na cungaidhean co-cheangailte a chleachdadh gu dìreach air an t-seòrsa prìomhadail.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u32`"
)]

int_module! { u32 }