//! Tairgsean airson an seòrsa integer soidhnichte de mheud puing.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Bu chòir do chòd ùr na cungaidhean co-cheangailte a chleachdadh gu dìreach air an t-seòrsa prìomhadail.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }