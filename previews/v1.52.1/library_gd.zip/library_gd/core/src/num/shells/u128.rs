//! Constants airson an seòrsa integer 128-bit gun ainm.
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! Bu chòir do chòd ùr na cungaidhean co-cheangailte a chleachdadh gu dìreach air an t-seòrsa prìomhadail.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }