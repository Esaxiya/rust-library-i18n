//! Constants airson an seòrsa integer soidhnichte 32-bit.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! Bu chòir do chòd ùr na cungaidhean co-cheangailte a chleachdadh gu dìreach air an t-seòrsa prìomhadail.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }