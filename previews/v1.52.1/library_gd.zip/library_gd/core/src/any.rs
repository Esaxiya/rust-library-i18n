//! Bidh am modal seo a `buileachadh an `Any` trait, a leigeas le taipeadh fiùghantach de sheòrsa `'static` sam bith tro mheòrachadh runtime.
//!
//! `Any` faodar fhèin a chleachdadh gus `TypeId` fhaighinn, agus tha barrachd fheartan aige nuair a thèid a chleachdadh mar stuth trait.
//! Mar `&dyn Any` (rud trait air iasad), tha na modhan `is` agus `downcast_ref` aige, gus deuchainn a dhèanamh a bheil an luach a tha ann de sheòrsa sònraichte, agus gus iomradh fhaighinn air an luach a-staigh mar sheòrsa.
//! Mar `&mut dyn Any`, tha an dòigh `downcast_mut` ann cuideachd, airson a bhith a `faighinn iomradh gluasadach air an luach a-staigh.
//! `Box<dyn Any>` a `cur ris an dòigh `downcast`, a bhios a` feuchainn ri tionndadh gu `Box<T>`.
//! Faic na sgrìobhainnean [`Box`] airson an làn fhiosrachadh.
//!
//! Thoir fa-near gu bheil `&dyn Any` cuingealaichte ri bhith a `dèanamh deuchainn a bheil luach de sheòrsa cruadhtan ainmichte, agus nach gabh a chleachdadh gus dearbhadh a bheil seòrsa a` cur an gnìomh trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Molaidhean glic agus `dyn Any`
//!
//! Is e aon phìos giùlain a bu chòir a chumail nad inntinn nuair a bhios tu a `cleachdadh `Any` mar rud trait, gu sònraichte le seòrsachan mar `Box<dyn Any>` no `Arc<dyn Any>`, is e dìreach a bhith a` gairm `.type_id()` air an luach a bheir toradh an `TypeId` den *container*, chan e an rud trait bunaiteach.
//!
//! Faodar seo a sheachnadh le bhith a `tionndadh a` phuing smart gu `&dyn Any` na àite, a thilleas `TypeId` an nì.
//! Mar eisimpleir:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Tha thu nas dualtaiche a bhith ag iarraidh seo:
//! let actual_id = (&*boxed).type_id();
//! // ... na seo:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Beachdaich air suidheachadh far a bheil sinn airson luach a chuir a-mach gu gnìomh a chlàradh a-mach.
//! Tha fios againn dè an luach a tha sinn ag obair air Debug a chuir an gnìomh, ach chan eil fios againn dè an seòrsa cruadhtan a th `ann.Tha sinn airson làimhseachadh sònraichte a thoirt do sheòrsan sònraichte: anns a`chùis seo clò-bhualadh fad luachan String ron luach aca.
//! Chan eil fios againn dè an seòrsa cruadhtan de ar luach aig àm cur ri chèile, agus mar sin feumaidh sinn meòrachadh runtime a chleachdadh na àite.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Gnìomh logger airson seòrsa sam bith a chuireas Debug an gnìomh.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Feuch ri ar luach a thionndadh gu `String`.
//!     // Ma tha sinn soirbheachail, tha sinn airson fad an String a thoirt a-mach a bharrachd air a luach.
//!     // Mura h-eil, is e seòrsa eadar-dhealaichte a th `ann: dìreach clò-bhuail e gun chòmhdach.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Tha an gnìomh seo airson a paramadair a chlàradh a-mach mus dèan thu obair leis.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... dèan beagan obair eile
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// trait sam bith
///////////////////////////////////////////////////////////////////////////////

/// A trait gus dealbh a dhèanamh de chlò-bhualadh fiùghantach.
///
/// Bidh a `mhòr-chuid de sheòrsan a` buileachadh `Any`.Ach, chan eil seòrsa sam bith anns a bheil iomradh neo-``statach`.
/// Faic an [module-level documentation][mod] airson tuilleadh fiosrachaidh.
///
/// [mod]: crate::any
// Chan eil an trait seo cunnartach, ged a tha sinn an urra ri mion-fhiosrachadh mu dhleastanas `type_id` an aon impl ann an còd neo-shàbhailte (me, `downcast`).Mar as trice, bhiodh sin na dhuilgheadas, ach leis gur e buileachadh plaide an aon impl de `Any`, chan urrainn do chòd sam bith eile `Any` a bhuileachadh.
//
// Dh `fhaodadh sinn an trait seo a dhèanamh mì-shàbhailte-cha bhiodh e ag adhbhrachadh briseadh, oir tha smachd againn air a h-uile buileachadh-ach tha sinn a` roghnachadh gun a bhith an dà chuid nach eil riatanach agus dh `fhaodadh sinn luchd-cleachdaidh a chuir an aghaidh eadar-dhealachadh traits mì-shàbhailte agus dòighean neo-shàbhailte (ie, Bhiodh `type_id` fhathast sàbhailte a ghairm, ach bhiodh sinn dualtach innse mar sin ann an sgrìobhainnean).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Faigh an `TypeId` de `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Modhan leudachaidh airson nithean trait sam bith.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Dèan cinnteach gum faodar toradh me, a bhith a `ceangal snàithlean a chlò-bhualadh agus mar sin a chleachdadh le `unwrap`.
// Aig a `cheann thall cha bhith feum air tuilleadh ma bhios an cur air falbh ag obair le ùrachadh.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// A `tilleadh `true` ma tha an seòrsa bogsa ann an aon rud ri `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Faigh `TypeId` den t-seòrsa sa bheil an gnìomh seo sa bhad.
        let t = TypeId::of::<T>();

        // Faigh `TypeId` den t-seòrsa anns an nì trait (`self`).
        let concrete = self.type_id();

        // Dèan coimeas eadar an dà `TypeId` air co-ionannachd.
        t == concrete
    }

    /// Tillidh e beagan iomradh air an luach bogsaichte ma tha e de sheòrsa `T`, no `None` mura h-eil e.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SÀBHAILTEACHD: dìreach dèan cinnteach a bheil sinn a `comharrachadh an seòrsa cheart, agus an urrainn dhuinn earbsa a bhith againn
            // an sgrùdadh sin airson sàbhailteachd cuimhne oir tha sinn air gin a chuir an gnìomh airson gach seòrsa;chan urrainn dha impidhean sam bith eile a bhith ann oir bhiodh iad a `dol an-aghaidh ar impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Tillidh e cuid de dh `iomradh gluasadach air an luach bogsaichte ma tha e de sheòrsa `T`, no `None` mura h-eil e.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SÀBHAILTEACHD: dìreach dèan cinnteach a bheil sinn a `comharrachadh an seòrsa cheart, agus an urrainn dhuinn earbsa a bhith againn
            // an sgrùdadh sin airson sàbhailteachd cuimhne oir tha sinn air gin a chuir an gnìomh airson gach seòrsa;chan urrainn dha impidhean sam bith eile a bhith ann oir bhiodh iad a `dol an-aghaidh ar impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Air adhart chun dòigh a tha air a mhìneachadh air an seòrsa `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Air adhart chun dòigh a tha air a mhìneachadh air an seòrsa `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Air adhart chun dòigh a tha air a mhìneachadh air an seòrsa `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Air adhart chun dòigh a tha air a mhìneachadh air an seòrsa `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Air adhart chun dòigh a tha air a mhìneachadh air an seòrsa `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Air adhart chun dòigh a tha air a mhìneachadh air an seòrsa `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID agus a dòighean
///////////////////////////////////////////////////////////////////////////////

/// A `TypeId` riochdachadh air feadh na cruinne airson aithnichear sònraichte a-seòrsa.
///
/// Tha gach `TypeId` na stuth neo-shoilleir nach leig le sgrùdadh a dhèanamh air na tha a-staigh ach a leigeas le gnìomhachd bunaiteach leithid clònadh, coimeas, clò-bhualadh agus sealltainn.
///
///
/// Chan eil `TypeId` ri fhaighinn an-dràsta ach airson seòrsachan a tha a `buntainn ri `'static`, ach faodar a` chuingealachadh seo a thoirt air falbh anns an future.
///
/// Fhad `s a tha `TypeId` a` buileachadh `Hash`, `PartialOrd`, agus `Ord`, is fhiach a bhith mothachail gum bi na luaisgean agus an òrdachadh eadar-dhealaichte eadar fiosan Rust.
/// Bi faiceallach gun cuir thu earbsa annta taobh a-staigh den chòd agad!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// A `tilleadh an `TypeId` den t-seòrsa anns a bheil an gnìomh gnèitheach seo air a thòiseachadh sa bhad.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// A `tilleadh ainm seòrsa mar sliseag sreang.
///
/// # Note
///
/// Tha seo an dùil airson cleachdadh breithneachaidh.
/// Tha dearbh th 'ann agus cruth an t-sreang thill nach eil a shònrachadh, seach a bhith as oidhirp tuairisgeul den t-seòrsa.
/// Mar eisimpleir, am measg nan teudan a dh `fhaodadh `type_name::<Option<String>>()` tilleadh tha `"Option<String>"` agus `"std::option::Option<std::string::String>"`.
///
///
/// Chan eilear den bheachd gu bheil an sreang a chaidh a thilleadh mar aithnichear sònraichte de sheòrsa oir faodaidh ioma-sheòrsa mapadh chun aon ainm den t-seòrsa.
/// San aon dòigh, chan eil gealltanas sam bith ann gum bi a h-uile pàirt de sheòrsa a `nochdadh anns an t-sreang a chaidh a thilleadh: mar eisimpleir, chan eil sònrachaidhean beatha air an toirt a-steach an-dràsta.
/// A bharrachd air an sin, faodaidh an toradh atharrachadh eadar dreachan den inneal-cruinneachaidh.
///
/// Tha an gnìomhachadh gnàthach a `cleachdadh an aon bhun-structair ri diagnosachd co-chruinneachaidh agus debuginfo, ach chan eil seo cinnteach.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// A `tilleadh ainm an seòrsa luach biorach mar sliseag sreang.
/// Tha seo an aon rud ri `type_name::<T>()`, ach faodar a chleachdadh far nach eil an seòrsa caochladair ri fhaighinn gu furasta.
///
/// # Note
///
/// Tha seo an dùil airson cleachdadh breithneachaidh.Chan eil dearbh susbaint agus cruth na sreang air a shònrachadh, ach a-mhàin a bhith na thuairisgeul oidhirp as fheàrr den t-seòrsa.
/// Mar eisimpleir, dh'fhaodadh `type_name_of_val::<Option<String>>(None)` `"Option<String>"` no `"std::option::Option<std::string::String>"` a thilleadh, ach chan e `"foobar"`.
///
/// A bharrachd air an sin, faodaidh an toradh atharrachadh eadar dreachan den inneal-cruinneachaidh.
///
/// Chan eil an gnìomh seo a `fuasgladh nithean trait, a` ciallachadh gum faod `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` a thilleadh, ach chan e `"u32"`.
///
/// Cha bu chòir ainm an t-seòrsa a mheas mar aithnichear sònraichte de sheòrsa;
/// faodaidh iomadh seòrsa an aon ainm a roinn.
///
/// Tha an gnìomhachadh gnàthach a `cleachdadh an aon bhun-structair ri diagnosachd co-chruinneachaidh agus debuginfo, ach chan eil seo cinnteach.
///
/// # Examples
///
/// Clò-bhuail an seòrsa integer bunaiteach agus seòladh.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}