/// Còd gnàthaichte taobh a-staigh an inneal-sgrios.
///
/// Nuair nach eil feum air luach tuilleadh, ruithidh Rust "destructor" air an luach sin.
/// Is e an dòigh as cumanta nach eil feum air luach tuilleadh nuair a thèid e a-mach à farsaingeachd.Faodaidh luchd-sgrios fhathast ruith ann an suidheachaidhean eile, ach tha sinn a `dol a chuimseachadh air farsaingeachd airson na h-eisimpleirean an seo.
/// Gus ionnsachadh mu chuid de na cùisean eile sin, faic roinn [the reference] air luchd-sgrios.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Tha dà phàirt anns an inneal-sgrios seo:
/// - Call gu `Drop::drop` airson an luach sin, ma tha an `Drop` trait sònraichte seo air a bhuileachadh airson an seòrsa.
/// - An "drop glue" a chaidh a chruthachadh gu fèin-ghluasadach a bhios gu ath-chuairteachail a `gairm luchd-sgrios gach raon den luach seo.
///
/// Mar a bhios Rust gu fèin-obrachail a `gairm luchd-sgrios gach raon a tha ann, cha leig thu leas `Drop` a bhuileachadh anns a` mhòr-chuid de chùisean.
/// Ach tha cuid de chùisean ann far a bheil e feumail, mar eisimpleir airson seòrsachan a bhios a `riaghladh goireas gu dìreach.
/// Is dòcha gu bheil an goireas sin mar chuimhneachan, is dòcha gur e tuairisgeul faidhle a th `ann, is dòcha gur e socaid lìonra a th` ann.
/// Cho luath `s nach tèid luach den t-seòrsa sin a chleachdadh tuilleadh, bu chòir dha "clean up" an goireas aige a shaoradh le bhith a` saoradh a `chuimhne no a` dùnadh am faidhle no an socaid.
/// Is e seo obair inneal-sgrios, agus mar sin obair `Drop::drop`.
///
/// ## Examples
///
/// Gus luchd-sgrios fhaicinn ann an gnìomh, leig dhuinn sùil a thoirt air a `phrògram a leanas:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Bidh Rust a `gairm `Drop::drop` an-toiseach airson `_x` agus an uairsin airson an dà chuid `_x.one` agus `_x.two`, a` ciallachadh gun clò-bhuail seo a `chlò-bhualadh
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Fiù ma bheir sinn air falbh gnìomhachadh `Drop` airson `HasTwoDrop`, canar luchd-sgrios nan raointean aige fhathast.
/// Bheireadh seo gu buil
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Chan urrainn dhut `Drop::drop` a ghairm thu fhèin
///
/// Leis gu bheil `Drop::drop` air a chleachdadh gus luach a ghlanadh, dh `fhaodadh gum bi e cunnartach an luach seo a chleachdadh às deidh don dòigh a bhith air a ghairm.
/// Leis nach eil `Drop::drop` a `gabhail seilbh air an in-chur a-steach, tha Rust a` cur casg air mì-chleachdadh le bhith gun a bhith a `leigeil leat `Drop::drop` a ghairm gu dìreach.
///
/// Ann am faclan eile, ma dh `fheuch thu ri `Drop::drop` a ghairm gu soilleir san eisimpleir gu h-àrd, gheibheadh tu mearachd co-chruinneachaidh.
///
/// Ma tha thu airson innse gu soilleir dè an luach a th `ann an luach, faodar [`mem::drop`] a chleachdadh na àite.
///
/// [`mem::drop`]: drop
///
/// ## Òrdugh drop
///
/// Dè an dà `HasDrop` a thuiteas oirnn an toiseach, ge-tà?Airson structaran, is e an aon òrdugh a tha iad ag ainmeachadh: an toiseach `one`, an uairsin `two`.
/// Ma tha thu airson seo fheuchainn ort fhèin, faodaidh tu `HasDrop` gu h-àrd atharrachadh gus beagan dàta a thoirt a-steach, mar integer, agus an uairsin a chleachdadh anns an `println!` taobh a-staigh de `Drop`.
/// Tha an giùlan seo cinnteach leis a `chànan.
///
/// Eu-coltach ri structaran, tha caochladairean ionadail air an leigeil sìos ann an òrdugh cas:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Thèid seo a chlò-bhualadh
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Feuch an toir thu sùil air [the reference] airson na riaghailtean iomlan.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` agus `Drop` toirmeasgach
///
/// Chan urrainn dhut an dà chuid [`Copy`] agus `Drop` a chuir an gnìomh air an aon sheòrsa.Bidh seòrsaichean a tha `Copy` a `faighinn dùblachadh gu h-obann leis an trusaiche, ga dhèanamh gu math duilich ro-innse cuin, agus dè cho tric` s a thèid luchd-sgrios a chuir gu bàs.
///
/// Mar sin, chan urrainn do luchd-sgrios a bhith aig na seòrsaichean sin.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// A `cur gu bàs an inneal-sgrios airson an seòrsa seo.
    ///
    /// Canar an dòigh seo gu h-obann nuair a thèid an luach a-mach à farsaingeachd, agus nach urrainnear a ghairm gu follaiseach (is e seo mearachd co-chruinneachaidh [E0040]).
    /// Ach, faodar an gnìomh [`mem::drop`] anns an prelude a chleachdadh gus gnìomhachadh `Drop` na h-argamaid a ghairm.
    ///
    /// Nuair a chaidh an dòigh seo a ghairm, cha deach `self` a thuigsinn fhathast.
    /// Cha tachair sin ach às deidh don dòigh a bhith seachad.
    /// Mura b `e seo a` chùis, bhiodh `self` na iomradh tarraingeach.
    ///
    /// # Panics
    ///
    /// Leis gum bi [`panic!`] a `gairm `drop` fhad` s a tha e a `falamhachadh, tha coltas ann gun tèid gin de [`panic!`] ann am buileachadh `drop`.
    ///
    /// Thoir fa-near, eadhon ma tha an panics seo, thathas den bheachd gu bheil an luach air a leigeil sìos;
    /// chan fhaod thu adhbhrachadh gun tèid `drop` a ghairm a-rithist.
    /// Mar as trice bidh an neach-cruinneachaidh a `làimhseachadh seo gu fèin-ghluasadach, ach nuair a bhios tu a` cleachdadh còd neo-shàbhailte, faodaidh e tachairt gu neo-àbhaisteach, gu sònraichte nuair a bhios tu a `cleachdadh [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}