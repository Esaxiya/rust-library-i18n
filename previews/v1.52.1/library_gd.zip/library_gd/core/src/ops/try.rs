/// A trait airson a bhith a `gnàthachadh giùlan a` ghnìomhaiche `?`.
///
/// Is e seòrsa a tha a `buileachadh `Try` aon aig a bheil dòigh canonical airson a choimhead a thaobh dichotomy success/failure.
/// Tha an trait seo a `ceadachadh an dà chuid na luachan soirbheachais no fàilligeadh sin a thoirt a-mach bho eisimpleir a th` ann agus eisimpleir ùr a chruthachadh bho luach soirbheachais no fàilligeadh.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// An seòrsa den luach seo nuair a thèid a mheas soirbheachail.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// An seòrsa den luach seo nuair a choimheadas tu air fàiligeadh.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// A `cur an gnìomh gnìomhaiche "?".Tha tilleadh `Ok(t)` a`ciallachadh gum bu chòir an cur gu bàs leantainn gu h-àbhaisteach, agus is e toradh `?` an luach `t`.
    /// Tha tilleadh `Err(e)` a `ciallachadh gum bu chòir dha cur gu bàs branch chun an taobh a-staigh a tha a` cuairteachadh `catch`, no tilleadh bhon ghnìomh.
    ///
    /// Ma thèid toradh `Err(e)` a thilleadh, is e luach `e` "wrapped" anns an t-seòrsa tilleadh den raon cuairteachaidh (a dh `fheumas e fhèin `Try` a bhuileachadh).
    ///
    /// Gu sònraichte, tha an luach `X::from_error(From::from(e))` air a thilleadh, far a bheil `X` mar an seòrsa tilleadh den ghnìomh cuairteachaidh.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Paisg luach mearachd gus an toradh co-dhèanta a thogail.
    /// Mar eisimpleir, tha `Result::Err(x)` agus `Result::from_error(x)` co-ionann.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Paisg luach ceart airson an toradh co-dhèanta a thogail.
    /// Mar eisimpleir, tha `Result::Ok(x)` agus `Result::from_ok(x)` co-ionann.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}