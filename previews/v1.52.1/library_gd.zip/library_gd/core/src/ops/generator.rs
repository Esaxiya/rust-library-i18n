use crate::marker::Unpin;
use crate::pin::Pin;

/// Toradh ath-thòiseachadh gineadair.
///
/// Tha an enum seo air a thilleadh bhon dòigh `Generator::resume` agus a `nochdadh na luachan tilleadh a dh` fhaodadh a bhith aig gineadair.
/// An-dràsta tha seo a `freagairt an dàrna cuid ri puing crochaidh (`Yielded`) no puing crìochnachaidh (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// An gineadair crochte le luach.
    ///
    /// Tha an stàit seo a `nochdadh gun deach gineadair a chuir dheth, agus mar as trice bidh e a` freagairt ri aithris `yield`.
    /// Tha an luach a chaidh a thoirt seachad san eadar-dhealachadh seo a rèir an abairt a chaidh a thoirt do `yield` agus a `leigeil le gineadairean luach a thoirt seachad gach uair a bheir iad seachad.
    ///
    ///
    Yielded(Y),

    /// Chrìochnaich an gineadair le luach tilleadh.
    ///
    /// Tha an stàit seo a `nochdadh gu bheil gineadair air crìoch a chuir gu bàs leis an luach a chaidh a thoirt seachad.
    /// Aon uair `s gu bheil gineadair air `Complete` a thilleadh tha e air a mheas mar mhearachd prògramadair `resume` a ghairm a-rithist.
    ///
    Complete(R),
}

/// An trait air a bhuileachadh le seòrsachan gineadair builtin.
///
/// Tha gineadairean, ris an canar cuideachd coroutines, an-dràsta nam feart cànain deuchainneach ann an Rust.
/// An-dràsta tha gineadairean [RFC 2033] an dùil an-dràsta a bhith a `toirt seachad bloc togail airson co-aonta async/await ach tha coltas ann gun leudaich iad gu bhith a` toirt seachad mìneachadh ergonomic airson itealain agus prìomhairean eile.
///
///
/// Tha an co-aonta agus semantics airson gineadairean neo-sheasmhach agus bidh feum air RFC eile airson seasmhachd.Aig an àm seo, ge-tà, tha an co-chòrdadh coltach ri dùnadh:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Gheibhear barrachd sgrìobhainnean de ghineadairean anns an leabhar neo-sheasmhach.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// An seòrsa luach a bheir an gineadair seo seachad.
    ///
    /// Tha an seòrsa co-cheangailte seo a `freagairt ris an abairt `yield` agus na luachan a tha ceadaichte a thilleadh gach uair a bheir gineadair a-mach.
    ///
    /// Mar eisimpleir tha e coltach gum biodh an seòrsa seo mar `T` aig iterator-as-a-generator, leis an t-seòrsa seo air ath-aithris.
    ///
    type Yield;

    /// An seòrsa luach a thilleas an gineadair seo.
    ///
    /// Tha seo a `freagairt ris an t-seòrsa a chaidh a thilleadh bho ghineadair an dàrna cuid le aithris `return` no gu h-inntinneach mar an abairt mu dheireadh de litear gineadair.
    /// Mar eisimpleir bhiodh futures a `cleachdadh seo mar `Result<T, E>` oir tha e a` riochdachadh future crìochnaichte.
    ///
    ///
    type Return;

    /// Ath-thòiseachadh coileanadh an gineadair seo.
    ///
    /// Tòisichidh an gnìomh seo gu bàs an gineadair no tòisichidh e gu bàs mura h-eil e mar-thà.
    /// Tillidh an gairm seo air ais don phuing crochaidh mu dheireadh aig a `ghineadair, ag ath-thòiseachadh gu bàs bhon `yield` as ùire.
    /// Leanaidh an gineadair a `dol an gnìomh gus an toir e toradh no tilleadh, agus aig an àm sin tillidh an gnìomh seo.
    ///
    /// # Luach tillidh
    ///
    /// Tha an enum `GeneratorState` a chaidh a thilleadh bhon ghnìomh seo a `nochdadh dè an stàit a th` aig a `ghineadair nuair a thilleas e.
    /// Ma thèid an tionndadh `Yielded` a thilleadh tha an gineadair air puing crochaidh a ruighinn agus chaidh luach a thoirt a-mach.
    /// Gheibhear gineadairean san stàit seo airson ath-thòiseachadh aig àm nas fhaide air adhart.
    ///
    /// Ma thèid `Complete` a thilleadh tha an gineadair deiseil gu tur leis an luach a chaidh a thoirt seachad.Tha e mì-dhligheach airson an gineadair a bhith air ath-thòiseachadh a-rithist.
    ///
    /// # Panics
    ///
    /// Faodaidh an gnìomh seo panic a ghairm ma thèid a ghairm an dèidh don tionndadh `Complete` a bhith air a thilleadh roimhe.
    /// Ged a tha litrichean gineadair sa chànan cinnteach gu panic nuair a thòisicheas iad às deidh `Complete`, chan eil seo cinnteach airson a h-uile buileachadh den `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}