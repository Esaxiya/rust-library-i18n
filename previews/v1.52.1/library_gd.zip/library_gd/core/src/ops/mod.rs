//! Luchd-obrachaidh cus cuideim.
//!
//! Le bhith a `buileachadh nan traits seo leigidh tu leat cus de ghnìomhaichean a luchdachadh sìos.
//!
//! Tha cuid de na traits sin air an toirt a-steach leis an prelude, agus mar sin tha iad rim faighinn anns a h-uile prògram Rust.Chan fhaod ach luchd-obrachaidh le taic bho traits a bhith air an luchdachadh cus.
//! Mar eisimpleir, faodar an gnìomhaiche cuir-ris (`+`) a luchdachadh thairis tron [`Add`] trait, ach leis nach eil taic trait aig a `ghnìomhaiche sònrachaidh (`=`), chan eil dòigh ann air a semantics a luchdachadh sìos.
//! A bharrachd air an sin, chan eil am modal seo a `toirt seachad dòigh sam bith gus gnìomhaichean ùra a chruthachadh.
//! Ma tha feum air cus luchdachadh no luchd-obrachaidh àbhaisteach, bu chòir dhut coimhead a dh `ionnsaigh macros no plugins compiler gus co-chòrdadh Rust a leudachadh.
//!
//! Cha bu chòir iongnadh a bhith air buileachadh gnìomhaiche traits anns na co-theacsan aca, a `cumail cuimhne air na ciall àbhaisteach aca agus [operator precedence].
//! Mar eisimpleir, nuair a bhios tu a `cur [`Mul`] an gnìomh, bu chòir gum biodh an obair rudeigin coltach ri iomadachadh (agus a bhith a` roinn thogalaichean ris a bheil dùil mar associativity).
//!
//! Thoir fa-near gu bheil geàrr-chuairt ghnìomhaichean `&&` agus `||`, ie, cha bhith iad a `luachadh an dàrna operand aca ach ma tha e a` cur ris an toradh.Leis nach eil an giùlan seo air a chuir an gnìomh le traits, chan eil `&&` agus `||` a `faighinn taic mar ghnìomhaichean a tha ro luchdaichte.
//!
//! Bidh mòran de na gnìomhaichean a `toirt an cuid operands a rèir luach.Ann an co-theacsan neo-ghnèitheach a tha a`toirt a-steach seòrsaichean togte, mar as trice chan eil seo na dhuilgheadas.
//! Ach, le bhith a `cleachdadh na gnìomhaichean sin ann an còd coitcheann, feumar beagan aire ma feumar luachan ath-chleachdadh an àite leigeil le gnìomhaichean an ithe.Is e aon roghainn [`clone`] a chleachdadh bho àm gu àm.
//! Is e roghainn eile a bhith an urra ris na seòrsaichean a tha an sàs a `toirt seachad gnìomhaichean a bharrachd airson iomraidhean.
//! Mar eisimpleir, airson seòrsa `T` a tha air a shònrachadh le neach-cleachdaidh agus a tha còir taic a thoirt do bharrachd, is dòcha gur e deagh bheachd a th `ann an dà chuid `T` agus `&T` an traits [`Add<T>`][`Add`] agus [`Add<&T>`][`Add`] a chuir an gnìomh gus an urrainnear còd coitcheann a sgrìobhadh gun clònadh gun fheum.
//!
//!
//! # Examples
//!
//! Tha an eisimpleir seo a `cruthachadh structar `Point` a bhios a` buileachadh [`Add`] agus [`Sub`], agus an uairsin a `sealltainn cuir ris agus toirt air falbh dà` Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Faic na sgrìobhainnean airson gach trait airson eisimpleir de bhuileachadh.
//!
//! Tha an [`Fn`], [`FnMut`], agus [`FnOnce`] traits air an cur an gnìomh le seòrsaichean a dh `fhaodar a ghairm mar ghnìomhan.Thoir fa-near gu bheil [`Fn`] a`toirt `&self`, [`FnMut`] a`toirt `&mut self` agus [`FnOnce`] a`toirt `self`.
//! Tha iad sin a rèir nan trì seòrsachan dhòighean a dh'fhaodar a chleachdadh air eisimpleir: gairm-le-iomradh, gairm-às-mutable-iomradh, agus gairm-air-luach.
//! Is e an cleachdadh as cumanta de na traits seo a bhith mar chrìochan ri gnìomhan aig àrd-ìre a bhios a `gabhail ghnìomhan no a` dùnadh mar argamaidean.
//!
//! A `gabhail [`Fn`] mar pharamadair:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! A `gabhail [`FnMut`] mar pharamadair:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! A `gabhail [`FnOnce`] mar pharamadair:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` ag ithe na caochladairean a chaidh a ghlacadh, agus mar sin chan urrainnear a ruith barrachd air aon uair
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // A `feuchainn ri `func()` a chuir a-steach a-rithist tilgidh e mearachd `use of moved value` airson `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` chan urrainnear a-nis a ghairm aig an ìre seo
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;