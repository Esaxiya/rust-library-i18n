/// Air a chleachdadh airson obrachaidhean dì-cho-labhairt so-ruigsinneach, mar `*v`.
///
/// A bharrachd air a bhith air a chleachdadh airson obrachaidhean dì-cho-labhairt follaiseach leis a `ghnìomhaiche (unary) `*` ann an co-theacsan so-ruigsinneach, tha `Deref` cuideachd air a chleachdadh gu h-obann leis an trusaiche ann an iomadh suidheachadh.
/// Canar ['`Deref` coercion'][more] ris an dòigh seo.
/// Ann an co-theacsan mutable, tha [`DerefMut`] air a chleachdadh.
///
/// Le bhith a `cur `Deref` an gnìomh airson molaidhean snasail tha e a` dèanamh cothrom air an dàta air a chùlaibh goireasach, agus is e sin as coireach gu bheil iad a `buileachadh `Deref`.
/// Air an làimh eile, chaidh na riaghailtean a thaobh `Deref` agus [`DerefMut`] a dhealbhadh gu sònraichte gus gabhail ri molaidhean snasail.
/// Air sgàth seo, cha bu chòir **`Deref` a bhith air a bhuileachadh ach airson molaidhean smart** gus troimh-chèile a sheachnadh.
///
/// Airson adhbharan coltach ris,**cha bu chòir don trait seo fàiligeadh** a-riamh.Faodaidh fàiligeadh rè dì-cho-labhairt a bhith gu math troimh-chèile nuair a thèid `Deref` a ghairm gu h-obann.
///
/// # Barrachd air co-èigneachadh `Deref`
///
/// Ma tha `T` a `buileachadh `Deref<Target = U>`, agus `x` na luach de sheòrsa `T`, an uairsin:
///
/// * Ann an co-theacsan so-ruigsinneach, tha `*x` (far nach eil `T` na iomradh no na chomharra amh) co-ionann ri `* Deref::deref(&x)`.
/// * Tha luachan de sheòrsa `&T` air an sparradh gu luachan de sheòrsa `&U`
/// * `T` gu h-obann a `buileachadh a h-uile modh (immutable) den t-seòrsa `U`.
///
/// Airson tuilleadh fiosrachaidh, tadhal air [the chapter in *The Rust Programming Language*][book] a bharrachd air na h-earrannan iomraidh air [the dereference operator][ref-deref-op], [method resolution] agus [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Structar le aon raon a tha ruigsinneach le bhith a `dì-chlàradh an structair.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// An seòrsa a thig às deidh sin dereferencing.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// A `dì-meas an luach.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Air a chleachdadh airson obrachaidhean dì-cho-labhairt gluasadach, mar ann an `*v = 1;`.
///
/// A bharrachd air a bhith air a chleachdadh airson obair dì-cho-labhairt follaiseach leis a `ghnìomhaiche (unary) `*` ann an co-theacsan gluasadach, tha `DerefMut` cuideachd air a chleachdadh gu h-obann leis an trusaiche ann an iomadh suidheachadh.
/// Canar ['`Deref` coercion'][more] ris an dòigh seo.
/// Ann an co-theacsan so-ruigsinneach, tha [`Deref`] air a chleachdadh.
///
/// Tha a bhith a `cur an gnìomh `DerefMut` airson molaidhean snasail a` dèanamh mutating an dàta air an cùlaibh goireasach, agus is e sin as coireach gu bheil iad a `buileachadh `DerefMut`.
/// Air an làimh eile, chaidh na riaghailtean a thaobh [`Deref`] agus `DerefMut` a dhealbhadh gu sònraichte gus gabhail ri molaidhean snasail.
/// Air sgàth seo, cha bu chòir **`DerefMut` a bhith air a bhuileachadh ach airson molaidhean smart** gus troimh-chèile a sheachnadh.
///
/// Airson adhbharan coltach ris,**cha bu chòir don trait seo fàiligeadh** a-riamh.Faodaidh fàiligeadh rè dì-chlàradh a bhith gu math troimh-chèile nuair a thèid `DerefMut` a ghairm gu h-obann.
///
/// # Barrachd air co-èigneachadh `Deref`
///
/// Ma tha `T` a `buileachadh `DerefMut<Target = U>`, agus `x` na luach de sheòrsa `T`, an uairsin:
///
/// * Ann an co-theacsan gluasadach, tha `*x` (far nach eil `T` na iomradh no na chomharraiche amh) co-ionann ri `* DerefMut::deref_mut(&mut x)`.
/// * Tha luachan de sheòrsa `&mut T` air an sparradh gu luachan de sheòrsa `&mut U`
/// * `T` gu h-obann a `buileachadh a h-uile modh (mutable) den t-seòrsa `U`.
///
/// Airson tuilleadh fiosrachaidh, tadhal air [the chapter in *The Rust Programming Language*][book] a bharrachd air na h-earrannan iomraidh air [the dereference operator][ref-deref-op], [method resolution] agus [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Structar le aon raon a ghabhas atharrachadh le bhith a `dì-chlàradh an structair.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Bidh mòran a `dì-luachadh an luach.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// A `nochdadh gum faodar structar a chleachdadh mar ghlacadair modh, às aonais am feart `arbitrary_self_types`.
///
/// Tha seo air a bhuileachadh le seòrsachan puing stdlib mar `Box<T>`, `Rc<T>`, `&T`, agus `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}