/// Air a chleachdadh airson obair clàr-amais (`container[index]`) ann an co-theacsan so-ruigsinneach.
///
/// `container[index]` gu dearbh tha siùcar syntactic airson `*container.index(index)`, ach dìreach nuair a thèid a chleachdadh mar luach so-ruigsinneach.
/// Ma thèid luach gluasadach iarraidh, thèid [`IndexMut`] a chleachdadh na àite.
/// Leigidh seo le rudan snog leithid `let value = v[index]` ma tha an seòrsa `value` a `buileachadh [`Copy`].
///
/// # Examples
///
/// Tha an eisimpleir a leanas a `buileachadh `Index` air inneal-leughaidh `NucleotideCount` a-mhàin, a` toirt cothrom cunntasan fa leth fhaighinn air ais le co-aonta clàr-amais.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// An seòrsa a chaidh a thilleadh às deidh clàr-amais.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// A `dèanamh obair clàr-amais (`container[index]`).
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// Air a chleachdadh airson obair clàr-amais (`container[index]`) ann an co-theacsan gluasadach.
///
/// `container[index]` gu dearbh tha siùcar syntactic airson `*container.index_mut(index)`, ach dìreach nuair a thèid a chleachdadh mar luach gluasadach.
/// Ma dh `iarrar luach so-ruigsinneach, thèid an [`Index`] trait a chleachdadh na àite.
/// Leigidh seo le rudan snog mar `v[index] = value`.
///
/// # Examples
///
/// Buileachadh gu math sìmplidh de structar `Balance` aig a bheil dà thaobh, far am faod gach fear a bhith air a chlàr-amais gu siùbhlach agus gu neo-ghluasadach.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // Anns a `chùis seo, is e siùcar a th` ann an `balance[Side::Right]` airson `*balance.index(Side::Right)`, leis nach eil sinn ach* a `leughadh * `balance[Side::Right]`, chan ann ga sgrìobhadh.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // Ach, anns a `chùis seo tha `balance[Side::Left]` siùcar airson `*balance.index_mut(Side::Left)`, leis gu bheil sinn a` sgrìobhadh `balance[Side::Left]`.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// A `dèanamh obair clàr-amais mutable (`container[index]`).
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}