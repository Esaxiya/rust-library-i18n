use crate::marker::Unsize;

/// Trait a tha a `nochdadh gur e comharradh no inneal-fillte a tha seo airson aon, far an urrainnear sàrachadh a dhèanamh air a` phuing.
///
/// Faic an [DST coercion RFC][dst-coerce] agus [the nomicon entry on coercion][nomicon-coerce] airson tuilleadh fiosrachaidh.
///
/// Airson seòrsachan puing togte, bidh comharran gu `T` a `tighinn gu comharran gu `U` ma tha `T: Unsize<U>` le bhith ag atharrachadh bho chomharradh tana gu comharradh geir.
///
/// Airson seòrsachan àbhaisteach, bidh an co-èigneachadh an seo ag obair le bhith a `coiteachadh `Foo<T>` gu `Foo<U>` cho fad` s a tha impl de `CoerceUnsized<Foo<U>> for Foo<T>` ann.
/// Chan urrainnear a leithid de impl a sgrìobhadh ach mura h-eil ach aon raon neo-phantomdata aig `Foo<T>` anns a bheil `T`.
/// Mas e `Bar<T>` an seòrsa raon sin, feumaidh buileachadh `CoerceUnsized<Bar<U>> for Bar<T>` a bhith ann.
/// Bidh an co-èigneachadh ag obair le bhith a `co-èigneachadh an raon `Bar<T>` a-steach do `Bar<U>` agus a` lìonadh a `chòrr de na raointean bho `Foo<T>` gus `Foo<U>` a chruthachadh.
/// Bidh seo gu h-èifeachdach a `drileadh sìos gu raon puing agus a` co-èigneachadh sin.
///
/// San fharsaingeachd, airson molaidhean snasail cuiridh tu `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` an gnìomh, le `?Sized` roghainneil ceangailte air `T` fhèin.
/// Airson seòrsachan pasgain a tha a `toirt a-steach `T` gu dìreach mar `Cell<T>` agus `RefCell<T>`, faodaidh tu `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` a chuir an gnìomh gu dìreach.
///
/// Leigidh seo le coercions de sheòrsa mar `Cell<Box<T>>` obrachadh.
///
/// [`Unsize`][unsize] air a chleachdadh gus seòrsachan a chomharrachadh a dh'fhaodar a cheangal ri DSTn ma tha iad air cùl molaidhean.Tha e air a bhuileachadh gu fèin-ghluasadach leis an trusaiche.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Tha seo air a chleachdadh airson sàbhailteachd nithean, gus dèanamh cinnteach gun urrainnear seòrsa cuidhteas modh a chuir air adhart.
///
/// Eisimpleir de bhuileachadh an trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}