/// An dreach den ghnìomhaiche gairm a bheir cuidhteas neo-ghluasadach.
///
/// Faodar imeachdan `Fn` a ghairm a-rithist is a-rithist às aonais stàite mutating.
///
/// *Chan eil an trait (`Fn`) seo gu bhith air a mheasgadh le [function pointers] (`fn`).*
///
/// `Fn` air a chuir an gnìomh gu fèin-ghluasadach le dùnadh a bheir dìreach iomraidhean so-ruigsinneach do chaochladairean a chaidh an glacadh no nach eil a `glacadh dad idir, a bharrachd air (safe) [function pointers] (le cuid de chlàran, faic na sgrìobhainnean aca airson tuilleadh fiosrachaidh).
///
/// A bharrachd air an sin, airson seòrsa `F` sam bith a bhios a `buileachadh `Fn`, tha `&F` a` buileachadh `Fn`, cuideachd.
///
/// Leis gu bheil an dà chuid [`FnMut`] agus [`FnOnce`] nan supertraits de `Fn`, faodar eisimpleir sam bith de `Fn` a chleachdadh mar pharamadair far a bheil dùil ri [`FnMut`] no [`FnOnce`].
///
/// Cleachd `Fn` mar cheangal nuair a tha thu airson gabhail ri paramadair de sheòrsa coltach ri gnìomh agus feumaidh tu a ghairm a-rithist agus gun a bhith a `mutadh stàite (me, nuair a bhios tu ga ghairm aig an aon àm).
/// Mura h-eil feum agad air riatanasan cho teann, cleachd [`FnMut`] no [`FnOnce`] mar chrìochan.
///
/// Faic an [chapter on closures in *The Rust Programming Language*][book] airson tuilleadh fiosrachaidh mun chuspair seo.
///
/// Cuideachd cudromach tha an co-chòrdadh sònraichte airson `Fn` traits (me
/// `Fn(usize, bool) -> usize`).Faodaidh an fheadhainn aig a bheil ùidh ann am mion-fhiosrachadh teicnigeach seo iomradh a thoirt air [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## A `gairm dùnadh
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## A `cleachdadh paramadair `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // gus an urrainn dha regex a bhith an urra ris an `&str: !FnMut` sin
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// A `dèanamh obair a` ghairm.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// An dreach den ghnìomhaiche gairm a bheir cuidhteas gluasadach.
///
/// Faodar imeachdan `FnMut` a ghairm a-rithist agus is dòcha gun atharraich iad stàite.
///
/// `FnMut` air a chuir an gnìomh gu fèin-ghluasadach le dùnadh a tha a `toirt iomradh caochlaideach air caochladairean a chaidh an glacadh, a bharrachd air a h-uile seòrsa a bhios a` cur an gnìomh [`Fn`], me, (safe) [function pointers] (leis gu bheil `FnMut` na àrd-uachdranas de [`Fn`]).
/// A bharrachd air an sin, airson seòrsa `F` sam bith a bhios a `buileachadh `FnMut`, tha `&mut F` a` buileachadh `FnMut`, cuideachd.
///
/// Leis gur e supertrait de `FnMut` a th `ann an [`FnOnce`], faodar eisimpleir sam bith de `FnMut` a chleachdadh far a bheil dùil ri [`FnOnce`], agus leis gu bheil [`Fn`] na fho-cheum de `FnMut`, faodar eisimpleir sam bith de [`Fn`] a chleachdadh far a bheil dùil ri `FnMut`.
///
/// Cleachd `FnMut` mar cheangal nuair a tha thu airson gabhail ri paramadair de sheòrsa coltach ri gnìomh agus feumaidh tu a ghairm a-rithist agus a-rithist, fhad `s a leigeas e le stàite a dhol timcheall.
/// Mura h-eil thu airson gum bi am paramadair ag atharrachadh stàite, cleachd [`Fn`] mar cheangal;mura feum thu a ghairm a-rithist is a-rithist, cleachd [`FnOnce`].
///
/// Faic an [chapter on closures in *The Rust Programming Language*][book] airson tuilleadh fiosrachaidh mun chuspair seo.
///
/// Cuideachd cudromach tha an co-chòrdadh sònraichte airson `Fn` traits (me
/// `Fn(usize, bool) -> usize`).Faodaidh an fheadhainn aig a bheil ùidh ann am mion-fhiosrachadh teicnigeach seo iomradh a thoirt air [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## A `gairm dùnadh a tha furasta a ghlacadh
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## A `cleachdadh paramadair `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // gus an urrainn dha regex a bhith an urra ris an `&str: !FnMut` sin
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// A `dèanamh obair a` ghairm.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// An dreach den ghnìomhaiche gairm a bheir glacadair le luach.
///
/// Faodar imeachdan `FnOnce` a ghairm, ach is dòcha nach gabh a ghairm grunn thursan.Air sgàth seo, mas e an aon rud a tha aithnichte mu sheòrsa gu bheil e a `buileachadh `FnOnce`, chan urrainnear a ghairm ach aon turas.
///
/// `FnOnce` air a bhuileachadh gu fèin-ghluasadach le dùnadh a dh `fhaodadh a bhith ag ithe caochladairean a chaidh an glacadh, a bharrachd air a h-uile seòrsa a tha a` cur an gnìomh [`FnMut`], me, (safe) [function pointers] (leis gu bheil `FnOnce` na àrd-uachdranas de [`FnMut`]).
///
///
/// Leis gu bheil gach cuid [`Fn`] agus [`FnMut`] nam fo-sgrìobhaidhean de `FnOnce`, faodar eisimpleir sam bith de [`Fn`] no [`FnMut`] a chleachdadh far a bheil dùil ri `FnOnce`.
///
/// Cleachd `FnOnce` mar cheangal nuair a tha thu airson gabhail ri paramadair de sheòrsa coltach ri gnìomh agus chan fheum thu ach aon uair a ghairm.
/// Ma dh `fheumas tu am paramadair a ghairm a-rithist agus a-rithist, cleachd [`FnMut`] mar cheangal;ma dh`fheumas tu cuideachd gun a bhith a` mùchadh stàite, cleachd [`Fn`].
///
/// Faic an [chapter on closures in *The Rust Programming Language*][book] airson tuilleadh fiosrachaidh mun chuspair seo.
///
/// Cuideachd cudromach tha an co-chòrdadh sònraichte airson `Fn` traits (me
/// `Fn(usize, bool) -> usize`).Faodaidh an fheadhainn aig a bheil ùidh ann am mion-fhiosrachadh teicnigeach seo iomradh a thoirt air [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## A `cleachdadh paramadair `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` ag ithe na caochladairean a chaidh a ghlacadh, agus mar sin chan urrainnear a ruith barrachd air aon uair.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // A `feuchainn ri `func()` a chuir a-steach a-rithist tilgidh e mearachd `use of moved value` airson `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` chan urrainnear a-nis a ghairm aig an ìre seo
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // gus an urrainn dha regex a bhith an urra ris an `&str: !FnMut` sin
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// An seòrsa a chaidh a thilleadh às deidh don ghnìomhaiche gairm a chleachdadh.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// A `dèanamh obair a` ghairm.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}