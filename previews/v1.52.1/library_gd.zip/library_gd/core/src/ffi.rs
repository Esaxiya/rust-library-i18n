#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Goireasan co-cheangailte ri ceanglaichean eadar-aghaidh gnìomh cèin (FFI).

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Co-ionann ri C `void`-seòrsa nuair a chleachdadh mar [pointer].
///
/// Gu dearbh, tha `*const c_void` co-ionann ri C's `const void*` agus tha `*mut c_void` co-ionann ri C's `void*`.
/// Thuirt sin, chan eil seo *co-ionann* ri seòrsa tilleadh C `void`, is e sin an seòrsa `()` aig Rust.
///
/// Gus modalan a mhodaladh gu seòrsachan neo-shoilleir ann am FFI, gus an tèid `extern type` a dhèanamh seasmhach, thathas a `moladh inneal-fillte newtype a chleachdadh timcheall air sreath byte falamh.
///
/// Faic an [Nomicon] airson mion-fhiosrachadh.
///
/// Dh `fhaodadh aon a bhith a` cleachdadh `std::os::raw::c_void` ma tha iad airson taic a thoirt do sheann compiler Rust sìos gu 1.1.0.
/// Às deidh Rust 1.30.0, chaidh ath-às-mhalairt leis a `mhìneachadh seo.
/// Airson tuilleadh fiosrachaidh, leugh [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, airson LLVM a bhith ag aithneachadh an seòrsa puing falamh agus le gnìomhan leudachaidh mar malloc(), feumaidh sinn a bhith air a riochdachadh mar i8 * ann an còd bit LLVM.
// Tha an enum a thathar a `cleachdadh an seo a` dèanamh cinnteach à seo agus a `cur casg air mì-chleachdadh den t-seòrsa "raw" le dìreach atharrachaidhean prìobhaideach a bhith agad.
// Feumaidh sinn dà dhreach, oir tha an trusaiche a `gearan mun fheart repr air dhòigh eile agus tha feum againn air co-dhiù aon caochladair oir air dhòigh eile bhiodh an enum neo-chòmhnaidh agus co-dhiù bhiodh e a` dì-chlàradh na comharran sin UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Buileachadh bunaiteach de `va_list`.
// Is e WIP an t-ainm, a `cleachdadh `VaListImpl` airson a-nis.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Invariant thairis air `'f`, mar sin tha gach nì `VaListImpl<'f>` ceangailte ri roinn na gnìomh anns a bheil e air a mhìneachadh
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 Buileachadh ABI air `va_list`.
/// Faic an [AArch64 Procedure Call Standard] airson tuilleadh fiosrachaidh.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC Buileachadh ABI air `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 Buileachadh ABI air `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Pasgadair airson `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Tionndadh `VaListImpl` gu `VaList` a tha co-chòrdail ri binary le C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Tionndadh `VaListImpl` gu `VaList` a tha co-chòrdail ri binary le C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// Feumar an VaArgSafe trait a chleachdadh ann an eadar-aghaidh poblach, ge-tà, chan fhaodar leigeil leis an trait fhèin a chleachdadh taobh a-muigh a `mhodal seo.
// Le bhith a `leigeil le luchd-cleachdaidh an trait a chuir an gnìomh airson seòrsa ùr (mar sin a` ceadachadh an va_arg intrinsic a chleachdadh air seòrsa ùr) tha e dualtach giùlan neo-mhìnichte adhbhrachadh.
//
// FIXME(dlrobertson): Gus an VaArgSafe trait a chleachdadh ann an eadar-aghaidh poblach ach cuideachd gus dèanamh cinnteach nach gabh a chleachdadh ann an àite eile, feumaidh an trait a bhith poblach taobh a-staigh modal prìobhaideach.
// Aon uair RFC 2145 air a bhith air an cur an gnìomh sùil a-steach a 'leasachadh seo.
//
//
//
//
mod sealed_trait {
    /// Trait a cheadaicheas na seòrsaichean ceadaichte a chleachdadh le [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Air adhart chun ath argumaid.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `va_arg` a chumail suas.
        unsafe { va_arg(self) }
    }

    /// Dèan lethbhreac den `va_list` aig an àite far a bheil e.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `va_end` a chumail suas.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // SÀBHAILTEACHD: bidh sinn a `sgrìobhadh chun `MaybeUninit`, mar sin tha e air a thòiseachadh agus tha `assume_init` laghail
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: bu chòir seo a 'gairm `va_end`, ach chan eil glan-slighe gu
        // gealltainn gum bi `drop` an-còmhnaidh a `faighinn a-steach don neach-fios, agus mar sin gheibheadh an `va_end` fios dìreach bhon aon ghnìomh ris an `va_copy` co-fhreagarrach.
        // `man va_end` ag ràdh gu bheil C a `feumachdainn seo, agus tha LLVM gu bunaiteach a` leantainn na semantics C, agus mar sin feumaidh sinn dèanamh cinnteach gu bheil `va_end` an-còmhnaidh air a ghairm bhon aon ghnìomh ri `va_copy`.
        //
        // Airson tuilleadh fiosrachaidh, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Bidh seo ag obair airson a-nis, seach gu bheil `va_end` na neo-op air na targaidean LLVM gnàthach gu lèir.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Destroy an arglist `ap` dèidh initialization le `va_start` no `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Dèan lethbhreac den àite a th `ann an-dràsta de arglist `src` chun an arglist `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Luchdan argamaid de seòrsa `T` bho `va_list` `ap` agus ceum an argamaid `ap` phuingean.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}