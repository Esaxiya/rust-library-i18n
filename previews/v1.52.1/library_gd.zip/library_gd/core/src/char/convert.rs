//! Atharrachaidhean caractar.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Bidh e ag atharrachadh `u32` gu `char`.
///
/// Thoir fa-near gu bheil a h-uile [`char`] s dligheach [`u32`] s, agus faodar an cur gu aon le
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Ach, chan eil an cùl fìor: chan eil a h-uile dligheach [`u32`] s dligheach [`char`] s.
/// `from_u32()` tillidh `None` mura h-eil an cuir a-steach luach dligheach airson [`char`].
///
/// Airson sàbhailte tionndadh de ghnìomh seo a leigeil seachad air na dearbhaidhean seo, faic [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// A `tilleadh `None` nuair nach eil an cur-a-steach [`char`] dligheach:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Bidh e ag atharrachadh `u32` gu `char`, a `seachnadh dligheachd.
///
/// Thoir fa-near gu bheil a h-uile [`char`] s dligheach [`u32`] s, agus faodar an cur gu aon le
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Ach, chan eil an cùl fìor: chan eil a h-uile dligheach [`u32`] s dligheach [`char`] s.
/// `from_u32_unchecked()` cha toir e an aire air seo, agus thèid a thilgeil gu dall gu [`char`], is dòcha a `cruthachadh fear neo-dhligheach.
///
///
/// # Safety
///
/// Tha an gnìomh seo cunnartach, oir dh `fhaodadh e luachan `char` neo-dhligheach a thogail.
///
/// Airson dreach sàbhailte den ghnìomh seo, faic gnìomh [`from_u32`].
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gu bheil `i` na luach char dligheach.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Converts a [`char`] a-steach [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Bidh e ag atharrachadh [`char`] gu [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Tha a 'char Tha casted ri luach na puing còd a tha, an uair sin neoni-leudachadh gu 64 bit.
        // Faic [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Bidh e ag atharrachadh [`char`] gu [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Tha an char air a thionndadh gu luach a `phuing còd, an uairsin air a leudachadh gu neoni gu 128 bit.
        // Faic [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Mapaichean byte ann an 0x00 ..=0xFF gu `char` aig a bheil an aon luach aig a `chòd còd aca, ann an U + 0000 ..=U + 00FF.
///
/// Tha Unicode air a dhealbhadh gus am bi seo gu h-èifeachdach a `còdachadh bytes leis an còdachadh charactaran ris an can IANA ISO-8859-1.
/// Tha an còdachadh seo co-chòrdail ri ASCII.
///
/// Thoir fa-near gu bheil seo eadar-dhealaichte bho ISO/IEC 8859-1 aka
/// ISO 8859-1 (le aon hyphen nas lugha), a tha a `fàgail cuid de "blanks", luachan byte nach eil air an sònrachadh do charactar sam bith.
/// Bidh ISO-8859-1 (am fear IANA) gan sònrachadh gu còdan smachd C0 agus C1.
///
/// Thoir fa-near gu bheil seo *cuideachd* eadar-dhealaichte bho Windows-1252 aka
/// còd duilleag 1252, a tha na superset ISO/IEC 8859-1 a bhios a `sònrachadh cuid de bheàrnan (chan e sin uile!) gu puingeachadh agus diofar charactaran Laideann.
///
/// Gus rudan a mhearachdachadh tuilleadh, tha [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, agus `windows-1252` uile nan ailiasan airson superset de Windows-1252 a bhios a `lìonadh nam beàrnan a tha air fhàgail le còdan smachd C0 agus C1 co-fhreagarrach.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Bidh e ag atharrachadh [`u8`] gu [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Mearachd a dh `fhaodar a thilleadh nuair a thèid pars a ghearradh.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // SÀBHAILTEACHD: dèan cinnteach gur e luach laghail aon-chòd a th `ann
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Thill an seòrsa mearachd nuair a dh `fhailicheas tionndadh bho u32 gu char.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Bidh e ag atharrachadh digit anns an radix a chaidh a thoirt gu `char`.
///
/// Canar 'radix' ris an seo uaireannan 'base'.
/// Tha radix de dhà a `comharrachadh àireamh binary, radix de dheich, deicheach, agus radix de shia deug, hexadecimal, gus cuid de luachan cumanta a thoirt seachad.
///
/// Thathas a `toirt taic do rèidiothan rèiteachaidh.
///
/// `from_digit()` tillidh `None` mura h-eil an cuir a-steach mar fhigeat anns an radix a chaidh a thoirt seachad.
///
/// # Panics
///
/// Panics ma thèid radix nas motha na 36 a thoirt dha.
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Tha deiche 11 mar aon fhigear ann am bonn 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// A `tilleadh `None` nuair nach e digit a th` anns an cur-a-steach:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// A `dol seachad air radix mòr, ag adhbhrachadh panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}