#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Tha mìneachaidhean structarail ann airson cruth seòrsachan togte a-steach.
//!
//! Faodar an cleachdadh mar thargaidean transmutes ann an còd neo-shàbhailte airson a bhith a `làimhseachadh na riochdachaidhean amh gu dìreach.
//!
//!
//! Bu chòir don mhìneachadh aca a bhith an-còmhnaidh a rèir an ABI a tha air a mhìneachadh ann an `rustc_middle::ty::layout`.
//!

/// Riochdachadh nì trait mar `&dyn SomeTrait`.
///
/// Tha an aon chruth aig an structar seo ri seòrsaichean mar `&dyn SomeTrait` agus `Box<dyn AnotherTrait>`.
///
/// `TraitObject` tha e cinnteach gu bheil e a `maidseadh dealbhadh, ach chan e an seòrsa stuthan trait a th` ann (me, chan eil na raointean ruigsinneach gu dìreach air `&dyn SomeTrait`) agus chan eil smachd aige air an dreach sin (cha atharraich atharrachadh a `mhìneachaidh cruth `&dyn SomeTrait`).
///
/// Tha e air a dhealbhadh a-mhàin airson a chleachdadh le còd neo-shàbhailte a dh `fheumas làimhseachadh mion-fhiosrachadh ìre ìosal.
///
/// Chan eil dòigh ann iomradh a thoirt air gach nì trait gu gnèitheach, agus mar sin is e gnìomhan mar [`std::mem::transmute`][transmute] an aon dòigh air luachan den t-seòrsa seo a chruthachadh.
/// San aon dòigh, is e `transmute` an aon dòigh air fìor nì trait a chruthachadh bho luach `TraitObject`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Co-chur a trait nì le mismatched-aon seòrsa, far a bheil an vtable chan eil a rèir an t-seòrsa air an luach a tha an dàta a tha na chomharra puingean-mòr dualtaiche leantainn air adhart gu undefined giùlan.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // eisimpleir trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // leig leis an trusaiche nì trait a dhèanamh
/// let object: &dyn Foo = &value;
///
/// // thoir sùil air an riochdachadh amh
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // is e am puing dàta seòladh `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // nì ùr a thogail, a `comharrachadh `i32` eadar-dhealaichte, le bhith faiceallach an `i32` vtable bho `object` a chleachdadh
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // bu chòir dha obrachadh dìreach mar gum biodh sinn air rud trait a thogail a-mach à `other_value` gu dìreach
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}