Panics an-dràsta snàithlean.

Tha seo a 'leigeil le prògram gus crìoch a chur air sa bhad agus a' toirt fios air ais do an neach-conaltraidh a 'phrògraim.
`panic!` bu chòir a chleachdadh nuair a ruigeas prògram staid nach gabh fhaighinn air ais.

Is e am macro seo an dòigh foirfe airson suidheachaidhean a dhearbhadh ann an còd eisimpleir agus ann an deuchainnean.
`panic!` Tha dlùth cheangail ris a `unwrap` dòigh dà chuid [`Option`][ounwrap] agus [`Result`][runwrap] enums.
Bidh an dà bhuileachadh a `gairm `panic!` nuair a thèid an suidheachadh gu atharrachaidhean [`None`] no [`Err`].

Nuair a chleachdas `panic!()` urrainn dhut Sònraich payload sreang, a tha air a thogail a 'cleachdadh an [`format!`] sheantansan.
Tha an t-uallach pàighidh sin air a chleachdadh nuair a tha thu a `stealladh an panic a-steach don t-snàthainn Rust, ag adhbhrachadh an t-snàthainn gu panic gu tur.

Giùlan default `std` hook, ie
a 'chòd a tha a' ruith gu dìreach an dèidh a 'panic tha invoked, tha a chlò-bhualadh an teachdaireachd payload gu `stderr` còmhla ri file/line/column fiosrachadh an `panic!()` ghairm.

Faodaidh tu a dhol thairis air an panic hook a `cleachdadh [`std::panic::set_hook()`].
Taobh a-staigh an hook faodar faighinn gu panic mar `&dyn Any + Send`, anns a bheil an dàrna cuid `&str` no `String` airson cuiridhean cunbhalach `panic!()`.
Airson panic le luach eile seòrsa eile, [`panic_any`] faodar a chleachdadh.

[`Result`] enum S tric a 'fuasgladh nas fheàrr airson a' slànachadh bho na mearachdan a 'cleachdadh an `panic!` mòra.
Macro seo a bu chòir a chleachdadh a sheachnadh air adhart a 'cleachdadh ceàrr luachan, leithid bho taobh a-muigh stòran.
Fiosrachadh mionaideach mu làimhseachadh mearachd a lorg ann an [book].

Faic cuideachd macro [`compile_error!`], airson a bhith a 'togail mearachdan rè chruinneachadh.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Buileachadh gnàthach

Ma tha am prìomh snàithlean panics cuiridh e crìoch air na snàithleanan agad agus thig am prògram agad gu crìch le còd `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





