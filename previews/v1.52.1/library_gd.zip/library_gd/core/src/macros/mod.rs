#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // A `leudachadh gu `$crate::panic::panic_2015` no `$crate::panic::panic_2021` an urra ri deasachadh an neach-fios.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Ag ràdh gu bheil dà abairtean a tha co-ionann ri chèile (a 'cleachdadh [`PartialEq`]).
///
/// Air panic, bidh am macro seo a `clò-bhualadh luachan nan abairtean leis na riochdachaidhean deasbaid aca.
///
///
/// Coltach ri [`assert!`], tha dàrna foirm aig an macro seo, far am faodar teachdaireachd àbhaisteach panic a thoirt seachad.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Tha na gluasadan gu h-ìosal a dh'aona ghnothaich.
                    // Às an aonais, a 'chruaich-sliotan airson an iasaid a tha a thòiseachadh fiù' s mus na luachan a tha a 'coimeas, a' leantainn gu follaiseach slaodach sìos.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Tha na gluasadan gu h-ìosal a dh'aona ghnothaich.
                    // Às an aonais, a 'chruaich-sliotan airson an iasaid a tha a thòiseachadh fiù' s mus na luachan a tha a 'coimeas, a' leantainn gu follaiseach slaodach sìos.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Ag ràdh gu bheil dà abairtean nach eil co-ionann ri chèile (a 'cleachdadh [`PartialEq`]).
///
/// Air panic, bidh am macro seo a `clò-bhualadh luachan nan abairtean leis na riochdachaidhean deasbaid aca.
///
///
/// Coltach ri [`assert!`], tha dàrna foirm aig an macro seo, far am faodar teachdaireachd àbhaisteach panic a thoirt seachad.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Tha na gluasadan gu h-ìosal a dh'aona ghnothaich.
                    // Às an aonais, a 'chruaich-sliotan airson an iasaid a tha a thòiseachadh fiù' s mus na luachan a tha a 'coimeas, a' leantainn gu follaiseach slaodach sìos.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Tha na gluasadan gu h-ìosal a dh'aona ghnothaich.
                    // Às an aonais, a 'chruaich-sliotan airson an iasaid a tha a thòiseachadh fiù' s mus na luachan a tha a 'coimeas, a' leantainn gu follaiseach slaodach sìos.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// A `dearbhadh gur e abairt boolean `true` aig àm-ruith.
///
/// Bidh seo ath-thagradh an [`panic!`] macro ma tha a 'toirt seachad a chur an cèill nach urrainn a bhith air a measadh a `true` aig runtime.
///
/// Like [`assert!`], seo macro Tha cuideachd an dàrna dreach, far a bheil custom panic urrainn an teachdaireachd a thoirt seachad.
///
/// # Uses
///
/// Eu-coltach ri [`assert!`], chan eil aithrisean `debug_assert!` air an comasachadh ach ann an togalaichean neo-leasaichte a rèir coltais.
/// An freagarraiche togail cha gnìomh `debug_assert!` aithrisean mur `-C debug-assertions` a thoirt seachad don a chur ri chèile.
/// Seo a 'dèanamh `debug_assert!` feumail airson sgrùdaidhean a tha ro dhaor airson a bhith an làthair ann an naidheachd a togail ach' s dòcha gum biodh e feumail aig àm a leasachadh.
/// Tha thoradh air leudachadh `debug_assert!`-còmhnaidh a 'sgrùdadh a-seòrsa.
///
/// Tha dearbhadh gun sgrùdadh a `leigeil le prògram ann an staid neo-chunbhalach cumail a` dol, a dh `fhaodadh a bhith a` toirt a-steach builean ris nach robh dùil ach nach toir e a-steach mì-shàbhailteachd fhad `s nach tachair seo ach ann an còd sàbhailte.
///
/// Tha coileanadh cosgais chanas, ge-tà, nach eil a ghabhas tomhas san fharsaingeachd.
/// An àite [`assert!`] le `debug_assert!` tha mar so a 'brosnachadh a-mhàin an dèidh mionaideach cunntasan, agus nas cudromaiche, a mhàin ann an sàbhailte code!
///
/// # Examples
///
/// ```
/// // is e teachdaireachd panic airson na dearbhaidhean sin luach teann an abairt a chaidh a thoirt seachad.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // gnìomh gu math sìmplidh
/// debug_assert!(some_expensive_computation());
///
/// // cumail a mach le teachdaireachd custom
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Ag ràdh gu bheil dà abairtean a tha co-ionann ri chèile.
///
/// Air panic, bidh am macro seo a `clò-bhualadh luachan nan abairtean leis na riochdachaidhean deasbaid aca.
///
/// Eu-coltach ri [`assert_eq!`], `debug_assert_eq!` Tha aithrisean ann a-mhàin an comas neo freagarraiche togail bho thùs.
/// An freagarraiche togail cha gnìomh `debug_assert_eq!` aithrisean mur `-C debug-assertions` a thoirt seachad don a chur ri chèile.
/// Tha seo a `dèanamh `debug_assert_eq!` feumail airson sgrùdaidhean a tha ro dhaor a bhith an làthair ann an togail fuasglaidh ach a dh` fhaodadh a bhith cuideachail aig àm leasachaidh.
///
/// Tha thoradh air leudachadh `debug_assert_eq!`-còmhnaidh a 'sgrùdadh a-seòrsa.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Ag ràdh gu bheil dà abairtean nach eil co-ionann ri chèile.
///
/// Air panic, bidh am macro seo a `clò-bhualadh luachan nan abairtean leis na riochdachaidhean deasbaid aca.
///
/// Eu-coltach ri [`assert_ne!`], `debug_assert_ne!` Tha aithrisean ann a-mhàin an comas neo freagarraiche togail bho thùs.
/// Cha chuir togalach leasaichte aithrisean `debug_assert_ne!` an gnìomh mura tèid `-C debug-assertions` a thoirt don neach-cruinneachaidh.
/// Seo a 'dèanamh `debug_assert_ne!` feumail airson sgrùdaidhean a tha ro dhaor airson a bhith an làthair ann an naidheachd a togail ach' s dòcha gum biodh e feumail aig àm a leasachadh.
///
/// Tha thoradh air leudachadh `debug_assert_ne!`-còmhnaidh a 'sgrùdadh a-seòrsa.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// A 'tilleadh co-dhiù a thoirt seachad a chur an cèill matches sam bith de na pàtranan a thoirt seachad.
///
/// Like ann `match` labhairt, pàtran Faodar optionally leantainn le `if` agus faire a chur an cèill a tha inntrigeadh aige don ainmean a 'dol leis a' phàtran.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Unwraps thoradh no propagates a mhearachd.
///
/// Chaidh an gnìomhaiche `?` a chur ris an àite `try!` agus bu chòir a chleachdadh na àite.
/// A thuilleadh, `try` glèidhte facal Rust ann an 2018, mar sin ma tha, feumaidh tu a chleachdadh, feumaidh tu a 'cleachdadh na [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` matches an [`Result`] a thoirt seachad.Ann an cùis na `Ok`-dhealaichte, air an abairt a tha luach an luach a phasgadh.
///
/// Ann an cùis an tionndadh `Err`, bidh e a `faighinn air ais a` mhearachd a-staigh.`try!` an uair sin a 'seinn an iompachadh cleachdadh `From`.
/// Seo a 'toirt fèin-ghluasadach atharrachadh eadar speisealaichte mhearachdan agus tuilleadh coitcheann fheadhainn.
/// Thèid a `mhearachd a thig às a thoirt air ais sa bhad.
///
/// Leis gu bheil an tràth tilleadh, `try!` fhaod a chleachdadh ach ann an gnìomhan a tha a 'tilleadh [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Tha an dòigh as fheàrr luath 'tilleadh Mearachdan
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // An dòigh a bh `ann roimhe airson Mearachdan a thilleadh gu sgiobalta
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // 'S e seo co-ionann ri:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// A `sgrìobhadh dàta cruth a-steach do bhufair.
///
/// Bidh am macro seo a `gabhail ri 'writer', sreang cruth, agus liosta argamaidean.
/// Bidh argumaidean air an cruth a rèir an t-sreang cruth ainmichte agus thèid an toradh a thoirt don sgrìobhadair.
/// Tha an sgrìobhadair a dh'fhaodadh a bhith luach sam bith le `write_fmt` dòigh;sa chumantas tha seo a `tighinn bho bhuileachadh an dàrna cuid an [`fmt::Write`] no an [`io::Write`] trait.
/// Tha macro tilleadh ge bith dè an dòigh `write_fmt` tilleadh;mar as trice [`fmt::Result`], no [`io::Result`].
///
/// Faic [`std::fmt`] airson barrachd fiosrachaidh air cruth sheantansan sreang.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// A modal urrainn-steach an dà chuid `std::fmt::Write` agus `std::io::Write` agus ghairm `write!` air rudan a chur an gnìomh an dara cuid, mar rudan nach eil mar as trice a chur an gnìomh an dà chuid.
///
/// Ach, feumaidh am modal an traits barantaichte a thoirt a-steach gus nach bi na h-ainmean aca a `strì:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // a `cleachdadh fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // a `cleachdadh io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Macro seo faodar a chleachdadh ann an `no_std` setups cho math.
/// Ann an suidheachadh `no_std` tha uallach ort airson mion-fhiosrachadh buileachaidh nam pàirtean.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Sgrìobh an cruth dàta a-steach bufair, le newline cois.
///
/// Air a h-uile àrd-chabhsairean, an newline tha an loidhne Feed caractar (`\n`/`U+000A`) aonar (chan eil bharrachd carriage return (`\r`/`U+000D`).
///
/// Airson tuilleadh fiosrachaidh, faic [`write!`].Airson fiosrachadh air an cruth sheantansan sreang, faic [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// A modal urrainn-steach an dà chuid `std::fmt::Write` agus `std::io::Write` agus ghairm `write!` air rudan a chur an gnìomh an dara cuid, mar rudan nach eil mar as trice a chur an gnìomh an dà chuid.
/// Ach, feumaidh am modal an traits barantaichte a thoirt a-steach gus nach bi na h-ainmean aca a `strì:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // a `cleachdadh fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // a `cleachdadh io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// A `nochdadh còd nach gabh ruigsinn.
///
/// Tha seo feumail uair sam bith nach urrainn don neach-cruinneachaidh dearbhadh gu bheil cuid de chòd do-ruigsinneach.Mar eisimpleir:
///
/// * Maids gàirdeanan le freiceadan h.
/// * Lùban a dynamically crìoch a chur air.
/// * Iterators a thig gu crìch gu dinamach.
///
/// Ma tha an dearbhadh gu bheil an còd neo-ruigsinneach a `dearbhadh ceàrr, thig am prògram gu crìch le [`panic!`] sa bhad.
///
/// Tha sàbhailte ionnan seo mòra a tha a [`unreachable_unchecked`] gnìomh, a bheir undefined giùlan Ma tha an còd air ruighinn.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Bidh seo an-còmhnaidh [`panic!`].
///
/// # Examples
///
/// Gàirdeanan maids:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // a chur ri chèile ma thuirt mearachd a-mach
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // aon de na h-àitean as bochda implementations de x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// A `nochdadh còd gun choileanadh le bhith a` clisgeadh le teachdaireachd "not implemented".
///
/// Tha seo a 'toirt cothrom do chòd a-seòrsa seic, a tha feumail ma tha thu a prototyping no a' cur an gnìomh trait a bheil feum air iomadh dòighean a nì thu nach eil plana bhith a 'cleachdadh na h-uile.
///
/// An diofar eadar `unimplemented!` agus [`todo!`] gu bheil `todo!` fhad 'sa' cur an cèill an rùn a chur an gnìomh an-gnìomh an dèidh sin agus tha an teachdaireachd "not yet implemented", `unimplemented!` dèanamh eil a leithid tagraidhean.
/// Is e an teachdaireachd aige "not implemented".
/// Cuideachd beagan IDEs a 'comharrachadh `Todo!` S.
///
/// # Panics
///
/// Bidh seo an-còmhnaidh [`panic!`] oir chan eil `unimplemented!` ach làmh-ghoirid airson `panic!` le teachdaireachd stèidhichte, sònraichte.
///
/// Coltach ri `panic!`, tha dàrna foirm aig an macro seo airson a bhith a `taisbeanadh luachan gnàthaichte.
///
/// # Examples
///
/// Say againn trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Tha sinn ag iarraidh a chur an gnìomh airson `Foo` 'MyStruct', ach airson adhbhar air choireigin chan eil a 'dèanamh ciall a chur an gnìomh `bar()` gnìomh.
/// `baz()` agus feumar `qux()` a mhìneachadh fhathast anns a `bhuileachadh againn air `Foo`, ach is urrainn dhuinn `unimplemented!` a chleachdadh anns na mìneachaidhean aca gus leigeil leis a` chòd againn cur ri chèile.
///
/// Tha sinn fhathast ag iarraidh a bhith air ar prògram a stad a 'ruith ma tha an unimplemented dòighean air an ruighinn.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Chan eil e a 'dèanamh ciall don `baz` a `MyStruct`, mar sin, nach' eil againn an seo aig a h-uile loidsig.
/////
///         // Thèid seo a thaisbeanadh "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Tha beagan loidsig againn an seo, Is urrainn dhuinn teachdaireachd a chuir gu neo-leasaichte!a thaisbeanadh ar dearmad.
///         // Bidh seo a 'taisbeanadh: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// A `nochdadh còd neo-chrìochnach.
///
/// Faodaidh seo a bhith feumail ma tha thu a prototyping agus tha iad dìreach a 'coimhead gu bheil an còd agad typecheck.
///
/// An diofar eadar [`unimplemented!`] agus `todo!` gu bheil `todo!` fhad 'sa' cur an cèill an rùn a chur an gnìomh an-gnìomh an dèidh sin agus tha an teachdaireachd "not yet implemented", `unimplemented!` dèanamh eil a leithid tagraidhean.
/// Is e an teachdaireachd aige "not implemented".
/// Cuideachd beagan IDEs a 'comharrachadh `Todo!` S.
///
/// # Panics
///
/// Bidh seo an-còmhnaidh [`panic!`].
///
/// # Examples
///
/// Seo eisimpleir de chuid de chòd a tha a `dol air adhart.Tha trait `Foo` againn:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Tha sinn ag iarraidh a chur an gnìomh `Foo` air aon de ar seòrsa, ach tha sinn cuideachd ag iarraidh a bhith ag obair air dìreach `bar()` toiseach.Gus an còd againn a chuir ri chèile, feumaidh sinn `baz()` a chuir an gnìomh, gus an urrainn dhuinn `todo!` a chleachdadh:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // buileachadh a `dol an seo
///     }
///
///     fn baz(&self) {
///         // na gabh dragh mu bhith a `buileachadh baz() airson a-nis
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // nach eil sinn fiù 's a' cleachdadh baz(), agus tha seo math.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Mìneachaidhean air a thogail ann an-macros.
///
/// Tha a `mhòr-chuid de na togalaichean macro (seasmhachd, faicsinneachd, msaa) air an toirt bhon chòd stòr an seo, ach a-mhàin gnìomhan leudachaidh a` cruth-atharrachadh macro a-steach do thoraidhean, tha na gnìomhan sin air an toirt seachad leis an trusaiche.
///
///
pub(crate) mod builtin {

    /// Adhbharan-chruinneachadh a 'fàilligeadh leis a' thoirt seachad teachdaireachd-mearachd nuair a thachair.
    ///
    /// Macro seo a bu chòir a chleachdadh nuair a crate 'cleachdadh cumhach chruinneachadh ro-innleachd a thoirt seachad nas fheàrr mearachd teachdaireachdan airson na h-brèige.
    ///
    /// Tha e na compiler-ìre riochd [`panic!`], ach emits mearachd rè * * chruinneachadh seach aig runtime * *.
    ///
    /// # Examples
    ///
    /// Is e dà eisimpleir den leithid macros agus àrainneachdan `#[cfg]`.
    ///
    /// Cuir a-mach mearachd co-chruinneachaidh nas fheàrr ma thèid macro seachad air luachan neo-dhligheach.
    /// Às aonais an branch mu dheireadh, bhiodh an trusaiche fhathast a `leigeil a-mach mearachd, ach cha bhiodh teachdaireachd a` mhearachd a `toirt iomradh air an dà luach dhligheach.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Cuir a-mach mearachd co-chruinneachaidh mura h-eil aon de ghrunn fheartan ri fhaighinn.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// A `togail pharamadairean airson na macros cruth sreang eile.
    ///
    /// Bidh am macro seo ag obair le bhith a `toirt sreang cruth cruth anns a bheil `{}` airson gach argamaid a bharrachd a chaidh seachad.
    /// `format_args!` ag ullachadh crìochan a bharrachd gus dèanamh cinnteach an urrainn toradh a mhìneachadh mar sreang agus canonicalizes na h-argamaidean a-steach do aon seòrsa.
    /// Faodar luach sam bith a chuireas an [`Display`] trait an gnìomh gu `format_args!`, agus cuideachd faodar buileachadh [`Debug`] sam bith a chuir air adhart gu `{:?}` taobh a-staigh an sreang cruth.
    ///
    ///
    /// Macro seo a 'foillseachadh luach-seòrsa [`fmt::Arguments`].Tha seo a luach a chur gu macros taobh a-staigh [`std::fmt`] airson coileanadh stiùireadh feumail.
    /// A h-uile cruth eile macros ([`cruth!`], [`write!`], [`println!`], etc) a tha proxied tro tè seo.
    /// `format_args!`, eu-coltach ris na macros a thàinig bhuaithe, a `seachnadh riarachadh tiùrran.
    ///
    /// Faodaidh tu an luach [`fmt::Arguments`] a tha `format_args!` a `tilleadh ann an co-theacsan `Debug` agus `Display` a chleachdadh mar a chithear gu h-ìosal.
    /// Tha an eisimpleir cuideachd a `sealltainn an cruth `Debug` agus `Display` chun an aon rud: an sreang cruth eadar-phòlaichte ann an `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Airson tuilleadh fiosrachaidh, faic na sgrìobhainnean ann an [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Same mar `format_args`, ach a 'cur newline ann an deireadh.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// A 'sgrùdadh an àrainneachd caochlaideach ri chèile aig an àm.
    ///
    /// Macro seo, thèid leudachadh gus luach an ainmeachadh àrainneachd caochlaideach ri chèile aig an àm, gèilleadh an cur an cèill an seòrsa `&'static str`.
    ///
    ///
    /// Ma tha an àrainneachd caochlaideach nach eil a mhìneachadh, agus an uair sin a chruinneachadh mearachd a thèid a thèid a sgaoileadh.
    /// Gus nach cuir thu a-mach mearachd co-chruinneachaidh, cleachd am macro [`option_env!`] na àite.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Faodaidh tu an teachdaireachd-mearachd le bhith a 'dol seachad air sreang mar dàrna paramadair:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Mura h-eil caochladair àrainneachd `documentation` air a mhìneachadh, gheibh thu a `mhearachd a leanas:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Optionally a 'sgrùdadh an àrainneachd caochlaideach ri chèile aig an àm.
    ///
    /// Ma tha an ainmeachadh àrainneachd caochlaideach tha an làthair aig àm ri chèile, bidh seo a leudachadh a-steach dhan an cur an cèill an seòrsa `Option<&'static str>` aig a bheil luach a th `Some` de luach na h-àrainneachd caochlaideach.
    /// Ma tha an àrainneachd caochlaideach Chan eil an-diugh, an sin thèid seo a leudachadh ri `None`.
    /// Faic [`Option<T>`][Option] airson barrachd fiosrachaidh air-seòrsa seo.
    ///
    /// A àm ri chèile mearachd nuair a thèid a sgaoileadh a-riamh a 'cleachdadh seo macro ge bith a bheil an àrainneachd caochlaideach a tha an làthair no nach eil.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates aithnichearan a-steach aon aithnichear.
    ///
    /// Tha seo a 'gabhail macro àireamh sam bith de cromag-aithnichearan dealaichte, agus concatenates iad uile a-steach dhan aon, gèilleadh an abairt a tha ùr aithnichear.
    /// Thoir an aire gur e leithid a 'dèanamh slàinteachas gu bheil seo macro nach urrainn a ghlacadh ionadail caochladairean.
    /// Cuideachd, mar riaghailt choitcheann, macros ach a-mhàin ceadaichte ann an Earrann, aithris no abairt suidheachadh.
    /// Tha sin a `ciallachadh ged a dh` fhaodadh tu am macro seo a chleachdadh airson a bhith a `toirt iomradh air caochladairean, gnìomhan no modalan msaa, chan urrainn dhut fear ùr a mhìneachadh leis.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (ùr, spòrsail, ainm) { }//nach gabh a chleachdadh san dòigh seo!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates literals a-steach stadaigeach sreang sliseag.
    ///
    /// Bidh am macro seo a `toirt àireamh sam bith de litrichean a tha air an sgaradh le cromag, a` toirt a-mach faireachdainn de sheòrsa `&'static str` a tha a `riochdachadh a h-uile gin de na litrichean a tha a` co-dhùnadh clì gu deas.
    ///
    ///
    /// Tha litreachasan integer agus puingean fleòdraidh air an sreangachadh gus an tèid co-dhùnadh a dhèanamh.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// A 'leudachadh na loidhne àireamh a chaidh a invoked.
    ///
    /// Le [`column!`] agus [`file!`], tha na macros sin a `toirt seachad fiosrachadh deasbaid do luchd-leasachaidh mun àite taobh a-staigh an stòr.
    ///
    /// Tha seòrsa `u32` aig an abairt leudaichte agus tha e stèidhichte air 1, agus mar sin bidh a `chiad loidhne anns gach faidhle a` luachadh gu 1, an dàrna gu 2, msaa.
    /// 'S e seo co-chòrdail ri teachdaireachdan mearachd le cumanta an trusaiche no luchd-deasachaidh mòr-chòrdte.
    /// Tha an loidhne a thill e *dòcha nach* loidhne na `line!` achanaich fhèin, ach an àite a bhith a 'chiad macro achanaich a' dol suas chun an achanaich an `line!` mòra.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Leudachadh gu àireamh a 'chuilbh aig a chaidh invoked.
    ///
    /// Le [`line!`] agus [`file!`], sin macros debugging a 'toirt fiosrachadh do luchd-leasachaidh mu dheidhinn an t-àite taobh a-staigh an tobar.
    ///
    /// Tha seòrsa `u32` aig an abairt leudaichte agus tha e stèidhichte air 1, agus mar sin tha a `chiad cholbh anns gach loidhne a` luachadh gu 1, an dàrna gu 2, msaa.
    /// 'S e seo co-chòrdail ri teachdaireachdan mearachd le cumanta an trusaiche no luchd-deasachaidh mòr-chòrdte.
    /// Tha an colbh a thill e *dòcha nach* loidhne na `column!` achanaich fhèin, ach an àite a bhith a 'chiad macro achanaich a' dol suas chun an achanaich an `column!` mòra.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Leudachadh gu faidhle ann an ainm a chaidh a invoked.
    ///
    /// Le [`line!`] agus [`column!`], sin macros debugging a 'toirt fiosrachadh do luchd-leasachaidh mu dheidhinn an t-àite taobh a-staigh an tobar.
    ///
    /// Tha seòrsa `&'static str` aig an abairt leudaichte, agus chan e am faidhle a chaidh a thilleadh a bhith a `toirt a-steach am macro `file!` fhèin, ach an àite a` chiad macro-ionnsaigh a tha a `leantainn suas gu macro `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// A `daingneachadh na h-argamaidean aige.
    ///
    /// Bidh seo macro geilleadh an cur an cèill an seòrsa `&'static str` a tha stringification a h-uile tokens seachad do mòra.
    /// No cuingeachaidhean a tha air an cur air sheantansan an macro achanaich fhèin.
    ///
    /// Thoir fa-near gu bheil a 'leudachadh toraidhean tokens an taic a dh'fhaodadh atharrachadh ann an future.Bu chòir dhut a bhith faiceallach ma tha sibh an crochadh air an toradh.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// A `toirt a-steach faidhle UTF-8 air a chòdachadh mar sreang.
    ///
    /// Tha am faidhle a tha suidhichte an coimeas ri an-dràsta file (coltach ri mar a tha modalan a lorg).
    /// Tha an t-slighe a chaidh a thoirt seachad air a mhìneachadh ann an dòigh sònraichte air àrd-ùrlar aig àm cur ri chèile.
    /// Mar sin, mar eisimpleir, achanaich le Windows frith-rathad anns a bheil backslashes `\` nach biodh a chur ri chèile gu ceart air Unix.
    ///
    ///
    /// Bheir am macro seo a-mach abairt den t-seòrsa `&'static str` a tha ann am susbaint an fhaidhle.
    ///
    /// # Examples
    ///
    /// A 'gabhail ris tha dà faidhlichean ann an aon phasgan le na leanas th' ann:
    ///
    /// Faidhle 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fhaidhle 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Bidh a bhith a `cur ri chèile 'main.rs' agus a` ruith a `bhinary a thig às a` clò-bhualadh "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// A `toirt a-steach faidhle mar iomradh air sreath byte.
    ///
    /// Tha am faidhle a tha suidhichte an coimeas ri an-dràsta file (coltach ri mar a tha modalan a lorg).
    /// Tha an t-slighe a chaidh a thoirt seachad air a mhìneachadh ann an dòigh sònraichte air àrd-ùrlar aig àm cur ri chèile.
    /// Mar sin, mar eisimpleir, achanaich le Windows frith-rathad anns a bheil backslashes `\` nach biodh a chur ri chèile gu ceart air Unix.
    ///
    ///
    /// Bheir am macro seo a-mach abairt den t-seòrsa `&'static [u8; N]` a tha ann am susbaint an fhaidhle.
    ///
    /// # Examples
    ///
    /// A 'gabhail ris tha dà faidhlichean ann an aon phasgan le na leanas th' ann:
    ///
    /// Faidhle 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fhaidhle 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Bidh a bhith a `cur ri chèile 'main.rs' agus a` ruith a `bhinary a thig às a` clò-bhualadh "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Leudachadh gu sreang a 'riochdachadh an-dràsta modal frith-rathad.
    ///
    /// Faodar smaoineachadh air slighe gnàthach a `mhodal mar rangachd mhodalan a` dol air ais suas chun crate root.
    /// Is e a `chiad phàirt den t-slighe a chaidh a thilleadh ainm an crate a thathar a` cur ri chèile an-dràsta.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Measadh boolean measgachadh de rèiteachaidh brataichean aig àm-ri chèile.
    ///
    /// A bharrachd air an fheart `#[cfg]`, tha am macro seo air a thoirt seachad gus leigeil le measadh abairt boolean air brataichean rèiteachaidh.
    /// Tha seo tric iallan gu nas lugha a chleachdadh còd.
    ///
    /// Tha sheantansan a thoirt don seo tha macro an aon sheantansan mar an [`cfg`] buadha.
    ///
    /// `cfg!`, ao-coltach ri `#[cfg]`, chan eil a thoirt air falbh sam bith code a-mhàin agus a 'measadh gu ceart no ceàrr.
    /// Mar eisimpleir, a h-uile blocaichean ann an if/else labhairt fheum air a bhith dligheach `cfg!` nuair a thathar a 'cleachdadh airson a' chùmhnant, a dh'aindeoin dè `cfg!` Tha measadh.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Parses faidhle mar an labhairt no a 'phìos a rèir co-theacsa.
    ///
    /// Tha am faidhle a tha suidhichte an coimeas ri an-dràsta file (coltach ri mar a tha modalan a lorg).Tha an frith-rathad a tha a 'toirt seachad mìneachadh ann an àrd-chabhsair a-slighe sònraichte ri chèile aig an àm.
    /// Mar sin, mar eisimpleir, achanaich le Windows frith-rathad anns a bheil backslashes `\` nach biodh a chur ri chèile gu ceart air Unix.
    ///
    /// A 'cleachdadh seo macro S tric droch bheachd, oir ma tha am faidhle parsed mar-labhairt, tha i dol a bhith air a chur mun cuairt ann an còd unhygienically.
    /// Dh `fhaodadh seo leantainn gu bheil caochladairean no gnìomhan eadar-dhealaichte bho na bha am faidhle an dùil ma tha caochladairean no gnìomhan ann aig a bheil an aon ainm san fhaidhle gnàthach.
    ///
    ///
    /// # Examples
    ///
    /// A 'gabhail ris tha dà faidhlichean ann an aon phasgan le na leanas th' ann:
    ///
    /// Fhaidhle 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Fhaidhle 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' 'cur ri chèile agus a' ruith an thoradh Binary Thèid a chlò-bhualadh "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// A `dearbhadh gur e abairt boolean `true` aig àm-ruith.
    ///
    /// Bidh seo ath-thagradh an [`panic!`] macro ma tha a 'toirt seachad a chur an cèill nach urrainn a bhith air a measadh a `true` aig runtime.
    ///
    /// # Uses
    ///
    /// Bithear a `sgrùdadh dearbhaidhean an-còmhnaidh ann an togalaichean deasbaid agus fuasglaidh, agus chan urrainnear an ciorramachadh.
    /// See [`debug_assert!`] airson a chanas nach eil an comas ann an togail naidheachd bho thùs.
    ///
    /// Sàbhailte code dòcha crochadh air `assert!` a chur an sàs a 'ruith invariants-ùine sin, ma bhris Dh'fhaodadh unsafety.
    ///
    /// Tha cùisean cleachdaidh eile de `assert!` a `toirt a-steach a bhith a` dèanamh deuchainn agus a `cur an sàs ionnsaigh ùine-ruith ann an còd sàbhailte (nach urrainn a bhriseas a bhith neo-shàbhailte).
    ///
    ///
    /// # Brathan Custom
    ///
    /// Macro seo tha an dàrna cruth, far a bheil custom panic urrainn an teachdaireachd a thoirt seachad le no as aonais argamaidean airson fòrmatadh.
    /// Faic [`std::fmt`] airson co-aonta airson an fhoirm seo.
    /// Abairtean chleachdadh mar cruth-argamaidean a-mhàin a thèid measadh ma tha an tagradh a 'fàilligeadh.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // is e teachdaireachd panic airson na dearbhaidhean sin luach teann an abairt a chaidh a thoirt seachad.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // gnìomh gu math sìmplidh
    ///
    /// assert!(some_computation());
    ///
    /// // cumail a mach le teachdaireachd custom
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Seanadh a-staigh.
    ///
    /// Leugh an [unstable book] airson an cleachdadh.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-stoidhle inline chomhchruinnich.
    ///
    /// Leugh an [unstable book] airson an cleachdadh.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Modal-ìre inline chomhchruinnich.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Prints seachad tokens a-steach na h-ìre toradh.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// A 'toirt cothrom no disables tana-chomas a chleachdadh airson debugging eile macros.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Buadha mòra a chleachdadh gus cur a-steach a 'tighinn macros.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Macro buadha a chur ri obair a dhèanamh ann a-steach ann an aonad deuchainn.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Macro buadha a chur ri obair a dhèanamh ann a tha e a-steach air a threòrachadh deuchainn.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// An buileachadh mionaideach de na `#[test]` agus `#[bench]` macros.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Buadha macro iarrtas a chur gu stadaigeach a chlàradh mar cruinneil allocator.
    ///
    /// Faic cuideachd [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// A 'cumail a' phìos a tha e iarrtas a chur gu ma tha a 'dol seachad air frith-rathad a tha so-ruigsinn, agus a thoirt a chaochladh.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// A 'leudachadh agus a h-uile `#[cfg]` `#[cfg_attr]` Feartan ann an còd criomag a tha e iarrtas a chur gu.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Mion-fhiosrachadh buileachaidh neo-sheasmhach an trusaiche `rustc`, na cleachd.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Mion-fhiosrachadh buileachaidh neo-sheasmhach an trusaiche `rustc`, na cleachd.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}