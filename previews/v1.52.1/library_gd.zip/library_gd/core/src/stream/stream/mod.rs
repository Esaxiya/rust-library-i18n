use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Eadar-aghaidh airson dèiligeadh ri itealain asyncronach.
///
/// Is e seo am prìomh shruth trait.
/// Airson tuilleadh mu bhun-bheachd sruthan san fharsaingeachd, faic an [module-level documentation].
/// Gu sònraichte, is dòcha gum bi thu airson faighinn a-mach ciamar a nì thu [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// An seòrsa stuthan a bheir an sruth a-mach.
    type Item;

    /// Feuch tarraing a-mach an ath luach an sruth, a 'clàradh an-dràsta airson obair wakeup ma luach Chan eil e fhathast ri fhaighinn, agus a' tilleadh `None` ma tha an sruth a tha claoidhte.
    ///
    /// # Luach tillidh
    ///
    /// Tha grunn luachan comasach air tilleadh, gach fear a `nochdadh staid srutha sònraichte:
    ///
    /// - `Poll::Pending` ciallachadh gu bheil seo sruth ath luach Chan eil e deiseil fhathast.Implementations cinnteach gum bi obair an-dràsta, thèid fios nuair a bhios an ath luach a dh'fhaodadh a bhith deiseil.
    ///
    /// - `Poll::Ready(Some(val))` a `ciallachadh gu bheil an sruth air luach, `val`, a thoirt gu buil gu soirbheachail, agus faodaidh e tuilleadh luachan a thoirt gu buil air gairmean `poll_next` às deidh sin.
    ///
    /// - `Poll::Ready(None)` a `ciallachadh gu bheil an sruth air tighinn gu crìch, agus cha bu chòir `poll_next` a ghairm a-rithist.
    ///
    /// # Panics
    ///
    /// Aon uair `s gu bheil sruth deiseil (air ais `Ready(None)` from `poll_next`), a` gairm a dhòigh `poll_next` a-rithist faodaidh panic, bacadh gu bràth, no duilgheadasan eile adhbhrachadh; chan eil an `Stream` trait a `cur riatanasan sam bith ri buaidh a leithid de ghairm.
    ///
    /// Ach, leis nach eil an dòigh `poll_next` air a chomharrachadh `unsafe`, tha riaghailtean àbhaisteach Rust a `buntainn: chan fhaod gairmean a bhith ag adhbhrachadh giùlan neo-mhìnichte (coirbeachd cuimhne, cleachdadh ceàrr air gnìomhan `unsafe`, no an leithid), ge bith dè an stàit a th` ann.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// A `tilleadh na crìochan air an fhad a tha air fhàgail den t-sruth.
    ///
    /// Gu sònraichte, bidh `size_hint()` a `tilleadh tuple far a bheil a` chiad eileamaid aig a `cheangal as ìsle, agus an dàrna eileamaid aig a` mhullach àrd.
    ///
    /// Tha an dàrna leth den tuple a tha a thill e an [`Option`]`<`[`usize`] `>`.
    /// A [`None`] seo a 'ciallachadh gu bheil an dara cuid nach eil aithnichte h-àrd a' dol, no na h-àrd a 'dol nas motha na [`usize`].
    ///
    /// # Notaichean buileachaidh
    ///
    /// Chan eilear a `cur an gnìomh gu bheil buileachadh sruth a` toirt a-mach an àireamh ainmichte de eileamaidean.Faodaidh sruth buga toradh nas lugha na an ìre as ìsle no nas motha na an ìre àrd de eileamaidean.
    ///
    /// `size_hint()` gu sònraichte airson a bhith air a chleachdadh airson optimizations leithid àite a ghlèidheadh airson eileamaidean an t-srutha, ach chan fheumar earbsa a bhith aca me, cuir às do sgrùdaidhean crìochnachaidh ann an còd neo-shàbhailte.
    /// An ceàrr a chur an gnìomh `size_hint()` Cha bu chòir leantainn air adhart gu memory sàbhailteachd bhrisidhean.
    ///
    /// Sin a ràdh, air cur an gnìomh a bu chòir a thoirt seachad ceart mheas, oir a chaochladh biodh e bhriseas an trait a 'ghnàths.
    ///
    /// Bidh am buileachadh bunaiteach a `tilleadh` (0,`[`None`]`) `a tha ceart airson sruth sam bith.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}