//! Composable asynchronous chuairt.
//!
//! Ma tha futures nan luachan asyncronach, an uairsin tha sruthan nan itealain asyncronach.
//! Ma tha thu fhèin a lorg le asynchronous chruinneachadh seòrsa de, agus dh'fheumadh a 'coileanadh obrachadh air na h-eileamaidean de Thuirt chruinneachadh, bidh tu a-steach gu luath a' ruith 'streams'.
//! Tha sruthan air an cleachdadh gu mòr ann an còd gnàthasan-cainnte Rust, mar sin is fhiach a bhith eòlach orra.
//!
//! Mus deach a 'mìneachadh tuilleadh, leig a' bruidhinn mu dheidhinn mar a modal seo structar:
//!
//! # Organization
//!
//! Tha am modal seo air a eagrachadh gu ìre mhòr a rèir seòrsa:
//!
//! * [Traits] a `phrìomh phàirt: tha na traits seo a` mìneachadh dè an seòrsa sruthan a th `ann agus dè as urrainn dhut a dhèanamh leotha.Is fhiach dòighean nan traits seo beagan ùine sgrùdaidh a bharrachd a chuir a-steach.
//! * Bidh gnìomhan a `toirt seachad cuid de dhòighean cuideachail gus cuid de shruthan bunaiteach a chruthachadh.
//! * Is e structaran gu tric na seòrsaichean tilleadh de na diofar dhòighean air traits a `mhodal seo.Mar as trice bidh thu airson sùil a thoirt air an dòigh a chruthaicheas an `struct`, seach an `struct` fhèin.
//! Airson tuilleadh fiosrachaidh mu carson, faic '[Gnìomhachadh Sruth](#buileachadh-sruth)'.
//!
//! [Traits]: #traits
//!
//! Sin e!Dèanamaid cladhach a-steach do shruthan.
//!
//! # Stream
//!
//! Is e cridhe agus anam a `mhodal seo an [`Stream`] trait.Tha cridhe [`Stream`] a`coimhead mar seo:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Eu-coltach ri `Iterator`, tha `Stream` a `dèanamh eadar-dhealachadh eadar an dòigh [`poll_next`] a thathas a` cleachdadh nuair a thathar a `cur an gnìomh `Stream`, agus dòigh (to-be-implemented) `next` a thathas a` cleachdadh nuair a bhios tu a `caitheamh sruth.
//!
//! Chan fheum luchd-cleachdaidh `Stream` ach beachdachadh air `next`, a bhios, nuair a thèid a ghairm, a `tilleadh future a bheir a-mach `Option<Stream::Item>`.
//!
//! Bheir an future a chaidh a thilleadh le `next` toradh `Some(Item)` cho fad `s a tha eileamaidean ann, agus aon uair` s gu bheil iad uile air an toirt a-mach, bheir iad `None` a-mach gus sealltainn gu bheil itealadh deiseil.
//! Ma tha sinn a `feitheamh air rudeigin asyncronach ri fhuasgladh, bidh an future a` feitheamh gus am bi an sruth deiseil airson toradh a-rithist.
//!
//! Faodaidh sruthan fa leth taghadh ath-thòiseachadh a dhèanamh, agus mar sin ma dh `fhaodadh gun toir `next` a-rithist `Some(Item)` a-rithist aig àm air choreigin.
//!
//! Tha làn mhìneachadh [`Stream`] a` toirt a-steach grunn dhòighean eile cuideachd, ach tha iad nan dòighean bunaiteach, air an togail air mullach [`poll_next`], agus mar sin gheibh thu iad an-asgaidh.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Sruth buileachaidh
//!
//! Tha cruthachadh ceum de do chuid fhèin a `toirt a-steach dà cheum: cruthachadh `struct` gus staid an t-srutha a chumail, agus an uairsin [`Stream`] a chuir an gnìomh airson an `struct` sin.
//!
//! Dèanamaid sruth leis an ainm `Counter` a tha a `cunntadh bho `1` gu `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // A 'chiad, an struct:
//!
//! /// Sruth a tha a `cunntadh bho aon gu còig
//! struct Counter {
//!     count: usize,
//! }
//!
//! // tha sinn ag iarraidh ar cunntadh gus tòiseachadh aig aon, mar sin, leig a 'Cuir new() dòigh gus cuideachadh.
//! // Chan eil seo buileach riatanach, ach tha e goireasach.
//! // Thoir fa-near gum bi sinn a `tòiseachadh `count` aig neoni, chì sinn carson ann am buileachadh `poll_next()`'s gu h-ìosal.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // An uairsin, bidh sinn a `cur `Stream` an gnìomh airson an `Counter` againn:
//!
//! impl Stream for Counter {
//!     // bidh sinn a 'cunntadh le usize
//!     type Item = usize;
//!
//!     // poll_next() an aon dòigh riatanach
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Ceum ar cunntadh.'S e seo carson a thòisich sinn aig neoni.
//!         self.count += 1;
//!
//!         // Lorg fhaicinn ma tha sinn deiseil cunntaidh no nach eil.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Sruthan a tha leisg * *.Tha seo a `ciallachadh nach bi dìreach cruthachadh sruthan a` dèanamh _do_ gu h-iomlan.Nothing dha-rìribh a 'tachairt gus a ghairm thu `next`.
//! Tha seo uaireannan na adhbhar troimh-chèile nuair a chruthaicheas tu sruth a-mhàin airson na fo-bhuaidhean aige.
//! Bheir an trusaiche rabhadh dhuinn mun t-seòrsa giùlan seo:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;