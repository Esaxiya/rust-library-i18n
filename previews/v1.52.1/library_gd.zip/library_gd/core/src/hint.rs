#![stable(feature = "core_hint", since = "1.27.0")]

//! Beachdan air trusaiche a bheir buaidh air mar a bu chòir còd a bhith air a sgaoileadh no air a bharrachadh.
//! Sanasan a dh'fhaodadh a bhith ri chèile ùine no runtime.

use crate::intrinsics;

/// Ag innse don neach-cruinneachaidh nach gabh ruigsinn air a `phuing seo sa chòd, a` comasachadh tuilleadh optimachaidhean.
///
/// # Safety
///
/// A 'ruighinn a' ghnìomh seo a tha gu tur *undefined giùlan*(UB).Gu sònraichte, a chur ri chèile a 'gabhail ris gu bheil a h-uile UB Feumaidh nach tachair, agus mar sin a' cur às gach meur gu bheil ruigsinneachd gu gairm gu `unreachable_unchecked()`.
///
/// Coltach ris a h-uile suidheachadh de UB, ma tha coltas ann gu bheil am barail seo ceàrr, ie, tha an gairm `unreachable_unchecked()` ruigsinneach am measg a h-uile sruth smachd a dh `fhaodadh a bhith ann, cuiridh an trusaiche an ro-innleachd optimization ceàrr an gnìomh, agus uaireannan dh` fhaodadh e còd a tha coltach nach eil ceangailte a mhilleadh, ag adhbhrachadh duilich-duilgheadasan to-debug.
///
///
/// Cleachd an gnìomh seo a-mhàin nuair as urrainn dhut dearbhadh nach gairm an còd gu bràth e.
/// Mura bheil, smaoinichibh air a cleachdadh an [`unreachable!`] mòra, nach eil a 'leigeil optimizations ach bidh panic nuair bàs.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` an-còmhnaidh dearbhach (chan e neoni), mar sin cha till `checked_div` `None` gu bràth.
/////
///     // Mar sin, tha an branch eile neo-ruigsinneach.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SÀBHAILTEACHD: feumaidh an cùmhnant sàbhailteachd airson `intrinsics::unreachable`
    // a bhith air a dhearbhadh leis an neach-fios.
    unsafe { intrinsics::unreachable() }
}

/// Bidh e a `sgaoileadh stiùireadh inneal gus innse don phròiseasar gu bheil e a` ruith ann an lùb snìomh trang-feitheamh (`glas glaiste`).
///
/// Upon a 'faighinn an lùib co-chomharran an giullachair urrainn feum as fheàrr a ghiùlan le, mar eisimpleir, a' sàbhaladh cumhachd no atharrachadh hyper-innealan.
///
/// Tha seo a 'ghnìomh eadar-dhealaichte bho [`thread::yield_now`] a tha dìreach gus am faighear an t-siostam a' chlàr phrògraman, ach `spin_loop` chan eil eadar-obrachadh leis an t-siostam-obrachaidh.
///
/// Tha cùis cleachdaidh cumanta airson `spin_loop` a `cur an gnìomh snìomh dòchasach crìochnaichte ann an lùb CAS ann am prìomhairean sioncronaidh.
/// Gus duilgheadasan leithid tionndadh prìomhachais a sheachnadh, thathas a `moladh gu làidir gun tèid an lùb snìomh a thoirt gu crìch an dèidh tomhas crìochnaichte de itealain agus gun tèid siostam bacaidh iomchaidh a dhèanamh.
///
///
/// **Nòta**: Air àrd-ùrlaran nach cuir taic ri bhith a `faighinn sanasan lùb-lùb chan eil an gnìomh seo a` dèanamh dad idir.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Luach atamach co-roinnte a chleachdas snàithleanan gus co-òrdanachadh
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Ann an snàithlean cùil suidhichidh sinn an luach aig a `cheann thall
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Do cuid obair, an uair sin dèan an luach beò
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Air ais air an t-snàthainn gnàthach againn, bidh sinn a `feitheamh ris an luach a shuidheachadh
/// while !live.load(Ordering::Acquire) {
///     // Tha an lùb snìomh mar mholadh don CPU a tha sinn a `feitheamh, ach is dòcha nach ann airson ùine mhòr
/////
///     hint::spin_loop();
/// }
///
/// // Tha an luach a tha a-nis air a stèidheachadh
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // Sàbhailteachd: a `cfg` attr cinnteach gu bheil sinn a-mhàin an gnìomh seo air a x86 targaidean.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SÀBHAILTEACHD: bidh an attr `cfg` a `dèanamh cinnteach nach cuir sinn an gnìomh seo ach air targaidean x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SÀBHAILTEACHD: bidh an attr `cfg` a `dèanamh cinnteach nach cuir sinn an gnìomh seo ach air targaidean aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SÀBHAILTEACHD: bidh an attr `cfg` a `dèanamh cinnteach nach cuir sinn an gnìomh seo ach air targaidean gàirdean
            // le taic airson v6 feart.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Dreuchd dearbh-aithne a tha *__ a `toirt __* don trusaiche a bhith gu ìre mhòr dòchasach mu na dh` fhaodadh `black_box` a dhèanamh.
///
/// Eu-coltach ri [`std::convert::identity`], thathas a `brosnachadh co-chruinneadair Rust a bhith a` gabhail ris gum faod `black_box` `dummy` a chleachdadh ann an dòigh dhligheach sam bith a tha ceadaichte còd Rust gun a bhith a `toirt a-steach giùlan neo-mhìnichte anns a` chòd gairm.
///
/// Tha an togalach seo a `dèanamh `black_box` feumail airson còd a sgrìobhadh anns nach eilear ag iarraidh cuid de optimizations, leithid slatan-tomhais.
///
/// Thoir fa-near ge-tà, gu bheil e a-mhàin `black_box` (agus is urrainn ach) air a tairgsinn air stèidh "best-effort".An ìre gu bheil e a 'urrainn a bhacadh optimisations dòcha a' crochadh air an àrd-ùrlar agus an còd-gen backend chleachdadh.
/// Chan urrainn dha prògraman a bhith an urra ri `black_box` airson *ceart* ann an dòigh sam bith.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Feumaidh sinn "use" an argamaid ann an dòigh air choreigin LLVM chan urrainn introspect, agus air targaidean a 'toirt taic do e faodaidh sinn mar as trice leudachaidh inline seanadh seo a dhèanamh.
    // Is e mìneachadh LLVM air co-chruinneachadh in-loidhne gur e bogsa math a th `ann, uill.
    // Chan e seo am buileachadh as motha oir tha e coltach gu bheil e a `dì-dhealbhadh barrachd na tha sinn ag iarraidh, ach tha e gu ruige seo math gu leòr.
    //
    //

    #[cfg(not(miri))] // Chan eil an seo ach beagan, mar sin tha e ceart gu leòr sgiobadh ann am Miri.
    // SÀBHAILTEACHD: tha an co-chruinneachadh in-loidhne neo-op.
    unsafe {
        // FIXME: Chan urrainn `asm!` a 'cleachdadh seach nach eil ea' toirt taic do agus MIPS eile architectures.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}