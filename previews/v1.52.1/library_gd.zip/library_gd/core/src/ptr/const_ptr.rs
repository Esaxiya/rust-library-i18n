use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// A `tilleadh `true` ma tha am putan null.
    ///
    /// Thoir fa-near gu bheil mòran chomharran null a dh `fhaodadh a bhith ann an seòrsan neo-mheasgaichte, oir is e dìreach an comharraiche dàta amh a thathas a` beachdachadh, chan e an fhaid, an gluasad, msaa.
    /// Mar sin, is dòcha nach bi dà phuing a tha null fhathast a `dèanamh coimeas eadar a chèile.
    ///
    /// ## Giùlan rè measadh const
    ///
    /// Nuair a thèid an gnìomh seo a chleachdadh rè measadh const, is dòcha gun till e `false` airson molaidhean a thig a-mach gu bhith null aig àm-ruith.
    /// Gu sònraichte, nuair a thèid puing gu cuid de chuimhne a chothromachadh taobh a-muigh a chrìochan ann an dòigh gus am bi am puing a thig às a sin null, tillidh an gnìomh `false` fhathast.
    ///
    /// Chan eil dòigh sam bith ann gum bi fios aig CTFE air suidheachadh iomlan a `chuimhne sin, agus mar sin chan urrainn dhuinn innse a bheil am puing null no nach eil.
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Dèan coimeas eadar cast ri puing tana, agus mar sin chan eil comharran geir a `beachdachadh ach air a` phàirt "data" aca airson neoni-neoni.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// A `tilgeadh gu stiùireadh de sheòrsa eile.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Cuir sìos comharradh (is dòcha farsaing) a-steach do phàirtean seòlaidh is meata-dàta.
    ///
    /// Faodar am puing ath-thogail le [`from_raw_parts`] nas fhaide air adhart.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// A `tilleadh `None` ma tha am putan null, no ma thilleas e iomradh co-roinnte air an luach a tha air a phasgadh ann an `Some`.Ma tha luach Faodar uninitialized, [`as_uninit_ref`] feumar a chleachdadh an àite.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Nuair a bhios tu a `gairm a` mhodh seo, feumaidh tu dèanamh cinnteach gu bheil *an dàrna cuid* am puing NULL *no* tha a h-uile gin de na leanas fìor:
    ///
    /// * Feumaidh am puing a bhith air a cho-thaobhadh gu ceart.
    ///
    /// * Feumaidh e a bhith "dereferencable" anns an t-seadh a tha air a mhìneachadh ann an [the module documentation].
    ///
    /// * Tha a 'chomharra a chomharrachadh, feumaidh a thòiseachadh an eisimpleir de `T`.
    ///
    /// * Feumaidh tu riaghailtean aliasing Rust a chuir an gnìomh, oir tha an ùine beatha `'a` a chaidh a thilleadh air a thaghadh gu neo-riaghailteach agus chan eil sin gu riatanach a `nochdadh fìor bheatha an dàta.
    ///   Gu sònraichte, fhad `s a mhaireas am beatha seo, chan fhaod an cuimhne a tha am puing a` comharrachadh a dhol fo bhrùthadh (ach a-staigh `UnsafeCell`).
    ///
    /// Tha seo fìor ged nach biodh toradh an dòigh seo air a chleachdadh!
    /// (Chan eil a `phàirt mu bhith air a thòiseachadh air a cho-dhùnadh gu h-iomlan fhathast, ach gus am bi e, is e an aon dòigh sàbhailte dèanamh cinnteach gu bheil iad air an tòiseachadh.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Tionndadh neo-sgrùdaichte
    ///
    /// Ma tha thu cinnteach nach urrainn don phuing a bhith a-riamh null agus gu bheil thu a `coimhead airson seòrsa de `as_ref_unchecked` a thilleas an `&T` an àite `Option<&T>`, fios agad gun urrainn dhut am puing a dhì-cheadachadh gu dìreach.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gu bheil `self` dligheach
        // airson fiosrachadh mura h-eil e null.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// A `tilleadh `None` ma tha am puing null, no ma thilleas e iomradh co-roinnte air an luach a tha air a phasgadh ann an `Some`.
    /// An coimeas ri [`as_ref`], chan eil seo ag iarraidh gum feumar an luach a thòiseachadh.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Nuair a bhios tu a `gairm a` mhodh seo, feumaidh tu dèanamh cinnteach gu bheil *an dàrna cuid* am puing NULL *no* tha a h-uile gin de na leanas fìor:
    ///
    /// * Feumaidh am puing a bhith air a cho-thaobhadh gu ceart.
    ///
    /// * Feumaidh e a bhith "dereferencable" anns an t-seadh a tha air a mhìneachadh ann an [the module documentation].
    ///
    /// * Feumaidh tu riaghailtean aliasing Rust a chuir an gnìomh, oir tha an ùine beatha `'a` a chaidh a thilleadh air a thaghadh gu neo-riaghailteach agus chan eil sin gu riatanach a `nochdadh fìor bheatha an dàta.
    ///
    ///   Gu sònraichte, fhad `s a mhaireas am beatha seo, chan fhaod an cuimhne a tha am puing a` comharrachadh a dhol fo bhrùthadh (ach a-staigh `UnsafeCell`).
    ///
    /// Tha seo fìor ged nach biodh toradh an dòigh seo air a chleachdadh!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gum bi `self` a `coinneachadh ris na h-uile
        // riatanasan airson iomradh.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Obraich a-mach an fhrith-thionndadh bho stiùireadh.
    ///
    /// `count` tha e ann an aonadan T;me, tha `count` de 3 a `riochdachadh frith-thionndadh de `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Ma thèid gin de na cumhaichean a leanas a bhriseadh, is e an toradh Giùlan Neo-mhìnichte:
    ///
    /// * Feumaidh an dà chuid a `phuing tòiseachaidh agus a` bhuil a thig às a bhith an dàrna cuid ann an crìochan no aon bhit seachad air deireadh an aon rud a chaidh a riarachadh.
    /// Cuimhnich gur ann Rust, gach (stack-allocated) caochlaideach air a mheas fa leth a riarachadh nì.
    ///
    /// * Chan urrainn don chothromachadh coimpiutaichte,**ann am bytes**, `isize` a thoirt thairis.
    ///
    /// * Chan urrainn don chothromachadh a bhith ann an crìochan a bhith an urra ri "wrapping around" an àite seòlaidh.Is e sin, feumaidh an t-suim neo-chrìochnach-mionaideach,**ann am bytes** a bhith a `freagairt ann an gnàthachadh.
    ///
    /// Bidh an co-chruinneachadh agus an leabharlann àbhaisteach mar as trice a `feuchainn ri dèanamh cinnteach nach bi cuibhreannan a-riamh a` ruighinn meud far a bheil frith-bhualadh na uallach.
    /// Mar eisimpleir, bidh `Vec` agus `Box` a `dèanamh cinnteach nach bi iad a-riamh a` riarachadh barrachd air `isize::MAX` bytes, agus mar sin tha `vec.as_ptr().add(vec.len())` an-còmhnaidh sàbhailte.
    ///
    /// Gu bunaiteach chan urrainn don mhòr-chuid de àrd-chabhsairean eadhon a leithid de riarachadh a thogail.
    /// Mar eisimpleir, chan urrainn dha àrd-ùrlar 64-bit aithnichte a-riamh iarrtas a chuir a-steach airson 2 <sup>63</sup> bytes mar thoradh air crìochan clàr-duilleig no a bhith a `sgoltadh an àite seòlaidh.
    /// Ach, is dòcha gum bi cuid de àrd-ùrlaran 32-bit agus 16-bit gu soirbheachail a `frithealadh iarrtas airson barrachd air bytes `isize::MAX` le rudan mar leudachadh corporra fiosaigeach.
    ///
    /// Mar sin, dh `fhaodadh gum bi cuimhne a chaidh fhaighinn gu dìreach bho luchd-sgaoilidh no faidhlichean le mapa cuimhne * ro mhòr airson a làimhseachadh leis a` ghnìomh seo.
    ///
    /// Beachdaich air a bhith a `cleachdadh [`wrapping_offset`] an àite ma tha na cuingeadan sin duilich a choileanadh.
    /// Is e an aon bhuannachd den dòigh seo gu bheil e a `comasachadh optimachadh co-chruinneachaidh nas ionnsaigheach.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `offset` a chumail suas.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Bidh e a `tomhas a` chothromachadh bho neach-comharrachaidh a `cleachdadh àireamhachd pasgadh.
    ///
    /// `count` tha e ann an aonadan T;me, tha `count` de 3 a `riochdachadh frith-thionndadh de `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Tha an obrachadh seo fhèin an-còmhnaidh sàbhailte, ach chan eil a bhith a `cleachdadh a` phuing a thig às.
    ///
    /// Tha am fiosaiche a thig às a seo fhathast ceangailte ris an aon rud a chaidh a riarachadh a tha `self` a `comharrachadh.
    /// Is dòcha nach bi e * air a chleachdadh gus faighinn gu rud eadar-dhealaichte.Thoir fa-near, ann an Rust, gu bheil a h-uile caochladair (stack-allocated) air a mheas mar nì air leth.
    ///
    /// Ann am faclan eile, chan eil `let z = x.wrapping_offset((y as isize) - (x as isize))`*a `dèanamh* a` dèanamh `z` an aon rud ri `y` eadhon ged a tha sinn a `gabhail ris gu bheil meud `1` aig `T` agus nach eil cus sruthadh ann: tha `z` fhathast ceangailte ris an nì `x` ceangailte ris, agus a` dì-chlàradh tha e na ghiùlan neo-mhìnichte mura h-eil `x` agus Puing `y` a-steach don aon rud a chaidh a riarachadh.
    ///
    /// An coimeas ri [`offset`], tha an dòigh seo gu bunaiteach a `cur dàil air an riatanas a bhith a` fuireach taobh a-staigh an aon rud a chaidh a riarachadh: tha [`offset`] sa bhad Giùlan gun mhìneachadh nuair a tha e a `dol thairis air crìochan nithean;Bidh `wrapping_offset` a`toirt a-mach stiùireadh ach bidh e fhathast a` leantainn gu Giùlan Neo-mhìnichte ma tha puing air a dhì-chlàradh nuair a tha e taobh a-muigh crìochan an nì ris a bheil e ceangailte.
    /// [`offset`] faodar a bharrachadh nas fheàrr agus mar sin tha e nas fheàrr ann an còd mothachail air coileanadh.
    ///
    /// Chan eil an sgrùdadh dàil a `beachdachadh ach air luach a` phuing a chaidh a dhì-chlàradh, chan e na luachan eadar-mheadhanach a chaidh a chleachdadh nuair a bha an toradh deireannach air a thomhas.
    /// Mar eisimpleir, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` tha daonnan an aon rud ri `x`.Ann am faclan eile, tha e ceadaichte an rud a chaidh a riarachadh fhàgail agus an uairsin a thoirt a-steach a-rithist.
    ///
    /// Ma dh `fheumas tu a dhol thairis air crìochan nithean, tilg a` phuing gu integer agus dèan an àireamhachd an sin.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// // Iterate a `cleachdadh pointeadair amh ann an àrdachadh de dhà eileamaid
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Tha an lùb seo a `clò-bhualadh "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SÀBHAILTEACHD: chan eil ro-ghoireasan aig an `arith_offset` intrinsic.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Obraich a-mach an astar eadar dà phuing.Tha an luach air a thilleadh ann an aonadan de T: tha an astar ann am bytes air a roinn le `mem::size_of::<T>()`.
    ///
    /// Is e an gnìomh seo an taobh eile de [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Ma thèid gin de na cumhaichean a leanas a bhriseadh, is e an toradh Giùlan Neo-mhìnichte:
    ///
    /// * Feumaidh an dà chuid an toiseach agus an neach-comharrachaidh eile a bhith an dàrna cuid ann an crìochan no aon bhit seachad air deireadh an aon rud a chaidh a riarachadh.
    /// Cuimhnich gur ann Rust, gach (stack-allocated) caochlaideach air a mheas fa leth a riarachadh nì.
    ///
    /// * Feumaidh an dà phuing a bhith *a `tighinn bho* stiùireadh chun an aon rud.
    ///   (Faic gu h-ìosal airson eisimpleir.)
    ///
    /// * Feumaidh an astar eadar na comharran, ann am bytes, a bhith na fhìor iomadachaidh de mheud `T`.
    ///
    /// * Chan urrainn don astar eadar na comharran,**ann am bytes**, `isize` a thoirt thairis.
    ///
    /// * Chan urrainn don astar a bhith ann an crìochan a bhith an urra ri "wrapping around" an àite seòlaidh.
    ///
    /// Chan eil seòrsaichean Rust a-riamh nas motha na cuibhreannan `isize::MAX` agus Rust a-riamh a `cuairteachadh an àite seòlaidh, agus mar sin bidh dà phuing taobh a-staigh cuid de luach de sheòrsa Rust `T` an-còmhnaidh a` sàsachadh an dà chumha mu dheireadh.
    ///
    /// Bidh an leabharlann àbhaisteach cuideachd a `dèanamh cinnteach nach bi cuibhreannan a-riamh a` ruighinn meud far a bheil frith-bhualadh na uallach.
    /// Mar eisimpleir, bidh `Vec` agus `Box` a `dèanamh cinnteach nach bi iad a-riamh a` riarachadh barrachd air `isize::MAX` bytes, agus mar sin bidh `ptr_into_vec.offset_from(vec.as_ptr())` an-còmhnaidh a `sàsachadh an dà chumha mu dheireadh.
    ///
    /// Gu bunaiteach chan urrainn don mhòr-chuid de àrd-chabhsairean eadhon riarachadh cho mòr a thogail.
    /// Mar eisimpleir, chan urrainn dha àrd-ùrlar 64-bit aithnichte a-riamh iarrtas a chuir a-steach airson 2 <sup>63</sup> bytes mar thoradh air crìochan clàr-duilleig no a bhith a `sgoltadh an àite seòlaidh.
    /// Ach, is dòcha gum bi cuid de àrd-ùrlaran 32-bit agus 16-bit gu soirbheachail a `frithealadh iarrtas airson barrachd air bytes `isize::MAX` le rudan mar leudachadh corporra fiosaigeach.
    /// Mar sin, dh `fhaodadh gum bi cuimhne a chaidh fhaighinn gu dìreach bho luchd-sgaoilidh no faidhlichean le mapa cuimhne * ro mhòr airson a làimhseachadh leis a` ghnìomh seo.
    /// (Thoir fa-near gu bheil an aon chuingealachadh aig [`offset`] agus [`add`] agus mar sin chan urrainnear an cleachdadh air cuibhreannan cho mòr an dàrna cuid.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Tha an gnìomh seo panics ma tha `T` na sheòrsa Zero-Sized ("ZST").
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// Cleachdadh *ceàrr*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Dèan ptr2_other an "alias" de ptr2, ach thig e bho ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Leis gu bheil ptr2_other agus ptr2 a `tighinn bho chomharran gu diofar nithean, is e giùlan neo-mhìnichte a th` ann an coimpiutaireachd an aghaidh, eadhon ged a tha iad a `comharrachadh an aon sheòladh!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Giùlan neo-mhìnichte
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `ptr_offset_from` a chumail suas.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// A `tilleadh a bheil barantas gu bheil dà phuing co-ionann.
    ///
    /// Aig àm-ruith tha an gnìomh seo gad ghiùlan fhèin mar `self == other`.
    /// Ach, ann an cuid de cho-theacsan (me, ri chèile-ùine mheasadh), chan eil e daonnan comasach gus co-dhùnadh co-ionannachd dà Pointers, mar sin a 'ghnìomh seo a dh'fhaodadh spuriously till `false` airson Pointers sin an dèidh dha-rìribh Cuir a-mach a bhith co-ionnan.
    ///
    /// Ach nuair a thilleas e `true`, tha cinnt ann gum bi na molaidhean co-ionann.
    ///
    /// Tha an gnìomh seo mar sgàthan [`guaranteed_ne`], ach chan e an taobh eile.Tha coimeasan puing ann airson an dà ghnìomh a `tilleadh `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Dh `fhaodadh an luach toraidh atharrachadh a rèir an dreach co-chruinneachaidh agus is dòcha nach bi còd mì-shàbhailte an urra ri toradh na gnìomh seo airson neart.
    /// Thathas a `moladh an gnìomh seo a chleachdadh a-mhàin airson optimizations coileanaidh far nach eil luachan tilleadh `false` spùtach leis a` ghnìomh seo a `toirt buaidh air toradh, ach dìreach an coileanadh.
    /// Cha deach sgrùdadh a dhèanamh air a `bhuaidh a tha aig a bhith a` cleachdadh an dòigh seo gus ùine ruith agus còd ùine-giùlain a ghiùlan gu eadar-dhealaichte.
    /// Cha bu chòir an dòigh seo a chleachdadh gus eadar-dhealachaidhean mar sin a thoirt a-steach, agus cha bu chòir a chumail seasmhach cuideachd mus bi tuigse nas fheàrr againn air a `chùis seo.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// A `tilleadh a bheil barantas gu bheil dà chomharra neo-chothromach.
    ///
    /// Aig àm-ruith tha an gnìomh seo gad ghiùlan fhèin mar `self != other`.
    /// Ach, ann an cuid de cho-theacsan (me, luachadh ùine-cruinneachaidh), chan eil e an-còmhnaidh comasach neo-ionannachd dà phuing a dhearbhadh, agus mar sin dh `fhaodadh an gnìomh seo `false` a thilleadh gu sporious airson molaidhean a tha nas fhaide air adhart a` tionndadh gu bhith neo-chothromach.
    ///
    /// Ach nuair a thilleas e `true`, tha cinnt ann gum bi na molaidhean neo-ionann.
    ///
    /// Tha an gnìomh seo mar sgàthan [`guaranteed_eq`], ach chan e an taobh eile.Tha coimeasan puing ann airson an dà ghnìomh a `tilleadh `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Dh `fhaodadh an luach toraidh atharrachadh a rèir an dreach co-chruinneachaidh agus is dòcha nach bi còd mì-shàbhailte an urra ri toradh na gnìomh seo airson neart.
    /// Thathas a `moladh an gnìomh seo a chleachdadh a-mhàin airson optimizations coileanaidh far nach eil luachan tilleadh `false` spùtach leis a` ghnìomh seo a `toirt buaidh air toradh, ach dìreach an coileanadh.
    /// Cha deach sgrùdadh a dhèanamh air a `bhuaidh a tha aig a bhith a` cleachdadh an dòigh seo gus ùine ruith agus còd ùine-giùlain a ghiùlan gu eadar-dhealaichte.
    /// Cha bu chòir an dòigh seo a chleachdadh gus eadar-dhealachaidhean mar sin a thoirt a-steach, agus cha bu chòir a chumail seasmhach cuideachd mus bi tuigse nas fheàrr againn air a `chùis seo.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Obraich a-mach an fhrith-thionndadh bho stiùireadh (goireasachd airson `.offset(count as isize)`).
    ///
    /// `count` tha e ann an aonadan T;me, tha `count` de 3 a `riochdachadh frith-thionndadh de `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Ma thèid gin de na cumhaichean a leanas a bhriseadh, is e an toradh Giùlan Neo-mhìnichte:
    ///
    /// * Feumaidh an dà chuid a `phuing tòiseachaidh agus a` bhuil a thig às a bhith an dàrna cuid ann an crìochan no aon bhit seachad air deireadh an aon rud a chaidh a riarachadh.
    /// Cuimhnich gur ann Rust, gach (stack-allocated) caochlaideach air a mheas fa leth a riarachadh nì.
    ///
    /// * Chan urrainn don chothromachadh coimpiutaichte,**ann am bytes**, `isize` a thoirt thairis.
    ///
    /// * Chan urrainn don chothromachadh a bhith ann an crìochan a bhith an urra ri "wrapping around" an àite seòlaidh.Is e sin, feumaidh an sùim neo-chrìochnach-mionaideach a bhith a `freagairt ann an `usize`.
    ///
    /// Bidh an co-chruinneachadh agus an leabharlann àbhaisteach mar as trice a `feuchainn ri dèanamh cinnteach nach bi cuibhreannan a-riamh a` ruighinn meud far a bheil frith-bhualadh na uallach.
    /// Mar eisimpleir, bidh `Vec` agus `Box` a `dèanamh cinnteach nach bi iad a-riamh a` riarachadh barrachd air `isize::MAX` bytes, agus mar sin tha `vec.as_ptr().add(vec.len())` an-còmhnaidh sàbhailte.
    ///
    /// Gu bunaiteach chan urrainn don mhòr-chuid de àrd-chabhsairean eadhon a leithid de riarachadh a thogail.
    /// Mar eisimpleir, chan urrainn dha àrd-ùrlar 64-bit aithnichte a-riamh iarrtas a chuir a-steach airson 2 <sup>63</sup> bytes mar thoradh air crìochan clàr-duilleig no a bhith a `sgoltadh an àite seòlaidh.
    /// Ach, is dòcha gum bi cuid de àrd-ùrlaran 32-bit agus 16-bit gu soirbheachail a `frithealadh iarrtas airson barrachd air bytes `isize::MAX` le rudan mar leudachadh corporra fiosaigeach.
    ///
    /// Mar sin, dh `fhaodadh gum bi cuimhne a chaidh fhaighinn gu dìreach bho luchd-sgaoilidh no faidhlichean le mapa cuimhne * ro mhòr airson a làimhseachadh leis a` ghnìomh seo.
    ///
    /// Beachdaich air a bhith a `cleachdadh [`wrapping_add`] an àite ma tha na cuingeadan sin duilich a choileanadh.
    /// Is e an aon bhuannachd den dòigh seo gu bheil e a `comasachadh optimachadh co-chruinneachaidh nas ionnsaigheach.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `offset` a chumail suas.
        unsafe { self.offset(count as isize) }
    }

    /// Obraich a-mach an fhrith-thionndadh bho stiùireadh (goireasachd airson `.offset ((cunnt mar isize).wrapping_neg())`).)
    ///
    /// `count` tha e ann an aonadan T;me, tha `count` de 3 a `riochdachadh frith-thionndadh de `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Ma thèid gin de na cumhaichean a leanas a bhriseadh, is e an toradh Giùlan Neo-mhìnichte:
    ///
    /// * Feumaidh an dà chuid a `phuing tòiseachaidh agus a` bhuil a thig às a bhith an dàrna cuid ann an crìochan no aon bhit seachad air deireadh an aon rud a chaidh a riarachadh.
    /// Cuimhnich gur ann Rust, gach (stack-allocated) caochlaideach air a mheas fa leth a riarachadh nì.
    ///
    /// * Chan urrainn don chothromachadh àireamhaichte a bhith nas àirde na `isize::MAX`**bytes**.
    ///
    /// * Chan urrainn don chothromachadh a bhith ann an crìochan a bhith an urra ri "wrapping around" an àite seòlaidh.Is e sin, feumaidh an t-suim neo-chrìochnach-mionaideach a bhith a `freagairt ann an cleachdadh.
    ///
    /// Bidh an co-chruinneachadh agus an leabharlann àbhaisteach mar as trice a `feuchainn ri dèanamh cinnteach nach bi cuibhreannan a-riamh a` ruighinn meud far a bheil frith-bhualadh na uallach.
    /// Mar eisimpleir, bidh `Vec` agus `Box` a `dèanamh cinnteach nach bi iad a-riamh a` riarachadh barrachd air `isize::MAX` bytes, agus mar sin tha `vec.as_ptr().add(vec.len()).sub(vec.len())` an-còmhnaidh sàbhailte.
    ///
    /// Gu bunaiteach chan urrainn don mhòr-chuid de àrd-chabhsairean eadhon a leithid de riarachadh a thogail.
    /// Mar eisimpleir, chan urrainn dha àrd-ùrlar 64-bit aithnichte a-riamh iarrtas a chuir a-steach airson 2 <sup>63</sup> bytes mar thoradh air crìochan clàr-duilleig no a bhith a `sgoltadh an àite seòlaidh.
    /// Ach, is dòcha gum bi cuid de àrd-ùrlaran 32-bit agus 16-bit gu soirbheachail a `frithealadh iarrtas airson barrachd air bytes `isize::MAX` le rudan mar leudachadh corporra fiosaigeach.
    ///
    /// Mar sin, dh `fhaodadh gum bi cuimhne a chaidh fhaighinn gu dìreach bho luchd-sgaoilidh no faidhlichean le mapa cuimhne * ro mhòr airson a làimhseachadh leis a` ghnìomh seo.
    ///
    /// Beachdaich air a bhith a `cleachdadh [`wrapping_sub`] an àite ma tha na cuingeadan sin duilich a choileanadh.
    /// Is e an aon bhuannachd den dòigh seo gu bheil e a `comasachadh optimachadh co-chruinneachaidh nas ionnsaigheach.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `offset` a chumail suas.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Bidh e a `tomhas a` chothromachadh bho neach-comharrachaidh a `cleachdadh àireamhachd pasgadh.
    /// (goireasachd airson `.wrapping_offset(count as isize)`)
    ///
    /// `count` tha e ann an aonadan T;me, tha `count` de 3 a `riochdachadh frith-thionndadh de `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Tha an obrachadh seo fhèin an-còmhnaidh sàbhailte, ach chan eil a bhith a `cleachdadh a` phuing a thig às.
    ///
    /// Tha am fiosaiche a thig às a seo fhathast ceangailte ris an aon rud a chaidh a riarachadh a tha `self` a `comharrachadh.
    /// Is dòcha nach bi e * air a chleachdadh gus faighinn gu rud eadar-dhealaichte.Thoir fa-near, ann an Rust, gu bheil a h-uile caochladair (stack-allocated) air a mheas mar nì air leth.
    ///
    /// Ann am faclan eile, chan eil `let z = x.wrapping_add((y as usize) - (x as usize))`*a `dèanamh* a` dèanamh `z` an aon rud ri `y` eadhon ged a tha sinn a `gabhail ris gu bheil meud `1` aig `T` agus nach eil cus sruthadh ann: tha `z` fhathast ceangailte ris an nì `x` ceangailte ris, agus a` dì-chlàradh tha e na ghiùlan neo-mhìnichte mura h-eil `x` agus Puing `y` a-steach don aon rud a chaidh a riarachadh.
    ///
    /// An coimeas ri [`add`], tha an dòigh seo gu bunaiteach a `cur dàil air an riatanas a bhith a` fuireach taobh a-staigh an aon rud a chaidh a riarachadh: tha [`add`] sa bhad Giùlan neo-mhìnichte nuair a tha e a `dol thairis air crìochan nithean;Bidh `wrapping_add` a`toirt a-mach stiùireadh ach bidh e fhathast a` leantainn gu Giùlan Neo-mhìnichte ma tha puing air a dhì-chlàradh nuair a tha e taobh a-muigh crìochan an nì ris a bheil e ceangailte.
    /// [`add`] faodar a bharrachadh nas fheàrr agus mar sin tha e nas fheàrr ann an còd mothachail air coileanadh.
    ///
    /// Chan eil an sgrùdadh dàil a `beachdachadh ach air luach a` phuing a chaidh a dhì-chlàradh, chan e na luachan eadar-mheadhanach a chaidh a chleachdadh nuair a bha an toradh deireannach air a thomhas.
    /// Mar eisimpleir, tha `x.wrapping_add(o).wrapping_sub(o)` an-còmhnaidh an aon rud ri `x`.Ann am faclan eile, tha e ceadaichte an rud a chaidh a riarachadh fhàgail agus an uairsin a thoirt a-steach a-rithist.
    ///
    /// Ma dh `fheumas tu a dhol thairis air crìochan nithean, tilg a` phuing gu integer agus dèan an àireamhachd an sin.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// // Iterate a `cleachdadh pointeadair amh ann an àrdachadh de dhà eileamaid
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Tha an lùb seo a `clò-bhualadh "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Bidh e a `tomhas a` chothromachadh bho neach-comharrachaidh a `cleachdadh àireamhachd pasgadh.
    /// (goireasachd airson `.wrapping_offset ((cunnt mar isize).wrapping_neg())`).)
    ///
    /// `count` tha e ann an aonadan T;me, tha `count` de 3 a `riochdachadh frith-thionndadh de `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Tha an obrachadh seo fhèin an-còmhnaidh sàbhailte, ach chan eil a bhith a `cleachdadh a` phuing a thig às.
    ///
    /// Tha am fiosaiche a thig às a seo fhathast ceangailte ris an aon rud a chaidh a riarachadh a tha `self` a `comharrachadh.
    /// Is dòcha nach bi e * air a chleachdadh gus faighinn gu rud eadar-dhealaichte.Thoir fa-near, ann an Rust, gu bheil a h-uile caochladair (stack-allocated) air a mheas mar nì air leth.
    ///
    /// Ann am faclan eile, chan eil `let z = x.wrapping_sub((x as usize) - (y as usize))`*a `dèanamh* a` dèanamh `z` an aon rud ri `y` eadhon ged a tha sinn a `gabhail ris gu bheil meud `1` aig `T` agus nach eil cus sruthadh ann: tha `z` fhathast ceangailte ris an nì `x` ceangailte ris, agus a` dì-chlàradh tha e na ghiùlan neo-mhìnichte mura h-eil `x` agus Puing `y` a-steach don aon rud a chaidh a riarachadh.
    ///
    /// An coimeas ri [`sub`], tha an dòigh seo gu bunaiteach a `cur dàil air an riatanas a bhith a` fuireach taobh a-staigh an aon rud a chaidh a riarachadh: tha [`sub`] sa bhad Giùlan gun mhìneachadh nuair a tha e a `dol thairis air crìochan nithean;Bidh `wrapping_sub` a`toirt a-mach stiùireadh ach bidh e fhathast a` leantainn gu Giùlan Neo-mhìnichte ma tha puing air a dhì-chlàradh nuair a tha e taobh a-muigh crìochan an nì ris a bheil e ceangailte.
    /// [`sub`] faodar a bharrachadh nas fheàrr agus mar sin tha e nas fheàrr ann an còd mothachail air coileanadh.
    ///
    /// Chan eil an sgrùdadh dàil a `beachdachadh ach air luach a` phuing a chaidh a dhì-chlàradh, chan e na luachan eadar-mheadhanach a chaidh a chleachdadh nuair a bha an toradh deireannach air a thomhas.
    /// Mar eisimpleir, tha `x.wrapping_add(o).wrapping_sub(o)` an-còmhnaidh an aon rud ri `x`.Ann am faclan eile, tha e ceadaichte an rud a chaidh a riarachadh fhàgail agus an uairsin a thoirt a-steach a-rithist.
    ///
    /// Ma dh `fheumas tu a dhol thairis air crìochan nithean, tilg a` phuing gu integer agus dèan an àireamhachd an sin.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Cleachdadh bunaiteach:
    ///
    /// ```
    /// // Iterate a `cleachdadh pointeadair amh ann an àrdachadh de dhà eileamaid (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Tha an lùb seo a `clò-bhualadh "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// A `suidheachadh luach a` phuing gu `ptr`.
    ///
    /// Ma tha `self` na chomharradh (fat) gu seòrsa neo-mheasgaichte, cha toir an obrachadh seo buaidh ach air a `phàirt phuing, ach airson comharran (thin) gu seòrsan meud, tha an aon bhuaidh aig seo air sònrachadh sìmplidh.
    ///
    /// Bidh dearbhadh aig `val` air a `phuing a tha mar thoradh air, ie, airson comharradh geir, tha an obrachadh seo gu semantically an aon rud ri bhith a` cruthachadh puing geir ùr le luach puing dàta `val` ach meata-dàta `self`.
    ///
    ///
    /// # Examples
    ///
    /// Tha an gnìomh seo gu sònraichte feumail airson a bhith a `ceadachadh àireamhachd puing byte-glic air molaidhean a dh` fhaodadh a bhith reamhar:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // clò-bhualaidh "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // SÀBHAILTEACHD: Ann an cùis puing tana, tha an obair seo co-ionann
        // gu sònrachadh sìmplidh.
        // Ann an cùis puing geir, leis a `bhuileachadh gnàthach puing saill, is e a` chiad raon de leithid de chomharradh an-còmhnaidh am puing dàta, a tha air a shònrachadh mar an ceudna.
        //
        unsafe { *thin = val };
        self
    }

    /// Leugh an luach bho `self` gun a bhith ga ghluasad.
    /// Tha seo a `fàgail a` chuimhne ann an `self` gun atharrachadh.
    ///
    /// Faic [`ptr::read`] airson draghan sàbhailteachd agus eisimpleirean.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `read` a chumail suas.
        unsafe { read(self) }
    }

    /// A `dèanamh leughadh luaineach den luach bho `self` gun a bhith ga ghluasad.Tha seo a`fàgail a` chuimhne ann an `self` gun atharrachadh.
    ///
    /// Thathar an dùil gum bi gnìomhachd luaineach ag obair air cuimhne I/O, agus tha iad cinnteach nach bi an trusaiche a `faighinn cuidhteas no ath-òrdachadh thairis air obraichean luaineach eile.
    ///
    ///
    /// Faic [`ptr::read_volatile`] airson draghan sàbhailteachd agus eisimpleirean.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `read_volatile` a chumail suas.
        unsafe { read_volatile(self) }
    }

    /// Leugh an luach bho `self` gun a bhith ga ghluasad.
    /// Tha seo a `fàgail a` chuimhne ann an `self` gun atharrachadh.
    ///
    /// Eu-coltach ri `read`, faodaidh am puing a bhith gun ainm.
    ///
    /// Faic [`ptr::read_unaligned`] airson draghan sàbhailteachd agus eisimpleirean.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `read_unaligned` a chumail suas.
        unsafe { read_unaligned(self) }
    }

    /// Dèan leth-bhreacan de bytes `count * size_of<T>` bho `self` gu `dest`.
    /// Faodaidh an stòr agus an ceann-uidhe a dhol thairis air.
    ///
    /// NOTE: tha seo aig an aon òrdugh argamaid * ri [`ptr::copy`].
    ///
    /// Faic [`ptr::copy`] airson draghan sàbhailteachd agus eisimpleirean.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `copy` a chumail suas.
        unsafe { copy(self, dest, count) }
    }

    /// Dèan leth-bhreacan de bytes `count * size_of<T>` bho `self` gu `dest`.
    /// Is dòcha nach bi an stòr agus an ceann-uidhe * a `dol thairis air.
    ///
    /// NOTE: tha seo aig an aon òrdugh argamaid * ri [`ptr::copy_nonoverlapping`].
    ///
    /// Faic [`ptr::copy_nonoverlapping`] airson draghan sàbhailteachd agus eisimpleirean.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `copy_nonoverlapping` a chumail suas.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// A `dèanamh coimeas eadar an fhrith-thionndadh a dh` fheumar a chuir an sàs anns a `phuing gus am bi e ceangailte ri `align`.
    ///
    /// Mura h-eil e comasach am puing a cho-thaobhadh, tillidh am buileachadh `usize::MAX`.
    /// Tha e ceadaichte don bhuileachadh *an-còmhnaidh* tilleadh `usize::MAX`.
    /// Chan fhaod ach coileanadh an algairim agad a bhith an urra ri bhith a `faighinn cothrom air a chleachdadh an seo, chan e cho ceart.
    ///
    /// Tha an fhrith-thionndadh air a chuir an cèill ann an àireamh de eileamaidean `T`, agus chan e bytes.Faodar an luach a chaidh a thilleadh a chleachdadh leis an dòigh `wrapping_add`.
    ///
    /// Chan eil geallaidhean sam bith ann nach bi cuir an aghaidh a `phuing a` dol thairis no a `dol nas fhaide na an riarachadh a tha am puing a` comharrachadh.
    ///
    /// Tha e an urra ris an neach-fios a bhith a `dèanamh cinnteach gu bheil an cothromachadh a chaidh a thilleadh ceart anns a h-uile teirm ach co-thaobhadh.
    ///
    /// # Panics
    ///
    /// A `ghnìomh panics mura h-eil `align` na chumhachd de dhà.
    ///
    /// # Examples
    ///
    /// A `faighinn gu `u8` a tha faisg air làimh mar `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // ged a dh `fhaodar a` phuing a cho-thaobhadh tro `offset`, bhiodh e a `comharrachadh taobh a-muigh an riarachadh
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SÀBHAILTEACHD: Chaidh sgrùdadh a dhèanamh air `align` mar chumhachd 2 gu h-àrd
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// A `tilleadh fad sliseag amh.
    ///
    /// Is e an luach a chaidh a thilleadh an àireamh de **eileamaidean**, chan e an àireamh de bytes.
    ///
    /// Tha an gnìomh seo sàbhailte, eadhon nuair nach urrainnear an sliseag amh a thilgeil gu iomradh sliseag oir tha am puing null no gun ainm.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SÀBHAILTEACHD: tha seo sàbhailte oir tha an aon dreach aig `*const [T]` agus `FatPtr<T>`.
            // Chan urrainn ach `std` an gealladh seo a thoirt seachad.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// A `tilleadh stiùireadh amh gu bufair an t-sliseag.
    ///
    /// Tha seo co-ionnan ri bhith a `tilgeil `self` gu `*const T`, ach nas sàbhailte de sheòrsa.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// A `tilleadh stiùireadh amh gu eileamaid no subslice, gun a bhith a` dèanamh sgrùdadh air crìochan.
    ///
    /// Is e a bhith a `gairm an dòigh seo le clàr-amais taobh a-muigh crìochan no nuair nach eil `self` dereferencable *[giùlan neo-mhìnichte]* eadhon ged nach eilear a` cleachdadh a `phuing a thig às.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SÀBHAILTEACHD: bidh an neach-fios a `dèanamh cinnteach gu bheil `self` dereferencable agus `index` a-steach.
        unsafe { index.get_unchecked(self) }
    }

    /// A `tilleadh `None` ma tha am puing null, no ma thilleas e sliseag roinnte chun luach a tha air a phasgadh ann an `Some`.
    /// An coimeas ri [`as_ref`], chan eil seo ag iarraidh gum feumar an luach a thòiseachadh.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Nuair a bhios tu a `gairm a` mhodh seo, feumaidh tu dèanamh cinnteach gu bheil *an dàrna cuid* am puing NULL *no* tha a h-uile gin de na leanas fìor:
    ///
    /// * Feumaidh an comharradh a bhith [valid] airson leughaidhean airson `ptr.len() * mem::size_of::<T>()` mòran bytes, agus feumaidh e a bhith air a cho-thaobhadh gu ceart.Tha seo a `ciallachadh gu sònraichte:
    ///
    ///     * Feumaidh an raon cuimhne gu lèir den t-slice seo a bhith taobh a-staigh aon nì a chaidh a riarachadh!
    ///       Chan urrainn dha sliseagan a dhol thairis air iomadh rud a chaidh a riarachadh.
    ///
    ///     * Feumaidh am puing a bhith air a cho-thaobhadh eadhon airson sliseagan de dh'fhaid neoni.
    ///     Is e aon adhbhar airson seo gum faod optimachadh cruth enum a bhith an urra ri iomraidhean (a `toirt a-steach sliseagan de dh` fhaid sam bith) a bhith air an aon rèir agus neo-null gus an eadar-dhealachadh bho dàta eile.
    ///
    ///     Gheibh thu stiùireadh a ghabhas cleachdadh mar `data` airson sliseagan de dh'fhaid neoni a `cleachdadh [`NonNull::dangling()`].
    ///
    /// * Chan fhaod meud iomlan `ptr.len() * mem::size_of::<T>()` an t-sliseag a bhith nas motha na `isize::MAX`.
    ///   Faic sgrìobhainnean sàbhailteachd [`pointer::offset`].
    ///
    /// * Feumaidh tu riaghailtean aliasing Rust a chuir an gnìomh, oir tha an ùine beatha `'a` a chaidh a thilleadh air a thaghadh gu neo-riaghailteach agus chan eil sin gu riatanach a `nochdadh fìor bheatha an dàta.
    ///   Gu sònraichte, fhad `s a mhaireas am beatha seo, chan fhaod an cuimhne a tha am puing a` comharrachadh a dhol fo bhrùthadh (ach a-staigh `UnsafeCell`).
    ///
    /// Tha seo fìor ged nach biodh toradh an dòigh seo air a chleachdadh!
    ///
    /// Faic cuideachd [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `as_uninit_slice` a chumail suas.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Co-ionannachd airson molaidhean
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Coimeas airson molaidhean
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}