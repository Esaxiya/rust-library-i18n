use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Pasgadair timcheall air `*mut T` amh neo-null a tha a `nochdadh gur ann le sealbhadair an inneal-fillte seo a tha an tagraiche.
/// Feumail airson a bhith a `togail às-tharraingean mar `Box<T>`, `Vec<T>`, `String`, agus `HashMap<K, V>`.
///
/// Eu-coltach ri `*mut T`, tha `Unique<T>` a `giùlan "as if" bha e na eisimpleir de `T`.
/// Bidh e a `buileachadh `Send`/`Sync` mas e `T` `Send`/`Sync`.
/// Tha e cuideachd a `ciallachadh an seòrsa barantas làidir aliasing ris am faod dùil a bhith aig eisimpleir `T`:
/// cha bu chòir tagraiche a `phuing atharrachadh às aonais slighe gun samhail dha fhèin.
///
/// Mura h-eil thu cinnteach a bheil e ceart `Unique` a chleachdadh airson na h-adhbharan agad, smaoinich air `NonNull` a chleachdadh, aig a bheil semantics nas laige.
///
///
/// Eu-coltach ri `*mut T`, feumaidh am puing a bhith neo-null an-còmhnaidh, eadhon ged nach eil am puing gu bràth air a dhì-chlàradh.
/// Tha seo gus am faod enums an luach toirmisgte seo a chleachdadh mar leth-bhreith-tha an aon mheud ri `Unique<T>` aig `Option<Unique<T>>`.
/// Ach dh `fhaodadh gum bi am puing fhathast a` crochadh mura h-eil e air a dhì-chlàradh.
///
/// Eu-coltach ri `*mut T`, tha `Unique<T>` covariant thairis air `T`.
/// Bu chòir seo a bhith an-còmhnaidh ceart airson seòrsa sam bith a tha a `cumail suas riatanasan aliasing Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: chan eil buaidh sam bith aig a `chomharra seo air caochlaideachd, ach tha e riatanach
    // airson dropck a bhith a `tuigsinn gu bheil seilbh againn gu loidsigeach air `T`.
    //
    // Airson mion-fhiosrachadh, faic:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` tha molaidhean `Send` ma tha `T` `Send` seach gu bheil an dàta air a bheil iad a `toirt iomradh neo-phàirteach.
/// Thoir fa-near gu bheil an inviasiant aliasing seo neo-èiginneach leis an t-siostam seòrsa;an abstraction a 'cleachdadh an `Unique` Feumaidh sparradh e.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` tha molaidhean `Sync` ma tha `T` `Sync` seach gu bheil an dàta air a bheil iad a `toirt iomradh neo-phàirteach.
/// Thoir fa-near gu bheil an inviasiant aliasing seo neo-èiginneach leis an t-siostam seòrsa;an abstraction a 'cleachdadh an `Unique` Feumaidh sparradh e.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// A `cruthachadh `Unique` ùr a tha crochte, ach air a dheagh cho-thaobhadh.
    ///
    /// Tha seo feumail airson a bhith a `tòiseachadh sheòrsan a bhios a` riarachadh leisg, mar a bhios `Vec::new` a `dèanamh.
    ///
    /// Thoir fa-near gur dòcha gu bheil luach a `phuing a` riochdachadh comharradh dligheach gu `T`, a `ciallachadh nach fhaodar seo a chleachdadh mar luach sentinel "not yet initialized".
    /// Feumaidh seòrsan a bhios a `riarachadh leisg sùil a chumail air tòiseachadh le dòigh eile.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SÀBHAILTEACHD: Bidh mem::align_of() a `tilleadh stiùireadh dligheach, neo-null.Tha an
        // mar sin thathas a `toirt urram do chumhachan airson new_unchecked() a ghairm.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// A `cruthachadh `Unique` ùr.
    ///
    /// # Safety
    ///
    /// `ptr` feumar a bhith neo-null.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gu bheil `ptr` neo-null.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// A `cruthachadh `Unique` ùr ma tha `ptr` neo-null.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SÀBHAILTEACHD: Chaidh am puing a sgrùdadh mu thràth agus chan eil e null.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// A `faighinn a` phuing `*mut` bunaiteach.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// A `dì-cheadachadh an t-susbaint.
    ///
    /// Tha an ùine beatha a tha mar thoradh air a cheangal ris fhèin agus mar sin bidh seo ga ghiùlan "as if" bha e gu dearbh na eisimpleir de T a tha a `faighinn iasad.
    /// Ma tha feum air beatha (unbound) nas fhaide, cleachd `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gum bi `self` a `coinneachadh ris na h-uile
        // riatanasan airson iomradh.
        unsafe { &*self.as_ptr() }
    }

    /// Bidh e gu mòr a `dì-chlàradh an t-susbaint.
    ///
    /// Tha an ùine beatha a tha mar thoradh air a cheangal ris fhèin agus mar sin bidh seo ga ghiùlan "as if" bha e gu dearbh na eisimpleir de T a tha a `faighinn iasad.
    /// Ma tha feum air beatha (unbound) nas fhaide, cleachd `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gum bi `self` a `coinneachadh ris na h-uile
        // riatanasan airson iomradh mutable.
        unsafe { &mut *self.as_ptr() }
    }

    /// A `tilgeadh gu stiùireadh de sheòrsa eile.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SÀBHAILTEACHD: Tha Unique::new_unchecked() a `cruthachadh rud sònraichte ùr agus feumalachdan
        // cha bu chòir am puing a chaidh a thoirt seachad a bhith null.
        // Leis gu bheil sinn a `dol seachad oirnn fhèin mar chomharradh, chan urrainn dhuinn a bhith null.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SÀBHAILTEACHD: Chan urrainnear iomradh gluasadach a chuir air falbh
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}