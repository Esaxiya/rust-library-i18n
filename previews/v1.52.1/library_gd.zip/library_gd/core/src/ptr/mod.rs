//! A `riaghladh cuimhne le làimh tro chomharran amh.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Bidh mòran de dhleastanasan sa mhodal seo a `gabhail bheachdan amh mar argamaidean agus a` leughadh bhuapa no a `sgrìobhadh thuca.Gus am bi seo sàbhailte, feumaidh na molaidhean sin a bhith *dligheach*.
//! Tha co-dhiù a bheil puing dligheach an urra ris an obair a thathas a `cleachdadh dha (leugh no sgrìobh), agus ìre a` chuimhne a gheibhear thuige (ie, cia mheud byte a tha read/written).
//! Bidh a `mhòr-chuid de dhleastanasan a` cleachdadh `*mut T` agus `* const T` gus faighinn gu dìreach aon luach, agus sa chùis seo tha an sgrìobhainn a `fàgail a-mach meud agus a` gabhail ris gu h-obann gur e `size_of::<T>()` bytes a th `ann.
//!
//! Chan eil na riaghailtean mionaideach airson dligheachd air an co-dhùnadh fhathast.Tha na geallaidhean a tha air an toirt seachad aig an ìre seo glè bheag:
//!
//! * Chan eil comharradh [null]*a-riamh* dligheach, chan eil eadhon airson ruigsinneachd [size zero][zst].
//! * Airson chomharra a bhith dligheach, tha e riatanach, ach chan eil gu leòr, gun a bhith na chomharra dereferenceable * *: chuimhneachan air raon de thoirt meud a 'tòiseachadh aig a' chomharra Feumaidh a h-uile a bhith taobh a-staigh crìochan an aon rud a riarachadh.
//!
//! Cuimhnich gur ann Rust, gach (stack-allocated) caochlaideach air a mheas fa leth a riarachadh nì.
//! * Fiù `s airson obrachaidhean de [size zero][zst], cha bu chòir don neach-comharrachaidh a bhith a` comharrachadh cuimhne tuigseach, ie, tha tuigseocation a `dèanamh chomharran neo-dhligheach eadhon airson obair meud neoni.
//! Ach, tha a bhith a `tilgeil integer *litearra* neo-neoni gu comharradh dligheach airson ruigsinneachd meud neoni, eadhon ged a thachras gu bheil cuimhne air choireigin aig an t-seòladh sin agus ma gheibh e tuigse.
//! Tha seo a `freagairt ri bhith a` sgrìobhadh an neach-sgaoilidh agad fhèin: chan eil e glè dhuilich a bhith a `riarachadh nithean de mheud neoni.
//! Is e [`NonNull::dangling`] an dòigh canonical airson comharradh fhaighinn a tha dligheach airson slighean meud neoni.
//! * Na h-uile a dhol a chluiche le gnìomhan ann am modal seo tha *neo-atamach* ann am mothachadh de [atomic operations] a chleachdadh gus synchronize eadar-innealan.
//! Tha seo a `ciallachadh gur e giùlan neo-mhìnichte a th` ann dà ruigsinneachd cho-aontach a dhèanamh chun aon àite bho dhiofar snàithlean mura leugh an dà ruigsinneachd a-mhàin bho chuimhne.
//! Thoir fa-near gu bheil seo gu sònraichte a `toirt a-steach [`read_volatile`] agus [`write_volatile`]: Chan urrainnear slighean so-ruigsinneach a chleachdadh airson sioncronadh eadar snàithlean.
//! * Tha toradh tilgeadh iomradh air comharradh dligheach cho fad `s a tha an rud bunaiteach beò agus nach eilear a` cleachdadh iomradh (dìreach comharran amh) gus faighinn chun aon chuimhne.
//!
//! Tha na axioms sin, còmhla ri bhith a `cleachdadh [`offset`] gu faiceallach airson àireamhachd puing, gu leòr gus mòran de rudan feumail a chuir an gnìomh gu ceart ann an còd neo-shàbhailte.
//! Thèid geallaidhean nas làidire a thoirt seachad aig a `cheann thall, leis gu bheil riaghailtean [aliasing] gan dearbhadh.
//! Airson barrachd fiosrachaidh, faic an [book] a thuilleadh air an earrann anns an t-iomradh seachad a [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Is dòcha nach eil comharran amh dligheach mar a chaidh a mhìneachadh gu h-àrd air an co-thaobhadh gu ceart (far a bheil co-thaobhadh "proper" air a mhìneachadh leis an t-seòrsa puing, ie, feumar `*const T` a cho-thaobhadh ri `mem::align_of::<T>()`).
//! Ach, feumaidh a `mhòr-chuid de dhleastanasan na h-argamaidean aca a cho-thaobhadh gu ceart, agus innsidh iad gu soilleir an riatanas seo anns na sgrìobhainnean aca.
//! Ainmeil Ach chan eil seo [`read_unaligned`] agus [`write_unaligned`].
//!
//! Nuair a dh `fheumas gnìomh co-thaobhadh ceart, nì e sin eadhon ged a tha meud 0 aig an ruigsinneachd, ie, eadhon ged nach eilear a` beantainn ri cuimhne.Beachdaich air a bhith a `cleachdadh [`NonNull::dangling`] ann an leithid de chùisean.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// A `cur gu bàs an inneal-sgrios (ma tha sin ann) den luach comharraichte.
///
/// Tha seo co-ionann gu semantically ri bhith a `gairm [`ptr::read`] agus a` tilgeil air falbh an toradh, ach tha na buannachdan a leanas aige:
///
/// * Tha e riatanach * a bhith a `cleachdadh `drop_in_place` gus seòrsan neo-mheasgaichte mar nithean trait a leigeil sìos, oir chan urrainnear an leughadh a-mach air a` chruach agus an leigeil sìos gu h-àbhaisteach.
///
/// * Tha e nas càirdeile don optimizer seo a dhèanamh thairis air [`ptr::read`] nuair a bhios e a `leigeil às cuimhne a chaidh a riarachadh le làimh (me, ann am buileachadh `Box`/`Rc`/`Vec`), leis nach fheum an trusaiche dearbhadh gu bheil e ceart a bhith a` cur às don leth-bhreac.
///
///
/// * Faodar a chleachdadh gus dàta [pinned] a leigeil sìos nuair nach eil `T` `repr(packed)` (chan fhaodar dàta pinn a ghluasad mus tèid a leigeil sìos).
///
/// Chan urrainnear luachan neo-chomharraichte a leigeil sìos nan àite, feumaidh iad a bhith air an lethbhreacadh gu àite co-thaobhach an toiseach a `cleachdadh [`ptr::read_unaligned`].Airson structaran pacaichte, thèid an gluasad seo a dhèanamh gu fèin-ghluasadach leis an trusaiche.
/// Tha seo a `ciallachadh nach eil na raointean de structaran pacaichte air an leigeil sìos nan àite.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Giùlan undefined ma tha gin de na cumhaichean a leanas a tha air an truailleadh:
///
/// * `to_drop` feumaidh [valid] a bhith ann airson gach cuid leughadh agus sgrìobhadh.
///
/// * `to_drop` feumar a cho-thaobhadh gu ceart.
///
/// * Feumaidh an luach `to_drop` puingean a bhith dligheach airson a leigeil sìos, a dh `fhaodadh gum feum e taic a thoirt do luchd-ionnsaigh a bharrachd, tha seo an urra ri seòrsa.
///
/// A bharrachd air an sin, mura e [`Copy`] a th `ann an `T`, faodaidh cleachdadh an luach comharraichte an dèidh `drop_in_place` a ghairm giùlan neo-mhìnichte.Thoir fa-near gu bheil `*to_drop = foo` a`cunntadh mar chleachdadh oir bheir e air an luach a leigeil sìos a-rithist.
/// [`write()`] faodar a chleachdadh gus dàta a sgrìobhadh thairis gun a bhith ag adhbhrachadh gun tèid a leigeil sìos.
///
/// Thoir fa-near, eadhon ged a tha meud `0` aig `T`, feumaidh am puing a bhith neo-NULL agus air a cho-thaobhadh gu ceart.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Làimh a thoirt air falbh an cuspair mu dheireadh bho vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Faigh stiùireadh amh chun an eileamaid mu dheireadh ann an `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Giorraich `v` gus casg a chuir air an rud mu dheireadh a leigeil sìos.
///     // Bidh sinn a `dèanamh sin an toiseach, gus casg a chuir air cùisean ma tha an `drop_in_place` fo panics.
///     v.set_len(1);
///     // Às aonais gairm `drop_in_place`, cha bhiodh an rud mu dheireadh air a leigeil sìos, agus bhiodh a `chuimhne a tha e a` riaghladh air a leigeil a-mach.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Dèan cinnteach gun deach an rud mu dheireadh a leigeil sìos.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Thoir fa-near gum bi an trusaiche a `dèanamh an leth-bhreac seo gu fèin-ghluasadach nuair a bhios tu a` leigeil sìos structaran pacaichte, ie, mar as trice cha leig thu leas a bhith draghail mu chùisean mar sin mura cuir thu fòn gu `drop_in_place` le làimh.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Chan eil diofar ann an còd an seo, tha an cruinneadair a `dol an àite seo.
    //

    // SÀBHAILTEACHD: faic am beachd gu h-àrd
    unsafe { drop_in_place(to_drop) }
}

/// A `cruthachadh comharradh amh null.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// A `cruthachadh stiùireadh amh null mutable.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Feumar impl làimhe gus `T: Clone` ceangailte a sheachnadh.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Feumar impl làimhe gus `T: Copy` ceangailte a sheachnadh.
impl<T> Copy for FatPtr<T> {}

/// A `cruthachadh sliseag amh bho stiùireadh agus faid.
///
/// Is e an argamaid `len` an àireamh de **eileamaidean**, chan e an àireamh de bytes.
///
/// Tha an gnìomh seo sàbhailte, ach gu dearbh tha a bhith a `cleachdadh an luach tillidh cunnartach.
/// Faic sgrìobhainnean [`slice::from_raw_parts`] airson riatanasan sàbhailteachd sliseag.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // cruthaich comharradh sliseag nuair a thòisicheas tu a-mach le stiùireadh chun chiad eileamaid
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SÀBHAILTEACHD: Tha faighinn chun luach bhon aonadh `Repr` sàbhailte bho * const [T]
        //
        // agus FatPtr aig a bheil na h-aon dealbhadh cuimhne.Chan urrainn ach std an gealladh seo a thoirt seachad.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// A `dèanamh an aon seòrsa gnìomh ri [`slice_from_raw_parts`], ach a-mhàin gu bheil sliseag mutable amh air a thilleadh, an taca ri sliseag amh dìonach.
///
///
/// Faic sgrìobhainnean [`slice_from_raw_parts`] airson tuilleadh fiosrachaidh.
///
/// Tha an gnìomh seo sàbhailte, ach gu dearbh tha a bhith a `cleachdadh an luach tillidh cunnartach.
/// Faic an sgrìobhainnean de [`slice::from_raw_parts_mut`] airson sliseag riatanasan sàbhailteachd.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // sònraich luach aig clàr-amais san t-sliseag
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SÀBHAILTEACHD: Tha faighinn chun luach bhon aonadh `Repr` sàbhailte bho * mut [T]
        // agus FatPtr aig a bheil na h-aon dealbhadh cuimhne
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Swaps na luachan aig dà mutable àiteachan den aon seòrsa, an dàrna cuid gun deinitializing.
///
/// Ach airson na leanas dà chuid, a 'ghnìomh seo a tha co-ionann ri semantically [`mem::swap`]:
///
///
/// * Bidh e ag obair air molaidhean amh an àite iomraidhean.
/// Nuair a tha iomraidhean rim faighinn, bu chòir [`mem::swap`] a thaghadh.
///
/// * Faodaidh an dà luach comharraichte a dhol an lùib a chèile.
/// Ma tha na luachan a `dol an lùib a chèile, thèid an roinn cuimhne a tha a` dol thairis air bho `x` a chleachdadh.
/// Chithear seo san dàrna eisimpleir gu h-ìosal.
///
/// # Safety
///
/// Giùlan undefined ma tha gin de na cumhaichean a leanas a tha air an truailleadh:
///
/// * Feumaidh an dà chuid `x` agus `y` a bhith [valid] airson gach cuid leughadh agus sgrìobhadh.
///
/// * Feumaidh an dà chuid `x` agus `y` a bhith air an aon rèir gu ceart.
///
/// Thoir fa-near, eadhon ged a tha meud `0` aig `T`, feumaidh na molaidhean a bhith neo-NULL agus air an co-thaobhadh gu ceart.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ag atharrachadh dà roinn nach eil a `dol an-sàs:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // is e seo `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // is e seo `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Ag atharrachadh dà roinn a tha a `dol an-sàs:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // is e seo `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // is e seo `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Tha clàran-amais `1..3` den t-sliseag a `dol an-sàs eadar `x` agus `y`.
///     // Bhiodh toraidhean reusanta dhaibh `[2, 3]`, gus am bi clàran-amais `0..3` `[1, 2, 3]` (a `maidseadh `y` ron `swap`);no airson gum bi iad `[0, 1]` gus am bi clàran-amais `1..4` `[0, 1, 2]` (a`maidseadh `x` ron `swap`).
/////
///     // Tha am buileachadh seo air a mhìneachadh gus an roghainn mu dheireadh a dhèanamh.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Thoir dhuinn fhìn beagan àite sgrìobaidh airson obrachadh leis.
    // Cha leig sinn a leas dragh a ghabhail mu thuiteam: chan eil `MaybeUninit` a `dèanamh dad nuair a thuiteas e.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Dèan an SÀBHAILTEACHD suaip: feumaidh an neach-conaltraidh gealltainn gu bheil `x` agus `y` dligheach airson sgrìobhadh agus co-thaobhadh gu ceart.
    // `tmp` chan urrainn dhaibh a bhith a `dol thairis air an dàrna cuid `x` no `y` oir bha `tmp` dìreach air a riarachadh air a` chruach mar rud a chaidh a riarachadh air leth.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` agus faodaidh `y` a dhol thairis air
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// A `dèanamh iomlaid air bytes `count * size_of::<T>()` eadar an dà roinn de chuimhne a` tòiseachadh aig `x` agus `y`.
/// Feumaidh an dà roinn * gun a bhith a `dol an lùib a chèile.
///
/// # Safety
///
/// Giùlan undefined ma tha gin de na cumhaichean a leanas a tha air an truailleadh:
///
/// * Feumaidh an dà chuid `x` agus `y` a bhith [valid] airson an dà chuid leughadh agus sgrìobhadh de `cunntadh *
///   meud_of: :<T>() `bytes.
///
/// * Feumaidh an dà chuid `x` agus `y` a bhith air an aon rèir gu ceart.
///
/// * An sgìre de chuimhne a `tòiseachadh aig `x` le meud de` cunntadh *
///   meud_of: :<T>() Feumaidh `bytes * gun a bhith a` dol thairis air an roinn cuimhne a `tòiseachadh aig `y` leis an aon mheud.
///
/// Cuimhnich gur fiù 's ma tha na h-èifeachdach a lethbhreacadh meud (`cunntadh * size_of: :<T>()`) is `0`, feumaidh na comharran a bhith neo-NULL agus air an co-thaobhadh gu ceart.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gu bheil `x` agus `y`
    // dligheach airson sgrìobhaidhean agus co-thaobhadh gu ceart.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Airson seòrsachan nas lugha na an optimization bloc gu h-ìosal, dìreach iomlaid gu dìreach gus pessimizing codegen a sheachnadh.
    //
    if mem::size_of::<T>() < 32 {
        // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gu bheil `x` agus `y` dligheach
        // airson sgrìobhaidhean, co-thaobhadh gu ceart, agus neo-cheangailte.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `swap_nonoverlapping` a chumail suas.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Is e an dòigh-obrach an seo simd a chleachdadh gus iomlaid x&y gu h-èifeachdach.
    // Tha deuchainnean a `nochdadh gur e iomlaid an dàrna cuid 32 bytes no 64 bytes aig an àm as èifeachdaiche airson pròiseasairean Intel Haswell E.
    // Tha LLVM nas comasaiche air a dhèanamh nas fheàrr ma bheir sinn #[repr(simd)] do structar, eadhon ged nach cleachd sinn an structar seo gu dìreach.
    //
    //
    // FIXME repr(simd) briste air emscripten agus redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Lùb tro x&y, gan copaigeadh `Block` aig àm Bu chòir don optimizer an lùb a thoirt a-mach gu h-iomlan airson a `mhòr-chuid de sheòrsan NB
    // Chan urrainn dhuinn lùb a chleachdadh oir tha an `range` impl a `gairm `mem::swap` gu ath-chuairteachail
    //
    let mut i = 0;
    while i + block_size <= len {
        // Cruthaich cuid de chuimhne neo-aithnichte mar àite sgrìobadh Tha foillseachadh `t` an seo a `seachnadh a bhith a` co-thaobhadh ris a `chruach nuair nach eilear a` cleachdadh an lùb seo
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SÀBHAILTEACHD: Mar `i < len`, agus mar a dh `fheumas an neach-fòn gealltainn gu bheil `x` agus `y` dligheach
        // airson `len` bytes, feumaidh `x + i` agus `y + i` a bhith nan seòlaidhean dligheach, a choileanas an cùmhnant sàbhailteachd airson `add`.
        //
        // Cuideachd, feumaidh an neach-conaltraidh gealltainn gu bheil `x` agus `y` dligheach airson sgrìobhaidhean, co-thaobhadh ceart, agus neo-cheangailte, a choileanas an cùmhnant sàbhailteachd airson `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Dèan iomlaid air bloc bytes de x&y, a `cleachdadh t mar bufair sealach Bu chòir seo a bhith air a mheudachadh gu gnìomhachd èifeachdach SIMD ma tha sin ri fhaighinn
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Dèan iomlaid air bytes sam bith a tha air fhàgail
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SÀBHAILTEACHD: faic beachd sàbhailteachd roimhe.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Gluais `src` a-steach don `dst` biorach, a `tilleadh an luach `dst` a bh` ann roimhe.
///
/// Chan eilear a `lughdachadh luach.
///
/// Tha an gnìomh seo co-ionann gu semantically ri [`mem::replace`] ach a-mhàin gu bheil e ag obair air comharran amh an àite iomraidhean.
/// Nuair a tha iomraidhean rim faighinn, bu chòir [`mem::replace`] a thaghadh.
///
/// # Safety
///
/// Giùlan undefined ma tha gin de na cumhaichean a leanas a tha air an truailleadh:
///
/// * `dst` feumaidh [valid] a bhith ann airson gach cuid leughadh agus sgrìobhadh.
///
/// * `dst` feumar a cho-thaobhadh gu ceart.
///
/// * `dst` feumaidh iad a bhith a `comharrachadh luach tòiseachaidh ceart de sheòrsa `T`.
///
/// Thoir fa-near, eadhon ged a tha meud `0` aig `T`, feumaidh am puing a bhith neo-NULL agus air a cho-thaobhadh gu ceart.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` bhiodh an aon bhuaidh aige gun a bhith ag iarraidh am bloc neo-shàbhailte.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gu bheil `dst` dligheach a bhith
    // tilgeadh gu iomradh gluasadach (dligheach airson sgrìobhadh, co-thaobhadh, tùsachadh), agus chan urrainn dha a dhol thairis air `src` oir feumaidh `dst` a bhith a `comharrachadh rud sònraichte a chaidh a riarachadh.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // chan urrainn dhaibh a dhol thairis air
    }
    src
}

/// Leugh an luach bho `src` gun a bhith ga ghluasad.Tha seo a 'fàgail an cuimhne ann an `src` atharrachadh.
///
/// # Safety
///
/// Giùlan undefined ma tha gin de na cumhaichean a leanas a tha air an truailleadh:
///
/// * `src` feumar a bhith [valid] airson leughaidhean.
///
/// * `src` feumar a cho-thaobhadh gu ceart.Cleachd [`read_unaligned`] mura h-eil seo mar sin.
///
/// * `src` feumaidh iad a bhith a `comharrachadh luach tòiseachaidh ceart de sheòrsa `T`.
///
/// Thoir fa-near, eadhon ged a tha meud `0` aig `T`, feumaidh am puing a bhith neo-NULL agus air a cho-thaobhadh gu ceart.
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`] làimh a chur an gnìomh:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Cruthaich leth-bhreac beagan den luach aig `a` ann an `tmp`.
///         let tmp = ptr::read(a);
///
///         // Le bhith a `fàgail aig an ìre seo (an dàrna cuid le bhith a` tilleadh gu follaiseach no le bhith a `gairm gnìomh a tha panics) dh` adhbhraicheadh an luach ann an `tmp` a leigeil sìos fhad `s a tha `a` fhathast a` toirt iomradh air an aon luach.
///         // Dh `fhaodadh seo giùlan neo-mhìnichte a bhrosnachadh mura h-e `T` `Copy`.
/////
/////
///
///         // Cruthaich leth-bhreac beagan den luach aig `b` ann an `a`.
///         // Tha seo sàbhailte oir chan urrainn dha iomraidhean gluasadach atharrais.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Mar a tha gu h-àrd, dh `fhaodadh a bhith a` fàgail an seo giùlan neo-mhìnichte a bhrosnachadh oir tha an aon luach air ainmeachadh le `a` agus `b`.
/////
///
///         // Gluais `tmp` a-steach do `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` air a ghluasad (tha `write` a `gabhail seilbh air an dàrna argamaid aige), agus mar sin chan eil dad air a leigeil sìos gu h-obann an seo.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Seilbh air an luach a chaidh a thilleadh
///
/// `read` a `cruthachadh leth-bhreac dòigheil de `T`, ge bith an e `T` [`Copy`].
/// Mura h-eil `T` [`Copy`], faodaidh a bhith a `cleachdadh an dà chuid an luach a chaidh a thilleadh agus an luach aig `*src` a dhol an aghaidh sàbhailteachd cuimhne.
/// Thoir fa-near gu bheil sònrachadh gu `*src` a `cunntadh mar chleachdadh oir feuchaidh e ris an luach aig `* src` a leigeil sìos.
///
/// [`write()`] faodar a chleachdadh gus dàta a sgrìobhadh thairis gun a bhith ag adhbhrachadh gun tèid a leigeil sìos.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` a-nis a `comharrachadh an aon chuimhne bunaiteach ri `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Le bhith a `sònrachadh do `s2` tha an luach tùsail aige air a leigeil sìos.
///     // Seachad air a `phuing seo, chan fhaodar `s` a chleachdadh tuilleadh, oir chaidh a` chuimhne bunaiteach a shaoradh.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Le bhith a `sònrachadh do `s` bhiodh an seann luach air a leigeil sìos a-rithist, a` leantainn gu giùlan neo-mhìnichte.
/////
///     // s= String::from("bar");//MEARACHD
///
///     // `ptr::write` faodar a chleachdadh gus luach a sgrìobhadh thairis gun a bhith ga leigeil sìos.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gu bheil `src` dligheach airson leughaidhean.
    // `src` chan urrainn dhaibh a dhol thairis air `tmp` oir bha `tmp` dìreach air a riarachadh air a `chruach mar rud air a riarachadh air leth.
    //
    //
    // Cuideachd, leis gun do sgrìobh sinn luach dligheach a-steach do `tmp`, tha e cinnteach gun tèid a thòiseachadh gu ceart.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Leugh an luach bho `src` gun a bhith ga ghluasad.Tha seo a 'fàgail an cuimhne ann an `src` atharrachadh.
///
/// Eu-coltach ri [`read`], tha `read_unaligned` ag obair le comharran neo-chomharraichte.
///
/// # Safety
///
/// Giùlan undefined ma tha gin de na cumhaichean a leanas a tha air an truailleadh:
///
/// * `src` feumar a bhith [valid] airson leughaidhean.
///
/// * `src` feumaidh iad a bhith a `comharrachadh luach tòiseachaidh ceart de sheòrsa `T`.
///
/// Coltach ri [`read`], bidh `read_unaligned` a `cruthachadh leth-bhreac dòigheil de `T`, ge bith an e `T` [`Copy`].
/// Mura h-eil `T` [`Copy`], faodaidh an dà chuid an luach a chaidh a thilleadh agus an luach aig `*src` [violate memory safety][read-ownership] a chleachdadh.
///
/// Thoir fa-near, eadhon ged a tha meud `0` aig `T`, feumaidh am puing a bhith neo-NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Air structaran `packed`
///
/// Tha e do-dhèanta an-dràsta comharran amh a chruthachadh gu raointean neo-chomharraichte de structar pacaichte.
///
/// Bidh a bhith a `feuchainn ri puing amh a chruthachadh gu raon structair `unaligned` le abairt mar `&packed.unaligned as *const FieldType` a` cruthachadh iomradh eadar-mheadhanach gun ainm mus atharraich thu sin gu comharraiche amh.
///
/// Tha an iomradh seo sealach agus air a thilgeadh sa bhad neo-chinnteach oir tha an neach-cruinneachaidh an-còmhnaidh a `dùileachadh gum bi iomraidhean air an co-thaobhadh gu ceart.
/// Mar thoradh air, a 'cleachdadh `&packed.unaligned as *const FieldType` ag adhbhrachadh sa bhad** undefined giùlan ann am prògram agad.
///
/// Is e eisimpleir de na rudan nach bu chòir a dhèanamh agus mar a tha seo a `buntainn ri `read_unaligned`:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // An seo bidh sinn a `feuchainn ri seòladh integer 32-bit a ghabhail nach eil air a cho-thaobhadh.
///     let unaligned =
///         // A sealach unaligned iomradh air a chruthachadh an seo a tha toraidhean ann undefined giùlan ge bith a bheil an t-iomradh a thathar a 'cleachdadh no nach eil.
/////
///         &packed.unaligned
///         // Cha bhith tilgeadh gu stiùireadh amh a `cuideachadh;thachair am mearachd mu thràth.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Tha e sàbhailte faighinn a-steach do raointean gun chomharradh gu dìreach le me `packed.unaligned`.
///
///
///
///
///
///
// FIXME: Ùraich docs stèidhichte air toradh RFC #2582 agus caraidean.
/// # Examples
///
/// Leugh luach usize bho bufair byte:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gu bheil `src` dligheach airson leughaidhean.
    // `src` chan urrainn dhaibh a dhol thairis air `tmp` oir bha `tmp` dìreach air a riarachadh air a `chruach mar rud air a riarachadh air leth.
    //
    //
    // Cuideachd, leis gun do sgrìobh sinn luach dligheach a-steach do `tmp`, tha e cinnteach gun tèid a thòiseachadh gu ceart.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// A `dol thairis air àite cuimhne leis an luach a chaidh a thoirt seachad gun a bhith a` leughadh no a `leigeil às an t-seann luach.
///
/// `write` nach leig às susbaint `dst`.
/// Tha seo sàbhailte, ach dh `fhaodadh e cuibhreannan no goireasan a leigeil ma sgaoil, agus mar sin bu chòir a bhith faiceallach gun a bhith a` toirt thairis air nì a bu chòir a leigeil sìos.
///
///
/// A bharrachd air an sin, chan eil e a `leigeil sìos `src`.Gu Semantically, tha `src` air a ghluasad a-steach don àite a tha air a chomharrachadh le `dst`.
///
/// Tha seo iomchaidh airson cuimhne neo-aithnichte a thòiseachadh, no cuimhne a sgrìobhadh thairis air an robh [`read`] roimhe.
///
/// # Safety
///
/// Giùlan undefined ma tha gin de na cumhaichean a leanas a tha air an truailleadh:
///
/// * `dst` feumaidh a bhith [valid] airson sgrìobhaidhean.
///
/// * `dst` feumar a cho-thaobhadh gu ceart.Cleachd [`write_unaligned`] mura h-eil seo mar sin.
///
/// Thoir fa-near, eadhon ged a tha meud `0` aig `T`, feumaidh am puing a bhith neo-NULL agus air a cho-thaobhadh gu ceart.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`] làimh a chur an gnìomh:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Cruthaich leth-bhreac beagan den luach aig `a` ann an `tmp`.
///         let tmp = ptr::read(a);
///
///         // Le bhith a `fàgail aig an ìre seo (an dàrna cuid le bhith a` tilleadh gu follaiseach no le bhith a `gairm gnìomh a tha panics) dh` adhbhraicheadh an luach ann an `tmp` a leigeil sìos fhad `s a tha `a` fhathast a` toirt iomradh air an aon luach.
///         // Dh `fhaodadh seo giùlan neo-mhìnichte a bhrosnachadh mura h-e `T` `Copy`.
/////
/////
///
///         // Cruthaich leth-bhreac beagan den luach aig `b` ann an `a`.
///         // Tha seo sàbhailte oir chan urrainn dha iomraidhean gluasadach atharrais.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Mar a tha gu h-àrd, dh `fhaodadh a bhith a` fàgail an seo giùlan neo-mhìnichte a bhrosnachadh oir tha an aon luach air ainmeachadh le `a` agus `b`.
/////
///
///         // Gluais `tmp` a-steach do `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` air a ghluasad (tha `write` a `gabhail seilbh air an dàrna argamaid aige), agus mar sin chan eil dad air a leigeil sìos gu h-obann an seo.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Tha sinn a `gairm an stuth bunaiteach gu dìreach gus gairmean gnìomh a sheachnadh anns a` chòd a chaidh a chruthachadh leis gur e gnìomh fillte a th `ann an `intrinsics::copy_nonoverlapping`.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gu bheil `dst` dligheach airson sgrìobhadh.
    // `dst` chan urrainn dhaibh a dhol thairis air `src` oir tha cothrom gluasadach aig an neach a tha a `fòn gu `dst` fhad` s a tha `src` leis a `ghnìomh seo.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// A `dol thairis air àite cuimhne leis an luach a chaidh a thoirt seachad gun a bhith a` leughadh no a `leigeil às an t-seann luach.
///
/// Eu-coltach ri [`write()`], faodaidh am puing a bhith gun ainm.
///
/// `write_unaligned` nach leig às susbaint `dst`.Tha seo sàbhailte, ach dh `fhaodadh e cuibhreannan no goireasan a leigeil ma sgaoil, agus mar sin bu chòir a bhith faiceallach gun a bhith a` toirt thairis air nì a bu chòir a leigeil sìos.
///
/// A bharrachd air an sin, chan eil e a `leigeil sìos `src`.Gu Semantically, tha `src` air a ghluasad a-steach don àite a tha air a chomharrachadh le `dst`.
///
/// Tha seo iomchaidh airson cuimhne neo-aithnichte a thòiseachadh, no cuimhne ath-sgrìobhaidh a chaidh a leughadh roimhe le [`read_unaligned`].
///
/// # Safety
///
/// Giùlan undefined ma tha gin de na cumhaichean a leanas a tha air an truailleadh:
///
/// * `dst` feumaidh a bhith [valid] airson sgrìobhaidhean.
///
/// Thoir fa-near, eadhon ged a tha meud `0` aig `T`, feumaidh am puing a bhith neo-NULL.
///
/// [valid]: self#safety
///
/// ## Air structaran `packed`
///
/// Tha e do-dhèanta an-dràsta comharran amh a chruthachadh gu raointean neo-chomharraichte de structar pacaichte.
///
/// Bidh a bhith a `feuchainn ri puing amh a chruthachadh gu raon structair `unaligned` le abairt mar `&packed.unaligned as *const FieldType` a` cruthachadh iomradh eadar-mheadhanach gun ainm mus atharraich thu sin gu comharraiche amh.
///
/// Tha an iomradh seo sealach agus air a thilgeadh sa bhad neo-chinnteach oir tha an neach-cruinneachaidh an-còmhnaidh a `dùileachadh gum bi iomraidhean air an co-thaobhadh gu ceart.
/// Mar thoradh air, a 'cleachdadh `&packed.unaligned as *const FieldType` ag adhbhrachadh sa bhad** undefined giùlan ann am prògram agad.
///
/// Tha eisimpleir de dè nach eil a dhèanamh agus mar a tha seo a 'buntainn ri `write_unaligned` tha:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // An seo bidh sinn a `feuchainn ri seòladh integer 32-bit a ghabhail nach eil air a cho-thaobhadh.
///     let unaligned =
///         // A sealach unaligned iomradh air a chruthachadh an seo a tha toraidhean ann undefined giùlan ge bith a bheil an t-iomradh a thathar a 'cleachdadh no nach eil.
/////
///         &mut packed.unaligned
///         // Cha bhith tilgeadh gu stiùireadh amh a `cuideachadh;thachair am mearachd mu thràth.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Tha e sàbhailte faighinn a-steach do raointean gun chomharradh gu dìreach le me `packed.unaligned`.
///
///
///
///
///
///
///
///
///
// FIXME: Ùraich docs stèidhichte air toradh RFC #2582 agus caraidean.
/// # Examples
///
/// Sgrìobh luach usize gu bufair byte:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gu bheil `dst` dligheach airson sgrìobhadh.
    // `dst` chan urrainn dhaibh a dhol thairis air `src` oir tha cothrom gluasadach aig an neach a tha a `fòn gu `dst` fhad` s a tha `src` leis a `ghnìomh seo.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Tha sinn ag iarraidh an ghnèitheach dìreach a sheachnadh gnìomh gairmean a chruthachadh ann an còd.
        intrinsics::forget(src);
    }
}

/// A `dèanamh leughadh luaineach den luach bho `src` gun a bhith ga ghluasad.Tha seo a`fàgail a` chuimhne ann an `src` gun atharrachadh.
///
/// Thathar an dùil gum bi gnìomhachd luaineach ag obair air cuimhne I/O, agus tha iad cinnteach nach bi an trusaiche a `faighinn cuidhteas no ath-òrdachadh thairis air obraichean luaineach eile.
///
/// # Notes
///
/// An-dràsta chan eil modal cuimhne a tha air a mhìneachadh gu cruaidh agus gu foirmeil aig Rust, agus mar sin tha na semantics mionaideach de na tha "volatile" a `ciallachadh an seo fo ùmhlachd atharrachadh thar ùine.
/// Le bhith ga ràdh, bidh na semantics cha mhòr an-còmhnaidh a `tighinn gu crìch gu math coltach ri [C11's definition of volatile][c11].
///
/// Cha bu chòir don chothlamair an òrdugh càirdeach no an àireamh de ghnìomhachd cuimhne luaineach atharrachadh.
/// Ach, tha obraichean cuimhne luaineach air seòrsan meud neoni (me, ma thèid seòrsa meud neoni a thoirt do `read_volatile`) nan noops agus faodar an leigeil seachad.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Giùlan undefined ma tha gin de na cumhaichean a leanas a tha air an truailleadh:
///
/// * `src` feumar a bhith [valid] airson leughaidhean.
///
/// * `src` feumar a cho-thaobhadh gu ceart.
///
/// * `src` feumaidh iad a bhith a `comharrachadh luach tòiseachaidh ceart de sheòrsa `T`.
///
/// Coltach ri [`read`], bidh `read_volatile` a `cruthachadh leth-bhreac dòigheil de `T`, ge bith an e `T` [`Copy`].
/// Mura h-eil `T` [`Copy`], faodaidh an dà chuid an luach a chaidh a thilleadh agus an luach aig `*src` [violate memory safety][read-ownership] a chleachdadh.
/// Ach, tha a bhith a `stòradh seòrsaichean neo-[` Copy`] ann an cuimhne luaineach cha mhòr cinnteach gu bheil iad ceàrr.
///
/// Thoir fa-near, eadhon ged a tha meud `0` aig `T`, feumaidh am puing a bhith neo-NULL agus air a cho-thaobhadh gu ceart.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Dìreach mar ann an C, ge bith a bheil gnìomhachd luaineach chan eil buaidh sam bith aige air ceistean co-cheangailte ri ruigsinneachd co-aontach bho ioma snàithlean.Bidh slighean so-ghiùlain gan giùlan fhèin dìreach mar ruigsinneachd neo-atamach a thaobh sin.
///
/// Gu sònraichte, tha rèis eadar `read_volatile` agus obair sgrìobhaidh sam bith chun an aon àite na ghiùlan neo-mhìnichte.
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Gun a bhith a `clisgeadh gus buaidh codegen a chumail nas lugha.
        abort();
    }
    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `volatile_load` a chumail suas.
    unsafe { intrinsics::volatile_load(src) }
}

/// A `dèanamh sgrìobhadh luaineach air àite cuimhne leis an luach a chaidh a thoirt seachad gun a bhith a` leughadh no a `leigeil às an t-seann luach.
///
/// Thathar an dùil gum bi gnìomhachd luaineach ag obair air cuimhne I/O, agus tha iad cinnteach nach bi an trusaiche a `faighinn cuidhteas no ath-òrdachadh thairis air obraichean luaineach eile.
///
/// `write_volatile` nach leig às susbaint `dst`.Tha seo sàbhailte, ach dh `fhaodadh e cuibhreannan no goireasan a leigeil ma sgaoil, agus mar sin bu chòir a bhith faiceallach gun a bhith a` toirt thairis air nì a bu chòir a leigeil sìos.
///
/// A bharrachd air an sin, chan eil e a `leigeil sìos `src`.Gu Semantically, tha `src` air a ghluasad a-steach don àite a tha air a chomharrachadh le `dst`.
///
/// # Notes
///
/// An-dràsta chan eil modal cuimhne a tha air a mhìneachadh gu cruaidh agus gu foirmeil aig Rust, agus mar sin tha na semantics mionaideach de na tha "volatile" a `ciallachadh an seo fo ùmhlachd atharrachadh thar ùine.
/// Le bhith ga ràdh, bidh na semantics cha mhòr an-còmhnaidh a `tighinn gu crìch gu math coltach ri [C11's definition of volatile][c11].
///
/// Cha bu chòir don chothlamair an òrdugh càirdeach no an àireamh de ghnìomhachd cuimhne luaineach atharrachadh.
/// Ach, tha obraichean cuimhne luaineach air seòrsan meud neoni (me, ma thèid seòrsa meud neoni a thoirt do `write_volatile`) nan noops agus faodar an leigeil seachad.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Giùlan undefined ma tha gin de na cumhaichean a leanas a tha air an truailleadh:
///
/// * `dst` feumaidh a bhith [valid] airson sgrìobhaidhean.
///
/// * `dst` feumar a cho-thaobhadh gu ceart.
///
/// Thoir fa-near, eadhon ged a tha meud `0` aig `T`, feumaidh am puing a bhith neo-NULL agus air a cho-thaobhadh gu ceart.
///
/// [valid]: self#safety
///
/// Dìreach mar ann an C, ge bith a bheil gnìomhachd luaineach chan eil buaidh sam bith aige air ceistean co-cheangailte ri ruigsinneachd co-aontach bho ioma snàithlean.Bidh slighean so-ghiùlain gan giùlan fhèin dìreach mar ruigsinneachd neo-atamach a thaobh sin.
///
/// Gu sònraichte, an rèis eadar `write_volatile` agus obrachadh sam bith eile (a 'leughadh no sgrìobhadh) air an aon location tha undefined giùlan.
///
/// # Examples
///
/// Cleachdadh bunaiteach:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Gun a bhith a `clisgeadh gus buaidh codegen a chumail nas lugha.
        abort();
    }
    // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `volatile_store` a chumail suas.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Co-thaobhadh puing `p`.
///
/// Obraich a-mach frith-bhualadh (a thaobh eileamaidean de `stride` stride) a dh `fheumar a chuir an sàs ann am puing `p` gus am faigheadh am puing `p` co-thaobhadh ri `a`.
///
/// Note: Chaidh am buileachadh seo a dhealbhadh gu faiceallach gus nach e panic.Tha e UB airson seo gu panic.
/// Tha a-mhàin fìor atharrachadh a dh'fhaodas a bhith air a dhèanamh an seo atharrachadh `INV_TABLE_MOD_16` agus co-cheangailte cunbhalachdan.
///
/// Ma cho-dhùnas sinn a-riamh a dhèanamh comasach an gnèitheach a ghairm le `a` nach eil na chumhachd de dhithis, is dòcha gum bi e nas glic dìreach atharrachadh gu buileachadh naive an àite a bhith a `feuchainn ri seo atharrachadh gus gabhail ris an atharrachadh sin.
///
///
/// Bidh ceistean sam bith a `dol gu@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Tha cleachdadh dìreach de na cleachdaidhean sin a `leasachadh codegen gu mòr aig ìre opt <=
    // 1, far nach eil na dreachan modh de na h-obraichean sin air an comharrachadh.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Obraich a-mach tionndadh modular iomadachaidh de `x` modulo `m`.
    ///
    /// Tha am buileachadh seo air a dhealbh airson `align_offset` agus tha na cumhachan a leanas:
    ///
    /// * `m` tha cumhachd-dhà;
    /// * `x < m`; (ma tha `x ≥ m`, pas ann an `x % m` na àite)
    ///
    /// Cha bhith buileachadh na gnìomh seo panic.Riamh.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Modulo clàr atharrachail modular 2lic=16.
        ///
        /// Thoir fa-near, nach eil luachan anns a `chlàr seo far nach eil taobh a-staigh (ie, airson `0⁻¹ mod 16`, `2⁻¹ mod 16`, msaa)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo airson a bheil an `INV_TABLE_MOD_16` an dùil.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SÀBHAILTEACHD: Feumaidh `m` a bhith na chumhachd de dhà, mar sin neo-neoni.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Bidh sinn ag itealaich "up" a `cleachdadh na foirmle a leanas:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // gu 2²ⁿ ≥ m.An uairsin is urrainn dhuinn lughdachadh chun `m` a tha sinn ag iarraidh le bhith a `toirt an toradh `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Thoir fa-near, gum bi sinn a `cleachdadh obraichean fillte an seo a dh`aona ghnothach-bidh am foirmle tùsail a` cleachdadh me, toirt air falbh `mod n`.
                // Tha e gu tur ceart `mod usize::MAX` a dhèanamh dhaibh nan àite, oir bidh sinn a `toirt an toradh `mod n` aig an deireadh co-dhiù.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // Sàbhailteachd: `a` a tha cumhachd a-dhà, uime sin neo-neoni.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` faodar cùis a thomhas nas sìmplidh tro `-p (mod a)`, ach tha a bhith a `dèanamh sin a` cur bacadh air comas LLVM stiùireadh mar `lea` a thaghadh.An àite sin bidh sinn a `dèanamh coimpiutaireachd
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // a bhios a `cuairteachadh obrachaidhean timcheall air giùlan luchdan, ach a` pessimizing `and` gu leòr airson LLVM a bhith comasach air na diofar optimizations a tha fios aige mu dheidhinn a chleachdadh.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // A-cheana ceangailte.Yay!
        return 0;
    } else if stride == 0 {
        // Mura h-eil am puing air a cho-thaobhadh, agus gu bheil an eileamaid de mheud neoni, cha bhith na h-eileamaidean gu bràth a `co-thaobhadh ris a` phuing.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SÀBHAILTEACHD: a tha cumhachd-de-dhà mar sin neo-neoni.stride==0 cùis air a làimhseachadh gu h-àrd.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SÀBHAILTEACHD: tha àrd-cheangal aig gcdpow a tha aig a `char as motha an àireamh de bhuillean ann an usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SÀBHAILTEACHD: tha gcd an-còmhnaidh nas motha no co-ionann ri 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Tha an branch seo a `fuasgladh airson an co-aontar sreathach loidhneach a leanas:
        //
        // ` p + so = 0 mod a `
        //
        // `p` an seo tha luach a `phuing, `s`, stride de `T`, `o` air a chothromachadh ann an` T`s, agus `a`, an co-thaobhadh a chaidh iarraidh.
        //
        // Le `g = gcd(a, s)`, agus an suidheachadh gu h-àrd ag ràdh gu bheil `p` cuideachd air a roinn le `g`, is urrainn dhuinn `a' = a/g`, `s' = s/g`, `p' = p/g` a chomharrachadh, agus an uairsin bidh seo co-ionann ri:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Is e a `chiad teirm "the relative alignment of `p` to `a`" (air a roinn leis an `g`), is e an dàrna teirm "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (a-rithist air a roinn le `g`).
        //
        // Tha sgaradh le `g` riatanach gus an taobh a-staigh a dhèanamh gu math mura h-eil `a` agus `s` co-phrìomhach.
        //
        // A bharrachd air an sin, chan e "minimal" an toradh a chaidh a thoirt a-mach leis an fhuasgladh seo, agus mar sin feumar an toradh `o mod lcm(s, a)` a ghabhail.Faodaidh sinn `lcm(s, a)` a chuir an àite le dìreach `a'`.
        //
        //
        //
        //
        //

        // SÀBHAILTEACHD: Tha àrd-cheangal aig `gcdpow` nach eil nas motha na an àireamh de 0-bits ann an `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SÀBHAILTEACHD: Tha `a2` neo-neoni.Chan urrainn do ghluasad `a` le `gcdpow` gluasad a-mach gin de na pìosan suidhichte
        // ann an `a` (tha fear dìreach aige).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SÀBHAILTEACHD: Tha àrd-cheangal aig `gcdpow` nach eil nas motha na an àireamh de 0-bits ann an `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SÀBHAILTEACHD: Tha àrd-cheangal aig `gcdpow` nach eil nas motha na an àireamh de 0-bit trailing a-steach
        // `a`.
        // A bharrachd air an sin, chan urrainn don toirt air falbh a dhol thairis air, oir bidh `a2 = a >> gcdpow` an-còmhnaidh nas motha na `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SÀBHAILTEACHD: Tha `a2` na chumhachd de dhà, mar a chaidh a dhearbhadh gu h-àrd.Tha `s2` gu math nas lugha na `a2`
        // seach gu bheil `(s % a) >> gcdpow` gu math nas ìsle na `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Cha ghabh seo a cho-thaobhadh idir.
    usize::MAX
}

/// Dèan coimeas eadar molaidhean amh airson co-ionannachd.
///
/// Tha seo an aon rud ri bhith a `cleachdadh a` ghnìomhaiche `==`, ach nas lugha gnèitheach:
/// feumaidh na h-argamaidean a bhith nan comharran amh `*const T`, chan e rud sam bith a chuireas `PartialEq` an gnìomh.
///
/// Faodar seo a chleachdadh gus coimeas a dhèanamh eadar iomraidhean `&T` (a tha a `tighinn gu `*const T` gu h-obann) leis an t-seòladh aca seach a bhith a` dèanamh coimeas eadar na luachan air a bheil iad a `comharrachadh (is e sin a tha buileachadh `PartialEq for &T` a` dèanamh).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Tha sliseagan cuideachd air an coimeas a rèir an fhaid (comharran geir):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Tha Traits cuideachd air an coimeas leis a `bhuileachadh aca:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Tha seòlaidhean co-ionann aig molaidhean.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Tha seòlaidhean co-ionann aig nithean, ach tha buileachadh eadar-dhealaichte aig `Trait`.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Tha atharrachadh an iomradh air `*const u8` a `dèanamh coimeas eadar seòladh.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash pointeadair amh.
///
/// Faodar seo a chleachdadh gus iomradh `&T` (a tha a `tighinn gu `*const T` gu h-obann) a sheòladh leis an t-seòladh aige seach an luach a tha e a` comharrachadh (is e sin a tha buileachadh `Hash for &T` a `dèanamh).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls airson molaidhean gnìomh
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Tha feum air an tilgeadh eadar-mheadhanach mar usize airson AVR
                // gus am bi àite seòlaidh a `phuing gnìomh stòr air a ghlèidheadh anns a` phuing gnìomh mu dheireadh.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Tha feum air an tilgeadh eadar-mheadhanach mar usize airson AVR
                // gus am bi àite seòlaidh a `phuing gnìomh stòr air a ghlèidheadh anns a` phuing gnìomh mu dheireadh.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Chan eil gnìomhan caochlaideach le 0 paramadairean
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Cruthaich stiùireadh amh `const` gu àite, gun a bhith a `cruthachadh iomradh eadar-mheadhanach.
///
/// Chan eil cruthachadh iomradh le `&`/`&mut` ceadaichte ach ma tha am puing air a cho-thaobhadh gu ceart agus a `comharrachadh dàta tùsail.
/// Ann an cùisean far nach eil na riatanasan sin ann, bu chòir molaidhean amh a chleachdadh nan àite.
/// Ach, tha `&expr as *const _` a `cruthachadh iomradh mus tilgear e gu comharradh amh, agus tha an t-iomradh sin fo ùmhlachd na h-aon riaghailtean ris a h-uile iomradh eile.
///
/// Faodaidh am macro seo puing amh *a chruthachadh gun* a bhith a `cruthachadh iomradh an toiseach.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` chruthaicheadh e iomradh gun ainm, agus mar sin a bhith na ghiùlan neo-mhìnichte!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Cruthaich stiùireadh amh `mut` gu àite, gun a bhith a `cruthachadh iomradh eadar-mheadhanach.
///
/// Chan eil cruthachadh iomradh le `&`/`&mut` ceadaichte ach ma tha am puing air a cho-thaobhadh gu ceart agus a `comharrachadh dàta tùsail.
/// Ann an cùisean far nach eil na riatanasan sin ann, bu chòir molaidhean amh a chleachdadh nan àite.
/// Ach, tha `&mut expr as *mut _` a `cruthachadh iomradh mus tilgear e gu comharradh amh, agus tha an t-iomradh sin fo ùmhlachd na h-aon riaghailtean ris a h-uile iomradh eile.
///
/// Faodaidh am macro seo puing amh *a chruthachadh gun* a bhith a `cruthachadh iomradh an toiseach.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` chruthaicheadh e iomradh gun ainm, agus mar sin a bhith na ghiùlan neo-mhìnichte!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` feachdan a `dèanamh lethbhreac den raon an àite a bhith a` cruthachadh teisteanas.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}