#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// A `toirt seachad an seòrsa meata-dàta puing de sheòrsa comharraichte sam bith.
///
/// # Meata-dàta puing
///
/// Faodar smaoineachadh air seòrsachan puing amh agus seòrsachan iomraidh ann an Rust mar dhà phàirt:
/// comharraiche dàta anns a bheil seòladh cuimhne an luach, agus cuid de mheata-dàta.
///
/// Airson seòrsachan meud staitistigeil (a bhios a `buileachadh an `Sized` traits) a bharrachd air airson seòrsachan `extern`, thathar ag ràdh gu bheil molaidhean` tana `: tha meata-dàta meud neoni agus an seòrsa `()`.
///
///
/// Thathas ag ràdh gu bheil comharran gu [dynamically-sized types][dst] `farsaing` no `reamhar`, tha meata-dàta neo-neoni aca:
///
/// * Airson structaran aig a bheil an raon mu dheireadh mar DST, is e meata-dàta am meata-dàta airson an raon mu dheireadh
/// * Airson an seòrsa `str`, is e meata-dàta an fhaid ann am bytes mar `usize`
/// * Airson seòrsaichean slice mar `[T]`, is e meata-dàta an fhaid ann an nithean mar `usize`
/// * Airson nithean trait mar `dyn SomeTrait`, is e meata-dàta [`DynMetadata<Self>`][DynMetadata] (me `DynMetadata<dyn SomeTrait>`)
///
/// Anns an future, is dòcha gum faigh an cànan Rust seòrsan ùra de sheòrsan aig a bheil meata-dàta puing eadar-dhealaichte.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # An `Pointee` trait
///
/// Is e puing an trait an seòrsa `Metadata` co-cheangailte ris, is e sin `()` no `usize` no `DynMetadata<_>` mar a chaidh a mhìneachadh gu h-àrd.
/// Tha e air a bhuileachadh gu fèin-ghluasadach airson gach seòrsa.
/// Faodar gabhail ris gu bheil e air a bhuileachadh ann an co-theacsa coitcheann, eadhon às aonais ceangal co-fhreagarrach.
///
/// # Usage
///
/// Faodar comharran amh a dhì-ghalarachadh a-steach don t-seòladh dàta agus na pàirtean meata-dàta leis an dòigh [`to_raw_parts`] aca.
///
/// Air neo, faodar meata-dàta leis fhèin a thoirt a-mach leis a `ghnìomh [`metadata`].
/// Faodar iomradh a thoirt air [`metadata`] agus air a sparradh gu follaiseach.
///
/// Faodar puing (possibly-wide) a chuir air ais còmhla bhon t-seòladh aige agus meata-dàta le [`from_raw_parts`] no [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// An seòrsa airson meata-dàta ann an molaidhean agus iomraidhean air `Self`.
    #[lang = "metadata_type"]
    // NOTE: Cùm trait bounds ann an `static_assert_expected_bounds_for_metadata`
    //
    // ann an `library/core/src/ptr/metadata.rs` ann an co-chòrdadh ris an fheadhainn an seo:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Tha molaidhean airson seòrsachan a tha a `buileachadh an ailias trait seo` tana `.
///
/// Tha seo a `toirt a-steach seòrsachan statach-`Sized` agus seòrsaichean `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: nach socraich seo mus bi ailiasan trait seasmhach sa chànan?
pub trait Thin = Pointee<Metadata = ()>;

/// Thoir a-mach am pàirt meata-dàta de phuing.
///
/// Faodar luachan de sheòrsa `*mut T`, `&T`, no `&mut T` a thoirt seachad gu dìreach chun ghnìomh seo oir tha iad gu h-obann a `co-èigneachadh gu `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SÀBHAILTEACHD: Tha faighinn chun luach bhon aonadh `PtrRepr` sàbhailte bho * const T.
    // agus PtrComponents<T>tha an aon chuimhneachan cruth.
    // Chan urrainn ach std an gealladh seo a thoirt seachad.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// A `cruthachadh stiùireadh amh (possibly-wide) bho sheòladh dàta agus meata-dàta.
///
/// Tha an gnìomh seo sàbhailte ach chan eil am puing a thilleas tu sàbhailte gu dì-cheadachadh.
/// Airson sliseagan, faic sgrìobhainnean [`slice::from_raw_parts`] airson riatanasan sàbhailteachd.
/// Airson nithean trait, feumaidh na meata-dàta a thighinn bho stiùireadh chun an aon sheòrsa bunasach.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SÀBHAILTEACHD: Tha faighinn chun luach bhon aonadh `PtrRepr` sàbhailte bho * const T.
    // agus PtrComponents<T>tha an aon chuimhneachan cruth.
    // Chan urrainn ach std an gealladh seo a thoirt seachad.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// A `dèanamh an aon seòrsa gnìomh ri [`from_raw_parts`], ach a-mhàin gu bheil comharradh `*mut` amh air a thilleadh, an àite puing `* const` amh.
///
///
/// Faic sgrìobhainnean [`from_raw_parts`] airson tuilleadh fiosrachaidh.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SÀBHAILTEACHD: Tha faighinn chun luach bhon aonadh `PtrRepr` sàbhailte bho * const T.
    // agus PtrComponents<T>tha an aon chuimhneachan cruth.
    // Chan urrainn ach std an gealladh seo a thoirt seachad.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Feumar impl làimhe gus `T: Copy` ceangailte a sheachnadh.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Feumar impl làimhe gus `T: Clone` ceangailte a sheachnadh.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Tha Metadata airson `Dyn = dyn SomeTrait` trait seòrsa rud.
///
/// Tha e na chomharradh air clàr so-ruigsinneach (clàr gairm brìgheil) a tha a `riochdachadh a h-uile fiosrachadh riatanach gus an seòrsa cruadhtan a tha air a stòradh am broinn rud trait a làimhseachadh.
/// An vtable gu sònraichte na bhroinn:
///
/// * meud seòrsa
/// * co-thaobhadh seòrsa
/// * stiùireadh airson impl `drop_in_place` den t-seòrsa (dh `fhaodadh seo a bhith na roghainn airson dàta seann-fhasanta)
/// * molaidhean airson a h-uile modh airson an seòrsa a chuir an gnìomh an trait
///
/// Thoir fa-near gu bheil a `chiad trì sònraichte oir tha feum orra gus rud trait sam bith a riarachadh, a leigeil sìos agus a thuigsinn.
///
/// Tha e comasach an structar seo ainmeachadh le paramadair seòrsa nach eil na nì `dyn` trait (mar eisimpleir `DynMetadata<u64>`) ach gun a bhith a `faighinn luach brìoghmhor den structar sin.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// An ro-leasachan cumanta de gach vtables.Tha e air a leantainn le molaidhean gnìomh airson modhan trait.
///
/// Mion-fhiosrachadh buileachaidh prìobhaideach de `DynMetadata::size_of` msaa.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// A `tilleadh meud an t-seòrsa a tha co-cheangailte ris an vtable seo.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// A `tilleadh co-thaobhadh den t-seòrsa a tha co-cheangailte ris an vtable seo.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// A `tilleadh meud agus co-thaobhadh còmhla mar `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SÀBHAILTEACHD: chuir an trusaiche a-mach an t-soitheach seo airson seòrsa cruadhtan Rust a
        // tha fios gu bheil cruth dligheach aige.An aon fheallsanachd ris an `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Impls làimhe a dh `fheumar gus crìochan `Dyn: $Trait` a sheachnadh.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}