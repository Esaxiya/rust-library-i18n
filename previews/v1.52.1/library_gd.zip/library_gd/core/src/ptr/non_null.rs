use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ach neo-neoni agus covariant.
///
/// Gu tric is e seo an rud ceart ri chleachdadh nuair a thathas a `togail structaran dàta a` cleachdadh comharran amh, ach aig a `cheann thall tha e nas cunnartach a chleachdadh air sgàth nam feartan a bharrachd aige.Mura h-eil thu cinnteach am bu chòir dhut `NonNull<T>` a chleachdadh, dìreach cleachd `*mut T`!
///
/// Eu-coltach ri `*mut T`, feumaidh am puing a bhith neo-null an-còmhnaidh, eadhon mura h-eil am puing a-riamh air a dhì-chlàradh.Tha seo gus am faod enums an luach toirmisgte seo a chleachdadh mar leth-bhreith-tha an aon mheud ri `* mut T` aig `Option<NonNull<T>>`.
/// Ach dh `fhaodadh gum bi am puing fhathast a` crochadh mura h-eil e air a dhì-chlàradh.
///
/// Eu-coltach ri `*mut T`, chaidh `NonNull<T>` a thaghadh airson a bhith covariant thairis air `T`.Tha seo ga dhèanamh comasach `NonNull<T>` a chleachdadh nuair a thathas a `togail seòrsaichean covariant, ach tha e a` toirt a-steach cunnart mì-chinnt ma thèid a chleachdadh ann an seòrsa nach bu chòir a bhith covariant.
/// (Chaidh an roghainn eile a dhèanamh airson `*mut T` eadhon ged gu teicnigeach cha b `urrainnear a` mhì-chinnt adhbhrachadh le bhith a `gairm gnìomhan neo-shàbhailte.)
///
/// Tha covariance ceart airson a `mhòr-chuid de tharraingean sàbhailte, leithid `Box`, `Rc`, `Arc`, `Vec`, agus `LinkedList`.'S e seo a' chùis oir bha iad a 'toirt seachad poblach API a leanas àbhaisteach co-roinnte XOR mutable riaghailtean Rust.
///
/// Mura h-urrainn don t-seòrsa agad a bhith covariant gu sàbhailte, feumaidh tu dèanamh cinnteach gu bheil raon a bharrachd ann gus ionnsaigh a thoirt.Gu tric bidh an raon seo mar sheòrsa [`PhantomData`] mar `PhantomData<Cell<T>>` no `PhantomData<&'a mut T>`.
///
/// Thoir fa-near gu bheil eisimpleir `From` aig `NonNull<T>` airson `&T`.Ach, chan eil seo ag atharrachadh gu bheil a bhith a `dol tro iomradh (puing a thig bho a) iomradh co-roinnte na ghiùlan neo-mhìnichte mura tachair an gluasad taobh a-staigh [`UnsafeCell<T>`].Tha an aon rud a`dèanamh airson iomradh so-atharraichte a chruthachadh bho iomradh coitcheann.
///
/// Nuair a bhios tu a `cleachdadh an eisimpleir `From` seo às aonais `UnsafeCell<T>`, tha e an urra riut dèanamh cinnteach nach tèid `as_mut` a ghairm a-riamh, agus nach eilear a` cleachdadh `as_ptr` airson mutation.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` chan eil molaidhean `Send` oir dh `fhaodadh an dàta air a bheil iad a` toirt iomradh a bhith air a chlaonadh.
// NB, chan eil feum air an impl seo, ach bu chòir dha teachdaireachdan mearachd nas fheàrr a thoirt seachad.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` chan eil molaidhean `Sync` oir dh `fhaodadh an dàta air a bheil iad a` toirt iomradh a bhith air a chlaonadh.
// NB, chan eil feum air an impl seo, ach bu chòir dha teachdaireachdan mearachd nas fheàrr a thoirt seachad.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// A `cruthachadh `NonNull` ùr a tha crochte, ach air a cho-thaobhadh gu math.
    ///
    /// Tha seo feumail airson a bhith a `tòiseachadh sheòrsan a bhios a` riarachadh leisg, mar a bhios `Vec::new` a `dèanamh.
    ///
    /// Thoir fa-near gur dòcha gu bheil luach a `phuing a` riochdachadh comharradh dligheach gu `T`, a `ciallachadh nach fhaodar seo a chleachdadh mar luach sentinel "not yet initialized".
    /// Feumaidh seòrsan a bhios a `riarachadh leisg sùil a chumail air tòiseachadh le dòigh eile.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SÀBHAILTEACHD: Bidh mem::align_of() a `tilleadh cleachdadh neo-neoni a tha an uairsin air a thionndadh
        // gu a * mut T.
        // Mar sin, chan eil e `ptr` null agus na cumhaichean airson a 'gairm new_unchecked() tha spèis.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// A `tilleadh iomraidhean co-roinnte mun luach.An coimeas ri [`as_ref`], chan eil seo ag iarraidh gum feumar an luach a thòiseachadh.
    ///
    /// Airson a `chunntair mutable faic [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Nuair a bhios tu a `gairm a` mhodh seo, feumaidh tu dèanamh cinnteach gu bheil a h-uile gin de na leanas fìor:
    ///
    /// * Feumaidh am puing a bhith air a cho-thaobhadh gu ceart.
    ///
    /// * Feumaidh e a bhith "dereferencable" anns an t-seadh a tha air a mhìneachadh ann an [the module documentation].
    ///
    /// * Feumaidh tu riaghailtean aliasing Rust a chuir an gnìomh, oir tha an ùine beatha `'a` a chaidh a thilleadh air a thaghadh gu neo-riaghailteach agus chan eil sin gu riatanach a `nochdadh fìor bheatha an dàta.
    ///
    ///   Gu sònraichte, fhad `s a mhaireas am beatha seo, chan fhaod an cuimhne a tha am puing a` comharrachadh a dhol fo bhrùthadh (ach a-staigh `UnsafeCell`).
    ///
    /// Tha seo fìor ged nach biodh toradh an dòigh seo air a chleachdadh!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gum bi `self` a `coinneachadh ris na h-uile
        // riatanasan airson iomradh.
        unsafe { &*self.cast().as_ptr() }
    }

    /// A `tilleadh iomraidhean sònraichte air an luach.An coimeas ri [`as_mut`], chan eil seo ag iarraidh gum feumar an luach a thòiseachadh.
    ///
    /// Airson a `chunntaidh roinnte faic [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Nuair a bhios tu a `gairm a` mhodh seo, feumaidh tu dèanamh cinnteach gu bheil a h-uile gin de na leanas fìor:
    ///
    /// * Feumaidh am puing a bhith air a cho-thaobhadh gu ceart.
    ///
    /// * Feumaidh e a bhith "dereferencable" anns an t-seadh a tha air a mhìneachadh ann an [the module documentation].
    ///
    /// * Feumaidh tu riaghailtean aliasing Rust a chuir an gnìomh, oir tha an ùine beatha `'a` a chaidh a thilleadh air a thaghadh gu neo-riaghailteach agus chan eil sin gu riatanach a `nochdadh fìor bheatha an dàta.
    ///
    ///   Gu sònraichte, fad beatha seo, chan fhaodar faighinn a-steach (leugh no sgrìobhadh) a `chuimhne a tha am puing a` comharrachadh tro phuing sam bith eile.
    ///
    /// Tha seo fìor ged nach biodh toradh an dòigh seo air a chleachdadh!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gum bi `self` a `coinneachadh ris na h-uile
        // riatanasan airson iomradh.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// A `cruthachadh `NonNull` ùr.
    ///
    /// # Safety
    ///
    /// `ptr` feumar a bhith neo-null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gu bheil `ptr` neo-null.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// A `cruthachadh `NonNull` ùr ma tha `ptr` neo-null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SÀBHAILTEACHD: Thathas a `sgrùdadh a` phuing mu thràth agus chan eil e null
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// A `dèanamh an aon seòrsa gnìomh ri [`std::ptr::from_raw_parts`], ach a-mhàin gu bheil comharradh `NonNull` air a thilleadh, an taca ri comharradh `*const` amh.
    ///
    ///
    /// Faic sgrìobhainnean [`std::ptr::from_raw_parts`] airson tuilleadh fiosrachaidh.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SÀBHAILTEACHD: Tha toradh `ptr::from::raw_parts_mut` neo-null oir tha `data_address`.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Cuir sìos comharradh (is dòcha farsaing) a-steach do phàirtean seòlaidh is meata-dàta.
    ///
    /// Faodar am puing ath-thogail le [`NonNull::from_raw_parts`] nas fhaide air adhart.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// A `faighinn a` phuing `*mut` bunaiteach.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// A `tilleadh iomradh co-roinnte air an luach.Ma dh`fhaodadh an luach a bhith neo-aithnichte, feumar [`as_uninit_ref`] a chleachdadh na àite.
    ///
    /// Airson a `chunntair mutable faic [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Nuair a bhios tu a `gairm a` mhodh seo, feumaidh tu dèanamh cinnteach gu bheil a h-uile gin de na leanas fìor:
    ///
    /// * Feumaidh am puing a bhith air a cho-thaobhadh gu ceart.
    ///
    /// * Feumaidh e a bhith "dereferencable" anns an t-seadh a tha air a mhìneachadh ann an [the module documentation].
    ///
    /// * Tha a 'chomharra a chomharrachadh, feumaidh a thòiseachadh an eisimpleir de `T`.
    ///
    /// * Feumaidh tu riaghailtean aliasing Rust a chuir an gnìomh, oir tha an ùine beatha `'a` a chaidh a thilleadh air a thaghadh gu neo-riaghailteach agus chan eil sin gu riatanach a `nochdadh fìor bheatha an dàta.
    ///
    ///   Gu sònraichte, fhad `s a mhaireas am beatha seo, chan fhaod an cuimhne a tha am puing a` comharrachadh a dhol fo bhrùthadh (ach a-staigh `UnsafeCell`).
    ///
    /// Tha seo fìor ged nach biodh toradh an dòigh seo air a chleachdadh!
    /// (Chan eil a `phàirt mu bhith air a thòiseachadh air a cho-dhùnadh gu h-iomlan fhathast, ach gus am bi e, is e an aon dòigh sàbhailte dèanamh cinnteach gu bheil iad air an tòiseachadh.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gum bi `self` a `coinneachadh ris na h-uile
        // riatanasan airson iomradh.
        unsafe { &*self.as_ptr() }
    }

    /// A `tilleadh iomradh sònraichte air an luach.Ma dh`fhaodadh an luach a bhith neo-aithnichte, feumar [`as_uninit_mut`] a chleachdadh na àite.
    ///
    /// Airson a `chunntaidh roinnte faic [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Nuair a bhios tu a `gairm a` mhodh seo, feumaidh tu dèanamh cinnteach gu bheil a h-uile gin de na leanas fìor:
    ///
    /// * Feumaidh am puing a bhith air a cho-thaobhadh gu ceart.
    ///
    /// * Feumaidh e a bhith "dereferencable" anns an t-seadh a tha air a mhìneachadh ann an [the module documentation].
    ///
    /// * Tha a 'chomharra a chomharrachadh, feumaidh a thòiseachadh an eisimpleir de `T`.
    ///
    /// * Feumaidh tu riaghailtean aliasing Rust a chuir an gnìomh, oir tha an ùine beatha `'a` a chaidh a thilleadh air a thaghadh gu neo-riaghailteach agus chan eil sin gu riatanach a `nochdadh fìor bheatha an dàta.
    ///
    ///   Gu sònraichte, fad beatha seo, chan fhaodar faighinn a-steach (leugh no sgrìobhadh) a `chuimhne a tha am puing a` comharrachadh tro phuing sam bith eile.
    ///
    /// Tha seo fìor ged nach biodh toradh an dòigh seo air a chleachdadh!
    /// (Chan eil a `phàirt mu bhith air a thòiseachadh air a cho-dhùnadh gu h-iomlan fhathast, ach gus am bi e, is e an aon dòigh sàbhailte dèanamh cinnteach gu bheil iad air an tòiseachadh.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SÀBHAILTEACHD: feumaidh an neach-fòn gealltainn gum bi `self` a `coinneachadh ris na h-uile
        // riatanasan airson iomradh mutable.
        unsafe { &mut *self.as_ptr() }
    }

    /// A `tilgeadh gu stiùireadh de sheòrsa eile.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SÀBHAILTEACHD: Tha `self` na chomharraiche `NonNull` a tha gu riatanach neo-null
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// A `cruthachadh sliseag amh neo-null bho stiùireadh tana agus fad.
    ///
    /// Is e an argamaid `len` an àireamh de **eileamaidean**, chan e an àireamh de bytes.
    ///
    /// Tha an gnìomh seo sàbhailte, ach chan eil e sàbhailte an luach a thilleadh.
    /// Faic sgrìobhainnean [`slice::from_raw_parts`] airson riatanasan sàbhailteachd sliseag.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // cruthaich comharradh sliseag nuair a thòisicheas tu a-mach le stiùireadh chun chiad eileamaid
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Thoir fa-near gu bheil an eisimpleir seo gu h-ealanta a `sealltainn cleachdadh den dòigh seo, ach` leig slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SÀBHAILTEACHD: Tha `data` na chomharraiche `NonNull` a tha gu riatanach neo-null
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// A `tilleadh fad sliseag amh neo-null.
    ///
    /// Is e an luach a chaidh a thilleadh an àireamh de **eileamaidean**, chan e an àireamh de bytes.
    ///
    /// Tha an gnìomh seo sàbhailte, eadhon nuair nach urrainnear an sliseag amh neo-null a dhì-chlàradh gu sliseag leis nach eil seòladh dligheach aig a `phuing.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// A `tilleadh stiùireadh neo-null gu bufair an t-sliseag.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SÀBHAILTEACHD: Tha fios againn gu bheil `self` neo-null.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// A `tilleadh stiùireadh amh gu bufair an t-sliseag.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// A `tilleadh iomradh co-roinnte air sliseag de luachan a dh` fhaodadh a bhith neo-aithnichte.An coimeas ri [`as_ref`], chan eil seo ag iarraidh gum feumar an luach a thòiseachadh.
    ///
    /// Airson a `chunntair mutable faic [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Nuair a bhios tu a `gairm a` mhodh seo, feumaidh tu dèanamh cinnteach gu bheil a h-uile gin de na leanas fìor:
    ///
    /// * Feumaidh an comharradh a bhith [valid] airson leughaidhean airson `ptr.len() * mem::size_of::<T>()` mòran bytes, agus feumaidh e a bhith air a cho-thaobhadh gu ceart.Tha seo a `ciallachadh gu sònraichte:
    ///
    ///     * Feumaidh an raon cuimhne gu lèir den t-slice seo a bhith taobh a-staigh aon nì a chaidh a riarachadh!
    ///       Chan urrainn dha sliseagan a dhol thairis air iomadh rud a chaidh a riarachadh.
    ///
    ///     * Feumaidh am puing a bhith air a cho-thaobhadh eadhon airson sliseagan de dh'fhaid neoni.
    ///     Is e aon adhbhar airson seo gum faod optimachadh cruth enum a bhith an urra ri iomraidhean (a `toirt a-steach sliseagan de dh` fhaid sam bith) a bhith air an aon rèir agus neo-null gus an eadar-dhealachadh bho dàta eile.
    ///
    ///     Gheibh thu stiùireadh a ghabhas cleachdadh mar `data` airson sliseagan de dh'fhaid neoni a `cleachdadh [`NonNull::dangling()`].
    ///
    /// * Chan fhaod meud iomlan `ptr.len() * mem::size_of::<T>()` an t-sliseag a bhith nas motha na `isize::MAX`.
    ///   Faic sgrìobhainnean sàbhailteachd [`pointer::offset`].
    ///
    /// * Feumaidh tu riaghailtean aliasing Rust a chuir an gnìomh, oir tha an ùine beatha `'a` a chaidh a thilleadh air a thaghadh gu neo-riaghailteach agus chan eil sin gu riatanach a `nochdadh fìor bheatha an dàta.
    ///   Gu sònraichte, fhad `s a mhaireas am beatha seo, chan fhaod an cuimhne a tha am puing a` comharrachadh a dhol fo bhrùthadh (ach a-staigh `UnsafeCell`).
    ///
    /// Tha seo fìor ged nach biodh toradh an dòigh seo air a chleachdadh!
    ///
    /// Faic cuideachd [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `as_uninit_slice` a chumail suas.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// A `tilleadh iomradh gun samhail air sliseag de luachan a dh` fhaodadh a bhith neo-aithnichte.An coimeas ri [`as_mut`], chan eil seo ag iarraidh gum feumar an luach a thòiseachadh.
    ///
    /// Airson a `chunntaidh roinnte faic [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Nuair a bhios tu a `gairm a` mhodh seo, feumaidh tu dèanamh cinnteach gu bheil a h-uile gin de na leanas fìor:
    ///
    /// * Feumaidh an comharradh a bhith [valid] airson a bhith a `leughadh agus a` sgrìobhadh airson `ptr.len() * mem::size_of::<T>()` mòran bytes, agus feumaidh e a bhith air a cho-thaobhadh gu ceart.Tha seo a `ciallachadh gu sònraichte:
    ///
    ///     * Feumaidh an raon cuimhne gu lèir den t-slice seo a bhith taobh a-staigh aon nì a chaidh a riarachadh!
    ///       Chan urrainn dha sliseagan a dhol thairis air iomadh rud a chaidh a riarachadh.
    ///
    ///     * Feumaidh am puing a bhith air a cho-thaobhadh eadhon airson sliseagan de dh'fhaid neoni.
    ///     Is e aon adhbhar airson seo gum faod optimachadh cruth enum a bhith an urra ri iomraidhean (a `toirt a-steach sliseagan de dh` fhaid sam bith) a bhith air an aon rèir agus neo-null gus an eadar-dhealachadh bho dàta eile.
    ///
    ///     Gheibh thu stiùireadh a ghabhas cleachdadh mar `data` airson sliseagan de dh'fhaid neoni a `cleachdadh [`NonNull::dangling()`].
    ///
    /// * Chan fhaod meud iomlan `ptr.len() * mem::size_of::<T>()` an t-sliseag a bhith nas motha na `isize::MAX`.
    ///   Faic sgrìobhainnean sàbhailteachd [`pointer::offset`].
    ///
    /// * Feumaidh tu riaghailtean aliasing Rust a chuir an gnìomh, oir tha an ùine beatha `'a` a chaidh a thilleadh air a thaghadh gu neo-riaghailteach agus chan eil sin gu riatanach a `nochdadh fìor bheatha an dàta.
    ///   Gu sònraichte, fad beatha seo, chan fhaodar faighinn a-steach (leugh no sgrìobhadh) a `chuimhne a tha am puing a` comharrachadh tro phuing sam bith eile.
    ///
    /// Tha seo fìor ged nach biodh toradh an dòigh seo air a chleachdadh!
    ///
    /// Faic cuideachd [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Tha seo sàbhailte oir tha `memory` dligheach airson leughaidhean agus sgrìobhadh airson `memory.len()` mòran bytes.
    /// // Thoir fa-near nach eil gairm `memory.as_mut()` ceadaichte an seo oir dh `fhaodadh an susbaint a bhith neo-aithnichte.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SÀBHAILTEACHD: feumaidh an neach-conaltraidh an cùmhnant sàbhailteachd airson `as_uninit_slice_mut` a chumail suas.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// A `tilleadh stiùireadh amh gu eileamaid no subslice, gun a bhith a` dèanamh sgrùdadh air crìochan.
    ///
    /// Is e a bhith a `gairm an dòigh seo le clàr-amais taobh a-muigh crìochan no nuair nach eil `self` dereferencable *[giùlan neo-mhìnichte]* eadhon ged nach eilear a` cleachdadh a `phuing a thig às.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SÀBHAILTEACHD: bidh an neach-fios a `dèanamh cinnteach gu bheil `self` dereferencable agus `index` a-steach.
        // Mar thoradh air an sin, chan urrainn don phuing a thig às a bhith NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SÀBHAILTEACHD: Chan urrainnear stiùireadh sònraichte a bhith null, mar sin na cumhaichean airson
        // new_unchecked() tha meas orra.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SÀBHAILTEACHD: Chan urrainnear iomradh gluasadach a chuir air falbh.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SÀBHAILTEACHD: Chan urrainnear iomradh a thoirt seachad, mar sin na cumhaichean airson
        // new_unchecked() tha meas orra.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}