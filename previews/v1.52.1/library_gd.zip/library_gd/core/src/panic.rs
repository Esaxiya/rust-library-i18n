//! Taic Panic anns an leabharlann àbhaisteach.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Structar a bheir fiosrachadh seachad mu panic.
///
/// `PanicInfo` structar air a thoirt seachad gu panic hook air a shuidheachadh le gnìomh [`set_hook`].
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// A `tilleadh an t-uallach pàighidh co-cheangailte ris an panic.
    ///
    /// Mar as trice is e `&'static str` no [`String`] a bhios an seo.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Ma chaidh am macro `panic!` bhon `core` crate (chan ann bho `std`) a chleachdadh le sreang cruth agus cuid de argamaidean a bharrachd, tillidh e an teachdaireachd sin deiseil airson a chleachdadh mar eisimpleir le [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// A `tilleadh fiosrachadh mun àite às an tàinig an panic, ma tha e ri fhaighinn.
    ///
    /// Bidh an dòigh seo an-còmhnaidh a `tilleadh [`Some`], ach dh` fhaodadh seo atharrachadh ann an dreachan future.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Ma thèid seo atharrachadh gus nach till gin idir,
        // dèiligeadh ris a `chùis sin ann an std::panicking::default_hook agus std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: chan urrainn dhuinn downcast_ref a chleachdadh: :<String>() an seo
        // bho nach eil String ri fhaighinn ann an libcore!
        // Is e String an t-uallach pàighidh nuair a thèid `std::panic!` a ghairm le iomadh argamaid, ach sa chùis sin tha an teachdaireachd ri fhaighinn cuideachd.
        //

        self.location.fmt(formatter)
    }
}

/// Structar anns a bheil fiosrachadh mu far a bheil panic.
///
/// Tha an structar seo air a chruthachadh le [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Tha coimeasan airson co-ionannachd agus òrdachadh air an dèanamh ann am faidhle, loidhne, agus an uairsin prìomhachas colbh.
/// Tha faidhlichean air an coimeas mar shreathan, chan e `Path`, a dh `fhaodadh a bhith neo-fhaicsinneach.
/// Faic sgrìobhainnean [`Àite: : faidhle`] airson tuilleadh deasbaid.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// A `tilleadh suidheachadh stòr neach-fios an gnìomh seo.
    /// Ma tha neach-gairm an gnìomh sin air an comharrachadh, thèid an t-àite gairm aige a thilleadh, agus mar sin air adhart suas a `chruach chun a` chiad ghairm taobh a-staigh buidheann gnìomh nach eil air a leantainn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// A `tilleadh an [`Location`] aig a bheil e.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// A `tilleadh [`Location`] bho taobh a-staigh mìneachadh an gnìomh seo.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // tha a bhith a `ruith an aon ghnìomh gun chead ann an àite eadar-dhealaichte a` toirt dhuinn an aon toradh
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // tha ruith luach a `ruith ann an àite eadar-dhealaichte a` toirt a-mach luach eadar-dhealaichte
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// A `tilleadh ainm an fhaidhle stòr às an tàinig an panic.
    ///
    /// # `&str`, chan e `&Path`
    ///
    /// Tha an t-ainm a chaidh a thilleadh a `toirt iomradh air slighe stòr air an t-siostam cur ri chèile, ach chan eil e dligheach seo a riochdachadh gu dìreach mar `&Path`.
    /// Dh `fhaodadh gum bi an còd cruinnichte a` ruith air siostam eadar-dhealaichte le buileachadh `Path` eadar-dhealaichte seach an siostam a tha a `toirt seachad na tha ann agus chan eil seòrsa "host path" eadar-dhealaichte aig an leabharlann seo an-dràsta.
    ///
    /// Bidh an giùlan as iongantaiche a `tachairt nuair a gheibhear faidhle "the same" tro ioma-shlighe ann an siostam a` mhodal (mar as trice a `cleachdadh feart `#[path = "..."]` no a leithid), a dh` fhaodadh a bhith ag adhbhrachadh còd a tha coltach ri luachan eadar-dhealaichte bhon ghnìomh seo.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Chan eil an luach seo freagarrach airson a dhol gu `Path::new` no luchd-togail coltach ris nuair a bhios an àrd-ùrlar aoigheachd agus an àrd-ùrlar targaid eadar-dhealaichte.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// A 'tilleadh an loidhne àireamh às a bheil an panic thùs.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// A `tilleadh an colbh bhon tàinig an panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// trait a-staigh air a chleachdadh le libstd gus dàta a thoirt seachad bho libstd gu `panic_unwind` agus amannan ruith panic eile.
/// Gun a bhith an dùil a bhith seasmhach uair sam bith a dh `aithghearr, na cleachd.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Gabh làn shealbh air na tha ann.
    /// Is e an seòrsa tilleadh gu dearbh `Box<dyn Any + Send>`, ach chan urrainn dhuinn `Box` a chleachdadh ann an libcore.
    ///
    /// Às deidh don dòigh seo a bhith air a ghairm, chan eil ach beagan de luach bunaiteach air fhàgail ann an `self`.
    /// Is e mearachd a th `ann a bhith a` gairm an dòigh seo dà uair, no a `gairm `get` às deidh dhut an dòigh seo a ghairm.
    ///
    /// Tha an argamaid air iasad oir chan eil an ùine-ruith panic (`__rust_start_panic`) a `faighinn ach `dyn BoxMeUp` air iasad.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Dìreach gabh air iasad an t-susbaint.
    fn get(&mut self) -> &(dyn Any + Send);
}