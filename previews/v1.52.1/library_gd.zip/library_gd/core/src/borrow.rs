//! Modal airson a bhith ag obair le dàta air iasad.

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait airson dàta fhaighinn air iasad.
///
/// Ann an Rust, tha e cumanta riochdachaidhean eadar-dhealaichte de sheòrsa a thoirt seachad airson cùisean cleachdaidh eadar-dhealaichte.
/// Mar eisimpleir, faodar àite stòraidh agus riaghladh airson luach a thaghadh gu sònraichte mar a tha iomchaidh airson cleachdadh sònraichte tro sheòrsaichean puing leithid [`Box<T>`] no [`Rc<T>`].
/// Seachad air na pasgain gnèitheach sin a ghabhas cleachdadh le seòrsa sam bith, tha cuid de sheòrsan a `toirt seachad taobhan roghainneil a` solarachadh comasachd a dh `fhaodadh a bhith cosgail.
/// Is e eisimpleir airson a leithid de sheòrsa [`String`] a chuireas ris a `chomas sreang a leudachadh chun [`str`] bunaiteach.
/// Feumaidh seo fiosrachadh a bharrachd a chumail gun fheum airson sreang sìmplidh nach gabh gluasad.
///
/// Bidh na seòrsachan sin a `toirt cothrom air an dàta bunaiteach tro iomraidhean air an t-seòrsa dàta sin.Thathas ag ràdh gu bheil iad`air iasad mar` an seòrsa sin.
/// Mar eisimpleir, faodar [`Box<T>`] fhaighinn air iasad mar `T` agus faodar [`String`] fhaighinn air iasad mar `str`.
///
/// Tha seòrsaichean a `cur an cèill gum faodar an toirt air iasad mar chuid de sheòrsa `T` le bhith a` buileachadh `Borrow<T>`, a `toirt iomradh air `T` ann am modh [`borrow`] trait.Tha seòrsa an-asgaidh air iasad mar grunn sheòrsaichean eadar-dhealaichte.
/// Ma tha e airson iasad fhaighinn mar an seòrsa-a `leigeil leis an dàta bunaiteach atharrachadh, faodaidh e [`BorrowMut<T>`] a chuir an gnìomh cuideachd.
///
/// Nas fhaide, nuair a bhios iad a `toirt seachad buileachadh airson traits a bharrachd, feumar beachdachadh am bu chòir dhaibh a bhith co-ionann ris an fheadhainn den t-seòrsa bunaiteach mar thoradh air a bhith ag obair mar riochdachadh den t-seòrsa bunaiteach sin.
/// Mar as trice bidh còd gnèitheach a `cleachdadh `Borrow<T>` nuair a bhios e an urra ri giùlan co-ionann de na buileachadh trait a bharrachd sin.
/// Tha coltas gum bi na traits seo a `nochdadh mar trait bounds a bharrachd.
///
/// Gu sònraichte feumaidh `Eq`, `Ord` agus `Hash` a bhith co-ionnan airson luachan air iasad agus seilbh: bu chòir `x.borrow() == y.borrow()` an aon toradh a thoirt seachad ri `x == y`.
///
/// Ma dh `fheumas còd gnèitheach dìreach a bhith ag obair airson a h-uile seòrsa as urrainn iomradh a thoirt air seòrsa `T` co-cheangailte ris, tha e nas fheàrr gu tric [`AsRef<T>`] a chleachdadh oir is urrainn do bharrachd sheòrsan a chuir an gnìomh gu sàbhailte.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Mar chruinneachadh dàta, tha an dà chuid iuchraichean agus luachan aig [`HashMap<K, V>`].Ma tha fìor dàta na h-iuchrach air a pasgadh ann an seòrsa riaghlaidh de sheòrsa air choreigin, bu chòir dha, ge-tà, a bhith comasach fhathast luach a lorg a `cleachdadh iomradh air dàta na h-iuchrach.
/// Mar eisimpleir, mas e sreang a tha san iuchair, tha e coltach gum bi e air a stòradh leis a `mhapa hash mar [`String`], fhad` s a bu chòir a bhith comasach sgrùdadh a dhèanamh a `cleachdadh [`&str`][`str`].
/// Mar sin, feumaidh `insert` obrachadh air `String` fhad `s a dh` fheumas `get` a bhith comasach air `&str` a chleachdadh.
///
/// Beagan nas sìmplidhe, tha na pàirtean buntainneach de `HashMap<K, V>` a `coimhead mar seo:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // raointean air fhàgail às
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Tha am mapa hash gu lèir coitcheann thairis air prìomh sheòrsa `K`.Leis gu bheil na h-iuchraichean sin air an stòradh leis a `mhapa hash, feumaidh dàta den iuchair a bhith aig an t-seòrsa seo.
/// Nuair a chuireas tu a-steach paidhir luach-iuchrach, tha an leithid de `K` air a thoirt don mhapa agus feumaidh e am bucaid hash ceart a lorg agus dèanamh cinnteach a bheil an iuchair an làthair mu thràth stèidhichte air an `K` sin.Mar sin feumaidh e `K: Hash + Eq`.
///
/// Nuair a thathar a `lorg luach air a` mhapa, ge-tà, le bhith a `toirt iomradh air `K` mar an iuchair airson a bhith a` lorg dh'fheumadh luach an leithid a bhith an-còmhnaidh a chruthachadh.
/// Airson iuchraichean sreang, bhiodh seo a `ciallachadh gum feumar luach `String` a chruthachadh dìreach airson a bhith a` lorg chùisean far nach eil ach `str` ri fhaighinn.
///
/// An àite sin, tha an dòigh `get` coitcheann thairis air an t-seòrsa prìomh dàta bunaiteach, ris an canar `Q` anns an ainm-sgrìobhte modh gu h-àrd.Tha e ag ràdh gu bheil `K` a `faighinn iasad mar `Q` le bhith ag iarraidh an `K: Borrow<Q>` sin.
/// Le bhith a `feumachdainn `Q: Hash + Eq` a bharrachd, tha e a` comharrachadh an riatanas gum bi `K` agus `Q` a `buileachadh an `Hash` agus `Eq` traits a bheir seachad toraidhean co-ionann.
///
/// Tha buileachadh `get` an urra gu sònraichte ri buileachadh co-ionann de `Hash` le bhith a `dearbhadh bucaid hash na h-iuchrach le bhith a` gairm `Hash::hash` air luach `Q` ged a chuir e a-steach an iuchair stèidhichte air an luach hash a chaidh a thomhas bhon luach `K`.
///
///
/// Mar thoradh, an hais map briseadh ma `K` wrapping a `Q` luach-hais a 'dèanamh eadar-dhealaichte seach `Q`.Mar eisimpleir, smaoinich gu bheil seòrsa agad a tha a `pasgadh sreang ach a` dèanamh coimeas eadar litrichean ASCII a `seachnadh na cùise aca:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Leis gu feum dà luach co-ionann an aon luach hash a thoirt gu buil, feumaidh buileachadh `Hash` dearmad a dhèanamh air cùis ASCII, cuideachd:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// An urrainn do `CaseInsensitiveString` `Borrow<str>` a bhuileachadh?Faodaidh e gu cinnteach a bhith a `toirt iomradh air sliseag sreang tron t-sreang seilbh aige.
/// Ach leis gu bheil a bhuileachadh `Hash` eadar-dhealaichte, tha e ga ghiùlan gu eadar-dhealaichte bho `str` agus mar sin chan fheum e, gu dearbh, `Borrow<str>` a bhuileachadh.
/// Ma tha e airson leigeil le daoine eile faighinn chun `str` bunaiteach, faodaidh e sin a dhèanamh tro `AsRef<str>` aig nach eil riatanasan a bharrachd.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Tha e gu mòr a `faighinn iasad bho luach seilbh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// A trait airson dàta fhaighinn air iasad.
///
/// Mar chompanach ri [`Borrow<T>`] tha an trait seo a `leigeil le seòrsa iasad fhaighinn mar sheòrsa bunaiteach le bhith a` toirt seachad iomradh gluasadach.
/// Faic [`Borrow<T>`] airson tuilleadh fiosrachaidh mu bhith a `faighinn iasad mar sheòrsa eile.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// A `faighinn iasad bho luach seilbh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}