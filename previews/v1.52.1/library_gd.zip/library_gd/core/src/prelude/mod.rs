//! An libcore prelude
//!
//! Tha am modal seo an dùil luchd-cleachdaidh libcore nach eil a `ceangal ri libstd cuideachd.
//! Tha am modal seo air a thoirt a-steach gu bunaiteach nuair a thèid `#![no_std]` a chleachdadh san aon dòigh ri prelude an leabharlann àbhaisteach.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// An dreach 2015 den phrìomh prelude.
///
/// Faic an [module-level documentation](self) airson tuilleadh.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// An dreach 2018 den phrìomh prelude.
///
/// Faic an [module-level documentation](self) airson tuilleadh.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// An dreach 2021 den phrìomh prelude.
///
/// Faic an [module-level documentation](self) airson tuilleadh.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Cuir barrachd rudan ris.
}