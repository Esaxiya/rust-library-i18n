//! Seòrsan a bhios a `pronnadh dàta chun àite a th` aige mar chuimhneachan.
//!
//! Tha e feumail uaireannan nithean a bhith agad a tha cinnteach nach gluais iad, anns an fhaireachdainn nach atharraich an suidheachadh aca mar chuimhneachan, agus mar sin faodar earbsa a chur annta.
//! Is e prìomh eisimpleir de leithid de shuidheachadh a bhith a `togail structaran fèin-iomraidh, oir le bhith a` gluasad nì le comharran dha fhèin bidh e neo-dhligheach iad, a dh `fhaodadh giùlan neo-mhìnichte adhbhrachadh.
//!
//! Aig ìre àrd, tha [`Pin<P>`] a `dèanamh cinnteach gu bheil àite seasmhach aig puing seòrsaiche `P` sam bith mar chuimhneachan, a` ciallachadh nach gabh a ghluasad gu àite eile agus nach gabh a chuimhne a thuigsinn gus an tèid a leigeil sìos.Tha sinn ag ràdh gur e "pinned" a th `anns a` phuing.Bidh cùisean a `fàs nas sàmhaiche nuair a bhios iad a` bruidhinn air seòrsachan a tha a `cothlamadh le dàta neo-phinn;[see below](#projections-and-structural-pinning) airson tuilleadh fiosrachaidh.
//!
//! Gu gnàthach, tha a h-uile seòrsa ann an Rust gluasadach.
//! Tha Rust a `ceadachadh a bhith a` dol seachad air gach seòrsa fo-luach, agus tha seòrsan smart-pointer cumanta leithid [`Box<T>`] agus `&mut T` a `ceadachadh ath-shuidheachadh agus gluasad nan luachan a tha annta: faodaidh tu gluasad a-mach à [`Box<T>`], no faodaidh tu [`mem::swap`] a chleachdadh.
//! [`Pin<P>`] a `pasgadh seòrsa puing `P`, mar sin [` Pin`]`<`[`Box`]`<T>> `ag obair gu math coltach ri cunbhalach
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`thèid a leigeil sìos, mar sin dèan na tha ann, agus gheibh an cuimhne
//!
//! tuigseocated.San aon dòigh, tha [`Pin`]`<&mut T>`gu math coltach ri `&mut T`.Ach, cha leig [`Pin<P>`] le teachdaichean [`Box<T>`] no `&mut T` fhaighinn gu dàta pinned, a tha a `ciallachadh nach urrainn dhut obrachaidhean leithid [`mem::swap`] a chleachdadh:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` feumach air `&mut T`, ach chan urrainn dhuinn fhaighinn.
//!     // Tha sinn an-sàs, chan urrainn dhuinn susbaint nan iomraidhean sin atharrachadh.
//!     // B `urrainn dhuinn `Pin::get_unchecked_mut` a chleachdadh, ach tha sin cunnartach airson adhbhar:
//!     // chan eil cead againn a chleachdadh airson rudan a ghluasad a-mach às an `Pin`.
//! }
//! ```
//!
//! Is fhiach a ràdh a-rithist nach eil [`Pin<P>`]*ag atharrachadh* an fhìrinn gu bheil co-chruinneadair Rust a `meas a h-uile seòrsa gluasadach.Tha [`mem::swap`] fhathast glaiste airson `T` sam bith.An àite sin, tha [`Pin<P>`] a`cur casg air luachan *sònraichte*(air an comharrachadh le comharran air am pasgadh ann an [`Pin<P>`]) bho bhith air an gluasad le bhith ga dhèanamh do-dhèanta dòighean a ghairm a dh` fheumas `&mut T` orra (mar [`mem::swap`]).
//!
//! [`Pin<P>`] Faodar a chleachdadh gus seòrsa puing `P` sam bith a chòmhdach, agus mar sin bidh e ag eadar-obrachadh le [`Deref`] agus [`DerefMut`].[`Pin<P>`] far am bu chòir beachdachadh air `P: Deref` mar "`P`-style pointer" gu `P::Target` pinned-mar sin, a [`Pin`]`<`[`Box`] `<T>>`tha comharradh seilbh air `T` pinned, agus [`Pin`] `<` [`Rc`]`<T>>`tha comharradh air a cunntadh le iomradh air `T` pinned.
//! Airson ceartachd, tha [`Pin<P>`] an urra ri buileachadh [`Deref`] agus [`DerefMut`] gun a bhith a `gluasad a-mach às am paramadair `self` aca, agus dìreach a-riamh gus puing a thilleadh gu dàta pinned nuair a thèid an gairm air puing pinned.
//!
//! # `Unpin`
//!
//! Tha mòran sheòrsaichean an-còmhnaidh gluasadach gu furasta, eadhon nuair a tha iad air am pronnadh, oir chan eil iad an urra ri seòladh seasmhach.Tha seo a `toirt a-steach a h-uile seòrsa bunaiteach (mar [`bool`], [`i32`], agus iomraidhean) a bharrachd air seòrsachan a tha a` gabhail a-steach dìreach de na seòrsaichean sin.Bidh seòrsachan nach eil a `gabhail cùram mu bhith a` pinning a `buileachadh an [`Unpin`] auto-trait, a bhios a` cur stad air buaidh [`Pin<P>`].
//! Airson `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`agus [`Box<T>`] ag obair san aon dòigh, mar a tha [`Pin`] `<&mut T>` agus `&mut T`.
//!
//! Thoir fa-near nach eil pinning agus [`Unpin`] a `toirt buaidh ach air an t-seòrsa biorach `P::Target`, chan e an seòrsa puing `P` fhèin a chaidh a phasgadh ann an [`Pin<P>`].Mar eisimpleir, ge bith a bheil [`Box<T>`] [`Unpin`] no nach eil, chan eil buaidh sam bith aige air giùlan [`Pin`]` <`[` Box`]`<T>> `(an seo, is e `T` an seòrsa biorach).
//!
//! # Eisimpleir: structar fèin-iomraidh
//!
//! Mus tèid sinn a-steach barrachd mion-fhiosrachaidh gus na barrantasan agus na roghainnean co-cheangailte ri `Pin<T>` a mhìneachadh, bruidhnidh sinn air cuid de eisimpleirean airson mar a dh `fhaodar a chleachdadh.
//! Feel free gu [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Is e structar fèin-iomraidh a tha seo oir tha an raon sliseag a `comharrachadh an raon dàta.
//! // Chan urrainn dhuinn innse don t-saothraiche mu dheidhinn sin le iomradh àbhaisteach, oir chan urrainnear am pàtran seo a mhìneachadh leis na riaghailtean àbhaisteach iasaid.
//! //
//! // An àite sin bidh sinn a `cleachdadh stiùireadh amh, ged a tha fios againn nach eil e null, mar a tha fios againn gu bheil e a` comharrachadh aig an t-sreang.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Gus dèanamh cinnteach nach gluais an dàta nuair a thilleas an gnìomh, bidh sinn ga chur anns an tiùrr far am fuirich e fad beatha an nì, agus b `e an aon dòigh air faighinn thuige.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // cha bhith sinn a `cruthachadh a` phuing ach aon uair `s gu bheil an dàta na àite no bidh e air gluasad mu thràth mus do thòisich sinn eadhon
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // tha fios againn gu bheil seo sàbhailte oir cha bhith atharrachadh achadh a `gluasad an structar gu lèir
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Bu chòir don neach-comharrachaidh an t-àite ceart a chomharrachadh, cho fad `s nach eil an structar air gluasad.
//! //
//! // Aig an aon àm, tha sinn saor airson a `phuing a ghluasad timcheall.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Leis nach bi an seòrsa againn a `buileachadh Unpin, bidh seo a` fàiligeadh ri chèile:
//! // leig mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Eisimpleir: liosta ionnsaigheach le ceangal dùbailte
//!
//! Ann an liosta ionnsaigheach le ceangal dùbailte, chan eil an cruinneachadh gu dearbh a `riarachadh a` chuimhne airson na h-eileamaidean fhèin.
//! Tha riarachadh fo smachd an luchd-dèiligidh, agus faodaidh eileamaidean a bhith beò air frèam cruachan a tha beò nas giorra na tha an cruinneachadh a `dèanamh.
//!
//! Gus an obair seo a dhèanamh, tha comharran aig a h-uile eileamaid don fhear a thàinig roimhe agus an neach a thàinig às a dhèidh air an liosta.Chan urrainnear eileamaidean a chur ris ach nuair a tha iad air am pronnadh, oir bhiodh gluasad na h-eileamaidean timcheall a `toirt na comharran gu neo-dhligheach.A bharrachd air an sin, bidh buileachadh [`Drop`] de eileamaid liosta ceangailte a`gleusadh comharran an sinnsear agus an neach a thàinig às a dhèidh gus a thoirt air falbh bhon liosta.
//!
//! Gu deatamach, feumaidh sinn a bhith an urra ri [`drop`] a bhith air a ghairm.Nam b `urrainnear eileamaid a thuigsinn no a bhith neo-dhligheach air dhòigh eile gun a bhith a` gairm [`drop`], bhiodh na comharran a-steach dha bho na h-eileamaidean faisg air làimh neo-dhligheach, a bhiodh a `briseadh an structar dàta.
//!
//! Mar sin, bidh pinning cuideachd a `tighinn le gealltanas co-cheangailte [` drop`].
//!
//! # `Drop` guarantee
//!
//! Is e adhbhar pinning a bhith comasach air a bhith an urra ri suidheachadh cuid de dhàta mar chuimhneachan.
//! Gus an obair seo a dhèanamh, chan e dìreach gluasad an dàta air a chuingealachadh;tha tuigseocating, repurposing, no ann an dòigh eile neo-dhligheach an cuimhne a chaidh a chleachdadh gus an dàta a stòradh air a chuingealachadh cuideachd.
//! Gu concrait, airson dàta pinned feumaidh tu a bhith a `cumail a-mach nach bi *a chuimhne a` faighinn neo-dhligheach no ath-riochdachadh bhon mhionaid a gheibh e pinn gus an tèid [`drop`] a ghairm*.Dìreach aon uair `s gun till [`drop`] no panics, faodar an cuimhne ath-chleachdadh.
//!
//! Faodaidh cuimhne a bhith "invalidated" le deallocation, ach cuideachd le bhith a `cur [`Some(v)`] an àite [`None`], no le bhith a` gairm [`Vec::set_len`] gu "kill" cuid de na h-eileamaidean dheth de vector.Faodar a chuir air ais le bhith a `cleachdadh [`ptr::write`] gus a sgrìobhadh thairis gun a bhith a` gairm an inneal-sgrios an toiseach.Chan eil dad de seo ceadaichte airson dàta pinned gun a bhith a `gairm [`drop`].
//!
//! Is e seo dìreach an seòrsa gealladh gum feum an liosta ceangailte ionnsaigheach bhon roinn roimhe seo obrachadh gu ceart.
//!
//! Thoir fa-near nach eil an gealladh seo *a `ciallachadh* nach eil cuimhne a` leigeil às!Tha e fhathast gu tur ceart gu leòr gun a bhith a `gairm [`drop`] air eileamaid pinned (me, faodaidh tu fhathast [`mem::forget`] a ghairm air [` Pin`]`<`[`Box`]`<T>> `).Anns an eisimpleir den liosta le ceangal dùbailte, bhiodh an eileamaid sin dìreach a`fuireach air an liosta.Ach chan fhaod thu an stòradh *a shaoradh no ath-chleachdadh gun a bhith a `gairm [` drop`]*.
//!
//! # `Drop` implementation
//!
//! Ma tha an seòrsa agad a `cleachdadh pinning (mar an dà eisimpleir gu h-àrd), feumaidh tu a bhith faiceallach nuair a bhios tu a` cur [`Drop`] an gnìomh.Tha gnìomh [`drop`] a `toirt `&mut self`, ach canar *ris an seo eadhon ged a chaidh an seòrsa agad a phinnadh roimhe*!Tha e mar gum biodh an cruinneadair ris an canar [`Pin::get_unchecked_mut`] gu fèin-ghluasadach.
//!
//! Chan urrainn dha seo a-riamh duilgheadas adhbhrachadh ann an còd sàbhailte oir tha feum air còd neo-shàbhailte a bhith a `cur an gnìomh seòrsa a tha an urra ri feannadh, ach bi mothachail gum feum thu co-dhùnadh feum a dhèanamh de bhith a` pinning san t-seòrsa agad (mar eisimpleir le bhith a `cur an gnìomh beagan obrachaidh air [` Pin`]`<&Self> Tha buaidh aig ``no [`Pin`]` <&mut Self> `) air do bhuileachadh [`Drop`] cuideachd: ma dh` fhaodadh eileamaid den t-seòrsa agad a bhith air a phinnadh, feumaidh tu a bhith a `làimhseachadh [`Drop`] mar rud a tha gu h-obann a` gabhail [`Pin`]`<&mut Fèin>`.
//!
//!
//! Mar eisimpleir, dh'fhaodadh tu `Drop` a bhuileachadh mar a leanas:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` ceart gu leòr oir tha fios againn nach cleachdar an luach seo a-rithist às deidh a bhith air a leigeil sìos.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Tha còd tuiteam fìrinneach a `dol an seo.
//!         }
//!     }
//! }
//! ```
//!
//! Tha an gnìomh `inner_drop` den t-seòrsa a bu chòir a bhith aig [`drop`] *, mar sin nì seo cinnteach nach cleachd thu `self`/`this` gun fhiosta ann an dòigh a tha a `dol an-aghaidh pinning.
//!
//! A bharrachd air an sin, mas e `#[repr(packed)]` an seòrsa agad, gluaisidh an trusaiche raointean timcheall gu fèin-ghluasadach gus an urrainn dhaibh an leigeil às.Dh `fhaodadh eadhon sin a dhèanamh airson achaidhean a tha a` tachairt a bhith air an co-thaobhadh gu leòr.Mar thoradh air an sin, chan urrainn dhut pinning le seòrsa `#[repr(packed)]` a chleachdadh.
//!
//! # Ro-mheasaidhean agus Buain Structarail
//!
//! Nuair a bhios tu ag obair le structaran pinned, tha a `cheist ag èirigh ciamar as urrainn dha faighinn gu raointean an structair sin ann am modh a tha a` gabhail dìreach [`Pin`]`<&mut Struct>`.
//! Is e an dòigh àbhaisteach dòighean cuideachaidh a sgrìobhadh (ris an canar *ro-mheasaidhean*) a thionndaidheas [`Pin`]`<&mut Struct>`gu bhith a`toirt iomradh air an raon, ach dè an seòrsa a bu chòir a bhith aig an iomradh sin?An e [`Pin`]` <&mut Field> `no `&mut Field`?
//! Tha an aon cheist ag èirigh le raointean `enum`, agus cuideachd nuair a thathas a `beachdachadh air seòrsachan container/wrapper leithid [`Vec<T>`], [`Box<T>`], no [`RefCell<T>`].
//! (Tha a `cheist seo a` buntainn an dà chuid ri iomraidhean mutable agus co-roinnte, bidh sinn dìreach a `cleachdadh a` chùis as cumanta de dh `iomraidhean mutable an seo airson dealbh.)
//!
//! Tha e a `tionndadh a-mach gu bheil e an urra ri ùghdar an structair dàta co-dhùnadh a bheil an ro-mheasadh pinned airson raon sònraichte a` tionndadh [`Pin`]`<&mut Struct>`gu [`Pin`] `<&mut Field>` no `&mut Field`.Tha cuid de chuingealachaidhean ann ge-tà, agus is e an cuingealachadh as cudromaiche *cunbhalachd*:
//! faodaidh gach raon a bhith *an dàrna cuid* air a ro-mheasadh gu iomradh pinned,*no* air pinning a thoirt air falbh mar phàirt den ro-mheasadh.
//! Ma thèid an dà chuid a dhèanamh airson an aon raon, tha coltas ann gum bi sin mì-chinnteach!
//!
//! Mar ùghdar structar dàta gheibh thu co-dhùnadh airson gach raon a bheil thu a `putadh "propagates" ris an raon seo no nach eil.
//! Canar "structural" ri pinning a tha a `sgaoileadh, oir tha e a` leantainn structar an t-seòrsa.
//! Anns na fo-earrannan a leanas, tha sinn a `toirt cunntas air na beachdachaidhean a dh` fheumar a dhèanamh airson gach roghainn.
//!
//! ## Chan eil pronnadh * structarail airson `field`
//!
//! Is dòcha gu bheil e a `coimhead mì-ghoireasach gur dòcha nach eil an raon de structar pinned air a phinnadh, ach is e sin an roghainn as fhasa: mura tèid [` Pin`]`<&mut Field>` a chruthachadh a-riamh, chan urrainn dad a dhol ceàrr!Mar sin, ma cho-dhùnas tu nach eil pinning structarail aig cuid de achadh, chan eil agad ach dèanamh cinnteach nach cruthaich thu a-riamh iomradh pinned air an raon sin.
//!
//! Is dòcha gum bi dòigh ro-mheasaidh aig achaidhean gun pinning structarail a thionndaidheas [`Pin`]`<&mut Struct>`gu `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Tha seo ceart gu leòr oir chan eilear den bheachd gu bheil `field` pinned.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Faodaidh tu cuideachd `impl Unpin for Struct`*a dhèanamh eadhon ged nach e* an seòrsa `field` [`Unpin`].Chan eil na tha an seòrsa sin a `smaoineachadh mu dheidhinn pinning buntainneach nuair nach eil [` Pin`]`<&mut Field>` air a chruthachadh a-riamh.
//!
//! ## Tha pinadh * structarail airson `field`
//!
//! Is e an roghainn eile a bhith a `co-dhùnadh gur e "structural" a th` ann am pinning airson `field`, a `ciallachadh ma tha an structar air a phinnadh tha an raon cuideachd.
//!
//! Leigidh seo le ro-mheasadh a sgrìobhadh a chruthaicheas [`Pin`]`<&mut Field>`, mar sin a` faicinn gu bheil an raon air a phinnadh:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Tha seo ceart gu leòr oir tha `field` air a phronnadh nuair a tha `self`.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Ach, thig pinning structarail le beagan riatanasan a bharrachd:
//!
//! 1. Feumaidh an structar a bhith [`Unpin`] a-mhàin ma tha na raointean structarail uile [`Unpin`].Is e seo an roghainn bunaiteach, ach tha [`Unpin`] na trait sàbhailte, mar sin mar ùghdar an structair tha e an urra riut *chan e* rudeigin mar `impl<T> Unpin for Struct<T>` a chur ris.
//! (Thoir fa-near gu bheil feum air còd neo-shàbhailte a bhith a `cur gnìomhachd ro-mheasaidh ris, agus mar sin chan eil an fhìrinn gu bheil [`Unpin`] sàbhailte trait a` briseadh a `phrionnsapail nach fheum thu ach dragh a ghabhail mu dheidhinn seo sam bith ma chleachdas tu` cunnartach '.
//! 2. Chan fhaod sgriosadair an structair raointean structarail a ghluasad a-mach às an argamaid aige.Is e seo an dearbh phuing a chaidh a thogail anns an [previous section][drop-impl]: tha `drop` a `toirt `&mut self`, ach is dòcha gu robh an structar (agus mar sin na raointean aige) air a phinned roimhe seo.
//!     Feumaidh tu gealltainn nach gluais thu raon taobh a-staigh do bhuileachadh [`Drop`].
//!     Gu sònraichte, mar a chaidh a mhìneachadh roimhe seo, tha seo a `ciallachadh nach fheum an structar agad a bhith * `#[repr(packed)]`.
//!     Faic an roinn sin airson mar a sgrìobhas tu [`drop`] ann an dòigh a chuidicheas an trusaiche thu gun a bhith a `briseadh pinning gun fhiosta.
//! 3. Feumaidh tu dèanamh cinnteach gun seas thu ris an [`Drop` guarantee][drop-guarantee]:
//!     aon uair `s gu bheil an structar agad air a phinnadh, chan eil an cuimhne anns a bheil an susbaint air a sgrìobhadh sìos no air a thuigsinn gun a bhith a` gairm luchd-sgrios an t-susbaint.
//!     Faodaidh seo a bhith duilich, mar a chithear le [`VecDeque<T>`]: faodaidh an sgriosadair [`VecDeque<T>`] fàiligeadh [`drop`] a ghairm air a h-uile eileamaid ma tha aon de na luchd-sgrios panics.Tha seo a `dol an-aghaidh gealladh [`Drop`], oir faodaidh e leantainn gu eileamaidean a bhith air an tuigsinn gun an sgriosadair aca a bhith air an gairm.(Chan eil ro-mheasaidhean pinning aig [`VecDeque<T>`], mar sin chan eil seo ag adhbhrachadh mì-chinnt.)
//! 4. Chan fhaod thu gnìomhachd sam bith eile a thabhann a dh `fhaodadh dàta a ghluasad a-mach às na raointean structarail nuair a tha an seòrsa agad air a phronnadh.Mar eisimpleir, ma tha [`Option<T>`] anns an structar agus gu bheil obrachadh coltach ri`take`ann le seòrsa `fn(Pin<&mut Struct<T>>) -> Option<T>`, faodar an obrachadh sin a chleachdadh gus `T` a ghluasad a-mach à `Struct<T>` pinned-a tha a` ciallachadh nach urrainn pinning a bhith structarail airson an raon a tha a `cumail seo dàta.
//!
//!     Airson eisimpleir nas iom-fhillte de bhith a `gluasad dàta a-mach à seòrsa pinned, smaoinich an robh modh `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>` aig [`RefCell<T>`].
//!     An uairsin dh `fhaodadh sinn na leanas a dhèanamh:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Tha seo tubaisteach, tha e a `ciallachadh gun urrainn dhuinn susbaint an [`RefCell<T>`] (a` cleachdadh `RefCell::get_pin_mut`) a phronnadh an toiseach agus an susbaint sin a ghluasad a `cleachdadh an t-iomradh mutable a fhuair sinn nas fhaide air adhart.
//!
//! ## Examples
//!
//! Airson seòrsa mar [`Vec<T>`], tha an dà chomas (pinning structarail no nach eil) a `dèanamh ciall.
//! Dh'fhaodadh dòighean `get_pin`/`get_pin_mut` a bhith aig [`Vec<T>`] le pinning structarail gus iomraidhean pinn fhaighinn air eileamaidean.Ach, cha b `urrainn dha * leigeil le bhith a` gairm [`pop`][Vec::pop] air [`Vec<T>`] pinned oir ghluaiseadh sin an susbaint (le structar structarail)!Agus cha b `urrainn dha [`push`][Vec::push] a cheadachadh, a dh` fhaodadh ath-riarachadh agus mar sin cuideachd an susbaint a ghluasad.
//!
//! Dh `fhaodadh [`Vec<T>`] gun pinning structarail `impl<T> Unpin for Vec<T>`, oir chan eil na susbaint a-riamh air am pronnadh agus tha an [`Vec<T>`] fhèin ceart gu leòr le bhith air a ghluasad cuideachd.
//! Aig an ìre sin chan eil buaidh aig pinning dìreach air an vector idir.
//!
//! Anns an leabharlann àbhaisteach, mar as trice chan eil seòrsaichean structarail aig seòrsachan puing, agus mar sin chan eil iad a `tabhann ro-mheasaidhean pinning.Sin as coireach gu bheil `Box<T>: Unpin` a`cumail airson a h-uile `T`.
//! Tha e ciallach seo a dhèanamh airson seòrsachan puing, oir chan eil gluasad an `Box<T>` gu dearbh a `gluasad an `T`: faodaidh an [`Box<T>`] a bhith air a ghluasad gu saor (aka `Unpin`) eadhon mura h-eil an `T`.Gu dearbh, eadhon [`Pin`]` <`[` Box`]`<T>Tha> `agus [` Pin`]`<&mut T>`an-còmhnaidh [`Unpin`] iad fhèin, airson an aon adhbhar: tha an susbaint aca (an `T`) air am pronnadh, ach faodar na comharran fhèin a ghluasad gun a bhith a`gluasad an dàta pinned.
//! Airson gach cuid [`Box<T>`] agus [`Pin`]`<`[`Box`] `<T>>`, a bheil an t-susbaint air a phinnadh gu tur neo-eisimeileach a bheil am puing air a phinnadh, a` ciallachadh nach eil pinning *structarail*.
//!
//! Nuair a bhios tu a `cur combinator [`Future`] an gnìomh, mar as trice bidh feum agad air pinning structarail airson an futures neadaichte, oir feumaidh tu iomraidhean pinned fhaighinn dhaibh gus [`poll`] a ghairm.
//! Ach ma tha dàta sam bith eile aig a `chothlamadh agad nach fheumar a phinnadh, faodaidh tu na raointean sin a dhèanamh gun structar agus mar sin faighinn a-steach gu saor le iomradh gluasadach eadhon nuair nach eil agad ach [` Pin`]`<&mut Self>`(leithid) mar anns a`bhuileachadh [`poll`] agad fhèin).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Puing pinned.
///
/// Is e pasgan a tha seo timcheall air seòrsa de phuing a tha a `dèanamh gu bheil luach aig a` phuing "pin" sin, a `cur stad air an luach air a bheil am puing sin a` gluasad mura cuir e [`Unpin`] an gnìomh.
///
///
/// *Faic na sgrìobhainnean [`pin` module] airson mìneachadh air pinning.*
///
/// [`pin` module]: self
///
// Note: tha an toradh `Clone` gu h-ìosal ag adhbhrachadh mì-chinnt mar a tha e comasach a bhuileachadh
// `Clone` airson iomraidhean mutable.
// Faic <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> airson tuilleadh fiosrachaidh.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Chan eil na buileachadh a leanas air an toirt a-mach gus cùisean fuaim a sheachnadh.
// `&self.pointer` cha bu chòir a bhith ruigsinneach do bhuileachadh trait gun earbsa.
//
// Faic <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> airson tuilleadh fiosrachaidh.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Tog `Pin<P>` ùr timcheall air comharradh gu cuid de dhàta de sheòrsa a bhios a `buileachadh [`Unpin`].
    ///
    /// Eu-coltach ri `Pin::new_unchecked`, tha an dòigh seo sàbhailte leis gu bheil am puing `P` a `dì-cheadachadh gu seòrsa [`Unpin`], a bhios a` cur às do na geallaidhean pinning.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SÀBHAILTEACHD: is e `Unpin` an luach air a bheil iomradh, agus mar sin chan eil riatanasan sam bith ann
        // timcheall air pinning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Unwraps an `Pin<P>` seo a `tilleadh a` phuing foidhe.
    ///
    /// Tha seo ag iarraidh gur e [`Unpin`] an dàta taobh a-staigh an `Pin` seo gus an urrainn dhuinn dearmad a dhèanamh air na h-invariants pinning nuair a dh `fhosglas tu e.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Tog `Pin<P>` ùr timcheall air iomradh air cuid de dhàta de sheòrsa a dh `fhaodadh no nach fhaod `Unpin` a bhuileachadh.
    ///
    /// Ma tha `pointer` a `dèanamh dìmeas air seòrsa `Unpin`, bu chòir `Pin::new` a chleachdadh na àite.
    ///
    /// # Safety
    ///
    /// Tha an neach-togail seo cunnartach oir chan urrainn dhuinn gealltainn gum bi an dàta air a bheil `pointer` air a phinnadh, a `ciallachadh nach tèid an dàta a ghluasad no gum bi an stòradh aige neo-dhligheach gus an tèid a leigeil sìos.
    /// Mura h-eil an `Pin<P>` a chaidh a thogail a `gealltainn gu bheil an dàta a tha `P` a` comharrachadh air a phinnadh, tha sin na bhriseadh air cùmhnant API agus dh `fhaodadh sin leantainn gu giùlan neo-mhìnichte ann an obrachaidhean (safe) nas fhaide air adhart.
    ///
    /// Le bhith a `cleachdadh an dòigh seo, tha thu a` dèanamh promise mu na buileachadh `P::Deref` agus `P::DerefMut`, ma tha iad ann.
    /// Nas cudromaiche, chan fhaod iad gluasad a-mach às na h-argamaidean `self` aca: Canaidh `Pin::as_mut` agus `Pin::as_ref` `DerefMut::deref_mut` agus `Deref::deref`*air a `phuing pinned* agus bidh iad an dùil gun seas na modhan sin ris na h-invariants pinning.
    /// A bharrachd air an sin, le bhith a `gairm an dòigh seo tha thu promise nach tèid na h-iomraidhean iomraidh `P` ris a ghluasad a-mach a-rithist;gu sònraichte, chan fheum e a bhith comasach `&mut P::Target` fhaighinn agus an uairsin gluasad a-mach às an iomradh sin (a`cleachdadh, mar eisimpleir [`mem::swap`]).
    ///
    ///
    /// Mar eisimpleir, tha e cunnartach a bhith a `gairm `Pin::new_unchecked` air `&'a mut T` oir ged as urrainn dhut a phronnadh airson an `'a` fad-beatha a chaidh a thoirt seachad, chan eil smachd agad air a bheil e air a phinned aon uair` s gu bheil `'a` a `tighinn gu crìch:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Bu chòir seo a bhith a `ciallachadh nach urrainn don phuing `a` gluasad a-rithist.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Dh'atharraich seòladh `a` gu slot cruachan `b`, agus mar sin ghluais `a` ged a tha sinn air a phinnadh roimhe!Tha sinn air briseadh a dhèanamh air cùmhnant pinning API.
    /////
    /// }
    /// ```
    ///
    /// Feumaidh luach, aon uair'sgu bheil e pinned, fuireach pinned gu bràth (mura h-eil an seòrsa aige a `buileachadh `Unpin`).
    ///
    /// San aon dòigh, tha e cunnartach a bhith a `gairm `Pin::new_unchecked` air `Rc<T>` oir dh` fhaodadh ailiasan a bhith ann ris an aon dàta nach eil fo smachd nan cuingealachaidhean pinning:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Bu chòir seo a bhith a `ciallachadh nach urrainn don phuing gluasad a-rithist.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // A-nis, nam b `e `x` an aon iomradh, tha iomradh gluasadach againn air dàta a shìn sinn gu h-àrd, a dh` fhaodadh sinn a chleachdadh gus a ghluasad mar a chunnaic sinn san eisimpleir roimhe seo.
    ///     // Tha sinn air briseadh a dhèanamh air cùmhnant pinning API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// A `faighinn iomradh co-roinnte pinned bhon phuing pinned seo.
    ///
    /// Is e dòigh coitcheann a tha seo airson a dhol bho `&Pin<Pointer<T>>` gu `Pin<&T>`.
    /// Tha e sàbhailte oir, mar phàirt de chùmhnant `Pin::new_unchecked`, chan urrainn don phuing gluasad às deidh `Pin<Pointer<T>>` a chruthachadh.
    ///
    /// "Malicious" tha buileachadh `Pointer::Deref` mar an ceudna air an riaghladh le cùmhnant `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SÀBHAILTEACHD: faic sgrìobhainnean mun ghnìomh seo
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Unwraps an `Pin<P>` seo a `tilleadh a` phuing foidhe.
    ///
    /// # Safety
    ///
    /// Tha an gnìomh seo cunnartach.Feumaidh tu gealltainn gun lean thu ort a `làimhseachadh a` phuing `P` mar pinned às deidh dhut an gnìomh seo a ghairm, gus an tèid na h-invariants air an t-seòrsa `Pin` a chumail suas.
    /// Mura h-eil an còd a tha a `cleachdadh an `P` a tha mar thoradh air a` leantainn air adhart a `cumail suas na h-invariants pinning a tha a` briseadh cùmhnant API agus a dh `fhaodadh leantainn gu giùlan neo-mhìnichte ann an obrachaidhean (safe) nas fhaide air adhart.
    ///
    ///
    /// Mas e an dàta bunaiteach [`Unpin`], bu chòir [`Pin::into_inner`] a chleachdadh na àite.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Faigh iomradh iomraiteach pinned bhon chomharra pinned seo.
    ///
    /// Is e dòigh coitcheann a tha seo airson a dhol bho `&mut Pin<Pointer<T>>` gu `Pin<&mut T>`.
    /// Tha e sàbhailte oir, mar phàirt de chùmhnant `Pin::new_unchecked`, chan urrainn don phuing gluasad às deidh `Pin<Pointer<T>>` a chruthachadh.
    ///
    /// "Malicious" tha buileachadh `Pointer::DerefMut` mar an ceudna air an riaghladh le cùmhnant `Pin::new_unchecked`.
    ///
    /// Tha an dòigh seo feumail nuair a bhios tu a `dèanamh iomadh gairm gu gnìomhan a bhios ag ithe an seòrsa pinned.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // dèan rudeigin
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` ag ithe `self`, mar sin ath-thionndaidh an `Pin<&mut Self>` tro `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SÀBHAILTEACHD: faic sgrìobhainnean mun ghnìomh seo
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// A `sònrachadh luach ùr don chuimhne air cùl an t-iomradh pinned.
    ///
    /// Bidh seo a `dol thairis air dàta pinned, ach tha sin ceart gu leòr: bidh an inneal-sgrios aige a` ruith mus tèid a sgrìobhadh thairis, agus mar sin chan eilear a `briseadh gealltanas pinning.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// A `togail prìne ùr le bhith a` mapadh luach an taobh a-staigh.
    ///
    /// Mar eisimpleir, nam biodh tu airson `Pin` de raon rudeigin fhaighinn, dh `fhaodadh tu seo a chleachdadh gus faighinn chun raon sin ann an aon loidhne de chòd.
    /// Ach, tha grunn gotchas ann leis na "pinning projections" sin;
    /// faic na sgrìobhainnean [`pin` module] airson tuilleadh fiosrachaidh mun chuspair sin.
    ///
    /// # Safety
    ///
    /// Tha an gnìomh seo cunnartach.
    /// Feumaidh tu gealltainn nach gluais an dàta a thilleas tu air ais cho fad `s nach gluais luach na h-argamaid (mar eisimpleir, seach gu bheil e mar aon de na raointean den luach sin), agus cuideachd nach gluais thu a-mach às an argamaid a gheibh thu gu an gnìomh a-staigh.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SÀBHAILTEACHD: feumaidh an cùmhnant sàbhailteachd airson `new_unchecked` a bhith
        // air a dhearbhadh leis an neach-fios.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Faigh teisteanas co-roinnte a-mach à prìne.
    ///
    /// Tha seo sàbhailte oir chan eil e comasach gluasad a-mach à iomradh coitcheann.
    /// Is dòcha gu bheil e coltach gu bheil duilgheadas an seo le mutability taobh a-staigh: gu dearbh, tha e comasach * `T` a ghluasad a-mach à `&RefCell<T>`.
    /// Ach, chan eil seo na dhuilgheadas fhad `s nach eil `Pin<&T>` ann cuideachd a` comharrachadh an aon dàta, agus cha leig `RefCell<T>` leat iomradh pinned a chruthachadh airson na tha ann.
    ///
    /// Faic an deasbad air ["pinning projections"] airson tuilleadh fiosrachaidh.
    ///
    /// Note: Bidh `Pin` cuideachd a `cur `Deref` an sàs air an targaid, a dh'fhaodar a chleachdadh gus faighinn chun luach a-staigh.
    /// Ach, chan eil `Deref` a `toirt seachad ach teisteanas a tha beò cho fada ri iasad an `Pin`, chan e beatha an `Pin` fhèin.
    /// Tha an dòigh seo a `ceadachadh an `Pin` a thionndadh gu iomradh leis an aon bheatha ris an `Pin` tùsail.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Bidh e ag atharrachadh an `Pin<&mut T>` seo gu `Pin<&T>` leis an aon bheatha.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Gets a mutable iomradh air an taobh a-staigh an dàta seo `Pin`.
    ///
    /// Feumaidh seo gur e `Unpin` an dàta taobh a-staigh an `Pin` seo.
    ///
    /// Note: Bidh `Pin` cuideachd a `cur `DerefMut` an sàs anns an dàta, a dh'fhaodar a chleachdadh gus faighinn chun luach a-staigh.
    /// Ach, chan eil `DerefMut` a `toirt seachad ach teisteanas a tha beò cho fada ri iasad an `Pin`, chan e beatha an `Pin` fhèin.
    ///
    /// Tha an dòigh seo a `ceadachadh an `Pin` a thionndadh gu iomradh leis an aon bheatha ris an `Pin` tùsail.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Gets a mutable iomradh air an taobh a-staigh an dàta seo `Pin`.
    ///
    /// # Safety
    ///
    /// Tha an gnìomh seo cunnartach.
    /// Feumaidh tu gealltainn nach gluais thu a-riamh an dàta a-mach às an iomradh gluasadach a gheibh thu nuair a chanas tu an gnìomh seo, gus an tèid na h-invariants air an t-seòrsa `Pin` a chumail suas.
    ///
    ///
    /// Mas e an dàta bunaiteach `Unpin`, bu chòir `Pin::get_mut` a chleachdadh na àite.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Tog prìne ùr le bhith a `mapadh luach an taobh a-staigh.
    ///
    /// Mar eisimpleir, nam biodh tu airson `Pin` de raon rudeigin fhaighinn, dh `fhaodadh tu seo a chleachdadh gus faighinn chun raon sin ann an aon loidhne de chòd.
    /// Ach, tha grunn gotchas ann leis na "pinning projections" sin;
    /// faic na sgrìobhainnean [`pin` module] airson tuilleadh fiosrachaidh mun chuspair sin.
    ///
    /// # Safety
    ///
    /// Tha an gnìomh seo cunnartach.
    /// Feumaidh tu gealltainn nach gluais an dàta a thilleas tu air ais cho fad `s nach gluais luach na h-argamaid (mar eisimpleir, seach gu bheil e mar aon de na raointean den luach sin), agus cuideachd nach gluais thu a-mach às an argamaid a gheibh thu gu an gnìomh a-staigh.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SÀBHAILTEACHD: tha e an urra ris an neach-fòn gun a bhith a `gluasad an
        // luach a-mach às an iomradh seo.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SÀBHAILTEACHD: leis gu bheil luach `this` cinnteach nach bi
        // air a ghluasad a-mach, tha a `ghairm seo gu `new_unchecked` sàbhailte.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Faigh teisteanas pinned bho iomradh statach.
    ///
    /// Tha seo sàbhailte, seach gu bheil `T` air iasad airson beatha `'static`, nach tig gu crìch gu bràth.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SÀBHAILTEACHD: Tha an 'iasad statach a `gealltainn nach bi an dàta
        // moved/invalidated gus an tèid a leigeil sìos (rud nach bi gu bràth).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Faigh teisteanas pinned mutable bho iomradh gluasadach gluasadach.
    ///
    /// Tha seo sàbhailte, seach gu bheil `T` air iasad airson beatha `'static`, nach tig gu crìch gu bràth.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SÀBHAILTEACHD: Tha an 'iasad statach a `gealltainn nach bi an dàta
        // moved/invalidated gus an tèid a leigeil sìos (rud nach bi gu bràth).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: tha seo a `ciallachadh gu bheil impl sam bith de `CoerceUnsized` a leigeas le coercing bho
// seòrsa a tha a `sparradh `Deref<Target=impl !Unpin>` gu seòrsa a tha a` sparradh `Deref<Target=Unpin>` mì-chinnteach.
// Is dòcha gum biodh impl mar sin mì-chinnteach airson adhbharan eile, ge-tà, mar sin feumaidh sinn a bhith faiceallach gun leigeil le leithid de sparran tighinn air tìr ann an std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}