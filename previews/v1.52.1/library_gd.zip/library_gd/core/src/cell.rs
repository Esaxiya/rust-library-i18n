//! Stuthan gabhaltach so-roinnte.
//!
//! Tha sàbhailteachd cuimhne Rust stèidhichte air an riaghailt seo: Le rud `T` air a thoirt seachad, chan urrainnear ach aon de na leanas a bhith agad:
//!
//! - Le grunn iomraidhean so-ruigsinneach (`&T`) air an nì (ris an canar cuideachd **aliasing**).
//! - Le aon iomradh gluasadach (`&mut T`) air an rud (ris an canar cuideachd **mutability**).
//!
//! Tha seo air a chuir an gnìomh leis an trusaiche Rust.Ach, tha suidheachaidhean ann far nach eil an riaghailt seo sùbailte gu leòr.Aig amannan feumaidh e iomadh iomradh a thoirt air rud agus a bhith ga bhrùthadh.
//!
//! Tha soithichean gluasadach so-roinnte ann gus comas a thoirt dha mutability ann an dòigh fo smachd, eadhon an làthair a bhith a `taomadh.Tha an dà chuid [`Cell<T>`] agus [`RefCell<T>`] a`ceadachadh seo a dhèanamh ann an dòigh le aon snàithlean.
//! Ach, chan eil `Cell<T>` no `RefCell<T>` snàithlean sàbhailte (chan eil iad a `buileachadh [`Sync`]).
//! Ma dh `fheumas tu aliasing agus mutation a dhèanamh eadar ioma snàithlean tha e comasach seòrsaichean [`Mutex<T>`], [`RwLock<T>`] no [`atomic`] a chleachdadh.
//!
//! Faodar luachan de na seòrsaichean `Cell<T>` agus `RefCell<T>` a bhith air an gluasad tro iomraidhean co-roinnte (ie
//! an seòrsa `&T` cumanta), ach chan urrainnear a `mhòr-chuid de na seòrsaichean Rust a mhùchadh ach tro iomraidhean sònraichte (`&mut T`).
//! Tha sinn ag ràdh gu bheil `Cell<T>` agus `RefCell<T>` a `toirt seachad` mutability taobh a-staigh `, an taca ri seòrsachan àbhaisteach Rust a tha a` taisbeanadh `oighreachd mutability`.
//!
//! Tha dà sheòrsa blas ann an seòrsaichean cealla: `Cell<T>` agus `RefCell<T>`.Bidh `Cell<T>` a `buileachadh mutability taobh a-staigh le bhith a` gluasad luachan a-steach agus a-mach às an `Cell<T>`.
//! Gus iomraidhean a chleachdadh an àite luachan, feumaidh fear an seòrsa `RefCell<T>` a chleachdadh, a `faighinn glas sgrìobhaidh mus dèan thu mutadh.Tha `Cell<T>` a`toirt seachad dhòighean gus an luach taobh a-staigh gnàthach fhaighinn air ais agus atharrachadh:
//!
//!  - Airson seòrsachan a tha a `cur an gnìomh [`Copy`], bidh am modh [`get`](Cell::get) a` faighinn air ais an luach taobh a-staigh gnàthach.
//!  - Airson seòrsachan a tha a `cur an gnìomh [`Default`], tha am modh [`take`](Cell::take) a` dol an àite an luach a-staigh gnàthach le [`Default::default()`] agus a `tilleadh an luach ùr.
//!  - Airson a h-uile seòrsa, tha am modh [`replace`](Cell::replace) a `dol an àite an luach a-staigh a th` ann an-dràsta agus a `tilleadh an luach ùr agus bidh an dòigh [`into_inner`](Cell::into_inner) ag ithe an `Cell<T>` agus a` tilleadh an luach a-staigh.
//!  A bharrachd air an sin, tha an dòigh [`set`](Cell::set) a `dol an àite an luach a-staigh, a` leigeil às an luach ùr.
//!
//! `RefCell<T>` a `cleachdadh beatha Rust gus` iasadachd fiùghantach `a chuir an gnìomh, pròiseas far am faod neach faighinn a-steach ruigsinneachd sealach, toirmeasgach, gluasadach don luach a-staigh.
//! Iasadan airson `RefCell<T>thathas a`cumail sùil air`s aig àm-ruith`, eu-coltach ri seòrsachan iomraidh dùthchasach Rust a tha air an leantainn gu staitigeach gu h-iomlan, aig àm cur ri chèile.
//! Leis gu bheil iasadan `RefCell<T>` fiùghantach tha e comasach feuchainn ri luach fhaighinn air iasad a tha mar-thà air iasad;nuair a thachras seo bidh e a `leantainn gu snàithlean panic.
//!
//! # Cuin a thaghadh mutability taobh a-staigh
//!
//! Is e an mutability oighreachail as cumanta, far am feum ruigsinneachd gun samhail a bhith aig luach mutate, aon de na prìomh eileamaidean cànain a tha a `toirt comas do Rust a bhith a` reusanachadh gu làidir mu bhith a `taobhadh ri puing, a` cur stad gu laghail air biastagan tubaist.
//! Air sgàth sin, is fheàrr mutability oighreachail, agus tha mutability taobh a-staigh na roghainn mu dheireadh.
//! Leis gu bheil seòrsaichean cealla a `comasachadh mùthadh far am biodh e air a cheadachadh air dhòigh eile, tha amannan ann nuair a dh` fhaodadh mutability taobh a-staigh a bhith iomchaidh, no eadhon *feumar* a chleachdadh, me
//!
//! * Stiùireadh a mutability 'inside' rudeigin immutable
//! * Mion-fhiosrachadh buileachaidh mu dhòighean so-ruigsinneach gu loidsigeach.
//! * Buileachadh mutating de [`Clone`].
//!
//! ## Stiùireadh a mutability 'inside' rudeigin immutable
//!
//! Bidh mòran de sheòrsan puing smart roinnte, a `gabhail a-steach [`Rc<T>`] agus [`Arc<T>`], a` toirt seachad soithichean a dh `fhaodar a bhith air an clònadh agus air an roinn eadar ioma-phàrtaidhean.
//! Leis gum faodadh na luachan a tha ann an iomadachadh, chan fhaodar an toirt air iasad ach le `&`, chan e `&mut`.
//! Às aonais cheallan bhiodh e do-dhèanta dàta a thionndadh taobh a-staigh nan comharran snasail sin idir.
//!
//! Tha e gu math cumanta an uairsin `RefCell<T>` a chuir taobh a-staigh seòrsachan puing co-roinnte gus mutability a thoirt air ais:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Cruthaich ùr an loga bacaidh a 'cuingealachadh comas an fiùghantach iasaid
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Thoir fa-near, mura robh sinn air leigeil leis an iasad roimhe den tasgadan tuiteam a-mach à farsaingeachd gum biodh an iasad às deidh sin ag adhbhrachadh snàithlean fiùghantach panic.
//!     //
//!     // Is e seo am prìomh chunnart bho bhith a `cleachdadh `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Thoir fa-near gu bheil an eisimpleir seo a `cleachdadh `Rc<T>` agus chan e `Arc<T>`.`RefCell<T>Tha iad airson suidheachaidhean aon-snàithlean.Beachdaich air a bhith a `cleachdadh [`RwLock<T>`] no [`Mutex<T>`] ma tha feum agad air mutability co-roinnte ann an suidheachadh ioma-snàthainn.
//!
//! ## Mion-fhiosrachadh buileachaidh mu dhòighean so-ruigsinneach gu loidsigeach
//!
//! Aig amannan is dòcha gum biodh e ion-mhiannaichte gun a bhith a `nochdadh ann an API gu bheil mutation a` tachairt "under the hood".
//! Faodaidh seo a bhith air sgàth loidsigeach an t-obrachadh a tha immutable, ach me, Tasgadh feachdan a 'buileachadh a' cluich mutation;no air sgàth gu feum thu mutation a chleachdadh gus modh trait a chuir an gnìomh a chaidh a mhìneachadh an toiseach gus `&self` a ghabhail.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Tha coimpiutaireachd daor a `dol an seo
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Buileachadh mutating de `Clone`
//!
//! Chan eil seo ach cùis shònraichte, ach cumanta, den fhear roimhe: a `falach mutability airson obrachaidhean a tha coltach gu bheil iad do-ruigsinneach.
//! Thathas an dùil nach atharraich an dòigh [`clone`](Clone::clone) luach an stòr, agus thathar ag aithris gun gabh e `&self`, chan e `&mut self`.
//! Mar sin, feumaidh mùthadh sam bith a thachras anns an dòigh `clone` seòrsachan cealla a chleachdadh.
//! Mar eisimpleir, tha [`Rc<T>`] a `cumail suas na cunntasan iomraidh aige taobh a-staigh `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Àite cuimhne gluasadach.
///
/// # Examples
///
/// Anns an eisimpleir seo, chì thu gu bheil `Cell<T>` a 'toirt cothrom mutation taobh a-staigh an immutable struct.
/// Ann am briathran eile, tha e a 'toirt cothrom "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // MEARACHD: Tha `my_struct` so-ruigsinneach
/// // my_struct.regular_field =new_value;
///
/// // OBAIR: ged a tha `my_struct` so-ruigsinneach, is e `Cell` a th `ann an `special_field`,
/// // a dh `fhaodas a bhith air a thionndadh gu bràth
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Faic an [module-level documentation](self) airson tuilleadh.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// A `cruthachadh `Cell<T>`, leis an luach `Default` airson T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// A `cruthachadh `Cell` ùr anns a bheil an luach a chaidh a thoirt seachad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// A `suidheachadh an luach a tha na bhroinn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Ag atharrachadh luachan dà chealla.
    /// Is e eadar-dhealachadh le `std::mem::swap` nach fheum an gnìomh seo iomradh `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SÀBHAILTEACHD: Faodaidh seo a bhith cunnartach ma thèid a ghairm bho snàithleanan fa leth, ach `Cell`
        // tha `!Sync` gus nach tachair seo.
        // Cha chuir seo comharran sam bith neo-dhligheach cuideachd oir bidh `Cell` a `dèanamh cinnteach nach bi dad sam bith eile a` comharrachadh a-steach do aon de na`Cell`s sin.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// A `dol an àite an luach a tha na bhroinn le `val`, agus a` tilleadh an t-seann luach a tha ann.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SÀBHAILTEACHD: Faodaidh seo rèisean dàta adhbhrachadh ma thèid an gairm bho snàithlean fa leth,
        // ach is e `Cell` `!Sync` gus nach tachair seo.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Unwraps an luach.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// A `tilleadh leth-bhreac den luach a tha na bhroinn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SÀBHAILTEACHD: Faodaidh seo rèisean dàta adhbhrachadh ma thèid an gairm bho snàithlean fa leth,
        // ach is e `Cell` `!Sync` gus nach tachair seo.
        unsafe { *self.value.get() }
    }

    /// Ag ùrachadh an luach a tha ann le bhith a `cleachdadh gnìomh agus a` tilleadh an luach ùr.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// A `tilleadh stiùireadh amh chun an dàta bunaiteach anns a` chill seo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// A `tilleadh iomradh gluasadach air an dàta bunaiteach.
    ///
    /// Bidh an gairm seo a `faighinn iasad de `Cell` gu siùbhlach (aig àm cur ri chèile) a tha a` gealltainn gu bheil an aon iomradh againn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// A `tilleadh `&Cell<T>` bho `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SÀBHAILTEACHD: Tha `&mut` a `dèanamh cinnteach à ruigsinneachd gun samhail.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// A `toirt luach a` chill, a `fàgail `Default::default()` na àite.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// A `tilleadh `&[Cell<T>]` bho `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SÀBHAILTEACHD: Tha an aon chruth cuimhne aig `Cell<T>` ri `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Àite cuimhne gluasadach le riaghailtean iasad a chaidh a sgrùdadh gu dinamach
///
/// Faic an [module-level documentation](self) airson tuilleadh.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// An error thill le [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Mearachd air a thilleadh le [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Tha luachan adhartach a `riochdachadh an àireamh de `Ref` gnìomhach.Tha luachan àicheil a`riochdachadh an àireamh de `RefMut` gnìomhach.
// Ioma `RefMut`s Chan urrainn a bhith gnìomhach aig àm ma tha iad a 'buntainn gu sònraichte, nonoverlapping phàirtean `RefCell` (me, an diofar raointean de sliseag).
//
// `Ref` Tha `RefMut` le chèile dà fhacal ann am meud, agus mar sin tha e coltach nach bi gu leòr de `Ref`s no`RefMut`s ann gu leòr airson a dhol thairis air leth den raon `usize`.
// Mar sin, is dòcha nach bi `BorrowFlag` a-riamh a `cur thairis no a` cur thairis.
// Ach, chan e seo barantas, mar pathological dh'fhaodadh am prògram tric a chruthachadh agus an uair sin mem::forget `Ref`s no`RefMut`s.
// Mar sin, feumaidh a h-uile code follaiseach sùil airson overflow agus underflow ann an òrdugh a sheachnadh unsafety, no co-dhiù an giùlan fhèin gu ceart ann an tachartas a overflow no underflow thachras (me, faic BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// A `cruthachadh `RefCell` ùr anns a bheil `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// A `caitheamh an `RefCell`, a` tilleadh an luach fillte.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Leis gu bheil an gnìomh seo a `toirt `self` (an `RefCell`) a rèir luach, tha an t-inneal-cruinneachaidh a` dearbhadh gu staitistigeach nach eil e air iasad an-dràsta.
        //
        self.value.into_inner()
    }

    /// An àite a 'pasgadh luach le fear ùr, a' tilleadh an t-seann luach, gun deinitializing aon.
    ///
    ///
    /// Tha an gnìomh seo a `freagairt ri [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics ma gheibhear an luach air iasad an-dràsta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// A `dol an àite an luach fillte le fear ùr air a thomhas bho `f`, a` tilleadh an t-seann luach, gun a bhith a `dì-chòireachadh aon seach aon.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma gheibhear an luach air iasad an-dràsta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Ag atharrachadh luach fillte `self` le luach fillte `other`, gun a bhith a `dì-chòireachadh aon seach aon.
    ///
    ///
    /// Tha an gnìomh seo a `freagairt ri [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics ma tha an luach ann an `RefCell` air iasad an-dràsta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Tha e gu mòr a `faighinn iasad den luach fillte.
    ///
    /// Mairidh an iasad gus am fàg an `Ref` a chaidh a thilleadh a-mach farsaingeachd.
    /// Faodar grunn iasadan so-ruigsinneach a thoirt a-mach aig an aon àm.
    ///
    /// # Panics
    ///
    /// Panics ma tha an luach an-dràsta air iasad gu mòr.
    /// Airson caochladh neo-phasgach, cleachd [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Eisimpleir de panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Immutably iasad luach an paisgte, a 'tilleadh mearachd ma tha an luach a tha an-dràsta mutably iasad.
    ///
    ///
    /// Mairidh an iasad gus am fàg an `Ref` a chaidh a thilleadh a-mach farsaingeachd.
    /// Faodar grunn iasadan so-ruigsinneach a thoirt a-mach aig an aon àm.
    ///
    /// Is e seo an tionndadh neo-phasgach de [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SÀBHAILTEACHD: Tha `BorrowRef` a `dèanamh cinnteach nach eil ann ach ruigsinneachd do-ruigsinneach
            // chun an luach fhad `s a tha e air iasad.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Bidh mòran a `faighinn iasad den luach fillte.
    ///
    /// Mairidh an iasad gus an till an `RefMut` air ais no a h-uile `RefMut` a thig bhon raon fàgail aige.
    ///
    /// Tha luach nach urrainn a bhith fhad 'sa iasad seo iasaid a tha gnìomhach.
    ///
    /// # Panics
    ///
    /// Panics ma gheibhear an luach air iasad an-dràsta.
    /// Airson caochladh neo-phasgach, cleachd [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Eisimpleir de panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Bidh mòran a `faighinn iasad den luach fillte, a` tilleadh mearachd ma gheibhear an luach air iasad an-dràsta.
    ///
    ///
    /// Mairidh an iasad gus an till an `RefMut` air ais no a h-uile `RefMut` a thig bhon raon fàgail aige.
    /// Tha luach nach urrainn a bhith fhad 'sa iasad seo iasaid a tha gnìomhach.
    ///
    /// Is e seo an caochladh neo-phasgach de [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SÀBHAILTEACHD: Tha `BorrowRef` a `gealltainn ruigsinneachd gun samhail.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// A `tilleadh stiùireadh amh chun an dàta bunaiteach anns a` chill seo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// A `tilleadh iomradh gluasadach air an dàta bunaiteach.
    ///
    /// Bidh an gairm seo a `faighinn iasad de `RefCell` gu siùbhlach (aig àm cur ri chèile) agus mar sin chan eil feum air sgrùdaidhean fiùghantach.
    ///
    /// Ach bi faiceallach: tha an dòigh seo an dùil gum bi `self` mutable, mar as trice chan eil seo fìor nuair a bhios tu a `cleachdadh `RefCell`.
    ///
    /// Thoir sùil air an dòigh [`borrow_mut`] an àite mura h-eil `self` mutable.
    ///
    /// Cuideachd, thoir an aire nach eil an dòigh seo ach airson suidheachaidhean sònraichte agus mar as trice chan e na tha thu ag iarraidh.
    /// Ma tha teagamh ann, cleachd [`borrow_mut`] na àite.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Thoir às a `bhuaidh a th` aig geàrdan sgaoilte air staid iasaid an `RefCell`.
    ///
    /// Tha an gairm seo coltach ri [`get_mut`] ach nas speisealta.
    /// Bidh e a `faighinn iasad de `RefCell` gu siùbhlach gus dèanamh cinnteach nach eil iasadan ann agus an uairsin ag ath-shuidheachadh na stàite a` cumail sùil air iasadan co-roinnte.
    /// Tha seo buntainneach ma chaidh cuid de iasadan `Ref` no `RefMut` a leigeil a-mach.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Immutably iasad luach an paisgte, a 'tilleadh mearachd ma tha an luach a tha an-dràsta mutably iasad.
    ///
    /// # Safety
    ///
    /// Eu-coltach ri `RefCell::borrow`, tha an dòigh seo cunnartach oir chan eil e a `tilleadh `Ref`, mar sin a` fàgail a `bhratach air iasad gun suathadh.
    /// Le bhith a `faighinn iasad den `RefCell` fhad` s a tha an t-iomradh air a thilleadh leis an dòigh seo beò tha giùlan neo-mhìnichte.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SÀBHAILTEACHD: Bidh sinn a `dèanamh cinnteach nach eil duine gu gnìomhach a` sgrìobhadh a-nis, ach tha
            // uallach an neach-conaltraidh dèanamh cinnteach nach bi duine a `sgrìobhadh gus nach eilear a` cleachdadh an iomradh a chaidh a thilleadh.
            // Cuideachd, tha `self.value.get()` a `toirt iomradh air an luach a tha le `self` agus mar sin tha e cinnteach gum bi e dligheach airson beatha `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// A `toirt an luach fillte, a` fàgail `Default::default()` na àite.
    ///
    /// # Panics
    ///
    /// Panics ma gheibhear an luach air iasad an-dràsta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics ma tha an luach an-dràsta air iasad gu mòr.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// A `cruthachadh `RefCell<T>`, leis an luach `Default` airson T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics ma tha an luach ann an `RefCell` air iasad an-dràsta.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics ma tha an luach ann an `RefCell` air iasad an-dràsta.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics ma tha an luach ann an `RefCell` air iasad an-dràsta.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ma tha an luach ann an `RefCell` air iasad an-dràsta.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ma tha an luach ann an `RefCell` air iasad an-dràsta.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ma tha an luach ann an `RefCell` air iasad an-dràsta.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics ma tha an luach ann an `RefCell` air iasad an-dràsta.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Faodaidh àrdachadh air iasad leantainn gu luach neo-leughaidh (<=0) anns na cùisean sin:
            // 1. B `e <0 a bh` ann, ie tha iasadan sgrìobhaidh ann, agus mar sin chan urrainn dhuinn iasad leughaidh a cheadachadh air sgàth riaghailtean iomraidh Rust
            // 2.
            // B `e isize::MAX (an ìre as motha de dh` iasadan leughaidh) agus chaidh e thairis gu isize::MIN (an ìre as motha de dh `iasadan sgrìobhaidh) agus mar sin chan urrainn dhuinn iasad leughaidh a bharrachd a cheadachadh oir chan urrainn do isize a bhith a` riochdachadh na h-uimhir de iasadan leughaidh (chan urrainn seo tachairt mura h-urrainn) thu mem::forget barrachd air beagan seasmhach de `Ref`s, nach eil na chleachdadh math)
            //
            //
            //
            //
            None
        } else {
            // Faodaidh àrdachadh air iasad luach leughaidh (> 0) fhaighinn anns na cùisean sin:
            // 1. B `e=0, ie cha deach fhaighinn air iasad, agus tha sinn a` gabhail a `chiad iasad a chaidh a leughadh
            // 2. Bha e> 0 agus <isize::MAX, i.e.
            // chaidh iasadan a leughadh, agus tha isize mòr gu leòr airson a bhith a `riochdachadh aon iasad leughaidh eile
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Leis gu bheil an Ref seo ann, tha fios againn gur e iasad leughaidh a tha sa bhratach air iasad.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Cuir stad air a `chunntair iasad bho bhith a` cur thairis gu iasad sgrìobhaidh.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// A `cuairteachadh iomradh air iasad gu luach ann am bogsa `RefCell`.
/// Seòrsa pasgain airson luach nach fhaighear air iasad bho `RefCell<T>`.
///
/// Faic an [module-level documentation](self) airson tuilleadh.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Dèan lethbhreac de `Ref`.
    ///
    /// Tha an `RefCell` air iasad mar-thà agus mar sin chan urrainn dha fàiligeadh.
    ///
    /// Tha seo na ghnìomh co-cheangailte ris am feumar a chleachdadh mar `Ref::clone(...)`.
    /// Bheireadh buileachadh `Clone` no dòigh-obrach bacadh air cleachdadh farsaing `r.borrow().clone()` gus susbaint `RefCell` a ghleusadh.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// A `dèanamh `Ref` ùr airson pàirt den dàta a chaidh fhaighinn air iasad.
    ///
    /// Tha an `RefCell` air iasad mar-thà agus mar sin chan urrainn dha fàiligeadh.
    ///
    /// Tha seo na ghnìomh co-cheangailte ris am feumar a chleachdadh mar `Ref::map(...)`.
    /// Bhiodh dòigh-obrach a `cur bacadh air modhan den aon ainm air susbaint `RefCell` a chaidh a chleachdadh tro `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// A `dèanamh `Ref` ùr airson co-phàirt roghainneil den dàta a chaidh fhaighinn air iasad.
    /// Tha an geàrd tùsail air a thilleadh mar `Err(..)` ma thilleas an dùnadh `None`.
    ///
    /// Tha an `RefCell` air iasad mar-thà agus mar sin chan urrainn dha fàiligeadh.
    ///
    /// Tha seo na ghnìomh co-cheangailte ris am feumar a chleachdadh mar `Ref::filter_map(...)`.
    /// Bhiodh dòigh-obrach a `cur bacadh air modhan den aon ainm air susbaint `RefCell` a chaidh a chleachdadh tro `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// A `cuairteachadh `Ref` ann an grunn` Ref`s airson diofar phàirtean den dàta a chaidh fhaighinn air iasad.
    ///
    /// Tha an `RefCell` air iasad mar-thà agus mar sin chan urrainn dha fàiligeadh.
    ///
    /// Tha seo na ghnìomh co-cheangailte ris am feumar a chleachdadh mar `Ref::map_split(...)`.
    /// Bhiodh dòigh-obrach a `cur bacadh air modhan den aon ainm air susbaint `RefCell` a chaidh a chleachdadh tro `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Tionndadh gu iomradh air an dàta bunaiteach.
    ///
    /// Chan urrainnear an `RefCell` bunaiteach a thoirt air iasad bho chèile a-rithist agus bidh e an-còmhnaidh air iasad mar-thà.
    ///
    /// Chan e deagh bheachd a th `ann a bhith a` leigeil a-mach barrachd air àireamh cunbhalach de dh `iomraidhean.
    /// Tha `RefCell` Faodar immutably air iasad a-rithist ma-mhàin àireamh nas lugha de aoidion thachair ann uile gu lèir.
    ///
    /// Tha seo na ghnìomh co-cheangailte ris am feumar a chleachdadh mar `Ref::leak(...)`.
    /// Bhiodh dòigh-obrach a `cur bacadh air modhan den aon ainm air susbaint `RefCell` a chaidh a chleachdadh tro `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Le bhith a `dìochuimhneachadh an Ref seo tha sinn a` dèanamh cinnteach nach urrainn don chunntair iasaid san RefCell a dhol air ais gu UNUSED taobh a-staigh beatha `'b`.
        // Dh'fheumadh ath-shuidheachadh na stàite tracadh iomraidh iomradh sònraichte air an RefCell a chaidh fhaighinn air iasad.
        // Cha ghabh tuilleadh iomraidhean gluasadach a chruthachadh bhon chill thùsail.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// A `dèanamh `RefMut` ùr airson co-phàirt den dàta a chaidh fhaighinn air iasad, me, tionndadh enum.
    ///
    /// Tha an `RefCell` mu thràth air iasad gu mòr, agus mar sin chan urrainn dha fàiligeadh.
    ///
    /// Tha seo na ghnìomh co-cheangailte ris am feumar a chleachdadh mar `RefMut::map(...)`.
    /// Bhiodh dòigh-obrach a `cur bacadh air modhan den aon ainm air susbaint `RefCell` a chaidh a chleachdadh tro `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): càraich iasad-seic
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// A `dèanamh `RefMut` ùr airson co-phàirt roghainneil den dàta a chaidh fhaighinn air iasad.
    /// Tha an geàrd tùsail air a thilleadh mar `Err(..)` ma thilleas an dùnadh `None`.
    ///
    /// Tha an `RefCell` mu thràth air iasad gu mòr, agus mar sin chan urrainn dha fàiligeadh.
    ///
    /// Tha seo na ghnìomh co-cheangailte ris am feumar a chleachdadh mar `RefMut::filter_map(...)`.
    /// Bhiodh dòigh-obrach a `cur bacadh air modhan den aon ainm air susbaint `RefCell` a chaidh a chleachdadh tro `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): càraich iasad-seic
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SÀBHAILTEACHD: tha an gnìomh a `cumail ri teisteanas sònraichte fad na h-ùine
        // den ghairm aige tro `orig`, agus chan eil iomradh air a `phuing ach taobh a-staigh a` ghairm gnìomh gun a bhith a `leigeil leis an iomradh toirmeasgach teicheadh.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SÀBHAILTEACHD: an aon rud gu h-àrd.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// A `cuairteachadh `RefMut` ann an grunn` RefMut`s airson diofar phàirtean den dàta a chaidh fhaighinn air iasad.
    ///
    /// Bidh an `RefCell` bunaiteach a `faighinn iasad bho chèile gus an tèid an dithis` RefMut` a thilleadh a-mach à farsaingeachd.
    ///
    /// Tha an `RefCell` mu thràth air iasad gu mòr, agus mar sin chan urrainn dha fàiligeadh.
    ///
    /// Tha seo na ghnìomh co-cheangailte ris am feumar a chleachdadh mar `RefMut::map_split(...)`.
    /// Bhiodh dòigh-obrach a `cur bacadh air modhan den aon ainm air susbaint `RefCell` a chaidh a chleachdadh tro `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Tionndadh gu iomradh gluasadach air an dàta bunaiteach.
    ///
    /// Chan urrainnear an `RefCell` bunaiteach fhaighinn air iasad a-rithist agus bidh e an-còmhnaidh a `nochdadh air iasad mar-thà, a` dèanamh an t-iomradh air a thilleadh dìreach an taobh a-staigh.
    ///
    ///
    /// Tha seo na ghnìomh co-cheangailte ris am feumar a chleachdadh mar `RefMut::leak(...)`.
    /// Bhiodh dòigh-obrach a `cur bacadh air modhan den aon ainm air susbaint `RefCell` a chaidh a chleachdadh tro `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Le bhith a `dìochuimhneachadh am BorrowRefMut seo bidh sinn a` dèanamh cinnteach nach urrainn don chunntair iasaid san RefCell a dhol air ais gu UNUSED taobh a-staigh beatha `'b`.
        // Dh'fheumadh ath-shuidheachadh na stàite tracadh iomraidh iomradh sònraichte air an RefCell a chaidh fhaighinn air iasad.
        // Chan urrainnear tuilleadh iomraidhean a chruthachadh bhon chill thùsail taobh a-staigh na beatha sin, a `ciallachadh gur e an iasad gnàthach an aon iomradh airson na beatha a tha air fhàgail.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Eu-coltach ri BorrowRefMut::clone, canar ùr ri cruthachadh a `chiad fhear
        // iomradh mutable, agus mar sin chan fheum iomradh a bhith ann an-dràsta.
        // Mar sin, ged a bhios clone ag àrdachadh an ath-chuinge gluasadach, an seo chan eil sinn gu soilleir a `ceadachadh a dhol bho UNUSED gu UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Clones a `BorrowRefMut`.
    //
    // Chan eil seo dligheach ach ma thèid gach `BorrowRefMut` a chleachdadh gus sùil a chumail air iomradh gluasadach air raon sònraichte neo-cheangailte den nì tùsail.
    //
    // Chan eil seo ann an inneal Clone gus nach bi an còd sin a `ciallachadh gu h-obann.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Cuir casg air a `chunntair iasad bho bhith a` sruthadh.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Seòrsa pasgain airson luach air iasad bho `RefCell<T>`.
///
/// Faic an [module-level documentation](self) airson tuilleadh.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Am prìomh thùs airson mutability taobh a-staigh ann an Rust.
///
/// Ma tha iomradh `&T` agad, an uairsin mar as trice ann an Rust bidh an trusaiche a `dèanamh optimizations stèidhichte air an eòlas gu bheil `&T` a` comharrachadh dàta so-ruigsinneach.Thathas a `meas a bhith ag atharrachadh an dàta sin, mar eisimpleir tro ailias no le bhith a` gluasad `&T` a-steach do `&mut T`, mar ghiùlan neo-mhìnichte.
/// `UnsafeCell<T>` tarraing a-mach às a `ghealladh immutability airson `&T`: faodaidh iomradh co-roinnte `&UnsafeCell<T>` a bhith a` comharrachadh dàta a tha air a thionndadh.Canar "interior mutability" ris an seo.
///
/// Bidh a h-uile seòrsa eile a leigeas le mutability a-staigh, leithid `Cell<T>` agus `RefCell<T>`, a `cleachdadh `UnsafeCell` air an taobh a-staigh gus an dàta aca a phasgadh.
///
/// Thoir fa-near nach toir `UnsafeCell` buaidh ach air a `ghealladh immutability airson iomraidhean co-roinnte.Chan eil buaidh sam bith air a`ghealladh àraid airson iomraidhean gluasadach.Chan eil *dòigh* laghail ann airson aliasing `&mut` fhaighinn, chan e eadhon le `UnsafeCell<T>`.
///
/// Tha an API `UnsafeCell` fhèin gu teicnigeach gu math sìmplidh: tha [`.get()`] a `toirt dhut puing amh `*mut T` chun t-susbaint aige.Tha e an urra ri _you_ mar an dealbhaiche toirt air falbh am puing amh sin a chleachdadh gu ceart.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Tha na riaghailtean mionaideach aliasing Rust rudeigin siùbhlach, ach chan eil na prìomh phuingean connspaideach:
///
/// - Ma chruthaicheas tu iomradh sàbhailte le `'a` fad-beatha (an dara cuid iomradh `&T` no `&mut T`) a tha ruigsinneach le còd sàbhailte (mar eisimpleir, air sgàth gun do thill thu air ais e), chan fhaod thu faighinn chun dàta ann an dòigh sam bith a tha a `dol an aghaidh an t-iomradh sin airson a` chòrr. de `'a`.
/// Mar eisimpleir, tha seo a `ciallachadh ma bheir thu an `*mut T` bho `UnsafeCell<T>` agus ma thilgeas tu e gu `&T`, feumaidh an dàta ann an `T` fuireach neo-ghluasadach (modulo dàta `UnsafeCell` sam bith a lorgar taobh a-staigh `T`, gu dearbh) gus an tig beatha an iomraidh sin gu crìch.
/// Mar an ceudna, ma tha thu a chruthachadh `&mut T` iomradh a tha air a leigeil ma sgaoil gu sàbhailte code, an sin chan fhaod thu cothrom air dàta taobh a-staigh `UnsafeCell` gus iomradh a criochnachadh.
///
/// - Aig a h-uile àm, feumaidh tu rèisean dàta a sheachnadh.Ma tha cothrom aig grunn snàithleanan air an aon `UnsafeCell`, feumaidh sgrìobhadh ceart tachairt mus dèan thu sgrìobhadh mu dheidhinn gach ruigsinneachd eile (no cleachd atomics).
///
/// Gus cuideachadh le dealbhadh ceart, tha na suidheachaidhean a leanas air an cur an cèill gu laghail airson còd aon-snàithlean:
///
/// 1. Faodar iomradh `&T` a leigeil ma sgaoil gu còd sàbhailte agus an sin faodaidh e a bhith ann còmhla ri iomraidhean `&T` eile, ach chan ann le `&mut T`
///
/// 2. Faodar iomradh `&mut T` a leigeil ma sgaoil gu còd sàbhailte fhad `s nach eil `&mut T` no `&T` eile ann còmhla ris.Feumaidh `&mut T` a bhith gun samhail an-còmhnaidh.
///
/// Thoir fa-near, ged a tha thu a `mùchadh susbaint `&UnsafeCell<T>` (eadhon ged a tha `&UnsafeCell<T>` eile a` toirt iomradh air a `chill) ceart gu leòr (fhad` s a chuireas tu na h-invariants gu h-àrd an sàs ann an dòigh eile), tha e fhathast na ghiùlan neo-mhìnichte gu bheil grunn ailiasan `&mut UnsafeCell<T>` agad.
/// Is e sin, tha `UnsafeCell` na inneal-fillte a chaidh a dhealbhadh gus eadar-obrachadh sònraichte le _shared_ accesses (_i.e._, tro iomradh `&UnsafeCell<_>`);chan eil draoidheachd sam bith ann nuair a bhios tu a `dèiligeadh ri _exclusive_ accesses (_e.g._, tro `&mut UnsafeCell<_>`): chan fhaodar an cealla no an luach fillte a bhith air a chlaonadh fad na h-iasad `&mut` sin.
///
/// Tha seo air a thaisbeanadh leis an accessor [`.get_mut()`], a tha na _safe_ getter a bheir a-mach `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Seo eisimpleir a `sealltainn mar as urrainn dhut susbaint `UnsafeCell<_>` a thionndadh gu làidir a dh` aindeoin gu bheil grunn iomraidhean ann a tha a `taobhadh ris a` chill:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Faigh iomraidhean iomadach/co-roinnte airson an aon `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SÀBHAILTEACHD: taobh a-staigh an raon seo chan eil iomradh sam bith eile air susbaint `x`,
///     // mar sin tha an fheadhainn againn gu h-èifeachdach gun samhail.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- iasad-+
///     *p1_exclusive += 27; // |
/// } // <---------- nach urrainn a dhol taobh a-muigh a 'phuing seo -------------------+
///
/// unsafe {
///     // SÀBHAILTEACHD: taobh a-staigh an raoin seo chan eil dùil aig duine gum bi cothrom sònraichte aige air susbaint `x`,
///     // gus am faigh sinn iomadh ruigsinneachd co-roinnte aig an aon àm.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Tha an eisimpleir a leanas a `sealltainn gu bheil ruigsinneachd toirmeasgach air `UnsafeCell<T>` a` ciallachadh ruigsinneachd air leth don `T` aige:
///
/// ```rust
/// #![forbid(unsafe_code)] // le ruigsinneachd air leth,
///                         // `UnsafeCell` na phasgan fosgailte no-op, mar sin chan eil feum air `unsafe` an seo.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Faigh iomradh sònraichte le ùine air a sgrùdadh le `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Le iomradh air leth, is urrainn dhuinn na susbaint a thionndadh an-asgaidh.
/// *p_unique.get_mut() = 0;
/// // Air neo, mar an ceudna:
/// x = UnsafeCell::new(0);
///
/// // Nuair a tha an luach againn, is urrainn dhuinn na susbaint a thoirt a-mach an-asgaidh.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Constructs ùr eisimpleir de `UnsafeCell` a bhios a 'suaineadh an luach a shònrachadh.
    ///
    ///
    /// Is e `unsafe` a h-uile ruigsinneachd air an luach a-staigh tro dhòighean-obrach.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Unwraps an luach.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// A `faighinn stiùireadh gluasadach chun luach fillte.
    ///
    /// Faodar seo a thilgeil gu stiùireadh de sheòrsa sam bith.
    /// Dèan cinnteach gu bheil an ruigsinneachd gun samhail (gun iomraidhean gnìomhach, gluasadach no nach eil) nuair a thilgeas tu gu `&mut T`, agus dèan cinnteach nach bi mùthaidhean no ailiasan gluasadach a `dol air adhart nuair a bhios iad a` tilgeadh gu `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Faodaidh sinn dìreach a `phuing a thilgeil bho `UnsafeCell<T>` gu `T` air sgàth #[repr(transparent)].
        // Bidh seo a `gabhail brath air inbhe sònraichte libstd, chan eil gealltanas sam bith ann airson còd neach-cleachdaidh gun obraich seo ann an dreachan future den inneal-cruinneachaidh!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// A `tilleadh iomradh gluasadach air an dàta bunaiteach.
    ///
    /// Tha an gairm seo a `faighinn iasad den `UnsafeCell` gu siùbhlach (aig àm cur ri chèile) a tha a` gealltainn gu bheil an aon iomradh againn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// A `faighinn stiùireadh gluasadach chun luach fillte.
    /// Is e an eadar-dhealachadh ri [`get`] gu bheil an gnìomh seo a `gabhail ri comharradh amh, a tha feumail gus cruthachadh iomraidhean sealach a sheachnadh.
    ///
    /// Faodar an toradh a thilgeil gu stiùireadh de sheòrsa sam bith.
    /// Dèan cinnteach gu bheil an ruigsinneachd gun samhail (gun iomraidhean gnìomhach, gluasadach no nach eil) nuair a thilgeas tu gu `&mut T`, agus dèan cinnteach nach eil mùthaidhean no ailiasan gluasadach a `dol air adhart nuair a bhios iad a` tilgeadh gu `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Feumaidh `UnsafeCell` a bhith a `tòiseachadh mean air mhean, oir dh` fheumadh gairm `get` iomradh a chruthachadh air dàta neo-aithnichte:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Faodaidh sinn dìreach a `phuing a thilgeil bho `UnsafeCell<T>` gu `T` air sgàth #[repr(transparent)].
        // Bidh seo a `gabhail brath air inbhe sònraichte libstd, chan eil gealltanas sam bith ann airson còd neach-cleachdaidh gun obraich seo ann an dreachan future den inneal-cruinneachaidh!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// A `cruthachadh `UnsafeCell`, le luach `Default` airson T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}