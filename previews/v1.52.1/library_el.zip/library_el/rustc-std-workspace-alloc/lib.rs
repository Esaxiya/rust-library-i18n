#![feature(no_core)]
#![no_core]

// Ανατρέξτε στο rustc-std-workpace-core για τον λόγο για τον οποίο απαιτείται αυτό το crate.

// Μετονομάστε το crate για να αποφύγετε τη διένεξη με τη μονάδα κατανομής στο liballoc.
extern crate alloc as foo;

pub use foo::*;