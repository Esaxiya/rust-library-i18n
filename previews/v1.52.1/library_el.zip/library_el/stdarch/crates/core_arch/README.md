`core::arch` - Η βασική αρχιτεκτονική του Rust βασίζεται στην αρχιτεκτονική
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Η μονάδα `core::arch` εφαρμόζει εγγενή εξαρτώμενα από την αρχιτεκτονική (π.χ. SIMD).

# Usage 

`core::arch` διατίθεται ως μέρος του `libcore` και επανεξάγεται από το `libstd`.Προτιμήστε τη χρήση μέσω `core::arch` ή `std::arch` παρά μέσω αυτού του crate.
Οι ασταθείς λειτουργίες είναι συχνά διαθέσιμες το βράδυ Rust μέσω του `feature(stdsimd)`.

Η χρήση του `core::arch` μέσω αυτού του crate απαιτεί το νυχτερινό Rust και μπορεί (και κάνει) να σπάει συχνά.Οι μόνες περιπτώσεις στις οποίες πρέπει να εξετάσετε τη χρήση μέσω αυτού του crate είναι:

* εάν πρέπει να μεταγλωττίσετε ξανά το `core::arch` μόνοι σας, π.χ. με συγκεκριμένες δυνατότητες-στόχους που δεν είναι ενεργοποιημένες για το `libcore`/`libstd`.
Note: Αν πρέπει να το μεταγλωττίσετε ξανά για έναν μη τυποποιημένο στόχο, προτιμήστε να χρησιμοποιήσετε το `xargo` και να μεταγλωττίσετε ξανά το `libcore`/`libstd` ανάλογα με την περίπτωση αντί να χρησιμοποιήσετε αυτό το crate.
  
* χρησιμοποιώντας ορισμένες δυνατότητες που ενδέχεται να μην είναι διαθέσιμες ακόμη και πίσω από ασταθείς λειτουργίες Rust.Προσπαθούμε να τα περιορίσουμε στο ελάχιστο.
Εάν πρέπει να χρησιμοποιήσετε ορισμένες από αυτές τις λειτουργίες, ανοίξτε ένα ζήτημα, ώστε να μπορούμε να τις εκθέσουμε σε νυχτερινό Rust και μπορείτε να τις χρησιμοποιήσετε από εκεί.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` διανέμεται κυρίως υπό τους όρους τόσο της άδειας MIT όσο και της άδειας Apache (Έκδοση 2.0), με τμήματα που καλύπτονται από διάφορες άδειες τύπου BSD.

Για λεπτομέρειες, ανατρέξτε στο LICENSE-APACHE και στο LICENSE-MIT.

# Contribution

Εκτός αν δηλώνετε ρητά κάτι διαφορετικό, οποιαδήποτε συνεισφορά που υποβάλλεται σκόπιμα για συμπερίληψη στο `core_arch` από εσάς, όπως ορίζεται στην άδεια Apache-2.0, θα έχει διπλή άδεια όπως παραπάνω, χωρίς πρόσθετους όρους ή προϋποθέσεις.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












