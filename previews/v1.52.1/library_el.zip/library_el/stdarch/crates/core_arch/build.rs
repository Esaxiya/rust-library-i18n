use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Χρησιμοποιήθηκε για να πει στους σχολιασμούς `#[assert_instr]` ότι όλα τα εγγενή simd είναι διαθέσιμα για τη δοκιμή του κωδικοποιητή τους, καθώς ορισμένα έχουν πίσω από ένα επιπλέον `-Ctarget-feature=+unimplemented-simd128` που δεν έχει κανένα ισοδύναμο στο `#[target_feature]` αυτή τη στιγμή.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}