//! Ένας τύπος δείκτη για κατανομή σωρού.
//!
//! [`Box<T>`], άνετα αναφέρεται ως 'box', παρέχει την απλούστερη μορφή κατανομής σωρού στο Rust.Τα Πλαίσια παρέχουν ιδιοκτησία για αυτήν την κατανομή και αποθέτουν το περιεχόμενό τους όταν είναι εκτός εμβέλειας.Τα κουτιά διασφαλίζουν επίσης ότι δεν εκχωρούν ποτέ περισσότερα από `isize::MAX` byte.
//!
//! # Examples
//!
//! Μετακινήστε μια τιμή από τη στοίβα στο σωρό δημιουργώντας ένα [`Box`]:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! Μετακινήστε μια τιμή από το [`Box`] πίσω στη στοίβα κατά [dereferencing]:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Δημιουργία αναδρομικής δομής δεδομένων:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Αυτό θα εκτυπώσει "Cons (1, Cons(2, Nil))`.
//!
//! Οι αναδρομικές δομές πρέπει να είναι συσκευασμένες, επειδή εάν ο ορισμός του `Cons` έμοιαζε με αυτόν τον τρόπο:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Δεν θα λειτουργούσε.Αυτό συμβαίνει επειδή το μέγεθος ενός `List` εξαρτάται από τον αριθμό των στοιχείων που περιλαμβάνονται στη λίστα και επομένως δεν γνωρίζουμε πόση μνήμη θα διαθέσει για ένα `Cons`.Παρουσιάζοντας ένα [`Box<T>`], το οποίο έχει καθορισμένο μέγεθος, γνωρίζουμε πόσο μεγάλο πρέπει να είναι το `Cons`.
//!
//! # Διάταξη μνήμης
//!
//! Για τιμές μη μηδενικού μεγέθους, ένα [`Box`] θα χρησιμοποιήσει το [`Global`] εκχωρητή για την κατανομή του.Είναι έγκυρο να μετατρέψετε και τους δύο τρόπους μεταξύ ενός [`Box`] και ενός ακατέργαστου δείκτη που έχει εκχωρηθεί με τον εκχωρητή [`Global`], δεδομένου ότι το [`Layout`] που χρησιμοποιείται με τον εκχωρητή είναι σωστό για τον τύπο.
//!
//! Πιο συγκεκριμένα, ένα `value:*mut T` που έχει εκχωρηθεί με τον [`Global`] εκχωρητή με `Layout::for_value(&* value)` μπορεί να μετατραπεί σε ένα κουτί χρησιμοποιώντας [`Box::<T>::from_raw(value)`].
//! Αντίθετα, η μνήμη που υποστηρίζει ένα `value:*mut T` που λαμβάνεται από το [`Box::<T>::into_raw`] μπορεί να αφαιρεθεί χρησιμοποιώντας τον εκχωρητή [`Global`] με [`Layout::for_value(&* value)`].
//!
//! Για τιμές μηδενικού μεγέθους, ο δείκτης `Box` πρέπει ακόμη να είναι [valid] για ανάγνωση και εγγραφή και επαρκή ευθυγράμμιση.
//! Συγκεκριμένα, η μετάδοση οποιουδήποτε ευθυγραμμισμένου μη μηδενικού ακέραιου κυριολεκτικού σε έναν ακατέργαστο δείκτη παράγει έναν έγκυρο δείκτη, αλλά ένας δείκτης που οδηγεί σε μνήμη που είχε εκχωρηθεί προηγουμένως που από τότε ελευθερώθηκε δεν είναι έγκυρη.
//! Ο προτεινόμενος τρόπος για να δημιουργήσετε ένα κουτί σε ένα ZST εάν το `Box::new` δεν μπορεί να χρησιμοποιηθεί είναι να χρησιμοποιήσετε το [`ptr::NonNull::dangling`].
//!
//! Εφόσον το `T: Sized`, ένα `Box<T>` είναι εγγυημένο ότι θα αντιπροσωπεύεται ως ένας δείκτης και είναι επίσης συμβατό με ABI με δείκτες C (δηλ. Τον τύπο C `T*`).
//! Αυτό σημαίνει ότι εάν έχετε εξωτερικές συναρτήσεις "C" Rust που θα κληθούν από το C, μπορείτε να ορίσετε αυτές τις συναρτήσεις Rust χρησιμοποιώντας τύπους `Box<T>` και να χρησιμοποιήσετε το `T*` ως αντίστοιχο τύπο στην πλευρά C.
//! Για παράδειγμα, σκεφτείτε αυτήν την κεφαλίδα C που δηλώνει συναρτήσεις που δημιουργούν και καταστρέφουν κάποιο είδος τιμής `Foo`:
//!
//! ```c
//! /* Κεφαλίδα Γ */
//!
//! /* Επιστρέφει την ιδιοκτησία στον καλούντα */
//! struct Foo* foo_new(void);
//!
//! /* Παίρνει ιδιοκτησία από τον καλούντα.no-op όταν καλείται με NULL */
//! void foo_delete(struct Foo*);
//! ```
//!
//! Αυτές οι δύο λειτουργίες ενδέχεται να εφαρμοστούν στο Rust ως εξής.Εδώ, ο τύπος `struct Foo*` από το C μεταφράζεται σε `Box<Foo>`, το οποίο καταγράφει τους περιορισμούς ιδιοκτησίας.
//! Σημειώστε επίσης ότι το μηδενικό όρισμα στο `foo_delete` αντιπροσωπεύεται στο Rust ως `Option<Box<Foo>>`, καθώς το `Box<Foo>` δεν μπορεί να είναι μηδενικό.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! Παρόλο που το `Box<T>` έχει την ίδια αναπαράσταση και το C ABI με το δείκτη C, αυτό δεν σημαίνει ότι μπορείτε να μετατρέψετε ένα αυθαίρετο `T*` σε `Box<T>` και να περιμένετε να λειτουργήσουν.
//! `Box<T>` οι τιμές θα είναι πάντα πλήρως ευθυγραμμισμένες, μη μηδενικοί δείκτες.Επιπλέον, ο καταστροφέας για το `Box<T>` θα προσπαθήσει να απελευθερώσει την τιμή με τον καθολικό κατανεμητή.Σε γενικές γραμμές, η βέλτιστη πρακτική είναι να χρησιμοποιείτε μόνο το `Box<T>` για δείκτες που προέρχονται από τον παγκόσμιο κατανεμητή.
//!
//! **Σημαντικό.** Τουλάχιστον επί του παρόντος, πρέπει να αποφύγετε τη χρήση τύπων `Box<T>` για συναρτήσεις που ορίζονται στο C αλλά επικαλούνται από το Rust.Σε αυτές τις περιπτώσεις, θα πρέπει να αντικατοπτρίζετε άμεσα τους τύπους C όσο το δυνατόν πιο κοντά.
//! Η χρήση τύπων όπως το `Box<T>` όπου ο ορισμός C χρησιμοποιεί μόνο το `T*` μπορεί να οδηγήσει σε απροσδιόριστη συμπεριφορά, όπως περιγράφεται στο [rust-lang/unsafe-code-guidelines#198][ucg#198].
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Ένας τύπος δείκτη για κατανομή σωρού.
///
/// Δείτε το [module-level documentation](../../std/boxed/index.html) για περισσότερα.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Διαθέτει μνήμη στο σωρό και στη συνέχεια τοποθετεί το `x` σε αυτό.
    ///
    /// Αυτό δεν κατανέμεται στην πραγματικότητα εάν το `T` είναι μηδενικού μεγέθους.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// Δημιουργεί ένα νέο πλαίσιο με μη αρχικοποιημένο περιεχόμενο.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Αναβαλλόμενη προετοιμασία:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// Κατασκευάζει ένα νέο `Box` με μη αρχικοποιημένα περιεχόμενα, με τη μνήμη να γεμίζει με `0` byte.
    ///
    ///
    /// Ανατρέξτε στο [`MaybeUninit::zeroed`][zeroed] για παραδείγματα σωστής και εσφαλμένης χρήσης αυτής της μεθόδου.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// Κατασκευάζει ένα νέο `Pin<Box<T>>`.
    /// Εάν το `T` δεν εφαρμόζει το `Unpin`, τότε το `x` θα καρφιτσωθεί στη μνήμη και δεν θα μπορεί να μετακινηθεί.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Εκχωρεί μνήμη στο σωρό και στη συνέχεια τοποθετεί το `x` σε αυτό, επιστρέφοντας ένα σφάλμα εάν η κατανομή αποτύχει
    ///
    ///
    /// Αυτό δεν κατανέμεται στην πραγματικότητα εάν το `T` είναι μηδενικού μεγέθους.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Δημιουργεί ένα νέο πλαίσιο με μη αρχικοποιημένα περιεχόμενα στο σωρό, επιστρέφοντας ένα σφάλμα εάν η κατανομή αποτύχει
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Αναβαλλόμενη προετοιμασία:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Κατασκευάζει ένα νέο `Box` με μη αρχικοποιημένα περιεχόμενα, με τη μνήμη να γεμίζει με `0` bytes στο σωρό
    ///
    ///
    /// Ανατρέξτε στο [`MaybeUninit::zeroed`][zeroed] για παραδείγματα σωστής και εσφαλμένης χρήσης αυτής της μεθόδου.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Διανέμει μνήμη στον δεδομένο εκχωρητή και στη συνέχεια τοποθετεί το `x` σε αυτό.
    ///
    /// Αυτό δεν κατανέμεται στην πραγματικότητα εάν το `T` είναι μηδενικού μεγέθους.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// Εκχωρεί μνήμη στον δεδομένο εκχωρητή και στη συνέχεια τοποθετεί το `x` σε αυτό, επιστρέφοντας ένα σφάλμα εάν η κατανομή αποτύχει
    ///
    ///
    /// Αυτό δεν κατανέμεται στην πραγματικότητα εάν το `T` είναι μηδενικού μεγέθους.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// Δημιουργεί ένα νέο κουτί με μη αρχικοποιημένο περιεχόμενο στον παρεχόμενο κατανεμητή.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Αναβαλλόμενη προετοιμασία:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Προτιμήστε τον αγώνα από το unrap_or_else, καθώς το κλείσιμο μερικές φορές δεν είναι γραμμένο.
        // Αυτό θα έκανε το μέγεθος του κώδικα μεγαλύτερο.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Κατασκευάζει ένα νέο πλαίσιο με μη αρχικοποιημένα περιεχόμενα στον παρεχόμενο εκχωρητή, επιστρέφοντας ένα σφάλμα εάν η κατανομή αποτύχει
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Αναβαλλόμενη προετοιμασία:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Κατασκευάζει ένα νέο `Box` με μη αρχικοποιημένα περιεχόμενα, με τη μνήμη να γεμίζει με `0` bytes στο παρεχόμενο κατανεμητή.
    ///
    ///
    /// Ανατρέξτε στο [`MaybeUninit::zeroed`][zeroed] για παραδείγματα σωστής και εσφαλμένης χρήσης αυτής της μεθόδου.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Προτιμήστε τον αγώνα από το unrap_or_else, καθώς το κλείσιμο μερικές φορές δεν είναι γραμμένο.
        // Αυτό θα έκανε το μέγεθος του κώδικα μεγαλύτερο.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Κατασκευάζει ένα νέο `Box` με μη αρχικοποιημένα περιεχόμενα, με τη μνήμη να γεμίζει με `0` bytes στο παρεχόμενο κατανεμητή, επιστρέφοντας ένα σφάλμα εάν η κατανομή αποτύχει,
    ///
    ///
    /// Ανατρέξτε στο [`MaybeUninit::zeroed`][zeroed] για παραδείγματα σωστής και εσφαλμένης χρήσης αυτής της μεθόδου.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Κατασκευάζει ένα νέο `Pin<Box<T, A>>`.
    /// Εάν το `T` δεν εφαρμόζει το `Unpin`, τότε το `x` θα καρφιτσωθεί στη μνήμη και δεν θα μπορεί να μετακινηθεί.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// Μετατρέπει ένα `Box<T>` σε `Box<[T]>`
    ///
    /// Αυτή η μετατροπή δεν κατανέμεται στο σωρό και συμβαίνει στη θέση του.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// Καταναλώνει το `Box`, επιστρέφοντας την τυλιγμένη τιμή.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// Κατασκευάζει μια νέα φέτα σε κουτί με μη αρχικοποιημένο περιεχόμενο.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Αναβαλλόμενη προετοιμασία:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Κατασκευάζει μια νέα φέτα σε κουτί με μη αρχικοποιημένα περιεχόμενα, με τη μνήμη να γεμίζει με `0` byte.
    ///
    ///
    /// Ανατρέξτε στο [`MaybeUninit::zeroed`][zeroed] για παραδείγματα σωστής και εσφαλμένης χρήσης αυτής της μεθόδου.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Κατασκευάζει μια νέα φέτα σε κουτί με μη αρχικοποιημένα περιεχόμενα στο παρεχόμενο κατανεμητή.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Αναβαλλόμενη προετοιμασία:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Κατασκευάζει μια νέα φέτα σε κουτί με μη αρχικοποιημένα περιεχόμενα στο παρεχόμενο κατανεμητή, με τη μνήμη να γεμίζει με `0` byte.
    ///
    ///
    /// Ανατρέξτε στο [`MaybeUninit::zeroed`][zeroed] για παραδείγματα σωστής και εσφαλμένης χρήσης αυτής της μεθόδου.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// Μετατρέπει σε `Box<T, A>`.
    ///
    /// # Safety
    ///
    /// Όπως και με το [`MaybeUninit::assume_init`], εναπόκειται στον καλούντα να εγγυηθεί ότι η τιμή είναι πραγματικά σε αρχικοποιημένη κατάσταση.
    ///
    /// Το να το καλέσετε αυτό όταν το περιεχόμενο δεν έχει ακόμη αρχικοποιηθεί πλήρως προκαλεί άμεση απροσδιόριστη συμπεριφορά.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Αναβαλλόμενη προετοιμασία:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// Μετατρέπει σε `Box<[T], A>`.
    ///
    /// # Safety
    ///
    /// Όπως και με το [`MaybeUninit::assume_init`], εναπόκειται στον καλούντα να εγγυηθεί ότι οι τιμές είναι πραγματικά σε αρχικοποιημένη κατάσταση.
    ///
    /// Το να το καλέσετε αυτό όταν το περιεχόμενο δεν έχει ακόμη αρχικοποιηθεί πλήρως προκαλεί άμεση απροσδιόριστη συμπεριφορά.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Αναβαλλόμενη προετοιμασία:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Κατασκευάζει ένα κουτί από έναν ακατέργαστο δείκτη.
    ///
    /// Αφού καλέσετε αυτήν τη λειτουργία, ο αρχικός δείκτης ανήκει στο `Box` που προκύπτει.
    /// Συγκεκριμένα, ο καταστροφέας `Box` θα καλέσει τον καταστροφέα του `T` και θα ελευθερώσει την εκχωρημένη μνήμη.
    /// Για να είναι ασφαλές, η μνήμη πρέπει να έχει εκχωρηθεί σύμφωνα με το [memory layout] που χρησιμοποιείται από το `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Αυτή η λειτουργία δεν είναι ασφαλής επειδή η ακατάλληλη χρήση μπορεί να οδηγήσει σε προβλήματα μνήμης.
    /// Για παράδειγμα, ένα διπλό ελεύθερο μπορεί να προκύψει εάν η συνάρτηση καλείται δύο φορές στον ίδιο ακατέργαστο δείκτη.
    ///
    /// Οι συνθήκες ασφαλείας περιγράφονται στην ενότητα [memory layout].
    ///
    /// # Examples
    ///
    /// Δημιουργήστε ξανά ένα `Box` που είχε προηγουμένως μετατραπεί σε ακατέργαστο δείκτη χρησιμοποιώντας [`Box::into_raw`]:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Δημιουργήστε μη αυτόματα ένα `Box` από το μηδέν χρησιμοποιώντας τον καθολικό εκχωρητή:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // Γενικά το .write απαιτείται για να αποφευχθεί η καταστροφή των προηγούμενων περιεχομένων του (uninitialized) του `ptr`, αν και για αυτό το απλό παράδειγμα το `*ptr = 5` θα είχε λειτουργήσει επίσης.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Κατασκευάζει ένα κουτί από έναν ακατέργαστο δείκτη στον δεδομένο κατανεμητή.
    ///
    /// Αφού καλέσετε αυτήν τη λειτουργία, ο αρχικός δείκτης ανήκει στο `Box` που προκύπτει.
    /// Συγκεκριμένα, ο καταστροφέας `Box` θα καλέσει τον καταστροφέα του `T` και θα ελευθερώσει την εκχωρημένη μνήμη.
    /// Για να είναι ασφαλές, η μνήμη πρέπει να έχει εκχωρηθεί σύμφωνα με το [memory layout] που χρησιμοποιείται από το `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Αυτή η λειτουργία δεν είναι ασφαλής επειδή η ακατάλληλη χρήση μπορεί να οδηγήσει σε προβλήματα μνήμης.
    /// Για παράδειγμα, ένα διπλό ελεύθερο μπορεί να προκύψει εάν η συνάρτηση καλείται δύο φορές στον ίδιο ακατέργαστο δείκτη.
    ///
    /// # Examples
    ///
    /// Δημιουργήστε ξανά ένα `Box` που είχε προηγουμένως μετατραπεί σε ακατέργαστο δείκτη χρησιμοποιώντας [`Box::into_raw_with_allocator`]:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Δημιουργήστε χειροκίνητα ένα `Box` από το μηδέν χρησιμοποιώντας τον εκχωρητή συστήματος:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // Γενικά το .write απαιτείται για να αποφευχθεί η καταστροφή των προηγούμενων περιεχομένων του (uninitialized) του `ptr`, αν και για αυτό το απλό παράδειγμα το `*ptr = 5` θα είχε λειτουργήσει επίσης.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// Καταναλώνει το `Box`, επιστρέφοντας έναν τυλιγμένο ακατέργαστο δείκτη.
    ///
    /// Ο δείκτης θα είναι σωστά ευθυγραμμισμένος και μηδενικός.
    ///
    /// Μετά την κλήση αυτής της λειτουργίας, ο καλών είναι υπεύθυνος για τη μνήμη που προηγουμένως διαχειριζόταν το `Box`.
    /// Συγκεκριμένα, ο καλών θα πρέπει να καταστρέψει σωστά το `T` και να απελευθερώσει τη μνήμη, λαμβάνοντας υπόψη το [memory layout] που χρησιμοποιείται από το `Box`.
    /// Ο ευκολότερος τρόπος για να γίνει αυτό είναι να μετατρέψετε τον ακατέργαστο δείκτη σε `Box` με τη λειτουργία [`Box::from_raw`], επιτρέποντας στον καταστροφέα `Box` να εκτελέσει τον καθαρισμό.
    ///
    ///
    /// Note: Αυτή είναι μια συσχετισμένη συνάρτηση, που σημαίνει ότι πρέπει να την ονομάσετε `Box::into_raw(b)` αντί για `b.into_raw()`.
    /// Αυτό συμβαίνει ώστε να μην υπάρχει σύγκρουση με μια μέθοδο στον εσωτερικό τύπο.
    ///
    /// # Examples
    /// Μετατροπή του ακατέργαστου δείκτη σε `Box` με [`Box::from_raw`] για αυτόματο καθαρισμό:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Μη αυτόματη εκκαθάριση εκτελώντας ρητά τον καταστροφέα και αφαιρώντας τη μνήμη:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// Καταναλώνει το `Box`, επιστρέφοντας έναν τυλιγμένο ακατέργαστο δείκτη και τον εκχωρητή.
    ///
    /// Ο δείκτης θα είναι σωστά ευθυγραμμισμένος και μηδενικός.
    ///
    /// Μετά την κλήση αυτής της λειτουργίας, ο καλών είναι υπεύθυνος για τη μνήμη που προηγουμένως διαχειριζόταν το `Box`.
    /// Συγκεκριμένα, ο καλών θα πρέπει να καταστρέψει σωστά το `T` και να απελευθερώσει τη μνήμη, λαμβάνοντας υπόψη το [memory layout] που χρησιμοποιείται από το `Box`.
    /// Ο ευκολότερος τρόπος για να γίνει αυτό είναι να μετατρέψετε τον ακατέργαστο δείκτη σε `Box` με τη λειτουργία [`Box::from_raw_in`], επιτρέποντας στον καταστροφέα `Box` να εκτελέσει τον καθαρισμό.
    ///
    ///
    /// Note: Αυτή είναι μια συσχετισμένη συνάρτηση, που σημαίνει ότι πρέπει να την ονομάσετε `Box::into_raw_with_allocator(b)` αντί για `b.into_raw_with_allocator()`.
    /// Αυτό συμβαίνει ώστε να μην υπάρχει σύγκρουση με μια μέθοδο στον εσωτερικό τύπο.
    ///
    /// # Examples
    /// Μετατροπή του ακατέργαστου δείκτη σε `Box` με [`Box::from_raw_in`] για αυτόματο καθαρισμό:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Μη αυτόματη εκκαθάριση εκτελώντας ρητά τον καταστροφέα και αφαιρώντας τη μνήμη:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Το Box αναγνωρίζεται ως "unique pointer" από το Stacked Borrows, αλλά εσωτερικά είναι ένας πρώτος δείκτης για το σύστημα τύπου.
        // Η άμεση μετατροπή του σε ακατέργαστο δείκτη δεν θα αναγνωριζόταν ως "releasing" ο μοναδικός δείκτης που επιτρέπει ψευδώνυμες πρώτες προσβάσεις, οπότε όλες οι μέθοδοι πρώτου δείκτη πρέπει να περάσουν από το `Box::leak`.
        //
        // Η μετατροπή *that* σε ακατέργαστο δείκτη συμπεριφέρεται σωστά.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// Επιστρέφει μια αναφορά στον υποκείμενο εκχωρητή.
    ///
    /// Note: Αυτή είναι μια συσχετισμένη συνάρτηση, που σημαίνει ότι πρέπει να την ονομάσετε `Box::allocator(&b)` αντί για `b.allocator()`.
    /// Αυτό συμβαίνει ώστε να μην υπάρχει σύγκρουση με μια μέθοδο στον εσωτερικό τύπο.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// Καταναλώνει και διαρρέει το `Box`, επιστρέφοντας μια μεταβλητή αναφορά, `&'a mut T`.
    /// Λάβετε υπόψη ότι ο τύπος `T` πρέπει να ξεπεράσει τον επιλεγμένο χρόνο ζωής `'a`.
    /// Εάν ο τύπος έχει μόνο στατικές αναφορές ή καθόλου, τότε αυτό μπορεί να επιλεγεί ως `'static`.
    ///
    /// Αυτή η λειτουργία είναι κυρίως χρήσιμη για δεδομένα που ζουν για το υπόλοιπο της διάρκειας ζωής του προγράμματος.
    /// Η απόρριψη της επιστρεφόμενης αναφοράς θα προκαλέσει διαρροή μνήμης.
    /// Εάν αυτό δεν είναι αποδεκτό, η αναφορά πρέπει πρώτα να τυλιχτεί με τη συνάρτηση [`Box::from_raw`] που παράγει `Box`.
    ///
    /// Αυτό το `Box` μπορεί στη συνέχεια να πέσει, το οποίο θα καταστρέψει σωστά το `T` και θα απελευθερώσει την εκχωρημένη μνήμη.
    ///
    /// Note: Αυτή είναι μια συσχετισμένη συνάρτηση, που σημαίνει ότι πρέπει να την ονομάσετε `Box::leak(b)` αντί για `b.leak()`.
    /// Αυτό συμβαίνει ώστε να μην υπάρχει σύγκρουση με μια μέθοδο στον εσωτερικό τύπο.
    ///
    /// # Examples
    ///
    /// Απλή χρήση:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Αμεγέθη δεδομένα:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// Μετατρέπει ένα `Box<T>` σε `Pin<Box<T>>`
    ///
    /// Αυτή η μετατροπή δεν κατανέμεται στο σωρό και συμβαίνει στη θέση του.
    ///
    /// Αυτό είναι επίσης διαθέσιμο μέσω [`From`].
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // Δεν είναι δυνατή η μετακίνηση ή η αντικατάσταση των εσωτερικών χώρων ενός `Pin<Box<T>>` όταν το `T: !Unpin`, επομένως είναι ασφαλές να το καρφιτσώσετε απευθείας χωρίς πρόσθετες απαιτήσεις.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Μην κάνετε τίποτα, η πτώση εκτελείται αυτήν τη στιγμή από τον μεταγλωττιστή.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// Δημιουργεί ένα `Box<T>`, με την τιμή `Default` για T.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Επιστρέφει ένα νέο πλαίσιο με `clone()` του περιεχομένου αυτού του κουτιού.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // Η τιμή είναι η ίδια
    /// assert_eq!(x, y);
    ///
    /// // Αλλά είναι μοναδικά αντικείμενα
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Προ-εκχωρήστε μνήμη για να επιτρέψετε τη γραφή της κλωνοποιημένης τιμής απευθείας.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// Αντιγράφει τα περιεχόμενα της πηγής στο `self` χωρίς να δημιουργεί νέα κατανομή.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // Η τιμή είναι η ίδια
    /// assert_eq!(x, y);
    ///
    /// // Και δεν έγινε κατανομή
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // Αυτό δημιουργεί ένα αντίγραφο των δεδομένων
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// Μετατρέπει έναν γενικό τύπο `T` σε `Box<T>`
    ///
    /// Η μετατροπή κατανέμεται στο σωρό και μετακινεί το `t` από τη στοίβα σε αυτό.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// Μετατρέπει ένα `Box<T>` σε `Pin<Box<T>>`
    ///
    /// Αυτή η μετατροπή δεν κατανέμεται στο σωρό και συμβαίνει στη θέση του.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// Μετατρέπει ένα `&[T]` σε `Box<[T]>`
    ///
    /// Αυτή η μετατροπή κατανέμεται στο σωρό και εκτελεί ένα αντίγραφο του `slice`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // δημιουργήστε ένα&[u8] το οποίο θα χρησιμοποιηθεί για τη δημιουργία ενός πλαισίου <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// Μετατρέπει ένα `&str` σε `Box<str>`
    ///
    /// Αυτή η μετατροπή κατανέμεται στο σωρό και εκτελεί ένα αντίγραφο του `s`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// Μετατρέπει ένα `Box<str>` σε `Box<[u8]>`
    /// Αυτή η μετατροπή δεν κατανέμεται στο σωρό και συμβαίνει στη θέση του.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // δημιουργήστε ένα κουτί<str>το οποίο θα χρησιμοποιηθεί για τη δημιουργία ενός πλαισίου <[u8]>
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // δημιουργήστε ένα&[u8] το οποίο θα χρησιμοποιηθεί για τη δημιουργία ενός πλαισίου <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// Μετατρέπει ένα `[T; N]` σε `Box<[T]>`
    /// Αυτή η μετατροπή μετακινεί τον πίνακα στη μνήμη που έχει εκχωρηθεί πρόσφατα.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Προσπαθήστε να κατεβείτε το πλαίσιο σε συγκεκριμένο τύπο.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Προσπαθήστε να κατεβείτε το πλαίσιο σε συγκεκριμένο τύπο.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Προσπαθήστε να κατεβείτε το πλαίσιο σε συγκεκριμένο τύπο.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Δεν είναι δυνατό να εξαγάγετε το εσωτερικό Uniq απευθείας από το κουτί, αντί να το ρίξουμε σε * const που ψευδώνει το Unique
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Εξειδίκευση για μέγεθος "I" που χρησιμοποιεί την εφαρμογή "I" του `last()` αντί για την προεπιλογή.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}