//! # Η βιβλιοθήκη κατανομής και συλλογών πυρήνα Rust
//!
//! Αυτή η βιβλιοθήκη παρέχει έξυπνους δείκτες και συλλογές για τη διαχείριση των τιμών που κατανέμονται σωρού.
//!
//! Αυτή η βιβλιοθήκη, όπως το libcore, κανονικά δεν χρειάζεται να χρησιμοποιηθεί απευθείας, καθώς τα περιεχόμενά της επανεξάγονται στο [`std` crate](../std/index.html).
//! Τα Crates που χρησιμοποιούν το χαρακτηριστικό `#![no_std]`, ωστόσο, συνήθως δεν θα εξαρτώνται από το `std`, επομένως θα χρησιμοποιούσαν αυτό το crate.
//!
//! ## Τιμές σε κουτί
//!
//! Ο τύπος [`Box`] είναι ένας τύπος έξυπνου δείκτη.Μπορεί να υπάρχει μόνο ένας κάτοχος ενός [`Box`] και ο κάτοχος μπορεί να αποφασίσει να μεταλλάξει τα περιεχόμενα, τα οποία ζουν στο σωρό.
//!
//! Αυτός ο τύπος μπορεί να σταλεί μεταξύ των νημάτων αποτελεσματικά, καθώς το μέγεθος μιας τιμής `Box` είναι το ίδιο με αυτό ενός δείκτη.
//! Οι δομές δεδομένων που μοιάζουν με δέντρο δεν δημιουργούνται συχνά με κουτιά, επειδή κάθε κόμβος έχει συχνά μόνο έναν ιδιοκτήτη, τον γονέα.
//!
//! ## Οι μετρημένοι δείκτες αναφοράς
//!
//! Ο τύπος [`Rc`] είναι ένας τύπος δείκτη που δεν είναι ασφαλής στο νήμα και προορίζεται για κοινή χρήση μνήμης σε ένα νήμα.
//! Ένας δείκτης [`Rc`] τυλίγει έναν τύπο, `T` και επιτρέπει μόνο πρόσβαση στο `&T`, μια κοινή αναφορά.
//!
//! Αυτός ο τύπος είναι χρήσιμος όταν η κληρονομική μεταβλητότητα (όπως η χρήση [`Box`]) είναι πολύ περιοριστική για μια εφαρμογή και συχνά συνδυάζεται με τους τύπους [`Cell`] ή [`RefCell`] για να επιτρέπεται η μετάλλαξη.
//!
//!
//! ## Ατομικά μετρημένοι δείκτες αναφοράς
//!
//! Ο τύπος [`Arc`] είναι το ισοδύναμο νήματος τύπου [`Rc`].Παρέχει όλες τις ίδιες λειτουργίες του [`Rc`], εκτός από το ότι απαιτεί τον κοινόχρηστο τύπο `T` να είναι κοινόχρηστο.
//! Επιπλέον, το ίδιο το [`Arc<T>`][`Arc`] μπορεί να αποσταλεί ενώ το [`Rc<T>`][`Rc`] δεν είναι.
//!
//! Αυτός ο τύπος επιτρέπει κοινόχρηστη πρόσβαση στα περιεχόμενα δεδομένα και συχνά συνδυάζεται με πρωτόγονα συγχρονισμού, όπως τα mutexes για να επιτρέπεται η μετάλλαξη των κοινόχρηστων πόρων.
//!
//! ## Collections
//!
//! Οι υλοποιήσεις των πιο κοινών δομών δεδομένων γενικού σκοπού ορίζονται σε αυτήν τη βιβλιοθήκη.Εξάγονται εκ νέου μέσω του [standard collections library](../std/collections/index.html).
//!
//! ## Διεπαφές σωρού
//!
//! Η μονάδα [`alloc`](alloc/index.html) καθορίζει τη διεπαφή χαμηλού επιπέδου με τον προεπιλεγμένο καθολικό εκχωρητή.Δεν είναι συμβατό με το API διανομής libc.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// Τεχνικά, αυτό είναι ένα σφάλμα στο rustdoc: το rustdoc βλέπει την τεκμηρίωση στα μπλοκ `#[lang = slice_alloc]` είναι για το `&[T]`, το οποίο έχει επίσης τεκμηρίωση που χρησιμοποιεί αυτήν τη δυνατότητα στο `core` και θυμώνει ότι η πύλη χαρακτηριστικών δεν είναι ενεργοποιημένη.
// Στην ιδανική περίπτωση, δεν θα έλεγχε την πύλη χαρακτηριστικών για έγγραφα από άλλα crates, αλλά επειδή αυτό μπορεί να εμφανιστεί μόνο για είδη lang, δεν φαίνεται να αξίζει τον κόπο.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// Να επιτρέπεται η δοκιμή αυτής της βιβλιοθήκης

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Ενότητα με εσωτερικές μακροεντολές που χρησιμοποιούνται από άλλες ενότητες (πρέπει να συμπεριληφθεί πριν από άλλες ενότητες).
#[macro_use]
mod macros;

// Σωροί που παρέχονται για στρατηγικές κατανομής χαμηλού επιπέδου

pub mod alloc;

// Πρωτόγονοι τύποι με τους παραπάνω σωρούς

// Πρέπει να ορίσετε υπό όρους το mod από το `boxed.rs` για να αποφύγετε την αναπαραγωγή των lang-item κατά τη δημιουργία δοκιμής cfg.αλλά πρέπει επίσης να επιτρέπεται στον κώδικα να έχει δηλώσεις `use boxed::Box;`.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}