use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Η σύνταξη μιας δοκιμασίας ενοποίησης μεταξύ των εκχωρητών τρίτων μερών και του `RawVec` είναι λίγο περίπλοκη, επειδή το `RawVec` API δεν εκθέτει ελαττωματικές μεθόδους κατανομής, οπότε δεν μπορούμε να ελέγξουμε τι συμβαίνει όταν εξαντληθεί ο εκχωρητής (πέρα από τον εντοπισμό ενός panic)
    //
    //
    // Αντ 'αυτού, ελέγχει απλώς ότι οι μέθοδοι `RawVec` περνούν τουλάχιστον μέσω του API Allocator όταν διατηρεί χώρο αποθήκευσης.
    //
    //
    //
    //
    //

    // Ένας χαζός κατανεμητής που καταναλώνει μια σταθερή ποσότητα καυσίμου πριν αρχίσουν να αποτυγχάνουν οι προσπάθειες κατανομής.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (προκαλεί ένα realloc, χρησιμοποιώντας 50 + 150=200 μονάδες καυσίμου)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Πρώτον, το `reserve` διαθέτει όπως το `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // Το 97 είναι περισσότερο από το διπλάσιο του 7, οπότε το `reserve` πρέπει να λειτουργεί όπως το `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // Το 3 είναι λιγότερο από το ήμισυ των 12, οπότε το `reserve` πρέπει να αυξηθεί εκθετικά.
        // Κατά τη στιγμή της σύνταξης αυτού του τεστ, ο παράγοντας αύξησης είναι 2, οπότε η νέα χωρητικότητα είναι 24, ωστόσο, ο παράγοντας αύξησης του 1.5 είναι επίσης ΟΚ.
        //
        // Εξ ου και το `>= 18` ισχυρίζεται.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}