use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Δείκτης εξειδίκευσης για τη συλλογή ενός επαναληπτικού αγωγού σε ένα Vec ενώ επαναχρησιμοποιεί την κατανομή πηγής, δηλαδή
/// εκτέλεση του αγωγού στη θέση του.
///
/// Το γονικό SourceIter trait είναι απαραίτητο για τη λειτουργία εξειδίκευσης για πρόσβαση στην κατανομή που πρόκειται να επαναχρησιμοποιηθεί.
/// Δεν αρκεί όμως να είναι έγκυρη η εξειδίκευση.
/// Δείτε επιπλέον όρια στο εμφύτευμα.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Το εσωτερικό std SourceIter/InPlaceIterable traits υλοποιείται μόνο από αλυσίδες προσαρμογέα <Adapter<Adapter<IntoIter>>> (όλα ανήκουν στο core/std).
// Τα πρόσθετα όρια στις εφαρμογές προσαρμογέα (πέραν του `impl<I: Trait> Trait for Adapter<I>`) εξαρτώνται μόνο από άλλα traits που έχουν ήδη επισημανθεί ως εξειδίκευση traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. ο δείκτης δεν εξαρτάται από τη διάρκεια ζωής των τύπων που παρέχονται από τον χρήστη.Modulo η τρύπα αντιγραφής, από την οποία εξαρτώνται ήδη πολλές άλλες ειδικότητες.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Πρόσθετες απαιτήσεις που δεν μπορούν να εκφραστούν μέσω trait bounds.Στηριζόμαστε στο const eval αντί:
        // α) χωρίς ZSTs καθώς δεν θα υπάρχει κατανομή για επαναχρησιμοποίηση και η αριθμητική δείκτη θα panic β) αντιστοιχεί στο μέγεθος όπως απαιτείται από τη σύμβαση Alloc γ) οι ευθυγραμμίσεις ταιριάζουν όπως απαιτείται από τη σύμβαση Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // εναλλακτική εφαρμογή σε πιο γενικές εφαρμογές
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // χρησιμοποιήστε το try-fold από τότε
        // - διανέμεται καλύτερα για ορισμένους προσαρμογείς επαναλήψεων
        // - Σε αντίθεση με τις περισσότερες εσωτερικές μεθόδους επανάληψης, παίρνει μόνο έναν &mut εαυτό
        // - μας αφήνει να περάσουμε τον δείκτη γραφής μέσα από τα σπλάχνα του και να τον επαναφέρουμε στο τέλος
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // η επανάληψη πέτυχε, μην πέσετε
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // Ελέγξτε αν η σύμβαση SourceIter τηρήθηκε προειδοποίηση: αν δεν ήταν, ίσως να μην φτάσουμε σε αυτό το σημείο
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // ελέγξτε το συμβόλαιο InPlaceIterable.Αυτό είναι δυνατό μόνο εάν ο επαναληπτής προωθήσει καθόλου τον δείκτη προέλευσης.
        // Εάν χρησιμοποιεί μη ελεγμένη πρόσβαση μέσω TrustedRandomAccess τότε ο δείκτης προέλευσης θα παραμείνει στην αρχική του θέση και δεν μπορούμε να τον χρησιμοποιήσουμε ως αναφορά
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // ρίξτε τις υπόλοιπες τιμές στην ουρά της πηγής, αλλά αποτρέψτε την πτώση της ίδιας της κατανομής μόλις το IntoIter βγει εκτός εμβέλειας, εάν η πτώση panics τότε διαρρέουμε επίσης τυχόν στοιχεία που συλλέγονται στο dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // το συμβόλαιο InPlaceIterable δεν μπορεί να επαληθευτεί με ακρίβεια εδώ, αφού το try_fold έχει αποκλειστική αναφορά στον δείκτη προέλευσης, το μόνο που μπορούμε να κάνουμε είναι να ελέγξουμε αν εξακολουθεί να βρίσκεται εντός εμβέλειας
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}