use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Ένας επαναληπτής που χρησιμοποιεί ένα κλείσιμο για να προσδιορίσει εάν ένα στοιχείο πρέπει να αφαιρεθεί.
///
/// Αυτή η δομή δημιουργήθηκε από το [`Vec::drain_filter`].
/// Δείτε την τεκμηρίωσή του για περισσότερα.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Το ευρετήριο του αντικειμένου που θα ελεγχθεί από την επόμενη κλήση στο `next`.
    pub(super) idx: usize,
    /// Ο αριθμός των αντικειμένων που έχουν αποστραγγιστεί μέχρι τώρα (removed).
    pub(super) del: usize,
    /// Το αρχικό μήκος `vec` πριν από την αποστράγγιση.
    pub(super) old_len: usize,
    /// Το υπόθετο δοκιμής φίλτρου.
    pub(super) pred: F,
    /// Μια σημαία που υποδηλώνει panic έχει προκύψει στη δοκιμαστική δοκιμασία.
    /// Αυτό χρησιμοποιείται ως υπόδειξη στην εφαρμογή drop για να αποφευχθεί η κατανάλωση του υπόλοιπου `DrainFilter`.
    /// Τυχόν μη επεξεργασμένα αντικείμενα θα μετατοπιστούν στο `vec`, αλλά κανένα άλλο στοιχείο δεν θα πέσει ή θα δοκιμαστεί από το βασικό φίλτρο.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Επιστρέφει μια αναφορά στον υποκείμενο εκχωρητή.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Ενημερώστε το ευρετήριο *μετά από* καλείται το κατηγορηματικό.
                // Εάν το ευρετήριο έχει ενημερωθεί προηγουμένως και το βασικό panics, το στοιχείο σε αυτό το ευρετήριο θα διαρρεύσει.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Αυτή είναι μια κατάσταση πολύ χαλάρωσης και δεν υπάρχει πραγματικά ένα προφανώς σωστό πράγμα να κάνουμε.
                        // Δεν θέλουμε να συνεχίσουμε να προσπαθούμε να εκτελέσουμε το `pred`, οπότε απλώς μετατοπίζουμε όλα τα μη επεξεργασμένα στοιχεία και λέμε στο vec ότι εξακολουθούν να υπάρχουν.
                        //
                        // Το backshift απαιτείται για να αποφευχθεί μια διπλή πτώση του τελευταίου επιτυχώς στραγγιζόμενου αντικειμένου πριν από το panic στο predicate.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Προσπαθήστε να καταναλώσετε τυχόν εναπομείναντα στοιχεία, εάν το υπόθεμα φίλτρου δεν έχει ακόμη πανικοβληθεί.
        // Θα αλλάξουμε τα υπόλοιπα στοιχεία είτε έχουμε ήδη πανικοβληθεί είτε αν η κατανάλωση εδώ panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}