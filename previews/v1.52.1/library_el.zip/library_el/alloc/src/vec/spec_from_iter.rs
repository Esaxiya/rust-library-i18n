use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Ειδίκευση trait που χρησιμοποιείται για Vec::from_iter
///
/// ## Το γράφημα αντιπροσωπείας:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Μια κοινή περίπτωση περνά ένα vector σε μια συνάρτηση που συλλέγει αμέσως σε vector.
        // Μπορούμε να βραχυκυκλώσουμε αυτό εάν το IntoIter δεν έχει προχωρήσει καθόλου.
        // Όταν έχει προχωρήσει, μπορούμε επίσης να επαναχρησιμοποιήσουμε τη μνήμη και να μεταφέρουμε τα δεδομένα προς τα εμπρός.
        // Αλλά το κάνουμε μόνο όταν το προκύπτον Vec δεν θα έχει μεγαλύτερη αχρησιμοποίητη χωρητικότητα από το να το δημιουργεί μέσω της γενικής εφαρμογής FromIterator.
        //
        // Αυτός ο περιορισμός δεν είναι απολύτως απαραίτητος καθώς η συμπεριφορά κατανομής της Vec είναι σκόπιμα μη καθορισμένη.
        // Αλλά είναι μια συντηρητική επιλογή.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // πρέπει να εκχωρήσει στο spec_extend(), καθώς το ίδιο το extend() μεταβιβάζει στο spec_from για κενά Vec
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Αυτό χρησιμοποιεί το `iterator.as_slice().to_vec()` δεδομένου ότι το spec_extend πρέπει να κάνει περισσότερα βήματα για να σκεφτεί την τελική χωρητικότητα + μήκος και έτσι να κάνει περισσότερη δουλειά.
// `to_vec()` κατανέμει άμεσα το σωστό ποσό και το συμπληρώνει ακριβώς.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): με το cfg(test) η εγγενής μέθοδος `[T]::to_vec`, η οποία απαιτείται για αυτόν τον ορισμό της μεθόδου, δεν είναι διαθέσιμη.
    // Αντ 'αυτού, χρησιμοποιήστε τη λειτουργία `slice::to_vec` η οποία είναι διαθέσιμη μόνο με το cfg(test) NB, δείτε τη μονάδα slice::hack στο slice.rs για περισσότερες πληροφορίες
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}