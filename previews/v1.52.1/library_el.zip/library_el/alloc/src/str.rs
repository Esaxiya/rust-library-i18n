//! Φέτες συμβολοσειράς Unicode.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Ο τύπος `&str` είναι ένας από τους δύο κύριους τύπους συμβολοσειρών, ο άλλος είναι `String`.
//! Σε αντίθεση με το αντίστοιχο `String`, το περιεχόμενό του δανείζεται.
//!
//! # Βασική χρήση
//!
//! Μια βασική δήλωση συμβολοσειράς τύπου `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Εδώ έχουμε δηλώσει μια κυριολεκτική συμβολοσειρά, γνωστή και ως φέτα χορδών.
//! Οι συμβολοσειρές συμβολοσειράς έχουν στατική διάρκεια ζωής, που σημαίνει ότι η συμβολοσειρά `hello_world` είναι εγγυημένη ότι ισχύει για όλη τη διάρκεια του προγράμματος.
//!
//! Μπορούμε επίσης να προσδιορίσουμε ρητά τη διάρκεια ζωής του «hello_world»:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Πολλές από τις χρήσεις σε αυτήν την ενότητα χρησιμοποιούνται μόνο στη διαμόρφωση δοκιμής.
// Είναι πιο καθαρό να απενεργοποιείτε την προειδοποίηση που δεν χρησιμοποιείται_ παρά να τις διορθώνετε.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: Το `str` στο `Concat<str>` δεν έχει νόημα εδώ.
/// Αυτή η παράμετρος τύπου του trait υπάρχει μόνο για την ενεργοποίηση ενός άλλου εμφ.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // βρόχοι με σκληρά κωδικοποιημένα μεγέθη τρέχουν πολύ πιο γρήγορα εξειδικεύουν τις θήκες με μικρά μήκη διαχωριστή
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // αυθαίρετη εναλλακτική λύση μη μηδενικού μεγέθους
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Βελτιστοποιημένη εφαρμογή συμμετοχής που λειτουργεί και για τα δύο Vec<T>(T: Αντιγραφή) και το εσωτερικό vec του String Σήμερα (2018-05-13) υπάρχει ένα σφάλμα με συμπεράσματα και εξειδίκευση τύπου (βλ. Τεύχος #36262) Για το λόγο αυτό SliceConcat<T>δεν είναι εξειδικευμένη για το T: Copy και SliceConcat<str>είναι ο μόνος χρήστης αυτής της λειτουργίας.
// Αφήνεται στη θέση του για τη στιγμή που έχει επιδιορθωθεί.
//
// τα όρια για το String-join είναι S: Borrow<str>και για Vec-join Borrow <[T]> [T] και str και τα δύο impl AsRef <[T]> για κάποιο T
// => s.borrow().as_ref() και έχουμε πάντα φέτες
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // το πρώτο κομμάτι είναι το μόνο χωρίς προηγούμενο διαχωριστικό
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // υπολογίστε το ακριβές συνολικό μήκος του ενωμένου Vec εάν ο υπολογισμός `len` υπερχειλίσει, θα panic θα είχαμε εξαντλήσει τη μνήμη ούτως ή άλλως και η υπόλοιπη συνάρτηση απαιτεί ολόκληρο το Vec που έχει εκχωρηθεί εκ των προτέρων για ασφάλεια
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // ετοιμάστε ένα μη αρχικοποιημένο buffer
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // διαχωριστής αντιγραφής και φέτες χωρίς οριακούς ελέγχους δημιουργούν βρόχους με σκληρές κωδικοποιήσεις για μικρούς διαχωριστές δυνατές βελτιώσεις (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Μια παράξενη εφαρμογή δανεισμού μπορεί να επιστρέψει διαφορετικά κομμάτια για τον υπολογισμό του μήκους και το πραγματικό αντίγραφο.
        //
        // Βεβαιωθείτε ότι δεν εκθέτουμε μη αρχικοποιημένα byte στον καλούντα.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Μέθοδοι για φέτες χορδών.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Μετατρέπει ένα `Box<str>` σε `Box<[u8]>` χωρίς αντιγραφή ή εκχώρηση.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Αντικαθιστά όλους τους αγώνες ενός μοτίβου με μια άλλη συμβολοσειρά.
    ///
    /// `replace` δημιουργεί ένα νέο [`String`] και αντιγράφει τα δεδομένα από αυτό το κομμάτι συμβολοσειράς σε αυτό.
    /// Με αυτόν τον τρόπο, προσπαθεί να βρει αγώνες μοτίβου.
    /// Εάν το βρει, τα αντικαθιστά με το ανταλλακτικό έγχορδα.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Όταν το μοτίβο δεν ταιριάζει:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Αντικαθιστά τους πρώτους N αγώνες ενός μοτίβου με μια άλλη συμβολοσειρά.
    ///
    /// `replacen` δημιουργεί ένα νέο [`String`] και αντιγράφει τα δεδομένα από αυτό το κομμάτι συμβολοσειράς σε αυτό.
    /// Με αυτόν τον τρόπο, προσπαθεί να βρει αγώνες μοτίβου.
    /// Εάν το βρει, το αντικαθιστά με το κομμάτι συμβολοσειράς αντικατάστασης το πολύ `count` φορές.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Όταν το μοτίβο δεν ταιριάζει:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Ελπίζω να μειώσω τους χρόνους ανακατανομής
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Επιστρέφει το πεζά ισοδύναμο αυτού του slice string, ως νέο [`String`].
    ///
    /// 'Lowercase' ορίζεται σύμφωνα με τους όρους του Unicode Derived Core Property `Lowercase`.
    ///
    /// Δεδομένου ότι ορισμένοι χαρακτήρες μπορούν να επεκταθούν σε πολλούς χαρακτήρες κατά την αλλαγή της υπόθεσης, αυτή η συνάρτηση επιστρέφει ένα [`String`] αντί να τροποποιεί την παράμετρο στη θέση του.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Ένα δύσκολο παράδειγμα, με σίγμα:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // αλλά στο τέλος μιας λέξης, είναι, όχι σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Οι γλώσσες χωρίς περίπτωση δεν αλλάζουν:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ χαρτώνει σε σ, εκτός από το τέλος μιας λέξης όπου αντιστοιχεί σε.
                // Αυτός είναι ο μόνος υπό όρους (contextual) αλλά ανεξάρτητος από τη γλώσσα χαρτογράφησης στο `SpecialCasing.txt`, τόσο σκληρός κωδικός παρά να έχει έναν γενικό μηχανισμό "condition".
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // για τον ορισμό του `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Επιστρέφει το κεφαλαίο ισοδύναμο αυτού του slice string, ως νέο [`String`].
    ///
    /// 'Uppercase' ορίζεται σύμφωνα με τους όρους του Unicode Derived Core Property `Uppercase`.
    ///
    /// Δεδομένου ότι ορισμένοι χαρακτήρες μπορούν να επεκταθούν σε πολλούς χαρακτήρες κατά την αλλαγή της υπόθεσης, αυτή η συνάρτηση επιστρέφει ένα [`String`] αντί να τροποποιεί την παράμετρο στη θέση του.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Τα σενάρια χωρίς πεζά δεν αλλάζουν:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Ένας χαρακτήρας μπορεί να γίνει πολλαπλός:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Μετατρέπει ένα [`Box<str>`] σε [`String`] χωρίς αντιγραφή ή εκχώρηση.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Δημιουργεί ένα νέο [`String`] επαναλαμβάνοντας μια συμβολοσειρά `n` φορές.
    ///
    /// # Panics
    ///
    /// Αυτή η συνάρτηση θα panic εάν η χωρητικότητα υπερχείλισης.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// Ένα panic κατά την υπερχείλιση:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Επιστρέφει ένα αντίγραφο αυτής της συμβολοσειράς όπου κάθε χαρακτήρας αντιστοιχεί στο αντίστοιχο κεφαλαίο ASCII.
    ///
    ///
    /// Τα γράμματα ASCII 'a' έως 'z' αντιστοιχίζονται σε 'A' έως 'Z', αλλά τα γράμματα που δεν είναι ASCII είναι αμετάβλητα.
    ///
    /// Για κεφαλαία τιμή στην θέση, χρησιμοποιήστε το [`make_ascii_uppercase`].
    ///
    /// Για κεφαλαία χαρακτήρες ASCII εκτός από χαρακτήρες εκτός ASCII, χρησιμοποιήστε το [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() διατηρεί το UTF-8 αναλλοίωτο.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Επιστρέφει ένα αντίγραφο αυτής της συμβολοσειράς όπου κάθε χαρακτήρας χαρτογραφείται στο αντίστοιχο πεζά ASCII.
    ///
    ///
    /// Τα γράμματα ASCII 'A' έως 'Z' αντιστοιχίζονται σε 'a' έως 'z', αλλά τα γράμματα που δεν είναι ASCII είναι αμετάβλητα.
    ///
    /// Για να μειώσετε την τιμή στη θέση σας, χρησιμοποιήστε το [`make_ascii_lowercase`].
    ///
    /// Για να πετύχετε τους χαρακτήρες ASCII εκτός από τους χαρακτήρες που δεν είναι ASCII, χρησιμοποιήστε το [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() διατηρεί το UTF-8 αναλλοίωτο.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Μετατρέπει μια τεμαχισμένη φέτα bytes σε μια φέτα συμβολοσειράς χωρίς να ελέγξει αν η συμβολοσειρά περιέχει έγκυρο UTF-8.
///
///
/// # Examples
///
/// Βασική χρήση:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}