//! Μια ουρά προτεραιότητας που εφαρμόζεται με δυαδικό σωρό.
//!
//! Η εισαγωγή και η εμφάνιση του μεγαλύτερου στοιχείου έχουν πολυπλοκότητα χρόνου *O*(log(*n*)).
//! Ο έλεγχος του μεγαλύτερου στοιχείου είναι *O*(1).Η μετατροπή ενός vector σε δυαδικό σωρό μπορεί να γίνει στη θέση του και έχει *O*(*n*) πολυπλοκότητα.
//! Ένας δυαδικός σωρός μπορεί επίσης να μετατραπεί σε ταξινομημένο vector στη θέση του, επιτρέποντάς του να χρησιμοποιηθεί για ένα επί τόπου *O*(*n*\*log(* n*)).
//!
//! # Examples
//!
//! Αυτό είναι ένα μεγαλύτερο παράδειγμα που εφαρμόζει το [Dijkstra's algorithm][dijkstra] για την επίλυση του [shortest path problem][sssp] σε ένα [directed graph][dir_graph].
//!
//! Δείχνει πώς να χρησιμοποιήσετε το [`BinaryHeap`] με προσαρμοσμένους τύπους.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Η ουρά προτεραιότητας εξαρτάται από το `Ord`.
//! // Εφαρμόστε ρητά το trait έτσι ώστε η ουρά να γίνει min-heap αντί για max-heap.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Παρατηρήστε ότι ανατρέπουμε την παραγγελία στο κόστος.
//!         // Σε περίπτωση ισοπαλίας συγκρίνουμε τις θέσεις, αυτό το βήμα είναι απαραίτητο για να γίνουν συνεπείς οι υλοποιήσεις των `PartialEq` και `Ord`.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` πρέπει να εφαρμοστεί επίσης.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Κάθε κόμβος παρουσιάζεται ως `usize`, για μικρότερη εφαρμογή.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Ο μικρότερος αλγόριθμος της Dijkstra.
//!
//! // Ξεκινήστε από το `start` και χρησιμοποιήστε το `dist` για να παρακολουθείτε την τρέχουσα μικρότερη απόσταση από κάθε κόμβο.Αυτή η εφαρμογή δεν είναι αποδοτική στη μνήμη, καθώς μπορεί να αφήσει διπλούς κόμβους στην ουρά.
//! //
//! // Χρησιμοποιεί επίσης το `usize::MAX` ως τιμή Sentinel, για απλούστερη εφαρμογή.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=τρέχουσα μικρότερη απόσταση από `start` έως `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Είμαστε στο `start`, με μηδενικό κόστος
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Εξετάστε τα σύνορα με κόμβους χαμηλότερου κόστους πρώτα (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Εναλλακτικά θα μπορούσαμε να συνεχίσουμε να βρίσκουμε όλα τα συντομότερα μονοπάτια
//!         if position == goal { return Some(cost); }
//!
//!         // Σημαντικό, καθώς ίσως έχουμε ήδη βρει έναν καλύτερο τρόπο
//!         if cost > dist[position] { continue; }
//!
//!         // Για κάθε κόμβο που μπορούμε να προσεγγίσουμε, δείτε αν μπορούμε να βρούμε έναν τρόπο με χαμηλότερο κόστος που περνά από αυτόν τον κόμβο
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Εάν ναι, προσθέστε το στα σύνορα και συνεχίστε
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Χαλάρωση, βρήκαμε τώρα έναν καλύτερο τρόπο
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Ο στόχος δεν είναι εφικτός
//!     None
//! }
//!
//! fn main() {
//!     // Αυτό είναι το κατευθυνόμενο γράφημα που θα χρησιμοποιήσουμε.
//!     // Οι αριθμοί κόμβων αντιστοιχούν στις διαφορετικές καταστάσεις και τα βάρη edge συμβολίζουν το κόστος μετακίνησης από έναν κόμβο στον άλλο.
//!     //
//!     // Σημειώστε ότι τα άκρα είναι μονόπλευρα.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Το γράφημα παριστάνεται ως μια λίστα γειτνίασης όπου κάθε δείκτης, που αντιστοιχεί σε μια τιμή κόμβου, έχει μια λίστα εξερχόμενων ακμών.
//!     // Επιλέχθηκε για την αποτελεσματικότητά του.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Κόμβος 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Κόμβος 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Κόμβος 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Κόμβος 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Κόμβος 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Μια ουρά προτεραιότητας που εφαρμόζεται με δυαδικό σωρό.
///
/// Αυτό θα είναι ένα μέγιστο σωρό.
///
/// Είναι λογικό σφάλμα ένα στοιχείο να τροποποιηθεί κατά τέτοιο τρόπο ώστε η παραγγελία του αντικειμένου σε σχέση με οποιοδήποτε άλλο στοιχείο, όπως καθορίζεται από το `Ord` trait, να αλλάζει ενώ βρίσκεται στο σωρό.
///
/// Αυτό είναι συνήθως δυνατό μόνο μέσω `Cell`, `RefCell`, παγκόσμιας κατάστασης, I/O ή μη ασφαλούς κώδικα.
/// Η συμπεριφορά που προκύπτει από ένα τέτοιο λογικό σφάλμα δεν καθορίζεται, αλλά δεν θα οδηγήσει σε απροσδιόριστη συμπεριφορά.
/// Αυτό θα μπορούσε να περιλαμβάνει panics, λανθασμένα αποτελέσματα, ματαίωση, διαρροές μνήμης και μη τερματισμό.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Το συμπέρασμα τύπου μας επιτρέπει να παραλείψουμε μια υπογραφή ρητού τύπου (η οποία θα ήταν `BinaryHeap<i32>` σε αυτό το παράδειγμα).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Μπορούμε να χρησιμοποιήσουμε το peek για να δούμε το επόμενο αντικείμενο στο σωρό.
/// // Σε αυτήν την περίπτωση, δεν υπάρχουν ακόμη στοιχεία, οπότε δεν λαμβάνουμε κανένα.
/// assert_eq!(heap.peek(), None);
///
/// // Ας προσθέσουμε μερικές βαθμολογίες ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Τώρα ρίξτε μια ματιά στο πιο σημαντικό στοιχείο στο σωρό.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Μπορούμε να ελέγξουμε το μήκος ενός σωρού.
/// assert_eq!(heap.len(), 3);
///
/// // Μπορούμε να επαναλάβουμε τα αντικείμενα στο σωρό, αν και επιστρέφονται με τυχαία σειρά.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Αν αντ 'αυτού εμφανίσουμε αυτά τα σκορ, θα πρέπει να επιστρέψουν στη σειρά.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Μπορούμε να καθαρίσουμε το σωρό των υπόλοιπων αντικειμένων.
/// heap.clear();
///
/// // Ο σωρός πρέπει τώρα να είναι άδειος.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Μπορεί να χρησιμοποιηθεί είτε το `std::cmp::Reverse` είτε μια προσαρμοσμένη εφαρμογή `Ord` για να γίνει το `BinaryHeap` ελάχιστο σωρό.
/// Αυτό κάνει το `heap.pop()` να επιστρέφει τη μικρότερη τιμή αντί της μεγαλύτερης.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Τυλίξτε τιμές σε `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Εάν εμφανίσουμε αυτά τα σκορ τώρα, θα πρέπει να επιστρέψουν στην αντίστροφη σειρά.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Χρόνος πολυπλοκότητας
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Η τιμή για το `push` είναι ένα αναμενόμενο κόστος.η τεκμηρίωση της μεθόδου δίνει μια πιο λεπτομερή ανάλυση.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Δομή τυλίγοντας μια μεταβλητή αναφορά στο μεγαλύτερο στοιχείο σε ένα `BinaryHeap`.
///
///
/// Αυτό το `struct` δημιουργήθηκε με τη μέθοδο [`peek_mut`] στο [`BinaryHeap`].
/// Δείτε την τεκμηρίωσή του για περισσότερα.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // ΑΣΦΑΛΕΙΑ: Το PeekMut δημιουργείται μόνο για άδειους σωρούς.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // ΑΣΦΑΛΕΙΑ: Το PeekMut δημιουργείται μόνο για άδειους σωρούς
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // ΑΣΦΑΛΕΙΑ: Το PeekMut δημιουργείται μόνο για άδειους σωρούς
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Αφαιρεί την τιμή από τον σωρό και την επιστρέφει.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Δημιουργεί ένα κενό `BinaryHeap<T>`.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Δημιουργεί ένα κενό `BinaryHeap` ως μέγιστο σωρό.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Δημιουργεί ένα κενό `BinaryHeap` με συγκεκριμένη χωρητικότητα.
    /// Αυτό εκχωρεί αρκετή μνήμη για στοιχεία `capacity`, έτσι ώστε το `BinaryHeap` να μην χρειάζεται να ανακατανεμηθεί έως ότου περιέχει τουλάχιστον τόσες πολλές τιμές.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Επιστρέφει μια μεταβλητή αναφορά στο μεγαλύτερο στοιχείο του δυαδικού σωρού ή `None` εάν είναι κενό.
    ///
    /// Note: Εάν η τιμή `PeekMut` έχει διαρρεύσει, ο σωρός μπορεί να βρίσκεται σε ασυνεπή κατάσταση.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Χρόνος πολυπλοκότητας
    ///
    /// Εάν το στοιχείο έχει τροποποιηθεί, τότε η χειρότερη περίπλοκη ώρα είναι *O*(log(*n*)), διαφορετικά είναι *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Αφαιρεί το μεγαλύτερο αντικείμενο από το δυαδικό σωρό και το επιστρέφει ή `None` εάν είναι κενό.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Χρόνος πολυπλοκότητας
    ///
    /// Το χειρότερο κόστος του `pop` σε έναν σωρό που περιέχει στοιχεία *n* είναι *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // ΑΣΦΑΛΕΙΑ: !self.is_empty() σημαίνει ότι self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Σπρώχνει ένα αντικείμενο στο δυαδικό σωρό.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Χρόνος πολυπλοκότητας
    ///
    /// Το αναμενόμενο κόστος των `push`, κατά μέσο όρο για κάθε πιθανή σειρά των στοιχείων που ωθούνται, και για έναν αρκετά μεγάλο αριθμό ωθήσεων, είναι *O*(1).
    ///
    /// Αυτή είναι η πιο σημαντική μέτρηση κόστους κατά την προώθηση στοιχείων που δεν είναι ήδη σε οποιοδήποτε ταξινομημένο μοτίβο.
    ///
    /// Η χρονική πολυπλοκότητα υποβαθμίζεται εάν τα στοιχεία ωθούνται κατά κύριο λόγο σε αύξουσα σειρά.
    /// Στη χειρότερη περίπτωση, τα στοιχεία ωθούνται με αύξουσα ταξινομημένη σειρά και το αποσβεσμένο κόστος ανά ώθηση είναι *O*(log(*n*)) έναντι σωρού που περιέχει στοιχεία *n*.
    ///
    /// Το χειρότερο κόστος μιας κλήσης *single* στο `push` είναι *O*(*n*).Η χειρότερη περίπτωση εμφανίζεται όταν εξαντλείται η χωρητικότητα και χρειάζεται αλλαγή μεγέθους.
    /// Το κόστος αλλαγής μεγέθους έχει αποσβεσθεί στα προηγούμενα στοιχεία.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // ΑΣΦΑΛΕΙΑ: Αφού προωθήσαμε ένα νέο αντικείμενο, αυτό σημαίνει ότι
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Καταναλώνει το `BinaryHeap` και επιστρέφει ένα vector σε ταξινομημένη σειρά (ascending).
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // ΑΣΦΑΛΕΙΑ: Το `end` πηγαίνει από το `self.len() - 1` στο 1 (περιλαμβάνονται και τα δύο),
            //  οπότε είναι πάντα ένα έγκυρο ευρετήριο για πρόσβαση.
            //  Είναι ασφαλές να έχετε πρόσβαση στο ευρετήριο 0 (δηλ. `ptr`), επειδή
            //  1 <=τέλος <self.len(), που σημαίνει self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // ΑΣΦΑΛΕΙΑ: Το `end` πηγαίνει από το `self.len() - 1` στο 1 (περιλαμβάνονται και τα δύο) έτσι:
            //  0 <1 <=τέλος <= self.len(), 1 <self.len() που σημαίνει 0 <τέλος και τέλος <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Οι υλοποιήσεις των sift_up και sift_down χρησιμοποιούν μη ασφαλή μπλοκ για να μετακινήσουν ένα στοιχείο από το vector (αφήνοντας πίσω από μια τρύπα), να μετακινηθούν κατά μήκος των άλλων και να μετακινήσουν το αφαιρεθέν στοιχείο πίσω στο vector στην τελική θέση της τρύπας.
    //
    // Ο τύπος `Hole` χρησιμοποιείται για να το αντιπροσωπεύσει και βεβαιωθείτε ότι η τρύπα έχει γεμίσει πίσω στο τέλος του πεδίου εφαρμογής της, ακόμη και στο panic.
    // Η χρήση μιας τρύπας μειώνει τον σταθερό συντελεστή σε σύγκριση με τη χρήση ανταλλακτικών, ο οποίος περιλαμβάνει διπλάσιες κινήσεις.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Ο καλών πρέπει να εγγυηθεί ότι `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Βγάλτε την τιμή στο `pos` και δημιουργήστε μια τρύπα.
        // ΑΣΦΑΛΕΙΑ: Ο καλών εγγυάται ότι η θέση <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // ΑΣΦΑΛΕΙΑ: hole.pos()> έναρξη>=0, που σημαίνει hole.pos()> 0
            //  και έτσι το hole.pos(), 1 δεν μπορεί να υποχωρήσει.
            //  Αυτό εγγυάται ότι ο γονέας <hole.pos(), έτσι είναι ένα έγκυρο ευρετήριο και επίσης!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // ΑΣΦΑΛΕΙΑ: Όπως και παραπάνω
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Πάρτε ένα στοιχείο στο `pos` και μετακινήστε το κάτω από το σωρό, ενώ τα παιδιά του είναι μεγαλύτερα.
    ///
    ///
    /// # Safety
    ///
    /// Ο καλών πρέπει να εγγυηθεί ότι `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // ΑΣΦΑΛΕΙΑ: Ο καλών εγγυάται ότι το pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Αμετάβλητο βρόχο: παιδί==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // συγκρίνετε με το μεγαλύτερο από τα δύο παιδιά ΑΣΦΑΛΕΙΑ: παιδί <τέλος, 1 <self.len() και παιδί + 1 <τέλος <= self.len(), επομένως είναι έγκυρα ευρετήρια.
            //
            //  παιδί==2 *hole.pos() + 1!= hole.pos() και παιδί + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 ή 2* hole.pos() + 2 θα μπορούσε να ξεχειλίσει εάν το T είναι ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // αν είμαστε ήδη σε τάξη, σταματήστε.
            // ΑΣΦΑΛΕΙΑ: το παιδί είναι τώρα είτε το παλιό είτε το παλιό παιδί + 1
            //  Έχουμε ήδη αποδείξει ότι και οι δύο είναι <self.len() και!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // ΑΣΦΑΛΕΙΑ: όπως και παραπάνω.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // ΑΣΦΑΛΕΙΑ: &&βραχυκύκλωμα, που σημαίνει ότι στο
        //  Δεύτερη συνθήκη είναι ήδη αλήθεια ότι το παιδί==τέλος, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // ΑΣΦΑΛΕΙΑ: το παιδί έχει ήδη αποδειχθεί ότι είναι έγκυρο ευρετήριο και
            //  παιδί==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Ο καλών πρέπει να εγγυηθεί ότι `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // ΑΣΦΑΛΕΙΑ: το pos <len είναι εγγυημένο από τον καλούντα και
        //  προφανώς len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Πάρτε ένα στοιχείο στο `pos` και μετακινήστε το μέχρι το σωρό και, στη συνέχεια, τοποθετήστε το στη θέση του.
    ///
    ///
    /// Note: Αυτό είναι ταχύτερο όταν το στοιχείο είναι γνωστό ότι είναι μεγάλο/πρέπει να είναι πιο κοντά στο κάτω μέρος.
    ///
    /// # Safety
    ///
    /// Ο καλών πρέπει να εγγυηθεί ότι `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // ΑΣΦΑΛΕΙΑ: Ο καλών εγγυάται ότι η θέση <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Αμετάβλητο βρόχο: παιδί==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // ΑΣΦΑΛΕΙΑ: παιδί <τέλος, 1 <self.len() και
            //  παιδί + 1 <τέλος <= self.len(), επομένως είναι έγκυρα ευρετήρια.
            //  παιδί==2 *hole.pos() + 1!= hole.pos() και παιδί + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 ή 2* hole.pos() + 2 θα μπορούσε να ξεχειλίσει εάν το T είναι ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ΑΣΦΑΛΕΙΑ: Όπως και παραπάνω
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // ΑΣΦΑΛΕΙΑ: παιδί==τέλος, 1 <self.len(), επομένως είναι έγκυρο ευρετήριο
            //  και παιδί==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // ΑΣΦΑΛΕΙΑ: η θέση είναι η θέση στην τρύπα και ήταν ήδη αποδεδειγμένη
        //  να είναι έγκυρο ευρετήριο.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // ΑΣΦΑΛΕΙΑ: το n ξεκινά από το self.len()/2 και μειώνεται στο 0.
            //  Η μόνη περίπτωση όταν! (N <self.len()) είναι εάν self.len() ==0, αλλά αποκλείεται από την κατάσταση βρόχου.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Μετακινεί όλα τα στοιχεία του `other` σε `self`, αφήνοντας το `other` κενό.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` χρειάζεται χειρισμούς O(len1 + len2) και περίπου 2 *(len1 + len2) συγκρίσεις στη χειρότερη περίπτωση, ενώ το `extend` παίρνει χειρισμούς O(len2* log(len1)) και περίπου 1 *len2* log_2(len1) συγκρίσεις στη χειρότερη περίπτωση, υποθέτοντας len1>= len2.
        // Για μεγαλύτερους σωρούς, το σημείο διασταύρωσης δεν ακολουθεί πλέον αυτόν τον συλλογισμό και προσδιορίστηκε εμπειρικά.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Επιστρέφει έναν επαναληπτικό που ανακτά στοιχεία σε σειρά σωρού.
    /// Τα ανακτημένα στοιχεία αφαιρούνται από τον αρχικό σωρό.
    /// Τα υπόλοιπα στοιχεία θα αφαιρεθούν με πτώση στη σειρά σωρού.
    ///
    /// Note:
    /// * `.drain_sorted()` είναι *O*(*n*\*log(* n*)); πολύ πιο αργό από το `.drain()`.
    ///   Θα πρέπει να χρησιμοποιήσετε το τελευταίο στις περισσότερες περιπτώσεις.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // αφαιρεί όλα τα στοιχεία σε σειρά σωρού
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Διατηρεί μόνο τα στοιχεία που καθορίζονται από την κατηγορία.
    ///
    /// Με άλλα λόγια, καταργήστε όλα τα στοιχεία `e` έτσι ώστε το `f(&e)` να επιστρέφει το `false`.
    /// Τα στοιχεία επισκέπτονται με μη ταξινομημένη (και μη καθορισμένη) σειρά.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // κρατήστε μόνο ζυγούς αριθμούς
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Επιστρέφει έναν επαναληπτικό που επισκέπτεται όλες τις τιμές στο υποκείμενο vector, με αυθαίρετη σειρά.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Εκτύπωση 1, 2, 3, 4 με αυθαίρετη σειρά
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Επιστρέφει έναν επαναληπτικό που ανακτά στοιχεία σε σειρά σωρού.
    /// Αυτή η μέθοδος καταναλώνει τον αρχικό σωρό.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Επιστρέφει το μεγαλύτερο στοιχείο στο δυαδικό σωρό ή `None` εάν είναι κενό.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Χρόνος πολυπλοκότητας
    ///
    /// Το κόστος είναι *O*(1) στη χειρότερη περίπτωση.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Επιστρέφει τον αριθμό των στοιχείων που μπορεί να διατηρήσει ο δυαδικός σωρός χωρίς ανακατανομή.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Διατηρεί την ελάχιστη χωρητικότητα για ακριβώς `additional` περισσότερα στοιχεία που θα εισαχθούν στο δεδομένο `BinaryHeap`.
    /// Δεν κάνει τίποτα εάν η χωρητικότητα είναι ήδη επαρκής.
    ///
    /// Σημειώστε ότι ο εκχωρητής μπορεί να δώσει στη συλλογή περισσότερο χώρο από ό, τι ζητά.
    /// Επομένως δεν μπορεί να γίνει επίκληση της ικανότητας να είναι ακριβώς ελάχιστη.
    /// Προτιμήστε το [`reserve`] εάν αναμένονται εισαγωγές future.
    ///
    /// # Panics
    ///
    /// Panics εάν η νέα χωρητικότητα ξεχειλίζει `usize`.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Διατηρεί χωρητικότητα για τουλάχιστον `additional` περισσότερα στοιχεία που θα εισαχθούν στο `BinaryHeap`.
    /// Η συλλογή ενδέχεται να διατηρήσει περισσότερο χώρο για να αποφευχθούν συχνές ανακατανομές.
    ///
    /// # Panics
    ///
    /// Panics εάν η νέα χωρητικότητα ξεχειλίζει `usize`.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Απορρίπτει όσο το δυνατόν περισσότερη χωρητικότητα.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Απορρίπτει χωρητικότητα με χαμηλότερο όριο.
    ///
    /// Η χωρητικότητα θα παραμείνει τουλάχιστον τόσο μεγάλη όσο και το μήκος και η παρεχόμενη τιμή.
    ///
    ///
    /// Εάν η τρέχουσα χωρητικότητα είναι μικρότερη από το κατώτερο όριο, αυτό δεν είναι op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Καταναλώνει το `BinaryHeap` και επιστρέφει το υποκείμενο vector με αυθαίρετη σειρά.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Θα εκτυπωθεί με κάποια σειρά
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Επιστρέφει το μήκος του δυαδικού σωρού.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Ελέγχει εάν ο δυαδικός σωρός είναι κενός.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Διαγράφει το δυαδικό σωρό, επιστρέφοντας έναν επαναληπτικό πάνω από τα στοιχεία που αφαιρέθηκαν.
    ///
    /// Τα στοιχεία αφαιρούνται με αυθαίρετη σειρά.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Σταματά όλα τα στοιχεία από το δυαδικό σωρό.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Η τρύπα αντιπροσωπεύει μια τρύπα σε ένα κομμάτι, δηλαδή, ένα ευρετήριο χωρίς έγκυρη τιμή (επειδή μετακινήθηκε από ή αντιγράφηκε).
///
/// Σε πτώση, το `Hole` θα επαναφέρει το κομμάτι γεμίζοντας τη θέση της τρύπας με την τιμή που είχε αρχικά αφαιρεθεί.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Δημιουργήστε ένα νέο `Hole` στο ευρετήριο `pos`.
    ///
    /// Μη ασφαλές επειδή η θέση πρέπει να βρίσκεται εντός του τμήματος δεδομένων.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // ΑΣΦΑΛΗ: η θέση πρέπει να βρίσκεται μέσα στη φέτα
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Επιστρέφει μια αναφορά στο στοιχείο που έχει αφαιρεθεί.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Επιστρέφει μια αναφορά στο στοιχείο στο `index`.
    ///
    /// Μη ασφαλές επειδή το ευρετήριο πρέπει να βρίσκεται εντός του τμήματος δεδομένων και να μην ισούται με τη θέση.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Μετακίνηση τρύπας σε νέα τοποθεσία
    ///
    /// Μη ασφαλές επειδή το ευρετήριο πρέπει να βρίσκεται εντός του τμήματος δεδομένων και να μην ισούται με τη θέση.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // γεμίστε ξανά την τρύπα
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Επανάληψη πάνω από τα στοιχεία ενός `BinaryHeap`.
///
/// Αυτό το `struct` δημιουργήθηκε από το [`BinaryHeap::iter()`].
/// Δείτε την τεκμηρίωσή του για περισσότερα.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Αφαιρέστε υπέρ του `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Ένας ιδιοκτήτης επανάληψης πάνω από τα στοιχεία ενός `BinaryHeap`.
///
/// Αυτό το `struct` δημιουργήθηκε από το [`BinaryHeap::into_iter()`] (παρέχεται από το `IntoIterator` trait).
/// Δείτε την τεκμηρίωσή του για περισσότερα.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Επανάληψη αποστράγγισης πάνω από τα στοιχεία ενός `BinaryHeap`.
///
/// Αυτό το `struct` δημιουργήθηκε από το [`BinaryHeap::drain()`].
/// Δείτε την τεκμηρίωσή του για περισσότερα.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Επανάληψη αποστράγγισης πάνω από τα στοιχεία ενός `BinaryHeap`.
///
/// Αυτό το `struct` δημιουργήθηκε από το [`BinaryHeap::drain_sorted()`].
/// Δείτε την τεκμηρίωσή του για περισσότερα.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Αφαιρεί στοιχεία σωρού με σειρά σωρού.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Μετατρέπει ένα `Vec<T>` σε `BinaryHeap<T>`.
    ///
    /// Αυτή η μετατροπή συμβαίνει επιτόπου και έχει *O*(*n*) χρονική πολυπλοκότητα.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Μετατρέπει ένα `BinaryHeap<T>` σε `Vec<T>`.
    ///
    /// Αυτή η μετατροπή δεν απαιτεί μετακίνηση δεδομένων ή κατανομή και έχει συνεχή πολυπλοκότητα χρόνου.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Δημιουργεί έναν καταναλωτή που επαναλαμβάνει, δηλαδή, που μετακινεί κάθε τιμή από τον δυαδικό σωρό με αυθαίρετη σειρά.
    /// Ο δυαδικός σωρός δεν μπορεί να χρησιμοποιηθεί αφού το καλέσετε.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Εκτύπωση 1, 2, 3, 4 με αυθαίρετη σειρά
    /// for x in heap.into_iter() {
    ///     // x έχει τον τύπο i32, όχι &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}