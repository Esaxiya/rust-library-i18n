use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// Πυρήνας ενός επαναληπτικού που συγχωνεύει την έξοδο δύο αυστηρά ανερχόμενων επαναληπτών, για παράδειγμα μια ένωση ή μια συμμετρική διαφορά.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// Τα κριτήρια αναφοράς γρηγορότερα από το να τυλίγονται και τα δύο επαναληπτικά σε μια δυνατότητα παρακολούθησης, πιθανώς επειδή μπορούμε να επιβάλουμε ένα FusedIterator δεσμευμένο.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// Δημιουργεί έναν νέο πυρήνα για έναν επαναληπτικό που συγχωνεύει ένα ζεύγος πηγών.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// Επιστρέφει το επόμενο ζεύγος στοιχείων που προέρχονται από το ζεύγος πηγών που συγχωνεύονται.
    /// Εάν και οι δύο επιλογές που επιστρέφονται περιέχουν μια τιμή, η τιμή είναι ίση και εμφανίζεται και στις δύο πηγές.
    /// Εάν μία από τις επιστρεφόμενες επιλογές περιέχει μια τιμή, αυτή η τιμή δεν εμφανίζεται στην άλλη πηγή (ή οι πηγές δεν αυξάνονται αυστηρά).
    ///
    /// Εάν καμία από τις επιλογές επιστροφής δεν περιέχει τιμή, η επανάληψη έχει ολοκληρωθεί και οι επόμενες κλήσεις θα επιστρέψουν το ίδιο κενό ζεύγος.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// Επιστρέφει ένα ζευγάρι άνω ορίων για το `size_hint` του τελικού επαναληπτικού.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}