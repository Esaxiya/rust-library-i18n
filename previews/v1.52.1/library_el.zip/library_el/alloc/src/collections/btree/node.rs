// Πρόκειται για μια προσπάθεια υλοποίησης που ακολουθεί το ιδανικό
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Δεδομένου ότι το Rust δεν έχει πραγματικά εξαρτώμενους τύπους και πολυμορφική αναδρομή, το κάνουμε με πολλή ανασφάλεια.
//

// Ένας κύριος στόχος αυτής της ενότητας είναι να αποφευχθεί η πολυπλοκότητα αντιμετωπίζοντας το δέντρο ως ένα γενικό (αν είναι περίεργο) δοχείο και αποφεύγοντας την αντιμετώπιση των περισσότερων αναλλοίωτων B-Tree.
//
// Ως εκ τούτου, αυτή η ενότητα δεν ενδιαφέρεται για το αν οι καταχωρήσεις ταξινομούνται, ποιοι κόμβοι μπορούν να είναι underfull ή ακόμα και τι σημαίνει underfull.Ωστόσο, βασίζουμε σε μερικά αναλλοίωτα:
//
// - Τα δέντρα πρέπει να έχουν ομοιόμορφο depth/height.Αυτό σημαίνει ότι κάθε διαδρομή προς ένα φύλλο από έναν δεδομένο κόμβο έχει ακριβώς το ίδιο μήκος.
// - Ένας κόμβος μήκους `n` έχει πλήκτρα `n`, τιμές `n` και άκρες `n + 1`.
//   Αυτό σημαίνει ότι ακόμη και ένας κενός κόμβος έχει τουλάχιστον ένα edge.
//   Για έναν κόμβο φύλλων, το "having an edge" σημαίνει μόνο ότι μπορούμε να προσδιορίσουμε μια θέση στον κόμβο, καθώς οι άκρες των φύλλων είναι κενές και δεν χρειάζονται αναπαράσταση δεδομένων.
// Σε έναν εσωτερικό κόμβο, ένα edge αναγνωρίζει και μια θέση και περιέχει έναν δείκτη σε έναν θυγατρικό κόμβο.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Η υποκείμενη αναπαράσταση των κόμβων των φύλλων και μέρος της αναπαράστασης των εσωτερικών κόμβων.
struct LeafNode<K, V> {
    /// Θέλουμε να είμαστε συνεκτικοί στα `K` και `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Το ευρετήριο αυτού του κόμβου στον πίνακα `edges` του γονικού κόμβου.
    /// `*node.parent.edges[node.parent_idx]` θα πρέπει να είναι το ίδιο με το `node`.
    /// Αυτό είναι εγγυημένο ότι θα αρχικοποιηθεί μόνο όταν το `parent` είναι μηδενικό.
    parent_idx: MaybeUninit<u16>,

    /// Ο αριθμός των κλειδιών και τιμών που αποθηκεύει αυτός ο κόμβος.
    len: u16,

    /// Οι πίνακες που αποθηκεύουν τα πραγματικά δεδομένα του κόμβου.
    /// Μόνο τα πρώτα στοιχεία `len` κάθε πίνακα αρχικοποιούνται και ισχύουν.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Αρχικοποιεί ένα νέο `LeafNode` στη θέση του.
    unsafe fn init(this: *mut Self) {
        // Ως γενική πολιτική, αφήνουμε τα πεδία μη αρχικοποιημένα εάν μπορούν, καθώς αυτό θα πρέπει να είναι ελαφρώς ταχύτερο και ευκολότερο να εντοπιστεί στο Valgrind.
        //
        unsafe {
            // parent_idx, κλειδιά και vals είναι όλα ίσωςUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Δημιουργεί ένα νέο κουτί `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Η υποκείμενη αναπαράσταση εσωτερικών κόμβων.Όπως και με το "LeafNode", αυτά πρέπει να κρύβονται πίσω από το "BoxedNode" για να αποφευχθεί η πτώση μη αρχικοποιημένων κλειδιών και τιμών.
/// Οποιοσδήποτε δείκτης σε ένα `InternalNode` μπορεί να μεταφερθεί απευθείας σε έναν δείκτη στο υποκείμενο τμήμα `LeafNode` του κόμβου, επιτρέποντας στον κώδικα να ενεργεί γενικά σε φύλλα και εσωτερικούς κόμβους χωρίς να χρειάζεται καν να ελέγξει κανείς από τους δύο δείκτες.
///
/// Αυτή η ιδιότητα ενεργοποιείται με τη χρήση του `repr(C)`.
///
#[repr(C)]
// gdb_providers.py χρησιμοποιεί αυτό το όνομα τύπου για ενδοσκόπηση.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Οι δείκτες στα παιδιά αυτού του κόμβου.
    /// `len + 1` από αυτά θεωρούνται αρχικοποιημένα και έγκυρα, εκτός από το ότι κοντά στο τέλος, ενώ το δέντρο διατηρείται μέσω δανεισμού τύπου `Dying`, ορισμένοι από αυτούς τους δείκτες κρέμονται.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Δημιουργεί ένα νέο κουτί `InternalNode`.
    ///
    /// # Safety
    /// Ένα αμετάβλητο των εσωτερικών κόμβων είναι ότι έχουν τουλάχιστον έναν αρχικοποιημένο και έγκυρο edge.
    /// Αυτή η λειτουργία δεν ρυθμίζει ένα τέτοιο edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Το μόνο που χρειάζεται είναι να προετοιμάσουμε τα δεδομένα.οι άκρες είναι MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Ένας διαχειριζόμενος, μηδενικός δείκτης σε έναν κόμβο.Αυτό είναι είτε ένας ιδιοκτήτης δείκτης στο `LeafNode<K, V>` είτε ένας ιδιοκτήτης δείκτης στο `InternalNode<K, V>`.
///
/// Ωστόσο, το `BoxedNode` δεν περιέχει πληροφορίες σχετικά με το ποιος από τους δύο τύπους κόμβων περιέχει, και, εν μέρει λόγω αυτής της έλλειψης πληροφοριών, δεν είναι ξεχωριστός τύπος και δεν έχει καταστροφικό.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Ο ριζικός κόμβος ενός δικού σας δέντρου.
///
/// Λάβετε υπόψη ότι αυτό δεν έχει καταστροφέα και πρέπει να καθαριστεί χειροκίνητα.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Επιστρέφει ένα νέο ιδιόκτητο δέντρο, με τον δικό του ριζικό κόμβο που είναι αρχικά κενός.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` δεν πρέπει να είναι μηδέν.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Δανείζεται αμοιβαία τον ιδιόκτητο ριζικό κόμβο.
    /// Σε αντίθεση με το `reborrow_mut`, αυτό είναι ασφαλές επειδή η τιμή επιστροφής δεν μπορεί να χρησιμοποιηθεί για να καταστρέψει τη ρίζα και δεν μπορεί να υπάρχουν άλλες αναφορές στο δέντρο.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Δανείζεται ελαφρώς ο ιδιοκτήτης ριζικού κόμβου.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Αμετάκλητα μεταβάσεις σε μια αναφορά που επιτρέπει τη διέλευση και προσφέρει καταστροφικές μεθόδους και λίγα άλλα.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Προσθέτει έναν νέο εσωτερικό κόμβο με ένα μόνο edge που δείχνει τον προηγούμενο ριζικό κόμβο, κάνει αυτόν τον νέο κόμβο τον ριζικό κόμβο και επιστρέφει τον.
    /// Αυτό αυξάνει το ύψος κατά 1 και είναι το αντίθετο του `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, εκτός από το ότι ξεχάσαμε ότι είμαστε εσωτερικοί τώρα:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Καταργεί τον εσωτερικό ριζικό κόμβο, χρησιμοποιώντας το πρώτο του παιδί ως νέο ριζικό κόμβο.
    /// Καθώς προορίζεται μόνο για κλήση όταν ο ριζικός κόμβος έχει μόνο ένα παιδί, δεν γίνεται εκκαθάριση σε κανένα από τα κλειδιά, τις τιμές και άλλα παιδιά.
    ///
    /// Αυτό μειώνει το ύψος κατά 1 και είναι το αντίθετο του `push_internal_level`.
    ///
    /// Απαιτείται αποκλειστική πρόσβαση στο αντικείμενο `Root` αλλά όχι στον ριζικό κόμβο.
    /// Δεν θα ακυρώσει άλλες λαβές ή αναφορές στον ριζικό κόμβο.
    ///
    /// Panics εάν δεν υπάρχει εσωτερικό επίπεδο, δηλαδή, εάν ο ριζικός κόμβος είναι φύλλο.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // ΑΣΦΑΛΕΙΑ: δηλώσαμε ότι είμαστε εσωτερικοί.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // ΑΣΦΑΛΕΙΑ: δανειστήκαμε αποκλειστικά το `self` και ο τύπος δανεισμού του είναι αποκλειστικός.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // ΑΣΦΑΛΕΙΑ: το πρώτο edge προετοιμάζεται πάντα.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. Το `NodeRef` είναι πάντα συνεκτικό σε `K` και `V`, ακόμα και όταν το `BorrowType` είναι `Mut`.
// Αυτό είναι τεχνικά λανθασμένο, αλλά δεν μπορεί να οδηγήσει σε μη ασφάλεια λόγω της εσωτερικής χρήσης του `NodeRef`, επειδή παραμένουμε εντελώς γενικοί σε σχέση με τα `K` και `V`.
//
// Ωστόσο, κάθε φορά που ένας δημόσιος τύπος τυλίγει το `NodeRef`, βεβαιωθείτε ότι έχει τη σωστή διακύμανση.
//
/// Μια αναφορά σε έναν κόμβο.
///
/// Αυτός ο τύπος έχει έναν αριθμό παραμέτρων που ελέγχουν τον τρόπο λειτουργίας του:
/// - `BorrowType`: Ένας εικονικός τύπος που περιγράφει το είδος δανεισμού και έχει διάρκεια ζωής.
///    - Όταν πρόκειται για `Immut<'a>`, το `NodeRef` ενεργεί περίπου σαν το `&'a Node`.
///    - Όταν πρόκειται για `ValMut<'a>`, το `NodeRef` ενεργεί περίπου σαν το `&'a Node` σε σχέση με τα κλειδιά και τη δομή του δέντρου, αλλά επιτρέπει επίσης να συνυπάρχουν πολλές μεταβλητές αναφορές σε τιμές σε όλο το δέντρο.
///    - Όταν πρόκειται για `Mut<'a>`, το `NodeRef` ενεργεί περίπου σαν `&'a mut Node`, αν και οι μέθοδοι εισαγωγής επιτρέπουν τη συνύπαρξη ενός μεταβλητού δείκτη σε μια τιμή.
///    - Όταν πρόκειται για `Owned`, το `NodeRef` ενεργεί περίπου σαν το `Box<Node>`, αλλά δεν διαθέτει καταστροφέα και πρέπει να καθαριστεί χειροκίνητα.
///    - Όταν πρόκειται για `Dying`, το `NodeRef` εξακολουθεί να λειτουργεί περίπου σαν το `Box<Node>`, αλλά έχει μεθόδους για να καταστρέψει το δέντρο λίγο-λίγο, και οι συνηθισμένες μέθοδοι, αν και δεν επισημαίνονται ως μη ασφαλείς για κλήση, μπορούν να επικαλεσθούν το UB εάν καλείται εσφαλμένα.
///
///   Εφόσον οποιοδήποτε `NodeRef` επιτρέπει την πλοήγηση μέσα στο δέντρο, το `BorrowType` ισχύει αποτελεσματικά σε ολόκληρο το δέντρο, όχι μόνο στον ίδιο τον κόμβο.
/// - `K` και `V`: Αυτοί είναι οι τύποι κλειδιών και τιμών που είναι αποθηκευμένοι στους κόμβους.
/// - `Type`: Αυτό μπορεί να είναι `Leaf`, `Internal` ή `LeafOrInternal`.
/// Όταν πρόκειται για `Leaf`, το `NodeRef` δείχνει έναν κόμβο φύλλων, όταν είναι `Internal`, το `NodeRef` δείχνει έναν εσωτερικό κόμβο και όταν αυτό είναι `LeafOrInternal`, το `NodeRef` θα μπορούσε να δείχνει σε οποιονδήποτε τύπο κόμβου.
///   `Type` ονομάζεται `NodeType` όταν χρησιμοποιείται εκτός `NodeRef`.
///
/// Τόσο το `BorrowType` όσο και το `NodeType` περιορίζουν ποιες μεθόδους εφαρμόζουμε, για να εκμεταλλευτούμε την ασφάλεια στατικού τύπου.Υπάρχουν περιορισμοί στον τρόπο με τον οποίο μπορούμε να εφαρμόσουμε αυτούς τους περιορισμούς:
/// - Για κάθε παράμετρο τύπου, μπορούμε να ορίσουμε μόνο μια μέθοδο είτε γενικά είτε για έναν συγκεκριμένο τύπο.
/// Για παράδειγμα, δεν μπορούμε να ορίσουμε μια μέθοδο όπως το `into_kv` γενικά για όλα τα `BorrowType` ή μία φορά για όλους τους τύπους που έχουν διάρκεια ζωής, επειδή θέλουμε να επιστρέψει τις αναφορές `&'a`.
///   Επομένως, το ορίζουμε μόνο για τον λιγότερο ισχυρό τύπο `Immut<'a>`.
/// - Δεν μπορούμε να πάρουμε σιωπηρό εξαναγκασμό από ας πούμε `Mut<'a>` έως `Immut<'a>`.
///   Επομένως, πρέπει να καλέσουμε ρητά το `reborrow` σε ένα πιο ισχυρό `NodeRef` για να φτάσουμε σε μια μέθοδο όπως το `into_kv`.
///
/// Όλες οι μέθοδοι στο `NodeRef` που επιστρέφουν κάποιο είδος αναφοράς, είτε:
/// - Πάρτε το `self` κατά αξία και επιστρέψτε τη διάρκεια ζωής που φέρει το `BorrowType`.
///   Μερικές φορές, για να επικαλεστούμε μια τέτοια μέθοδο, πρέπει να καλέσουμε το `reborrow_mut`.
/// - Πάρτε το `self` με αναφορά και το (implicitly) επιστρέφει τη διάρκεια ζωής αυτής της αναφοράς, αντί για τη διάρκεια ζωής που φέρει το `BorrowType`.
/// Με αυτόν τον τρόπο, ο ελεγκτής δανεισμού εγγυάται ότι το `NodeRef` παραμένει δανειζόμενο όσο χρησιμοποιείται η επιστρεφόμενη αναφορά.
///   Οι μέθοδοι που υποστηρίζουν το ένθετο κάμπτουν αυτόν τον κανόνα επιστρέφοντας έναν ακατέργαστο δείκτη, δηλαδή μια αναφορά χωρίς καμία διάρκεια ζωής.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Ο αριθμός των επιπέδων που διαχωρίζονται ο κόμβος και το επίπεδο των φύλλων, μια σταθερά του κόμβου που δεν μπορεί να περιγραφεί εξ ολοκλήρου από το `Type` και ότι ο ίδιος ο κόμβος δεν αποθηκεύεται.
    /// Πρέπει να αποθηκεύσουμε μόνο το ύψος του ριζικού κόμβου και να αντλήσουμε το ύψος κάθε άλλου κόμβου από αυτόν.
    /// Πρέπει να είναι μηδέν εάν το `Type` είναι `Leaf` και μη μηδέν εάν το `Type` είναι `Internal`.
    ///
    ///
    height: usize,
    /// Ο δείκτης προς το φύλλο ή τον εσωτερικό κόμβο.
    /// Ο ορισμός του `InternalNode` διασφαλίζει ότι ο δείκτης είναι έγκυρος.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Αποσυσκευάστε μια αναφορά κόμβου που συσκευάστηκε ως `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Εκθέτει τα δεδομένα ενός εσωτερικού κόμβου.
    ///
    /// Επιστρέφει ένα ακατέργαστο ptr για να αποφύγει την ακύρωση άλλων αναφορών σε αυτόν τον κόμβο.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // ΑΣΦΑΛΕΙΑ: ο τύπος στατικού κόμβου είναι `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Δανείζεται αποκλειστική πρόσβαση στα δεδομένα ενός εσωτερικού κόμβου.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Βρίσκει το μήκος του κόμβου.Αυτός είναι ο αριθμός των κλειδιών ή των τιμών.
    /// Ο αριθμός των άκρων είναι `len() + 1`.
    /// Σημειώστε ότι, παρά το γεγονός ότι είναι ασφαλές, η κλήση αυτής της λειτουργίας μπορεί να έχει την παρενέργεια της ακύρωσης μεταβλητών αναφορών που έχει δημιουργήσει μη ασφαλής κώδικας.
    ///
    pub fn len(&self) -> usize {
        // Βασικά, έχουμε πρόσβαση μόνο στο πεδίο `len` εδώ.
        // Εάν το BorrowType είναι marker::ValMut, ενδέχεται να υπάρχουν εκκρεμείς μεταβλητές αναφορές σε τιμές που δεν πρέπει να ακυρώσουμε.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Επιστρέφει τον αριθμό των επιπέδων που διαχωρίζονται ο κόμβος και τα φύλλα.
    /// Το μηδέν ύψος σημαίνει ότι ο κόμβος είναι το ίδιο το φύλλο.
    /// Εάν φωτογραφίζετε δέντρα με τη ρίζα στην κορυφή, ο αριθμός αναφέρει σε ποιο ύψος εμφανίζεται ο κόμβος.
    /// Εάν φωτογραφίζετε δέντρα με φύλλα στην κορυφή, ο αριθμός λέει πόσο ψηλά εκτείνεται το δέντρο πάνω από τον κόμβο.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Προσωρινά βγάζει μια άλλη, αμετάβλητη αναφορά στον ίδιο κόμβο.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Εκθέτει το τμήμα φύλλων οποιουδήποτε φύλλου ή εσωτερικού κόμβου.
    ///
    /// Επιστρέφει ένα ακατέργαστο ptr για να αποφύγει την ακύρωση άλλων αναφορών σε αυτόν τον κόμβο.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Ο κόμβος πρέπει να ισχύει για τουλάχιστον το τμήμα LeafNode.
        // Αυτό δεν αποτελεί αναφορά στον τύπο NodeRef, επειδή δεν γνωρίζουμε εάν πρέπει να είναι μοναδικό ή κοινόχρηστο.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Βρίσκει τον γονέα του τρέχοντος κόμβου.
    /// Επιστρέφει το `Ok(handle)` εάν ο τρέχων κόμβος έχει πραγματικά γονέα, όπου το `handle` δείχνει το edge του γονέα που δείχνει στον τρέχοντα κόμβο.
    ///
    /// Επιστρέφει το `Err(self)` εάν ο τρέχων κόμβος δεν έχει γονέα, επιστρέφοντας το αρχικό `NodeRef`.
    ///
    /// Το όνομα της μεθόδου προϋποθέτει ότι απεικονίζετε δέντρα με τον ριζικό κόμβο στην κορυφή.
    ///
    /// `edge.descend().ascend().unwrap()` και `node.ascend().unwrap().descend()` θα πρέπει και οι δύο, μετά την επιτυχία, να μην κάνουν τίποτα.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Πρέπει να χρησιμοποιήσουμε ακατέργαστους δείκτες σε κόμβους επειδή, εάν το BorrowType είναι marker::ValMut, ενδέχεται να υπάρχουν εκκρεμείς μεταβλητές αναφορές σε τιμές που δεν πρέπει να ακυρώσουμε.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Λάβετε υπόψη ότι το `self` πρέπει να είναι απεριόριστο.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Λάβετε υπόψη ότι το `self` πρέπει να είναι απεριόριστο.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Εκθέτει το τμήμα φύλλων οποιουδήποτε φύλλου ή εσωτερικού κόμβου σε ένα αμετάβλητο δέντρο.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // ΑΣΦΑΛΕΙΑ: δεν μπορεί να υπάρξει μεταβλητή αναφορά σε αυτό το δέντρο που δανείστηκε ως `Immut`.
        unsafe { &*ptr }
    }

    /// Δανείζεται μια προβολή στα πλήκτρα που είναι αποθηκευμένα στον κόμβο.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Παρόμοια με το `ascend`, λαμβάνει μια αναφορά στον γονικό κόμβο ενός κόμβου, αλλά επίσης αφαιρεί τον τρέχοντα κόμβο στη διαδικασία.
    /// Αυτό δεν είναι ασφαλές επειδή ο τρέχων κόμβος θα εξακολουθεί να είναι προσβάσιμος παρά την κατάργησή του.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Ασφαλώς ισχυρίζεται στον μεταγλωττιστή τις στατικές πληροφορίες ότι αυτός ο κόμβος είναι `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Μη ασφαλής ισχυρίζεται στον μεταγλωττιστή τις στατικές πληροφορίες ότι αυτός ο κόμβος είναι `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Προσωρινά βγάζει μια άλλη, μεταβλητή αναφορά στον ίδιο κόμβο.Προσοχή, καθώς αυτή η μέθοδος είναι πολύ επικίνδυνη, διπλασιάστε, καθώς μπορεί να μην φαίνεται αμέσως επικίνδυνη.
    ///
    /// Επειδή οι μεταβλητοί δείκτες μπορούν να περιπλανηθούν οπουδήποτε γύρω από το δέντρο, ο επιστρεφόμενος δείκτης μπορεί εύκολα να χρησιμοποιηθεί για να κάνει τον αρχικό δείκτη να κρέμεται, εκτός ορίων ή μη έγκυρος σύμφωνα με τους κανόνες στοίβας δανεισμού.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) Εξετάστε το ενδεχόμενο να προσθέσετε μια άλλη παράμετρο τύπου στο `NodeRef` που περιορίζει τη χρήση μεθόδων πλοήγησης σε ανανεωμένους δείκτες, αποτρέποντας αυτήν την ασφάλεια.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Δανείζεται αποκλειστική πρόσβαση στο τμήμα φύλλων οποιουδήποτε φύλλου ή εσωτερικού κόμβου.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // ΑΣΦΑΛΕΙΑ: έχουμε αποκλειστική πρόσβαση σε ολόκληρο τον κόμβο.
        unsafe { &mut *ptr }
    }

    /// Προσφέρει αποκλειστική πρόσβαση στο τμήμα φύλλων οποιουδήποτε φύλλου ή εσωτερικού κόμβου.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // ΑΣΦΑΛΕΙΑ: έχουμε αποκλειστική πρόσβαση σε ολόκληρο τον κόμβο.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Δανείζεται αποκλειστική πρόσβαση σε ένα στοιχείο του χώρου αποθήκευσης κλειδιών.
    ///
    /// # Safety
    /// `index` είναι στα όρια του 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // ΑΣΦΑΛΕΙΑ: ο καλών δεν θα μπορεί να καλέσει περαιτέρω μεθόδους για τον εαυτό του
        // έως ότου απορριφθεί η αναφορά key slice, καθώς έχουμε μοναδική πρόσβαση για όλη τη διάρκεια του δανεισμού.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Δανείζεται αποκλειστική πρόσβαση σε ένα στοιχείο ή ένα κομμάτι της περιοχής αποθήκευσης αξίας του κόμβου.
    ///
    /// # Safety
    /// `index` είναι στα όρια του 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // ΑΣΦΑΛΕΙΑ: ο καλών δεν θα μπορεί να καλέσει περαιτέρω μεθόδους για τον εαυτό του
        // έως ότου απορριφθεί η τιμή αναφοράς, καθώς έχουμε μοναδική πρόσβαση για τη διάρκεια του δανεισμού.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Δανείζεται αποκλειστική πρόσβαση σε ένα στοιχείο ή τμήμα της περιοχής αποθήκευσης του κόμβου για περιεχόμενο edge.
    ///
    /// # Safety
    /// `index` είναι στα όρια του 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // ΑΣΦΑΛΕΙΑ: ο καλών δεν θα μπορεί να καλέσει περαιτέρω μεθόδους για τον εαυτό του
        // έως ότου απορριφθεί η αναφορά slice edge, καθώς έχουμε μοναδική πρόσβαση για όλη τη διάρκεια του δανεισμού.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Ο κόμβος έχει περισσότερα από `idx` αρχικοποιημένα στοιχεία.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Δημιουργούμε μόνο μια αναφορά στο ένα στοιχείο που μας ενδιαφέρει, για να αποφύγουμε το ψευδώνυμο με εκκρεμείς αναφορές σε άλλα στοιχεία, ιδίως αυτά που επέστρεψαν στον καλούντα σε προηγούμενες επαναλήψεις.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Πρέπει να εξαναγκάσουμε σε δείκτες συστοιχίας χωρίς μέγεθος λόγω του ζητήματος Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Δανείζεται αποκλειστική πρόσβαση στο μήκος του κόμβου.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Ορίζει τον σύνδεσμο του κόμβου στο γονικό του edge, χωρίς να ακυρώνει άλλες αναφορές στον κόμβο.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Διαγράφει τον σύνδεσμο της ρίζας με τον γονικό του edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Προσθέτει ένα ζεύγος τιμών-κλειδιών στο τέλος του κόμβου.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Κάθε στοιχείο που επιστρέφεται από το `range` είναι ένα έγκυρο ευρετήριο edge για τον κόμβο.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Προσθέτει ένα ζεύγος κλειδιού-τιμής και ένα edge για μετάβαση στα δεξιά αυτού του ζεύγους, στο τέλος του κόμβου.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Ελέγχει εάν ένας κόμβος είναι ένας κόμβος `Internal` ή ένας κόμβος `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Μια αναφορά σε ένα συγκεκριμένο ζεύγος κλειδιού-τιμής ή edge μέσα σε έναν κόμβο.
/// Η παράμετρος `Node` πρέπει να είναι `NodeRef`, ενώ το `Type` μπορεί να είναι `KV` (που σημαίνει λαβή σε ζεύγος κλειδιού-τιμής) ή `Edge` (που σημαίνει λαβή σε edge).
///
/// Σημειώστε ότι ακόμη και οι κόμβοι `Leaf` μπορούν να έχουν λαβές `Edge`.
/// Αντί να αντιπροσωπεύουν ένα δείκτη σε έναν θυγατρικό κόμβο, αυτά αντιπροσωπεύουν τους χώρους όπου οι θυγατρικοί δείκτες θα πήγαιναν ανάμεσα στα ζεύγη τιμών-κλειδιών.
/// Για παράδειγμα, σε έναν κόμβο με μήκος 2, θα υπάρχουν 3 πιθανές τοποθεσίες edge, μία στα αριστερά του κόμβου, μία μεταξύ των δύο ζευγών και μία στα δεξιά του κόμβου.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Δεν χρειαζόμαστε την πλήρη γενικότητα του `#[derive(Clone)]`, καθώς η μόνη φορά που το `Node` θα είναι "Clone"able είναι όταν πρόκειται για αμετάβλητη αναφορά και επομένως `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Ανακτά τον κόμβο που περιέχει το ζεύγος edge ή το κλειδί-τιμή στην οποία δείχνει η λαβή.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Επιστρέφει τη θέση αυτής της λαβής στον κόμβο.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Δημιουργεί μια νέα λαβή σε ένα ζεύγος τιμών-κλειδιών στο `node`.
    /// Μη ασφαλές επειδή ο καλών πρέπει να διασφαλίσει ότι `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Θα μπορούσε να είναι μια δημόσια εφαρμογή του PartialEq, αλλά χρησιμοποιείται μόνο σε αυτήν την ενότητα.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Αφαιρεί προσωρινά μια άλλη, αμετάβλητη λαβή στην ίδια θέση.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Δεν μπορούμε να χρησιμοποιήσουμε το Handle::new_kv ή το Handle::new_edge επειδή δεν γνωρίζουμε τον τύπο μας
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Ασφαλώς ισχυρίζεται στον μεταγλωττιστή τις στατικές πληροφορίες ότι ο κόμβος της λαβής είναι `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Αφαιρεί προσωρινά μια άλλη, μεταβλητή λαβή στην ίδια θέση.
    /// Προσοχή, καθώς αυτή η μέθοδος είναι πολύ επικίνδυνη, διπλασιάστε, καθώς μπορεί να μην φαίνεται αμέσως επικίνδυνη.
    ///
    ///
    /// Για λεπτομέρειες, ανατρέξτε στο `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Δεν μπορούμε να χρησιμοποιήσουμε το Handle::new_kv ή το Handle::new_edge επειδή δεν γνωρίζουμε τον τύπο μας
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Δημιουργεί μια νέα λαβή σε ένα edge στο `node`.
    /// Μη ασφαλές επειδή ο καλών πρέπει να διασφαλίσει ότι `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Δεδομένου ενός ευρετηρίου edge όπου θέλουμε να εισαγάγουμε σε έναν κόμβο γεμάτο χωρητικότητα, υπολογίζει έναν λογικό δείκτη KV ενός σημείου διαχωρισμού και πού να εκτελέσουμε την εισαγωγή.
///
/// Ο στόχος του διαχωριστικού σημείου είναι να καταλήξει το κλειδί και η τιμή του σε έναν γονικό κόμβο.
/// τα πλήκτρα, οι τιμές και οι άκρες στα αριστερά του σημείου διαχωρισμού γίνονται το αριστερό παιδί・
/// τα κλειδιά, οι τιμές και οι άκρες στα δεξιά του σημείου διαχωρισμού γίνονται το σωστό παιδί.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust τεύχος #74834 προσπαθεί να εξηγήσει αυτούς τους συμμετρικούς κανόνες.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Εισάγει ένα νέο ζεύγος κλειδιού-τιμής μεταξύ των ζευγών κλειδιού-τιμής δεξιά και αριστερά αυτού του edge.
    /// Αυτή η μέθοδος προϋποθέτει ότι υπάρχει αρκετός χώρος στον κόμβο για να χωρέσει το νέο ζεύγος.
    ///
    /// Ο επιστρεφόμενος δείκτης δείχνει την τιμή που έχει εισαχθεί.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Εισάγει ένα νέο ζεύγος κλειδιού-τιμής μεταξύ των ζευγών κλειδιού-τιμής δεξιά και αριστερά αυτού του edge.
    /// Αυτή η μέθοδος χωρίζει τον κόμβο εάν δεν υπάρχει αρκετός χώρος.
    ///
    /// Ο επιστρεφόμενος δείκτης δείχνει την τιμή που έχει εισαχθεί.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Διορθώνει το γονικό δείκτη και το ευρετήριο στον θυγατρικό κόμβο στον οποίο συνδέεται αυτό το edge.
    /// Αυτό είναι χρήσιμο όταν έχει αλλάξει η σειρά των άκρων,
    fn correct_parent_link(self) {
        // Δημιουργήστε backpointer χωρίς να ακυρώσετε άλλες αναφορές στον κόμβο.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Εισάγει ένα νέο ζεύγος κλειδιού-τιμής και ένα edge που θα πάει δεξιά από αυτό το νέο ζεύγος μεταξύ αυτού του edge και του ζεύγους κλειδιού-τιμής στα δεξιά αυτού του edge.
    /// Αυτή η μέθοδος προϋποθέτει ότι υπάρχει αρκετός χώρος στον κόμβο για να χωρέσει το νέο ζεύγος.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Εισάγει ένα νέο ζεύγος κλειδιού-τιμής και ένα edge που θα πάει δεξιά από αυτό το νέο ζεύγος μεταξύ αυτού του edge και του ζεύγους κλειδιού-τιμής στα δεξιά αυτού του edge.
    /// Αυτή η μέθοδος χωρίζει τον κόμβο εάν δεν υπάρχει αρκετός χώρος.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Εισάγει ένα νέο ζεύγος κλειδιού-τιμής μεταξύ των ζευγών κλειδιού-τιμής δεξιά και αριστερά αυτού του edge.
    /// Αυτή η μέθοδος διαχωρίζει τον κόμβο εάν δεν υπάρχει αρκετός χώρος και προσπαθεί να εισαγάγει το διαχωρισμένο τμήμα στον γονικό κόμβο αναδρομικά, έως ότου επιτευχθεί η ρίζα.
    ///
    ///
    /// Εάν το αποτέλεσμα που επιστρέφεται είναι `Fit`, ο κόμβος της λαβής του μπορεί να είναι ο κόμβος αυτού του edge ή ένας πρόγονος.
    /// Εάν το αποτέλεσμα που επιστρέφεται είναι `Split`, το πεδίο `left` θα είναι ο ριζικός κόμβος.
    /// Ο επιστρεφόμενος δείκτης δείχνει την τιμή που έχει εισαχθεί.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Βρίσκει τον κόμβο που επισημαίνει αυτό το edge.
    ///
    /// Το όνομα της μεθόδου προϋποθέτει ότι απεικονίζετε δέντρα με τον ριζικό κόμβο στην κορυφή.
    ///
    /// `edge.descend().ascend().unwrap()` και `node.ascend().unwrap().descend()` θα πρέπει και οι δύο, μετά την επιτυχία, να μην κάνουν τίποτα.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Πρέπει να χρησιμοποιήσουμε ακατέργαστους δείκτες σε κόμβους επειδή, εάν το BorrowType είναι marker::ValMut, ενδέχεται να υπάρχουν εκκρεμείς μεταβλητές αναφορές σε τιμές που δεν πρέπει να ακυρώσουμε.
        // Δεν υπάρχει καμία ανησυχία για την πρόσβαση στο πεδίο ύψους επειδή αντιγράφεται αυτή η τιμή.
        // Λάβετε υπόψη ότι, όταν ο δείκτης κόμβου δεν γίνεται αναφορά, έχουμε πρόσβαση στον πίνακα άκρων με μια αναφορά (ζήτημα Rust #73987) και ακυρώνουμε τυχόν άλλες αναφορές σε ή μέσα στον πίνακα, σε περίπτωση που υπάρχει.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Δεν μπορούμε να καλέσουμε ξεχωριστές μεθόδους κλειδιού και τιμής, επειδή η κλήση του δεύτερου ακυρώνει την αναφορά που επιστρέφεται από την πρώτη.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Αντικαταστήστε το κλειδί και την τιμή στην οποία αναφέρεται η λαβή KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Βοηθά τις υλοποιήσεις του `split` για ένα συγκεκριμένο `NodeType`, φροντίζοντας για τα φύλλα δεδομένων.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Διαχωρίζει τον υποκείμενο κόμβο σε τρία μέρη:
    ///
    /// - Ο κόμβος περικόπτεται για να περιέχει μόνο τα ζεύγη τιμών κλειδιού στα αριστερά αυτής της λαβής.
    /// - Το κλειδί και η τιμή που δείχνουν αυτή η λαβή εξάγονται.
    /// - Όλα τα ζεύγη κλειδιών-τιμών στα δεξιά αυτής της λαβής τοποθετούνται σε έναν νέο κόμβο.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Αφαιρεί το ζεύγος κλειδιού-τιμής που δείχνει η λαβή και το επιστρέφει, μαζί με το edge στο οποίο κατέρρευσε το ζεύγος κλειδιού-τιμής.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Διαχωρίζει τον υποκείμενο κόμβο σε τρία μέρη:
    ///
    /// - Ο κόμβος περικόπτεται ώστε να περιέχει μόνο τα άκρα και ζεύγη κλειδιού-τιμής στα αριστερά αυτής της λαβής.
    /// - Το κλειδί και η τιμή που δείχνουν αυτή η λαβή εξάγονται.
    /// - Όλα τα άκρα και τα ζεύγη τιμών-κλειδιών στα δεξιά αυτής της λαβής τοποθετούνται σε έναν νέο κόμβο.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Αντιπροσωπεύει μια συνεδρία για την αξιολόγηση και την εκτέλεση μιας λειτουργίας εξισορρόπησης γύρω από ένα εσωτερικό ζεύγος κλειδιού-τιμής.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Επιλέγει ένα πλαίσιο εξισορρόπησης που περιλαμβάνει τον κόμβο ως παιδί, έτσι μεταξύ του KV αμέσως προς τα αριστερά ή προς τα δεξιά στον γονικό κόμβο.
    /// Επιστρέφει ένα `Err` εάν δεν υπάρχει γονέας.
    /// Panics εάν ο γονέας είναι άδειος.
    ///
    /// Προτιμά την αριστερή πλευρά, να είναι βέλτιστη εάν ο δεδομένος κόμβος είναι κάπως υποβρύχιος, που σημαίνει εδώ μόνο ότι έχει λιγότερα στοιχεία από τον αριστερό αδελφό του και από τον δεξιό αδελφό του, εάν υπάρχουν.
    /// Σε αυτήν την περίπτωση, η συγχώνευση με τον αριστερό αδερφό είναι ταχύτερη, καθώς χρειάζεται μόνο να μετακινήσουμε τα στοιχεία N του κόμβου, αντί να τα μετατοπίσουμε προς τα δεξιά και να μετακινήσουμε περισσότερα από τα στοιχεία N μπροστά.
    /// Η κλοπή από τον αριστερό αδελφό είναι επίσης συνήθως ταχύτερη, καθώς χρειάζεται μόνο να μετατοπίσουμε τα στοιχεία N του κόμβου προς τα δεξιά, αντί να μετατοπίζουμε τουλάχιστον N από τα στοιχεία του αδελφού προς τα αριστερά.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Επιστρέφει εάν είναι δυνατή η συγχώνευση, δηλαδή εάν υπάρχει αρκετός χώρος σε έναν κόμβο για να συνδυάσει το κεντρικό KV και με τους δύο γειτονικούς θυγατρικούς κόμβους.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Εκτελεί συγχώνευση και αφήνει ένα κλείσιμο να αποφασίσει τι θα επιστρέψει.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // ΑΣΦΑΛΕΙΑ: το ύψος των κόμβων που συγχωνεύονται είναι ένα κάτω από το ύψος
                // του κόμβου αυτού του edge, έτσι πάνω από το μηδέν, οπότε είναι εσωτερικά.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Συγχώνευση του ζεύγους κλειδιού-τιμής του γονέα και των δύο γειτονικών θυγατρικών κόμβων στον αριστερό θυγατρικό κόμβο και επιστρέφει τον συρρικνωμένο γονικό κόμβο.
    ///
    ///
    /// Panics εκτός αν εμείς `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Συγχωνεύει το ζεύγος κλειδιού-τιμής του γονέα και τους δύο γειτονικούς θυγατρικούς κόμβους στον αριστερό θυγατρικό κόμβο και επιστρέφει αυτόν τον θυγατρικό κόμβο.
    ///
    ///
    /// Panics εκτός αν εμείς `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Συγχώνευση του ζεύγους κλειδιού-τιμής του γονέα και των δύο γειτονικών θυγατρικών κόμβων στον αριστερό θυγατρικό κόμβο και επιστρέφει τη λαβή edge σε αυτόν τον θυγατρικό κόμβο όπου κατέληξε το θυγατρικό edge,
    ///
    ///
    /// Panics εκτός αν εμείς `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Αφαιρεί ένα ζεύγος κλειδιού-τιμής από το αριστερό παιδί και το τοποθετεί στο χώρο αποθήκευσης κλειδιού-τιμής του γονέα, ενώ ωθεί το παλιό ζεύγος κλειδιού-τιμής γονέα στο σωστό παιδί.
    ///
    /// Επιστρέφει μια λαβή στο edge στο δεξί παιδί που αντιστοιχεί στο σημείο όπου κατέληξε το αρχικό edge που καθορίστηκε από το `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Αφαιρεί ένα ζεύγος κλειδιού-τιμής από το δεξί παιδί και το τοποθετεί στην αποθήκευση κλειδιού-τιμής του γονέα, ενώ ωθεί το παλιό ζεύγος κλειδιού-τιμής στο αριστερό παιδί.
    ///
    /// Επιστρέφει μια λαβή στο edge στο αριστερό παιδί που καθορίζεται από το `track_left_edge_idx`, το οποίο δεν μετακινήθηκε.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Αυτό κλέβει παρόμοιο με το `steal_left` αλλά κλέβει πολλά στοιχεία ταυτόχρονα.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Βεβαιωθείτε ότι μπορούμε να κλέψουμε με ασφάλεια.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Μετακίνηση δεδομένων φύλλων.
            {
                // Κάντε χώρο για κλεμμένα στοιχεία στο σωστό παιδί.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Μετακίνηση στοιχείων από το αριστερό παιδί στο δεξί.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Μετακινήστε το αριστερότερο κλεμμένο ζευγάρι στον γονέα.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Μετακινήστε το ζεύγος κλειδιού-τιμής γονέα στο σωστό παιδί.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Κάντε χώρο για κλεμμένες άκρες.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Κλέψτε τις άκρες.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Ο συμμετρικός κλώνος του `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Βεβαιωθείτε ότι μπορούμε να κλέψουμε με ασφάλεια.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Μετακίνηση δεδομένων φύλλων.
            {
                // Μετακινήστε το πιο κλεμμένο ζευγάρι στον γονέα.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Μετακινήστε το ζεύγος κλειδιού-τιμής γονέα στο αριστερό παιδί.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Μετακίνηση στοιχείων από το δεξί παιδί στο αριστερό.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Γεμίστε το κενό όπου υπήρχαν κλεμμένα στοιχεία.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Κλέψτε τις άκρες.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Συμπληρώστε το κενό όπου υπήρχαν κλεμμένες άκρες.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Καταργεί τυχόν στατικές πληροφορίες που ισχυρίζονται ότι αυτός ο κόμβος είναι κόμβος `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Καταργεί τυχόν στατικές πληροφορίες που ισχυρίζονται ότι αυτός ο κόμβος είναι κόμβος `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Ελέγχει εάν ο υποκείμενος κόμβος είναι κόμβος `Internal` ή κόμβος `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Μετακινήστε το επίθημα μετά το `self` από έναν κόμβο σε έναν άλλο.Το `right` πρέπει να είναι κενό.
    /// Το πρώτο edge του `right` παραμένει αμετάβλητο.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Αποτέλεσμα εισαγωγής, όταν ένας κόμβος έπρεπε να επεκταθεί πέραν της χωρητικότητάς του.
pub struct SplitResult<'a, K, V, NodeType> {
    // Τροποποιημένος κόμβος σε υπάρχον δέντρο με στοιχεία και άκρα που ανήκουν στα αριστερά του `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Κάποιο κλειδί και τιμή διαχωρίζονται, για να εισαχθούν αλλού.
    pub kv: (K, V),
    // Ιδιοκτήτης, μη συνδεδεμένος, νέος κόμβος με στοιχεία και άκρα που ανήκουν στα δεξιά του `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Εάν οι αναφορές κόμβων αυτού του τύπου δανεισμού επιτρέπουν τη διέλευση σε άλλους κόμβους στο δέντρο.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Το Traversal δεν είναι απαραίτητο, συμβαίνει χρησιμοποιώντας το αποτέλεσμα του `borrow_mut`.
        // Απενεργοποιώντας τη διασταύρωση και δημιουργώντας μόνο νέες αναφορές σε ρίζες, γνωρίζουμε ότι κάθε αναφορά του τύπου `Owned` αφορά έναν ριζικό κόμβο.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Εισάγει μια τιμή σε ένα κομμάτι των αρχικοποιημένων στοιχείων που ακολουθείται από ένα μη αρχικοποιημένο στοιχείο.
///
/// # Safety
/// Το slice έχει περισσότερα από `idx` στοιχεία.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Αφαιρεί και επιστρέφει μια τιμή από ένα κομμάτι όλων των αρχικοποιημένων στοιχείων, αφήνοντας πίσω ένα μη αρχικοποιημένο στοιχείο.
///
///
/// # Safety
/// Το slice έχει περισσότερα από `idx` στοιχεία.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Μετατοπίζει τα στοιχεία σε θέσεις `distance` σε φέτα προς τα αριστερά.
///
/// # Safety
/// Η φέτα έχει τουλάχιστον στοιχεία `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Μετατοπίζει τα στοιχεία σε θέση `distance` σε φέτες προς τα δεξιά.
///
/// # Safety
/// Η φέτα έχει τουλάχιστον στοιχεία `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Μετακινεί όλες τις τιμές από ένα κομμάτι αρχικοποιημένων στοιχείων σε ένα κομμάτι μη αρχικοποιημένων στοιχείων, αφήνοντας πίσω το `src` ως όλα τα μη αρχικοποιημένα.
///
/// Λειτουργεί όπως το `dst.copy_from_slice(src)` αλλά δεν απαιτεί το `T` να είναι `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;