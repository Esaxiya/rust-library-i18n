use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Παίρνει προσωρινά ένα άλλο, αμετάβλητο ισοδύναμο του ίδιου εύρους.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Βρίσκει τις ξεχωριστές άκρες των φύλλων που οριοθετούν ένα καθορισμένο εύρος σε ένα δέντρο.
    /// Επιστρέφει είτε ένα ζευγάρι διαφορετικών λαβών στο ίδιο δέντρο ή ένα ζευγάρι κενών επιλογών.
    ///
    /// # Safety
    ///
    /// Εκτός αν το `BorrowType` είναι `Immut`, μην χρησιμοποιείτε τις διπλές λαβές για να επισκεφτείτε το ίδιο KV δύο φορές.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Ισοδύναμο με `(root1.first_leaf_edge(), root2.last_leaf_edge())` αλλά πιο αποτελεσματικό.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Βρίσκει το ζεύγος των άκρων των φύλλων που οριοθετούν ένα συγκεκριμένο εύρος σε ένα δέντρο.
    ///
    /// Το αποτέλεσμα έχει νόημα μόνο εάν το δέντρο έχει ταξινομηθεί με κλειδί, όπως το δέντρο σε `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // ΑΣΦΑΛΕΙΑ: ο τύπος δανεισμού μας είναι αμετάβλητος.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Βρίσκει το ζευγάρι των άκρων των φύλλων που οριοθετούν ένα ολόκληρο δέντρο.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Διαχωρίζει μια μοναδική αναφορά σε ένα ζευγάρι άκρων φύλλων οριοθετώντας ένα καθορισμένο εύρος.
    /// Το αποτέλεσμα είναι μη μοναδικές αναφορές που επιτρέπουν τη μετάλλαξη (some), η οποία πρέπει να χρησιμοποιηθεί προσεκτικά.
    ///
    /// Το αποτέλεσμα έχει νόημα μόνο εάν το δέντρο έχει ταξινομηθεί με κλειδί, όπως το δέντρο σε `BTreeMap`.
    ///
    ///
    /// # Safety
    /// Μην χρησιμοποιείτε τις διπλές λαβές για να επισκεφτείτε το ίδιο KV δύο φορές.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Διαχωρίζει μια μοναδική αναφορά σε ένα ζευγάρι άκρων φύλλων που οριοθετούν το πλήρες εύρος του δέντρου.
    /// Τα αποτελέσματα είναι μη μοναδικές αναφορές που επιτρέπουν τη μετάλλαξη (μόνο των τιμών), επομένως πρέπει να χρησιμοποιούνται με προσοχή.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Αντιγράφουμε εδώ το ριζικό NodeRef-δεν θα επισκεφτούμε ποτέ το ίδιο KV δύο φορές και δεν θα καταλήξουμε σε αλληλεπικαλυπτόμενες αναφορές τιμών.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Διαχωρίζει μια μοναδική αναφορά σε ένα ζευγάρι άκρων φύλλων που οριοθετούν το πλήρες εύρος του δέντρου.
    /// Τα αποτελέσματα είναι μη μοναδικές αναφορές που επιτρέπουν μαζικά καταστροφικές μεταλλάξεις, επομένως πρέπει να χρησιμοποιούνται με τη μέγιστη προσοχή.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Αντιγράφουμε εδώ το root NodeRef-δεν θα έχουμε ποτέ πρόσβαση σε αυτόν με τρόπο που επικαλύπτει τις αναφορές που λαμβάνονται από το root.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Λαμβάνοντας υπόψη μια λαβή φύλλου edge, επιστρέφει το [`Result::Ok`] με μια λαβή στο γειτονικό KV στη δεξιά πλευρά, το οποίο βρίσκεται είτε στον ίδιο κόμβο φύλλων είτε σε έναν κόμβο προγόνων.
    ///
    /// Εάν το φύλλο edge είναι το τελευταίο στο δέντρο, επιστρέφει το [`Result::Err`] με τον ριζικό κόμβο.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Λαμβάνοντας υπόψη μια λαβή φύλλου edge, επιστρέφει το [`Result::Ok`] με μια λαβή στο γειτονικό KV στην αριστερή πλευρά, το οποίο βρίσκεται είτε στον ίδιο κόμβο φύλλων είτε σε έναν κόμβο προγόνων.
    ///
    /// Εάν το φύλλο edge είναι το πρώτο στο δέντρο, επιστρέφει το [`Result::Err`] με τον ριζικό κόμβο.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Λαμβάνοντας υπόψη μια εσωτερική λαβή edge, επιστρέφει το [`Result::Ok`] με μια λαβή στο γειτονικό KV στη δεξιά πλευρά, η οποία βρίσκεται είτε στον ίδιο εσωτερικό κόμβο είτε σε έναν πρόγονο κόμβο.
    ///
    /// Εάν το εσωτερικό edge είναι το τελευταίο στο δέντρο, επιστρέφει το [`Result::Err`] με τον ριζικό κόμβο.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Λαμβάνοντας υπόψη μια λαβή φύλλου edge σε ένα δέντρο που πεθαίνει, επιστρέφει το επόμενο φύλλο edge στη δεξιά πλευρά, και το ζεύγος κλειδιού-τιμής στο μεταξύ, το οποίο είναι είτε στον ίδιο κόμβο φύλλων, σε έναν κόμβο προγόνων ή ανύπαρκτο.
    ///
    ///
    /// Αυτή η μέθοδος αφαιρεί επίσης οποιοδήποτε node(s) φτάνει στο τέλος του.
    /// Αυτό σημαίνει ότι εάν δεν υπάρχει πλέον ζεύγος κλειδιού-τιμής, ολόκληρο το υπόλοιπο του δέντρου θα έχει αφαιρεθεί και δεν έχει απομείνει τίποτα για επιστροφή.
    ///
    /// # Safety
    /// Το δεδομένο edge δεν πρέπει να έχει επιστραφεί προηγουμένως από το αντίστοιχο `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Λαμβάνοντας υπόψη μια λαβή φύλλου edge σε ένα δέντρο που πεθαίνει, επιστρέφει το επόμενο φύλλο edge στην αριστερή πλευρά και το ζεύγος κλειδιού-τιμής στο ενδιάμεσο, το οποίο βρίσκεται είτε στον ίδιο κόμβο φύλλων, σε έναν κόμβο προγόνων ή ανύπαρκτο.
    ///
    ///
    /// Αυτή η μέθοδος αφαιρεί επίσης οποιοδήποτε node(s) φτάνει στο τέλος του.
    /// Αυτό σημαίνει ότι εάν δεν υπάρχει πλέον ζεύγος κλειδιού-τιμής, ολόκληρο το υπόλοιπο του δέντρου θα έχει αφαιρεθεί και δεν έχει απομείνει τίποτα για επιστροφή.
    ///
    /// # Safety
    /// Το δεδομένο edge δεν πρέπει να έχει επιστραφεί προηγουμένως από το αντίστοιχο `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Αφαιρεί έναν σωρό κόμβων από το φύλλο μέχρι τη ρίζα.
    /// Αυτός είναι ο μόνος τρόπος για να αφαιρεθεί το υπόλοιπο ενός δέντρου αφού τα `deallocating_next` και `deallocating_next_back` χτυπήσουν και στις δύο πλευρές του δέντρου και έπληξαν το ίδιο edge.
    /// Καθώς προορίζεται μόνο για κλήση όταν έχουν επιστραφεί όλα τα πλήκτρα και οι τιμές, δεν γίνεται εκκαθάριση σε κανένα από τα κλειδιά ή τις τιμές.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Μετακινεί τη λαβή φύλλου edge στο επόμενο φύλλο edge και επιστρέφει αναφορές στο κλειδί και την τιμή μεταξύ τους.
    ///
    ///
    /// # Safety
    /// Πρέπει να υπάρχει ένα άλλο KV στην κατεύθυνση που διανύθηκε.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Μετακινεί τη λαβή φύλλου edge στο προηγούμενο φύλλο edge και επιστρέφει αναφορές στο κλειδί και την τιμή μεταξύ τους.
    ///
    ///
    /// # Safety
    /// Πρέπει να υπάρχει ένα άλλο KV στην κατεύθυνση που διανύθηκε.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Μετακινεί τη λαβή φύλλου edge στο επόμενο φύλλο edge και επιστρέφει αναφορές στο κλειδί και την τιμή μεταξύ τους.
    ///
    ///
    /// # Safety
    /// Πρέπει να υπάρχει ένα άλλο KV στην κατεύθυνση που διανύθηκε.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Το τελευταίο είναι πιο γρήγορο, σύμφωνα με τα κριτήρια αξιολόγησης.
        kv.into_kv_valmut()
    }

    /// Μετακινεί τη λαβή φύλλου edge στο προηγούμενο φύλλο και επιστρέφει αναφορές στο κλειδί και την τιμή μεταξύ τους.
    ///
    ///
    /// # Safety
    /// Πρέπει να υπάρχει ένα άλλο KV στην κατεύθυνση που διανύθηκε.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Το τελευταίο είναι πιο γρήγορο, σύμφωνα με τα κριτήρια αξιολόγησης.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Μετακινεί τη λαβή φύλλου edge στο επόμενο φύλλο edge και επιστρέφει το κλειδί και την τιμή ενδιάμεσα, αφαιρώντας οποιονδήποτε κόμβο που αφήνεται πίσω, αφήνοντας τον αντίστοιχο edge στον γονικό κόμβο του.
    ///
    /// # Safety
    /// - Πρέπει να υπάρχει ένα άλλο KV στην κατεύθυνση που διανύθηκε.
    /// - Αυτό το KV δεν είχε επιστραφεί προηγουμένως από το αντίστοιχο `next_back_unchecked` σε οποιοδήποτε αντίγραφο των λαβών που χρησιμοποιήθηκαν για να διασχίσει το δέντρο.
    ///
    /// Ο μόνος ασφαλής τρόπος για να προχωρήσετε με την ενημερωμένη λαβή είναι να το συγκρίνετε, να το αφήσετε, να καλέσετε ξανά αυτήν τη μέθοδο σύμφωνα με τις συνθήκες ασφαλείας του ή να καλέσετε το αντίστοιχο `next_back_unchecked` υπό τις συνθήκες ασφαλείας του.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Μετακινεί τη λαβή φύλλου edge στο προηγούμενο φύλλο edge και επιστρέφει το κλειδί και την τιμή ενδιάμεσα, αφαιρώντας οποιονδήποτε κόμβο που αφήνεται πίσω, αφήνοντας τον αντίστοιχο edge στον γονικό κόμβο του.
    ///
    /// # Safety
    /// - Πρέπει να υπάρχει ένα άλλο KV στην κατεύθυνση που διανύθηκε.
    /// - Αυτό το φύλλο edge δεν είχε επιστραφεί προηγουμένως από το αντίστοιχο `next_unchecked` σε οποιοδήποτε αντίγραφο των λαβών που χρησιμοποιήθηκαν για να διασχίσει το δέντρο.
    ///
    /// Ο μόνος ασφαλής τρόπος για να προχωρήσετε με την ενημερωμένη λαβή είναι να το συγκρίνετε, να το αφήσετε, να καλέσετε ξανά αυτήν τη μέθοδο σύμφωνα με τις συνθήκες ασφαλείας του ή να καλέσετε το αντίστοιχο `next_unchecked` υπό τις συνθήκες ασφαλείας του.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Επιστρέφει το αριστερό φύλλο edge μέσα ή κάτω από έναν κόμβο, με άλλα λόγια, το edge που χρειάζεστε πρώτα κατά την πλοήγηση προς τα εμπρός (ή τελευταίο κατά την πλοήγηση προς τα πίσω).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Επιστρέφει το δεξιότερο φύλλο edge μέσα ή κάτω από έναν κόμβο, με άλλα λόγια, το edge που χρειάζεστε τελευταίο κατά την πλοήγηση προς τα εμπρός (ή πρώτα κατά την πλοήγηση προς τα πίσω).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Επισκέπτεται τους κόμβους των φύλλων και τα εσωτερικά KV κατά σειρά ανερχόμενων κλειδιών και επίσης επισκέπτεται τους εσωτερικούς κόμβους στο σύνολό τους σε πρώτη βάθος, πράγμα που σημαίνει ότι οι εσωτερικοί κόμβοι προηγούνται των μεμονωμένων KV και των θυγατρικών τους κόμβων.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Υπολογίζει τον αριθμό των στοιχείων σε ένα (υπο) δέντρο.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Επιστρέφει το φύλλο edge πιο κοντά σε ένα KV για προώθηση πλοήγησης.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Επιστρέφει το φύλλο edge που βρίσκεται πλησιέστερα σε KV για πλοήγηση προς τα πίσω.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}