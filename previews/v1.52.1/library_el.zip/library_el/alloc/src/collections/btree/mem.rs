use core::intrinsics;
use core::mem;
use core::ptr;

/// Αυτό αντικαθιστά την τιμή πίσω από τη μοναδική αναφορά `v` καλώντας τη σχετική λειτουργία.
///
///
/// Εάν εμφανιστεί ένα panic στο κλείσιμο `change`, ολόκληρη η διαδικασία θα ακυρωθεί.
#[allow(dead_code)] // διατηρήστε ως απεικόνιση και για χρήση future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Αυτό αντικαθιστά την τιμή πίσω από τη μοναδική αναφορά `v` καλώντας τη σχετική συνάρτηση και επιστρέφει ένα αποτέλεσμα που επιτεύχθηκε.
///
///
/// Εάν εμφανιστεί ένα panic στο κλείσιμο `change`, ολόκληρη η διαδικασία θα ακυρωθεί.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}