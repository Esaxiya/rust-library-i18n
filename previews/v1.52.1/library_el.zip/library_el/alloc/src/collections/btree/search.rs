use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Ένα αποκλειστικό όριο που πρέπει να αναζητήσετε, όπως το `Bound::Included(T)`.
    Included(T),
    /// Ένα αποκλειστικό όριο για αναζήτηση, όπως το `Bound::Excluded(T)`.
    Excluded(T),
    /// Ένα χωρίς όρους όριο, όπως το `Bound::Unbounded`.
    AllIncluded,
    /// Ένα άνευ όρων αποκλειστικό όριο.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Αναζητά ένα δεδομένο κλειδί σε ένα (υπο) δέντρο με επικεφαλής τον κόμβο, αναδρομικά.
    /// Επιστρέφει ένα `Found` με τη λαβή του αντίστοιχου KV, εάν υπάρχει.
    /// Διαφορετικά, επιστρέφει ένα `GoDown` με τη λαβή του φύλλου edge όπου ανήκει το κλειδί.
    ///
    /// Το αποτέλεσμα έχει νόημα μόνο εάν το δέντρο έχει ταξινομηθεί με κλειδί, όπως το δέντρο σε `BTreeMap`.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Κατεβαίνει στον πλησιέστερο κόμβο όπου το edge που ταιριάζει με το κάτω όριο του εύρους είναι διαφορετικό από το edge που ταιριάζει με το ανώτερο όριο, δηλαδή, ο πλησιέστερος κόμβος που περιέχει τουλάχιστον ένα κλειδί που περιέχεται στην περιοχή.
    ///
    ///
    /// Εάν βρεθεί, επιστρέφει ένα `Ok` με αυτόν τον κόμβο, το ζεύγος των δεικτών edge οριοθετεί το εύρος και το αντίστοιχο ζεύγος ορίων για τη συνέχιση της αναζήτησης στους θυγατρικούς κόμβους, σε περίπτωση που ο κόμβος είναι εσωτερικός.
    ///
    /// Εάν δεν βρεθεί, επιστρέφει ένα `Err` με το φύλλο edge να ταιριάζει σε ολόκληρη την περιοχή.
    ///
    /// Το αποτέλεσμα έχει νόημα μόνο εάν το δέντρο έχει παραγγελθεί με κλειδί.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Θα πρέπει να αποφεύγεται η επισήμανση αυτών των μεταβλητών.
        // Υποθέτουμε ότι τα όρια που αναφέρονται από το `range` παραμένουν τα ίδια, αλλά μια εφαρμογή αντιπαράθεσης θα μπορούσε να αλλάξει μεταξύ των κλήσεων (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Βρίσκει ένα edge στον κόμβο οριοθετώντας το κάτω όριο ενός εύρους.
    /// Επιστρέφει επίσης το κάτω όριο που θα χρησιμοποιηθεί για τη συνέχιση της αναζήτησης στον αντίστοιχο θυγατρικό κόμβο, εάν το `self` είναι ένας εσωτερικός κόμβος.
    ///
    ///
    /// Το αποτέλεσμα έχει νόημα μόνο εάν το δέντρο έχει παραγγελθεί με κλειδί.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Κλώνος `find_lower_bound_edge` για το άνω όριο.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Αναζητά ένα δεδομένο κλειδί στον κόμβο, χωρίς επανάληψη.
    /// Επιστρέφει ένα `Found` με τη λαβή του αντίστοιχου KV, εάν υπάρχει.
    /// Διαφορετικά, επιστρέφει ένα `GoDown` με τη λαβή του edge όπου μπορεί να βρεθεί το κλειδί (εάν ο κόμβος είναι εσωτερικός) ή όπου μπορεί να εισαχθεί το κλειδί.
    ///
    ///
    /// Το αποτέλεσμα έχει νόημα μόνο εάν το δέντρο έχει ταξινομηθεί με κλειδί, όπως το δέντρο σε `BTreeMap`.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Επιστρέφει είτε το ευρετήριο KV στον κόμβο στον οποίο υπάρχει το κλειδί (ή ένα ισοδύναμο), είτε το ευρετήριο edge όπου ανήκει το κλειδί.
    ///
    ///
    /// Το αποτέλεσμα έχει νόημα μόνο εάν το δέντρο έχει ταξινομηθεί με κλειδί, όπως το δέντρο σε `BTreeMap`.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Βρίσκει ένα ευρετήριο edge στον κόμβο οριοθετώντας το κάτω όριο ενός εύρους.
    /// Επιστρέφει επίσης το κάτω όριο που θα χρησιμοποιηθεί για τη συνέχιση της αναζήτησης στον αντίστοιχο θυγατρικό κόμβο, εάν το `self` είναι ένας εσωτερικός κόμβος.
    ///
    ///
    /// Το αποτέλεσμα έχει νόημα μόνο εάν το δέντρο έχει παραγγελθεί με κλειδί.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Κλώνος `find_lower_bound_index` για το άνω όριο.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}