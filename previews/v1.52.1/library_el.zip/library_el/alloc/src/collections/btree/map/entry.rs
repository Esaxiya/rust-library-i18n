use core::fmt::{self, Debug};
use core::marker::PhantomData;
use core::mem;

use super::super::borrow::DormantMutRef;
use super::super::node::{marker, Handle, InsertResult::*, NodeRef};
use super::BTreeMap;

use Entry::*;

/// Μια προβολή σε μία καταχώριση σε έναν χάρτη, η οποία μπορεί είτε να είναι κενή είτε να καταλαμβάνεται.
///
/// Αυτό το `enum` κατασκευάζεται από τη μέθοδο [`entry`] στο [`BTreeMap`].
///
/// [`entry`]: BTreeMap::entry
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Entry<'a, K: 'a, V: 'a> {
    /// Μια κενή καταχώριση.
    #[stable(feature = "rust1", since = "1.0.0")]
    Vacant(#[stable(feature = "rust1", since = "1.0.0")] VacantEntry<'a, K, V>),

    /// Κατειλημμένη είσοδος.
    #[stable(feature = "rust1", since = "1.0.0")]
    Occupied(#[stable(feature = "rust1", since = "1.0.0")] OccupiedEntry<'a, K, V>),
}

#[stable(feature = "debug_btree_map", since = "1.12.0")]
impl<K: Debug + Ord, V: Debug> Debug for Entry<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {
            Vacant(ref v) => f.debug_tuple("Entry").field(v).finish(),
            Occupied(ref o) => f.debug_tuple("Entry").field(o).finish(),
        }
    }
}

/// Μια προβολή σε μια κενή καταχώριση σε ένα `BTreeMap`.
/// Είναι μέρος του [`Entry`] enum.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VacantEntry<'a, K: 'a, V: 'a> {
    pub(super) key: K,
    pub(super) handle: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>,
    pub(super) dormant_map: DormantMutRef<'a, BTreeMap<K, V>>,

    // Να είστε αμετάβλητοι στα `K` και `V`
    pub(super) _marker: PhantomData<&'a mut (K, V)>,
}

#[stable(feature = "debug_btree_map", since = "1.12.0")]
impl<K: Debug + Ord, V> Debug for VacantEntry<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("VacantEntry").field(self.key()).finish()
    }
}

/// Μια προβολή σε μια κατεχόμενη καταχώριση σε ένα `BTreeMap`.
/// Είναι μέρος του [`Entry`] enum.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct OccupiedEntry<'a, K: 'a, V: 'a> {
    pub(super) handle: Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV>,
    pub(super) dormant_map: DormantMutRef<'a, BTreeMap<K, V>>,

    // Να είστε αμετάβλητοι στα `K` και `V`
    pub(super) _marker: PhantomData<&'a mut (K, V)>,
}

#[stable(feature = "debug_btree_map", since = "1.12.0")]
impl<K: Debug + Ord, V: Debug> Debug for OccupiedEntry<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("OccupiedEntry").field("key", self.key()).field("value", self.get()).finish()
    }
}

/// Το σφάλμα επέστρεψε από το [`try_insert`](BTreeMap::try_insert) όταν το κλειδί υπάρχει ήδη.
///
/// Περιέχει την καταλαμβανόμενη καταχώριση και την τιμή που δεν έχει εισαχθεί.
#[unstable(feature = "map_try_insert", issue = "82766")]
pub struct OccupiedError<'a, K: 'a, V: 'a> {
    /// Η καταχώριση στον χάρτη που είχε ήδη καταληφθεί.
    pub entry: OccupiedEntry<'a, K, V>,
    /// Η τιμή που δεν έχει εισαχθεί, επειδή η καταχώριση ήταν ήδη κατειλημμένη.
    pub value: V,
}

#[unstable(feature = "map_try_insert", issue = "82766")]
impl<K: Debug + Ord, V: Debug> Debug for OccupiedError<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("OccupiedError")
            .field("key", self.entry.key())
            .field("old_value", self.entry.get())
            .field("new_value", &self.value)
            .finish()
    }
}

#[unstable(feature = "map_try_insert", issue = "82766")]
impl<'a, K: Debug + Ord, V: Debug> fmt::Display for OccupiedError<'a, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "failed to insert {:?}, key {:?} already exists with value {:?}",
            self.value,
            self.entry.key(),
            self.entry.get(),
        )
    }
}

impl<'a, K: Ord, V> Entry<'a, K, V> {
    /// Διασφαλίζει μια τιμή στην καταχώριση εισάγοντας την προεπιλεγμένη, εάν είναι κενή, και επιστρέφει μια μεταβλητή αναφορά στην τιμή στην καταχώριση.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// map.entry("poneyland").or_insert(12);
    ///
    /// assert_eq!(map["poneyland"], 12);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_insert(self, default: V) -> &'a mut V {
        match self {
            Occupied(entry) => entry.into_mut(),
            Vacant(entry) => entry.insert(default),
        }
    }

    /// Διασφαλίζει μια τιμή στην καταχώριση εισάγοντας το αποτέλεσμα της προεπιλεγμένης συνάρτησης εάν είναι κενό και επιστρέφει μια μεταβλητή αναφορά στην τιμή στην καταχώριση.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, String> = BTreeMap::new();
    /// let s = "hoho".to_string();
    ///
    /// map.entry("poneyland").or_insert_with(|| s);
    ///
    /// assert_eq!(map["poneyland"], "hoho".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_insert_with<F: FnOnce() -> V>(self, default: F) -> &'a mut V {
        match self {
            Occupied(entry) => entry.into_mut(),
            Vacant(entry) => entry.insert(default()),
        }
    }

    /// Διασφαλίζει μια τιμή στην καταχώριση εισάγοντας, εάν είναι κενό, το αποτέλεσμα της προεπιλεγμένης λειτουργίας.
    /// Αυτή η μέθοδος επιτρέπει τη δημιουργία τιμών που προέρχονται από κλειδί για εισαγωγή παρέχοντας στην προεπιλεγμένη συνάρτηση μια αναφορά στο κλειδί που μετακινήθηκε κατά την κλήση της μεθόδου `.entry(key)`.
    ///
    ///
    /// Η αναφορά στο μετακινημένο κλειδί παρέχεται έτσι ώστε η κλωνοποίηση ή η αντιγραφή του κλειδιού να μην είναι απαραίτητη, σε αντίθεση με το `.or_insert_with(|| ... )`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    ///
    /// map.entry("poneyland").or_insert_with_key(|key| key.chars().count());
    ///
    /// assert_eq!(map["poneyland"], 9);
    /// ```
    ///
    #[inline]
    #[stable(feature = "or_insert_with_key", since = "1.50.0")]
    pub fn or_insert_with_key<F: FnOnce(&K) -> V>(self, default: F) -> &'a mut V {
        match self {
            Occupied(entry) => entry.into_mut(),
            Vacant(entry) => {
                let value = default(entry.key());
                entry.insert(value)
            }
        }
    }

    /// Επιστρέφει μια αναφορά στο κλειδί αυτής της καταχώρισης.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// assert_eq!(map.entry("poneyland").key(), &"poneyland");
    /// ```
    #[stable(feature = "map_entry_keys", since = "1.10.0")]
    pub fn key(&self) -> &K {
        match *self {
            Occupied(ref entry) => entry.key(),
            Vacant(ref entry) => entry.key(),
        }
    }

    /// Παρέχει επιτόπια μεταβλητή πρόσβαση σε κατεχόμενη καταχώριση πριν από πιθανές εισαγωγές στο χάρτη.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    ///
    /// map.entry("poneyland")
    ///    .and_modify(|e| { *e += 1 })
    ///    .or_insert(42);
    /// assert_eq!(map["poneyland"], 42);
    ///
    /// map.entry("poneyland")
    ///    .and_modify(|e| { *e += 1 })
    ///    .or_insert(42);
    /// assert_eq!(map["poneyland"], 43);
    /// ```
    #[stable(feature = "entry_and_modify", since = "1.26.0")]
    pub fn and_modify<F>(self, f: F) -> Self
    where
        F: FnOnce(&mut V),
    {
        match self {
            Occupied(mut entry) => {
                f(entry.get_mut());
                Occupied(entry)
            }
            Vacant(entry) => Vacant(entry),
        }
    }
}

impl<'a, K: Ord, V: Default> Entry<'a, K, V> {
    #[stable(feature = "entry_or_default", since = "1.28.0")]
    /// Διασφαλίζει μια τιμή στην καταχώριση εισάγοντας την προεπιλεγμένη τιμή εάν είναι κενή και επιστρέφει μια μεταβλητή αναφορά στην τιμή στην καταχώριση.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, Option<usize>> = BTreeMap::new();
    /// map.entry("poneyland").or_default();
    ///
    /// assert_eq!(map["poneyland"], None);
    /// ```
    pub fn or_default(self) -> &'a mut V {
        match self {
            Occupied(entry) => entry.into_mut(),
            Vacant(entry) => entry.insert(Default::default()),
        }
    }
}

impl<'a, K: Ord, V> VacantEntry<'a, K, V> {
    /// Παίρνει μια αναφορά στο κλειδί που θα χρησιμοποιηθεί κατά την εισαγωγή μιας τιμής μέσω του VacantEntry.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// assert_eq!(map.entry("poneyland").key(), &"poneyland");
    /// ```
    #[stable(feature = "map_entry_keys", since = "1.10.0")]
    pub fn key(&self) -> &K {
        &self.key
    }

    /// Πάρτε την κυριότητα του κλειδιού.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::collections::btree_map::Entry;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    ///
    /// if let Entry::Vacant(v) = map.entry("poneyland") {
    ///     v.into_key();
    /// }
    /// ```
    #[stable(feature = "map_entry_recover_keys2", since = "1.12.0")]
    pub fn into_key(self) -> K {
        self.key
    }

    /// Ορίζει την τιμή της καταχώρησης με το κλειδί "VacantEntry" και επιστρέφει μια μεταβλητή αναφορά σε αυτήν.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::collections::btree_map::Entry;
    ///
    /// let mut map: BTreeMap<&str, u32> = BTreeMap::new();
    ///
    /// if let Entry::Vacant(o) = map.entry("poneyland") {
    ///     o.insert(37);
    /// }
    /// assert_eq!(map["poneyland"], 37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(self, value: V) -> &'a mut V {
        let out_ptr = match self.handle.insert_recursing(self.key, value) {
            (Fit(_), val_ptr) => {
                // ΑΣΦΑΛΕΙΑ: Έχουμε καταναλώσει το self.handle και η λαβή επέστρεψε.
                let map = unsafe { self.dormant_map.awaken() };
                map.length += 1;
                val_ptr
            }
            (Split(ins), val_ptr) => {
                drop(ins.left);
                // ΑΣΦΑΛΕΙΑ: Έχουμε καταναλώσει το self.handle και η αναφορά επιστράφηκε.
                let map = unsafe { self.dormant_map.awaken() };
                let root = map.root.as_mut().unwrap();
                root.push_internal_level().push(ins.kv.0, ins.kv.1, ins.right);
                map.length += 1;
                val_ptr
            }
        };
        // Τώρα που έχουμε ολοκληρώσει την ανάπτυξη του δέντρου χρησιμοποιώντας δανεισμένες αναφορές, αποπροσανατολίζουμε τον δείκτη σε ένα μέρος του, που πήραμε στην πορεία.
        //
        unsafe { &mut *out_ptr }
    }
}

impl<'a, K: Ord, V> OccupiedEntry<'a, K, V> {
    /// Παίρνει μια αναφορά στο κλειδί στην καταχώριση.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// map.entry("poneyland").or_insert(12);
    /// assert_eq!(map.entry("poneyland").key(), &"poneyland");
    /// ```
    #[stable(feature = "map_entry_keys", since = "1.10.0")]
    pub fn key(&self) -> &K {
        self.handle.reborrow().into_kv().0
    }

    /// Πάρτε την κυριότητα του κλειδιού και της αξίας από τον χάρτη.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::collections::btree_map::Entry;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// map.entry("poneyland").or_insert(12);
    ///
    /// if let Entry::Occupied(o) = map.entry("poneyland") {
    ///     // Διαγράφουμε την καταχώριση από τον χάρτη.
    ///     o.remove_entry();
    /// }
    ///
    /// // Εάν τώρα προσπαθήσετε να πάρετε την τιμή, θα panic:
    /// // println! ("{}", χάρτης ["poneyland"]);
    /// ```
    #[stable(feature = "map_entry_recover_keys2", since = "1.12.0")]
    pub fn remove_entry(self) -> (K, V) {
        self.remove_kv()
    }

    /// Παίρνει μια αναφορά στην τιμή στην καταχώριση.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::collections::btree_map::Entry;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// map.entry("poneyland").or_insert(12);
    ///
    /// if let Entry::Occupied(o) = map.entry("poneyland") {
    ///     assert_eq!(o.get(), &12);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> &V {
        self.handle.reborrow().into_kv().1
    }

    /// Λαμβάνει μια μεταβλητή αναφορά στην τιμή στην καταχώριση.
    ///
    /// Εάν χρειάζεστε μια αναφορά στο `OccupiedEntry` που μπορεί να επιβιώσει από την καταστροφή της τιμής `Entry`, ανατρέξτε στο [`into_mut`].
    ///
    ///
    /// [`into_mut`]: OccupiedEntry::into_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::collections::btree_map::Entry;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// map.entry("poneyland").or_insert(12);
    ///
    /// assert_eq!(map["poneyland"], 12);
    /// if let Entry::Occupied(mut o) = map.entry("poneyland") {
    ///     *o.get_mut() += 10;
    ///     assert_eq!(*o.get(), 22);
    ///
    ///     // Μπορούμε να χρησιμοποιήσουμε την ίδια καταχώριση πολλές φορές.
    ///     *o.get_mut() += 2;
    /// }
    /// assert_eq!(map["poneyland"], 24);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self) -> &mut V {
        self.handle.kv_mut().1
    }

    /// Μετατρέπει την καταχώρηση σε μεταβλητή αναφορά στην τιμή της.
    ///
    /// Εάν χρειάζεστε πολλές αναφορές στο `OccupiedEntry`, ανατρέξτε στο [`get_mut`].
    ///
    /// [`get_mut`]: OccupiedEntry::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::collections::btree_map::Entry;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// map.entry("poneyland").or_insert(12);
    ///
    /// assert_eq!(map["poneyland"], 12);
    /// if let Entry::Occupied(o) = map.entry("poneyland") {
    ///     *o.into_mut() += 10;
    /// }
    /// assert_eq!(map["poneyland"], 22);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_mut(self) -> &'a mut V {
        self.handle.into_val_mut()
    }

    /// Ορίζει την τιμή της καταχώρησης με το κλειδί "OccupiedEntry" και επιστρέφει την παλιά τιμή της καταχώρησης.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::collections::btree_map::Entry;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// map.entry("poneyland").or_insert(12);
    ///
    /// if let Entry::Occupied(mut o) = map.entry("poneyland") {
    ///     assert_eq!(o.insert(15), 12);
    /// }
    /// assert_eq!(map["poneyland"], 15);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, value: V) -> V {
        mem::replace(self.get_mut(), value)
    }

    /// Παίρνει την τιμή της καταχώρησης από τον χάρτη και την επιστρέφει.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::collections::btree_map::Entry;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// map.entry("poneyland").or_insert(12);
    ///
    /// if let Entry::Occupied(o) = map.entry("poneyland") {
    ///     assert_eq!(o.remove(), 12);
    /// }
    /// // Εάν προσπαθήσουμε να πάρουμε την αξία του "poneyland", θα είναι panic:
    /// // println! ("{}", χάρτης ["poneyland"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(self) -> V {
        self.remove_kv().1
    }

    // Σώμα `remove_entry`, πιθανώς ξεχωριστό επειδή το όνομα αντικατοπτρίζει το επιστρεφόμενο ζεύγος.
    pub(super) fn remove_kv(self) -> (K, V) {
        let mut emptied_internal_root = false;
        let (old_kv, _) = self.handle.remove_kv_tracking(|| emptied_internal_root = true);
        // ΑΣΦΑΛΕΙΑ: καταναλώσαμε το ενδιάμεσο ριζικό δανεισμό, `self.handle`.
        let map = unsafe { self.dormant_map.awaken() };
        map.length -= 1;
        if emptied_internal_root {
            let root = map.root.as_mut().unwrap();
            root.pop_internal_level();
        }
        old_kv
    }
}