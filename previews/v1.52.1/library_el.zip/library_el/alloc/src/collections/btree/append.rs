use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Προσθέτει όλα τα ζεύγη κλειδιού-τιμής από την ένωση δύο ανερχόμενων επαναληπτών, αυξάνοντας μια μεταβλητή `length` στην πορεία.Το τελευταίο καθιστά ευκολότερο για τον καλούντα να αποφύγει διαρροή όταν πανικοβληθεί ένας χειριστής πτώσης.
    ///
    /// Εάν και οι δύο επαναληπτές παράγουν το ίδιο κλειδί, αυτή η μέθοδος ρίχνει το ζεύγος από τον αριστερό επαναληπτή και προσαρτά το ζεύγος από τον δεξιό επαναληπτή.
    ///
    /// Εάν θέλετε το δέντρο να καταλήξει σε αυστηρά αύξουσα σειρά, όπως για το `BTreeMap`, και οι δύο επαναληπτές θα πρέπει να παράγουν κλειδιά με αυστηρά αύξουσα σειρά, καθένα μεγαλύτερο από όλα τα κλειδιά στο δέντρο, συμπεριλαμβανομένων τυχόν κλειδιών που υπάρχουν ήδη στο δέντρο κατά την είσοδο.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Ετοιμάζουμε να συγχωνεύσουμε τα `left` και `right` σε μια ταξινομημένη ακολουθία σε γραμμικό χρόνο.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Εν τω μεταξύ, χτίζουμε ένα δέντρο από την ταξινομημένη ακολουθία σε γραμμικό χρόνο.
        self.bulk_push(iter, length)
    }

    /// Σπρώχνει όλα τα ζεύγη τιμών-κλειδιών στο τέλος του δέντρου, αυξάνοντας μια μεταβλητή `length` στην πορεία.
    /// Το τελευταίο καθιστά ευκολότερο για τον καλούντα να αποφύγει διαρροή όταν ο επαναληπτής πανικοβάλλεται.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Επαναλάβετε όλα τα ζεύγη τιμών-κλειδιών, ωθώντας τα σε κόμβους στο σωστό επίπεδο.
        for (key, value) in iter {
            // Προσπαθήστε να ωθήσετε το ζεύγος κλειδιών-τιμών στον τρέχοντα κόμβο φύλλων.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Δεν υπάρχει χώρος, ανεβείτε και σπρώξτε εκεί.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Βρέθηκε ένας κόμβος με κενό χώρο, πατήστε εδώ.
                                open_node = parent;
                                break;
                            } else {
                                // Ανεβείτε πάλι.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Είμαστε στην κορυφή, δημιουργούμε έναν νέο ριζικό κόμβο και πιέζουμε εκεί.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Πιέστε το ζεύγος κλειδιού-τιμής και το νέο δεξιό υπόφυτο.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Πηγαίνετε πάλι στο δεξί φύλλο.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Αυξήστε το μήκος κάθε επανάληψης, για να βεβαιωθείτε ότι ο χάρτης πέφτει τα συνημμένα στοιχεία, ακόμη και αν προχωρήσει ο επαναληπτικός πανικός.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Ένα επαναληπτικό για τη συγχώνευση δύο ταξινομημένων ακολουθιών σε μία
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Εάν δύο κλειδιά είναι ίδια, επιστρέφει το ζεύγος τιμών-κλειδιών από τη σωστή πηγή.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}