use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// Αφαιρεί ένα ζεύγος κλειδιού-τιμής από το δέντρο και επιστρέφει αυτό το ζεύγος, καθώς και το φύλλο edge που αντιστοιχεί στο προηγούμενο ζεύγος.
    /// Είναι πιθανό αυτό να αδειάσει έναν ριζικό κόμβο που είναι εσωτερικός, τον οποίο ο καλούντος πρέπει να εμφανιστεί από το χάρτη που κρατά το δέντρο.
    /// Ο καλών θα πρέπει επίσης να μειώσει το μήκος του χάρτη.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // Πρέπει να ξεχάσουμε προσωρινά τον τύπο του παιδιού, επειδή δεν υπάρχει ξεχωριστός τύπος κόμβου για τους άμεσους γονείς ενός φύλλου.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // ΑΣΦΑΛΕΙΑ: Το `new_pos` είναι το φύλλο από το οποίο ξεκινήσαμε ή από έναν αδελφό.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // Μόνο όταν συγχωνευτήκαμε, ο γονέας (αν υπάρχει) έχει συρρικνωθεί, αλλά παραλείποντας το επόμενο βήμα διαφορετικά δεν αποδίδει αποτελέσματα.
            //
            // ΑΣΦΑΛΕΙΑ: Δεν θα καταστρέψουμε ούτε θα αναδιατάξουμε το φύλλο όπου βρίσκεται το `pos`
            // χειρίζοντας τον γονέα του αναδρομικά・στη χειρότερη περίπτωση θα καταστρέψουμε ή θα αναδιατάξουμε τον γονέα μέσω του παππού και γιαγιά, αλλάζοντας έτσι τον σύνδεσμο με τον γονέα μέσα στο φύλλο.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // Αφαιρέστε ένα παρακείμενο KV από το φύλλο του και στη συνέχεια τοποθετήστε το στη θέση του στοιχείου που μας ζητήθηκε να αφαιρέσουμε.
        //
        // Προτιμήστε το αριστερό παρακείμενο KV, για τους λόγους που αναφέρονται στο `choose_parent_kv`.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // Ο εσωτερικός κόμβος ενδέχεται να έχει κλαπεί ή συγχωνευθεί.
        // Επιστρέψτε δεξιά για να βρείτε πού κατέληξε το αρχικό KV.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}