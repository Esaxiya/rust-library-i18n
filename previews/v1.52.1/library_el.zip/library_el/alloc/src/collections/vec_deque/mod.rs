//! Μια ουρά διπλού άκρου που υλοποιήθηκε με ένα αναπτυσσόμενο δακτύλιο buffer.
//!
//! Αυτή η ουρά έχει *O*(1) αποσβεσμένα ένθετα και αφαιρέσεις και από τα δύο άκρα του δοχείου.
//! Έχει επίσης *O*(1) ευρετηρίαση σαν vector.
//! Τα περιεχόμενα στοιχεία δεν απαιτείται να είναι αντιγράψιμα και η ουρά θα μπορεί να αποσταλεί εάν ο περιορισμένος τύπος μπορεί να αποσταλεί.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Μεγαλύτερη δυνατή ισχύ δύο

/// Μια ουρά διπλού άκρου που υλοποιήθηκε με ένα αναπτυσσόμενο δακτύλιο buffer.
///
/// Η χρήση "default" αυτού του τύπου ως ουρά είναι να χρησιμοποιήσετε το [`push_back`] για προσθήκη στην ουρά και το [`pop_front`] να το αφαιρέσετε από την ουρά.
///
/// [`extend`] και το [`append`] σπρώχνουν προς τα πίσω με αυτόν τον τρόπο και η επανάληψη πάνω από το `VecDeque` πηγαίνει μπροστά προς τα πίσω.
///
/// Δεδομένου ότι το `VecDeque` είναι ένα buffer δακτυλίου, τα στοιχεία του δεν είναι απαραίτητα γειτονικά στη μνήμη.
/// Εάν θέλετε να αποκτήσετε πρόσβαση στα στοιχεία ως ένα κομμάτι, όπως για αποτελεσματική ταξινόμηση, μπορείτε να χρησιμοποιήσετε το [`make_contiguous`].
/// Περιστρέφει το `VecDeque` έτσι ώστε τα στοιχεία του να μην τυλίγονται και επιστρέφει ένα μεταβλητό κομμάτι στην τώρα συνεχόμενη ακολουθία στοιχείων.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // η ουρά και το κεφάλι είναι δείκτες στο buffer.
    // Η ουρά δείχνει πάντα το πρώτο στοιχείο που θα μπορούσε να διαβαστεί, το Head πάντα επισημαίνει πού πρέπει να γραφτούν τα δεδομένα.
    //
    // Εάν η ουρά==κεφάλι το buffer είναι κενό.Το μήκος του ringbuffer ορίζεται ως η απόσταση μεταξύ των δύο.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Εκτελεί τον καταστροφέα για όλα τα αντικείμενα στη φέτα όταν πέσει (κανονικά ή κατά την ξετύλιξη).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // χρησιμοποιήστε πτώση για [T]
            ptr::drop_in_place(front);
        }
        // Το RawVec χειρίζεται την αφαίρεση
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Δημιουργεί ένα κενό `VecDeque<T>`.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Οριακά πιο βολικό
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Οριακά πιο βολικό
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Για τύπους μηδενικού μεγέθους, είμαστε πάντα στη μέγιστη χωρητικότητα
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Μετατρέψτε το ptr σε μια φέτα
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Μετατρέψτε το ptr σε ένα mut slice
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Μετακινεί ένα στοιχείο έξω από το buffer
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Γράφει ένα στοιχείο στο buffer, μετακινώντας το.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Επιστρέφει `true` εάν το buffer είναι σε πλήρη χωρητικότητα.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Επιστρέφει το ευρετήριο στο υποκείμενο buffer για ένα δεδομένο λογικό στοιχείο ευρετηρίου.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Επιστρέφει το ευρετήριο στο υποκείμενο buffer για ένα δεδομένο λογικό στοιχείο ευρετήριο + προσθήκη.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Επιστρέφει το ευρετήριο στο υποκείμενο buffer για ένα δεδομένο ευρετήριο λογικού στοιχείου, δευτερεύον.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Αντιγράφει ένα συνεχόμενο μπλοκ μνήμης len από src έως dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Αντιγράφει ένα συνεχόμενο μπλοκ μνήμης len από src έως dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Αντιγράφει ένα δυνητικά αναδιπλούμενο μπλοκ μνήμης len από src έως dest.
    /// (abs(dst - src) + len) δεν πρέπει να είναι μεγαλύτερο από cap() (Πρέπει να υπάρχει το πολύ μια συνεχής αλληλεπικαλυπτόμενη περιοχή μεταξύ src και προορισμού).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // Το src δεν τυλίγει, το dst δεν τυλίγει
                //
                //        Ν...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] Δ.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst πριν το src, το src δεν τυλίγει, το dst τυλίγει
                //
                //
                //    Ν...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. Δ.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src πριν από το dst, το src δεν τυλίγει, το dst τυλίγει
                //
                //
                //              Ν...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. Δ.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst πριν από το src, src αναδιπλώνεται, το dst δεν τυλίγει
                //
                //
                //    .. Σ.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] Δ...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src πριν από το dst, το src τυλίγει, το dst δεν τυλίγει
                //
                //
                //    .. Σ.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] Δ...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst πριν src, src αναδιπλώνεται, dst αναδιπλώνεται
                //
                //
                //    ... Σ.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. Δ..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src πριν από το dst, src αναδιπλώνεται, dst αναδιπλώνεται
                //
                //
                //    .. Σ..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 Χ00Χ... Δ.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Περιστρέψτε τα τμήματα της κεφαλής και της ουράς γύρω για να χειριστείτε το γεγονός ότι μόλις ανακατανεμήσαμε.
    /// Μη ασφαλές επειδή εμπιστεύεται το old_capacity.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Μετακινήστε το συντομότερο συνεχόμενο τμήμα του ρυθμιστικού δακτυλίου TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...εντάξει......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // Όχι
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Δημιουργεί ένα κενό `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Δημιουργεί ένα κενό `VecDeque` με χώρο για τουλάχιστον στοιχεία `capacity`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 αφού το ringbuffer αφήνει πάντα ένα κενό χώρο
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Παρέχει μια αναφορά στο στοιχείο στο δεδομένο ευρετήριο.
    ///
    /// Το στοιχείο στο ευρετήριο 0 είναι το μπροστινό μέρος της ουράς.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Παρέχει μια μεταβλητή αναφορά στο στοιχείο στο δεδομένο ευρετήριο.
    ///
    /// Το στοιχείο στο ευρετήριο 0 είναι το μπροστινό μέρος της ουράς.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Ανταλλάσσει στοιχεία στους δείκτες `i` και `j`.
    ///
    /// `i` και το `j` μπορεί να είναι ίσο.
    ///
    /// Το στοιχείο στο ευρετήριο 0 είναι το μπροστινό μέρος της ουράς.
    ///
    /// # Panics
    ///
    /// Panics εάν οποιοδήποτε από τα δύο ευρετήρια είναι εκτός ορίων.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Επιστρέφει τον αριθμό των στοιχείων που μπορεί να διατηρήσει το `VecDeque` χωρίς ανακατανομή.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Διατηρεί την ελάχιστη χωρητικότητα για ακριβώς `additional` περισσότερα στοιχεία που θα εισαχθούν στο δεδομένο `VecDeque`.
    /// Δεν κάνει τίποτα εάν η χωρητικότητα είναι ήδη επαρκής.
    ///
    /// Σημειώστε ότι ο εκχωρητής μπορεί να δώσει στη συλλογή περισσότερο χώρο από ό, τι ζητά.
    /// Επομένως δεν μπορεί να γίνει επίκληση της ικανότητας να είναι ακριβώς ελάχιστη.
    /// Προτιμήστε το [`reserve`] εάν αναμένονται εισαγωγές future.
    ///
    /// # Panics
    ///
    /// Panics εάν η νέα χωρητικότητα ξεχειλίζει `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Διατηρεί χωρητικότητα για τουλάχιστον `additional` περισσότερα στοιχεία που θα εισαχθούν στο δεδομένο `VecDeque`.
    /// Η συλλογή ενδέχεται να διατηρήσει περισσότερο χώρο για να αποφευχθούν συχνές ανακατανομές.
    ///
    /// # Panics
    ///
    /// Panics εάν η νέα χωρητικότητα ξεχειλίζει `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Προσπαθεί να διατηρήσει την ελάχιστη χωρητικότητα για ακριβώς `additional` περισσότερα στοιχεία που θα εισαχθούν στο δεδομένο `VecDeque<T>`.
    ///
    /// Αφού καλέσετε το `try_reserve_exact`, η χωρητικότητα θα είναι μεγαλύτερη ή ίση με `self.len() + additional`.
    /// Δεν κάνει τίποτα εάν η χωρητικότητα είναι ήδη επαρκής.
    ///
    /// Σημειώστε ότι ο εκχωρητής μπορεί να δώσει στη συλλογή περισσότερο χώρο από ό, τι ζητά.
    /// Επομένως, δεν μπορεί να γίνει επίκληση της ικανότητας να είναι ακριβώς ελάχιστη.
    /// Προτιμήστε το `reserve` εάν αναμένονται εισαγωγές future.
    ///
    /// # Errors
    ///
    /// Εάν η χωρητικότητα υπερχείλισης `usize`, ή ο εκχωρητής αναφέρει μια αποτυχία, τότε επιστρέφεται ένα σφάλμα.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Προ-δεσμεύστε τη μνήμη, κλείνοντας εάν δεν μπορούμε
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Τώρα ξέρουμε ότι αυτό δεν μπορεί OOM(Out-Of-Memory) στη μέση της σύνθετης δουλειάς μας
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // πολύ περίπλοκο
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Προσπαθεί να διατηρήσει χωρητικότητα για τουλάχιστον `additional` περισσότερα στοιχεία που θα εισαχθούν στο δεδομένο `VecDeque<T>`.
    /// Η συλλογή ενδέχεται να διατηρήσει περισσότερο χώρο για να αποφευχθούν συχνές ανακατανομές.
    /// Αφού καλέσετε το `try_reserve`, η χωρητικότητα θα είναι μεγαλύτερη ή ίση με `self.len() + additional`.
    /// Δεν κάνει τίποτα εάν η χωρητικότητα είναι ήδη επαρκής.
    ///
    /// # Errors
    ///
    /// Εάν η χωρητικότητα υπερχείλισης `usize`, ή ο εκχωρητής αναφέρει μια αποτυχία, τότε επιστρέφεται ένα σφάλμα.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Προ-δεσμεύστε τη μνήμη, κλείνοντας εάν δεν μπορούμε
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Τώρα ξέρουμε ότι αυτό δεν είναι OOM στη μέση της σύνθετης δουλειάς μας
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // πολύ περίπλοκο
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Μειώνει όσο το δυνατόν περισσότερο τη χωρητικότητα του `VecDeque`.
    ///
    /// Θα πέσει όσο το δυνατόν πιο κοντά στο μήκος, αλλά ο εκχωρητής μπορεί να ενημερώσει το `VecDeque` ότι υπάρχει χώρος για μερικά ακόμη στοιχεία.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Μειώνει τη χωρητικότητα του `VecDeque` με χαμηλότερο όριο.
    ///
    /// Η χωρητικότητα θα παραμείνει τουλάχιστον τόσο μεγάλη όσο και το μήκος και η παρεχόμενη τιμή.
    ///
    ///
    /// Εάν η τρέχουσα χωρητικότητα είναι μικρότερη από το κατώτερο όριο, αυτό δεν είναι op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Δεν χρειάζεται να ανησυχούμε για υπερχείλιση, καθώς ούτε το `self.len()` ούτε το `self.capacity()` μπορεί ποτέ να είναι `usize::MAX`.
        // +1 καθώς το ringbuffer αφήνει πάντα ένα κενό χώρο.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Υπάρχουν τρεις περιπτώσεις ενδιαφέροντος:
            //   Όλα τα στοιχεία είναι εκτός επιθυμητών ορίων Τα στοιχεία είναι συνεχόμενα και η κεφαλή είναι εκτός επιθυμητών ορίων Τα στοιχεία είναι ασυνεχή και η ουρά είναι εκτός επιθυμητών ορίων
            //
            //
            // Σε όλες τις άλλες ώρες, οι θέσεις των στοιχείων δεν επηρεάζονται.
            //
            // Υποδεικνύει ότι τα στοιχεία στο κεφάλι πρέπει να μετακινηθούν.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Μετακίνηση στοιχείων από τα επιθυμητά όρια (θέσεις μετά το target_cap)
            if self.tail >= target_cap && head_outside {
                // Θ
                //   [. . . . . . . . o o o o o o o . ]
                //    Θ
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // Θ
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // ΗΤ
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Συντομεύει το `VecDeque`, διατηρώντας τα πρώτα στοιχεία `len` και ρίχνοντας τα υπόλοιπα.
    ///
    ///
    /// Εάν το `len` είναι μεγαλύτερο από το τρέχον μήκος του "VecDeque", αυτό δεν έχει αποτέλεσμα.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Εκτελεί τον καταστροφέα για όλα τα αντικείμενα στη φέτα όταν πέσει (κανονικά ή κατά την ξετύλιξη).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Ασφαλές επειδή:
        //
        // * Κάθε τμήμα που έχει περάσει στο `drop_in_place` είναι έγκυρο.η δεύτερη θήκη έχει `len <= front.len()` και η επιστροφή στο `len > self.len()` εξασφαλίζει `begin <= back.len()` στην πρώτη περίπτωση
        //
        // * Η κεφαλή του VecDeque μετακινείται πριν από την κλήση του `drop_in_place`, οπότε καμία τιμή δεν μειώνεται δύο φορές εάν `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Βεβαιωθείτε ότι το δεύτερο μισό πέφτει ακόμη και όταν ένας καταστροφέας στο πρώτο panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Επιστρέφει έναν επαναληπτικό εμπρός-πίσω.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Επιστρέφει έναν επαναληπτικό front-to-back που επιστρέφει μεταβλητές αναφορές.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // ΑΣΦΑΛΕΙΑ: Η εσωτερική αναλλοίωτη ασφάλεια `IterMut` έχει δημιουργηθεί επειδή το
        // `ring` δημιουργούμε είναι μια απαράμιλλη φέτα για όλη τη ζωή "_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Επιστρέφει ένα ζευγάρι φετών που περιέχουν, κατά σειρά, τα περιεχόμενα του `VecDeque`.
    ///
    /// Εάν είχε προηγουμένως κληθεί το [`make_contiguous`], όλα τα στοιχεία του `VecDeque` θα βρίσκονται στο πρώτο και το δεύτερο θα είναι κενό.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Επιστρέφει ένα ζευγάρι φετών που περιέχουν, κατά σειρά, τα περιεχόμενα του `VecDeque`.
    ///
    /// Εάν είχε προηγουμένως κληθεί το [`make_contiguous`], όλα τα στοιχεία του `VecDeque` θα βρίσκονται στο πρώτο και το δεύτερο θα είναι κενό.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Επιστρέφει τον αριθμό των στοιχείων στο `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Επιστρέφει το `true` εάν το `VecDeque` είναι κενό.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Δημιουργεί έναν επαναληπτικό που καλύπτει το καθορισμένο εύρος στο `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics εάν το σημείο εκκίνησης είναι μεγαλύτερο από το τελικό σημείο ή εάν το τελικό σημείο είναι μεγαλύτερο από το μήκος του vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Ένα πλήρες φάσμα καλύπτει όλα τα περιεχόμενα
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Η κοινή αναφορά που έχουμε στο &self διατηρείται στο «_ του Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Δημιουργεί έναν επαναληπτικό που καλύπτει το καθορισμένο μεταβλητό εύρος στο `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics εάν το σημείο εκκίνησης είναι μεγαλύτερο από το τελικό σημείο ή εάν το τελικό σημείο είναι μεγαλύτερο από το μήκος του vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Ένα πλήρες φάσμα καλύπτει όλα τα περιεχόμενα
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // ΑΣΦΑΛΕΙΑ: Η εσωτερική αναλλοίωτη ασφάλεια `IterMut` έχει δημιουργηθεί επειδή το
        // `ring` δημιουργούμε είναι μια απαράμιλλη φέτα για όλη τη ζωή "_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Δημιουργεί έναν επαναληπτικό επαναληπτικό που αφαιρεί το καθορισμένο εύρος στο `VecDeque` και αποδίδει τα αντικείμενα που αφαιρέθηκαν.
    ///
    /// Σημείωση 1: Το εύρος στοιχείων αφαιρείται ακόμη και αν ο επαναληπτικός δεν καταναλώνεται μέχρι το τέλος.
    ///
    /// Σημείωση 2: Δεν έχει καθοριστεί πόσα στοιχεία αφαιρούνται από το deque, εάν η τιμή `Drain` δεν πέσει, αλλά το δάνειο που κατέχει λήγει (π.χ. λόγω του `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics εάν το σημείο εκκίνησης είναι μεγαλύτερο από το τελικό σημείο ή εάν το τελικό σημείο είναι μεγαλύτερο από το μήκος του vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Ένα πλήρες εύρος διαγράφει όλα τα περιεχόμενα
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Ασφάλεια μνήμης
        //
        // Όταν δημιουργείται για πρώτη φορά το Drain, η πηγή deque μειώνεται για να βεβαιωθείτε ότι δεν είναι προσβάσιμα καθόλου στοιχεία που δεν έχουν αρχικοποιηθεί ή μετακινηθεί αν δεν εκτελεστεί ποτέ ο καταστροφέας του Drain.
        //
        //
        // Το Drain θα ptr::read εξαλείψει τις τιμές για κατάργηση.
        // Όταν τελειώσει, τα υπόλοιπα δεδομένα θα αντιγραφούν πίσω για να καλύψουν την τρύπα και οι τιμές head/tail θα αποκατασταθούν σωστά.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Τα στοιχεία της deque χωρίζονται σε τρία τμήματα:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;Η= self.head;t=drain_tail;h=drain_head
        //
        // Αποθηκεύουμε το drain_tail ως self.head και το drain_head και self.head ως after_tail και after_head αντίστοιχα στο Drain.
        // Αυτό περικόπτει επίσης την αποτελεσματική συστοιχία έτσι ώστε εάν διαρρεύσει το Drain, έχουμε ξεχάσει τις δυνητικά μετακινούμενες τιμές μετά την έναρξη του drain.
        //
        //
        //        Τ ο Χ
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" σχετικά με τις τιμές μετά την έναρξη του drain μέχρι την ολοκλήρωση του drain και την εκτέλεση του καταστροφέα Drain.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Βασικά, δημιουργούμε μόνο κοινόχρηστες αναφορές από το `self` εδώ και διαβάζουμε από αυτό.
                // Δεν γράφουμε στο `self` ούτε επιστρέφουμε σε μεταβλητή αναφορά.
                // Ως εκ τούτου, ο ακατέργαστος δείκτης που δημιουργήσαμε παραπάνω, για το `deque`, παραμένει σε ισχύ.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Διαγράφει το `VecDeque`, αφαιρώντας όλες τις τιμές.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Επιστρέφει το `true` εάν το `VecDeque` περιέχει ένα στοιχείο ίσο με τη δεδομένη τιμή.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Παρέχει μια αναφορά στο μπροστινό στοιχείο ή `None` εάν το `VecDeque` είναι κενό.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Παρέχει μια μεταβλητή αναφορά στο μπροστινό στοιχείο ή `None` εάν το `VecDeque` είναι κενό.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Παρέχει μια αναφορά στο πίσω στοιχείο ή `None` εάν το `VecDeque` είναι κενό.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Παρέχει μια μεταβλητή αναφορά στο πίσω στοιχείο ή `None` εάν το `VecDeque` είναι κενό.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Αφαιρεί το πρώτο στοιχείο και το επιστρέφει ή `None` εάν το `VecDeque` είναι κενό.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Αφαιρεί το τελευταίο στοιχείο από το `VecDeque` και το επιστρέφει ή `None` εάν είναι κενό.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Προετοιμάζει ένα στοιχείο στο `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Προσθέτει ένα στοιχείο στο πίσω μέρος του `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Πρέπει να θεωρήσουμε ότι το `head == 0` σημαίνει
        // ότι το `self` είναι γειτονικό;
        self.tail <= self.head
    }

    /// Αφαιρεί ένα στοιχείο από οπουδήποτε στο `VecDeque` και το επιστρέφει, αντικαθιστώντας το με το πρώτο στοιχείο.
    ///
    ///
    /// Αυτό δεν διατηρεί την παραγγελία, αλλά είναι *O*(1).
    ///
    /// Επιστρέφει το `None` εάν το `index` είναι εκτός ορίων.
    ///
    /// Το στοιχείο στο ευρετήριο 0 είναι το μπροστινό μέρος της ουράς.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Αφαιρεί ένα στοιχείο από οπουδήποτε στο `VecDeque` και το επιστρέφει, αντικαθιστώντας το με το τελευταίο στοιχείο.
    ///
    ///
    /// Αυτό δεν διατηρεί την παραγγελία, αλλά είναι *O*(1).
    ///
    /// Επιστρέφει το `None` εάν το `index` είναι εκτός ορίων.
    ///
    /// Το στοιχείο στο ευρετήριο 0 είναι το μπροστινό μέρος της ουράς.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Εισάγει ένα στοιχείο στο `index` μέσα στο `VecDeque`, μετατοπίζοντας όλα τα στοιχεία με δείκτες μεγαλύτερους ή ίσους με `index` προς τα πίσω.
    ///
    ///
    /// Το στοιχείο στο ευρετήριο 0 είναι το μπροστινό μέρος της ουράς.
    ///
    /// # Panics
    ///
    /// Panics εάν το `index` είναι μεγαλύτερο από το μήκος του "VecDeque"
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Μετακινήστε τον μικρότερο αριθμό στοιχείων στην προσωρινή μνήμη και εισαγάγετε το δεδομένο αντικείμενο
        //
        // Το πολύ len/2, θα μετακινηθούν 1 στοιχεία. O(min(n, n-i))
        //
        // Υπάρχουν τρεις κύριες περιπτώσεις:
        //  Τα στοιχεία είναι γειτονικά
        //      - ειδική περίπτωση όταν η ουρά είναι 0 Στοιχεία είναι ασυνεχείς και το ένθετο βρίσκεται στην ουρά Το στοιχείο είναι ασυνεχές και το ένθετο βρίσκεται στην κεφαλή
        //
        //
        // Για καθένα από αυτά υπάρχουν δύο ακόμη περιπτώσεις:
        //  Το ένθετο είναι πιο κοντά στην ουρά Το ένθετο είναι πιο κοντά στο κεφάλι
        //
        // Κλειδί: H, self.head
        //      T, self.tail o, Έγκυρο στοιχείο I, στοιχείο εισαγωγής A, Το στοιχείο που πρέπει να είναι μετά το σημείο εισαγωγής M, δείχνει το στοιχείο μετακινήθηκε
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       ΤΙΗ
                //      [Ένα oooooo.......
                //      .
                //      .]
                //
                //                       ΗΤ
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // γειτονικός, εισαγάγετε πιο κοντά στην ουρά:
                    //
                    //             ΤΙΗ
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           Θ
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // συνεχόμενη, εισάγετε πιο κοντά στην ουρά και η ουρά είναι 0:
                    //
                    //
                    //       ΤΙΗ
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       ΗΤ
                    //      [o I A o o o o o . . . . . . . o]
                    //       ΜΜ

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Έχει ήδη μετακινηθεί η ουρά, επομένως αντιγράφουμε μόνο στοιχεία `index - 1`.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // γειτονικός, εισαγάγετε πιο κοντά στο κεφάλι:
                    //
                    //             ΤΙΗ
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             Θ
                    //      [. . . o o o o I A o o . . . . .]
                    //                       ΜΜΜ

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // ασυνεχής, εισαγάγετε πιο κοντά στην ουρά, στην ουρά:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   ΗΤ
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // ασυνεχής, εισαγάγετε πιο κοντά στο κεφάλι, στην ουρά:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             ΗΤ
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // αντιγράψτε στοιχεία έως και νέα κεφαλή
                    self.copy(1, 0, self.head);

                    // αντιγράψτε το τελευταίο στοιχείο σε κενό σημείο στο κάτω μέρος του buffer
                    self.copy(0, self.cap() - 1, 1);

                    // μετακίνηση στοιχείων από το idx στο τέλος προς τα εμπρός, χωρίς το στοιχείο ^
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // ασυνεχές, το ένθετο είναι πιο κοντά στην ουρά, το τμήμα κεφαλής και βρίσκεται στο ευρετήριο μηδέν στο εσωτερικό buffer:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           ΗΤ
                    //      [A o o o o o o o o o . . o o o I]
                    //                               ΜΜΜ

                    // αντιγράψτε στοιχεία έως και νέα ουρά
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // αντιγράψτε το τελευταίο στοιχείο σε κενό σημείο στο κάτω μέρος του buffer
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // ασυνεχής, εισαγάγετε πιο κοντά στην ουρά, το κεφάλι:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           ΗΤ
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // αντιγράψτε στοιχεία έως και νέα ουρά
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // αντιγράψτε το τελευταίο στοιχείο σε κενό σημείο στο κάτω μέρος του buffer
                    self.copy(self.cap() - 1, 0, 1);

                    // μετακινήστε στοιχεία από το idx-1 στο τέλος προς τα εμπρός, χωρίς το στοιχείο ^
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // ασυνεχής, εισάγετε πιο κοντά στο κεφάλι, το κεφάλι:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     ΗΤ
                    //      [o o o o I A o o . . . . . o o o]
                    //                 ΜΜΜ

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // ουρά μπορεί να έχει αλλάξει, γι 'αυτό πρέπει να υπολογίσουμε εκ νέου
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Αφαιρεί και επιστρέφει το στοιχείο στο `index` από το `VecDeque`.
    /// Όποιο άκρο είναι πιο κοντά στο σημείο αφαίρεσης θα μετακινηθεί για να δημιουργηθεί χώρος και όλα τα επηρεαζόμενα στοιχεία θα μετακινηθούν σε νέες θέσεις.
    ///
    /// Επιστρέφει το `None` εάν το `index` είναι εκτός ορίων.
    ///
    /// Το στοιχείο στο ευρετήριο 0 είναι το μπροστινό μέρος της ουράς.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Υπάρχουν τρεις κύριες περιπτώσεις:
        //  Τα στοιχεία είναι συνεχόμενα Τα στοιχεία είναι ασυνεχή και η αφαίρεση γίνεται στο τμήμα ουράς Τα στοιχεία είναι ασυνεχή και η αφαίρεση γίνεται στο τμήμα κεφαλής
        //
        //      - ειδική περίπτωση όταν τα στοιχεία είναι τεχνικά συνεχόμενα, αλλά self.head =0
        //
        // Για καθένα από αυτά υπάρχουν δύο ακόμη περιπτώσεις:
        //  Το ένθετο είναι πιο κοντά στην ουρά Το ένθετο είναι πιο κοντά στο κεφάλι
        //
        // Κλειδί: H, self.head
        //      T, self.tail o, Έγκυρο στοιχείο x, Στοιχείο επισημασμένο για αφαίρεση R, Δείχνει το στοιχείο που αφαιρείται M, Υποδεικνύει ότι το στοιχείο μετακινήθηκε
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // γειτονικός, αφαιρέστε πιο κοντά στην ουρά:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               Θ
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // γειτονικός, αφαιρέστε πιο κοντά στο κεφάλι:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             Θ
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // ασυνεχής, αφαιρέστε πιο κοντά στην ουρά, στην ουρά:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   ΗΤ
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // ασυνεχής, αφαιρέστε πιο κοντά στο κεφάλι, το κεφάλι:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   ΗΤ
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // ασυνεχής, αφαιρέστε πιο κοντά στο κεφάλι, στην ουρά:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           ΗΤ
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // ή σχεδόν αδιαμφισβήτητο, αφαιρέστε δίπλα στο κεφάλι, στην ουρά:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         Θ
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // σχεδιάστε στοιχεία στην ουρά
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Αποτρέπει την υπερχείλιση.
                    if self.head != 0 {
                        // αντιγράψτε το πρώτο στοιχείο σε κενό σημείο
                        self.copy(self.cap() - 1, 0, 1);

                        // μετακινήστε τα στοιχεία στο τμήμα της κεφαλής προς τα πίσω
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // ασυνεχές, αφαιρέστε πιο κοντά στην ουρά, το κεφάλι:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           ΗΤ
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMΜ

                    // σχεδίαση στοιχείων έως idx
                    self.copy(1, 0, idx);

                    // αντιγράψτε το τελευταίο στοιχείο σε κενό σημείο
                    self.copy(0, self.cap() - 1, 1);

                    // μετακινήστε τα στοιχεία από την ουρά στο τέλος προς τα εμπρός, εξαιρουμένου του τελευταίου
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Διαχωρίζει το `VecDeque` σε δύο στο δεδομένο ευρετήριο.
    ///
    /// Επιστρέφει ένα νέο `VecDeque` που έχει εκχωρηθεί.
    /// `self` περιέχει στοιχεία `[0, at)` και το επιστρεφόμενο `VecDeque` περιέχει στοιχεία `[at, len)`.
    ///
    /// Σημειώστε ότι η χωρητικότητα του `self` δεν αλλάζει.
    ///
    /// Το στοιχείο στο ευρετήριο 0 είναι το μπροστινό μέρος της ουράς.
    ///
    /// # Panics
    ///
    /// Panics εάν `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` βρίσκεται στο πρώτο ημίχρονο.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // απλώς πάρτε όλο το δεύτερο ημίχρονο.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` βρίσκεται στο δεύτερο ημίχρονο, πρέπει να λάβουμε υπόψη τα στοιχεία που παραλείψαμε στο πρώτο ημίχρονο.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Εκκαθάριση όπου βρίσκονται τα άκρα των ρυθμιστικών
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Μετακινεί όλα τα στοιχεία του `other` σε `self`, αφήνοντας το `other` κενό.
    ///
    /// # Panics
    ///
    /// Panics εάν ο νέος αριθμός στοιχείων στον εαυτό υπερχειλίζει ένα `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // αφελές εμφ
        self.extend(other.drain(..));
    }

    /// Διατηρεί μόνο τα στοιχεία που καθορίζονται από την κατηγορία.
    ///
    /// Με άλλα λόγια, καταργήστε όλα τα στοιχεία `e` έτσι ώστε το `f(&e)` να επιστρέφει ψευδές.
    /// Αυτή η μέθοδος λειτουργεί στη θέση της, επισκέπτοντας κάθε στοιχείο ακριβώς μία φορά στην αρχική σειρά και διατηρεί τη σειρά των διατηρούμενων στοιχείων.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Η ακριβής σειρά μπορεί να είναι χρήσιμη για την παρακολούθηση της εξωτερικής κατάστασης, όπως ένα ευρετήριο.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Αυτό μπορεί να panic ή να ακυρωθεί
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Διπλασιάστε το μέγεθος του buffer.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Τροποποιεί το `VecDeque` στη θέση του έτσι ώστε το `len()` να είναι ίσο με το `new_len`, είτε αφαιρώντας τα πλεονάζοντα στοιχεία από το πίσω μέρος είτε προσθέτοντας στοιχεία που δημιουργούνται καλώντας το `generator` στο πίσω μέρος.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Αναδιάταξη της εσωτερικής αποθήκευσης αυτής της deque, ώστε να είναι ένα συνεχόμενο κομμάτι, το οποίο στη συνέχεια επιστρέφεται.
    ///
    /// Αυτή η μέθοδος δεν εκχωρεί και δεν αλλάζει τη σειρά των παρεχόμενων στοιχείων.Καθώς επιστρέφει ένα μεταβλητό κομμάτι, αυτό μπορεί να χρησιμοποιηθεί για να ταξινομήσετε ένα deque.
    ///
    /// Μόλις ο εσωτερικός χώρος αποθήκευσης είναι συνεχόμενος, οι μέθοδοι [`as_slices`] και [`as_mut_slices`] θα επιστρέψουν ολόκληρο το περιεχόμενο του `VecDeque` σε ένα μόνο κομμάτι.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Ταξινόμηση του περιεχομένου ενός deque.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // ταξινόμηση της deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // ταξινόμηση σε αντίστροφη σειρά
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Να έχετε αμετάβλητη πρόσβαση στο συνεχόμενο κομμάτι.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // μπορούμε τώρα να είμαστε σίγουροι ότι το `slice` περιέχει όλα τα στοιχεία του deque, ενώ εξακολουθεί να έχει αμετάβλητη πρόσβαση στο `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // υπάρχει αρκετός ελεύθερος χώρος για να αντιγράψετε την ουρά με μία κίνηση, αυτό σημαίνει ότι αρχικά μετατοπίζουμε το κεφάλι προς τα πίσω και, στη συνέχεια, αντιγράφουμε την ουρά στη σωστή θέση.
            //
            //
            // από: DEFGH .... ABC
            // σε: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Προς το παρόν δεν θεωρούμε .... ABCDEFGH
            // να γειτνιάζει γιατί το `head` θα είναι `0` σε αυτήν την περίπτωση.
            // Αν και πιθανότατα θέλουμε να το αλλάξουμε αυτό, δεν είναι ασήμαντο, καθώς μερικά μέρη αναμένουν ότι το `is_contiguous` σημαίνει ότι μπορούμε απλά να κόψουμε χρησιμοποιώντας το `buf[tail..head]`.
            //
            //

            // υπάρχει αρκετός ελεύθερος χώρος για να αντιγράψετε το κεφάλι με μία κίνηση, αυτό σημαίνει ότι πρώτα μετακινούμε την ουρά προς τα εμπρός και, στη συνέχεια, αντιγράφουμε το κεφάλι στη σωστή θέση.
            //
            //
            // από: FGH .... ABCDE
            // σε: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // το ελεύθερο είναι μικρότερο από το κεφάλι και την ουρά, αυτό σημαίνει ότι πρέπει να "swap" αργά η ουρά και το κεφάλι.
            //
            //
            // από: EFGHI ... ABCD ή HIJK.ABCDEFG
            // σε: ABCDEFGHI ... ή ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Το γενικό πρόβλημα μοιάζει με αυτό το GHIJKLM ... ABCDEF, πριν από οποιαδήποτε ανταλλαγή ABCDEFM ... GHIJKL, μετά από 1 πέρασμα ανταλλαγής ABCDEFGHIJM ... KL, αλλάξτε έως ότου το αριστερό edge φτάσει στο προσωρινό κατάστημα
                //                  - στη συνέχεια επανεκκινήστε τον αλγόριθμο με ένα νέο κατάστημα (smaller) Μερικές φορές το temp store επιτυγχάνεται όταν το σωστό edge βρίσκεται στο τέλος του buffer, αυτό σημαίνει ότι έχουμε φτάσει στη σωστή σειρά με λιγότερα swaps!
                //
                // E.g
                // EF..ABCD ABCDEF .., μετά από τέσσερα μόνο swaps έχουμε τελειώσει
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Περιστρέφει την ουρά `mid` με δύο άκρες στα αριστερά.
    ///
    /// Equivalently,
    /// - Περιστρέφει το αντικείμενο `mid` στην πρώτη θέση.
    /// - Ανοίγει τα πρώτα αντικείμενα `mid` και τα ωθεί στο τέλος.
    /// - Περιστρέφει τα μέρη `len() - mid` προς τα δεξιά.
    ///
    /// # Panics
    ///
    /// Εάν το `mid` είναι μεγαλύτερο από το `len()`.
    /// Σημειώστε ότι το `mid == len()` κάνει _not_ panic και είναι μια εναλλαγή χωρίς-op.
    ///
    /// # Complexity
    ///
    /// Παίρνει χρόνο `*O*(min(mid, len() - mid))` και χωρίς επιπλέον χώρο.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Περιστρέφει τις θέσεις `k` στην ουρά διπλής όψης προς τα δεξιά.
    ///
    /// Equivalently,
    /// - Περιστρέφει το πρώτο αντικείμενο στη θέση `k`.
    /// - Ανοίγει τα τελευταία αντικείμενα `k` και τα ωθεί προς τα εμπρός.
    /// - Περιστρέφει τα μέρη `len() - k` προς τα αριστερά.
    ///
    /// # Panics
    ///
    /// Εάν το `k` είναι μεγαλύτερο από το `len()`.
    /// Σημειώστε ότι το `k == len()` κάνει _not_ panic και είναι μια εναλλαγή χωρίς-op.
    ///
    /// # Complexity
    ///
    /// Παίρνει χρόνο `*O*(min(k, len() - k))` και χωρίς επιπλέον χώρο.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // ΑΣΦΑΛΕΙΑ: οι ακόλουθες δύο μέθοδοι απαιτούν το ποσό περιστροφής
    // να είναι μικρότερο από το μισό του μήκους.
    //
    // `wrap_copy` απαιτεί το `min(x, cap() - x) + copy_len <= cap()`, αλλά το `min` δεν είναι ποτέ περισσότερο από το ήμισυ της χωρητικότητας, ανεξάρτητα από το x, οπότε είναι καλό να καλέσετε εδώ γιατί καλούμε με κάτι μικρότερο από το μισό μήκος, το οποίο δεν είναι ποτέ πάνω από το μισό της χωρητικότητας.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Δυαδική αναζητά αυτό το ταξινομημένο `VecDeque` για ένα δεδομένο στοιχείο.
    ///
    /// Εάν βρεθεί η τιμή, τότε επιστρέφεται το [`Result::Ok`], το οποίο περιέχει το ευρετήριο του αντίστοιχου στοιχείου.
    /// Εάν υπάρχουν πολλοί αγώνες, τότε θα μπορούσε να επιστραφεί κάποιος από τους αγώνες.
    /// Εάν η τιμή δεν βρεθεί τότε το [`Result::Err`] επιστρέφεται, που περιέχει το ευρετήριο όπου θα μπορούσε να εισαχθεί ένα αντίστοιχο στοιχείο διατηρώντας τη σειρά ταξινόμησης.
    ///
    ///
    /// # Examples
    ///
    /// Αναζητά μια σειρά τεσσάρων στοιχείων.
    /// Το πρώτο βρίσκεται, με μια μοναδικά καθορισμένη θέση.το δεύτερο και το τρίτο δεν βρέθηκαν.το τέταρτο θα μπορούσε να ταιριάξει με οποιαδήποτε θέση στο `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Εάν θέλετε να εισαγάγετε ένα στοιχείο σε ταξινομημένο `VecDeque`, διατηρώντας παράλληλα τη σειρά ταξινόμησης:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Δυαδική αναζήτηση αυτού του ταξινομημένου `VecDeque` με μια λειτουργία σύγκρισης.
    ///
    /// Η συνάρτηση σύγκρισης πρέπει να εφαρμόσει μια παραγγελία σύμφωνα με τη σειρά ταξινόμησης του υποκείμενου `VecDeque`, επιστρέφοντας έναν κωδικό παραγγελίας που υποδεικνύει εάν το επιχείρημά του είναι `Less`, `Equal` ή `Greater` από τον επιθυμητό στόχο.
    ///
    ///
    /// Εάν βρεθεί η τιμή, τότε επιστρέφεται το [`Result::Ok`], το οποίο περιέχει το ευρετήριο του αντίστοιχου στοιχείου.Εάν υπάρχουν πολλοί αγώνες, τότε θα μπορούσε να επιστραφεί κάποιος από τους αγώνες.
    /// Εάν η τιμή δεν βρεθεί τότε το [`Result::Err`] επιστρέφεται, που περιέχει το ευρετήριο όπου θα μπορούσε να εισαχθεί ένα αντίστοιχο στοιχείο διατηρώντας τη σειρά ταξινόμησης.
    ///
    /// # Examples
    ///
    /// Αναζητά μια σειρά τεσσάρων στοιχείων.Το πρώτο βρίσκεται, με μια μοναδικά καθορισμένη θέση.το δεύτερο και το τρίτο δεν βρέθηκαν.το τέταρτο θα μπορούσε να ταιριάζει με οποιαδήποτε θέση στο `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Δυαδική αναζήτηση αυτού του ταξινομημένου `VecDeque` με λειτουργία εξαγωγής κλειδιού.
    ///
    /// Υποθέτει ότι το `VecDeque` ταξινομείται με το κλειδί, για παράδειγμα με το [`make_contiguous().sort_by_key()`](#method.make_contiguous) χρησιμοποιώντας την ίδια λειτουργία εξαγωγής κλειδιού.
    ///
    ///
    /// Εάν βρεθεί η τιμή, τότε επιστρέφεται το [`Result::Ok`], το οποίο περιέχει το ευρετήριο του αντίστοιχου στοιχείου.
    /// Εάν υπάρχουν πολλοί αγώνες, τότε θα μπορούσε να επιστραφεί κάποιος από τους αγώνες.
    /// Εάν η τιμή δεν βρεθεί τότε το [`Result::Err`] επιστρέφεται, που περιέχει το ευρετήριο όπου θα μπορούσε να εισαχθεί ένα αντίστοιχο στοιχείο διατηρώντας τη σειρά ταξινόμησης.
    ///
    /// # Examples
    ///
    /// Αναζητά μια σειρά τεσσάρων στοιχείων σε μια φέτα ζευγών ταξινομημένων κατά τα δεύτερα στοιχεία τους.
    /// Το πρώτο βρίσκεται, με μια μοναδικά καθορισμένη θέση.το δεύτερο και το τρίτο δεν βρέθηκαν.το τέταρτο θα μπορούσε να ταιριάξει με οποιαδήποτε θέση στο `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Τροποποιεί το `VecDeque` στη θέση του, έτσι ώστε το `len()` να είναι ίσο με το new_len, είτε αφαιρώντας περίσσεια στοιχείων από το πίσω μέρος είτε προσαρτώντας κλώνους του `value` στο πίσω μέρος.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Επιστρέφει το ευρετήριο στο υποκείμενο buffer για ένα δεδομένο λογικό στοιχείο ευρετηρίου.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // το μέγεθος είναι πάντα δύναμη 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Υπολογίστε τον αριθμό των στοιχείων που απομένουν για ανάγνωση στο buffer
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // το μέγεθος είναι πάντα δύναμη 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Πάντα διαιρούμενο σε τρεις ενότητες, για παράδειγμα: αυτο: [a b c|d e f] άλλο: [0 1 2 3|4 5] μπροστά=3, mid=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Δεν είναι δυνατή η χρήση του Hash::hash_slice σε φέτες που επιστρέφονται με τη μέθοδο as_slices, καθώς το μήκος τους μπορεί να ποικίλλει σε διαφορετικά πανομοιότυπα.
        //
        //
        // Το Hasher εγγυάται μόνο ισοδυναμία για το ίδιο ακριβώς σύνολο κλήσεων με τις μεθόδους του.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Καταναλώνει το `VecDeque` σε επαναληπτικό εμπρός-πίσω-αποδίδοντας στοιχεία από την τιμή.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Αυτή η λειτουργία πρέπει να είναι το ηθικό ισοδύναμο:
        //
        //      για αντικείμενο σε iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Μετατρέψτε το [`Vec<T>`] σε [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Αυτό αποφεύγει την ανακατανομή όπου είναι δυνατόν, αλλά οι προϋποθέσεις για αυτό είναι αυστηρές και υπόκεινται σε αλλαγές, και έτσι δεν πρέπει να βασίζεστε εκτός εάν το `Vec<T>` προέρχεται από το `From<VecDeque<T>>` και δεν έχει ανακατανεμηθεί.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Δεν υπάρχει πραγματική κατανομή για τα ZST να ανησυχούν για χωρητικότητα, αλλά το `VecDeque` δεν μπορεί να χειριστεί τόσο μεγάλο όσο το `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Πρέπει να αλλάξουμε το μέγεθος εάν η χωρητικότητα δεν είναι δύναμη δύο, πολύ μικρή ή δεν έχει τουλάχιστον έναν ελεύθερο χώρο.
            // Το κάνουμε αυτό ενώ είναι ακόμα στο `Vec`, έτσι τα αντικείμενα θα πέσουν στο panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Μετατρέψτε το [`VecDeque<T>`] σε [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Αυτό δεν χρειάζεται ποτέ να ανακατανεμηθεί, αλλά χρειάζεται να κάνετε *O*(*n*) μετακίνηση δεδομένων εάν το κυκλικό buffer δεν είναι στην αρχή της κατανομής.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Αυτό είναι *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Αυτό χρειάζεται αναδιάταξη δεδομένων.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}