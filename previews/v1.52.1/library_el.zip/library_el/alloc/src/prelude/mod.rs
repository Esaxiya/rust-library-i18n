//! Η κατανομή Prelude
//!
//! Ο σκοπός αυτής της ενότητας είναι να μετριάσει τις εισαγωγές αντικειμένων που χρησιμοποιούνται συνήθως από το `alloc` crate προσθέτοντας μια εισαγωγή σφαιρών στην κορυφή των ενοτήτων:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;