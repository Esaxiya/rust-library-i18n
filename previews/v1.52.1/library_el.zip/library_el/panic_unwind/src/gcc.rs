//! Υλοποίηση του panics που υποστηρίζεται από το libgcc/libunwind (σε κάποια μορφή).
//!
//! Για φόντο σχετικά με το χειρισμό εξαιρέσεων και το ξετύλιγμα στοίβας, ανατρέξτε στο "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) και τα έγγραφα που συνδέονται από αυτό.
//! Αυτές είναι επίσης καλές διαβάσεις:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Μια σύντομη περίληψη
//!
//! Ο χειρισμός εξαίρεσης συμβαίνει σε δύο φάσεις: μια φάση αναζήτησης και μια φάση καθαρισμού.
//!
//! Και στις δύο φάσεις, ο ξετυλίκτης περπατά στοίβες πλαισίων από πάνω προς τα κάτω χρησιμοποιώντας πληροφορίες από τις στοίβες πλαισίων ξετυλίγματος των ενοτήτων της τρέχουσας διαδικασίας (το "module" εδώ αναφέρεται σε λειτουργική μονάδα, δηλαδή σε εκτελέσιμη ή δυναμική βιβλιοθήκη).
//!
//!
//! Για κάθε πλαίσιο στοίβας, επικαλείται το σχετικό "personality routine", του οποίου η διεύθυνση αποθηκεύεται επίσης στην ενότητα πληροφοριών χαλάρωσης.
//!
//! Στη φάση αναζήτησης, η δουλειά μιας ρουτίνας προσωπικότητας είναι να εξετάσει το αντικείμενο εξαίρεσης που ρίχνεται και να αποφασίσει εάν πρέπει να πιάσει σε αυτό το πλαίσιο στοίβας.Μόλις αναγνωριστεί το πλαίσιο χειριστή, ξεκινά η φάση καθαρισμού.
//!
//! Στη φάση εκκαθάρισης, ο ξετυλίγοντας επικαλεί ξανά κάθε ρουτίνα προσωπικότητας.
//! Αυτή τη φορά αποφασίζει ποιος (εάν υπάρχει) κωδικός καθαρισμού πρέπει να εκτελεστεί για το τρέχον πλαίσιο στοίβας.Εάν ναι, το στοιχείο ελέγχου μεταφέρεται σε ένα ειδικό branch στο σώμα λειτουργίας, το "landing pad", το οποίο επικαλείται καταστροφές, ελευθερώνει μνήμη κ.λπ.
//! Στο τέλος της επιφάνειας προσγείωσης, ο έλεγχος μεταφέρεται πίσω στο ξετύλιγμα και τα ξετυλίγματα συνεχίζονται.
//!
//! Μόλις η στοίβα ξετυλιχθεί μέχρι το επίπεδο του πλαισίου του χειριστή, οι στάσεις ξετυλίγματος και η τελευταία ρουτίνα προσωπικότητας μεταφέρει τον έλεγχο στο μπλοκ σύλληψης.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Αναγνωριστικό κλάσης εξαίρεσης του Rust.
// Αυτό χρησιμοποιείται από ρουτίνες προσωπικότητας για να προσδιορίσει εάν η εξαίρεση απορρίφθηκε από το δικό τους χρόνο εκτέλεσης.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-προμηθευτής, γλώσσα
    0x4d4f5a_00_52555354
}

// Τα αναγνωριστικά εγγραφής ανακτήθηκαν από τα TargetLowering::getExceptionPointerRegister() και TargetLowering::getExceptionSelectorRegister() του LLVM για κάθε αρχιτεκτονική, στη συνέχεια αντιστοιχίστηκαν σε αριθμούς μητρώου DWARF μέσω πινάκων ορισμού μητρώου (συνήθως<arch>RegisterInfo.td, αναζήτηση για "DwarfRegNum").
//
// Δείτε επίσης http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Ο ακόλουθος κώδικας βασίζεται στις ρουτίνες προσωπικότητας C και C++ του GCC.Για αναφορά, δείτε:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM Ρουτίνα προσωπικότητας EHABI.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS χρησιμοποιεί την προεπιλεγμένη ρουτίνα, επειδή χρησιμοποιεί το SjLj ξετύλιγμα.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Τα Backtraces στο ARM θα καλέσουν την προσωπικότητα ρουτίνα με κατάσταση==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Σε αυτές τις περιπτώσεις θέλουμε να συνεχίσουμε να ξετυλίγουμε τη στοίβα, διαφορετικά όλα τα backtraces μας θα τελειώσουν στο __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // Το μηχάνημα DWARF υποθέτει ότι το _Unwind_Context κρατά πράγματα όπως η συνάρτηση και οι δείκτες LSDA, ωστόσο το ARM EHABI τα τοποθετεί στο αντικείμενο εξαίρεσης.
            // Για να διατηρήσετε τις υπογραφές λειτουργιών όπως το _Unwind_GetLanguageSpecificData(), οι οποίες λαμβάνουν μόνο το δείκτη περιβάλλοντος, οι ρουτίνες προσωπικότητας GCC αποθηκεύουν έναν δείκτη στην εξαίρεση_ αντικείμενο στο περιβάλλον, χρησιμοποιώντας την τοποθεσία που προορίζεται για το "scratch register" (r12) του ARM.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Μια πιο βασισμένη προσέγγιση θα ήταν να παρέχουμε τον πλήρη ορισμό του _Unwind_Context του ARM στις δεσμεύσεις libunwind και να πάρουμε τα απαιτούμενα δεδομένα από εκεί απευθείας, παρακάμπτοντας τις λειτουργίες συμβατότητας DWARF.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // Το EHABI απαιτεί τη ρουτίνα προσωπικότητας για την ενημέρωση της τιμής SP στην προσωρινή μνήμη του αντικειμένου εξαίρεσης.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Στο ARM EHABI, η ρουτίνα προσωπικότητας είναι υπεύθυνη για την πραγματική χαλάρωση ενός πλαισίου στοίβας πριν από την επιστροφή (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // ορίζεται στο libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Προεπιλεγμένη ρουτίνα προσωπικότητας, η οποία χρησιμοποιείται απευθείας στους περισσότερους στόχους και έμμεσα στο Windows x86_64 μέσω SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Στους στόχους x86_64 MinGW, ο μηχανισμός ξετυλίγματος είναι SEH, ωστόσο τα δεδομένα χειριστή ξετυλίγματος (γνωστός και ως LSDA) χρησιμοποιούν κωδικοποίηση συμβατή με GCC.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Η ρουτίνα της προσωπικότητας για τους περισσότερους από τους στόχους μας.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Η διεύθυνση επιστροφής σημειώνει 1 byte μετά την εντολή κλήσης, η οποία θα μπορούσε να βρίσκεται στην επόμενη περιοχή IP στον πίνακα εύρους LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Πλαίσιο εγγραφής πληροφοριών ξεκούρασης
//
// Η εικόνα κάθε ενότητας περιέχει μια ενότητα πληροφοριών ξετυλίγματος πλαισίου (συνήθως ".eh_frame").Όταν μια μονάδα είναι loaded/unloaded στη διαδικασία, ο ξετυλίκτης πρέπει να ενημερωθεί για τη θέση αυτής της ενότητας στη μνήμη.Οι μέθοδοι επίτευξης που διαφέρουν ανάλογα με την πλατφόρμα.
// Σε ορισμένα (π.χ. Linux), το ξετυλίγματος μπορεί να ανακαλύψει μόνο του τις ενότητες πληροφοριών ξεκούρασης (απαριθμώντας δυναμικά τις τρέχουσες φορτωμένες ενότητες μέσω του dl_iterate_phdr() API and finding their ".eh_frame" sections). Άλλοι, όπως το Windows, απαιτούν μονάδες για την ενεργή καταχώριση των τμημάτων πληροφοριών ξεκούρασης μέσω του API ανεβασμού
//
//
// Αυτή η ενότητα ορίζει δύο σύμβολα που αναφέρονται και καλούνται από το rsbegin.rs για να καταχωρήσουν τις πληροφορίες μας στον χρόνο εκτέλεσης GCC.
// Η υλοποίηση της στοίβας ξετυλίγματος (προς το παρόν) αναβάλλεται στο libgcc_eh, ωστόσο το Rust crates χρησιμοποιεί αυτά τα ειδικά σημεία εισόδου Rust για να αποφύγει πιθανές συγκρούσεις με οποιοδήποτε χρόνο εκτέλεσης GCC.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}