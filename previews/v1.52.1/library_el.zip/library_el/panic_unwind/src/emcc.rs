//! Ξετύλιγμα για τον στόχο *emscripten*.
//!
//! Ενώ η συνήθης χαλαρωτική εφαρμογή του Rust για τις πλατφόρμες Unix καλεί απευθείας τα libunwind APIs, στο Emscripten αντ 'αυτού καλούμε τα C++ ξετυλίγοντας API.
//! Αυτό είναι απλώς μια χρησιμότητα δεδομένου ότι ο χρόνος εκτέλεσης του Emscripten εφαρμόζει πάντα αυτά τα API και δεν εφαρμόζει libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Αυτό ταιριάζει με τη διάταξη του std::type_info στο C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // Το κορυφαίο byte `\x01` εδώ είναι στην πραγματικότητα ένα μαγικό σήμα για το LLVM να *δεν* εφαρμόσει οποιοδήποτε άλλο mangling όπως το πρόθεμα με χαρακτήρα `_`.
    //
    //
    // Αυτό το σύμβολο είναι το vtable που χρησιμοποιείται από το `std::type_info` του C++ .
    // Αντικείμενα τύπου `std::type_info`, τύποι περιγραφών, έχουν δείκτη σε αυτόν τον πίνακα.
    // Οι περιγραφείς τύπου αναφέρονται από τις δομές C++ EH που ορίζονται παραπάνω και που κατασκευάζουμε παρακάτω.
    //
    // Σημειώστε ότι το πραγματικό μέγεθος είναι μεγαλύτερο από 3 usize, αλλά χρειαζόμαστε μόνο το vtable μας για να δείξουμε το τρίτο στοιχείο.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info για μια κατηγορία rust_panic
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Κανονικά θα χρησιμοποιούσαμε το .as_ptr().add(2), αλλά αυτό δεν λειτουργεί σε περιβάλλον const.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Αυτό σκόπιμα δεν χρησιμοποιεί το κανονικό σχήμα mangling, επειδή δεν θέλουμε το C++ να μπορεί να παράγει ή να πιάνει Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Αυτό είναι απαραίτητο, επειδή ο κώδικας C++ μπορεί να καταγράψει την εκτέλεσή μας με std::exception_ptr και να τον ξαναρχίσουμε πολλές φορές, πιθανώς ακόμη και σε άλλο νήμα.
    //
    //
    caught: AtomicBool,

    // Αυτό πρέπει να είναι μια επιλογή, επειδή η διάρκεια ζωής του αντικειμένου ακολουθεί τη σημασιολογία C++ : όταν το catch_unwind μετακινεί το πλαίσιο από την εξαίρεση, πρέπει να αφήσει το αντικείμενο εξαίρεσης σε έγκυρη κατάσταση, επειδή ο καταστροφικός του εξακολουθεί να καλείται από __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try πραγματικά μας δίνει έναν δείκτη σε αυτήν τη δομή.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Δεδομένου ότι το cleanup() δεν επιτρέπεται να panic, απλώς ακυρώνουμε.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}