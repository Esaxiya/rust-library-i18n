//! Ξετυλίγοντας panics για Miri.
use alloc::boxed::Box;
use core::any::Any;

// Ο τύπος του ωφέλιμου φορτίου που διαδίδει ο κινητήρας Miri ξετυλίγοντας για εμάς.
// Πρέπει να έχει μέγεθος δείκτη.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Εξωτερική λειτουργία που παρέχεται από το Miri για να ξεκινήσει η χαλάρωση.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Το ωφέλιμο φορτίο που περνάμε στο `miri_start_panic` θα είναι ακριβώς το επιχείρημα που έχουμε στο `cleanup` παρακάτω.
    // Οπότε απλώς το τοποθετούμε μία φορά, για να πάρουμε κάτι σε μέγεθος δείκτη.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Ανακτήστε το υποκείμενο `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}