//! Μια βιβλιοθήκη υποστήριξης για συγγραφείς μακροεντολών κατά τον ορισμό νέων μακροεντολών.
//!
//! Αυτή η βιβλιοθήκη, που παρέχεται από την τυπική διανομή, παρέχει τους τύπους που καταναλώνονται στις διεπαφές καθορισμένων διαδικαστικών ορισμών μακροεντολών, όπως λειτουργίες όπως μακροεντολές `#[proc_macro]`, μακροεντολές `#[proc_macro_attribute]` και προσαρμοσμένα παράγωγα χαρακτηριστικά`#[proc_macro_derive]".
//!
//!
//! Δείτε το [the book] για περισσότερα.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Καθορίζει εάν το proc_macro έχει καταστεί προσβάσιμο στο τρέχον πρόγραμμα.
///
/// Το proc_macro crate προορίζεται μόνο για χρήση εντός της εφαρμογής διαδικαστικών μακροεντολών.Όλες οι συναρτήσεις σε αυτό το crate panic, εάν κληθούν έξω από μια διαδικαστική μακροεντολή, όπως από ένα σενάριο build ή μια δοκιμαστική μονάδα ή ένα συνηθισμένο δυαδικό Rust.
///
/// Λαμβάνοντας υπόψη τις βιβλιοθήκες Rust που έχουν σχεδιαστεί για να υποστηρίζουν τόσο περιπτώσεις χρήσης μακροεντολών όσο και μη μακροεντολών, το `proc_macro::is_available()` παρέχει έναν τρόπο χωρίς πανικό για να εντοπίσει εάν η υποδομή που απαιτείται για τη χρήση του API του proc_macro είναι προς το παρόν διαθέσιμη.
/// Επιστρέφει αληθές εάν κληθεί από το εσωτερικό μιας διαδικαστικής μακροεντολής, ψευδές εάν γίνει επίκληση από οποιοδήποτε άλλο δυαδικό.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Ο κύριος τύπος που παρέχεται από αυτό το crate, αντιπροσωπεύει μια αφηρημένη ροή tokens, ή, πιο συγκεκριμένα, μια ακολουθία δέντρων token.
/// Ο τύπος παρέχει διεπαφές για επανάληψη αυτών των δέντρων token και, αντίθετα, συλλέγοντας έναν αριθμό δέντρων token σε μία ροή.
///
///
/// Αυτό είναι τόσο η είσοδος όσο και η έξοδος των ορισμών `#[proc_macro]`, `#[proc_macro_attribute]` και `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Παρουσιάστηκε σφάλμα από το `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Επιστρέφει ένα κενό `TokenStream` που δεν περιέχει δέντρα token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Ελέγχει εάν αυτό το `TokenStream` είναι κενό.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Προσπάθειες να σπάσει τη συμβολοσειρά σε tokens και να αναλύσει αυτά τα tokens σε μια ροή token.
/// Μπορεί να αποτύχει για διάφορους λόγους, για παράδειγμα, εάν η συμβολοσειρά περιέχει μη ισορροπημένους οριοθέτες ή χαρακτήρες που δεν υπάρχουν στη γλώσσα.
///
/// Όλα τα tokens στην αναλυμένη ροή έχουν έκταση `Span::call_site()`.
///
/// NOTE: ορισμένα σφάλματα ενδέχεται να προκαλέσουν panics αντί να επιστρέψουν το `LexError`.Διατηρούμε το δικαίωμα να αλλάξουμε αυτά τα σφάλματα σε "LexError" αργότερα.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// Σημείωση, η γέφυρα παρέχει μόνο `to_string`, υλοποιεί το `fmt::Display` με βάση αυτό (το αντίστροφο της συνηθισμένης σχέσης μεταξύ των δύο).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Εκτυπώνει τη ροή token ως συμβολοσειρά που υποτίθεται ότι μπορεί να μετατραπεί χωρίς απώλειες στην ίδια ροή token (modulo spans), εκτός από πιθανώς το "TokenTree: : Group`s με οριοθέτες `Delimiter::None` και αρνητικά αριθμητικά γράμματα.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Εκτυπώνει το token σε μορφή κατάλληλη για εντοπισμό σφαλμάτων.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Δημιουργεί μια ροή token που περιέχει ένα μόνο δέντρο token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Συλλέγει έναν αριθμό δέντρων token σε μία μόνο ροή.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Μια λειτουργία "flattening" σε ροές token, συλλέγει δέντρα token από πολλές ροές token σε μία ροή.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Χρησιμοποιήστε μια βελτιστοποιημένη εφαρμογή if/when δυνατή.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Δημόσιες λεπτομέρειες εφαρμογής για τον τύπο `TokenStream`, όπως επαναληπτικοί.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Επαναληπτικός για τα TokenTream του TokenStream.
    /// Η επανάληψη είναι "shallow", π.χ., η επανάληψη δεν επαναλαμβάνεται σε οριοθετημένες ομάδες και επιστρέφει ολόκληρες ομάδες ως δέντρα token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` δέχεται αυθαίρετο tokens και επεκτείνεται σε `TokenStream` που περιγράφει την είσοδο.
/// Για παράδειγμα, το `quote!(a + b)` θα παράγει μια έκφραση, η οποία, όταν αξιολογηθεί, κατασκευάζει τα `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Η αποσύνδεση γίνεται με το `$` και λειτουργεί λαμβάνοντας την επόμενη ταυτότητα ως τον μη εισαγωγικό όρο.
/// Για να παραθέσετε το ίδιο το `$`, χρησιμοποιήστε το `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Μια περιοχή πηγαίου κώδικα, μαζί με πληροφορίες επέκτασης μακροεντολών.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Δημιουργεί ένα νέο `Diagnostic` με το δεδομένο `message` στο εύρος `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Ένα εύρος που επιλύεται στον ιστότοπο ορισμού μακροεντολών.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Η διάρκεια της επίκλησης της τρέχουσας διαδικαστικής μακροεντολής.
    /// Τα αναγνωριστικά που δημιουργούνται με αυτό το εύρος θα επιλυθούν σαν να γράφτηκαν απευθείας στην τοποθεσία μακροεντολών κλήσης (υγιεινή τοποθεσίας κλήσεων) και άλλος κωδικός στον ιστότοπο μακροεντολών κλήσεων θα μπορεί επίσης να αναφέρεται σε αυτά.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Ένα εύρος που αντιπροσωπεύει την υγιεινή `macro_rules` και μερικές φορές επιλύεται στον ιστότοπο ορισμού μακροεντολών (τοπικές μεταβλητές, ετικέτες, `$crate`) και μερικές φορές στον ιστότοπο κλήσεων μακροεντολών (οτιδήποτε άλλο).
    ///
    /// Η τοποθεσία του span λαμβάνεται από τον ιστότοπο κλήσεων.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Το αρχικό αρχείο προέλευσης στο οποίο δείχνει αυτό το εύρος.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// Το `Span` για το tokens στην προηγούμενη επέκταση μακροεντολής από την οποία δημιουργήθηκε το `self`, εάν υπάρχει.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Το εύρος για τον πηγαίο κώδικα προέλευσης από τον οποίο δημιουργήθηκε το `self`.
    /// Εάν αυτό το `Span` δεν δημιουργήθηκε από άλλες επεκτάσεις μακροεντολών, τότε η τιμή επιστροφής είναι η ίδια με το `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Παίρνει το αρχικό line/column στο αρχείο προέλευσης για αυτό το εύρος.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Παίρνει το line/column στο αρχείο προέλευσης για αυτό το εύρος.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Δημιουργεί ένα νέο εύρος που περιλαμβάνει `self` και `other`.
    ///
    /// Επιστρέφει `None` εάν τα `self` και `other` προέρχονται από διαφορετικά αρχεία.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Δημιουργεί ένα νέο εύρος με τις ίδιες πληροφορίες line/column με το `self`, αλλά επιλύει σύμβολα σαν να ήταν στο `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Δημιουργεί ένα νέο εύρος με την ίδια συμπεριφορά ανάλυσης ονόματος με το `self` αλλά με τις πληροφορίες line/column του `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Συγκρίνεται με τα ανοίγματα για να δει αν είναι ίσες.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Επιστρέφει το κείμενο προέλευσης πίσω από ένα διάστημα.
    /// Αυτό διατηρεί τον αρχικό πηγαίο κώδικα, συμπεριλαμβανομένων κενών και σχολίων.
    /// Επιστρέφει ένα αποτέλεσμα μόνο εάν το εύρος αντιστοιχεί στον πραγματικό πηγαίο κώδικα.
    ///
    /// Note: Το παρατηρήσιμο αποτέλεσμα μιας μακροεντολής πρέπει να βασίζεται μόνο στο tokens και όχι σε αυτό το κείμενο προέλευσης.
    ///
    /// Το αποτέλεσμα αυτής της λειτουργίας είναι η καλύτερη προσπάθεια που χρησιμοποιείται μόνο για διαγνωστικά.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Εκτυπώνει ένα εύρος σε μορφή κατάλληλη για εντοπισμό σφαλμάτων.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Ένα ζεύγος γραμμής-στήλης που αντιπροσωπεύει την αρχή ή το τέλος ενός `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Η γραμμή 1-ευρετηρίου στο αρχείο προέλευσης από την οποία ξεκινά ή τελειώνει το εύρος (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Η στήλη με ευρετήριο 0 (σε χαρακτήρες UTF-8) στο αρχείο προέλευσης στο οποίο ξεκινά ή τελειώνει το εύρος (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Το αρχείο προέλευσης ενός δεδομένου `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Παίρνει τη διαδρομή προς αυτό το αρχείο προέλευσης.
    ///
    /// ### Note
    /// Εάν το εύρος κώδικα που σχετίζεται με αυτό το `SourceFile` δημιουργήθηκε από μια εξωτερική μακροεντολή, αυτή η μακροεντολή, ενδέχεται να μην είναι μια πραγματική διαδρομή στο σύστημα αρχείων.
    /// Χρησιμοποιήστε το [`is_real`] για έλεγχο.
    ///
    /// Σημειώστε επίσης ότι ακόμη και αν το `is_real` επιστρέψει το `true`, εάν το `--remap-path-prefix` πέρασε στη γραμμή εντολών, η διαδρομή όπως έχει δοθεί ενδέχεται να μην είναι στην πραγματικότητα έγκυρη.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Επιστρέφει `true` εάν αυτό το αρχείο προέλευσης είναι πραγματικό αρχείο προέλευσης και δεν δημιουργείται από επέκταση εξωτερικής μακροεντολής.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Αυτό είναι ένα hack έως ότου εφαρμοστούν τα intercrate spans και μπορούμε να έχουμε αρχεία πραγματικής πηγής για spans που δημιουργούνται σε εξωτερικές μακροεντολές.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Ένα μοναδικό token ή μια οριοθετημένη ακολουθία δέντρων token (π.χ. `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Μια ροή token που περιβάλλεται από οριοθέτες αγκυλών.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Ένα αναγνωριστικό.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Ένας μεμονωμένος χαρακτήρας στίξης ("+", `,`, `$`, κ.λπ.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Ένας κυριολεκτικός χαρακτήρας (`'a'`), συμβολοσειρά (`"hello"`), αριθμός (`2.3`), κ.λπ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Επιστρέφει το εύρος αυτού του δέντρου, εκχωρώντας στη μέθοδο `span` του περιεχόμενου token ή σε οριοθετημένη ροή.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Διαμορφώνει το εύρος για *μόνο αυτό το token*.
    ///
    /// Σημειώστε ότι εάν αυτό το token είναι `Group`, τότε αυτή η μέθοδος δεν θα διαμορφώσει το εύρος καθενός από τα εσωτερικά tokens, αυτό θα μεταβιβάσει απλά στη μέθοδο `set_span` κάθε παραλλαγής.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Εκτυπώνει το δέντρο token σε μορφή κατάλληλη για εντοπισμό σφαλμάτων.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Κάθε ένα από αυτά έχει το όνομα στον τύπο δομής του παραγόμενου εντοπισμού σφαλμάτων, οπότε μην ενοχλείτε με ένα επιπλέον επίπεδο έμμεσης
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// Σημείωση, η γέφυρα παρέχει μόνο `to_string`, υλοποιεί το `fmt::Display` με βάση αυτό (το αντίστροφο της συνηθισμένης σχέσης μεταξύ των δύο).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Εκτυπώνει το δέντρο token ως συμβολοσειρά που υποτίθεται ότι μπορεί να μετατραπεί χωρίς απώλειες στο ίδιο δέντρο token (modulo spans), εκτός από πιθανώς το «TokenTree: : Group`s με οριοθέτες `Delimiter::None` και αρνητικά αριθμητικά γράμματα.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Μια οριοθετημένη ροή token.
///
/// Ένα `Group` περιέχει εσωτερικά ένα `TokenStream` που περιβάλλεται από το «Delimiter».
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Περιγράφει πώς οριοθετείται μια ακολουθία δέντρων token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Ένας σιωπηρός οριοθέτης, που μπορεί, για παράδειγμα, να εμφανίζεται γύρω από το tokens που προέρχεται από ένα "macro variable" `$var`.
    /// Είναι σημαντικό να διατηρήσετε τις προτεραιότητες του χειριστή σε περιπτώσεις όπως το `$var * 3` όπου το `$var` είναι `1 + 2`.
    /// Οι έμμεσοι οριοθέτες ενδέχεται να μην επιβιώσουν από τη διαδρομή token μέσω μιας συμβολοσειράς.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Δημιουργεί ένα νέο `Group` με το δεδομένο οριοθέτη και τη ροή token.
    ///
    /// Αυτός ο κατασκευαστής θα ορίσει το εύρος αυτής της ομάδας σε `Span::call_site()`.
    /// Για να αλλάξετε το εύρος μπορείτε να χρησιμοποιήσετε τη μέθοδο `set_span` παρακάτω.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Επιστρέφει το όριο αυτού του `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Επιστρέφει το `TokenStream` του tokens που οριοθετείται σε αυτό το `Group`.
    ///
    /// Σημειώστε ότι η επιστρεφόμενη ροή token δεν περιλαμβάνει τον οριοθέτη που επιστρέφεται παραπάνω.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Επιστρέφει το εύρος για τους οριοθέτες αυτής της ροής token, καλύπτοντας ολόκληρο το `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Επιστρέφει το εύρος προς το άνοιγμα οριοθέτη αυτής της ομάδας.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Επιστρέφει το εύρος που δείχνει στον οριοθέτη κλεισίματος αυτής της ομάδας.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Διαμορφώνει το εύρος για τους οριοθέτες αυτού του «Ομίλου», αλλά όχι το εσωτερικό του tokens.
    ///
    /// Αυτή η μέθοδος **δεν** θα ορίσει το εύρος όλων των εσωτερικών tokens που εκτείνονται από αυτήν την ομάδα, αλλά μάλλον θα ορίσει το εύρος του οριοθέτη tokens στο επίπεδο του `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// Σημείωση, η γέφυρα παρέχει μόνο `to_string`, υλοποιεί το `fmt::Display` με βάση αυτό (το αντίστροφο της συνηθισμένης σχέσης μεταξύ των δύο).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Εκτυπώνει την ομάδα ως συμβολοσειρά που θα πρέπει να μετατρέπεται χωρίς απώλειες στην ίδια ομάδα (modulo spans), εκτός από πιθανώς το «TokenTree: : Group`s με οριοθέτες `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// Το `Punct` είναι ένας χαρακτήρας στίξης όπως οι `+`, `-` ή `#`.
///
/// Οι τελεστές πολλαπλών χαρακτήρων όπως το `+=` παρουσιάζονται ως δύο παρουσίες του `Punct` με διαφορετικές μορφές `Spacing`.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Εάν ένα `Punct` ακολουθείται αμέσως από άλλο `Punct` ή ακολουθεί άλλο token ή κενό διάστημα.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// π.χ., το `+` είναι `Alone` σε `+ =`, `+ident` ή `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// π.χ., το `+` είναι `Joint` σε `+=` ή `'#`.
    /// Επιπλέον, ένα μόνο απόσπασμα `'` μπορεί να ενώσει με αναγνωριστικά για να σχηματίσει τη διάρκεια ζωής `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Δημιουργεί ένα νέο `Punct` από τον δεδομένο χαρακτήρα και το διάστημα.
    /// Το όρισμα `ch` πρέπει να είναι έγκυρος χαρακτήρας στίξης που επιτρέπεται από τη γλώσσα, διαφορετικά η συνάρτηση θα είναι panic.
    ///
    /// Το επιστρεφόμενο `Punct` θα έχει το προεπιλεγμένο εύρος του `Span::call_site()` το οποίο μπορεί να διαμορφωθεί περαιτέρω με τη μέθοδο `set_span` παρακάτω.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Επιστρέφει την τιμή αυτού του χαρακτήρα στίξης ως `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Επιστρέφει το διάστημα αυτού του χαρακτήρα στίξης, υποδεικνύοντας αν ακολουθείται αμέσως από άλλο `Punct` στη ροή token, ώστε να μπορούν ενδεχομένως να συνδυαστούν σε χειριστή πολλαπλών χαρακτήρων (`Joint`) ή ακολουθείται από κάποιο άλλο token ή κενό διάστημα (`Alone`), οπότε ο χειριστής έχει σίγουρα τελείωσε.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Επιστρέφει το εύρος για αυτόν τον χαρακτήρα στίξης.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Διαμορφώστε το εύρος για αυτόν τον χαρακτήρα στίξης.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Σημείωση, η γέφυρα παρέχει μόνο `to_string`, υλοποιεί το `fmt::Display` με βάση αυτό (το αντίστροφο της συνηθισμένης σχέσης μεταξύ των δύο).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Εκτυπώνει τον χαρακτήρα στίξης ως συμβολοσειρά που πρέπει να μετατρέπεται χωρίς απώλειες στον ίδιο χαρακτήρα.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Ένα αναγνωριστικό (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Δημιουργεί ένα νέο `Ident` με το δεδομένο `string` καθώς και το καθορισμένο `span`.
    /// Το όρισμα `string` πρέπει να είναι ένα έγκυρο αναγνωριστικό που επιτρέπεται από τη γλώσσα (συμπεριλαμβανομένων λέξεων-κλειδιών, π.χ. `self` ή `fn`).Διαφορετικά, η συνάρτηση θα panic.
    ///
    /// Σημειώστε ότι το `span`, που βρίσκεται επί του παρόντος στο rustc, διαμορφώνει τις πληροφορίες υγιεινής για αυτό το αναγνωριστικό.
    ///
    /// Από τότε, το `Span::call_site()` επιλέγει ρητά την "call-site" υγιεινή που σημαίνει ότι τα αναγνωριστικά που δημιουργούνται με αυτό το εύρος θα επιλυθούν σαν να γράφτηκαν απευθείας στη θέση της μακροεντολής κλήσης και άλλος κωδικός στον ιστότοπο κλήσεων μακροεντολών θα μπορεί να αναφέρεται τους επίσης.
    ///
    ///
    /// Αργότερα ανοίγματα όπως το `Span::def_site()` θα επιτρέψουν την επιλογή "definition-site" υγιεινής, πράγμα που σημαίνει ότι τα αναγνωριστικά που δημιουργούνται με αυτό το εύρος θα επιλυθούν στη θέση του ορισμού της μακροεντολής και άλλος κωδικός στον ιστότοπο κλήσεων μακροεντολών δεν θα μπορεί να αναφέρεται σε αυτά.
    ///
    /// Λόγω της τρέχουσας σημασίας της υγιεινής, αυτός ο κατασκευαστής, σε αντίθεση με άλλους tokens, απαιτεί ένα `Span` να καθοριστεί κατά την κατασκευή.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Το ίδιο με το `Ident::new`, αλλά δημιουργεί ένα μη αναγνωριστικό (`r#ident`).
    /// Το όρισμα `string` είναι ένα έγκυρο αναγνωριστικό που επιτρέπεται από τη γλώσσα (συμπεριλαμβανομένων λέξεων-κλειδιών, π.χ. `fn`).
    /// Λέξεις-κλειδιά που μπορούν να χρησιμοποιηθούν σε τμήματα διαδρομών (π.χ.
    /// `self`, Το "super") δεν υποστηρίζεται και θα προκαλέσει panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Επιστρέφει το εύρος αυτού του `Ident`, που περιλαμβάνει ολόκληρη τη συμβολοσειρά που επιστρέφεται από το [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Διαμορφώνει το εύρος αυτού του `Ident`, αλλάζοντας πιθανώς το περιβάλλον υγιεινής του.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Σημείωση, η γέφυρα παρέχει μόνο `to_string`, υλοποιεί το `fmt::Display` με βάση αυτό (το αντίστροφο της συνηθισμένης σχέσης μεταξύ των δύο).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Εκτυπώνει το αναγνωριστικό ως συμβολοσειρά που πρέπει να μετατρέπεται χωρίς απώλειες στο ίδιο αναγνωριστικό.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Μια κυριολεκτική συμβολοσειρά (`"hello"`), συμβολοσειρά byte (`b"hello"`), χαρακτήρας (`'a'`), χαρακτήρας byte (`b'a'`), ακέραιος αριθμός ή αριθμός κινητού σημείου με ή χωρίς επίθημα («1», `1u8`, `2.3`, `2.3f32`).
///
/// Boolean κυριολεκτικά όπως `true` και `false` δεν ανήκουν εδώ, είναι «Ident».
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Δημιουργεί ένα νέο ακέραιο ακέραιο κυριολεκτικό με την καθορισμένη τιμή.
        ///
        /// Αυτή η συνάρτηση θα δημιουργήσει έναν ακέραιο αριθμό όπως το `1u32` όπου η ακέραια τιμή που καθορίζεται είναι το πρώτο μέρος του token και το ακέραιο είναι επίσης επίθετο στο τέλος.
        /// Οι γραμματοσειρές που δημιουργούνται από αρνητικούς αριθμούς ενδέχεται να μην επιβιώνουν μετ 'επιστροφής μέσω `TokenStream` ή χορδών και μπορεί να χωριστούν σε δύο tokens (`-` και θετικά γράμματα).
        ///
        ///
        /// Τα γράμματα που δημιουργούνται μέσω αυτής της μεθόδου έχουν το εύρος `Span::call_site()` από προεπιλογή, το οποίο μπορεί να διαμορφωθεί με τη μέθοδο `set_span` παρακάτω.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Δημιουργεί ένα νέο ακέραιο ακέραιο κυριολεκτικό με την καθορισμένη τιμή.
        ///
        /// Αυτή η συνάρτηση θα δημιουργήσει έναν ακέραιο αριθμό όπως το `1` όπου η ακέραια τιμή που καθορίζεται είναι το πρώτο μέρος του token.
        /// Δεν έχει οριστεί επίθημα σε αυτό το token, που σημαίνει ότι οι επικλήσεις όπως το `Literal::i8_unsuffixed(1)` είναι ισοδύναμες με `Literal::u32_unsuffixed(1)`.
        /// Τα λογοτεχνικά γράμματα που δημιουργούνται από αρνητικούς αριθμούς ενδέχεται να μην μπορούν να επιβιώσουν στα rountrips μέσω `TokenStream` ή string και μπορεί να χωριστούν σε δύο tokens (`-` και θετικά κυριολεκτικά).
        ///
        ///
        /// Τα γράμματα που δημιουργούνται μέσω αυτής της μεθόδου έχουν το εύρος `Span::call_site()` από προεπιλογή, το οποίο μπορεί να διαμορφωθεί με τη μέθοδο `set_span` παρακάτω.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Δημιουργεί ένα νέο κυριολεκτικό κυμαινόμενο σημείο.
    ///
    /// Αυτός ο κατασκευαστής είναι παρόμοιος με εκείνους όπως το `Literal::i8_unsuffixed` όπου η τιμή του πλωτήρα εκπέμπεται απευθείας στο token αλλά δεν χρησιμοποιείται επίθημα, επομένως μπορεί να συναχθεί ότι είναι `f64` αργότερα στον μεταγλωττιστή.
    ///
    /// Τα λογοτεχνικά γράμματα που δημιουργούνται από αρνητικούς αριθμούς ενδέχεται να μην μπορούν να επιβιώσουν στα rountrips μέσω `TokenStream` ή string και μπορεί να χωριστούν σε δύο tokens (`-` και θετικά κυριολεκτικά).
    ///
    /// # Panics
    ///
    /// Αυτή η συνάρτηση απαιτεί το καθορισμένο float να είναι πεπερασμένο, για παράδειγμα εάν είναι άπειρο ή NaN, αυτή η συνάρτηση θα panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Δημιουργεί ένα νέο κυριολεκτικό κυριολεκτικό σημείο.
    ///
    /// Αυτός ο κατασκευαστής θα δημιουργήσει ένα κυριολεκτικό όπως το `1.0f32` όπου η καθορισμένη τιμή είναι το προηγούμενο μέρος του token και το `f32` είναι το επίθημα του token.
    /// Αυτό το token θα θεωρείται πάντα ως `f32` στον μεταγλωττιστή.
    /// Τα λογοτεχνικά γράμματα που δημιουργούνται από αρνητικούς αριθμούς ενδέχεται να μην μπορούν να επιβιώσουν στα rountrips μέσω `TokenStream` ή string και μπορεί να χωριστούν σε δύο tokens (`-` και θετικά κυριολεκτικά).
    ///
    ///
    /// # Panics
    ///
    /// Αυτή η συνάρτηση απαιτεί το καθορισμένο float να είναι πεπερασμένο, για παράδειγμα εάν είναι άπειρο ή NaN, αυτή η συνάρτηση θα panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Δημιουργεί ένα νέο κυριολεκτικό κυμαινόμενο σημείο.
    ///
    /// Αυτός ο κατασκευαστής είναι παρόμοιος με εκείνους όπως το `Literal::i8_unsuffixed` όπου η τιμή του πλωτήρα εκπέμπεται απευθείας στο token αλλά δεν χρησιμοποιείται επίθημα, επομένως μπορεί να συναχθεί ότι είναι `f64` αργότερα στον μεταγλωττιστή.
    ///
    /// Τα λογοτεχνικά γράμματα που δημιουργούνται από αρνητικούς αριθμούς ενδέχεται να μην μπορούν να επιβιώσουν στα rountrips μέσω `TokenStream` ή string και μπορεί να χωριστούν σε δύο tokens (`-` και θετικά κυριολεκτικά).
    ///
    /// # Panics
    ///
    /// Αυτή η συνάρτηση απαιτεί το καθορισμένο float να είναι πεπερασμένο, για παράδειγμα εάν είναι άπειρο ή NaN, αυτή η συνάρτηση θα panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Δημιουργεί ένα νέο κυριολεκτικό κυριολεκτικό σημείο.
    ///
    /// Αυτός ο κατασκευαστής θα δημιουργήσει ένα κυριολεκτικό όπως το `1.0f64` όπου η καθορισμένη τιμή είναι το προηγούμενο μέρος του token και το `f64` είναι το επίθημα του token.
    /// Αυτό το token θα θεωρείται πάντα ως `f64` στον μεταγλωττιστή.
    /// Τα λογοτεχνικά γράμματα που δημιουργούνται από αρνητικούς αριθμούς ενδέχεται να μην μπορούν να επιβιώσουν στα rountrips μέσω `TokenStream` ή string και μπορεί να χωριστούν σε δύο tokens (`-` και θετικά κυριολεκτικά).
    ///
    ///
    /// # Panics
    ///
    /// Αυτή η συνάρτηση απαιτεί το καθορισμένο float να είναι πεπερασμένο, για παράδειγμα εάν είναι άπειρο ή NaN, αυτή η συνάρτηση θα panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Συμβολοσειρά κυριολεκτικά.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Κυριολεκτικός χαρακτήρας.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Γραμμή συμβολοσειράς byte.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Επιστρέφει το εύρος που περιλαμβάνει αυτήν την κυριολεκτική.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Διαμορφώνει το εύρος που σχετίζεται με αυτό το κυριολεκτικό.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Επιστρέφει ένα `Span` που είναι ένα υποσύνολο του `self.span()` που περιέχει μόνο τα bytes προέλευσης στην περιοχή `range`.
    /// Επιστρέφει το `None` εάν το επιθυμητό εύρος είναι εκτός των ορίων του `self`.
    ///
    // FIXME(SergioBenitez): ελέγξτε ότι το εύρος byte ξεκινά και τελειώνει σε ένα όριο UTF-8 της πηγής.
    // Διαφορετικά, είναι πιθανό ότι ένα panic θα εμφανιστεί αλλού κατά την εκτύπωση του κειμένου προέλευσης.
    // FIXME(SergioBenitez): Δεν υπάρχει τρόπος για τον χρήστη να γνωρίζει σε τι χαρτογραφεί πραγματικά το `self.span()`, επομένως αυτή η μέθοδος μπορεί να ονομάζεται μόνο τυφλά.
    // Για παράδειγμα, το `to_string()` για τον χαρακτήρα 'c' επιστρέφει "'\u{63}'".δεν υπάρχει τρόπος να γνωρίζει ο χρήστης εάν το κείμενο προέλευσης ήταν 'c' ή αν ήταν '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) κάτι παρόμοιο με το `Option::cloned`, αλλά για το `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// Σημείωση, η γέφυρα παρέχει μόνο `to_string`, υλοποιεί το `fmt::Display` με βάση αυτό (το αντίστροφο της συνηθισμένης σχέσης μεταξύ των δύο).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Εκτυπώνει το κυριολεκτικό ως συμβολοσειρά που θα πρέπει να μετατρέπεται χωρίς απώλειες στην ίδια κυριολεκτική (εκτός από την πιθανή στρογγυλοποίηση για κυριολεκτικά κυμαινόμενα σημεία).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Παρακολούθηση πρόσβασης σε μεταβλητές περιβάλλοντος.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Ανακτήστε μια μεταβλητή περιβάλλοντος και προσθέστε την για να δημιουργήσετε πληροφορίες εξάρτησης.
    /// Το σύστημα build που εκτελεί τον μεταγλωττιστή θα γνωρίζει ότι η μεταβλητή είχε πρόσβαση κατά τη διάρκεια της μεταγλώττισης και θα είναι σε θέση να εκτελέσει ξανά το build όταν αλλάζει η τιμή αυτής της μεταβλητής.
    ///
    /// Εκτός από την παρακολούθηση εξάρτησης, αυτή η συνάρτηση πρέπει να είναι ισοδύναμη με το `env::var` από την τυπική βιβλιοθήκη, εκτός από το ότι το όρισμα πρέπει να είναι UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}