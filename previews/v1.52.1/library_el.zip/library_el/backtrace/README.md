# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Μια βιβλιοθήκη για την απόκτηση backtraces στο χρόνο εκτέλεσης για το Rust.
Αυτή η βιβλιοθήκη στοχεύει να ενισχύσει την υποστήριξη της τυπικής βιβλιοθήκης παρέχοντας μια διασύνδεση μέσω προγραμματισμού για εργασία, αλλά υποστηρίζει επίσης εύκολα την εκτύπωση της τρέχουσας οπίσθιας ανόδου όπως το panics του libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Για να καταγράψετε απλά ένα backtrace και να αναβάλλετε την αντιμετώπιση μέχρι αργότερα, μπορείτε να χρησιμοποιήσετε τον τύπο `Backtrace` ανώτατου επιπέδου.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Εάν, ωστόσο, θέλετε περισσότερη ακατέργαστη πρόσβαση στην πραγματική λειτουργικότητα ανίχνευσης, μπορείτε να χρησιμοποιήσετε τις συναρτήσεις `trace` και `resolve` απευθείας.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Επιλύστε αυτόν τον δείκτη εντολών σε ένα όνομα συμβόλου
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // συνεχίστε στο επόμενο καρέ
    });
}
```

# License

Αυτό το έργο έχει άδεια χρήσης με οποιοδήποτε από τα δύο

 * Apache Άδεια, Έκδοση 2.0, ([LICENSE-APACHE](LICENSE-APACHE) ή http://www.apache.org/licenses/LICENSE-2.0)
 * Άδεια MIT ([LICENSE-MIT](LICENSE-MIT) ή http://opensource.org/licenses/MIT)

στην επιλογή σας.

### Contribution

Εκτός εάν δηλώνετε ρητά κάτι διαφορετικό, οποιαδήποτε συνεισφορά που υποβάλλεται σκόπιμα για συμπερίληψη σε backtrace-rs από εσάς, όπως ορίζεται στην άδεια Apache-2.0, θα έχει διπλή άδεια όπως παραπάνω, χωρίς πρόσθετους όρους ή προϋποθέσεις.







