use backtrace::Backtrace;

// Αυτή η δοκιμή λειτουργεί μόνο σε πλατφόρμες με λειτουργική λειτουργία `symbol_address` για πλαίσια που αναφέρουν την αρχική διεύθυνση ενός συμβόλου.
// Ως αποτέλεσμα, ενεργοποιείται μόνο σε λίγες πλατφόρμες.
//
const ENABLED: bool = cfg!(all(
    // Windows δεν έχει δοκιμαστεί πραγματικά και το OSX δεν υποστηρίζει την εύρεση ενός πλαισίου που περικλείει, απενεργοποιήστε το
    //
    target_os = "linux",
    // Στο ARM η εύρεση της λειτουργίας κλεισίματος επιστρέφει απλώς το ίδιο το ip.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}