//! Τύποι που εξαρτώνται από την πλατφόρμα.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// Μια πλατφόρμα ανεξάρτητη αναπαράσταση μιας συμβολοσειράς.
/// Όταν εργάζεστε με ενεργοποιημένο το `std`, συνιστάται στις μεθόδους ευκολίας για την παροχή μετατροπών σε τύπους `std`.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// Ένα κομμάτι, που συνήθως παρέχεται σε πλατφόρμες Unix.
    Bytes(&'a [u8]),
    /// Ευρείες χορδές συνήθως από Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Το Lossy μετατρέπεται σε `Cow<str>`, θα εκχωρήσει εάν το `Bytes` δεν είναι έγκυρο UTF-8 ή εάν το `BytesOrWideString` είναι `Wide`.
    ///
    /// # Απαιτούμενα χαρακτηριστικά
    ///
    /// Αυτή η λειτουργία απαιτεί την ενεργοποίηση της δυνατότητας `std` του `backtrace` crate και η δυνατότητα `std` είναι ενεργοποιημένη από προεπιλογή.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// Παρέχει μια αναπαράσταση `Path` του `BytesOrWideString`.
    ///
    /// # Απαιτούμενα χαρακτηριστικά
    ///
    /// Αυτή η λειτουργία απαιτεί την ενεργοποίηση της δυνατότητας `std` του `backtrace` crate και η δυνατότητα `std` είναι ενεργοποιημένη από προεπιλογή.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}