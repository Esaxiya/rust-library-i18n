//! Μια ενότητα που βοηθά στη διαχείριση συνδέσεων dbghelp στο Windows
//!
//! Τα Backtraces στο Windows (τουλάχιστον για MSVC) τροφοδοτούνται σε μεγάλο βαθμό μέσω του `dbghelp.dll` και των διαφόρων λειτουργιών που περιέχει.
//! Αυτές οι λειτουργίες φορτώνονται *δυναμικά* αντί να συνδέονται στατικά με το `dbghelp.dll`.
//! Αυτό γίνεται επί του παρόντος από την τυπική βιβλιοθήκη (και απαιτείται θεωρητικά εκεί), αλλά είναι μια προσπάθεια για τη μείωση των στατικών εξαρτήσεων dll μιας βιβλιοθήκης, δεδομένου ότι τα backtraces είναι συνήθως αρκετά προαιρετικά.
//!
//! Τούτου λεχθέντος, το `dbghelp.dll` φορτώνει σχεδόν πάντα με επιτυχία το Windows.
//!
//! Λάβετε υπόψη ότι, δεδομένου ότι φορτώνουμε όλη αυτή την υποστήριξη δυναμικά, δεν μπορούμε πραγματικά να χρησιμοποιήσουμε τους ακατέργαστους ορισμούς στο `winapi`, αλλά μάλλον πρέπει να ορίσουμε τους τύπους του δείκτη λειτουργίας και να το χρησιμοποιήσουμε.
//! Δεν θέλουμε πραγματικά να ασχοληθούμε με την αναπαραγωγή του winapi, επομένως έχουμε μια δυνατότητα Cargo `verify-winapi` που ισχυρίζεται ότι όλες οι συνδέσεις ταιριάζουν με αυτές του winapi και αυτή η δυνατότητα είναι ενεργοποιημένη στο CI.
//!
//! Τέλος, θα σημειώσετε εδώ ότι το dll για `dbghelp.dll` δεν εκφορτώνεται ποτέ και αυτό είναι επί του παρόντος σκόπιμο.
//! Η σκέψη είναι ότι μπορούμε να το αποθηκεύσουμε σε παγκόσμιο επίπεδο και να το χρησιμοποιήσουμε μεταξύ των κλήσεων στο API, αποφεύγοντας το ακριβό loads/unloads.
//! Εάν αυτό είναι πρόβλημα για ανιχνευτές διαρροών ή κάτι τέτοιο, μπορούμε να περάσουμε τη γέφυρα όταν φτάνουμε εκεί.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Εργαστείτε γύρω από τα `SymGetOptions` και `SymSetOptions` που δεν είναι παρόντα στο ίδιο το winapi.
// Διαφορετικά, αυτό χρησιμοποιείται μόνο όταν κάνουμε διπλό έλεγχο τύπων έναντι του winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Δεν έχει οριστεί ακόμη στο winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Αυτό ορίζεται στο winapi, αλλά είναι λανθασμένο (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Δεν έχει οριστεί ακόμη στο winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Αυτή η μακροεντολή χρησιμοποιείται για τον καθορισμό μιας δομής `Dbghelp` που περιέχει εσωτερικά όλους τους δείκτες λειτουργίας που ενδέχεται να φορτώσουμε.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Το φορτωμένο DLL για `dbghelp.dll`
            dll: HMODULE,

            // Κάθε δείκτης συνάρτησης για κάθε συνάρτηση που ενδέχεται να χρησιμοποιήσουμε
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Αρχικά δεν έχουμε φορτώσει το DLL
            dll: 0 as *mut _,
            // Αρχικά όλες οι συναρτήσεις ρυθμίζονται στο μηδέν για να πούμε ότι πρέπει να φορτωθούν δυναμικά.
            //
            $($name: 0,)*
        };

        // Ευκολία typedef για κάθε τύπο λειτουργίας.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Προσπάθειες για άνοιγμα `dbghelp.dll`.
            /// Επιστρέφει την επιτυχία εάν λειτουργεί ή σφάλμα εάν αποτύχει το `LoadLibraryW`.
            ///
            /// Panics εάν η βιβλιοθήκη έχει ήδη φορτωθεί.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Λειτουργία για κάθε μέθοδο που θα θέλαμε να χρησιμοποιήσουμε.
            // Όταν καλείται, είτε θα διαβάσει τον προσωρινά αποθηκευμένο δείκτη συνάρτησης είτε θα τον φορτώσει και θα επιστρέψει την φορτωμένη τιμή.
            // Τα φορτία ισχυρίζονται ότι επιτυγχάνουν.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Εξυπηρέτηση διακομιστή μεσολάβησης για χρήση των κλειδαριών καθαρισμού για αναφορά των λειτουργιών dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Αρχικοποιήστε όλη την απαραίτητη υποστήριξη για πρόσβαση σε λειτουργίες `dbghelp` API από αυτό το crate.
///
///
/// Σημειώστε ότι αυτή η λειτουργία είναι **ασφαλής**, εσωτερικά έχει τον δικό της συγχρονισμό.
/// Σημειώστε επίσης ότι είναι ασφαλές να καλέσετε αυτήν τη λειτουργία πολλές φορές αναδρομικά.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Το πρώτο πράγμα που πρέπει να κάνουμε είναι να συγχρονίσουμε αυτήν τη λειτουργία.Αυτό μπορεί να κληθεί ταυτόχρονα από άλλα νήματα ή αναδρομικά μέσα σε ένα νήμα.
        // Λάβετε υπόψη ότι είναι πιο δύσκολο από αυτό, διότι αυτό που χρησιμοποιούμε εδώ, το `dbghelp`,*επίσης* πρέπει να συγχρονιστεί με όλους τους άλλους καλούντες στο `dbghelp` σε αυτήν τη διαδικασία.
        //
        // Συνήθως δεν υπάρχουν πολλές κλήσεις προς το `dbghelp` στην ίδια διαδικασία και πιθανότατα μπορούμε να υποθέσουμε με ασφάλεια ότι είμαστε οι μόνοι που έχουμε πρόσβαση σε αυτό.
        // Υπάρχει, ωστόσο, ένας κύριος άλλος χρήστης που πρέπει να ανησυχούμε για τον οποίο ειρωνικά είμαστε εμείς, αλλά στην τυπική βιβλιοθήκη.
        // Η τυπική βιβλιοθήκη Rust εξαρτάται από αυτό το crate για υποστήριξη backtrace και αυτό το crate υπάρχει επίσης στο crates.io.
        // Αυτό σημαίνει ότι εάν η τυπική βιβλιοθήκη εκτυπώνει ένα panic backtrace μπορεί να τρέξει με αυτό το crate που προέρχεται από το crates.io, προκαλώντας segfaults.
        //
        // Για να βοηθήσουμε στην επίλυση αυτού του προβλήματος συγχρονισμού χρησιμοποιούμε ένα τέχνασμα για τα Windows εδώ (είναι, τελικά, ένας περιορισμός για τα Windows σχετικά με το συγχρονισμό).
        // Δημιουργούμε ένα *session-local* με το όνομα mutex για την προστασία αυτής της κλήσης.
        // Η πρόθεση εδώ είναι ότι η τυπική βιβλιοθήκη και αυτό το crate δεν χρειάζεται να μοιραστούν API επιπέδου Rust για συγχρονισμό εδώ, αλλά μπορούν αντ 'αυτού να λειτουργήσουν πίσω από τα παρασκήνια για να βεβαιωθείτε ότι συγχρονίζονται μεταξύ τους.
        //
        // Με αυτόν τον τρόπο, όταν αυτή η λειτουργία καλείται μέσω της τυπικής βιβλιοθήκης ή μέσω του crates.io, μπορούμε να είμαστε σίγουροι ότι αποκτάται το ίδιο mutex.
        //
        // Όλα αυτά λοιπόν είναι να πούμε ότι το πρώτο πράγμα που κάνουμε εδώ είναι να δημιουργήσουμε ατομικά ένα `HANDLE` που ονομάζεται mutex στο Windows.
        // Συγχρονίζουμε λίγο με άλλα νήματα που μοιράζονται αυτήν τη λειτουργία ειδικά και διασφαλίζουμε ότι δημιουργείται μόνο μία λαβή ανά παρουσία αυτής της λειτουργίας.
        // Σημειώστε ότι η λαβή δεν είναι ποτέ κλειστή μόλις αποθηκευτεί στο παγκόσμιο.
        //
        // Αφού πάμε στην κλειδαριά απλώς το αποκτάμε και η λαβή `Init` που μοιράζουμε θα είναι υπεύθυνη για την απόρριψή της τελικά.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Εντάξει, phew!Τώρα που είμαστε όλοι συγχρονισμένοι με ασφάλεια, ας ξεκινήσουμε να επεξεργαζόμαστε τα πάντα.
        // Πρώτον, πρέπει να διασφαλίσουμε ότι το `dbghelp.dll` είναι πραγματικά φορτωμένο σε αυτήν τη διαδικασία.
        // Αυτό το κάνουμε δυναμικά για να αποφύγουμε μια στατική εξάρτηση.
        // Αυτό έχει γίνει ιστορικά για την επίλυση παράξενων ζητημάτων σύνδεσης και αποσκοπεί στο να κάνει τα δυαδικά αρχεία λίγο πιο φορητά, καθώς αυτό είναι σε μεγάλο βαθμό απλώς ένα βοηθητικό πρόγραμμα εντοπισμού σφαλμάτων.
        //
        //
        // Μόλις ανοίξουμε το `dbghelp.dll`, πρέπει να καλέσουμε κάποιες λειτουργίες αρχικοποίησης σε αυτό και αυτό αναλύεται πιο κάτω.
        // Αυτό το κάνουμε μόνο μία φορά, οπότε έχουμε ένα παγκόσμιο boolean που δείχνει εάν έχουμε τελειώσει ακόμα ή όχι.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Βεβαιωθείτε ότι η σημαία `SYMOPT_DEFERRED_LOADS` έχει ρυθμιστεί, επειδή σύμφωνα με τα έγγραφα του MSVC σχετικά με αυτό: "This is the fastest, most efficient way to use the symbol handler.", οπότε ας το κάνουμε αυτό!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Πραγματικά αρχικοποίηση συμβόλων με MSVC.Σημειώστε ότι αυτό μπορεί να αποτύχει, αλλά το αγνοούμε.
        // Δεν υπάρχει τόνος προηγούμενης τέχνης για αυτό καθαυτό, αλλά το LLVM εσωτερικά φαίνεται να αγνοεί την τιμή επιστροφής εδώ και μία από τις βιβλιοθήκες απολυμαντικών στο LLVM εκτυπώνει μια τρομακτική προειδοποίηση εάν αυτό αποτύχει, αλλά ουσιαστικά την αγνοεί μακροπρόθεσμα.
        //
        //
        // Μια περίπτωση που εμφανίζεται πολύ για το Rust είναι ότι η τυπική βιβλιοθήκη και αυτό το crate στο crates.io θέλουν και οι δύο να ανταγωνιστούν για το `SymInitializeW`.
        // Η τυπική βιβλιοθήκη ιστορικά ήθελε να αρχικοποιήσει έπειτα τον καθαρισμό τις περισσότερες φορές, αλλά τώρα που χρησιμοποιεί αυτό το crate σημαίνει ότι κάποιος θα φτάσει στην αρχικοποίηση και ο άλλος θα πάρει αυτήν την αρχικοποίηση.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}