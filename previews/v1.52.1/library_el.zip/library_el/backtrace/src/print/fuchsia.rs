use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // Το dl_iterate_phdr λαμβάνει μια επιστροφή κλήσης που θα λαμβάνει ένα δείκτη dl_phdr_info για κάθε DSO που έχει συνδεθεί στη διαδικασία.
    // Το dl_iterate_phdr διασφαλίζει επίσης ότι ο δυναμικός σύνδεσμος είναι κλειδωμένος από την αρχή έως το τέλος της επανάληψης.
    // Εάν η επιστροφή κλήσης επιστρέψει μη μηδενική τιμή, η επανάληψη τερματίζεται νωρίς.
    // 'data' θα μεταφερθεί ως το τρίτο όρισμα στην επιστροφή κλήσης σε κάθε κλήση.
    // 'size' δίνει το μέγεθος του dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Πρέπει να αναλύσουμε το αναγνωριστικό build και ορισμένα βασικά δεδομένα κεφαλίδας προγράμματος, πράγμα που σημαίνει ότι χρειαζόμαστε και λίγο υλικό από τις προδιαγραφές ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Τώρα πρέπει να αντιγράψουμε, bit for bit, τη δομή του τύπου dl_phdr_info που χρησιμοποιείται από τον τρέχοντα δυναμικό σύνδεσμο της fuchsia.
// Το Chromium έχει επίσης αυτό το όριο ABI καθώς και το crashpad.
// Τελικά θα θέλαμε να μετακινήσουμε αυτές τις περιπτώσεις για να χρησιμοποιήσουμε το elf-search, αλλά θα πρέπει να το παρέχουμε στο SDK και αυτό δεν έχει γίνει ακόμη.
//
// Έτσι, εμείς (και αυτοί) έχουν κολλήσει να χρησιμοποιήσουμε αυτήν τη μέθοδο που δημιουργεί μια στενή σύζευξη με το φούξια libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Δεν έχουμε κανέναν τρόπο να γνωρίζουμε εάν τα e_phoff και e_phnum είναι έγκυρα.
    // Το libc πρέπει να το διασφαλίσει για εμάς, οπότε είναι ασφαλές να σχηματίσετε ένα κομμάτι εδώ.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Το Elf_Phdr αντιπροσωπεύει μια κεφαλίδα προγράμματος ELF 64-bit στην τελικότητα της αρχιτεκτονικής προορισμού.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Το Phdr αντιπροσωπεύει μια έγκυρη κεφαλίδα προγράμματος ELF και τα περιεχόμενά της.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Δεν έχουμε κανέναν τρόπο να ελέγξουμε εάν τα p_addr ή p_memsz είναι έγκυρα.
    // Η βιβλιοθήκη του Φούξια αναλύει πρώτα τις σημειώσεις, οπότε λόγω του ότι είναι εδώ, αυτές οι κεφαλίδες πρέπει να είναι έγκυρες.
    //
    // NoteIter δεν απαιτεί τα υποκείμενα δεδομένα να είναι έγκυρα, αλλά απαιτεί τα όρια να είναι έγκυρα.
    // Ελπίζουμε ότι το libc έχει διασφαλίσει ότι αυτό ισχύει για εμάς εδώ.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Ο τύπος σημείωσης για αναγνωριστικά build.
const NT_GNU_BUILD_ID: u32 = 3;

// Το Elf_Nhdr αντιπροσωπεύει μια κεφαλίδα σημείωσης ELF στο endianness του στόχου.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Η σημείωση αντιπροσωπεύει μια νότα ELF (κεφαλίδα + περιεχόμενα).
// Το όνομα παραμένει ως φέτα u8 επειδή δεν τερματίζεται πάντα null και το rust καθιστά αρκετά εύκολο να ελέγξετε ότι τα bytes ταιριάζουν ούτως ή άλλως.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// Το NoteIter σάς επιτρέπει να επαναλαμβάνετε με ασφάλεια ένα τμήμα σημειώσεων.
// Τερματίζει μόλις παρουσιαστεί σφάλμα ή δεν υπάρχουν άλλες σημειώσεις.
// Εάν κάνετε επανάληψη για μη έγκυρα δεδομένα, θα λειτουργήσει σαν να μην βρέθηκαν σημειώσεις.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Είναι μια αναλλοίωτη συνάρτηση ότι ο δείκτης και το μέγεθος που δίνεται υποδηλώνουν μια έγκυρη σειρά byte που μπορούν να διαβαστούν.
    // Το περιεχόμενο αυτών των byte μπορεί να είναι οτιδήποτε, αλλά το εύρος πρέπει να είναι έγκυρο για να είναι ασφαλές.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to ευθυγραμμίζει το 'x' με την ευθυγράμμιση "by-byte με την προϋπόθεση ότι το 'to' είναι ισχύς 2.
// Αυτό ακολουθεί ένα τυπικό μοτίβο σε C/C ++ ELF κώδικα ανάλυσης όπου (x + έως, 1)&-to χρησιμοποιείται.
// Το Rust δεν σας αφήνει να αναιρέσετε τη χρήση, έτσι χρησιμοποιώ
// 2-συμπληρωματική μετατροπή για να το αναδημιουργήσει.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// Το take_bytes_align4 καταναλώνει num bytes από τη φέτα (εάν υπάρχει) και επιπλέον διασφαλίζει ότι η τελική φέτα είναι σωστά ευθυγραμμισμένη.
// Εάν είτε ο αριθμός των byte που ζητήσατε είναι πολύ μεγάλος είτε το slice δεν μπορεί να ευθυγραμμιστεί εκ νέου λόγω του ότι δεν υπάρχει αρκετό byte που υπάρχει, δεν επιστρέφεται κανένα και το slice δεν τροποποιείται.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Αυτή η συνάρτηση δεν έχει πραγματικές αναλλοίωτες που πρέπει να υποστηρίζει ο καλών εκτός από το ότι το 'bytes' πρέπει να είναι ευθυγραμμισμένο για απόδοση (και σε ορισμένες ορθότητες αρχιτεκτονικών).
// Οι τιμές στα πεδία Elf_Nhdr μπορεί να είναι ανοησίες, αλλά αυτή η συνάρτηση δεν διασφαλίζει κάτι τέτοιο.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Αυτό είναι ασφαλές αρκεί να υπάρχει αρκετός χώρος και μόλις επιβεβαιώσαμε ότι στην παραπάνω δήλωση if έτσι δεν θα πρέπει να είναι ασφαλές.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Σημειώστε ότι sice_of: :<Elf_Nhdr>() είναι πάντα ευθυγραμμισμένο 4 byte.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Ελέγξτε αν φτάσαμε στο τέλος.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Μεταδίδουμε ένα nhdr αλλά εξετάζουμε προσεκτικά την προκύπτουσα δομή.
        // Δεν εμπιστευόμαστε το namesz ή το descsz και δεν λαμβάνουμε ανασφαλείς αποφάσεις με βάση τον τύπο.
        //
        // Έτσι, ακόμη και αν βγούμε πλήρη σκουπίδια θα πρέπει να είμαστε ασφαλείς.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Υποδεικνύει ότι ένα τμήμα είναι εκτελέσιμο.
const PERM_X: u32 = 0b00000001;
/// Υποδεικνύει ότι ένα τμήμα είναι εγγράψιμο.
const PERM_W: u32 = 0b00000010;
/// Υποδεικνύει ότι ένα τμήμα είναι αναγνώσιμο.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Αντιπροσωπεύει ένα τμήμα ELF στο χρόνο εκτέλεσης.
struct Segment {
    /// Δίνει την εικονική διεύθυνση χρόνου εκτέλεσης των περιεχομένων αυτού του τμήματος.
    addr: usize,
    /// Δίνει το μέγεθος μνήμης των περιεχομένων αυτού του τμήματος.
    size: usize,
    /// Δίνει την ενότητα εικονική διεύθυνση αυτού του τμήματος με το αρχείο ELF.
    mod_rel_addr: usize,
    /// Δίνει τα δικαιώματα που βρίσκονται στο αρχείο ELF.
    /// Ωστόσο, αυτά τα δικαιώματα δεν είναι απαραίτητα τα δικαιώματα που υπάρχουν στο χρόνο εκτέλεσης.
    flags: Perm,
}

/// Σας επιτρέπει να επαναλάβετε τα τμήματα από ένα DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Αντιπροσωπεύει ένα ELF DSO (Dynamic Shared Object).
/// Αυτός ο τύπος αναφέρεται στα δεδομένα που είναι αποθηκευμένα στο πραγματικό DSO αντί να δημιουργεί το δικό του αντίγραφο.
struct Dso<'a> {
    /// Ο δυναμικός σύνδεσμος μας δίνει πάντα ένα όνομα, ακόμα κι αν το όνομα είναι κενό.
    /// Στην περίπτωση του κύριου εκτελέσιμου, αυτό το όνομα θα είναι κενό.
    /// Στην περίπτωση ενός κοινόχρηστου αντικειμένου θα είναι το όνομα (βλ. DT_SONAME).
    name: &'a str,
    /// Στο Fuchsia σχεδόν όλα τα δυαδικά αρχεία έχουν αναγνωριστικά build, αλλά αυτό δεν αποτελεί αυστηρή απαίτηση.
    /// Δεν υπάρχει τρόπος να ταιριάξετε τις πληροφορίες DSO με ένα πραγματικό αρχείο ELF στη συνέχεια, εάν δεν υπάρχει build_id, οπότε απαιτούμε κάθε DSO να έχει εδώ.
    ///
    /// Τα DSO χωρίς build_id αγνοούνται.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Επιστρέφει έναν επαναληπτικό σε τμήματα σε αυτό το DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Αυτά τα σφάλματα κωδικοποιούν ζητήματα που προκύπτουν κατά την ανάλυση πληροφοριών για κάθε DSO.
///
enum Error {
    /// NameError σημαίνει ότι προέκυψε σφάλμα κατά τη μετατροπή μιας συμβολοσειράς στυλ C σε μια συμβολοσειρά rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError σημαίνει ότι δεν βρήκαμε αναγνωριστικό build.
    /// Αυτό μπορεί να συμβαίνει είτε επειδή το DSO δεν είχε αναγνωριστικό έκδοσης είτε επειδή το τμήμα που περιείχε το αναγνωριστικό έκδοσης είχε λανθασμένη μορφή.
    ///
    BuildIDError,
}

/// Κλήσεις είτε 'dso' είτε 'error' για κάθε DSO που συνδέεται στη διαδικασία από τον δυναμικό σύνδεσμο.
///
///
/// # Arguments
///
/// * `visitor` - Ένα DsoPrinter που θα έχει μία από τις μεθόδους κατανάλωσης που ονομάζεται foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // Το dl_iterate_phdr διασφαλίζει ότι το info.name θα οδηγεί σε μια έγκυρη τοποθεσία.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Αυτή η λειτουργία εκτυπώνει τη σήμανση Fuchsia συμβολιστή για όλες τις πληροφορίες που περιέχονται σε ένα DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}