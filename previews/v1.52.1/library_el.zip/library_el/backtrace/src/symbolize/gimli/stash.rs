// χρησιμοποιείται μόνο στο Linux αυτήν τη στιγμή, οπότε επιτρέψτε τον νεκρό κώδικα αλλού
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Ένας απλός κατανεμητής αρένα για buffer byte.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Εκχωρεί ένα buffer του καθορισμένου μεγέθους και επιστρέφει μια μεταβλητή αναφορά σε αυτό.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // ΑΣΦΑΛΕΙΑ: αυτή είναι η μόνη λειτουργία που κατασκευάζει ποτέ μια μεταβλητή
        // αναφορά στο `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // ΑΣΦΑΛΕΙΑ: δεν αφαιρούμε ποτέ στοιχεία από το `self.buffers`, άρα μια αναφορά
        // στα δεδομένα μέσα σε οποιοδήποτε buffer θα διαρκέσει όσο το `self`.
        &mut buffers[i]
    }
}