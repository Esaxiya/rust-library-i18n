//! Υποστήριξη για συμβολισμό χρησιμοποιώντας το `gimli` crate στο crates.io
//!
//! Αυτή είναι η προεπιλεγμένη εφαρμογή συμβολισμού για το Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // «Η στατική διάρκεια ζωής είναι ένα ψέμα για την αντιμετώπιση της έλλειψης υποστήριξης για δομές αυτοαναφοράς.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Μετατροπή σε «στατική διάρκεια ζωής, καθώς τα σύμβολα πρέπει να δανείζονται μόνο `map` και `stash` και τα διατηρούμε παρακάτω.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Για φόρτωση εγγενών βιβλιοθηκών στο Windows, δείτε κάποια συζήτηση για το rust-lang/rust#71060 για τις διάφορες στρατηγικές εδώ.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Οι βιβλιοθήκες MinGW προς το παρόν δεν υποστηρίζουν ASLR (rust-lang/rust#16514), αλλά τα DLL μπορούν να μεταφερθούν στον χώρο διευθύνσεων.
            // Φαίνεται ότι οι διευθύνσεις στις πληροφορίες εντοπισμού σφαλμάτων είναι όλες σαν να φορτώθηκε αυτή η βιβλιοθήκη στο "image base", το οποίο είναι ένα πεδίο στις κεφαλίδες αρχείων COFF.
            // Δεδομένου ότι αυτό φαίνεται στην λίστα debuginfo, αναλύουμε τον πίνακα συμβόλων και αποθηκεύουμε τις διευθύνσεις σαν να έχει φορτωθεί και η βιβλιοθήκη στο "image base".
            //
            // Ωστόσο, η βιβλιοθήκη ενδέχεται να μην φορτωθεί στο "image base".
            // (πιθανώς κάτι άλλο μπορεί να φορτωθεί εκεί;) Εδώ μπαίνει το πεδίο `bias` και πρέπει να υπολογίσουμε την αξία του `bias` εδώ.Δυστυχώς, αν και δεν είναι σαφές πώς να το αποκτήσετε από μια φορτωμένη λειτουργική μονάδα.
            // Αυτό που έχουμε, ωστόσο, είναι η πραγματική διεύθυνση φόρτωσης (`modBaseAddr`).
            //
            // Σαν κομμάτι του cop-out για τώρα χαρτογραφούμε το αρχείο, διαβάστε τις πληροφορίες κεφαλίδας αρχείου και, στη συνέχεια, ρίξτε το mmap.Αυτό είναι σπατάλη γιατί πιθανότατα θα ξανανοίξουμε το mmap αργότερα, αλλά αυτό θα λειτουργήσει αρκετά καλά για τώρα.
            //
            // Μόλις έχουμε το `image_base` (επιθυμητή θέση φόρτωσης) και το `base_addr` (πραγματική θέση φόρτωσης) μπορούμε να συμπληρώσουμε το `bias` (διαφορά μεταξύ του πραγματικού και του επιθυμητού) και στη συνέχεια η δηλωμένη διεύθυνση κάθε τμήματος είναι το `image_base`, καθώς αυτό λέει το αρχείο.
            //
            //
            // Προς το παρόν φαίνεται ότι σε αντίθεση με το ELF/MachO μπορούμε να κάνουμε ένα τμήμα ανά βιβλιοθήκη, χρησιμοποιώντας το `modBaseSize` ως ολόκληρο το μέγεθος.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS χρησιμοποιεί τη μορφή αρχείου Mach-O και χρησιμοποιεί ειδικά DYLD API για τη φόρτωση μιας λίστας εγγενών βιβλιοθηκών που αποτελούν μέρος της εφαρμογής.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Λήψη του ονόματος αυτής της βιβλιοθήκης που αντιστοιχεί στη διαδρομή του τόπου φόρτωσής της.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Φορτώστε την κεφαλίδα της εικόνας αυτής της βιβλιοθήκης και μεταβείτε στο `object` για να αναλύσετε όλες τις εντολές φόρτωσης, ώστε να μπορούμε να καταλάβουμε όλα τα τμήματα που εμπλέκονται εδώ.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Επαναλάβετε τα τμήματα και καταχωρίστε γνωστές περιοχές για τμήματα που βρίσκουμε.
            // Επιπλέον, καταγράψτε πληροφορίες για τμήματα κειμένου για επεξεργασία αργότερα, δείτε τα παρακάτω σχόλια.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Προσδιορίστε το "slide" για αυτήν τη βιβλιοθήκη που καταλήγει να είναι η προκατάληψη που χρησιμοποιούμε για να καταλάβουμε πού φορτώνονται αντικείμενα στη μνήμη.
            // Αυτό είναι λίγο περίεργο υπολογισμό και είναι το αποτέλεσμα του να δοκιμάσετε μερικά πράγματα στη φύση και να δείτε τι κολλάει.
            //
            // Η γενική ιδέα είναι ότι το `bias` plus ένα τμήμα `stated_virtual_memory_address` πρόκειται να είναι εκεί που βρίσκεται στον πραγματικό χώρο διευθύνσεων όπου βρίσκεται το τμήμα.
            // Το άλλο πράγμα στο οποίο βασίζουμε είναι ότι μια πραγματική διεύθυνση μείον το `bias` είναι το ευρετήριο για αναζήτηση στον πίνακα συμβόλων και το debuginfo.
            //
            // Αποδεικνύεται, ωστόσο, ότι για βιβλιοθήκες φορτωμένες από το σύστημα αυτοί οι υπολογισμοί είναι λανθασμένοι.Ωστόσο, για τα εγγενή εκτελέσιμα, φαίνεται σωστό.
            // Ανυψώνοντας κάποια λογική από την πηγή του LLDB, έχει κάποια ειδική θήκη για την πρώτη ενότητα `__TEXT` που φορτώθηκε από την μετατόπιση αρχείου 0 με μη μηδενικό μέγεθος.
            // Για οποιονδήποτε λόγο, όταν υπάρχει, φαίνεται ότι ο πίνακας συμβόλων σχετίζεται μόνο με τη διαφάνεια vmaddr για τη βιβλιοθήκη.
            // Εάν δεν είναι *παρόν*, τότε ο πίνακας συμβόλων είναι σχετικός με τη διαφάνεια vmaddr συν τη δηλωμένη διεύθυνση του τμήματος.
            //
            // Για να χειριστούμε αυτήν την κατάσταση εάν *δεν* βρούμε μια ενότητα κειμένου στο αρχείο μετατόπιση μηδέν, τότε αυξάνουμε την προκατάληψη από τη δηλωμένη διεύθυνση των πρώτων ενοτήτων κειμένου και μειώνουμε επίσης όλες τις δηλωμένες διευθύνσεις με αυτό το ποσό.
            //
            // Με αυτόν τον τρόπο ο πίνακας συμβόλων εμφανίζεται πάντα σε σχέση με το ποσό πόλωσης της βιβλιοθήκης.
            // Αυτό φαίνεται να έχει τα σωστά αποτελέσματα για συμβολισμό μέσω του πίνακα συμβόλων.
            //
            // Ειλικρινά, δεν είμαι απολύτως σίγουρος αν αυτό είναι σωστό ή αν υπάρχει κάτι άλλο που πρέπει να υποδεικνύει πώς να το κάνουμε αυτό.
            // Προς το παρόν αν και αυτό φαίνεται να λειτουργεί αρκετά καλά (?) και θα πρέπει πάντα να είμαστε σε θέση να το τροποποιήσουμε με την πάροδο του χρόνου, αν είναι απαραίτητο.
            //
            // Για περισσότερες πληροφορίες, ανατρέξτε στο #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Άλλο Unix (π.χ.
        // Linux) οι πλατφόρμες χρησιμοποιούν το ELF ως μορφή αρχείου αντικειμένου και συνήθως εφαρμόζουν ένα API που ονομάζεται `dl_iterate_phdr` για τη φόρτωση εγγενών βιβλιοθηκών.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` πρέπει να είναι έγκυροι δείκτες.
        // `vec` θα πρέπει να είναι έγκυρος δείκτης για `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 δεν υποστηρίζει εγγενώς πληροφορίες εντοπισμού σφαλμάτων, αλλά το σύστημα build θα τοποθετήσει πληροφορίες εντοπισμού σφαλμάτων στη διαδρομή `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Όλα τα άλλα πρέπει να χρησιμοποιούν ELF, αλλά δεν ξέρουν πώς να φορτώνουν εγγενείς βιβλιοθήκες.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Όλες οι γνωστές κοινόχρηστες βιβλιοθήκες που έχουν φορτωθεί.
    libraries: Vec<Library>,

    /// Αντιστοιχίζει την προσωρινή μνήμη όπου διατηρούμε αναλυμένες πληροφορίες νάνων.
    ///
    /// Αυτή η λίστα έχει σταθερή χωρητικότητα για ολόκληρο το χρόνο ανύψωσης που δεν αυξάνεται ποτέ.
    /// Το στοιχείο `usize` κάθε ζεύγους είναι ένας δείκτης σε `libraries` πάνω από όπου το `usize::max_value()` αντιπροσωπεύει το τρέχον εκτελέσιμο.
    ///
    /// Το `Mapping` είναι αντίστοιχες αναλυμένες πληροφορίες νάνου.
    ///
    /// Σημειώστε ότι αυτό είναι βασικά μια προσωρινή μνήμη LRU και θα αλλάζουμε τα πράγματα εδώ καθώς συμβολίζουμε διευθύνσεις.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Τμήματα αυτής της βιβλιοθήκης φορτώθηκαν στη μνήμη και όπου φορτώθηκαν.
    segments: Vec<LibrarySegment>,
    /// Το "bias" αυτής της βιβλιοθήκης, συνήθως όπου φορτώνεται στη μνήμη.
    /// Αυτή η τιμή προστίθεται στη δηλωμένη διεύθυνση κάθε τμήματος για να λάβει την πραγματική διεύθυνση εικονικής μνήμης στην οποία φορτώνεται το τμήμα.
    /// Επιπλέον, αυτή η προκατάληψη αφαιρείται από πραγματικές διευθύνσεις εικονικής μνήμης σε ευρετήριο σε debuginfo και στον πίνακα συμβόλων.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Η δηλωμένη διεύθυνση αυτού του τμήματος στο αρχείο αντικειμένου.
    /// Αυτό δεν είναι στην πραγματικότητα όπου φορτώνεται το τμήμα, αλλά αυτή η διεύθυνση συν το `bias` της βιβλιοθήκης που περιέχει είναι πού θα το βρει.
    ///
    stated_virtual_memory_address: usize,
    /// Το μέγεθος αυτού του τμήματος στη μνήμη.
    len: usize,
}

// μη ασφαλές επειδή απαιτείται εξωτερικός συγχρονισμός
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // μη ασφαλές επειδή απαιτείται εξωτερικός συγχρονισμός
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Μια πολύ μικρή, πολύ απλή προσωρινή μνήμη LRU για αντιστοίχιση πληροφοριών εντοπισμού σφαλμάτων.
        //
        // Ο ρυθμός επιτυχίας πρέπει να είναι πολύ υψηλός, καθώς η τυπική στοίβα δεν διασχίζει πολλές κοινές βιβλιοθήκες.
        //
        // Οι δομές `addr2line::Context` είναι πολύ ακριβές για τη δημιουργία τους.
        // Το κόστος του αναμένεται να αποσβένεται με επακόλουθα ερωτήματα `locate`, τα οποία αξιοποιούν τις δομές που δημιουργούνται κατά την κατασκευή του «addr2line: : Context`s για να έχετε ωραίες επιταχύνσεις.
        //
        // Εάν δεν είχαμε αυτήν την κρυφή μνήμη, αυτή η απόσβεση δεν θα συμβεί ποτέ, και η συμβολική οπισθοδρόμηση θα ήταν ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Αρχικά, ελέγξτε εάν αυτό το `lib` έχει οποιοδήποτε τμήμα που περιέχει το `addr` (χειρισμός μετεγκατάστασης).Εάν περάσει αυτός ο έλεγχος τότε μπορούμε να συνεχίσουμε παρακάτω και να μεταφράσουμε πραγματικά τη διεύθυνση.
                //
                // Λάβετε υπόψη ότι χρησιμοποιούμε το `wrapping_add` εδώ για να αποφύγουμε τους ελέγχους υπερχείλισης.Έχει δει στην άγρια φύση ότι ο υπολογισμός προκατάληψης SVMA + ξεχειλίζει.
                // Φαίνεται λίγο περίεργο που θα συνέβαινε, αλλά δεν υπάρχει τεράστιο ποσό που μπορούμε να κάνουμε για αυτό εκτός από πιθανώς απλώς να αγνοήσουμε αυτά τα τμήματα, καθώς πιθανότατα δείχνουν προς το διάστημα.
                //
                // Αυτό εμφανίστηκε αρχικά στο rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Τώρα που γνωρίζουμε ότι το `lib` περιέχει `addr`, μπορούμε να αντισταθμίσουμε με την προκατάληψη για να βρούμε τη δηλωμένη διεύθυνση virutal memory.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Αμετάβλητο: μετά την ολοκλήρωση αυτού του όρου χωρίς πρόωρη επιστροφή
        // από σφάλμα, η καταχώριση προσωρινής μνήμης για αυτήν τη διαδρομή βρίσκεται στο ευρετήριο 0.

        if let Some(idx) = idx {
            // Όταν η αντιστοίχιση βρίσκεται ήδη στην προσωρινή μνήμη, μετακινήστε την προς τα εμπρός.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Όταν η αντιστοίχιση δεν βρίσκεται στην προσωρινή μνήμη, δημιουργήστε μια νέα αντιστοίχιση, τοποθετήστε την στο μπροστινό μέρος της προσωρινής μνήμης και εκδιώξτε την παλαιότερη καταχώριση προσωρινής μνήμης, εάν είναι απαραίτητο.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // μην διαρρεύσετε τη διάρκεια ζωής του `'static`, βεβαιωθείτε ότι καλύπτεται μόνο από τους εαυτούς μας
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Επεκτείνετε τη διάρκεια ζωής του `sym` στο `'static`, διότι δυστυχώς απαιτείται εδώ, αλλά είναι πάντα βγαίνοντας ως αναφορά, οπότε καμία αναφορά σε αυτό δεν πρέπει να παραμείνει πέρα από αυτό το πλαίσιο ούτως ή άλλως.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Τέλος, λάβετε μια προσωρινή μνήμη ή δημιουργήστε μια νέα αντιστοίχιση για αυτό το αρχείο και αξιολογήστε τις πληροφορίες DWARF για να βρείτε το file/line/name για αυτήν τη διεύθυνση.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Καταφέραμε να εντοπίσουμε τις πληροφορίες πλαισίου για αυτό το σύμβολο και το πλαίσιο του "addr2line" έχει εσωτερικά όλες τις λεπτομέρειες.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Δεν ήταν δυνατή η εύρεση πληροφοριών εντοπισμού σφαλμάτων, αλλά τις βρήκαμε στον πίνακα συμβόλων του εκτελέσιμου ξωτικού.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}