//! Στρατηγική συμβολισμού με χρήση του κώδικα ανάλυσης DWARF στο libbacktrace.
//!
//! Η βιβλιοθήκη libbacktrace C, που διανέμεται συνήθως με το gcc, υποστηρίζει όχι μόνο τη δημιουργία ενός backtrace (το οποίο δεν χρησιμοποιούμε πραγματικά), αλλά επίσης συμβολίζει το backtrace και το χειρισμό πληροφοριών εντοπισμού σφαλμάτων νάνου για πράγματα όπως τα κεκλιμένα πλαίσια και τα άλλα.
//!
//!
//! Αυτό είναι σχετικά περίπλοκο λόγω πολλών διαφόρων ανησυχιών εδώ, αλλά η βασική ιδέα είναι:
//!
//! * Πρώτα ονομάζουμε `backtrace_syminfo`.Αυτό παίρνει πληροφορίες συμβόλων από τον πίνακα δυναμικών συμβόλων εάν μπορούμε.
//! * Στη συνέχεια καλούμε `backtrace_pcinfo`.Αυτό θα αναλύσει τους πίνακες εντοπισμού σφαλμάτων εάν είναι διαθέσιμοι και θα μας επιτρέψει να ανακτήσουμε πληροφορίες σχετικά με τα ενσωματωμένα καρέ, τα ονόματα αρχείων, τους αριθμούς γραμμής κ.λπ.
//!
//! Υπάρχουν πολλά κόλπα για να μπουν οι πίνακες νάνων στο libbacktrace, αλλά ελπίζουμε ότι δεν είναι το τέλος του κόσμου και είναι αρκετά σαφές όταν διαβάζετε παρακάτω.
//!
//! Αυτή είναι η προεπιλεγμένη στρατηγική συμβολισμού για πλατφόρμες εκτός MSVC και εκτός OSX.Σε libstd αν και αυτή είναι η προεπιλεγμένη στρατηγική για OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Εάν είναι δυνατόν, προτιμήστε το όνομα `function` που προέρχεται από το debuginfo και μπορεί συνήθως να είναι πιο ακριβές για ενσωματωμένα πλαίσια, για παράδειγμα.
                // Εάν αυτό δεν υπάρχει, επιστρέψτε στο όνομα του πίνακα συμβόλων που καθορίζεται στο `symname`.
                //
                // Σημειώστε ότι μερικές φορές το `function` μπορεί να αισθάνεται κάπως λιγότερο ακριβές, για παράδειγμα να αναφέρεται ως `try<i32,closure>` isntead του `std::panicking::try::do_call`.
                //
                // Δεν είναι ξεκάθαρο γιατί, αλλά συνολικά το όνομα `function` φαίνεται πιο ακριβές.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // μην κάνεις τίποτα για τώρα
}

/// Ο τύπος του δείκτη `data` πέρασε στο `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Μόλις αυτή η επιστροφή κλήσης επικαλεσθεί από το `backtrace_syminfo` όταν αρχίσουμε να επιλύουμε, προχωρούμε περαιτέρω στην κλήση του `backtrace_pcinfo`.
    // Η συνάρτηση `backtrace_pcinfo` θα συμβουλεύεται τις πληροφορίες εντοπισμού σφαλμάτων και θα προσπαθήσει να κάνει πράγματα όπως η ανάκτηση πληροφοριών file/line καθώς και τα ενσωματωμένα καρέ.
    // Λάβετε υπόψη ότι το `backtrace_pcinfo` μπορεί να αποτύχει ή να μην κάνει πολλά αν δεν υπάρχουν πληροφορίες εντοπισμού σφαλμάτων, οπότε αν συμβεί αυτό, είναι βέβαιο ότι θα καλέσετε την επανάκληση με τουλάχιστον ένα σύμβολο από το `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Ο τύπος του δείκτη `data` πέρασε στο `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Το libbacktrace API υποστηρίζει τη δημιουργία μιας κατάστασης, αλλά δεν υποστηρίζει την καταστροφή μιας κατάστασης.
// Το θεωρώ προσωπικά αυτό που σημαίνει ότι ένα κράτος προορίζεται να δημιουργηθεί και στη συνέχεια να ζήσει για πάντα.
//
// Θα ήθελα πολύ να δηλώσω έναν χειριστή at_exit() που καθαρίζει αυτήν την κατάσταση, αλλά το libbacktrace δεν παρέχει κανέναν τρόπο.
//
// Με αυτούς τους περιορισμούς, αυτή η συνάρτηση έχει μια κατάσταση στατικής κρυφής μνήμης που υπολογίζεται την πρώτη φορά που ζητείται.
//
// Θυμηθείτε ότι το backtracing όλα συμβαίνει σειριακά (ένα παγκόσμιο κλείδωμα).
//
// Σημειώστε ότι η έλλειψη συγχρονισμού εδώ οφείλεται στην απαίτηση ότι το `resolve` συγχρονίζεται εξωτερικά.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Μην ασκείτε ασφαλείς δυνατότητες του libbacktrace, αφού το ονομάζουμε πάντα με συγχρονισμένο τρόπο.
        //
        0,
        error_cb,
        ptr::null_mut(), // χωρίς επιπλέον δεδομένα
    );

    return STATE;

    // Σημειώστε ότι για να λειτουργήσει το libbacktrace χρειάζεται να βρείτε τις πληροφορίες εντοπισμού σφαλμάτων DWARF για το τρέχον εκτελέσιμο.Αυτό το κάνει συνήθως μέσω ενός αριθμού μηχανισμών που περιλαμβάνουν, αλλά δεν περιορίζονται σε:
    //
    // * /proc/self/exe σε υποστηριζόμενες πλατφόρμες
    // * Το όνομα αρχείου πέρασε ρητά κατά τη δημιουργία κατάστασης
    //
    // Η βιβλιοθήκη libbacktrace είναι ένα μεγάλο τμήμα κώδικα C.Αυτό φυσικά σημαίνει ότι έχει ευπάθειες στην ασφάλεια της μνήμης, ειδικά όταν χειρίζεται το debuginfo με εσφαλμένη μορφή.
    // Το Libstd αντιμετώπισε πολλά από αυτά ιστορικά.
    //
    // Εάν το /proc/self/exe χρησιμοποιείται, τότε μπορούμε συνήθως να τα αγνοήσουμε καθώς υποθέτουμε ότι το libbacktrace είναι "mostly correct" και διαφορετικά δεν κάνει περίεργα πράγματα με τις πληροφορίες εντοπισμού σφαλμάτων "attempted to be correct" dwarf.
    //
    //
    // Αν όμως περάσουμε σε ένα όνομα αρχείου, τότε είναι δυνατό σε ορισμένες πλατφόρμες (όπως BSD) όπου ένας κακόβουλος ηθοποιός μπορεί να προκαλέσει ένα αυθαίρετο αρχείο να τοποθετηθεί σε αυτήν την τοποθεσία.
    // Αυτό σημαίνει ότι εάν πούμε στο libbacktrace για ένα όνομα αρχείου μπορεί να χρησιμοποιεί ένα αυθαίρετο αρχείο, πιθανόν να προκαλεί segfaults.
    // Αν δεν πούμε τίποτα στο libbacktrace τότε δεν θα κάνει τίποτα σε πλατφόρμες που δεν υποστηρίζουν διαδρομές όπως το /proc/self/exe!
    //
    // Δεδομένου ότι προσπαθούμε όσο το δυνατόν περισσότερο για * να μην περάσουμε σε ένα όνομα αρχείου, αλλά πρέπει σε πλατφόρμες που δεν υποστηρίζουν καθόλου το /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Σημειώστε ότι ιδανικά θα χρησιμοποιούσαμε το `std::env::current_exe`, αλλά δεν μπορούμε να απαιτήσουμε το `std` εδώ.
            //
            // Χρησιμοποιήστε το `_NSGetExecutablePath` για να φορτώσετε την τρέχουσα εκτελέσιμη διαδρομή σε μια στατική περιοχή (η οποία αν είναι πολύ μικρή απλώς εγκαταλείψτε).
            //
            //
            // Σημειώστε ότι εμπιστευόμαστε σοβαρά το libbacktrace εδώ για να μην πεθάνουμε σε διεφθαρμένα εκτελέσιμα, αλλά σίγουρα ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows έχει έναν τρόπο ανοίγματος αρχείων όπου μετά το άνοιγμά του δεν μπορεί να διαγραφεί.
            // Αυτό είναι γενικά αυτό που θέλουμε εδώ, επειδή θέλουμε να διασφαλίσουμε ότι το εκτελέσιμο δεν θα αλλάζει από κάτω από εμάς αφού το παραδώσουμε στο libbacktrace, ελπίζουμε ότι μετριάζει την ικανότητα να μεταβιβαστούν αυθαίρετα δεδομένα στο libbacktrace (τα οποία μπορεί να αντιμετωπιστούν λανθασμένα).
            //
            //
            // Δεδομένου ότι κάνουμε λίγο χορό εδώ για να προσπαθήσουμε να πάρουμε ένα είδος κλειδώματος στη δική μας εικόνα:
            //
            // * Αποκτήστε μια λαβή για την τρέχουσα διαδικασία, φορτώστε το όνομα του αρχείου.
            // * Ανοίξτε ένα αρχείο σε αυτό το όνομα αρχείου με τις σωστές σημαίες.
            // * Φορτώστε ξανά το όνομα αρχείου της τρέχουσας διαδικασίας, βεβαιωθείτε ότι είναι το ίδιο
            //
            // Αν όλα αυτά περάσουν, θεωρητικά έχουμε ανοίξει το αρχείο της διαδικασίας μας και είμαστε εγγυημένοι ότι δεν θα αλλάξει.FWIW ένα σωρό από αυτό αντιγράφεται από το libstd ιστορικά, οπότε αυτή είναι η καλύτερη ερμηνεία μου για το τι συνέβαινε.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Αυτό ζει σε στατική μνήμη, ώστε να μπορούμε να το επιστρέψουμε ..
                static mut BUF: [i8; N] = [0; N];
                // ... και αυτό ζει στη στοίβα αφού είναι προσωρινό
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // Διαρροή σκόπιμα `handle` εδώ επειδή έχοντας ανοιχτό θα πρέπει να διατηρήσουμε το κλείδωμα μας σε αυτό το όνομα αρχείου.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Θέλουμε να επιστρέψουμε ένα κομμάτι που δεν έχει τερματιστεί, οπότε αν όλα συμπληρώθηκαν και ισούται με το συνολικό μήκος, τότε το ισοδυναμεί με αποτυχία.
                //
                //
                // Διαφορετικά, όταν επιστρέφετε στην επιτυχία, βεβαιωθείτε ότι το nul byte περιλαμβάνεται στο slice.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // Τα σφάλματα backtrace σαρώνουν αυτή τη στιγμή κάτω από το χαλί
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Καλέστε το `backtrace_syminfo` API το οποίο (από την ανάγνωση του κωδικού) θα πρέπει να καλέσει το `syminfo_cb` ακριβώς μία φορά (ή πιθανώς να αποτύχει με σφάλμα).
    // Στη συνέχεια χειριζόμαστε περισσότερα μέσα στο `syminfo_cb`.
    //
    // Λάβετε υπόψη ότι το κάνουμε αυτό, καθώς το `syminfo` θα συμβουλευτεί τον πίνακα συμβόλων, βρίσκοντας ονόματα συμβόλων ακόμη και αν δεν υπάρχουν πληροφορίες εντοπισμού σφαλμάτων στο δυαδικό.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}