use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Επιλύστε μια διεύθυνση σε ένα σύμβολο, μεταβιβάζοντας το σύμβολο στο καθορισμένο κλείσιμο.
///
/// Αυτή η συνάρτηση θα αναζητήσει τη δεδομένη διεύθυνση σε περιοχές όπως ο τοπικός πίνακας συμβόλων, ο πίνακας δυναμικών συμβόλων ή οι πληροφορίες εντοπισμού σφαλμάτων DWARF (ανάλογα με την ενεργοποιημένη εφαρμογή) για να βρουν σύμβολα για απόδοση.
///
///
/// Το κλείσιμο ενδέχεται να μην καλείται εάν δεν ήταν δυνατή η εκτέλεση ανάλυσης και μπορεί επίσης να καλείται περισσότερες από μία φορές στην περίπτωση των ενσωματωμένων λειτουργιών.
///
/// Τα παραγόμενα σύμβολα αντιπροσωπεύουν την εκτέλεση στο καθορισμένο `addr`, επιστρέφοντας ζεύγη file/line για τη συγκεκριμένη διεύθυνση (εάν υπάρχει).
///
/// Λάβετε υπόψη ότι εάν έχετε `Frame`, συνιστάται να χρησιμοποιήσετε τη λειτουργία `resolve_frame` αντί αυτής.
///
/// # Απαιτούμενα χαρακτηριστικά
///
/// Αυτή η λειτουργία απαιτεί την ενεργοποίηση της δυνατότητας `std` του `backtrace` crate και η δυνατότητα `std` είναι ενεργοποιημένη από προεπιλογή.
///
/// # Panics
///
/// Αυτή η λειτουργία προσπαθεί ποτέ να panic, αλλά αν το `cb` παρείχε panics τότε ορισμένες πλατφόρμες θα αναγκάσουν ένα διπλό panic να ακυρώσει τη διαδικασία.
/// Ορισμένες πλατφόρμες χρησιμοποιούν βιβλιοθήκη C που χρησιμοποιεί εσωτερικά επιστροφές κλήσεων που δεν μπορούν να ξετυλιχτούν, οπότε η λήψη από το `cb` ενδέχεται να προκαλέσει διακοπή διαδικασίας.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // Κοιτάξτε μόνο στο πάνω πλαίσιο
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Επιλύστε ένα προηγούμενο πλαίσιο λήψης σε ένα σύμβολο, μεταφέροντας το σύμβολο στο καθορισμένο κλείσιμο.
///
/// Αυτό το functin εκτελεί την ίδια λειτουργία με το `resolve` εκτός από το ότι παίρνει το `Frame` ως όρισμα αντί για διεύθυνση.
/// Αυτό μπορεί να επιτρέψει σε ορισμένες εφαρμογές της πλατφόρμας backtracing να παρέχουν πιο ακριβείς πληροφορίες συμβόλων ή πληροφορίες σχετικά με ενσωματωμένα καρέ, για παράδειγμα.
///
/// Συνιστάται να το χρησιμοποιείτε αν μπορείτε.
///
/// # Απαιτούμενα χαρακτηριστικά
///
/// Αυτή η λειτουργία απαιτεί την ενεργοποίηση της δυνατότητας `std` του `backtrace` crate και η δυνατότητα `std` είναι ενεργοποιημένη από προεπιλογή.
///
/// # Panics
///
/// Αυτή η λειτουργία προσπαθεί ποτέ να panic, αλλά αν το `cb` παρείχε panics τότε ορισμένες πλατφόρμες θα αναγκάσουν ένα διπλό panic να ακυρώσει τη διαδικασία.
/// Ορισμένες πλατφόρμες χρησιμοποιούν βιβλιοθήκη C που χρησιμοποιεί εσωτερικά επιστροφές κλήσεων που δεν μπορούν να ξετυλιχτούν, οπότε η λήψη από το `cb` ενδέχεται να προκαλέσει διακοπή διαδικασίας.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // Κοιτάξτε μόνο στο πάνω πλαίσιο
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Οι τιμές IP από πλαίσια στοίβας είναι συνήθως (always?) η εντολή *μετά* την κλήση που είναι το πραγματικό ίχνος στοίβας.
// Συμβολίζοντας αυτό, ο αριθμός filename/line είναι ένας μπροστά και ίσως στο κενό εάν είναι κοντά στο τέλος της λειτουργίας.
//
// Αυτό φαίνεται να ισχύει πάντοτε σε όλες τις πλατφόρμες, οπότε αφαιρούμε πάντα ένα από ένα επιλυμένο ip για να το επιλύσουμε στην προηγούμενη εντολή κλήσης αντί για την εντολή που επιστρέφεται.
//
//
// Στην ιδανική περίπτωση δεν θα το κάναμε αυτό.
// Στην ιδανική περίπτωση, θα απαιτούσαμε από τους καλούντες των `resolve` API εδώ να κάνουν χειροκίνητα το -1 και να λάβουν λογαριασμό ότι θέλουν πληροφορίες τοποθεσίας για την *προηγούμενη* οδηγία, όχι την τρέχουσα.
// Στην ιδανική περίπτωση θα εκθέτουμε επίσης στο `Frame` εάν είμαστε πράγματι η διεύθυνση της επόμενης εντολής ή της τρέχουσας.
//
// Προς το παρόν, αν και αυτό είναι μια πολύ ενδιαφέρουσα ανησυχία, επομένως απλώς εσωτερικά αφαιρούμε ένα.
// Οι καταναλωτές πρέπει να συνεχίσουν να εργάζονται και να έχουν αρκετά καλά αποτελέσματα, οπότε θα πρέπει να είμαστε αρκετά καλοί.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Το ίδιο με το `resolve`, μόνο μη ασφαλές καθώς δεν είναι συγχρονισμένο.
///
/// Αυτή η συνάρτηση δεν έχει εγγυητές συγχρονισμού, αλλά είναι διαθέσιμη όταν η δυνατότητα `std` αυτού του crate δεν έχει μεταγλωττιστεί.
/// Δείτε τη συνάρτηση `resolve` για περισσότερα έγγραφα και παραδείγματα.
///
/// # Panics
///
/// Δείτε πληροφορίες για το `resolve` για προειδοποιήσεις σχετικά με το πανικό `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Το ίδιο με το `resolve_frame`, μόνο μη ασφαλές καθώς δεν είναι συγχρονισμένο.
///
/// Αυτή η συνάρτηση δεν έχει εγγυητές συγχρονισμού, αλλά είναι διαθέσιμη όταν η δυνατότητα `std` αυτού του crate δεν έχει μεταγλωττιστεί.
/// Δείτε τη συνάρτηση `resolve_frame` για περισσότερα έγγραφα και παραδείγματα.
///
/// # Panics
///
/// Δείτε πληροφορίες για το `resolve_frame` για προειδοποιήσεις σχετικά με το πανικό `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Ένα trait που αντιπροσωπεύει την ανάλυση ενός συμβόλου σε ένα αρχείο.
///
/// Αυτό το trait αποδίδεται ως αντικείμενο trait στο κλείσιμο που δίνεται στη συνάρτηση `backtrace::resolve` και ουσιαστικά αποστέλλεται καθώς δεν είναι γνωστό ποια εφαρμογή βρίσκεται πίσω από αυτό.
///
///
/// Ένα σύμβολο μπορεί να δώσει πληροφορίες σχετικά με τη συνάρτηση σχετικά με μια συνάρτηση, για παράδειγμα το όνομα, το όνομα αρχείου, τον αριθμό γραμμής, την ακριβή διεύθυνση κ.λπ.
/// Ωστόσο, δεν είναι πάντα διαθέσιμες όλες οι πληροφορίες σε ένα σύμβολο, επομένως όλες οι μέθοδοι επιστρέφουν ένα `Option`.
///
///
pub struct Symbol {
    // TODO: αυτό το δεσμευμένο σε όλη τη ζωή πρέπει να διατηρηθεί τελικά στο `Symbol`,
    // αλλά αυτή τη στιγμή είναι μια σημαντική αλλαγή.
    // Προς το παρόν αυτό είναι ασφαλές, καθώς το `Symbol` διανέμεται μόνο με αναφορά και δεν μπορεί να κλωνοποιηθεί.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Επιστρέφει το όνομα αυτής της λειτουργίας.
    ///
    /// Η επιστρεφόμενη δομή μπορεί να χρησιμοποιηθεί για την αναζήτηση διαφόρων ιδιοτήτων σχετικά με το όνομα του συμβόλου:
    ///
    ///
    /// * Η εφαρμογή `Display` θα εκτυπώσει το διαχωρισμένο σύμβολο.
    /// * Μπορείτε να αποκτήσετε πρόσβαση στην πρώτη τιμή `str` του συμβόλου (εάν ισχύει utf-8).
    /// * Μπορείτε να έχετε πρόσβαση στα ακατέργαστα byte για το όνομα του συμβόλου.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Επιστρέφει την αρχική διεύθυνση αυτής της λειτουργίας.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Επιστρέφει το ακατέργαστο όνομα αρχείου ως φέτα.
    /// Αυτό είναι κυρίως χρήσιμο για περιβάλλοντα `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Επιστρέφει τον αριθμό της στήλης για το σημείο που εκτελείται αυτό το σύμβολο.
    ///
    /// Μόνο το gimli παρέχει αυτήν τη στιγμή μια τιμή εδώ και ακόμη και τότε μόνο εάν το `filename` επιστρέφει το `Some` και συνεπώς υπόκειται επομένως σε παρόμοιες προειδοποιήσεις.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Επιστρέφει τον αριθμό γραμμής για το σημείο εκτέλεσης αυτού του συμβόλου.
    ///
    /// Αυτή η τιμή επιστροφής είναι συνήθως `Some` εάν το `filename` επιστρέφει το `Some` και συνεπώς υπόκειται σε παρόμοιες προειδοποιήσεις.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Επιστρέφει το όνομα του αρχείου όπου καθορίστηκε αυτή η συνάρτηση.
    ///
    /// Αυτή τη στιγμή είναι διαθέσιμη μόνο όταν χρησιμοποιείται το libbacktrace ή το gimli (π.χ.
    /// unix πλατφόρμες άλλες) και όταν ένα δυαδικό μεταγλωττίζεται με το debuginfo.
    /// Εάν δεν πληρούται καμία από αυτές τις προϋποθέσεις, τότε πιθανότατα θα επιστρέψει το `None`.
    ///
    /// # Απαιτούμενα χαρακτηριστικά
    ///
    /// Αυτή η λειτουργία απαιτεί την ενεργοποίηση της δυνατότητας `std` του `backtrace` crate και η δυνατότητα `std` είναι ενεργοποιημένη από προεπιλογή.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Ίσως ένα αναλυμένο σύμβολο C++ , εάν αποτύχει η ανάλυση του συμβολοσειρά ως Rust.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Φροντίστε να διατηρήσετε αυτό το μηδενικό μέγεθος, έτσι ώστε η δυνατότητα `cpp_demangle` να μην έχει κόστος όταν είναι απενεργοποιημένη.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Ένα περιτύλιγμα γύρω από ένα όνομα συμβόλου για την παροχή εργονομικών βοηθητικών παραγόντων στο διαχωρισμένο όνομα, τα ακατέργαστα bytes, την ακατέργαστη συμβολοσειρά κ.λπ.
///
// Να επιτρέπεται ο νεκρός κωδικός όταν δεν είναι ενεργοποιημένη η δυνατότητα `cpp_demangle`.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Δημιουργεί ένα νέο όνομα συμβόλου από τα ακατέργαστα υποκείμενα byte.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Επιστρέφει το αρχικό όνομα συμβόλου (mangled) ως `str` εάν το σύμβολο είναι έγκυρο utf-8.
    ///
    /// Χρησιμοποιήστε την εφαρμογή `Display`, εάν θέλετε την εκκαθαρισμένη έκδοση.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Επιστρέφει το αρχικό όνομα συμβόλου ως λίστα byte
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Αυτό μπορεί να εκτυπωθεί, εάν το σύμβολο αποδιοργανωμένου δεν είναι στην πραγματικότητα έγκυρο, οπότε χειριστείτε το σφάλμα εδώ χαριτωμένα, μην το διαδώσετε προς τα έξω.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Προσπαθήστε να ανακτήσετε αυτήν την προσωρινή μνήμη που χρησιμοποιείται για να συμβολίσει διευθύνσεις.
///
/// Αυτή η μέθοδος θα προσπαθήσει να απελευθερώσει οποιεσδήποτε καθολικές δομές δεδομένων που διαφορετικά είχαν προσωρινά αποθηκευτεί παγκοσμίως ή στο νήμα που συνήθως αντιπροσωπεύουν αναλυμένες πληροφορίες DWARF ή παρόμοιες.
///
///
/// # Caveats
///
/// Ενώ αυτή η λειτουργία είναι πάντα διαθέσιμη, δεν κάνει τίποτα στις περισσότερες εφαρμογές.
/// Οι βιβλιοθήκες όπως το dbghelp ή το libbacktrace δεν παρέχουν διευκολύνσεις για την απομάκρυνση της κατάστασης και τη διαχείριση της εκχωρημένης μνήμης.
/// Προς το παρόν η δυνατότητα `gimli-symbolize` αυτού του crate είναι η μόνη δυνατότητα όπου αυτή η λειτουργία έχει οποιοδήποτε αποτέλεσμα.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}