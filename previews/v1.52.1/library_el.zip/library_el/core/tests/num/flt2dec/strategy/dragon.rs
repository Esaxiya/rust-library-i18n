use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Η Miri είναι πολύ αργή
fn exact_sanity_test() {
    // Αυτή η δοκιμή καταλήγει να εκτελεί ό, τι μπορώ να υποθέσω μόνο ότι είναι κάποια γωνιακή περίπτωση της συνάρτησης βιβλιοθήκης `exp2`, που ορίζεται σε οποιοδήποτε χρόνο εκτέλεσης C χρησιμοποιούμε.
    // Στο VS 2013, αυτή η λειτουργία είχε προφανώς ένα σφάλμα καθώς αυτή η δοκιμή αποτυγχάνει όταν συνδέεται, αλλά με το VS 2015 το σφάλμα εμφανίζεται σταθερό καθώς η δοκιμή εκτελείται εντάξει.
    //
    // Το σφάλμα φαίνεται να είναι μια διαφορά στην τιμή επιστροφής του `exp2(-1057)`, όπου στο VS 2013 επιστρέφει ένα διπλό με το μοτίβο bit 0x2 και στο VS 2015 επιστρέφει 0x20000.
    //
    //
    // Προς το παρόν, απλώς αγνοήστε αυτήν τη δοκιμή εξ ολοκλήρου στο MSVC καθώς δοκιμάζεται αλλού και δεν ενδιαφερόμαστε πολύ να δοκιμάσουμε την εφαρμογή exp2 κάθε πλατφόρμας.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}