use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Αυτό δεν είναι σταθερό εμβαδόν επιφάνειας, αλλά βοηθά να διατηρηθεί το `?` φθηνό μεταξύ τους, ακόμα κι αν το LLVM δεν μπορεί πάντα να το εκμεταλλευτεί αυτήν τη στιγμή.
    //
    // (Δυστυχώς το αποτέλεσμα και η επιλογή είναι ασυνεπή, οπότε το ControlFlow δεν μπορεί να ταιριάξει και τα δύο.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}