//! Note
//! ----
//! Πιθανότατα βλέπετε αυτό το αρχείο επειδή προσθέτετε μια δοκιμή (ή ίσως απλά περιηγείστε, σε αυτήν την περίπτωση, hey εκεί!).
//!
//! Η δοκιμαστική σουίτα iter χωρίζεται σε δύο μεγάλες ενότητες και σε μερικές μικρότερες ενότητες.Οι δύο μεγάλες ενότητες είναι `adapters` και `traits`.
//!
//! `adapters` προορίζονται για μεθόδους στο `Iterator` που προσαρμόζουν τα δεδομένα μέσα στον επαναληπτή, είτε εκπέμποντας ένα άλλο επαναληπτικό είτε επιστρέφοντας ένα στοιχείο από μέσα στο επαναληπτικό μετά την εκτέλεση ενός κλεισίματος σε κάθε στοιχείο.
//!
//!
//! `traits` προορίζονται για trait's που επεκτείνουν ένα `Iterator` (και το ίδιο το `Iterator` trait, που περιέχουν κυρίως διάφορες μεθόδους).
//! Ως επί το πλείστον, εάν μια δοκιμή στο `traits` χρησιμοποιεί έναν συγκεκριμένο προσαρμογέα, τότε θα πρέπει να μετακινηθεί στο αρχείο δοκιμής αυτού του προσαρμογέα στο `adapters`.
//!
//!
//!
//!
//!

mod adapters;
mod range;
mod sources;
mod traits;

use core::cell::Cell;
use core::convert::TryFrom;
use core::iter::*;

pub fn is_trusted_len<I: TrustedLen>(_: I) {}

#[test]
fn test_multi_iter() {
    let xs = [1, 2, 3, 4];
    let ys = [4, 3, 2, 1];
    assert!(xs.iter().eq(ys.iter().rev()));
    assert!(xs.iter().lt(xs.iter().skip(2)));
}

#[test]
fn test_counter_from_iter() {
    let it = (0..).step_by(5).take(10);
    let xs: Vec<isize> = FromIterator::from_iter(it);
    assert_eq!(xs, [0, 5, 10, 15, 20, 25, 30, 35, 40, 45]);
}

#[test]
fn test_functor_laws() {
    // identity:
    fn identity<T>(x: T) -> T {
        x
    }
    assert_eq!((0..10).map(identity).sum::<usize>(), (0..10).sum());

    // composition:
    fn f(x: usize) -> usize {
        x + 3
    }
    fn g(x: usize) -> usize {
        x * 2
    }
    fn h(x: usize) -> usize {
        g(f(x))
    }
    assert_eq!((0..10).map(f).map(g).sum::<usize>(), (0..10).map(h).sum());
}

#[test]
fn test_monad_laws_left_identity() {
    fn f(x: usize) -> impl Iterator<Item = usize> {
        (0..10).map(move |y| x * y)
    }
    assert_eq!(once(42).flat_map(f.clone()).sum::<usize>(), f(42).sum());
}

#[test]
fn test_monad_laws_right_identity() {
    assert_eq!((0..10).flat_map(|x| once(x)).sum::<usize>(), (0..10).sum());
}

#[test]
fn test_monad_laws_associativity() {
    fn f(x: usize) -> impl Iterator<Item = usize> {
        0..x
    }
    fn g(x: usize) -> impl Iterator<Item = usize> {
        (0..x).rev()
    }
    assert_eq!(
        (0..10).flat_map(f).flat_map(g).sum::<usize>(),
        (0..10).flat_map(|x| f(x).flat_map(g)).sum::<usize>()
    );
}

#[test]
pub fn extend_for_unit() {
    let mut x = 0;
    {
        let iter = (0..5).map(|_| {
            x += 1;
        });
        ().extend(iter);
    }
    assert_eq!(x, 5);
}