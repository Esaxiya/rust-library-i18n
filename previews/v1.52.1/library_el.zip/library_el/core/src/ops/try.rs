/// Ένα trait για προσαρμογή της συμπεριφοράς του χειριστή `?`.
///
/// Ένας τύπος που εφαρμόζει το `Try` είναι αυτός που έχει έναν κανονικό τρόπο για να το δει με όρους διχοτομίας success/failure.
/// Αυτό το trait επιτρέπει την εξαγωγή αυτών των τιμών επιτυχίας ή αποτυχίας από μια υπάρχουσα παρουσία και τη δημιουργία μιας νέας παρουσίας από μια τιμή επιτυχίας ή αποτυχίας.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Ο τύπος αυτής της τιμής όταν θεωρείται επιτυχής.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Ο τύπος αυτής της τιμής όταν προβληθεί ως αποτυχημένος.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Εφαρμόζει το χειριστή "?".Η επιστροφή του `Ok(t)` σημαίνει ότι η εκτέλεση θα πρέπει να συνεχιστεί κανονικά και το αποτέλεσμα του `?` είναι η τιμή `t`.
    /// Η επιστροφή του `Err(e)` σημαίνει ότι η εκτέλεση πρέπει να branch στο εσωτερικό του `catch` ή να επιστρέφει από τη συνάρτηση.
    ///
    /// Εάν επιστραφεί ένα αποτέλεσμα `Err(e)`, η τιμή `e` θα είναι "wrapped" στον τύπο επιστροφής του εύρους εγκλεισμού (το οποίο πρέπει να εφαρμόσει το ίδιο το `Try`).
    ///
    /// Συγκεκριμένα, επιστρέφεται η τιμή `X::from_error(From::from(e))`, όπου το `X` είναι ο τύπος επιστροφής της συνάρτησης.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Τυλίξτε μια τιμή σφάλματος για να δημιουργήσετε το σύνθετο αποτέλεσμα.
    /// Για παράδειγμα, τα `Result::Err(x)` και `Result::from_error(x)` είναι ισοδύναμα.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Τυλίξτε μια τιμή ΟΚ για να δημιουργήσετε το σύνθετο αποτέλεσμα.
    /// Για παράδειγμα, τα `Result::Ok(x)` και `Result::from_ok(x)` είναι ισοδύναμα.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}