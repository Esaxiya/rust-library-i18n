/// Χρησιμοποιείται για αμετάβλητες λειτουργίες αποαναφοράς, όπως το `*v`.
///
/// Εκτός από το ότι χρησιμοποιείται για ρητές αποαναφορές σε σχέση με τον χειριστή (unary) `*` σε αμετάβλητα περιβάλλοντα, το `Deref` χρησιμοποιείται επίσης σιωπηρά από τον μεταγλωττιστή σε πολλές περιπτώσεις.
/// Αυτός ο μηχανισμός ονομάζεται ['`Deref` coercion'][more].
/// Σε μεταβλητά περιβάλλοντα, χρησιμοποιείται το [`DerefMut`].
///
/// Η εφαρμογή του `Deref` για έξυπνους δείκτες διευκολύνει την πρόσβαση στα δεδομένα πίσω από αυτά, γι 'αυτό και εφαρμόζουν το `Deref`.
/// Από την άλλη πλευρά, οι κανόνες σχετικά με τα `Deref` και [`DerefMut`] σχεδιάστηκαν ειδικά για να φιλοξενήσουν έξυπνους δείκτες.
/// Εξαιτίας αυτού, το **Deref θα πρέπει να εφαρμόζεται μόνο για έξυπνους δείκτες** για να αποφευχθεί σύγχυση.
///
/// Για παρόμοιους λόγους,**αυτό το trait δεν πρέπει ποτέ να αποτύχει**.Η αποτυχία κατά τη διάρκεια της αποπαραπομπής μπορεί να είναι εξαιρετικά συγκεχυμένη όταν το `Deref` καλείται σιωπηρά.
///
/// # Περισσότερα για τον εξαναγκασμό `Deref`
///
/// Εάν το `T` εφαρμόζει το `Deref<Target = U>` και το `x` είναι τιμή τύπου `T`, τότε:
///
/// * Σε αμετάβλητα περιβάλλοντα, το `*x` (όπου το `T` δεν είναι ούτε αναφορά ούτε ένα ακατέργαστο δείκτη) είναι ισοδύναμο με το `* Deref::deref(&x)`.
/// * Οι τιμές του τύπου `&T` εξαναγκάζονται σε τιμές του τύπου `&U`
/// * `T` εφαρμόζει σιωπηρά όλες τις μεθόδους (immutable) του τύπου `U`.
///
/// Για περισσότερες λεπτομέρειες, επισκεφθείτε το [the chapter in *The Rust Programming Language*][book] καθώς και τις ενότητες αναφοράς στα [the dereference operator][ref-deref-op], [method resolution] και [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Μια δομή με ένα μόνο πεδίο, η οποία είναι προσβάσιμη με αποπροσανατολισμό της δομής.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Ο τύπος που προκύπτει μετά την αποαναφορά.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Αναφέρει την τιμή.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Χρησιμοποιείται για μεταβλητές λειτουργίες αποαναφοράς, όπως στο `*v = 1;`.
///
/// Εκτός από το ότι χρησιμοποιείται για ρητές αποαναφορές στις λειτουργίες με το χειριστή (unary) `*` σε μεταβλητά περιβάλλοντα, το `DerefMut` χρησιμοποιείται επίσης σιωπηρά από τον μεταγλωττιστή σε πολλές περιπτώσεις.
/// Αυτός ο μηχανισμός ονομάζεται ['`Deref` coercion'][more].
/// Σε αμετάβλητα περιβάλλοντα, χρησιμοποιείται το [`Deref`].
///
/// Η εφαρμογή του `DerefMut` για έξυπνους δείκτες καθιστά εύκολη τη μετάλλαξη των δεδομένων πίσω από αυτά, γι 'αυτό και εφαρμόζουν το `DerefMut`.
/// Από την άλλη πλευρά, οι κανόνες σχετικά με τα [`Deref`] και `DerefMut` σχεδιάστηκαν ειδικά για να φιλοξενήσουν έξυπνους δείκτες.
/// Εξαιτίας αυτού, το **"DerefMut" θα πρέπει να εφαρμόζεται μόνο για έξυπνους δείκτες** για την αποφυγή σύγχυσης.
///
/// Για παρόμοιους λόγους,**αυτό το trait δεν πρέπει ποτέ να αποτύχει**.Η αποτυχία κατά τη διάρκεια της αποπαραπομπής μπορεί να είναι εξαιρετικά συγκεχυμένη όταν το `DerefMut` καλείται σιωπηρά.
///
/// # Περισσότερα για τον εξαναγκασμό `Deref`
///
/// Εάν το `T` εφαρμόζει το `DerefMut<Target = U>` και το `x` είναι τιμή τύπου `T`, τότε:
///
/// * Σε μεταβλητά περιβάλλοντα, το `*x` (όπου το `T` δεν είναι ούτε αναφορά ούτε ακατέργαστο δείκτη) είναι ισοδύναμο με το `* DerefMut::deref_mut(&mut x)`.
/// * Οι τιμές του τύπου `&mut T` εξαναγκάζονται σε τιμές του τύπου `&mut U`
/// * `T` εφαρμόζει σιωπηρά όλες τις μεθόδους (mutable) του τύπου `U`.
///
/// Για περισσότερες λεπτομέρειες, επισκεφθείτε το [the chapter in *The Rust Programming Language*][book] καθώς και τις ενότητες αναφοράς στα [the dereference operator][ref-deref-op], [method resolution] και [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Μια δομή με ένα μόνο πεδίο το οποίο μπορεί να τροποποιηθεί με αποπροσανατολισμό της δομής.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Αμοιβαία αναφέρει την τιμή.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Υποδεικνύει ότι μια δομή μπορεί να χρησιμοποιηθεί ως δέκτης μεθόδου, χωρίς τη δυνατότητα `arbitrary_self_types`.
///
/// Αυτό υλοποιείται από τύπους δεικτών stdlib όπως `Box<T>`, `Rc<T>`, `&T` και `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}