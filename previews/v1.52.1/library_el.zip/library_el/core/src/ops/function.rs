/// Η έκδοση του χειριστή κλήσεων που παίρνει έναν αμετάβλητο δέκτη.
///
/// Οι παρουσίες του `Fn` μπορούν να κληθούν επανειλημμένα χωρίς κατάσταση μετάλλαξης.
///
/// *Αυτό το trait (`Fn`) δεν πρέπει να συγχέεται με το [function pointers] (`fn`).*
///
/// `Fn` υλοποιείται αυτόματα από κλεισίματα τα οποία λαμβάνουν μόνο αμετάβλητες αναφορές σε καταγεγραμμένες μεταβλητές ή δεν καταγράφουν καθόλου, καθώς και (safe) [function pointers] (με ορισμένες προειδοποιήσεις, ανατρέξτε στην τεκμηρίωσή τους για περισσότερες λεπτομέρειες).
///
/// Επιπλέον, για οποιονδήποτε τύπο `F` που εφαρμόζει `Fn`, το `&F` εφαρμόζει επίσης `Fn`.
///
/// Δεδομένου ότι και οι δύο [`FnMut`] και [`FnOnce`] είναι υπερσυστήματα του `Fn`, οποιαδήποτε παρουσία του `Fn` μπορεί να χρησιμοποιηθεί ως παράμετρος όπου αναμένεται [`FnMut`] ή [`FnOnce`].
///
/// Χρησιμοποιήστε το `Fn` ως δεσμευμένο όταν θέλετε να αποδεχτείτε μια παράμετρο τύπου τύπου λειτουργίας και πρέπει να την καλέσετε επανειλημμένα και χωρίς κατάσταση μετάλλαξης (π.χ. όταν την καλεί ταυτόχρονα).
/// Εάν δεν χρειάζεστε τόσο αυστηρές απαιτήσεις, χρησιμοποιήστε τα [`FnMut`] ή [`FnOnce`] ως όρια.
///
/// Δείτε το [chapter on closures in *The Rust Programming Language*][book] για περισσότερες πληροφορίες σχετικά με αυτό το θέμα.
///
/// Σημείωση είναι επίσης η ειδική σύνταξη για `Fn` traits (π.χ.
/// `Fn(usize, bool) -> χρησιμοποιήστε »).Όσοι ενδιαφέρονται για τις τεχνικές λεπτομέρειες αυτού μπορούν να ανατρέξουν στο [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Κλήση κλεισίματος
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Χρησιμοποιώντας μια παράμετρο `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // έτσι ώστε το regex να μπορεί να βασιστεί σε αυτό το `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Εκτελεί τη λειτουργία κλήσης.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Η έκδοση του χειριστή κλήσεων που λαμβάνει έναν μεταβλητό δέκτη.
///
/// Οι παρουσίες του `FnMut` μπορούν να κληθούν επανειλημμένα και μπορεί να μεταλλάξουν την κατάσταση.
///
/// `FnMut` υλοποιείται αυτόματα από κλεισίματα που λαμβάνουν μεταβλητές αναφορές σε μεταβλητές που έχουν καταγραφεί, καθώς και όλους τους τύπους που εφαρμόζουν [`Fn`], π.χ. (safe) [function pointers] (αφού το `FnMut` είναι ένα supertrait του [`Fn`]).
/// Επιπλέον, για οποιονδήποτε τύπο `F` που εφαρμόζει `FnMut`, το `&mut F` εφαρμόζει επίσης `FnMut`.
///
/// Δεδομένου ότι το [`FnOnce`] είναι ένα supertrait του `FnMut`, οποιαδήποτε περίπτωση του `FnMut` μπορεί να χρησιμοποιηθεί όπου αναμένεται ένα [`FnOnce`], και δεδομένου ότι το [`Fn`] είναι ένα υπόστρωμα του `FnMut`, οποιαδήποτε περίπτωση του [`Fn`] μπορεί να χρησιμοποιηθεί όπου αναμένεται το `FnMut`.
///
/// Χρησιμοποιήστε το `FnMut` ως όριο όταν θέλετε να αποδεχτείτε μια παράμετρο τύπου τύπου λειτουργίας και πρέπει να την καλέσετε επανειλημμένα, επιτρέποντάς της να αλλάξει κατάσταση.
/// Εάν δεν θέλετε η παράμετρος να μεταλλάσσεται κατάσταση, χρησιμοποιήστε το [`Fn`] ως δεσμευμένο.εάν δεν χρειάζεται να το καλέσετε επανειλημμένα, χρησιμοποιήστε το [`FnOnce`].
///
/// Δείτε το [chapter on closures in *The Rust Programming Language*][book] για περισσότερες πληροφορίες σχετικά με αυτό το θέμα.
///
/// Σημείωση είναι επίσης η ειδική σύνταξη για `Fn` traits (π.χ.
/// `Fn(usize, bool) -> χρησιμοποιήστε »).Όσοι ενδιαφέρονται για τις τεχνικές λεπτομέρειες αυτού μπορούν να ανατρέξουν στο [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Κλήση κλεισίματος με δυνατότητα λήψης
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Χρησιμοποιώντας μια παράμετρο `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // έτσι ώστε το regex να μπορεί να βασιστεί σε αυτό το `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Εκτελεί τη λειτουργία κλήσης.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Η έκδοση του τελεστή κλήσεων που λαμβάνει έναν παραλήπτη ανά αξία.
///
/// Οι εμφανίσεις του `FnOnce` μπορούν να κληθούν, αλλά ενδέχεται να μην είναι δυνατή η κλήση πολλές φορές.Εξαιτίας αυτού, εάν το μόνο πράγμα που είναι γνωστό για έναν τύπο είναι ότι εφαρμόζει το `FnOnce`, μπορεί να κληθεί μόνο μία φορά.
///
/// `FnOnce` υλοποιείται αυτόματα από κλεισίματα που ενδέχεται να καταναλώνουν καταγεγραμμένες μεταβλητές, καθώς και όλους τους τύπους που εφαρμόζουν [`FnMut`], π.χ. (safe) [function pointers] (δεδομένου ότι το `FnOnce` είναι supertrait του [`FnMut`]).
///
///
/// Δεδομένου ότι και οι δύο [`Fn`] και [`FnMut`] είναι υποστρώματα του `FnOnce`, οποιαδήποτε περίπτωση [`Fn`] ή [`FnMut`] μπορεί να χρησιμοποιηθεί όπου αναμένεται ένα `FnOnce`.
///
/// Χρησιμοποιήστε το `FnOnce` ως όριο όταν θέλετε να αποδεχτείτε μια παράμετρο τύπου τύπου λειτουργίας και πρέπει να την καλέσετε μόνο μία φορά.
/// Εάν πρέπει να καλέσετε επανειλημμένα την παράμετρο, χρησιμοποιήστε το [`FnMut`] ως δεσμευμένο.εάν το χρειάζεστε επίσης για να μην κάνετε μετάλλαξη κατάστασης, χρησιμοποιήστε το [`Fn`].
///
/// Δείτε το [chapter on closures in *The Rust Programming Language*][book] για περισσότερες πληροφορίες σχετικά με αυτό το θέμα.
///
/// Σημείωση είναι επίσης η ειδική σύνταξη για `Fn` traits (π.χ.
/// `Fn(usize, bool) -> χρησιμοποιήστε »).Όσοι ενδιαφέρονται για τις τεχνικές λεπτομέρειες αυτού μπορούν να ανατρέξουν στο [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Χρησιμοποιώντας μια παράμετρο `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` καταναλώνει τις καταγεγραμμένες μεταβλητές της, οπότε δεν μπορεί να εκτελεστεί περισσότερες από μία φορές.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Η απόπειρα επανάκλησης του `func()` θα προκαλέσει σφάλμα `use of moved value` για το `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` δεν μπορεί πλέον να γίνει επίκληση σε αυτό το σημείο
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // έτσι ώστε το regex να μπορεί να βασιστεί σε αυτό το `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Ο επιστρεφόμενος τύπος μετά τη χρήση του τελεστή κλήσεων.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Εκτελεί τη λειτουργία κλήσης.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}