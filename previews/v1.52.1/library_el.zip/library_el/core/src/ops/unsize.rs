use crate::marker::Unsize;

/// Trait που δηλώνει ότι πρόκειται για δείκτη ή περιτύλιγμα για ένα, όπου μπορεί να εκτελεστεί αλλαγή μεγέθους στο pointee.
///
/// Ανατρέξτε στα [DST coercion RFC][dst-coerce] και [the nomicon entry on coercion][nomicon-coerce] για περισσότερες λεπτομέρειες.
///
/// Για τους ενσωματωμένους τύπους δεικτών, οι δείκτες στο `T` θα εξαναγκάζονται σε δείκτες στο `U` εάν `T: Unsize<U>` μετατρέποντας από ένα λεπτό δείκτη σε έναν δείκτη λίπους.
///
/// Για προσαρμοσμένους τύπους, ο εξαναγκασμός εδώ λειτουργεί με εξαναγκασμό `Foo<T>` έως `Foo<U>` υπό την προϋπόθεση ότι υπάρχει ένα impl of `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Ένα τέτοιο impl μπορεί να γραφτεί μόνο εάν το `Foo<T>` έχει μόνο ένα πεδίο που δεν περιλαμβάνει τα phantomdata που περιλαμβάνει το `T`.
/// Εάν ο τύπος αυτού του πεδίου είναι `Bar<T>`, πρέπει να υπάρχει εφαρμογή του `CoerceUnsized<Bar<U>> for Bar<T>`.
/// Ο εξαναγκασμός θα λειτουργήσει πιέζοντας το πεδίο `Bar<T>` σε `Bar<U>` και συμπληρώνοντας τα υπόλοιπα πεδία από το `Foo<T>` για να δημιουργήσει ένα `Foo<U>`.
/// Αυτό θα λειτουργήσει αποτελεσματικά σε ένα πεδίο δείκτη και θα το εξαναγκάσει.
///
/// Γενικά, για έξυπνους δείκτες θα εφαρμόσετε το `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, με ένα προαιρετικό `?Sized` συνδεδεμένο στο ίδιο το `T`.
/// Για τύπους περιτυλίγματος που ενσωματώνουν απευθείας `T` όπως `Cell<T>` και `RefCell<T>`, μπορείτε να εφαρμόσετε απευθείας το `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Αυτό θα επιτρέψει σε εξαναγκασμούς τύπων όπως το `Cell<Box<T>>` να λειτουργήσουν.
///
/// [`Unsize`][unsize] χρησιμοποιείται για την επισήμανση τύπων που μπορούν να εξαναγκαστούν σε DST εάν βρίσκονται πίσω από δείκτες.Εφαρμόζεται αυτόματα από τον μεταγλωττιστή.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Αυτό χρησιμοποιείται για την ασφάλεια αντικειμένων, για να ελέγξετε εάν μπορεί να αποσταλεί ο τύπος δέκτη μιας μεθόδου.
///
/// Ένα παράδειγμα εφαρμογής του trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}