//! Υπερφορτωμένοι χειριστές.
//!
//! Η εφαρμογή αυτών των traits σάς επιτρέπει να υπερφορτώνετε συγκεκριμένους χειριστές.
//!
//! Ορισμένα από αυτά τα traits εισάγονται από το prelude, επομένως είναι διαθέσιμα σε κάθε πρόγραμμα Rust.Μόνο οι χειριστές που υποστηρίζονται από το traits μπορούν να υπερφορτωθούν.
//! Για παράδειγμα, ο χειριστής προσθήκης (`+`) μπορεί να υπερφορτωθεί μέσω του [`Add`] trait, αλλά επειδή ο χειριστής ανάθεσης (`=`) δεν έχει υποστήριξη trait, δεν υπάρχει τρόπος υπερφόρτωσης της σημασιολογίας του.
//! Επιπλέον, αυτή η ενότητα δεν παρέχει κανένα μηχανισμό για τη δημιουργία νέων τελεστών.
//! Εάν απαιτείται υπερβολική υπερφόρτωση ή προσαρμοσμένοι τελεστές, θα πρέπει να κοιτάξετε προς τις μακροεντολές ή τα πρόσθετα μεταγλωττιστή για να επεκτείνετε τη σύνταξη του Rust.
//!
//! Οι υλοποιήσεις του χειριστή traits δεν πρέπει να προκαλούν έκπληξη στα αντίστοιχα περιβάλλοντά τους, έχοντας κατά νου τις συνήθεις έννοιες και το [operator precedence].
//! Για παράδειγμα, κατά την εφαρμογή [`Mul`], η λειτουργία θα πρέπει να έχει κάποια ομοιότητα με τον πολλαπλασιασμό (και να μοιράζεται τις αναμενόμενες ιδιότητες όπως η συσχέτιση).
//!
//! Σημειώστε ότι οι χειριστές `&&` και `||` βραχυκυκλώματος, δηλαδή, αξιολογούν το δεύτερο τελεστέο τους μόνο εάν συμβάλλει στο αποτέλεσμα.Δεδομένου ότι αυτή η συμπεριφορά δεν είναι εφαρμόσιμη από τα traits, τα `&&` και `||` δεν υποστηρίζονται ως υπερφορτωμένοι χειριστές.
//!
//! Πολλοί από τους χειριστές παίρνουν τους τελεστές τους από αξία.Σε μη γενικά περιβάλλοντα που περιλαμβάνουν ενσωματωμένους τύπους, αυτό συνήθως δεν αποτελεί πρόβλημα.
//! Ωστόσο, η χρήση αυτών των τελεστών σε γενικό κώδικα, απαιτεί κάποια προσοχή εάν οι τιμές πρέπει να επαναχρησιμοποιηθούν σε αντίθεση με το να επιτρέπεται στους χειριστές να τις καταναλώνουν.Μία επιλογή είναι να χρησιμοποιείτε περιστασιακά το [`clone`].
//! Μια άλλη επιλογή είναι να βασιστείτε στους τύπους που εμπλέκονται παρέχοντας πρόσθετες εφαρμογές χειριστή για αναφορές.
//! Για παράδειγμα, για έναν τύπο χρήστη `T` που υποτίθεται ότι υποστηρίζει την προσθήκη, είναι πιθανώς καλή ιδέα να εφαρμόσετε και τα `T` και `&T` τα traits [`Add<T>`][`Add`] και [`Add<&T>`][`Add`] έτσι ώστε ο γενικός κώδικας να μπορεί να γραφτεί χωρίς περιττή κλωνοποίηση.
//!
//!
//! # Examples
//!
//! Αυτό το παράδειγμα δημιουργεί μια δομή `Point` που εφαρμόζει [`Add`] και [`Sub`] και, στη συνέχεια, δείχνει την προσθήκη και αφαίρεση δύο σημείων.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Δείτε την τεκμηρίωση για κάθε trait για παράδειγμα υλοποίησης.
//!
//! Τα [`Fn`], [`FnMut`] και [`FnOnce`] traits υλοποιούνται από τύπους που μπορούν να επικαλεστούν όπως συναρτήσεις.Σημειώστε ότι το [`Fn`] παίρνει το `&self`, το [`FnMut`] παίρνει το `&mut self` και το [`FnOnce`] παίρνει το `self`.
//! Αυτά αντιστοιχούν στα τρία είδη μεθόδων που μπορούν να επικαλεσθούν σε μια περίπτωση: κλήση ανά αναφορά, κλήση ανά μεταβλητή αναφορά και κλήση ανά αξία.
//! Η πιο συνηθισμένη χρήση αυτών των traits είναι να λειτουργεί ως όρια σε συναρτήσεις υψηλότερου επιπέδου που λειτουργούν ή κλείνουν ως επιχειρήματα.
//!
//! Λήψη ενός [`Fn`] ως παραμέτρου:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Λήψη ενός [`FnMut`] ως παραμέτρου:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Λήψη ενός [`FnOnce`] ως παραμέτρου:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` καταναλώνει τις καταγεγραμμένες μεταβλητές του, επομένως δεν μπορεί να εκτελεστεί περισσότερες από μία φορές
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Η απόπειρα επανάκλησης του `func()` θα προκαλέσει σφάλμα `use of moved value` για το `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` δεν μπορεί πλέον να γίνει επίκληση σε αυτό το σημείο
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;