/// Χρησιμοποιείται για ευρετηρίαση λειτουργιών (`container[index]`) σε αμετάβλητα περιβάλλοντα.
///
/// `container[index]` είναι στην πραγματικότητα συντακτική ζάχαρη για `*container.index(index)`, αλλά μόνο όταν χρησιμοποιείται ως αμετάβλητη τιμή.
/// Εάν ζητηθεί μια μεταβλητή τιμή, χρησιμοποιείται το [`IndexMut`].
/// Αυτό επιτρέπει ωραία πράγματα όπως το `let value = v[index]` εάν ο τύπος του `value` εφαρμόζει το [`Copy`].
///
/// # Examples
///
/// Το ακόλουθο παράδειγμα εφαρμόζει το `Index` σε ένα κοντέινερ `NucleotideCount` μόνο για ανάγνωση, επιτρέποντας την ανάκτηση μεμονωμένων μετρήσεων με σύνταξη ευρετηρίου.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// Ο τύπος που επιστράφηκε μετά την ευρετηρίαση.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// Εκτελεί τη λειτουργία ευρετηρίου (`container[index]`).
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// Χρησιμοποιείται για λειτουργίες ευρετηρίου (`container[index]`) σε μεταβλητά περιβάλλοντα.
///
/// `container[index]` είναι στην πραγματικότητα συντακτική ζάχαρη για `*container.index_mut(index)`, αλλά μόνο όταν χρησιμοποιείται ως μεταβλητή τιμή.
/// Εάν ζητηθεί μια αμετάβλητη τιμή, χρησιμοποιείται το [`Index`] trait.
/// Αυτό επιτρέπει ωραία πράγματα όπως το `v[index] = value`.
///
/// # Examples
///
/// Μια πολύ απλή εφαρμογή μιας δομής `Balance` που έχει δύο πλευρές, όπου κάθε μία μπορεί να ευρετηριαστεί ευμετάβλητα και αμετάβλητα.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // Σε αυτήν την περίπτωση, το `balance[Side::Right]` είναι ζάχαρη για το `*balance.index(Side::Right)`, καθώς διαβάζουμε μόνο*`balance[Side::Right]`, δεν το γράφουμε.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // Ωστόσο, σε αυτήν την περίπτωση το `balance[Side::Left]` είναι ζάχαρη για το `*balance.index_mut(Side::Left)`, καθώς γράφουμε το `balance[Side::Left]`.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// Εκτελεί τη μεταβλητή λειτουργία ευρετηρίου (`container[index]`).
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}