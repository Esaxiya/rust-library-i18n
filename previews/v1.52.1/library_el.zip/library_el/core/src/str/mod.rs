//! Χειρισμός συμβολοσειρών.
//!
//! Για περισσότερες λεπτομέρειες, ανατρέξτε στην ενότητα [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. εκτός ορίων
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. έναρξη <=τέλος
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. όριο χαρακτήρων
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // βρείτε τον χαρακτήρα
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` πρέπει να είναι μικρότερο από το len και ένα όριο
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Επιστρέφει το μήκος `self`.
    ///
    /// Αυτό το μήκος είναι σε byte, όχι [`char`] s ή γραφήματα.
    /// Με άλλα λόγια, μπορεί να μην είναι αυτό που ένας άνθρωπος θεωρεί το μήκος της χορδής.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // φανταχτερά!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Επιστρέφει το `true` εάν το `self` έχει μήκος μηδέν byte.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Ελέγχει ότι το «index`-th byte είναι το πρώτο byte σε μια ακολουθία κωδικού UTF-8 ή το τέλος της συμβολοσειράς.
    ///
    ///
    /// Η αρχή και το τέλος της συμβολοσειράς (όταν `index== self.len()`) θεωρούνται όρια).
    ///
    /// Επιστρέφει `false` εάν το `index` είναι μεγαλύτερο από `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // έναρξη του `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // δεύτερο byte του `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // τρίτο byte του `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 και ο Λεν είναι πάντα εντάξει.
        // Δοκιμάστε το 0 ρητά, ώστε να μπορεί να βελτιστοποιήσει τον έλεγχο εύκολα και να παραλείψει την ανάγνωση δεδομένων συμβολοσειράς για αυτήν την περίπτωση.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Αυτό είναι λίγο μαγικό ισοδύναμο με: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Μετατρέπει ένα κομμάτι συμβολοσειράς σε ένα κομμάτι byte.
    /// Για να μετατρέψετε το slice byte σε slice string, χρησιμοποιήστε τη συνάρτηση [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // ΑΣΦΑΛΕΙΑ: σταθερός ήχος επειδή μεταδίδουμε δύο τύπους με την ίδια διάταξη
        unsafe { mem::transmute(self) }
    }

    /// Μετατρέπει ένα μεταβλητό κομμάτι συμβολοσειράς σε ένα μεταβλητό κομμάτι byte.
    ///
    /// # Safety
    ///
    /// Ο καλών πρέπει να διασφαλίσει ότι το περιεχόμενο του slice είναι έγκυρο UTF-8 πριν από τη λήξη του δανεισμού και το υποκείμενο `str`.
    ///
    ///
    /// Η χρήση ενός `str` του οποίου το περιεχόμενο δεν είναι έγκυρο UTF-8 είναι απροσδιόριστη συμπεριφορά.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // ΑΣΦΑΛΕΙΑ: το cast από `&str` έως `&[u8]` είναι ασφαλές από το `str`
        // έχει την ίδια διάταξη με το `&[u8]` (μόνο το libstd μπορεί να κάνει αυτήν την εγγύηση).
        // Το dereference του δείκτη είναι ασφαλές δεδομένου ότι προέρχεται από μια μεταβλητή αναφορά που είναι εγγυημένη ότι είναι έγκυρη για εγγραφές.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Μετατρέπει ένα κομμάτι συμβολοσειράς σε έναν ακατέργαστο δείκτη.
    ///
    /// Καθώς οι φέτες συμβολοσειράς είναι ένα κομμάτι byte, ο ακατέργαστος δείκτης δείχνει ένα [`u8`].
    /// Αυτός ο δείκτης θα δείχνει το πρώτο byte του slice string.
    ///
    /// Ο καλών πρέπει να διασφαλίσει ότι ο επιστρεφόμενος δείκτης δεν γράφεται ποτέ.
    /// Εάν πρέπει να μεταλλάξετε τα περιεχόμενα του slice string, χρησιμοποιήστε το [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Μετατρέπει ένα μεταβλητό κομμάτι συμβολοσειράς σε ακατέργαστο δείκτη.
    ///
    /// Καθώς οι φέτες συμβολοσειράς είναι ένα κομμάτι byte, ο ακατέργαστος δείκτης δείχνει ένα [`u8`].
    /// Αυτός ο δείκτης θα δείχνει το πρώτο byte του slice string.
    ///
    /// Είναι δική σας ευθύνη να βεβαιωθείτε ότι το κομμάτι χορδών τροποποιείται μόνο με τρόπο που παραμένει έγκυρο UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Επιστρέφει ένα υποσύνολο `str`.
    ///
    /// Αυτή είναι η εναλλακτική λύση για την ευρετηρίαση του `str`.
    /// Επιστρέφει [`None`] όποτε ισοδύναμη λειτουργία ευρετηρίασης θα panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // δείκτες όχι στα όρια ακολουθίας UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // εκτός ορίων
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Επιστρέφει ένα μεταβλητό υποσύνολο `str`.
    ///
    /// Αυτή είναι η εναλλακτική λύση για την ευρετηρίαση του `str`.
    /// Επιστρέφει [`None`] όποτε ισοδύναμη λειτουργία ευρετηρίασης θα panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // σωστό μήκος
    /// assert!(v.get_mut(0..5).is_some());
    /// // εκτός ορίων
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Επιστρέφει ένα μη ελεγμένο υποσύνολο `str`.
    ///
    /// Αυτή είναι η ανεξέλεγκτη εναλλακτική λύση για την ευρετηρίαση του `str`.
    ///
    /// # Safety
    ///
    /// Οι καλούντες αυτής της λειτουργίας είναι υπεύθυνοι ότι πληρούνται αυτές οι προϋποθέσεις:
    ///
    /// * Ο αρχικός δείκτης δεν πρέπει να υπερβαίνει τον τελικό δείκτη.
    /// * Τα ευρετήρια πρέπει να βρίσκονται εντός των ορίων του αρχικού τμήματος.
    /// * Τα ευρετήρια πρέπει να βρίσκονται στα όρια της ακολουθίας UTF-8.
    ///
    /// Σε αντίθετη περίπτωση, το επιστρεφόμενο κομμάτι συμβολοσειράς ενδέχεται να αναφέρεται σε μη έγκυρη μνήμη ή να παραβιάζει τα αναλλοίωτα που κοινοποιούνται από τον τύπο `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να τηρεί τη σύμβαση ασφαλείας για το `get_unchecked`.
        // η φέτα δεν μπορεί να αναφερθεί επειδή το `self` είναι μια ασφαλής αναφορά.
        // Ο επιστρεφόμενος δείκτης είναι ασφαλής, επειδή οι ενσωματώσεις του `SliceIndex` πρέπει να εγγυηθούν ότι είναι.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Επιστρέφει ένα μεταβλητό, μη ελεγμένο υποσύνολο του `str`.
    ///
    /// Αυτή είναι η ανεξέλεγκτη εναλλακτική λύση για την ευρετηρίαση του `str`.
    ///
    /// # Safety
    ///
    /// Οι καλούντες αυτής της λειτουργίας είναι υπεύθυνοι ότι πληρούνται αυτές οι προϋποθέσεις:
    ///
    /// * Ο αρχικός δείκτης δεν πρέπει να υπερβαίνει τον τελικό δείκτη.
    /// * Τα ευρετήρια πρέπει να βρίσκονται εντός των ορίων του αρχικού τμήματος.
    /// * Τα ευρετήρια πρέπει να βρίσκονται στα όρια της ακολουθίας UTF-8.
    ///
    /// Σε αντίθετη περίπτωση, το επιστρεφόμενο κομμάτι συμβολοσειράς ενδέχεται να αναφέρεται σε μη έγκυρη μνήμη ή να παραβιάζει τα αναλλοίωτα που κοινοποιούνται από τον τύπο `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να τηρεί τη σύμβαση ασφαλείας για το `get_unchecked_mut`.
        // η φέτα δεν μπορεί να αναφερθεί επειδή το `self` είναι μια ασφαλής αναφορά.
        // Ο επιστρεφόμενος δείκτης είναι ασφαλής, επειδή οι ενσωματώσεις του `SliceIndex` πρέπει να εγγυηθούν ότι είναι.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Δημιουργεί ένα κομμάτι συμβολοσειράς από άλλο κομμάτι συμβολοσειράς, παρακάμπτοντας τους ελέγχους ασφαλείας.
    ///
    /// Αυτό γενικά δεν συνιστάται, χρησιμοποιήστε με προσοχή!Για μια ασφαλή εναλλακτική λύση, δείτε [`str`] και [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Αυτό το νέο κομμάτι πηγαίνει από `begin` έως `end`, συμπεριλαμβανομένου του `begin` αλλά εξαιρουμένου του `end`.
    ///
    /// Για να λάβετε ένα μεταβλητό κομμάτι συμβολοσειράς, δείτε τη μέθοδο [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Οι καλούντες αυτής της λειτουργίας είναι υπεύθυνοι για την ικανοποίηση τριών προϋποθέσεων:
    ///
    /// * `begin` δεν πρέπει να υπερβαίνει το `end`.
    /// * `begin` και το `end` πρέπει να είναι θέσεις byte εντός του slice string.
    /// * `begin` και το `end` πρέπει να βρίσκεται στα όρια της ακολουθίας UTF-8.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να τηρεί τη σύμβαση ασφαλείας για το `get_unchecked`.
        // η φέτα δεν μπορεί να αναφερθεί επειδή το `self` είναι μια ασφαλής αναφορά.
        // Ο επιστρεφόμενος δείκτης είναι ασφαλής, επειδή οι ενσωματώσεις του `SliceIndex` πρέπει να εγγυηθούν ότι είναι.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Δημιουργεί ένα κομμάτι συμβολοσειράς από άλλο κομμάτι συμβολοσειράς, παρακάμπτοντας τους ελέγχους ασφαλείας.
    /// Αυτό γενικά δεν συνιστάται, χρησιμοποιήστε με προσοχή!Για μια ασφαλή εναλλακτική λύση, δείτε [`str`] και [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Αυτό το νέο κομμάτι πηγαίνει από `begin` έως `end`, συμπεριλαμβανομένου του `begin` αλλά εξαιρουμένου του `end`.
    ///
    /// Για να λάβετε ένα αμετάβλητο κομμάτι συμβολοσειράς, δείτε τη μέθοδο [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Οι καλούντες αυτής της λειτουργίας είναι υπεύθυνοι για την ικανοποίηση τριών προϋποθέσεων:
    ///
    /// * `begin` δεν πρέπει να υπερβαίνει το `end`.
    /// * `begin` και το `end` πρέπει να είναι θέσεις byte εντός του slice string.
    /// * `begin` και το `end` πρέπει να βρίσκεται στα όρια της ακολουθίας UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να τηρεί τη σύμβαση ασφαλείας για το `get_unchecked_mut`.
        // η φέτα δεν μπορεί να αναφερθεί επειδή το `self` είναι μια ασφαλής αναφορά.
        // Ο επιστρεφόμενος δείκτης είναι ασφαλής, επειδή οι ενσωματώσεις του `SliceIndex` πρέπει να εγγυηθούν ότι είναι.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Χωρίστε ένα κομμάτι χορδών σε δύο σε ένα ευρετήριο.
    ///
    /// Το όρισμα, `mid`, πρέπει να είναι ένα byte από την αρχή της συμβολοσειράς.
    /// Πρέπει επίσης να βρίσκεται στο όριο ενός σημείου κώδικα UTF-8.
    ///
    /// Οι δύο φέτες που επέστρεψαν ξεκινούν από την αρχή της χορδής σε `mid` και από `mid` έως το τέλος της χορδής.
    ///
    /// Για να λάβετε μεταβλητές φέτες συμβολοσειράς, ανατρέξτε στη μέθοδο [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics εάν το `mid` δεν βρίσκεται σε όριο σημείου κώδικα UTF-8 ή εάν έχει περάσει από το τέλος του τελευταίου σημείου κώδικα του slice string.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary ελέγχει ότι το ευρετήριο βρίσκεται στο [0, .len()]
        if self.is_char_boundary(mid) {
            // ΑΣΦΑΛΕΙΑ: μόλις ελέγξατε ότι το `mid` βρίσκεται σε όριο char.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Χωρίστε ένα μεταβλητό κομμάτι συμβολοσειράς σε δύο σε ένα ευρετήριο.
    ///
    /// Το όρισμα, `mid`, πρέπει να είναι ένα byte από την αρχή της συμβολοσειράς.
    /// Πρέπει επίσης να βρίσκεται στο όριο ενός σημείου κώδικα UTF-8.
    ///
    /// Οι δύο φέτες που επέστρεψαν ξεκινούν από την αρχή της χορδής σε `mid` και από `mid` έως το τέλος της χορδής.
    ///
    /// Για να λάβετε αμετάβλητες φέτες συμβολοσειράς, ανατρέξτε στη μέθοδο [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics εάν το `mid` δεν βρίσκεται σε όριο σημείου κώδικα UTF-8 ή εάν έχει περάσει από το τέλος του τελευταίου σημείου κώδικα του slice string.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary ελέγχει ότι το ευρετήριο βρίσκεται στο [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // ΑΣΦΑΛΕΙΑ: μόλις ελέγξατε ότι το `mid` βρίσκεται σε όριο char.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Επιστρέφει έναν επαναληπτικό πάνω από τα [`char`] του slice string.
    ///
    /// Επειδή ένα slice string αποτελείται από έγκυρο UTF-8, μπορούμε να επαναλάβουμε μέσω ενός string string από το [`char`].
    /// Αυτή η μέθοδος επιστρέφει έναν τέτοιο επαναληπτικό.
    ///
    /// Είναι σημαντικό να θυμάστε ότι το [`char`] αντιπροσωπεύει μια κλιματική τιμή Unicode και ενδέχεται να μην ταιριάζει με την ιδέα σας για το τι είναι το 'character'.
    ///
    /// Η επανάληψη των συστάδων γραφικών μπορεί να είναι αυτό που πραγματικά θέλετε.
    /// Αυτή η λειτουργικότητα δεν παρέχεται από την τυπική βιβλιοθήκη του Rust, ελέγξτε το crates.io.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Θυμηθείτε, οι χαρακτήρες [`char`] ενδέχεται να μην ταιριάζουν με τη διαίσθησή σας σχετικά με τους χαρακτήρες:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // όχι 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Επιστρέφει έναν επαναληπτικό πάνω από τα [`char`] του slice string και τις θέσεις τους.
    ///
    /// Επειδή ένα slice string αποτελείται από έγκυρο UTF-8, μπορούμε να επαναλάβουμε μέσω ενός string string από το [`char`].
    /// Αυτή η μέθοδος επιστρέφει έναν επαναληπτικό και των δύο [`char`] s, καθώς και των θέσεων byte τους.
    ///
    /// Ο επαναληπτής παράγει πλειάδες.Η θέση είναι πρώτη, η [`char`] είναι δεύτερη.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Θυμηθείτε, οι χαρακτήρες [`char`] ενδέχεται να μην ταιριάζουν με τη διαίσθησή σας σχετικά με τους χαρακτήρες:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // όχι (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // σημειώστε τα 3 εδώ, ο τελευταίος χαρακτήρας πήρε δύο byte
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Επανάληψη πάνω από τα bytes μιας φέτα συμβολοσειράς.
    ///
    /// Δεδομένου ότι ένα κομμάτι συμβολοσειράς αποτελείται από μια ακολουθία byte, μπορούμε να επαναλάβουμε ένα κομμάτι συμβολοσειράς ανά byte.
    /// Αυτή η μέθοδος επιστρέφει έναν τέτοιο επαναληπτικό.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Διαχωρίζει ένα κομμάτι συμβολοσειράς ανά κενό διάστημα.
    ///
    /// Ο επαναληπτικός που επιστρέφεται θα επιστρέψει τμήματα συμβολοσειράς που είναι υπο-φέτες του αρχικού τμήματος συμβολοσειράς, διαχωρισμένα με οποιοδήποτε κενό διάστημα.
    ///
    ///
    /// 'Whitespace' ορίζεται σύμφωνα με τους όρους του Unicode Derived Core Property `White_Space`.
    /// Αν θέλετε μόνο να χωρίσετε σε κενό διάστημα ASCII, χρησιμοποιήστε το [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Λαμβάνονται υπόψη όλα τα είδη κενού χώρου:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Διαχωρίζει ένα κομμάτι συμβολοσειράς από το κενό διάστημα ASCII.
    ///
    /// Ο επαναληπτικός που επιστρέφεται θα επιστρέψει φέτες συμβολοσειράς που είναι υπο-φέτες του αρχικού τμήματος συμβολοσειράς, διαχωρισμένες με οποιοδήποτε κενό διάστημα ASCII.
    ///
    ///
    /// Για να διαχωρίσετε από το Unicode `Whitespace` αντ 'αυτού, χρησιμοποιήστε το [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Λαμβάνονται υπόψη όλα τα είδη διαστήματος ASCII:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Ένας επαναληπτής πάνω από τις γραμμές μιας συμβολοσειράς, ως φέτες συμβολοσειράς.
    ///
    /// Οι γραμμές τερματίζονται είτε με νέα γραμμή (`\n`) είτε με επιστροφή μεταφοράς με γραμμή τροφοδοσίας (`\r\n`).
    ///
    /// Το τελικό τέλος της γραμμής είναι προαιρετικό.
    /// Μια συμβολοσειρά που τελειώνει με τελική γραμμή που τελειώνει θα επιστρέψει τις ίδιες γραμμές με μια κατά τα άλλα πανομοιότυπη συμβολοσειρά χωρίς τελική γραμμή.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Δεν απαιτείται τελική γραμμή:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Επανάληψη πάνω από τις γραμμές μιας συμβολοσειράς.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Επιστρέφει έναν επαναληπτικό `u16` πάνω από τη συμβολοσειρά που κωδικοποιείται ως UTF-16.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Επιστρέφει το `true` εάν το δεδομένο μοτίβο ταιριάζει με ένα δευτερεύον κομμάτι αυτού του slice string.
    ///
    /// Επιστρέφει `false` εάν δεν το κάνει.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Επιστρέφει `true` εάν το δεδομένο μοτίβο ταιριάζει με ένα πρόθεμα αυτού του slice string.
    ///
    /// Επιστρέφει `false` εάν δεν το κάνει.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Επιστρέφει `true` εάν το δεδομένο μοτίβο ταιριάζει με ένα επίθημα αυτού του τμήματος συμβολοσειράς.
    ///
    /// Επιστρέφει `false` εάν δεν το κάνει.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Επιστρέφει το ευρετήριο byte του πρώτου χαρακτήρα αυτού του slice string που ταιριάζει με το μοτίβο.
    ///
    /// Επιστρέφει [`None`] εάν το μοτίβο δεν ταιριάζει.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Απλά μοτίβα:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Πιο σύνθετα μοτίβα με στυλ και σημεία κλεισίματος χωρίς σημεία:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Δεν βρίσκω το μοτίβο:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Επιστρέφει το ευρετήριο byte για τον πρώτο χαρακτήρα της πιο δεξιάς αντιστοίχισης του μοτίβου σε αυτό το κομμάτι συμβολοσειράς.
    ///
    /// Επιστρέφει [`None`] εάν το μοτίβο δεν ταιριάζει.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Απλά μοτίβα:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Πιο περίπλοκα μοτίβα με κλείσιμο:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Δεν βρίσκω το μοτίβο:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Ένας επαναληπτικός χαρακτήρας πάνω από τα υποστρώματα αυτού του τμήματος συμβολοσειράς, διαχωρισμένο με χαρακτήρες που ταιριάζουν με ένα μοτίβο.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Επαναληπτική συμπεριφορά
    ///
    /// Ο επαναλαμβανόμενος επαναληπτής θα είναι [`DoubleEndedIterator`] εάν το μοτίβο επιτρέπει μια αντίστροφη αναζήτηση και η αναζήτηση forward/reverse αποδίδει τα ίδια στοιχεία.
    /// Αυτό ισχύει για, π.χ., [`char`], αλλά όχι για `&str`.
    ///
    /// Εάν το μοτίβο επιτρέπει μια αντίστροφη αναζήτηση, αλλά τα αποτελέσματά του ενδέχεται να διαφέρουν από μια αναζήτηση προς τα εμπρός, μπορεί να χρησιμοποιηθεί η μέθοδος [`rsplit`].
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Απλά μοτίβα:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Εάν το μοτίβο είναι ένα κομμάτι χαρακτήρων, χωρίστε σε κάθε εμφάνιση οποιουδήποτε από τους χαρακτήρες:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Ένα πιο περίπλοκο μοτίβο, χρησιμοποιώντας ένα κλείσιμο:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Εάν μια συμβολοσειρά περιέχει πολλούς συνεχόμενους διαχωριστές, θα καταλήξετε με κενές συμβολοσειρές στην έξοδο:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Τα συνεχόμενα διαχωριστικά διαχωρίζονται από την κενή συμβολοσειρά.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Οι διαχωριστές στην αρχή ή στο τέλος μιας συμβολοσειράς γειτονεύουν με κενές χορδές.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Όταν η κενή συμβολοσειρά χρησιμοποιείται ως διαχωριστικό, διαχωρίζει κάθε χαρακτήρα στη συμβολοσειρά, μαζί με την αρχή και το τέλος της συμβολοσειράς.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Οι συνεχόμενοι διαχωριστές μπορούν να οδηγήσουν σε πιθανή εκπληκτική συμπεριφορά όταν το κενό διάστημα χρησιμοποιείται ως διαχωριστικό.Αυτός ο κωδικός είναι σωστός:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Σας δίνει το _not_:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Χρησιμοποιήστε το [`split_whitespace`] για αυτήν τη συμπεριφορά.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Ένας επαναληπτικός χαρακτήρας πάνω από τα υποστρώματα αυτού του τμήματος συμβολοσειράς, διαχωρισμένο με χαρακτήρες που ταιριάζουν με ένα μοτίβο.
    /// Διαφέρει από την επανάληψη που παράγεται από το `split` στο ότι το `split_inclusive` αφήνει το αντιστοιχισμένο μέρος ως τερματιστή του υποστρώματος.
    ///
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Εάν το τελευταίο στοιχείο της συμβολοσειράς ταιριάζει, αυτό το στοιχείο θα θεωρείται ο τερματιστής του προηγούμενου υποστρώματος.
    /// Αυτό το substring θα είναι το τελευταίο στοιχείο που θα επιστραφεί από τον επαναληπτή.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Ένας επαναληπτικός χαρακτήρας πάνω από τα υποστρώματα του δεδομένου τμήματος συμβολοσειράς, διαχωρίζεται από χαρακτήρες που ταιριάζουν με ένα μοτίβο και αποδίδεται με αντίστροφη σειρά.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Επαναληπτική συμπεριφορά
    ///
    /// Ο επαναλαμβανόμενος επαναληπτής απαιτεί το μοτίβο να υποστηρίζει μια αντίστροφη αναζήτηση και θα είναι [`DoubleEndedIterator`] εάν μια αναζήτηση forward/reverse αποδίδει τα ίδια στοιχεία.
    ///
    ///
    /// Για επανάληψη από μπροστά, μπορεί να χρησιμοποιηθεί η μέθοδος [`split`].
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Απλά μοτίβα:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Ένα πιο περίπλοκο μοτίβο, χρησιμοποιώντας ένα κλείσιμο:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Ένας επαναληπτικός χαρακτήρας πάνω από τα υποστρώματα του δεδομένου τμήματος συμβολοσειράς, διαχωρισμένο με χαρακτήρες που ταιριάζουν με ένα σχέδιο
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ισοδύναμο με [`split`], εκτός από το ότι το υπόστρωμα που ακολουθεί παραλείπεται εάν είναι κενό.
    ///
    /// [`split`]: str::split
    ///
    /// Αυτή η μέθοδος μπορεί να χρησιμοποιηθεί για δεδομένα συμβολοσειράς που είναι _terminated_, αντί για _separated_ από ένα μοτίβο.
    ///
    /// # Επαναληπτική συμπεριφορά
    ///
    /// Ο επαναλαμβανόμενος επαναληπτής θα είναι [`DoubleEndedIterator`] εάν το μοτίβο επιτρέπει μια αντίστροφη αναζήτηση και η αναζήτηση forward/reverse αποδίδει τα ίδια στοιχεία.
    /// Αυτό ισχύει για, π.χ., [`char`], αλλά όχι για `&str`.
    ///
    /// Εάν το μοτίβο επιτρέπει μια αντίστροφη αναζήτηση, αλλά τα αποτελέσματά του ενδέχεται να διαφέρουν από μια αναζήτηση προς τα εμπρός, μπορεί να χρησιμοποιηθεί η μέθοδος [`rsplit_terminator`].
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Ένα επαναληπτικό πάνω από τα υποστρώματα του `self`, διαχωρισμένο με χαρακτήρες που ταιριάζουν με ένα μοτίβο και αποδίδεται με αντίστροφη σειρά.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ισοδύναμο με [`split`], εκτός από το ότι το υπόστρωμα που ακολουθεί παραλείπεται εάν είναι κενό.
    ///
    /// [`split`]: str::split
    ///
    /// Αυτή η μέθοδος μπορεί να χρησιμοποιηθεί για δεδομένα συμβολοσειράς που είναι _terminated_, αντί για _separated_ από ένα μοτίβο.
    ///
    /// # Επαναληπτική συμπεριφορά
    ///
    /// Ο επαναλαμβανόμενος επαναληπτής απαιτεί το μοτίβο να υποστηρίζει μια αντίστροφη αναζήτηση και θα έχει διπλό τέλος εάν μια αναζήτηση forward/reverse αποφέρει τα ίδια στοιχεία.
    ///
    ///
    /// Για επανάληψη από μπροστά, μπορεί να χρησιμοποιηθεί η μέθοδος [`split_terminator`].
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Ένας επαναληπτικός χαρακτήρας πάνω από τα υποστρώματα του δεδομένου τμήματος συμβολοσειράς, διαχωρισμένο με ένα μοτίβο, περιορίζεται στην επιστροφή στα περισσότερα αντικείμενα `n`.
    ///
    /// Εάν επιστραφούν τα υποστρώματα `n`, το τελευταίο υπόστρωμα (το «n`th substring) θα περιέχει το υπόλοιπο της συμβολοσειράς.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Επαναληπτική συμπεριφορά
    ///
    /// Ο επαναλαμβανόμενος επαναληπτής δεν θα έχει διπλό τέλος, επειδή δεν είναι αποτελεσματικό να υποστηρίζεται.
    ///
    /// Εάν το μοτίβο επιτρέπει μια αντίστροφη αναζήτηση, μπορεί να χρησιμοποιηθεί η μέθοδος [`rsplitn`].
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Απλά μοτίβα:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Ένα πιο περίπλοκο μοτίβο, χρησιμοποιώντας ένα κλείσιμο:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Ένας επαναληπτικός χαρακτήρας πάνω από τα υποστρώματα αυτού του τμήματος συμβολοσειράς, διαχωρισμένο με ένα μοτίβο, ξεκινώντας από το τέλος της συμβολοσειράς, περιορίζεται στην επιστροφή στα περισσότερα αντικείμενα `n`.
    ///
    ///
    /// Εάν επιστραφούν τα υποστρώματα `n`, το τελευταίο υπόστρωμα (το «n`th substring) θα περιέχει το υπόλοιπο της συμβολοσειράς.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Επαναληπτική συμπεριφορά
    ///
    /// Ο επαναλαμβανόμενος επαναληπτής δεν θα έχει διπλό τέλος, επειδή δεν είναι αποτελεσματικό να υποστηρίζεται.
    ///
    /// Για χωρισμό από μπροστά, μπορεί να χρησιμοποιηθεί η μέθοδος [`splitn`].
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Απλά μοτίβα:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Ένα πιο περίπλοκο μοτίβο, χρησιμοποιώντας ένα κλείσιμο:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Διαχωρίζει τη συμβολοσειρά στην πρώτη εμφάνιση του καθορισμένου οριοθέτη και επιστρέφει το πρόθεμα πριν από τον οριοθέτη και το επίθημα μετά τον οριοθέτη.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Διαχωρίζει τη συμβολοσειρά στην τελευταία εμφάνιση του καθορισμένου οριοθέτη και επιστρέφει το πρόθεμα πριν από τον οριοθέτη και το επίθημα μετά τον οριοθέτη.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Ένας επαναληπτής πάνω από τους αποσυνδεδεμένους αγώνες ενός μοτίβου εντός της δεδομένης φέτα συμβολοσειράς.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Επαναληπτική συμπεριφορά
    ///
    /// Ο επαναλαμβανόμενος επαναληπτής θα είναι [`DoubleEndedIterator`] εάν το μοτίβο επιτρέπει μια αντίστροφη αναζήτηση και η αναζήτηση forward/reverse αποδίδει τα ίδια στοιχεία.
    /// Αυτό ισχύει για, π.χ., [`char`], αλλά όχι για `&str`.
    ///
    /// Εάν το μοτίβο επιτρέπει μια αντίστροφη αναζήτηση, αλλά τα αποτελέσματά του ενδέχεται να διαφέρουν από μια αναζήτηση προς τα εμπρός, μπορεί να χρησιμοποιηθεί η μέθοδος [`rmatches`].
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Ένας επαναληπτής πάνω από τους αποσυνδεδεμένους αγώνες ενός μοτίβου σε αυτό το κομμάτι συμβολοσειράς, αποδόθηκε με αντίστροφη σειρά.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Επαναληπτική συμπεριφορά
    ///
    /// Ο επαναλαμβανόμενος επαναληπτής απαιτεί το μοτίβο να υποστηρίζει μια αντίστροφη αναζήτηση και θα είναι [`DoubleEndedIterator`] εάν μια αναζήτηση forward/reverse αποδίδει τα ίδια στοιχεία.
    ///
    ///
    /// Για επανάληψη από μπροστά, μπορεί να χρησιμοποιηθεί η μέθοδος [`matches`].
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Ένας επαναληπτής για τους διαχωρισμένους αγώνες ενός μοτίβου σε αυτό το κομμάτι συμβολοσειράς, καθώς και το ευρετήριο από το οποίο ξεκινά η αντιστοίχιση.
    ///
    /// Για αγώνες `pat` εντός `self` που επικαλύπτονται, επιστρέφονται μόνο οι δείκτες που αντιστοιχούν στον πρώτο αγώνα.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Επαναληπτική συμπεριφορά
    ///
    /// Ο επαναλαμβανόμενος επαναληπτής θα είναι [`DoubleEndedIterator`] εάν το μοτίβο επιτρέπει μια αντίστροφη αναζήτηση και η αναζήτηση forward/reverse αποδίδει τα ίδια στοιχεία.
    /// Αυτό ισχύει για, π.χ., [`char`], αλλά όχι για `&str`.
    ///
    /// Εάν το μοτίβο επιτρέπει μια αντίστροφη αναζήτηση, αλλά τα αποτελέσματά του ενδέχεται να διαφέρουν από μια αναζήτηση προς τα εμπρός, μπορεί να χρησιμοποιηθεί η μέθοδος [`rmatch_indices`].
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // μόνο το πρώτο `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Ένας επαναληπτής για τους διαχωρισμένους αγώνες ενός μοτίβου εντός `self`, αποδόθηκε σε αντίστροφη σειρά μαζί με το ευρετήριο του αγώνα.
    ///
    /// Για αγώνες `pat` εντός `self` που επικαλύπτονται, επιστρέφονται μόνο οι δείκτες που αντιστοιχούν στον τελευταίο αγώνα.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Επαναληπτική συμπεριφορά
    ///
    /// Ο επαναλαμβανόμενος επαναληπτής απαιτεί το μοτίβο να υποστηρίζει μια αντίστροφη αναζήτηση και θα είναι [`DoubleEndedIterator`] εάν μια αναζήτηση forward/reverse αποδίδει τα ίδια στοιχεία.
    ///
    ///
    /// Για επανάληψη από μπροστά, μπορεί να χρησιμοποιηθεί η μέθοδος [`match_indices`].
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // μόνο το τελευταίο `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Επιστρέφει ένα κομμάτι συμβολοσειράς με αφαιρεμένο το κεντρικό και το κενό διάστημα.
    ///
    /// 'Whitespace' ορίζεται σύμφωνα με τους όρους του Unicode Derived Core Property `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Επιστρέφει ένα κομμάτι συμβολοσειράς με αφαιρεμένο το κεντρικό κενό διάστημα.
    ///
    /// 'Whitespace' ορίζεται σύμφωνα με τους όρους του Unicode Derived Core Property `White_Space`.
    ///
    /// # Κατευθυντικότητα του κειμένου
    ///
    /// Μια συμβολοσειρά είναι μια ακολουθία byte.
    /// `start` σε αυτό το πλαίσιο σημαίνει την πρώτη θέση αυτής της συμβολοσειράς byte.Για μια γλώσσα από αριστερά προς τα δεξιά όπως τα Αγγλικά ή τα Ρωσικά, αυτή θα είναι αριστερή και για τις γλώσσες από τα δεξιά προς τα αριστερά όπως τα Αραβικά ή τα Εβραϊκά, αυτή θα είναι η δεξιά πλευρά.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Επιστρέφει ένα κομμάτι συμβολοσειράς με το κενό διάστημα που έχει αφαιρεθεί.
    ///
    /// 'Whitespace' ορίζεται σύμφωνα με τους όρους του Unicode Derived Core Property `White_Space`.
    ///
    /// # Κατευθυντικότητα του κειμένου
    ///
    /// Μια συμβολοσειρά είναι μια ακολουθία byte.
    /// `end` σε αυτό το πλαίσιο σημαίνει την τελευταία θέση αυτής της συμβολοσειράς byte.Για μια γλώσσα από αριστερά προς τα δεξιά όπως τα Αγγλικά ή τα Ρωσικά, αυτή θα είναι η δεξιά πλευρά και για τις γλώσσες από τα δεξιά προς τα αριστερά όπως τα Αραβικά ή τα Εβραϊκά, αυτή θα είναι η αριστερή πλευρά.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Επιστρέφει ένα κομμάτι συμβολοσειράς με αφαιρεμένο το κεντρικό κενό διάστημα.
    ///
    /// 'Whitespace' ορίζεται σύμφωνα με τους όρους του Unicode Derived Core Property `White_Space`.
    ///
    /// # Κατευθυντικότητα του κειμένου
    ///
    /// Μια συμβολοσειρά είναι μια ακολουθία byte.
    /// 'Left' σε αυτό το πλαίσιο σημαίνει την πρώτη θέση αυτής της συμβολοσειράς byte.για μια γλώσσα όπως τα Αραβικά ή τα Εβραϊκά που είναι «δεξιά προς τα αριστερά» και όχι «αριστερά προς τα δεξιά», αυτή θα είναι η πλευρά _right_ και όχι η αριστερή.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Επιστρέφει ένα κομμάτι συμβολοσειράς με το κενό διάστημα που έχει αφαιρεθεί.
    ///
    /// 'Whitespace' ορίζεται σύμφωνα με τους όρους του Unicode Derived Core Property `White_Space`.
    ///
    /// # Κατευθυντικότητα του κειμένου
    ///
    /// Μια συμβολοσειρά είναι μια ακολουθία byte.
    /// 'Right' σε αυτό το πλαίσιο σημαίνει την τελευταία θέση αυτής της συμβολοσειράς byte.για μια γλώσσα όπως τα Αραβικά ή τα Εβραϊκά που είναι «δεξιά προς τα αριστερά» και όχι «αριστερά προς τα δεξιά», αυτή θα είναι η πλευρά _left_ και όχι η δεξιά.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Επιστρέφει ένα κομμάτι συμβολοσειράς με όλα τα προθέματα και τα επίθημα που ταιριάζουν με ένα μοτίβο που καταργήθηκε επανειλημμένα.
    ///
    /// Το [pattern] μπορεί να είναι ένα [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Απλά μοτίβα:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Ένα πιο περίπλοκο μοτίβο, χρησιμοποιώντας ένα κλείσιμο:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Θυμηθείτε τον πιο γνωστό αγώνα, διορθώστε τον παρακάτω εάν
            // το τελευταίο παιχνίδι είναι διαφορετικό
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ΑΣΦΑΛΕΙΑ: Το `Searcher` είναι γνωστό ότι επιστρέφει έγκυρους δείκτες.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Επιστρέφει ένα κομμάτι συμβολοσειράς με όλα τα προθέματα που ταιριάζουν με ένα μοτίβο που καταργήθηκε επανειλημμένα.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Κατευθυντικότητα του κειμένου
    ///
    /// Μια συμβολοσειρά είναι μια ακολουθία byte.
    /// `start` σε αυτό το πλαίσιο σημαίνει την πρώτη θέση αυτής της συμβολοσειράς byte.Για μια γλώσσα από αριστερά προς τα δεξιά όπως τα Αγγλικά ή τα Ρωσικά, αυτή θα είναι αριστερή και για τις γλώσσες από τα δεξιά προς τα αριστερά όπως τα Αραβικά ή τα Εβραϊκά, αυτή θα είναι η δεξιά πλευρά.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // ΑΣΦΑΛΕΙΑ: Το `Searcher` είναι γνωστό ότι επιστρέφει έγκυρους δείκτες.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Επιστρέφει ένα κομμάτι συμβολοσειράς με το πρόθεμα αφαιρεμένο.
    ///
    /// Εάν η συμβολοσειρά ξεκινά με το μοτίβο `prefix`, επιστρέφει το substring μετά το πρόθεμα, τυλιγμένο σε `Some`.
    /// Σε αντίθεση με το `trim_start_matches`, αυτή η μέθοδος αφαιρεί το πρόθεμα ακριβώς μία φορά.
    ///
    /// Εάν η συμβολοσειρά δεν ξεκινά με `prefix`, επιστρέφει το `None`.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Επιστρέφει ένα κομμάτι συμβολοσειράς με το επίθημα αφαιρεμένο.
    ///
    /// Εάν η συμβολοσειρά τελειώσει με το μοτίβο `suffix`, επιστρέφει το υπόστρωμα πριν από το επίθημα, τυλιγμένο σε `Some`.
    /// Σε αντίθεση με το `trim_end_matches`, αυτή η μέθοδος αφαιρεί το επίθημα ακριβώς μία φορά.
    ///
    /// Εάν η συμβολοσειρά δεν τελειώνει με `suffix`, επιστρέφει το `None`.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Επιστρέφει ένα κομμάτι συμβολοσειράς με όλα τα επίθημα που ταιριάζουν με ένα μοτίβο που καταργήθηκε επανειλημμένα.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Κατευθυντικότητα του κειμένου
    ///
    /// Μια συμβολοσειρά είναι μια ακολουθία byte.
    /// `end` σε αυτό το πλαίσιο σημαίνει την τελευταία θέση αυτής της συμβολοσειράς byte.Για μια γλώσσα από αριστερά προς τα δεξιά όπως τα Αγγλικά ή τα Ρωσικά, αυτή θα είναι η δεξιά πλευρά και για τις γλώσσες από τα δεξιά προς τα αριστερά όπως τα Αραβικά ή τα Εβραϊκά, αυτή θα είναι η αριστερή πλευρά.
    ///
    ///
    /// # Examples
    ///
    /// Απλά μοτίβα:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Ένα πιο περίπλοκο μοτίβο, χρησιμοποιώντας ένα κλείσιμο:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ΑΣΦΑΛΕΙΑ: Το `Searcher` είναι γνωστό ότι επιστρέφει έγκυρους δείκτες.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Επιστρέφει ένα κομμάτι συμβολοσειράς με όλα τα προθέματα που ταιριάζουν με ένα μοτίβο που καταργήθηκε επανειλημμένα.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Κατευθυντικότητα του κειμένου
    ///
    /// Μια συμβολοσειρά είναι μια ακολουθία byte.
    /// 'Left' σε αυτό το πλαίσιο σημαίνει την πρώτη θέση αυτής της συμβολοσειράς byte.για μια γλώσσα όπως τα Αραβικά ή τα Εβραϊκά που είναι «δεξιά προς τα αριστερά» και όχι «αριστερά προς τα δεξιά», αυτή θα είναι η πλευρά _right_ και όχι η αριστερή.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Επιστρέφει ένα κομμάτι συμβολοσειράς με όλα τα επίθημα που ταιριάζουν με ένα μοτίβο που καταργήθηκε επανειλημμένα.
    ///
    /// Το [pattern] μπορεί να είναι ένα `&str`, [`char`], ένα κομμάτι [`char`] s, ή μια συνάρτηση ή κλείσιμο που καθορίζει εάν ένας χαρακτήρας ταιριάζει.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Κατευθυντικότητα του κειμένου
    ///
    /// Μια συμβολοσειρά είναι μια ακολουθία byte.
    /// 'Right' σε αυτό το πλαίσιο σημαίνει την τελευταία θέση αυτής της συμβολοσειράς byte.για μια γλώσσα όπως τα Αραβικά ή τα Εβραϊκά που είναι «δεξιά προς τα αριστερά» και όχι «αριστερά προς τα δεξιά», αυτή θα είναι η πλευρά _left_ και όχι η δεξιά.
    ///
    ///
    /// # Examples
    ///
    /// Απλά μοτίβα:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Ένα πιο περίπλοκο μοτίβο, χρησιμοποιώντας ένα κλείσιμο:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Αναλύει αυτό το κομμάτι συμβολοσειράς σε άλλο τύπο.
    ///
    /// Επειδή το `parse` είναι τόσο γενικό, μπορεί να προκαλέσει προβλήματα με την εξαγωγή τύπου.
    /// Ως εκ τούτου, το `parse` είναι μία από τις λίγες φορές που θα δείτε τη σύνταξη γνωστή ως 'turbofish': `::<>`.
    ///
    /// Αυτό βοηθά τον αλγόριθμο συμπερασμάτων να κατανοήσει συγκεκριμένα τον τύπο στον οποίο προσπαθείτε να αναλύσετε.
    ///
    /// `parse` μπορεί να αναλυθεί σε οποιονδήποτε τύπο που εφαρμόζει το [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Θα επιστρέψει το [`Err`] εάν δεν είναι δυνατό να αναλυθεί αυτό το κομμάτι συμβολοσειράς στον επιθυμητό τύπο.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Βασική χρήση
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Χρησιμοποιώντας το 'turbofish' αντί για σχολιασμό `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Αποτυχία ανάλυσης:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Ελέγχει εάν όλοι οι χαρακτήρες σε αυτήν τη συμβολοσειρά βρίσκονται εντός του εύρους ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Μπορούμε να αντιμετωπίσουμε κάθε byte ως χαρακτήρα εδώ: όλοι οι χαρακτήρες πολλαπλών byte ξεκινούν με ένα byte που δεν βρίσκεται στην περιοχή ascii, οπότε θα σταματήσουμε εκεί ήδη.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Ελέγχει ότι οι δύο χορδές είναι αντιστοιχία ASCII χωρίς ευαισθησία πεζών-κεφαλαίων.
    ///
    /// Το ίδιο με το `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, αλλά χωρίς εκχώρηση και αντιγραφή προσωρινών.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Μετατρέπει αυτήν τη συμβολοσειρά σε αντίστοιχη κεφαλαία ASCII.
    ///
    /// Τα γράμματα ASCII 'a' έως 'z' αντιστοιχίζονται σε 'A' έως 'Z', αλλά τα γράμματα που δεν είναι ASCII είναι αμετάβλητα.
    ///
    /// Για να επιστρέψετε μια νέα κεφαλαία τιμή χωρίς να τροποποιήσετε την υπάρχουσα, χρησιμοποιήστε το [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // ΑΣΦΑΛΕΙΑ: ασφαλής επειδή μεταδίδουμε δύο τύπους με την ίδια διάταξη.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Μετατρέπει αυτήν τη συμβολοσειρά σε ισοδύναμο πεζά ASCII στη θέση του.
    ///
    /// Τα γράμματα ASCII 'A' έως 'Z' αντιστοιχίζονται σε 'a' έως 'z', αλλά τα γράμματα που δεν είναι ASCII είναι αμετάβλητα.
    ///
    /// Για να επιστρέψετε μια νέα πεζά τιμή χωρίς να τροποποιήσετε την υπάρχουσα, χρησιμοποιήστε το [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // ΑΣΦΑΛΕΙΑ: ασφαλής επειδή μεταδίδουμε δύο τύπους με την ίδια διάταξη.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Επιστρέψτε έναν επαναληπτικό που ξεφεύγει από κάθε char στο `self` με [`char::escape_debug`].
    ///
    ///
    /// Note: Μόνο εκτεταμένα σημεία κώδικα γραφήματος που ξεκινούν τη συμβολοσειρά θα διαφύγουν.
    ///
    /// # Examples
    ///
    /// Ως επαναληπτικό:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Χρησιμοποιώντας το `println!` απευθείας:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Και τα δύο είναι ισοδύναμα με:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Χρήση `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Επιστρέψτε έναν επαναληπτικό που ξεφεύγει από κάθε char στο `self` με [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Ως επαναληπτικό:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Χρησιμοποιώντας το `println!` απευθείας:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Και τα δύο είναι ισοδύναμα με:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Χρήση `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Επιστρέψτε έναν επαναληπτικό που ξεφεύγει από κάθε char στο `self` με [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Ως επαναληπτικό:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Χρησιμοποιώντας το `println!` απευθείας:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Και τα δύο είναι ισοδύναμα με:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Χρήση `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Δημιουργεί ένα κενό str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Δημιουργεί ένα κενό μεταβλητό str
    #[inline]
    fn default() -> Self {
        // ΑΣΦΑΛΕΙΑ: Η κενή συμβολοσειρά είναι έγκυρη UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Ένας ονομαστός, κλωνοποιήσιμος τύπος fn
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // ΑΣΦΑΛΕΙΑ: δεν είναι ασφαλές
        unsafe { from_utf8_unchecked(bytes) }
    };
}