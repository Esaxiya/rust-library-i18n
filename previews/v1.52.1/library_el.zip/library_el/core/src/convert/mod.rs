//! Traits για μετατροπές μεταξύ τύπων.
//!
//! Το traits σε αυτήν την ενότητα παρέχει έναν τρόπο μετατροπής από έναν τύπο σε έναν άλλο τύπο.
//! Κάθε trait εξυπηρετεί διαφορετικό σκοπό:
//!
//! - Εφαρμόστε το [`AsRef`] trait για φθηνές μετατροπές αναφοράς σε αναφορά
//! - Εφαρμόστε το [`AsMut`] trait για φθηνές μετατροπές με δυνατότητα μετάλλαξης σε μεταβολή
//! - Εφαρμόστε το [`From`] trait για την κατανάλωση μετατροπών από αξία σε αξία
//! - Εφαρμόστε το [`Into`] trait για την κατανάλωση μετατροπών από αξία σε αξία σε τύπους εκτός του τρέχοντος crate
//! - Τα [`TryFrom`] και [`TryInto`] traits συμπεριφέρονται όπως τα [`From`] και [`Into`], αλλά θα πρέπει να εφαρμοστούν όταν η μετατροπή μπορεί να αποτύχει.
//!
//! Τα traits σε αυτήν την ενότητα χρησιμοποιούνται συχνά ως trait bounds για γενικές συναρτήσεις έτσι ώστε να υποστηρίζονται επιχειρήματα πολλαπλών τύπων.Δείτε την τεκμηρίωση κάθε trait για παραδείγματα.
//!
//! Ως συγγραφέας βιβλιοθήκης, θα πρέπει πάντα να προτιμάτε την εφαρμογή [`From<T>`][`From`] ή [`TryFrom<T>`][`TryFrom`] αντί για [`Into<U>`][`Into`] ή [`TryInto<U>`][`TryInto`], καθώς τα [`From`] και [`TryFrom`] παρέχουν μεγαλύτερη ευελιξία και προσφέρουν αντίστοιχες εφαρμογές [`Into`] ή [`TryInto`] δωρεάν, χάρη σε μια γενική εφαρμογή στην τυπική βιβλιοθήκη.
//! Όταν στοχεύετε μια έκδοση πριν από το Rust 1.41, ενδέχεται να είναι απαραίτητο να εφαρμόσετε το [`Into`] ή το [`TryInto`] απευθείας κατά τη μετατροπή σε τύπο εκτός του τρέχοντος crate.
//!
//! # Γενικές υλοποιήσεις
//!
//! - [`AsRef`] και [`AsMut`] αυτόματη διαφορά εάν ο εσωτερικός τύπος είναι αναφορά
//! - ["From`]"<U>για T` σημαίνει ["Into"] "</u><T><U>για U`</u>
//! - ["TryFrom`]"<U>για T` σημαίνει ["TryInto"] "</u><T><U>για U`</u>
//! - [`From`] και το [`Into`] είναι αντανακλαστικά, πράγμα που σημαίνει ότι όλοι οι τύποι μπορούν οι ίδιοι οι `into` και οι ίδιοι οι `from`
//!
//! Δείτε κάθε trait για παραδείγματα χρήσης.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Η συνάρτηση ταυτότητας.
///
/// Δύο πράγματα είναι σημαντικά να σημειωθούν σχετικά με αυτήν τη λειτουργία:
///
/// - Δεν είναι πάντα ισοδύναμο με ένα κλείσιμο όπως το `|x| x`, καθώς το κλείσιμο μπορεί να εξαναγκάσει το `x` σε διαφορετικό τύπο.
///
/// - Μετακινεί την είσοδο `x` που περνά στη συνάρτηση.
///
/// Ενώ μπορεί να φαίνεται περίεργο να έχουμε μια λειτουργία που επιστρέφει πίσω την είσοδο, υπάρχουν μερικές ενδιαφέρουσες χρήσεις.
///
///
/// # Examples
///
/// Χρησιμοποιώντας το `identity` για να μην κάνετε τίποτα σε μια σειρά από άλλες, ενδιαφέρουσες, λειτουργίες:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Ας προσποιηθούμε ότι η προσθήκη ενός είναι μια ενδιαφέρουσα λειτουργία.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Χρησιμοποιώντας το `identity` ως θήκη βάσης "do nothing" υπό όρους:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Κάντε πιο ενδιαφέροντα πράγματα ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Χρησιμοποιώντας το `identity` για να διατηρήσετε τις παραλλαγές X02 ενός επαναληπτικού `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Χρησιμοποιήθηκε για μια φτηνή μετατροπή αναφοράς σε αναφορά.
///
/// Αυτό το trait είναι παρόμοιο με το [`AsMut`] που χρησιμοποιείται για τη μετατροπή μεταξύ μεταβλητών αναφορών.
/// Εάν πρέπει να κάνετε μια δαπανηρή μετατροπή, είναι καλύτερα να εφαρμόσετε το [`From`] με τον τύπο `&T` ή να γράψετε μια προσαρμοσμένη λειτουργία.
///
/// `AsRef` έχει την ίδια υπογραφή με το [`Borrow`], αλλά το [`Borrow`] διαφέρει σε μερικές πτυχές:
///
/// - Σε αντίθεση με το `AsRef`, το [`Borrow`] διαθέτει κουβέρτα για οποιοδήποτε `T` και μπορεί να χρησιμοποιηθεί για την αποδοχή μιας αναφοράς ή μιας τιμής.
/// - [`Borrow`] απαιτεί επίσης ότι τα [`Hash`], [`Eq`] και [`Ord`] για αξία δανεισμού είναι ισοδύναμα με αυτά της ιδιοκτησιακής αξίας.
/// Για αυτόν τον λόγο, εάν θέλετε να δανειστείτε μόνο ένα πεδίο δομής, μπορείτε να εφαρμόσετε το `AsRef`, αλλά όχι το [`Borrow`].
///
/// **Note: Αυτό το trait δεν πρέπει να αποτύχει **.Εάν η μετατροπή μπορεί να αποτύχει, χρησιμοποιήστε μια ειδική μέθοδο που επιστρέφει [`Option<T>`] ή [`Result<T, E>`].
///
/// # Γενικές υλοποιήσεις
///
/// - `AsRef` αυτόματες παραπομπές εάν ο εσωτερικός τύπος είναι αναφορά ή μεταβλητή αναφορά (π.χ. `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Χρησιμοποιώντας trait bounds μπορούμε να δεχτούμε επιχειρήματα διαφορετικών τύπων εφόσον μπορούν να μετατραπούν στον καθορισμένο τύπο `T`.
///
/// Για παράδειγμα: Δημιουργώντας μια γενική συνάρτηση που παίρνει ένα `AsRef<str>` δηλώνουμε ότι θέλουμε να δεχτούμε όλες τις αναφορές που μπορούν να μετατραπούν σε [`&str`] ως επιχείρημα.
/// Δεδομένου ότι και οι δύο [`String`] και [`&str`] εφαρμόζουν `AsRef<str>` μπορούμε να δεχτούμε και τα δύο ως όρισμα εισαγωγής.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Εκτελεί τη μετατροπή.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Χρησιμοποιήθηκε για να κάνει μια φτηνή μετατροπή αναφοράς μεταβλητή σε μεταβλητή.
///
/// Αυτό το trait είναι παρόμοιο με το [`AsRef`] αλλά χρησιμοποιείται για τη μετατροπή μεταξύ μεταβλητών αναφορών.
/// Εάν πρέπει να κάνετε μια δαπανηρή μετατροπή, είναι καλύτερα να εφαρμόσετε το [`From`] με τον τύπο `&mut T` ή να γράψετε μια προσαρμοσμένη λειτουργία.
///
/// **Note: Αυτό το trait δεν πρέπει να αποτύχει **.Εάν η μετατροπή μπορεί να αποτύχει, χρησιμοποιήστε μια ειδική μέθοδο που επιστρέφει [`Option<T>`] ή [`Result<T, E>`].
///
/// # Γενικές υλοποιήσεις
///
/// - `AsMut` αυτόματες παραπομπές εάν ο εσωτερικός τύπος είναι μεταβλητή αναφορά (π.χ. `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Χρησιμοποιώντας το `AsMut` ως trait bound για μια γενική συνάρτηση, μπορούμε να δεχτούμε όλες τις μεταβλητές αναφορές που μπορούν να μετατραπούν σε τύπο `&mut T`.
/// Επειδή το [`Box<T>`] εφαρμόζει το `AsMut<T>` μπορούμε να γράψουμε μια συνάρτηση `add_one` που λαμβάνει όλα τα ορίσματα που μπορούν να μετατραπούν σε `&mut u64`.
/// Επειδή το [`Box<T>`] εφαρμόζει το `AsMut<T>`, το `add_one` δέχεται επίσης επιχειρήματα τύπου `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Εκτελεί τη μετατροπή.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Μια μετατροπή από τιμή σε αξία που καταναλώνει την τιμή εισαγωγής.Το αντίθετο του [`From`].
///
/// Κάποιος πρέπει να αποφύγει την εφαρμογή [`Into`] και να εφαρμόσει το [`From`] αντ 'αυτού.
/// Η υλοποίηση του [`From`] παρέχει αυτομάτως μια εφαρμογή του [`Into`] χάρη στην γενική εφαρμογή στην τυπική βιβλιοθήκη.
///
/// Προτιμήστε τη χρήση του [`Into`] έναντι του [`From`] κατά τον καθορισμό του trait bounds σε μια γενική συνάρτηση για να διασφαλίσετε ότι μπορούν επίσης να χρησιμοποιηθούν τύποι που εφαρμόζουν μόνο το [`Into`].
///
/// **Note: Αυτό το trait δεν πρέπει να αποτύχει **.Εάν η μετατροπή μπορεί να αποτύχει, χρησιμοποιήστε το [`TryInto`].
///
/// # Γενικές υλοποιήσεις
///
/// - ["Από"] "<T>για το U` υπονοεί το `Into<U> for T`
/// - [`Into`] είναι ανακλαστική, που σημαίνει ότι το `Into<T> for T` έχει εφαρμοστεί
///
/// # Υλοποίηση [`Into`] για μετατροπές σε εξωτερικούς τύπους σε παλιές εκδόσεις του Rust
///
/// Πριν από το Rust 1.41, εάν ο τύπος προορισμού δεν ήταν μέρος του τρέχοντος crate τότε δεν θα μπορούσατε να εφαρμόσετε το [`From`] απευθείας.
/// Για παράδειγμα, πάρτε αυτόν τον κωδικό:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Αυτό δεν θα συγκεντρωθεί σε παλαιότερες εκδόσεις της γλώσσας, επειδή οι κανόνες ορφανών του Rust ήταν λίγο πιο αυστηροί.
/// Για να το παρακάμψετε, θα μπορούσατε να εφαρμόσετε το [`Into`] απευθείας:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Είναι σημαντικό να κατανοήσουμε ότι το [`Into`] δεν παρέχει εφαρμογή [`From`] (όπως το [`From`] με το [`Into`]).
/// Επομένως, πρέπει πάντα να προσπαθείτε να εφαρμόσετε το [`From`] και στη συνέχεια να επιστρέψετε στο [`Into`] εάν το [`From`] δεν μπορεί να εφαρμοστεί.
///
/// # Examples
///
/// [`String`] υλοποιεί ["Into"] "<" ["Vec"] "<" ["u8"] ">>:
///
/// Για να εκφράσουμε ότι θέλουμε μια γενική συνάρτηση να λαμβάνει όλα τα ορίσματα που μπορούν να μετατραπούν σε έναν καθορισμένο τύπο `T`, μπορούμε να χρησιμοποιήσουμε ένα trait bound του ["Into"] "<T>".
///
/// Για παράδειγμα: Η συνάρτηση `is_hello` λαμβάνει όλα τα ορίσματα που μπορούν να μετατραπούν σε ["Vec"] "<" [`u8"] ">".
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Εκτελεί τη μετατροπή.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Χρησιμοποιήθηκε για να κάνει μετατροπές από αξία σε αξία ενώ καταναλώνει την τιμή εισαγωγής.Είναι το αντίστροφο του [`Into`].
///
/// Κάποιος πρέπει πάντα να προτιμά να εφαρμόζει το `From` σε σχέση με το [`Into`], επειδή η εφαρμογή του `From` παρέχει αυτόματα σε αυτόν μια εφαρμογή του [`Into`] χάρη στην γενική εφαρμογή στην τυπική βιβλιοθήκη.
///
///
/// Εφαρμόστε μόνο το [`Into`] κατά τη στόχευση μιας έκδοσης πριν από το Rust 1.41 και τη μετατροπή σε τύπο εκτός του τρέχοντος crate.
/// `From` δεν μπόρεσε να πραγματοποιήσει αυτούς τους τύπους μετατροπών σε παλαιότερες εκδόσεις λόγω των ορφανών κανόνων του Rust.
/// Ανατρέξτε στο [`Into`] για περισσότερες λεπτομέρειες.
///
/// Προτιμήστε τη χρήση [`Into`] σε σχέση με τη χρήση `From` κατά τον καθορισμό trait bounds σε μια γενική συνάρτηση.
/// Με αυτόν τον τρόπο, οι τύποι που εφαρμόζουν άμεσα το [`Into`] μπορούν να χρησιμοποιηθούν και ως ορίσματα.
///
/// Το `From` είναι επίσης πολύ χρήσιμο όταν εκτελείτε χειρισμό σφαλμάτων.Κατά την κατασκευή μιας συνάρτησης που μπορεί να αποτύχει, ο τύπος επιστροφής θα έχει γενικά τη μορφή `Result<T, E>`.
/// Το `From` trait απλοποιεί το χειρισμό σφαλμάτων επιτρέποντας σε μια συνάρτηση να επιστρέψει έναν μόνο τύπο σφάλματος που ενσωματώνει πολλούς τύπους σφαλμάτων.Ανατρέξτε στην ενότητα "Examples" και [the book][book] για περισσότερες λεπτομέρειες.
///
/// **Note: Αυτό το trait δεν πρέπει να αποτύχει **.Εάν η μετατροπή μπορεί να αποτύχει, χρησιμοποιήστε το [`TryFrom`].
///
/// # Γενικές υλοποιήσεις
///
/// - `From<T> for U` υπονοεί [«Into`]» <U>για T`</u>
/// - `From` είναι ανακλαστική, που σημαίνει ότι το `From<T> for T` έχει εφαρμοστεί
///
/// # Examples
///
/// [`String`] εφαρμόζει το `From<&str>`:
///
/// Μια ρητή μετατροπή από `&str` σε συμβολοσειρά γίνεται ως εξής:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Ενώ εκτελείτε χειρισμό σφαλμάτων, είναι συχνά χρήσιμο να εφαρμόσετε το `From` για τον δικό σας τύπο σφάλματος.
/// Μετατρέποντας τους υποκείμενους τύπους σφαλμάτων στον δικό μας προσαρμοσμένο τύπο σφάλματος που ενσωματώνει τον υποκείμενο τύπο σφάλματος, μπορούμε να επιστρέψουμε έναν μόνο τύπο σφάλματος χωρίς να χάσουμε πληροφορίες σχετικά με την υποκείμενη αιτία.
/// Ο χειριστής '?' μετατρέπει αυτόματα τον υποκείμενο τύπο σφάλματος στον προσαρμοσμένο τύπο σφάλματος καλώντας το `Into<CliError>::into` που παρέχεται αυτόματα κατά την εφαρμογή του `From`.
/// Στη συνέχεια, ο μεταγλωττιστής εισάγει ποια εφαρμογή του `Into` πρέπει να χρησιμοποιηθεί.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Εκτελεί τη μετατροπή.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Μια απόπειρα μετατροπής που καταναλώνει `self`, η οποία μπορεί ή όχι να είναι ακριβή.
///
/// Συνήθως, οι συγγραφείς της βιβλιοθήκης δεν πρέπει να εφαρμόζουν άμεσα αυτό το trait, αλλά προτιμούν να εφαρμόζουν το [`TryFrom`] trait, το οποίο προσφέρει μεγαλύτερη ευελιξία και παρέχει μια ισοδύναμη εφαρμογή `TryInto` δωρεάν, χάρη σε μια γενική εφαρμογή στην τυπική βιβλιοθήκη.
/// Για περισσότερες πληροφορίες σχετικά με αυτό, ανατρέξτε στην τεκμηρίωση για το [`Into`].
///
/// # Εφαρμογή `TryInto`
///
/// Αυτό υποφέρει από τους ίδιους περιορισμούς και συλλογισμούς με την εφαρμογή [`Into`], δείτε εδώ για λεπτομέρειες.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Ο τύπος που επιστρέφεται σε περίπτωση σφάλματος μετατροπής.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Εκτελεί τη μετατροπή.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Απλές και ασφαλείς μετατροπές τύπου που ενδέχεται να αποτύχουν με ελεγχόμενο τρόπο σε ορισμένες περιπτώσεις.Είναι το αντίστροφο του [`TryInto`].
///
/// Αυτό είναι χρήσιμο όταν κάνετε μια μετατροπή τύπου που μπορεί να επιτύχει ασήμαντα, αλλά μπορεί επίσης να χρειαστεί ειδικός χειρισμός.
/// Για παράδειγμα, δεν υπάρχει τρόπος μετατροπής ενός [`i64`] σε [`i32`] χρησιμοποιώντας το [`From`] trait, επειδή ένα [`i64`] μπορεί να περιέχει μια τιμή που δεν μπορεί να αντιπροσωπεύσει ένα [`i32`] και έτσι η μετατροπή θα χάσει δεδομένα.
///
/// Αυτό μπορεί να αντιμετωπιστεί περικόπτοντας το [`i64`] σε [`i32`] (ουσιαστικά δίνοντας την τιμή modulo [`i32::MAX`] του ["i64"]) ή απλώς επιστρέφοντας το [`i32::MAX`] ή με κάποια άλλη μέθοδο.
/// Το [`From`] trait προορίζεται για τέλειες μετατροπές, επομένως το `TryFrom` trait ενημερώνει τον προγραμματιστή πότε μια μετατροπή τύπου θα μπορούσε να πάει άσχημα και τους επιτρέπει να αποφασίσουν πώς να το χειριστούν.
///
/// # Γενικές υλοποιήσεις
///
/// - `TryFrom<T> for U` υποδηλώνει [`TryInto`]`<U>για T`</u>
/// - [`try_from`] είναι αντανακλαστικό, πράγμα που σημαίνει ότι το `TryFrom<T> for T` έχει εφαρμοστεί και δεν μπορεί να αποτύχει-ο σχετικός τύπος `Error` για την κλήση `T::try_from()` σε τιμή τύπου `T` είναι [`Infallible`].
/// Όταν ο τύπος [`!`] σταθεροποιηθεί, τα [`Infallible`] και [`!`] θα είναι ισοδύναμα.
///
/// `TryFrom<T>` μπορεί να εφαρμοστεί ως εξής:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Όπως περιγράφεται, το [`i32`] εφαρμόζει το "TryFrom <" ["i64"] ">:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Σιωπηλά κόβει το `big_number`, απαιτεί ανίχνευση και χειρισμό της περικοπής μετά το γεγονός.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Επιστρέφει σφάλμα επειδή το `big_number` είναι πολύ μεγάλο για να χωρέσει σε `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Επιστρέφει `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Ο τύπος που επιστρέφεται σε περίπτωση σφάλματος μετατροπής.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Εκτελεί τη μετατροπή.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ΓΕΝΙΚΕΣ ΕΠΙΠΤΩΣΕΙΣ
////////////////////////////////////////////////////////////////////////////////

// Καθώς ανυψώνονται&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Καθώς ανυψώνεται πάνω από &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): αντικαταστήστε τα παραπάνω impls για&/&mut με το ακόλουθο πιο γενικό:
// // Καθώς ανεβαίνει ο Ντέρεφ
// εμφ <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>για D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// Το AsMut ανυψώνει πάνω από &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): αντικαταστήστε το παραπάνω impl για το &mut με το ακόλουθο πιο γενικό:
// // Το AsMut ανεβαίνει πάνω από το DerefMut
// εμφ <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>για D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Από υπονοεί το Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Από (και έτσι Into) είναι αντανακλαστική
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Σημείωση σταθερότητας:** Αυτό το impl δεν υπάρχει ακόμα, αλλά είμαστε "reserving space" για να το προσθέσουμε στο future.
/// Δείτε το [rust-lang/rust#64715][#64715] για λεπτομέρειες.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): Αντ 'αυτού, κάντε μια διορθωμένη αρχή.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// Το TryFrom συνεπάγεται το TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Οι αλάνθαστες μετατροπές είναι σημασιολογικά ισοδύναμες με τις πλάνες με έναν ακατοίκητο τύπο σφάλματος.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// ΠΟΛΥ ΣΚΥΡΟΔΕΜΑΤΟΣ
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// Ο ΤΥΠΟΣ ΣΦΑΛΜΑΤΟΣ ΣΦΑΛΜΑΤΟΣ
////////////////////////////////////////////////////////////////////////////////

/// Ο τύπος σφάλματος για σφάλματα που δεν μπορούν ποτέ να συμβούν.
///
/// Δεδομένου ότι αυτό το enum δεν έχει καμία παραλλαγή, μια τιμή αυτού του τύπου δεν μπορεί ποτέ να υπάρχει.
/// Αυτό μπορεί να είναι χρήσιμο για γενικά API που χρησιμοποιούν [`Result`] και παραμετροποιούν τον τύπο σφάλματος, για να δείξουν ότι το αποτέλεσμα είναι πάντα [`Ok`].
///
/// Για παράδειγμα, το [`TryFrom`] trait (μετατροπή που επιστρέφει ένα [`Result`]) έχει μια ολοκληρωμένη εφαρμογή για όλους τους τύπους όπου υπάρχει μια αντίστροφη εφαρμογή [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Συμβατότητα Future
///
/// Αυτό το enum έχει τον ίδιο ρόλο με το [the `!`“never”type][never], το οποίο είναι ασταθές σε αυτήν την έκδοση του Rust.
/// Όταν το `!` σταθεροποιείται, σχεδιάζουμε να κάνουμε το `Infallible` ένα ψευδώνυμο τύπου σε αυτό:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Και τελικά καταργήθηκε το `Infallible`.
///
/// Ωστόσο, υπάρχει μία περίπτωση όπου η σύνταξη `!` μπορεί να χρησιμοποιηθεί πριν σταθεροποιηθεί το `!` ως πλήρης τύπος: στη θέση του τύπου επιστροφής μιας συνάρτησης.
/// Συγκεκριμένα, είναι πιθανές υλοποιήσεις για δύο διαφορετικούς τύπους δείκτη λειτουργίας:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Με το `Infallible` να είναι enum, αυτός ο κωδικός είναι έγκυρος.
/// Ωστόσο, όταν το `Infallible` γίνει ψευδώνυμο για το never type, τα δύο "impl" θα αρχίσουν να αλληλεπικαλύπτονται και επομένως θα απαγορεύονται από τους κανόνες συνοχής trait της γλώσσας.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}