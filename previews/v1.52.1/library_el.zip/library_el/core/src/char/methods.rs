//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Το υψηλότερο έγκυρο σημείο κώδικα που μπορεί να έχει ένα `char`.
    ///
    /// Το `char` είναι [Unicode Scalar Value], που σημαίνει ότι είναι [Code Point], αλλά μόνο σε συγκεκριμένο εύρος.
    /// `MAX` είναι το υψηλότερο έγκυρο σημείο κώδικα που είναι έγκυρο [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` Το () χρησιμοποιείται στο Unicode για να αντιπροσωπεύσει ένα σφάλμα αποκωδικοποίησης.
    ///
    /// Μπορεί να συμβεί, για παράδειγμα, όταν δίνει UTF-8 bytes σε μορφή [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Η έκδοση του [Unicode](http://www.unicode.org/) στην οποία βασίζονται τα μέρη Unicode των μεθόδων `char` και `str`.
    ///
    /// Νέες εκδόσεις του Unicode κυκλοφορούν τακτικά και στη συνέχεια ενημερώνονται όλες οι μέθοδοι στην τυπική βιβλιοθήκη ανάλογα με το Unicode.
    /// Επομένως, η συμπεριφορά ορισμένων μεθόδων `char` και `str` και η αξία αυτής της σταθεράς αλλάζει με την πάροδο του χρόνου.
    /// Αυτό *δεν* θεωρείται μια σημαντική αλλαγή.
    ///
    /// Το σχήμα αρίθμησης έκδοσης εξηγείται στο [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Δημιουργεί έναν επαναλήπτη πάνω από τα κωδικοποιημένα σημεία κωδικού UTF-16 στο `iter`, επιστρέφοντας μη ζευγαρωμένα υποκατάστατα ως «Err».
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Ένας αποκωδικοποιητής με απώλεια μπορεί να ληφθεί αντικαθιστώντας τα αποτελέσματα `Err` με τον χαρακτήρα αντικατάστασης:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Μετατρέπει ένα `u32` σε `char`.
    ///
    /// Σημειώστε ότι όλα τα `char`s είναι έγκυρα [`u32`] s και μπορούν να μεταδοθούν σε ένα με
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Ωστόσο, το αντίστροφο δεν είναι αλήθεια: δεν είναι όλα τα έγκυρα [«u32»] έγκυρα «char`s.
    /// `from_u32()` θα επιστρέψει το `None` εάν η είσοδος δεν είναι έγκυρη τιμή για ένα `char`.
    ///
    /// Για μια μη ασφαλή έκδοση αυτής της λειτουργίας που αγνοεί αυτούς τους ελέγχους, ανατρέξτε στο [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Επιστροφή `None` όταν η είσοδος δεν είναι έγκυρη `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Μετατρέπει ένα `u32` σε `char`, αγνοώντας την εγκυρότητα.
    ///
    /// Σημειώστε ότι όλα τα `char`s είναι έγκυρα [`u32`] s και μπορούν να μεταδοθούν σε ένα με
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Ωστόσο, το αντίστροφο δεν είναι αλήθεια: δεν είναι όλα τα έγκυρα [«u32»] έγκυρα «char`s.
    /// `from_u32_unchecked()` θα το αγνοήσει αυτό και θα ρίξει τυφλά στο `char`, δημιουργώντας πιθανώς ένα μη έγκυρο.
    ///
    ///
    /// # Safety
    ///
    /// Αυτή η συνάρτηση δεν είναι ασφαλής, καθώς μπορεί να δημιουργήσει μη έγκυρες τιμές `char`.
    ///
    /// Για μια ασφαλή έκδοση αυτής της λειτουργίας, ανατρέξτε στη λειτουργία [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // ΑΣΦΑΛΕΙΑ: η σύμβαση ασφαλείας πρέπει να τηρείται από τον καλούντα.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Μετατρέπει ένα ψηφίο στη δεδομένη ακτίνα σε `char`.
    ///
    /// Ένα 'radix' εδώ μερικές φορές ονομάζεται επίσης 'base'.
    /// Μια ακτίνα δύο υποδεικνύει δυαδικό αριθμό, ακτίνα δέκα, δεκαδικό και ακτίνα δεκαέξι, δεκαεξαδικό, για να δώσει μερικές κοινές τιμές.
    ///
    /// Υποστηρίζονται αυθαίρετες ρίζες.
    ///
    /// `from_digit()` θα επιστρέψει το `None` εάν η είσοδος δεν είναι ψηφίο στη δεδομένη ακτίνα.
    ///
    /// # Panics
    ///
    /// Panics εάν έχει ακτίνα μεγαλύτερη από 36.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Το δεκαδικό 11 είναι ένα μονοψήφιο στη βάση 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Επιστροφή `None` όταν η είσοδος δεν είναι ψηφίο:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Περνώντας μια μεγάλη ακτίνα, προκαλώντας panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Ελέγχει εάν ένα `char` είναι ένα ψηφίο στη δεδομένη ακτίνα.
    ///
    /// Ένα 'radix' εδώ μερικές φορές ονομάζεται επίσης 'base'.
    /// Μια ακτίνα δύο υποδεικνύει δυαδικό αριθμό, ακτίνα δέκα, δεκαδικό και ακτίνα δεκαέξι, δεκαεξαδικό, για να δώσει μερικές κοινές τιμές.
    ///
    /// Υποστηρίζονται αυθαίρετες ρίζες.
    ///
    /// Σε σύγκριση με το [`is_numeric()`], αυτή η λειτουργία αναγνωρίζει μόνο τους χαρακτήρες `0-9`, `a-z` και `A-Z`.
    ///
    /// 'Digit' ορίζεται ότι είναι μόνο οι ακόλουθοι χαρακτήρες:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Για μια πιο ολοκληρωμένη κατανόηση του 'digit', ανατρέξτε στο [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics εάν έχει ακτίνα μεγαλύτερη από 36.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Περνώντας μια μεγάλη ακτίνα, προκαλώντας panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Μετατρέπει ένα `char` σε ψηφίο στη δεδομένη ακτίνα.
    ///
    /// Ένα 'radix' εδώ μερικές φορές ονομάζεται επίσης 'base'.
    /// Μια ακτίνα δύο υποδεικνύει δυαδικό αριθμό, ακτίνα δέκα, δεκαδικό και ακτίνα δεκαέξι, δεκαεξαδικό, για να δώσει μερικές κοινές τιμές.
    ///
    /// Υποστηρίζονται αυθαίρετες ρίζες.
    ///
    /// 'Digit' ορίζεται ότι είναι μόνο οι ακόλουθοι χαρακτήρες:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Επιστρέφει το `None` εάν το `char` δεν αναφέρεται σε ένα ψηφίο στη δεδομένη ακτίνα.
    ///
    /// # Panics
    ///
    /// Panics εάν έχει ακτίνα μεγαλύτερη από 36.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Η αποτυχία μη ψηφίων οδηγεί σε αποτυχία:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Περνώντας μια μεγάλη ακτίνα, προκαλώντας panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // ο κωδικός χωρίζεται εδώ για να βελτιώσει την ταχύτητα εκτέλεσης για περιπτώσεις όπου το `radix` είναι σταθερό και 10 ή μικρότερο
        //
        let val = if likely(radix <= 10) {
            // Εάν δεν είναι ψηφίο, θα δημιουργηθεί ένας αριθμός μεγαλύτερος από το radix.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Επιστρέφει έναν επαναληπτικό που αποδίδει τη δεκαεξαδική διαφυγή Unicode ενός χαρακτήρα ως `char`s.
    ///
    /// Αυτό θα ξεφύγει από τους χαρακτήρες με τη σύνταξη Rust της φόρμας `\u{NNNNNN}` όπου το `NNNNNN` είναι μια δεκαεξαδική αναπαράσταση.
    ///
    ///
    /// # Examples
    ///
    /// Ως επαναληπτικό:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Χρησιμοποιώντας το `println!` απευθείας:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Και τα δύο είναι ισοδύναμα με:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Χρήση `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 διασφαλίζει ότι για το c==0 ο κωδικός υπολογίζει ότι πρέπει να εκτυπωθεί ένα ψηφίο και (το οποίο είναι το ίδιο) αποφεύγει την (31, 32) υπορροή
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // το ευρετήριο του πιο σημαντικού δεκαεξαδικού ψηφίου
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Μια εκτεταμένη έκδοση του `escape_debug` που επιτρέπει προαιρετικά τη διαφυγή κωδικών σημείων Extended Grapheme.
    /// Αυτό μας επιτρέπει να μορφοποιήσουμε χαρακτήρες όπως τα σημάδια χωρίς διαστήματα καλύτερα όταν βρίσκονται στην αρχή μιας συμβολοσειράς.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Επιστρέφει έναν επαναληπτικό που αποδίδει τον κυριολεκτικό κωδικό διαφυγής ενός χαρακτήρα ως `char`s.
    ///
    /// Αυτό θα ξεφύγει από τους χαρακτήρες που μοιάζουν με τις εφαρμογές `Debug` των `str` ή `char`.
    ///
    ///
    /// # Examples
    ///
    /// Ως επαναληπτικό:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Χρησιμοποιώντας το `println!` απευθείας:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Και τα δύο είναι ισοδύναμα με:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Χρήση `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Επιστρέφει έναν επαναληπτικό που αποδίδει τον κυριολεκτικό κωδικό διαφυγής ενός χαρακτήρα ως `char`s.
    ///
    /// Η προεπιλογή επιλέγεται με προκατάληψη για την παραγωγή γραμματοσειρών που είναι νόμιμες σε μια ποικιλία γλωσσών, συμπεριλαμβανομένων των C++ 11 και παρόμοιων γ-γ-γλωσσών.
    /// Οι ακριβείς κανόνες είναι:
    ///
    /// * Η καρτέλα διαγράφεται ως `\t`.
    /// * Η επιστροφή μεταφοράς διαφυλάσσεται ως `\r`.
    /// * Η τροφοδοσία γραμμής διαγράφεται ως `\n`.
    /// * Ένα μόνο απόσπασμα διαφυλάσσεται ως `\'`.
    /// * Η διπλή προσφορά διαγράφεται ως `\"`.
    /// * Η ανάστροφη κάθετο διαφεύγει ως `\\`.
    /// * Οποιοσδήποτε χαρακτήρας στην περιοχή "εκτυπώσιμη ASCII" `0x20` .. `0x7e` inclusive δεν διαφυλάσσεται.
    /// * Σε όλους τους άλλους χαρακτήρες δίνονται δεκαεξαδικές διαφυγές Unicode.δείτε [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Ως επαναληπτικό:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Χρησιμοποιώντας το `println!` απευθείας:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Και τα δύο είναι ισοδύναμα με:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Χρήση `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Επιστρέφει τον αριθμό των byte που θα χρειαζόταν αυτό το `char` εάν κωδικοποιήθηκε στο UTF-8.
    ///
    /// Αυτός ο αριθμός byte είναι πάντα μεταξύ 1 και 4, συμπεριλαμβανομένων.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Ο τύπος `&str` εγγυάται ότι το περιεχόμενό του είναι UTF-8 και έτσι μπορούμε να συγκρίνουμε το μήκος που θα χρειαζόταν εάν κάθε σημείο κώδικα αναπαριστάτο ως `char` έναντι του ίδιου του `&str`:
    ///
    ///
    /// ```
    /// // ως χαρακτήρες
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // και τα δύο μπορούν να αναπαρασταθούν ως τρία byte
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // ως &str, αυτά τα δύο κωδικοποιούνται στο UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // μπορούμε να δούμε ότι παίρνουν συνολικά έξι byte ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... ακριβώς όπως το &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Επιστρέφει τον αριθμό των μονάδων κώδικα 16 bit που θα χρειαζόταν αυτό το `char` εάν κωδικοποιήθηκε στο UTF-16.
    ///
    ///
    /// Δείτε την τεκμηρίωση για το [`len_utf8()`] για περισσότερες εξηγήσεις αυτής της έννοιας.
    /// Αυτή η λειτουργία είναι καθρέφτης, αλλά για UTF-16 αντί για UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Κωδικοποιεί αυτόν τον χαρακτήρα ως UTF-8 στο παρεχόμενο buffer byte και, στη συνέχεια, επιστρέφει το υποσύνολο του buffer που περιέχει τον κωδικοποιημένο χαρακτήρα.
    ///
    ///
    /// # Panics
    ///
    /// Panics εάν το buffer δεν είναι αρκετά μεγάλο.
    /// Ένα buffer μήκους τεσσάρων είναι αρκετά μεγάλο για να κωδικοποιεί οποιοδήποτε `char`.
    ///
    /// # Examples
    ///
    /// Και στα δύο αυτά παραδείγματα, το 'ß' παίρνει δύο byte για κωδικοποίηση.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Ένα buffer που είναι πολύ μικρό:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // ΑΣΦΑΛΕΙΑ: Το `char` δεν είναι υποκατάστατο, επομένως αυτό ισχύει UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Κωδικοποιεί αυτόν τον χαρακτήρα ως UTF-16 στο παρεχόμενο buffer `u16` και, στη συνέχεια, επιστρέφει το υποσύνολο του buffer που περιέχει τον κωδικοποιημένο χαρακτήρα.
    ///
    ///
    /// # Panics
    ///
    /// Panics εάν το buffer δεν είναι αρκετά μεγάλο.
    /// Ένα buffer μήκους 2 είναι αρκετά μεγάλο για να κωδικοποιήσει οποιοδήποτε `char`.
    ///
    /// # Examples
    ///
    /// Και στα δύο αυτά παραδείγματα, το '𝕊' παίρνει δύο "u16" για κωδικοποίηση.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Ένα buffer που είναι πολύ μικρό:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Επιστρέφει `true` εάν αυτό το `char` έχει την ιδιότητα `Alphabetic`.
    ///
    /// `Alphabetic` περιγράφεται στο Κεφάλαιο 4 (Ιδιότητες χαρακτήρων) του [Unicode Standard] και καθορίζεται στο [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // η αγάπη είναι πολλά πράγματα, αλλά δεν είναι αλφαβητική
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Επιστρέφει `true` εάν αυτό το `char` έχει την ιδιότητα `Lowercase`.
    ///
    /// `Lowercase` περιγράφεται στο Κεφάλαιο 4 (Ιδιότητες χαρακτήρων) του [Unicode Standard] και καθορίζεται στο [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Τα διάφορα κινεζικά σενάρια και σημεία στίξης δεν έχουν πεζά και έτσι:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Επιστρέφει `true` εάν αυτό το `char` έχει την ιδιότητα `Uppercase`.
    ///
    /// `Uppercase` περιγράφεται στο Κεφάλαιο 4 (Ιδιότητες χαρακτήρων) του [Unicode Standard] και καθορίζεται στο [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Τα διάφορα κινεζικά σενάρια και σημεία στίξης δεν έχουν πεζά και έτσι:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Επιστρέφει `true` εάν αυτό το `char` έχει την ιδιότητα `White_Space`.
    ///
    /// `White_Space` καθορίζεται στο [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // ένα μη σπάσιμο χώρο
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Επιστρέφει `true` εάν αυτό το `char` ικανοποιεί είτε [`is_alphabetic()`] είτε [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Επιστρέφει `true` εάν αυτό το `char` έχει τη γενική κατηγορία κωδικών ελέγχου.
    ///
    /// Οι κωδικοί ελέγχου (σημεία κωδικού με τη γενική κατηγορία `Cc`) περιγράφονται στο Κεφάλαιο 4 (Ιδιότητες χαρακτήρων) του [Unicode Standard] και καθορίζονται στο [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// // U + 009C, STRING TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Επιστρέφει `true` εάν αυτό το `char` έχει την ιδιότητα `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` περιγράφεται στο [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] και καθορίζεται στο [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Επιστρέφει `true` εάν αυτό το `char` έχει μία από τις γενικές κατηγορίες αριθμών.
    ///
    /// Οι γενικές κατηγορίες για αριθμούς (`Nd` για δεκαδικά ψηφία, `Nl` για αριθμητικούς χαρακτήρες που μοιάζουν με γράμματα και `No` για άλλους αριθμητικούς χαρακτήρες) καθορίζονται στο [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Επιστρέφει έναν επαναληπτικό που αποδίδει τη πεζά χαρτογράφηση αυτού του `char` ως ένα ή περισσότερα
    /// `char`s.
    ///
    /// Εάν αυτό το `char` δεν έχει πεζά αντιστοίχιση, ο επαναληπτής αποδίδει το ίδιο `char`.
    ///
    /// Εάν αυτό το `char` έχει μια χαρτογράφηση ενός προς ένα πεζά που δίνεται από το [Unicode Character Database][ucd] [`UnicodeData.txt`], ο επαναληπτικός αποδίδει αυτό το `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Εάν αυτό το `char` απαιτεί ειδικές εκτιμήσεις (π.χ. πολλαπλά "char"), ο επαναληπτής αποδίδει τους "char" (ες) που δίνονται από το [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Αυτή η λειτουργία εκτελεί μια άνευ όρων χαρτογράφηση χωρίς προσαρμογή.Δηλαδή, η μετατροπή είναι ανεξάρτητη από το πλαίσιο και τη γλώσσα.
    ///
    /// Στο [Unicode Standard], το Κεφάλαιο 4 (Ιδιότητες χαρακτήρων) ασχολείται γενικά με τη χαρτογράφηση περιπτώσεων και το Κεφάλαιο 3 (Conformance) περιγράφει τον προεπιλεγμένο αλγόριθμο για τη μετατροπή πεζών.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Ως επαναληπτικό:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Χρησιμοποιώντας το `println!` απευθείας:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Και τα δύο είναι ισοδύναμα με:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Χρήση `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Μερικές φορές το αποτέλεσμα είναι περισσότεροι από ένας χαρακτήρες:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Οι χαρακτήρες που δεν έχουν κεφαλαία και πεζά μετατρέπονται σε τους.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Επιστρέφει έναν επαναληπτικό που αποδίδει την κεφαλαία χαρτογράφηση αυτού του `char` ως ένα ή περισσότερα
    /// `char`s.
    ///
    /// Εάν αυτό το `char` δεν έχει κεφαλαία αντιστοίχιση, ο επαναληπτής αποδίδει το ίδιο `char`.
    ///
    /// Εάν αυτό το `char` έχει αντιστοίχιση ενός προς ένα κεφαλαία που δίνεται από το [Unicode Character Database][ucd] [`UnicodeData.txt`], ο επαναληπτικός αποδίδει το `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Εάν αυτό το `char` απαιτεί ειδικές εκτιμήσεις (π.χ. πολλαπλά "char"), ο επαναληπτής αποδίδει τους "char" (ες) που δίνονται από το [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Αυτή η λειτουργία εκτελεί μια άνευ όρων χαρτογράφηση χωρίς προσαρμογή.Δηλαδή, η μετατροπή είναι ανεξάρτητη από το πλαίσιο και τη γλώσσα.
    ///
    /// Στο [Unicode Standard], το Κεφάλαιο 4 (Ιδιότητες χαρακτήρων) ασχολείται γενικά με τη χαρτογράφηση περιπτώσεων και το Κεφάλαιο 3 (Conformance) περιγράφει τον προεπιλεγμένο αλγόριθμο για τη μετατροπή πεζών.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Ως επαναληπτικό:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Χρησιμοποιώντας το `println!` απευθείας:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Και τα δύο είναι ισοδύναμα με:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Χρήση `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Μερικές φορές το αποτέλεσμα είναι περισσότεροι από ένας χαρακτήρες:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Οι χαρακτήρες που δεν έχουν κεφαλαία και πεζά μετατρέπονται σε τους.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Σημείωση για τις τοπικές ρυθμίσεις
    ///
    /// Στα τουρκικά, το ισοδύναμο του 'i' στα λατινικά έχει πέντε μορφές αντί για δύο:
    ///
    /// * 'Dotless': Εγώ/μερικές φορές γράφω ï
    /// * 'Dotted': İ/θ
    ///
    /// Σημειώστε ότι το πεζά 'i' είναι το ίδιο με το λατινικό.Ως εκ τούτου:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Η τιμή του `upper_i` εδώ βασίζεται στη γλώσσα του κειμένου: εάν είμαστε στο `en-US`, θα πρέπει να είναι `"I"`, αλλά αν είμαστε στο `tr_TR`, θα πρέπει να είναι `"İ"`.
    /// `to_uppercase()` δεν το λαμβάνει υπόψη και έτσι:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// κρατά σε όλες τις γλώσσες.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Ελέγχει εάν η τιμή βρίσκεται εντός του εύρους ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Κάνει ένα αντίγραφο της τιμής στο αντίστοιχο κεφαλαίο ASCII.
    ///
    /// Τα γράμματα ASCII 'a' έως 'z' αντιστοιχίζονται σε 'A' έως 'Z', αλλά τα γράμματα που δεν είναι ASCII είναι αμετάβλητα.
    ///
    /// Για κεφαλαία τιμή στην θέση, χρησιμοποιήστε το [`make_ascii_uppercase()`].
    ///
    /// Για κεφαλαία χαρακτήρες ASCII εκτός από χαρακτήρες εκτός ASCII, χρησιμοποιήστε το [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Κάνει ένα αντίγραφο της τιμής στο αντίστοιχο πεζά ASCII.
    ///
    /// Τα γράμματα ASCII 'A' έως 'Z' αντιστοιχίζονται σε 'a' έως 'z', αλλά τα γράμματα που δεν είναι ASCII είναι αμετάβλητα.
    ///
    /// Για να μειώσετε την τιμή στη θέση σας, χρησιμοποιήστε το [`make_ascii_lowercase()`].
    ///
    /// Για να πετύχετε τους χαρακτήρες ASCII εκτός από τους χαρακτήρες που δεν είναι ASCII, χρησιμοποιήστε το [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Ελέγχει ότι δύο τιμές είναι μια αντιστοίχιση με ευαίσθητα γράμματα ASCII.
    ///
    /// Ισοδύναμο με `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Μετατρέπει αυτόν τον τύπο σε αντίστοιχο κεφαλαίο ASCII.
    ///
    /// Τα γράμματα ASCII 'a' έως 'z' αντιστοιχίζονται σε 'A' έως 'Z', αλλά τα γράμματα που δεν είναι ASCII είναι αμετάβλητα.
    ///
    /// Για να επιστρέψετε μια νέα κεφαλαία τιμή χωρίς να τροποποιήσετε την υπάρχουσα, χρησιμοποιήστε το [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Μετατρέπει αυτόν τον τύπο σε αντίστοιχο πεζά ASCII.
    ///
    /// Τα γράμματα ASCII 'A' έως 'Z' αντιστοιχίζονται σε 'a' έως 'z', αλλά τα γράμματα που δεν είναι ASCII είναι αμετάβλητα.
    ///
    /// Για να επιστρέψετε μια νέα πεζά τιμή χωρίς να τροποποιήσετε την υπάρχουσα, χρησιμοποιήστε το [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Ελέγχει εάν η τιμή είναι αλφαβητικός χαρακτήρας ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' ή
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Ελέγχει εάν η τιμή είναι κεφαλαίος χαρακτήρας ASCII:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Ελέγχει εάν η τιμή είναι πεζός χαρακτήρας ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Ελέγχει εάν η τιμή είναι αλφαριθμητικός χαρακτήρας ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' ή
    /// - U + 0061 'a' ..=U + 007A 'z' ή
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Ελέγχει εάν η τιμή είναι δεκαδικό ψηφίο ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Ελέγχει εάν η τιμή είναι δεκαεξαδικό ψηφίο ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9' ή
    /// - U + 0041 'A' ..=U + 0046 'F' ή
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Ελέγχει εάν η τιμή είναι ένας χαρακτήρας στίξης ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /` ή
    /// - U + 003A ..=U + 0040 `: ; < = > ? @` ή
    /// - U + 005B ..=U + 0060 "[\] ^ _" `` ή
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Ελέγχει εάν η τιμή είναι γραφικός χαρακτήρας ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Ελέγχει εάν η τιμή είναι χαρακτήρας διαστήματος ASCII:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FORM FEED, ή U + 000D CARRIAGE RETURN.
    ///
    /// Το Rust χρησιμοποιεί το WhatWG Infra Standard's [definition of ASCII whitespace][infra-aw].Υπάρχουν πολλοί άλλοι ορισμοί σε ευρεία χρήση.
    /// Για παράδειγμα, το [the POSIX locale][pct] περιλαμβάνει U + 000B VERTICAL TAB καθώς και όλους τους παραπάνω χαρακτήρες, αλλά-από την ίδια προδιαγραφή-[ο προεπιλεγμένος κανόνας για το "field splitting" στο Bourne shell][bfs] θεωρεί *μόνο* SPACE, HORIZONTAL TAB και LINE FEED ως κενό διάστημα.
    ///
    ///
    /// Εάν γράφετε ένα πρόγραμμα που θα επεξεργαστεί μια υπάρχουσα μορφή αρχείου, ελέγξτε ποιος είναι ο ορισμός αυτού του τύπου πριν από τη χρήση αυτής της λειτουργίας.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Ελέγχει εάν η τιμή είναι χαρακτήρας ελέγχου ASCII:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR ή U + 007F DELETE.
    /// Σημειώστε ότι οι περισσότεροι χαρακτήρες διαστήματος ASCII είναι χαρακτήρες ελέγχου, αλλά το SPACE δεν είναι.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Κωδικοποιεί μια πρώτη τιμή u32 ως UTF-8 στο παρεχόμενο buffer byte και, στη συνέχεια, επιστρέφει το υποσύνολο του buffer που περιέχει τον κωδικοποιημένο χαρακτήρα.
///
///
/// Σε αντίθεση με το `char::encode_utf8`, αυτή η μέθοδος χειρίζεται επίσης σημεία κωδικού στο υποκατάστατο εύρος.
/// (Η δημιουργία `char` στην περιοχή αντικατάστασης είναι UB.) Το αποτέλεσμα είναι έγκυρο [generalized UTF-8] αλλά δεν ισχύει UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics εάν το buffer δεν είναι αρκετά μεγάλο.
/// Ένα buffer μήκους τεσσάρων είναι αρκετά μεγάλο για να κωδικοποιεί οποιοδήποτε `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Κωδικοποιεί μια πρώτη τιμή u32 ως UTF-16 στο παρεχόμενο buffer `u16` και, στη συνέχεια, επιστρέφει το υποσύνολο του buffer που περιέχει τον κωδικοποιημένο χαρακτήρα.
///
///
/// Σε αντίθεση με το `char::encode_utf16`, αυτή η μέθοδος χειρίζεται επίσης σημεία κωδικού στο υποκατάστατο εύρος.
/// (Η δημιουργία `char` στην περιοχή αντικατάστασης είναι UB.)
///
/// # Panics
///
/// Panics εάν το buffer δεν είναι αρκετά μεγάλο.
/// Ένα buffer μήκους 2 είναι αρκετά μεγάλο για να κωδικοποιήσει οποιοδήποτε `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // ΑΣΦΑΛΕΙΑ: κάθε βραχίονας ελέγχει εάν υπάρχουν αρκετά κομμάτια για να γράψετε
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // Το BMP πέφτει
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Τα συμπληρωματικά αεροπλάνα χωρίζονται σε υποκατάστατα.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}