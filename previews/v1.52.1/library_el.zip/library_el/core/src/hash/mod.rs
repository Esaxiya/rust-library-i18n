//! Γενική υποστήριξη κατακερματισμού.
//!
//! Αυτή η ενότητα παρέχει έναν γενικό τρόπο υπολογισμού του [hash] μιας τιμής.
//! Τα καλύμματα χρησιμοποιούνται πιο συχνά με τα [`HashMap`] και [`HashSet`].
//!
//! [hash]: https://en.wikipedia.org/wiki/Hash_function
//! [`HashMap`]: ../../std/collections/struct.HashMap.html
//! [`HashSet`]: ../../std/collections/struct.HashSet.html
//!
//! Ο απλούστερος τρόπος για να δημιουργήσετε έναν τύπο κατακερματισμού είναι να χρησιμοποιήσετε το `#[derive(Hash)]`:
//!
//! # Examples
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! #[derive(Hash)]
//! struct Person {
//!     id: u32,
//!     name: String,
//!     phone: u64,
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert!(calculate_hash(&person1) != calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```
//!
//! Εάν χρειάζεστε περισσότερο έλεγχο σχετικά με τον τρόπο κατακερματισμού μιας τιμής, πρέπει να εφαρμόσετε το [`Hash`] trait:
//!
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! struct Person {
//!     id: u32,
//!     # #[allow(dead_code)]
//!     name: String,
//!     phone: u64,
//! }
//!
//! impl Hash for Person {
//!     fn hash<H: Hasher>(&self, state: &mut H) {
//!         self.id.hash(state);
//!         self.phone.hash(state);
//!     }
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert_eq!(calculate_hash(&person1), calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::marker;

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use self::sip::SipHasher;

#[unstable(feature = "hashmap_internals", issue = "none")]
#[allow(deprecated)]
#[doc(hidden)]
pub use self::sip::SipHasher13;

mod sip;

/// Τύπος κατακερματισμού.
///
/// Οι τύποι που εφαρμόζουν το `Hash` είναι σε θέση να «επεξεργαστούν» με μια παρουσία του [`Hasher`].
///
/// ## Εφαρμογή `Hash`
///
/// Μπορείτε να αντλήσετε `Hash` με `#[derive(Hash)]` εάν όλα τα πεδία εφαρμόζουν `Hash`.
/// Το κατακερματισμό που προκύπτει θα είναι ο συνδυασμός των τιμών από την κλήση [`hash`] σε κάθε πεδίο.
///
/// ```
/// #[derive(Hash)]
/// struct Rustacean {
///     name: String,
///     country: String,
/// }
/// ```
///
/// Εάν χρειάζεστε περισσότερο έλεγχο σχετικά με τον τρόπο κατακερματισμού μιας τιμής, μπορείτε φυσικά να εφαρμόσετε μόνοι σας το `Hash` trait:
///
/// ```
/// use std::hash::{Hash, Hasher};
///
/// struct Person {
///     id: u32,
///     name: String,
///     phone: u64,
/// }
///
/// impl Hash for Person {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         self.id.hash(state);
///         self.phone.hash(state);
///     }
/// }
/// ```
///
/// ## `Hash` και `Eq`
///
/// Κατά την εφαρμογή τόσο των `Hash` όσο και των [`Eq`], είναι σημαντικό να ισχύει η ακόλουθη ιδιότητα:
///
/// ```text
/// k1 == k2 -> hash(k1) == hash(k2)
/// ```
///
/// Με άλλα λόγια, εάν δύο πλήκτρα είναι ίδια, οι κατακερματισμοί τους πρέπει επίσης να είναι ίσοι.
/// [`HashMap`] και [`HashSet`] και οι δύο βασίζονται σε αυτήν τη συμπεριφορά.
///
/// Ευτυχώς, δεν θα χρειαστεί να ανησυχείτε για τη διατήρηση αυτής της ιδιότητας κατά την παραγωγή των [`Eq`] και `Hash` με `#[derive(PartialEq, Eq, Hash)]`.
///
///
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [`hash`]: Hash::hash
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hash {
    /// Τροφοδοτεί αυτήν την τιμή στο δεδομένο [`Hasher`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// 7920.hash(&mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn hash<H: Hasher>(&self, state: &mut H);

    /// Τροφοδοτεί ένα κομμάτι αυτού του τύπου στο δεδομένο [`Hasher`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let numbers = [6, 28, 496, 8128];
    /// Hash::hash_slice(&numbers, &mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "hash_slice", since = "1.3.0")]
    fn hash_slice<H: Hasher>(data: &[Self], state: &mut H)
    where
        Self: Sized,
    {
        for piece in data {
            piece.hash(state);
        }
    }
}

// Ξεχωριστή ενότητα για επανεξαγωγή της μακροεντολής `Hash` από prelude χωρίς το trait `Hash`.
pub(crate) mod macros {
    /// Παράγει μακροεντολή που δημιουργεί ένα impl του trait `Hash`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Hash($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Hash;

/// Ένα trait για κατακερματισμό μιας αυθαίρετης ροής byte.
///
/// Οι εμφανίσεις του `Hasher` αντιπροσωπεύουν συνήθως κατάσταση που αλλάζει κατά την κατακερματισμό δεδομένων.
///
/// `Hasher` παρέχει μια αρκετά βασική διεπαφή για την ανάκτηση του παραγόμενου κατακερματισμού (με [`finish`]), και τη σύνταξη ακέραιων αριθμών καθώς και φέτες byte σε μια παρουσία (με [`write`] και [`write_u8`] κ.λπ.).
/// Τις περισσότερες φορές, οι παρουσίες `Hasher` χρησιμοποιούνται σε συνδυασμό με το [`Hash`] trait.
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::Hasher;
///
/// let mut hasher = DefaultHasher::new();
///
/// hasher.write_u32(1989);
/// hasher.write_u8(11);
/// hasher.write_u8(9);
/// hasher.write(b"Huh?");
///
/// println!("Hash is {:x}!", hasher.finish());
/// ```
///
/// [`finish`]: Hasher::finish
/// [`write`]: Hasher::write
/// [`write_u8`]: Hasher::write_u8
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hasher {
    /// Επιστρέφει την τιμή κατακερματισμού για τις τιμές που έχουν γραφτεί μέχρι στιγμής.
    ///
    /// Παρά το όνομά της, η μέθοδος δεν επαναφέρει την εσωτερική κατάσταση του hasher.
    /// Τα πρόσθετα [`write`] θα συνεχίσουν από την τρέχουσα τιμή.
    /// Εάν πρέπει να ξεκινήσετε μια νέα τιμή κατακερματισμού, θα πρέπει να δημιουργήσετε ένα νέο hasher.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// hasher.write(b"Cool!");
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    ///
    /// [`write`]: Hasher::write
    #[stable(feature = "rust1", since = "1.0.0")]
    fn finish(&self) -> u64;

    /// Γράφει ορισμένα δεδομένα σε αυτό το `Hasher`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let data = [0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef];
    ///
    /// hasher.write(&data);
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write(&mut self, bytes: &[u8]);

    /// Γράφει ένα μόνο `u8` σε αυτό το hasher.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u8(&mut self, i: u8) {
        self.write(&[i])
    }
    /// Γράφει ένα μόνο `u16` σε αυτό το hasher.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u16(&mut self, i: u16) {
        self.write(&i.to_ne_bytes())
    }
    /// Γράφει ένα μόνο `u32` σε αυτό το hasher.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u32(&mut self, i: u32) {
        self.write(&i.to_ne_bytes())
    }
    /// Γράφει ένα μόνο `u64` σε αυτό το hasher.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u64(&mut self, i: u64) {
        self.write(&i.to_ne_bytes())
    }
    /// Γράφει ένα μόνο `u128` σε αυτό το hasher.
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_u128(&mut self, i: u128) {
        self.write(&i.to_ne_bytes())
    }
    /// Γράφει ένα μόνο `usize` σε αυτό το hasher.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_usize(&mut self, i: usize) {
        self.write(&i.to_ne_bytes())
    }

    /// Γράφει ένα μόνο `i8` σε αυτό το hasher.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i8(&mut self, i: i8) {
        self.write_u8(i as u8)
    }
    /// Γράφει ένα μόνο `i16` σε αυτό το hasher.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i16(&mut self, i: i16) {
        self.write_u16(i as u16)
    }
    /// Γράφει ένα μόνο `i32` σε αυτό το hasher.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i32(&mut self, i: i32) {
        self.write_u32(i as u32)
    }
    /// Γράφει ένα μόνο `i64` σε αυτό το hasher.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i64(&mut self, i: i64) {
        self.write_u64(i as u64)
    }
    /// Γράφει ένα μόνο `i128` σε αυτό το hasher.
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_i128(&mut self, i: i128) {
        self.write_u128(i as u128)
    }
    /// Γράφει ένα μόνο `isize` σε αυτό το hasher.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_isize(&mut self, i: isize) {
        self.write_usize(i as usize)
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<H: Hasher + ?Sized> Hasher for &mut H {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

/// Ένα trait για τη δημιουργία παρουσιών του [`Hasher`].
///
/// Ένα `BuildHasher` χρησιμοποιείται συνήθως (π.χ. από το [`HashMap`]) για τη δημιουργία ["Hasher"] για κάθε κλειδί έτσι ώστε να έχουν κατακερματιστεί ανεξάρτητα το ένα από το άλλο, καθώς το ["Hasher" περιέχει κατάσταση.
///
///
/// Για κάθε παρουσία του `BuildHasher`, το ["Hasher"] που δημιουργήθηκε από το [`build_hasher`] πρέπει να είναι ίδιο.
/// Δηλαδή, εάν η ίδια ροή byte τροφοδοτείται σε κάθε hasher, θα δημιουργηθεί επίσης η ίδια έξοδος.
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::RandomState;
/// use std::hash::{BuildHasher, Hasher};
///
/// let s = RandomState::new();
/// let mut hasher_1 = s.build_hasher();
/// let mut hasher_2 = s.build_hasher();
///
/// hasher_1.write_u32(8128);
/// hasher_2.write_u32(8128);
///
/// assert_eq!(hasher_1.finish(), hasher_2.finish());
/// ```
///
/// [`build_hasher`]: BuildHasher::build_hasher
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub trait BuildHasher {
    /// Τύπος του hasher που θα δημιουργηθεί.
    #[stable(since = "1.7.0", feature = "build_hasher")]
    type Hasher: Hasher;

    /// Δημιουργεί ένα νέο hasher.
    ///
    /// Κάθε κλήση στο `build_hasher` στην ίδια παρουσία πρέπει να παράγει πανομοιότυπα ["Hasher"] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::RandomState;
    /// use std::hash::BuildHasher;
    ///
    /// let s = RandomState::new();
    /// let new_s = s.build_hasher();
    /// ```
    #[stable(since = "1.7.0", feature = "build_hasher")]
    fn build_hasher(&self) -> Self::Hasher;
}

/// Χρησιμοποιείται για τη δημιουργία μιας προεπιλεγμένης παρουσίας [`BuildHasher`] για τύπους που εφαρμόζουν [`Hasher`] και [`Default`].
///
/// `BuildHasherDefault<H>` μπορεί να χρησιμοποιηθεί όταν ένας τύπος `H` εφαρμόζει [`Hasher`] και [`Default`] και χρειάζεστε μια αντίστοιχη παρουσία [`BuildHasher`], αλλά καμία δεν έχει οριστεί.
///
///
/// Οποιοδήποτε `BuildHasherDefault` είναι [zero-sized].Μπορεί να δημιουργηθεί με [`default`][method.default].
/// Όταν χρησιμοποιείτε το `BuildHasherDefault` με [`HashMap`] ή [`HashSet`], αυτό δεν χρειάζεται να γίνει, καθώς εφαρμόζουν οι ίδιες κατάλληλες παρουσίες [`Default`].
///
/// # Examples
///
/// Χρησιμοποιώντας το `BuildHasherDefault` για να καθορίσετε ένα προσαρμοσμένο [`BuildHasher`] για
/// [`HashMap`]:
///
/// ```
/// use std::collections::HashMap;
/// use std::hash::{BuildHasherDefault, Hasher};
///
/// #[derive(Default)]
/// struct MyHasher;
///
/// impl Hasher for MyHasher {
///     fn write(&mut self, bytes: &[u8]) {
///         // Ο αλγόριθμος κατακερματισμού σας πηγαίνει εδώ!
///        unimplemented!()
///     }
///
///     fn finish(&self) -> u64 {
///         // Ο αλγόριθμος κατακερματισμού σας πηγαίνει εδώ!
///         unimplemented!()
///     }
/// }
///
/// type MyBuildHasher = BuildHasherDefault<MyHasher>;
///
/// let hash_map = HashMap::<u32, u32, MyBuildHasher>::default();
/// ```
///
/// [method.default]: BuildHasherDefault::default
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [zero-sized]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#zero-sized-types-zsts
///
///
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub struct BuildHasherDefault<H>(marker::PhantomData<H>);

#[stable(since = "1.9.0", feature = "core_impl_debug")]
impl<H> fmt::Debug for BuildHasherDefault<H> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("BuildHasherDefault")
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H: Default + Hasher> BuildHasher for BuildHasherDefault<H> {
    type Hasher = H;

    fn build_hasher(&self) -> H {
        H::default()
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Clone for BuildHasherDefault<H> {
    fn clone(&self) -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Default for BuildHasherDefault<H> {
    fn default() -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> PartialEq for BuildHasherDefault<H> {
    fn eq(&self, _other: &BuildHasherDefault<H>) -> bool {
        true
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> Eq for BuildHasherDefault<H> {}

mod impls {
    use crate::mem;
    use crate::slice;

    use super::*;

    macro_rules! impl_write {
        ($(($ty:ident, $meth:ident),)*) => {$(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for $ty {
                #[inline]
                fn hash<H: Hasher>(&self, state: &mut H) {
                    state.$meth(*self)
                }

                #[inline]
                fn hash_slice<H: Hasher>(data: &[$ty], state: &mut H) {
                    let newlen = data.len() * mem::size_of::<$ty>();
                    let ptr = data.as_ptr() as *const u8;
                    // ΑΣΦΑΛΕΙΑ: Το `ptr` είναι έγκυρο και ευθυγραμμισμένο, καθώς αυτή η μακροεντολή χρησιμοποιείται μόνο
                    // για αριθμητικά πρωτόγονα που δεν έχουν επένδυση.
                    // Το νέο κομμάτι εκτείνεται μόνο σε `data` και δεν μεταλλάσσεται ποτέ και το συνολικό του μέγεθος είναι το ίδιο με το αρχικό `data`, οπότε δεν μπορεί να είναι πάνω από `isize::MAX`.
                    //
                    state.write(unsafe { slice::from_raw_parts(ptr, newlen) })
                }
            }
        )*}
    }

    impl_write! {
        (u8, write_u8),
        (u16, write_u16),
        (u32, write_u32),
        (u64, write_u64),
        (usize, write_usize),
        (i8, write_i8),
        (i16, write_i16),
        (i32, write_i32),
        (i64, write_i64),
        (isize, write_isize),
        (u128, write_u128),
        (i128, write_i128),
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for bool {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u8(*self as u8)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for char {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u32(*self as u32)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for str {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write(self.as_bytes());
            state.write_u8(0xff)
        }
    }

    #[stable(feature = "never_hash", since = "1.29.0")]
    impl Hash for ! {
        #[inline]
        fn hash<H: Hasher>(&self, _: &mut H) {
            *self
        }
    }

    macro_rules! impl_hash_tuple {
        () => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for () {
                #[inline]
                fn hash<H: Hasher>(&self, _state: &mut H) {}
            }
        );

        ( $($name:ident)+) => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl<$($name: Hash),+> Hash for ($($name,)+) where last_type!($($name,)+): ?Sized {
                #[allow(non_snake_case)]
                #[inline]
                fn hash<S: Hasher>(&self, state: &mut S) {
                    let ($(ref $name,)+) = *self;
                    $($name.hash(state);)+
                }
            }
        );
    }

    macro_rules! last_type {
        ($a:ident,) => { $a };
        ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
    }

    impl_hash_tuple! {}
    impl_hash_tuple! { A }
    impl_hash_tuple! { A B }
    impl_hash_tuple! { A B C }
    impl_hash_tuple! { A B C D }
    impl_hash_tuple! { A B C D E }
    impl_hash_tuple! { A B C D E F }
    impl_hash_tuple! { A B C D E F G }
    impl_hash_tuple! { A B C D E F G H }
    impl_hash_tuple! { A B C D E F G H I }
    impl_hash_tuple! { A B C D E F G H I J }
    impl_hash_tuple! { A B C D E F G H I J K }
    impl_hash_tuple! { A B C D E F G H I J K L }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: Hash> Hash for [T] {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            self.len().hash(state);
            Hash::hash_slice(self, state)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *const T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // Λεπτός δείκτης
                    state.write_usize(*self as *const () as usize);
                } else {
                    // Λίπος δείκτης ΑΣΦΑΛΕΙΑ: έχουμε πρόσβαση στη μνήμη που καταλαμβάνεται από το `self`, η οποία είναι εγγυημένη ότι είναι έγκυρη.
                    // Αυτό προϋποθέτει ότι ένας δείκτης λίπους μπορεί να αντιπροσωπεύεται από ένα `(usize, usize)`, το οποίο είναι ασφαλές να κάνετε στο `std`, επειδή αποστέλλεται και διατηρείται σε συγχρονισμό με την εφαρμογή του δείκτη λίπους στο `rustc`.
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // Λεπτός δείκτης
                    state.write_usize(*self as *const () as usize);
                } else {
                    // Λίπος δείκτης ΑΣΦΑΛΕΙΑ: έχουμε πρόσβαση στη μνήμη που καταλαμβάνεται από το `self`, η οποία είναι εγγυημένη ότι είναι έγκυρη.
                    // Αυτό προϋποθέτει ότι ένας δείκτης λίπους μπορεί να αντιπροσωπεύεται από ένα `(usize, usize)`, το οποίο είναι ασφαλές να κάνετε στο `std`, επειδή αποστέλλεται και διατηρείται σε συγχρονισμό με την εφαρμογή του δείκτη λίπους στο `rustc`.
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }
}