//! Πρωτόγονο traits και τύποι που αντιπροσωπεύουν βασικές ιδιότητες τύπων.
//!
//! Οι τύποι Rust μπορούν να ταξινομηθούν με διάφορους χρήσιμους τρόπους ανάλογα με τις εγγενείς τους ιδιότητες.
//! Αυτές οι ταξινομήσεις παρουσιάζονται ως traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Τύποι που μπορούν να μεταφερθούν πέρα από τα όρια νημάτων.
///
/// Αυτό το trait εφαρμόζεται αυτόματα όταν ο μεταγλωττιστής αποφασίσει ότι είναι κατάλληλο.
///
/// Ένα παράδειγμα τύπου "Αποστολή" είναι ο δείκτης [`rc::Rc`][`Rc`] που μετράει την αναφορά.
/// Εάν δύο νήματα επιχειρήσουν να κλωνοποιήσουν [`Rc`] που δείχνουν την ίδια τιμή που μετράται με αναφορά, ενδέχεται να προσπαθήσουν να ενημερώσουν την καταμέτρηση αναφοράς ταυτόχρονα, που είναι [undefined behavior][ub] επειδή το [`Rc`] δεν χρησιμοποιεί ατομικές λειτουργίες.
///
/// Ο ξάδερφος του [`sync::Arc`][arc] χρησιμοποιεί ατομικές λειτουργίες (που προκαλούν κάποια γενικά έξοδα) και έτσι είναι το `Send`.
///
/// Ανατρέξτε στο [the Nomicon](../../nomicon/send-and-sync.html) για περισσότερες λεπτομέρειες.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Τύποι με σταθερό μέγεθος που είναι γνωστοί στο χρόνο μεταγλώττισης.
///
/// Όλες οι παράμετροι τύπου έχουν ένα σιωπηρό όριο `Sized`.Η ειδική σύνταξη `?Sized` μπορεί να χρησιμοποιηθεί για να αφαιρέσει αυτό το δεσμευμένο εάν δεν είναι κατάλληλο.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // δομή FooUse(Foo<[i32]>);//σφάλμα: Το μέγεθος δεν εφαρμόζεται για το [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Η μόνη εξαίρεση είναι ο έμμεσος τύπος `Self` ενός trait.
/// Ένα trait δεν έχει μια έμμεση δέσμευση `Sized`, καθώς αυτό δεν είναι συμβατό με το αντικείμενο [trait], όπου, εξ ορισμού, το trait πρέπει να συνεργαστεί με όλους τους πιθανούς υλοποιητές και έτσι θα μπορούσε να έχει οποιοδήποτε μέγεθος.
///
///
/// Αν και το Rust θα σας επιτρέψει να συνδέσετε το `Sized` σε ένα trait, δεν θα μπορείτε να το χρησιμοποιήσετε για να σχηματίσετε ένα αντικείμενο trait αργότερα:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // ας y: &dyn Bar= &Impl;//σφάλμα: το trait `Bar` δεν μπορεί να γίνει αντικείμενο
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // για προεπιλογή, για παράδειγμα, το οποίο απαιτεί να αξιολογηθεί το `[T]: !Default`
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Τύποι που μπορούν να είναι "unsized" σε δυναμικό μέγεθος.
///
/// Για παράδειγμα, ο τύπος πίνακα μεγέθους `[i8; 2]` εφαρμόζει τα `Unsize<[i8]>` και `Unsize<dyn fmt::Debug>`.
///
/// Όλες οι υλοποιήσεις του `Unsize` παρέχονται αυτόματα από τον μεταγλωττιστή.
///
/// `Unsize` εφαρμόζεται για:
///
/// - `[T; N]` είναι `Unsize<[T]>`
/// - `T` είναι `Unsize<dyn Trait>` όταν `T: Trait`
/// - `Foo<..., T, ...>` είναι `Unsize<Foo<..., U, ...>>` εάν:
///   - `T: Unsize<U>`
///   - Το Foo είναι δομή
///   - Μόνο το τελευταίο πεδίο του `Foo` έχει έναν τύπο που περιλαμβάνει `T`
///   - `T` δεν ανήκει στον τύπο οποιουδήποτε άλλου πεδίου
///   - `Bar<T>: Unsize<Bar<U>>`, εάν το τελευταίο πεδίο του `Foo` έχει τύπο `Bar<T>`
///
/// `Unsize` χρησιμοποιείται μαζί με το [`ops::CoerceUnsized`] για να επιτρέπει σε δοχεία "user-defined" όπως το [`Rc`] να περιέχουν τύπους δυναμικού μεγέθους.
/// Ανατρέξτε στα [DST coercion RFC][RFC982] και [the nomicon entry on coercion][nomicon-coerce] για περισσότερες λεπτομέρειες.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Απαιτείται trait για σταθερές που χρησιμοποιούνται σε αγώνες μοτίβου.
///
/// Οποιοσδήποτε τύπος παράγει `PartialEq` εφαρμόζει αυτόματα αυτό το trait, * ανεξάρτητα από το αν οι παράμετροι τύπου του εφαρμόζουν `Eq`.
///
/// Εάν ένα στοιχείο `const` περιέχει κάποιο τύπο που δεν εφαρμόζει αυτό το trait, τότε αυτός ο τύπος είτε το (1.) δεν εφαρμόζει το `PartialEq` (που σημαίνει ότι η σταθερά δεν θα παράσχει τη συγκεκριμένη μέθοδο σύγκρισης, την οποία η παραγωγή κώδικα υποθέτει ότι είναι διαθέσιμη), ή το (2.) που εφαρμόζει *το δικό του* έκδοση του `PartialEq` (η οποία υποθέτουμε ότι δεν συμμορφώνεται με σύγκριση δομικής-ισότητας).
///
///
/// Σε ένα από τα δύο παραπάνω σενάρια, απορρίπτουμε τη χρήση μιας τέτοιας σταθεράς σε μια αντιστοίχιση μοτίβου.
///
/// Δείτε επίσης τα [structural match RFC][RFC1445] και [issue 63438] που οδήγησαν στη μετάβαση από τη σχεδίαση που βασίζεται σε χαρακτηριστικά σε αυτό το trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Απαιτείται trait για σταθερές που χρησιμοποιούνται σε αγώνες μοτίβου.
///
/// Οποιοσδήποτε τύπος προέρχεται `Eq` εφαρμόζει αυτόματα αυτό το trait, * ανεξάρτητα από το αν οι παράμετροι τύπου του εφαρμόζουν `Eq`.
///
/// Αυτό είναι ένα hack για να επιλύσουμε έναν περιορισμό στο σύστημα τύπων μας.
///
/// # Background
///
/// Θέλουμε να απαιτήσουμε ότι οι τύποι const που χρησιμοποιούνται σε αντιστοιχίες μοτίβων έχουν το χαρακτηριστικό `#[derive(PartialEq, Eq)]`.
///
/// Σε έναν πιο ιδανικό κόσμο, θα μπορούσαμε να ελέγξουμε αυτήν την απαίτηση ελέγχοντας απλώς ότι ο συγκεκριμένος τύπος εφαρμόζει τόσο το `StructuralPartialEq` trait *όσο και το*`Eq` trait.
/// Ωστόσο, μπορείτε να έχετε ADT που *κάνουν*`derive(PartialEq, Eq)`, και να είναι μια περίπτωση που θέλουμε να δέχεται ο μεταγλωττιστής, αλλά ο τύπος της σταθεράς αποτυγχάνει να εφαρμόσει το `Eq`.
///
/// Δηλαδή, μια περίπτωση όπως αυτή:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Το πρόβλημα στον παραπάνω κώδικα είναι ότι το `Wrap<fn(&())>` δεν εφαρμόζει το `PartialEq`, ούτε το `Eq`, επειδή "για <" a> fn(&'a _)` does not implement those traits.)
///
/// Επομένως, δεν μπορούμε να βασιστούμε σε αφελές έλεγχο για `StructuralPartialEq` και απλώς `Eq`.
///
/// Για να επιλύσουμε αυτό το πρόβλημα, χρησιμοποιούμε δύο ξεχωριστά traits που εγχέονται από καθένα από τα δύο παράγωγα (`#[derive(PartialEq)]` και `#[derive(Eq)]`) και ελέγχουμε ότι και οι δύο είναι παρόντες ως μέρος του ελέγχου δομικών αγώνων.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Τύποι των οποίων οι τιμές μπορούν να αναπαραχθούν απλά αντιγράφοντας bit.
///
/// Από προεπιλογή, οι μεταβλητές συνδέσεις έχουν «μετακίνηση σημασιολογίας».Με άλλα λόγια:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` έχει μετακινηθεί στο `y` και έτσι δεν μπορεί να χρησιμοποιηθεί
///
/// // println! ("{: ?}", x);//σφάλμα: χρήση μετακινημένης τιμής
/// ```
///
/// Ωστόσο, εάν ένας τύπος εφαρμόζει το `Copy`, αντ 'αυτού έχει «αντιγραφή σημασιολογίας»:
///
/// ```
/// // Μπορούμε να αντλήσουμε μια εφαρμογή `Copy`.
/// // `Clone` απαιτείται επίσης, καθώς είναι ένα supertrait του `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` είναι αντίγραφο του `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Είναι σημαντικό να σημειωθεί ότι σε αυτά τα δύο παραδείγματα, η μόνη διαφορά είναι εάν επιτρέπεται η πρόσβαση στο `x` μετά την ανάθεση.
/// Κάτω από την κουκούλα, τόσο ένα αντίγραφο όσο και μια κίνηση μπορεί να οδηγήσουν σε αντιγραφή bit στη μνήμη, αν και αυτό μερικές φορές βελτιστοποιείται.
///
/// ## Πώς μπορώ να εφαρμόσω το `Copy`;
///
/// Υπάρχουν δύο τρόποι για να εφαρμόσετε το `Copy` στον τύπο σας.Το πιο απλό είναι να χρησιμοποιήσετε το `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Μπορείτε επίσης να εφαρμόσετε χειροκίνητα τα `Copy` και `Clone`:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Υπάρχει μια μικρή διαφορά μεταξύ των δύο: η στρατηγική `derive` θα τοποθετήσει επίσης ένα `Copy` δεσμευμένο σε παραμέτρους τύπου, κάτι που δεν είναι πάντα επιθυμητό.
///
/// ## Ποια είναι η διαφορά μεταξύ `Copy` και `Clone`;
///
/// Τα αντίγραφα συμβαίνουν σιωπηρά, για παράδειγμα ως μέρος μιας εκχώρησης `y = x`.Η συμπεριφορά του `Copy` δεν είναι υπερφορτωμένη.είναι πάντα ένα απλό αντίγραφο.
///
/// Η κλωνοποίηση είναι μια ρητή ενέργεια, `x.clone()`.Η εφαρμογή του [`Clone`] μπορεί να παράσχει κάθε είδους συμπεριφορά που απαιτείται για την ασφαλή αναπαραγωγή τιμών.
/// Για παράδειγμα, η εφαρμογή του [`Clone`] για το [`String`] πρέπει να αντιγράψει το buffer με συμβολοσειρά προς τα πάνω στο σωρό.
/// Ένα απλό αντίστροφο αντίγραφο των τιμών [`String`] θα αντιγράψει απλώς τον δείκτη, οδηγώντας σε ένα διπλό ελεύθερο στη γραμμή.
/// Για το λόγο αυτό, το [`String`] είναι [`Clone`] αλλά όχι το `Copy`.
///
/// [`Clone`] είναι ένα supertrait του `Copy`, οπότε ό, τι είναι `Copy` πρέπει επίσης να εφαρμόσει το [`Clone`].
/// Εάν ένας τύπος είναι `Copy`, τότε η εφαρμογή του [`Clone`] χρειάζεται μόνο να επιστρέψει το `*self` (δείτε το παραπάνω παράδειγμα).
///
/// ## Πότε μπορεί ο τύπος μου να είναι `Copy`;
///
/// Ένας τύπος μπορεί να εφαρμόσει `Copy` εάν όλα τα συστατικά του εφαρμόζουν `Copy`.Για παράδειγμα, αυτή η δομή μπορεί να είναι `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Μια δομή μπορεί να είναι `Copy` και το [`i32`] είναι `Copy`, επομένως το `Point` μπορεί να είναι `Copy`.
/// Αντίθετα, σκεφτείτε
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Η δομή `PointList` δεν μπορεί να εφαρμόσει `Copy`, επειδή το [`Vec<T>`] δεν είναι `Copy`.Εάν επιχειρήσουμε να δημιουργήσουμε μια εφαρμογή `Copy`, θα λάβουμε ένα σφάλμα:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Οι κοινόχρηστες αναφορές (`&T`) είναι επίσης `Copy`, οπότε ένας τύπος μπορεί να είναι `Copy`, ακόμα και όταν περιέχει κοινόχρηστες αναφορές τύπων `T` που δεν είναι * `Copy`.
/// Εξετάστε την ακόλουθη δομή, η οποία μπορεί να εφαρμόσει το `Copy`, επειδή διατηρεί μόνο μια *κοινόχρηστη αναφορά* για τον τύπο "Copy" `PointList` από ψηλά:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Πότε *δεν μπορεί* ο τύπος μου να είναι `Copy`;
///
/// Ορισμένοι τύποι δεν μπορούν να αντιγραφούν με ασφάλεια.Για παράδειγμα, η αντιγραφή του `&mut T` θα δημιουργούσε ένα ψευδώνυμο μεταβλητή αναφορά.
/// Η αντιγραφή του [`String`] θα αναπαράγει την ευθύνη για τη διαχείριση του buffer του ["String"], οδηγώντας σε διπλό δωρεάν.
///
/// Γενικεύοντας την τελευταία περίπτωση, οποιοσδήποτε τύπος που εφαρμόζει το [`Drop`] δεν μπορεί να είναι `Copy`, επειδή διαχειρίζεται κάποιο πόρο εκτός από τα δικά του [`size_of::<T>`] byte.
///
/// Εάν προσπαθήσετε να εφαρμόσετε το `Copy` σε δομή ή enum που περιέχει δεδομένα που δεν είναι "Αντιγραφή", θα εμφανιστεί το σφάλμα [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Πότε *πρέπει* ο τύπος μου να είναι `Copy`;
///
/// Σε γενικές γραμμές, εάν ο τύπος _can_ σας εφαρμόζει `Copy`, θα πρέπει.
/// Λάβετε υπόψη, ωστόσο, ότι η εφαρμογή `Copy` αποτελεί μέρος του δημόσιου API του τύπου σας.
/// Εάν ο τύπος μπορεί να γίνει μη-Copy` στο future, θα ήταν συνετό να παραλείψετε την εφαρμογή `Copy` τώρα, για να αποφύγετε μια αλλαγή του API.
///
/// ## Πρόσθετοι εφαρμοστές
///
/// Εκτός από το [implementors listed below][impls], οι ακόλουθοι τύποι εφαρμόζουν επίσης το `Copy`:
///
/// * Τύποι στοιχείων λειτουργίας (δηλαδή, οι διαφορετικοί τύποι που ορίζονται για κάθε συνάρτηση)
/// * Τύποι δείκτη λειτουργίας (π.χ., `fn() -> i32`)
/// * Τύποι συστοιχιών, για όλα τα μεγέθη, εάν ο τύπος αντικειμένου εφαρμόζει επίσης `Copy` (π.χ. `[i32; 123456]`)
/// * Τυπικοί τύποι, εάν κάθε στοιχείο εφαρμόζει επίσης `Copy` (π.χ. `()`, `(i32, bool)`)
/// * Τύποι κλεισίματος, εάν δεν καταγράφουν καμία τιμή από το περιβάλλον ή εάν όλες αυτές οι καταγεγραμμένες τιμές εφαρμόζουν οι ίδιοι το `Copy`.
///   Λάβετε υπόψη ότι οι μεταβλητές που συλλαμβάνονται με κοινή αναφορά εφαρμόζουν πάντα το `Copy` (ακόμα και αν το referent δεν το κάνει), ενώ οι μεταβλητές που συλλαμβάνονται με μεταβλητή αναφορά δεν υλοποιούν ποτέ το `Copy`
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Αυτό επιτρέπει την αντιγραφή ενός τύπου που δεν εφαρμόζει το `Copy` λόγω μη ικανοποιητικών ορίων διάρκειας ζωής (αντιγραφή `A<'_>` όταν μόνο `A<'static>: Copy` και `A<'_>: Clone`).
// Έχουμε αυτό το χαρακτηριστικό εδώ προς το παρόν μόνο επειδή υπάρχουν αρκετές υπάρχουσες εξειδικεύσεις στο `Copy` που υπάρχουν ήδη στην τυπική βιβλιοθήκη και δεν υπάρχει τρόπος να έχουμε αυτήν την συμπεριφορά με ασφάλεια αυτήν τη στιγμή.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Παράγει μακροεντολή που δημιουργεί ένα impl του trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Τύποι για τους οποίους είναι ασφαλές να μοιράζεστε αναφορές μεταξύ νημάτων.
///
/// Αυτό το trait εφαρμόζεται αυτόματα όταν ο μεταγλωττιστής αποφασίσει ότι είναι κατάλληλο.
///
/// Ο ακριβής ορισμός είναι: ένας τύπος `T` είναι [`Sync`] εάν και μόνο εάν το `&T` είναι [`Send`].
/// Με άλλα λόγια, εάν δεν υπάρχει πιθανότητα [undefined behavior][ub] (συμπεριλαμβανομένων των αγώνων δεδομένων) όταν περνάτε αναφορές `&T` μεταξύ νημάτων.
///
/// Όπως θα περίμενε κανείς, πρωτόγονοι τύποι όπως [`u8`] και [`f64`] είναι όλοι [`Sync`], και έτσι είναι απλοί συγκεντρωτικοί τύποι που τους περιέχουν, όπως πλειάδες, δομές και αθροίσματα.
/// Περισσότερα παραδείγματα βασικών τύπων [`Sync`] περιλαμβάνουν τύπους "immutable" όπως `&T` και αυτούς με απλή κληρονομική μεταβλητότητα, όπως [`Box<T>`][box], [`Vec<T>`][vec] και τους περισσότερους άλλους τύπους συλλογής.
///
/// (Οι γενικές παράμετροι πρέπει να είναι [`Sync`] για το κοντέινερ τους να είναι [«Συγχρονισμός»].)
///
/// Μια κάπως εκπληκτική συνέπεια του ορισμού είναι ότι το `&mut T` είναι `Sync` (εάν το `T` είναι `Sync`), παρόλο που φαίνεται ότι μπορεί να παρέχει μη συγχρονισμένη μετάλλαξη.
/// Το κόλπο είναι ότι μια μεταβλητή αναφορά πίσω από μια κοινόχρηστη αναφορά (δηλαδή, `& &mut T`) γίνεται μόνο για ανάγνωση, σαν να ήταν `& &T`.
/// Ως εκ τούτου, δεν υπάρχει κίνδυνος κούρσας δεδομένων.
///
/// Οι τύποι που δεν είναι `Sync` είναι εκείνοι που έχουν "interior mutability" σε μη ασφαλή μορφή νήματος, όπως [`Cell`][cell] και [`RefCell`][refcell].
/// Αυτοί οι τύποι επιτρέπουν τη μετάλλαξη του περιεχομένου τους ακόμη και μέσω μιας αμετάβλητης, κοινής αναφοράς.
/// Για παράδειγμα, η μέθοδος `set` στο [`Cell<T>`][cell] παίρνει το `&self`, επομένως απαιτεί μόνο κοινόχρηστο [`&Cell<T>`][cell] αναφοράς.
/// Η μέθοδος δεν εκτελεί συγχρονισμό, επομένως το [`Cell`][cell] δεν μπορεί να είναι `Sync`.
///
/// Ένα άλλο παράδειγμα τύπου non-Sync είναι ο δείκτης [`Rc`][rc] που μετράει την αναφορά.
/// Δεδομένης οποιασδήποτε αναφοράς [`&Rc<T>`][rc], μπορείτε να κλωνοποιήσετε ένα νέο [`Rc<T>`][rc], τροποποιώντας τις μετρήσεις αναφοράς με μη ατομικό τρόπο.
///
/// Για περιπτώσεις που κάποιος χρειάζεται εσωτερική μεταβλητότητα χωρίς νήμα, το Rust παρέχει [atomic data types], καθώς και ρητό κλείδωμα μέσω [`sync::Mutex`][mutex] και [`sync::RwLock`][rwlock].
/// Αυτοί οι τύποι διασφαλίζουν ότι οποιαδήποτε μετάλλαξη δεν μπορεί να προκαλέσει αγώνες δεδομένων, επομένως οι τύποι είναι `Sync`.
/// Ομοίως, το [`sync::Arc`][arc] παρέχει ένα ανάλογο ασφαλούς νήματος του [`Rc`][rc].
///
/// Οποιοσδήποτε τύπος με εσωτερική μεταβλητότητα πρέπει επίσης να χρησιμοποιεί το περιτύλιγμα [`cell::UnsafeCell`][unsafecell] γύρω από το value(s) το οποίο μπορεί να μεταλλαχθεί μέσω μιας κοινής αναφοράς.
/// Αν δεν το κάνετε αυτό είναι [undefined behavior][ub].
/// Για παράδειγμα, το [transmute`][transmute]-ing από `&T` έως `&mut T` δεν είναι έγκυρο.
///
/// Δείτε το [the Nomicon][nomicon-send-and-sync] για περισσότερες λεπτομέρειες σχετικά με το `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): Μόλις υποστηρίξετε την προσθήκη σημειώσεων στο `rustc_on_unimplemented` προσγειώνεται σε beta και έχει επεκταθεί για να ελέγξετε αν ένα κλείσιμο βρίσκεται οπουδήποτε στην αλυσίδα απαιτήσεων, επεκτείνετε το ως τέτοιο (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Ο τύπος μηδενικού μεγέθους χρησιμοποιείται για την επισήμανση των πραγμάτων που "act like" κατέχουν `T`.
///
/// Η προσθήκη ενός πεδίου `PhantomData<T>` στον τύπο σας λέει στον μεταγλωττιστή ότι ο τύπος σας ενεργεί σαν να αποθηκεύει μια τιμή τύπου `T`, παρόλο που δεν είναι πραγματικά.
/// Αυτές οι πληροφορίες χρησιμοποιούνται κατά τον υπολογισμό ορισμένων ιδιοτήτων ασφαλείας.
///
/// Για μια πιο εμπεριστατωμένη εξήγηση του τρόπου χρήσης του `PhantomData<T>`, ανατρέξτε στο [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Μια άθλια νότα 👻👻👻
///
/// Αν και και οι δύο έχουν τρομακτικά ονόματα, οι `PhantomData` και οι «φανταστικοί τύποι» σχετίζονται, αλλά δεν είναι πανομοιότυποι.Μια παράμετρος τύπου φαντάσματος είναι απλά μια παράμετρος τύπου που δεν χρησιμοποιείται ποτέ.
/// Στο Rust, αυτό συχνά αναγκάζει τον μεταγλωττιστή να παραπονιέται και η λύση είναι να προσθέσετε μια χρήση "dummy" ως `PhantomData`.
///
/// # Examples
///
/// ## Παράμετροι διάρκειας ζωής που δεν χρησιμοποιούνται
///
/// Ίσως η πιο συνηθισμένη περίπτωση χρήσης για το `PhantomData` είναι μια δομή που έχει μια αχρησιμοποίητη παράμετρο ζωής, συνήθως ως μέρος κάποιου μη ασφαλούς κώδικα.
/// Για παράδειγμα, εδώ είναι μια δομή `Slice` που έχει δύο δείκτες του τύπου `*const T`, πιθανώς να δείχνει σε έναν πίνακα κάπου:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Η πρόθεση είναι ότι τα υποκείμενα δεδομένα ισχύουν μόνο για τη διάρκεια ζωής `'a`, επομένως το `Slice` δεν πρέπει να υπερβεί το `'a`.
/// Ωστόσο, αυτή η πρόθεση δεν εκφράζεται στον κώδικα, καθώς δεν υπάρχουν χρήσεις του `'a` διάρκειας ζωής και ως εκ τούτου δεν είναι σαφές σε ποια δεδομένα εφαρμόζεται.
/// Μπορούμε να το διορθώσουμε λέγοντας στον μεταγλωττιστή να ενεργήσει *σαν* η δομή `Slice` να περιέχει μια αναφορά `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Αυτό επίσης με τη σειρά του απαιτεί τον σχολιασμό `T: 'a`, υποδεικνύοντας ότι τυχόν αναφορές στο `T` είναι έγκυρες καθ 'όλη τη διάρκεια ζωής `'a`.
///
/// Όταν ξεκινάτε ένα `Slice` απλώς παρέχετε την τιμή `PhantomData` για το πεδίο `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Παράμετροι τύπου που δεν χρησιμοποιούνται
///
/// Μερικές φορές συμβαίνει ότι έχετε αχρησιμοποίητες παραμέτρους τύπου που υποδεικνύουν σε ποιον τύπο δεδομένων είναι μια δομή "tied", παρόλο που αυτά τα δεδομένα δεν βρίσκονται στην ίδια την δομή.
/// Εδώ είναι ένα παράδειγμα όπου αυτό προκύπτει με το [FFI].
/// Η ξένη διεπαφή χρησιμοποιεί λαβές τύπου `*mut ()` για να αναφέρεται σε τιμές Rust διαφορετικών τύπων.
/// Παρακολουθούμε τον τύπο Rust χρησιμοποιώντας μια παράμετρο τύπου φαντασμάτων στο struct `ExternalResource` που τυλίγει μια λαβή.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Ιδιοκτησιακό καθεστώς και έλεγχος πτώσης
///
/// Η προσθήκη ενός πεδίου τύπου `PhantomData<T>` δηλώνει ότι ο τύπος σας κατέχει δεδομένα του τύπου `T`.Αυτό με τη σειρά του υποδηλώνει ότι όταν ο τύπος σας πέσει, μπορεί να πέσει μία ή περισσότερες εμφανίσεις του τύπου `T`.
/// Αυτό έχει σχέση με την ανάλυση [drop check] του μεταγλωττιστή Rust.
///
/// Εάν η δομή σας στην πραγματικότητα δεν *κατέχει* τα δεδομένα του τύπου `T`, είναι καλύτερα να χρησιμοποιήσετε έναν τύπο αναφοράς, όπως `PhantomData<&'a T>` (ideally) ή `PhantomData<*const T>` (εάν δεν ισχύει διάρκεια ζωής), ώστε να μην υποδεικνύεται η ιδιοκτησία.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Ο μεταγλωττιστής-εσωτερικός trait χρησιμοποιείται για να υποδείξει τον τύπο των διακριτών του enum.
///
/// Αυτό το trait εφαρμόζεται αυτόματα για κάθε τύπο και δεν προσθέτει καμία εγγύηση στο [`mem::Discriminant`].
/// Είναι **απροσδιόριστη συμπεριφορά** για μετάδοση μεταξύ `DiscriminantKind::Discriminant` και `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Ο τύπος του διακριτικού, ο οποίος πρέπει να ικανοποιεί το trait bounds που απαιτείται από το `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Ο μεταγλωττιστής-εσωτερικός trait χρησιμοποιείται για να προσδιορίσει εάν ένας τύπος περιέχει οποιοδήποτε `UnsafeCell` εσωτερικά, αλλά όχι μέσω έμμεσης.
///
/// Αυτό επηρεάζει, για παράδειγμα, εάν ένα `static` αυτού του τύπου τοποθετείται σε στατική μνήμη μόνο για ανάγνωση ή εγγράψιμη στατική μνήμη.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Τύποι που μπορούν να μετακινηθούν με ασφάλεια αφού καρφιτσωθούν.
///
/// Το ίδιο το Rust δεν έχει καμία έννοια για ακίνητους τύπους και θεωρεί ότι οι κινήσεις (π.χ. μέσω εκχώρησης ή [`mem::replace`]) είναι πάντα ασφαλείς.
///
/// Ο τύπος [`Pin`][Pin] χρησιμοποιείται αντ 'αυτού για την αποτροπή μετακινήσεων μέσω του συστήματος τύπου.Οι δείκτες `P<T>` τυλιγμένοι στο περιτύλιγμα [`Pin<P<T>>`][Pin] δεν μπορούν να μετακινηθούν από.
/// Ανατρέξτε στην τεκμηρίωση [`pin` module] για περισσότερες πληροφορίες σχετικά με την καρφίτσωμα.
///
/// Η εφαρμογή του `Unpin` trait για `T` καταργεί τους περιορισμούς της καρφώματος από τον τύπο, ο οποίος στη συνέχεια επιτρέπει τη μετακίνηση του `T` από το [`Pin<P<T>>`][Pin] με λειτουργίες όπως το [`mem::replace`].
///
///
/// `Unpin` δεν έχει καμία συνέπεια για μη καρφιτσωμένα δεδομένα.
/// Συγκεκριμένα, το [`mem::replace`] μετακινεί ευτυχώς τα δεδομένα `!Unpin` (λειτουργεί για οποιοδήποτε `&mut T`, όχι μόνο όταν το `T: Unpin`).
/// Ωστόσο, δεν μπορείτε να χρησιμοποιήσετε το [`mem::replace`] σε δεδομένα τυλιγμένα μέσα σε ένα [`Pin<P<T>>`][Pin], επειδή δεν μπορείτε να λάβετε το `&mut T` που χρειάζεστε για αυτό, και *αυτό* κάνει αυτό το σύστημα να λειτουργεί.
///
/// Αυτό, για παράδειγμα, μπορεί να γίνει μόνο σε τύπους που εφαρμόζουν το `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Χρειαζόμαστε μια μεταβλητή αναφορά για να καλέσουμε το `mem::replace`.
/// // Μπορούμε να λάβουμε μια τέτοια αναφορά με το (implicitly) επικαλούμενο το `Pin::deref_mut`, αλλά αυτό είναι δυνατό μόνο επειδή το `String` εφαρμόζει το `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Αυτό το trait εφαρμόζεται αυτόματα για σχεδόν κάθε τύπο.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Ένας τύπος δείκτη που δεν εφαρμόζει το `Unpin`.
///
/// Εάν ένας τύπος περιέχει `PhantomPinned`, δεν θα εφαρμόσει το `Unpin` από προεπιλογή.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Εφαρμογές του `Copy` για πρωτόγονους τύπους.
///
/// Οι υλοποιήσεις που δεν μπορούν να περιγραφούν στο Rust εφαρμόζονται στο `traits::SelectionContext::copy_clone_conditions()` στο `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Οι κοινόχρηστες αναφορές μπορούν να αντιγραφούν, αλλά οι μεταβλητές αναφορές *δεν μπορούν*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}