//! Αποκωδικοποιεί μια τιμή κυμαινόμενου σημείου σε μεμονωμένα μέρη και εύρη σφαλμάτων.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Αποκωδικοποιημένη πεπερασμένη τιμή, έτσι ώστε:
///
/// - Η αρχική τιμή ισούται με `mant * 2^exp`.
///
/// - Οποιοσδήποτε αριθμός από `(mant - minus)*2^exp` έως `(mant + plus)* 2^exp` στρογγυλοποιείται στην αρχική τιμή.
/// Η γκάμα συμπεριλαμβάνεται μόνο όταν το `inclusive` είναι `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Η κλίμακα μάντισσα.
    pub mant: u64,
    /// Το χαμηλότερο εύρος σφαλμάτων.
    pub minus: u64,
    /// Το ανώτερο εύρος σφαλμάτων.
    pub plus: u64,
    /// Ο κοινός εκθέτης στη βάση 2.
    pub exp: i16,
    /// Αληθές όταν το εύρος σφαλμάτων περιλαμβάνει.
    ///
    /// Στο IEEE 754, αυτό ισχύει όταν η αρχική μάντισσα ήταν ομοιόμορφη.
    pub inclusive: bool,
}

/// Αποκωδικοποιημένη τιμή χωρίς υπογραφή.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Άπειρα, είτε θετικά είτε αρνητικά.
    Infinite,
    /// Μηδέν, είτε θετικό είτε αρνητικό.
    Zero,
    /// Πεπερασμένοι αριθμοί με περαιτέρω αποκωδικοποιημένα πεδία.
    Finite(Decoded),
}

/// Ένας τύπος κινητής υποδιαστολής που μπορεί να «αποκωδικοποιήσει» δ.
pub trait DecodableFloat: RawFloat + Copy {
    /// Η ελάχιστη θετική κανονικοποιημένη τιμή.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Επιστρέφει ένα σύμβολο (true όταν είναι αρνητικό) και την τιμή `FullDecoded` από τον δεδομένο αριθμό κινούμενου σημείου.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // γείτονες: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode διατηρεί πάντα τον εκθέτη, οπότε η μάντισσα είναι κλιμακωτή για μη φυσιολογικά.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // γείτονες: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // όπου maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // γείτονες: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}