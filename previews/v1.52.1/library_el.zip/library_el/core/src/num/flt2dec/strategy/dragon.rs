//! Σχεδόν άμεση (αλλά ελαφρώς βελτιστοποιημένη) μετάφραση Rust του Σχήματος 3 του "Εκτύπωση αριθμών κυμαινόμενου σημείου γρήγορα και με ακρίβεια" [^ 1].
//!
//!
//! [^1]: Burger, RG and Dybvig, RK 1996. Εκτύπωση αριθμών κινητής υποδιαστολής
//!   γρήγορα και με ακρίβεια.SIGPLAN Όχι.31, 5 (Μάιος 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// προκαθορισμένοι πίνακες του «Digit`s για 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// χρησιμοποιήσιμο μόνο όταν `x < 16 * scale` Το `scaleN` πρέπει να είναι `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Η πιο σύντομη εφαρμογή λειτουργίας για το Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // ο αριθμός `v` προς μορφοποίηση είναι γνωστό ότι είναι:
    // - ίσο με `mant * 2^exp`;
    // - πριν από το `(mant - 2 *minus)* 2^exp` στον αρχικό τύπο・και
    // - ακολουθούμενο από `(mant + 2 *plus)* 2^exp` στον αρχικό τύπο.
    //
    // Προφανώς, τα `minus` και `plus` δεν μπορούν να είναι μηδέν.(για άπειρα, χρησιμοποιούμε τιμές εκτός εύρους.) Υποθέτουμε επίσης ότι δημιουργείται τουλάχιστον ένα ψηφίο, δηλαδή, το `mant` δεν μπορεί να είναι επίσης μηδέν.
    //
    // Αυτό σημαίνει επίσης ότι οποιοσδήποτε αριθμός μεταξύ `low = (mant - minus)*2^exp` και `high = (mant + plus)* 2^exp` θα αντιστοιχιστεί σε αυτόν τον ακριβή αριθμό κινούμενου σημείου, με όρια που περιλαμβάνονται όταν το αρχικό mantissa ήταν ομοιόμορφο (δηλαδή, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` είναι `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // εκτιμήστε το `k_0` από τις αρχικές εισόδους που ικανοποιούν το `10^(k_0-1) < high <= 10^(k_0+1)`.
    // το σφιχτό `k` που ικανοποιεί το `10^(k-1) < high <= 10^k` υπολογίζεται αργότερα.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // μετατρέψτε το `{mant, plus, minus} * 2^exp` στην κλασματική μορφή έτσι ώστε:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // διαιρέστε το `mant` με το `10^k`.τώρα `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // διόρθωση όταν `mant + plus > scale` (ή `>=`).
    // στην πραγματικότητα δεν τροποποιούμε το `scale`, καθώς μπορούμε να παρακάμψουμε τον αρχικό πολλαπλασιασμό.
    // τώρα `scale < mant + plus <= scale * 10` και είμαστε έτοιμοι να δημιουργήσουμε ψηφία.
    //
    // Σημειώστε ότι το `d[0]` * μπορεί να είναι μηδέν, όταν το `scale - plus < mant < scale`.
    // Σε αυτήν την περίπτωση, η κατάσταση στρογγυλοποίησης (`up` παρακάτω) θα ενεργοποιηθεί αμέσως.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // ισοδυναμεί με κλιμάκωση `scale` έως 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` για δημιουργία ψηφίων.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // αναλλοίωτα, όπου το `d[0..n-1]` είναι ψηφία που έχουν δημιουργηθεί μέχρι στιγμής:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (έτσι `mant / scale < 10`) όπου το `d[i..j]` είναι συντομογραφία για το "d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // δημιουργία ενός ψηφίου: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // Αυτή είναι μια απλοποιημένη περιγραφή του τροποποιημένου αλγορίθμου Dragon.
        // παραλείπονται πολλά ενδιάμεσα παράγωγα και επιχειρήματα πληρότητας για ευκολία.
        //
        // ξεκινήστε με τροποποιημένα αναλλοίωτα, καθώς έχουμε ενημερώσει το `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // Ας υποθέσουμε ότι το `d[0..n-1]` είναι η συντομότερη αναπαράσταση μεταξύ `low` και `high`, δηλαδή, το `d[0..n-1]` ικανοποιεί και τα δύο από τα παρακάτω, αλλά το `d[0..n-2]` δεν:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: ψηφία γύρω από `v`);και
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (το τελευταίο ψηφίο είναι σωστό).
        //
        // η δεύτερη συνθήκη απλοποιείται σε `2 * mant <= scale`.
        // Η επίλυση αναλλοίωτων σε όρους `mant`, `low` και `high` αποδίδει μια απλούστερη έκδοση της πρώτης συνθήκης: `-plus < mant < minus`.
        // από το `-plus < 0 <= mant`, έχουμε τη σωστή συντομότερη αναπαράσταση όταν `mant < minus` και `2 * mant <= scale`.
        // (το πρώτο γίνεται `mant <= minus` όταν το αρχικό mantissa είναι ομοιόμορφο.)
        //
        // όταν το δεύτερο δεν κρατάει («2 * mant> κλίμακα»), πρέπει να αυξήσουμε το τελευταίο ψηφίο.
        // αυτό αρκεί για την αποκατάσταση αυτής της κατάστασης: γνωρίζουμε ήδη ότι η παραγωγή ψηφίων εγγυάται το `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // Σε αυτήν την περίπτωση, η πρώτη συνθήκη γίνεται `-plus < mant - scale < minus`.
        // από το `mant < scale` μετά τη γενιά, έχουμε `scale < mant + plus`.
        // (και πάλι, αυτό γίνεται `scale <= mant + plus` όταν το αρχικό mantissa είναι ομοιόμορφο.)
        //
        // εν συντομία:
        // - σταματήστε και στρίψτε `down` (διατηρήστε τα ψηφία ως έχουν) όταν `mant < minus` (ή `<=`).
        // - σταματήστε και στρίψτε `up` (αύξηση του τελευταίου ψηφίου) όταν `scale < mant + plus` (ή `<=`).
        // - συνεχίστε να δημιουργείτε διαφορετικά.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // έχουμε τη συντομότερη εκπροσώπηση, προχωρήστε στη στρογγυλοποίηση

        // επαναφέρετε τα αμετάβλητα.
        // Αυτό κάνει τον αλγόριθμο να τερματίζεται πάντα: Τα `minus` και `plus` αυξάνονται πάντα, αλλά το `mant` είναι κλιπ modulo `scale` και το `scale` είναι σταθερό.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // η στρογγυλοποίηση γίνεται όταν i) ενεργοποιήθηκε μόνο η συνθήκη στρογγυλοποίησης, ή ii) ενεργοποιήθηκαν και οι δύο συνθήκες και η ισοπαλία προτιμά στρογγυλοποίηση.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // εάν η στρογγυλοποίηση αλλάζει το μήκος, ο εκθέτης πρέπει επίσης να αλλάξει.
        // φαίνεται ότι αυτή η κατάσταση είναι πολύ δύσκολο να ικανοποιηθεί (πιθανώς αδύνατη), αλλά απλώς είμαστε ασφαλείς και συνεπείς εδώ.
        //
        // ΑΣΦΑΛΕΙΑ: αρχικοποιήσαμε αυτήν τη μνήμη παραπάνω.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // ΑΣΦΑΛΕΙΑ: αρχικοποιήσαμε αυτήν τη μνήμη παραπάνω.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Η ακριβής και σταθερή εφαρμογή λειτουργίας για το Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // εκτιμήστε το `k_0` από τις αρχικές εισόδους που ικανοποιούν το `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // διαιρέστε το `mant` με το `10^k`.τώρα `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // διόρθωση όταν `mant + plus >= scale`, όπου `plus / scale = 10^-buf.len() / 2`.
    // Προκειμένου να διατηρήσουμε το bignum σταθερού μεγέθους, χρησιμοποιούμε πραγματικά το `mant + floor(plus) >= scale`.
    // στην πραγματικότητα δεν τροποποιούμε το `scale`, καθώς μπορούμε να παρακάμψουμε τον αρχικό πολλαπλασιασμό.
    // και πάλι με τον συντομότερο αλγόριθμο, το `d[0]` μπορεί να είναι μηδέν αλλά τελικά θα στρογγυλοποιηθεί.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // ισοδυναμεί με κλιμάκωση `scale` έως 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // εάν εργαζόμαστε με τον περιορισμό του τελευταίου ψηφίου, πρέπει να συντομεύσουμε το buffer πριν από την πραγματική απόδοση, προκειμένου να αποφευχθεί η διπλή στρογγυλοποίηση.
    //
    // Σημειώστε ότι πρέπει να μεγεθύνετε το buffer ξανά όταν πραγματοποιηθεί στρογγυλοποίηση!
    let mut len = if k < limit {
        // Ωχ, δεν μπορούμε ούτε να παράγουμε *ένα* ψηφίο.
        // αυτό είναι δυνατό όταν, ας πούμε, έχουμε κάτι σαν το 9.5 και στρογγυλοποιείται στο 10.
        // επιστρέφουμε ένα κενό buffer, με εξαίρεση τη μεταγενέστερη περίπτωση στρογγυλοποίησης που εμφανίζεται όταν `k == limit` και πρέπει να παράγει ακριβώς ένα ψηφίο.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` για δημιουργία ψηφίων.
        // (αυτό μπορεί να είναι ακριβό, οπότε μην τα υπολογίζετε όταν το buffer είναι κενό.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // Τα ακόλουθα ψηφία είναι όλα μηδενικά, σταματάμε εδώ *μην* προσπαθείτε να κάνετε στρογγυλοποίηση!μάλλον, συμπληρώστε τα υπόλοιπα ψηφία.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // ΑΣΦΑΛΕΙΑ: αρχικοποιήσαμε αυτήν τη μνήμη παραπάνω.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // στρογγυλοποίηση αν σταματήσουμε στη μέση των ψηφίων εάν τα ακόλουθα ψηφία είναι ακριβώς 5000 ..., ελέγξτε το προηγούμενο ψηφίο και προσπαθήστε να στρογγυλοποιήσετε στο ζυγό (δηλαδή, αποφύγετε τη στρογγυλοποίηση όταν το προηγούμενο ψηφίο είναι ομοιόμορφο).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // ΑΣΦΑΛΕΙΑ: Το `buf[len-1]` αρχικοποιείται.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // εάν η στρογγυλοποίηση αλλάζει το μήκος, ο εκθέτης πρέπει επίσης να αλλάξει.
        // αλλά μας ζητήθηκε ένας σταθερός αριθμός ψηφίων, οπότε μην αλλάξουμε το buffer ...
        // ΑΣΦΑΛΕΙΑ: αρχικοποιήσαμε αυτήν τη μνήμη παραπάνω.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... εκτός αν μας ζητηθεί η σταθερή ακρίβεια.
            // Πρέπει επίσης να ελέγξουμε ότι, εάν το αρχικό buffer ήταν κενό, το πρόσθετο ψηφίο μπορεί να προστεθεί μόνο όταν `k == limit` (θήκη edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // ΑΣΦΑΛΕΙΑ: αρχικοποιήσαμε αυτήν τη μνήμη παραπάνω.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}