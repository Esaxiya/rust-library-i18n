//! Προσαρμοσμένη εφαρμογή αυθαίρετου αριθμού (bignum) ακριβείας.
//!
//! Αυτό έχει σχεδιαστεί για να αποφεύγει την κατανομή σωρού εις βάρος της μνήμης στοίβας.
//! Ο πιο χρησιμοποιούμενος τύπος bignum, `Big32x40`, περιορίζεται από 32 × 40=1.280 bit και θα διαρκέσει έως και 160 byte μνήμης στοίβας.
//! Αυτό είναι περισσότερο από αρκετό για όλες τις πιθανές πεπερασμένες τιμές `f64`.
//!
//! Κατ 'αρχήν, είναι δυνατόν να έχουμε πολλούς τύπους bignum για διαφορετικές εισόδους, αλλά δεν το κάνουμε για να αποφύγουμε τον κωδικό να φουσκώνει.
//!
//! Κάθε bignum παρακολουθείται για τις πραγματικές χρήσεις, οπότε συνήθως δεν έχει σημασία.
//!

// Αυτή η λειτουργική μονάδα είναι μόνο για dec2flt και flt2dec, και μόνο δημόσια λόγω coretests.
// Δεν προορίζεται να σταθεροποιηθεί ποτέ.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// Αριθμητικές πράξεις που απαιτούνται από τα bignums.
pub trait FullOps: Sized {
    /// Επιστρέφει το `(carry', v')` έτσι ώστε το `carry' * 2^W + v' = self + other + carry`, όπου το `W` είναι ο αριθμός των bit στο `Self`.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// Επιστρέφει το `(carry', v')` έτσι ώστε το `carry'*2^W + v' = self* other + carry`, όπου το `W` είναι ο αριθμός των bit στο `Self`.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// Επιστρέφει το `(carry', v')` έτσι ώστε το `carry'*2^W + v' = self* other + other2 + carry`, όπου το `W` είναι ο αριθμός των bit στο `Self`.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// Επιστρέφει `(quo, rem)` έτσι ώστε `borrow *2^W + self = quo* other + rem` και `0 <= rem < other`, όπου `W` είναι ο αριθμός των bit σε `Self`.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // Αυτό δεν μπορεί να ξεχειλίζει.η έξοδος είναι μεταξύ `0` και `2 * 2^nbits - 1`.
                    // FIXME: θα το βελτιστοποιήσει το LLVM σε ADC ή παρόμοιο;
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // Αυτό δεν μπορεί να ξεχειλίζει.
                    // η έξοδος είναι μεταξύ `0` και `2^nbits * (2^nbits - 1)`.
                    // FIXME: θα το βελτιστοποιήσει το LLVM σε ADC ή παρόμοιο;
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // Αυτό δεν μπορεί να ξεχειλίζει.
                    // η έξοδος είναι μεταξύ `0` και `2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // Αυτό δεν μπορεί να ξεχειλίζει.η έξοδος είναι μεταξύ `0` και `other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // Δείτε το RFC #521 για να το ενεργοποιήσετε.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// Πίνακας δυνάμεων 5 που αντιπροσωπεύονται σε ψηφία.Συγκεκριμένα, η μεγαλύτερη τιμή {u8, u16, u32} που έχει ισχύ πέντε, συν τον αντίστοιχο εκθέτη.
/// Χρησιμοποιείται σε `mul_pow5`.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// Ακεραία αυθαίρετης ακρίβειας εκχωρημένης στοίβας (έως και ορισμένο όριο).
        ///
        /// Αυτό υποστηρίζεται από μια συστοιχία σταθερού μεγέθους δεδομένου τύπου ("digit").
        /// Αν και ο πίνακας δεν είναι πολύ μεγάλος (συνήθως περίπου εκατό byte), η αντιγραφή του απερίσκεπτα μπορεί να οδηγήσει σε επιτυχία.
        ///
        /// Επομένως, αυτό δεν είναι σκόπιμα το `Copy`.
        ///
        /// Όλες οι λειτουργίες είναι διαθέσιμες στα bignums panic σε περίπτωση υπερχείλισης.
        /// Ο καλούντος είναι υπεύθυνος να χρησιμοποιεί αρκετά μεγάλους τύπους bignum.
        pub struct $name {
            /// Ένα συν το όφσετ στο μέγιστο "digit" που χρησιμοποιείται.
            /// Αυτό δεν μειώνεται, επομένως να γνωρίζετε τη σειρά υπολογισμού.
            /// `base[size..]` πρέπει να είναι μηδέν.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` αντιπροσωπεύει το `a + b *2^W + c* 2^(2W) + ...` όπου το `W` είναι ο αριθμός bits στον τύπο ψηφίου.
            base: [$ty; $n],
        }

        impl $name {
            /// Κάνει ένα bignum από ένα ψηφίο.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// Κάνει ένα bignum από την τιμή `u64`.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// Επιστρέφει τα εσωτερικά ψηφία ως φέτα `[a, b, c, ...]` έτσι ώστε η αριθμητική τιμή να είναι `a + b *2^W + c* 2^(2W) + ...` όπου `W` είναι ο αριθμός bit στον τύπο ψηφίου.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// Επιστρέφει το bit «i`-th όπου το bit 0 είναι το λιγότερο σημαντικό.
            /// Με άλλα λόγια, το κομμάτι με βάρος `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// Επιστρέφει το `true` εάν το bignum είναι μηδέν.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// Επιστρέφει τον αριθμό των bit που απαιτούνται για την αναπαράσταση αυτής της τιμής.
            /// Σημειώστε ότι το μηδέν θεωρείται ότι χρειάζεται 0 bit.
            pub fn bit_length(&self) -> usize {
                // Περάστε τα πιο σημαντικά ψηφία που είναι μηδέν.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // Δεν υπάρχουν μη μηδενικά ψηφία, δηλαδή ο αριθμός είναι μηδέν.
                    return 0;
                }
                // Αυτό θα μπορούσε να βελτιστοποιηθεί με αλλαγές leading_zeros() και bit, αλλά μάλλον δεν αξίζει τον κόπο.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// Προσθέτει το `other` στον εαυτό του και επιστρέφει τη δική του μεταβλητή αναφορά.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// Αφαιρεί το `other` από τον εαυτό του και επιστρέφει τη δική του μεταβλητή αναφορά.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// Πολλαπλασιάζεται από το `other` με ψηφίο και επιστρέφει τη δική του μεταβλητή αναφορά.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// Πολλαπλασιάζεται από το `2^bits` και επιστρέφει τη δική του μεταβλητή αναφορά.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // μετατόπιση κατά `digits * digitbits` bits
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // μετατόπιση κατά `bits` bits
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // Το self.base [.. ψηφία] είναι μηδέν, δεν χρειάζεται αλλαγή
                }

                self.size = sz;
                self
            }

            /// Πολλαπλασιάζεται από το `5^e` και επιστρέφει τη δική του μεταβλητή αναφορά.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // Υπάρχουν ακριβώς n μηδενικά που ακολουθούν στο 2 ^ n, και τα μόνα σχετικά μεγέθη ψηφίων είναι οι διαδοχικές δυνάμεις των δύο, οπότε αυτός είναι ο κατάλληλος δείκτης για τον πίνακα.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // Πολλαπλασιάστε με τη μεγαλύτερη μονοψήφια ισχύ όσο το δυνατόν περισσότερο ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... μετά τελειώστε το υπόλοιπο.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// Πολλαπλασιάζεται από τον αριθμό που περιγράφεται από το `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (όπου το `W` είναι ο αριθμός bit στον τύπο ψηφίου) και επιστρέφει τη δική του μεταβλητή αναφορά.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // η εσωτερική ρουτίνα.λειτουργεί καλύτερα όταν aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// Διαιρείται με ένα ψηφίο `other` και επιστρέφει τη δική του μεταβλητή αναφορά *και* το υπόλοιπο.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// Διαιρέστε τον εαυτό σας με ένα άλλο bignum, αντικαθιστώντας το `q` με το πηλίκο και το `r` με το υπόλοιπο.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // Το ηλίθιο αργό base-2 μακρύ τμήμα έχει ληφθεί από
                // https://en.wikipedia.org/wiki/Division_algorithm
                // Το FIXME χρησιμοποιεί μια μεγαλύτερη βάση ($ty) για τη μεγάλη διαίρεση.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Ορίστε το bit `i` του q σε 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// Ο τύπος ψηφίου για `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// αυτό χρησιμοποιείται μόνο για δοκιμές.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}