//! Λίγο να παίζεις θετικά IEEE 754 floats.Οι αρνητικοί αριθμοί δεν είναι και δεν χρειάζεται να αντιμετωπιστούν.
//! Οι κανονικοί αριθμοί κινητής υποδιαστολής έχουν κανονική αναπαράσταση ως (frac, exp) έτσι ώστε η τιμή να είναι 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) όπου N είναι ο αριθμός των bit.
//!
//! Τα μη φυσιολογικά είναι ελαφρώς διαφορετικά και περίεργα, αλλά ισχύει η ίδια αρχή.
//!
//! Εδώ, ωστόσο, τα αντιπροσωπεύουμε ως (sig, k) με f positive, έτσι ώστε η τιμή να είναι f *
//! 2 <sup>ε</sup> .Εκτός από το να κάνει το "hidden bit" σαφές, αυτό αλλάζει τον εκθέτη από τη λεγόμενη μετατόπιση της μάντισσας.
//!
//! Με άλλα λόγια, συνήθως τα float γράφονται ως (1) αλλά εδώ γράφονται ως (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Καλούμε (1) την **κλασματική αναπαράσταση** και (2) την **αναπόσπαστη αναπαράσταση**.
//!
//! Πολλές λειτουργίες σε αυτήν την ενότητα χειρίζονται μόνο κανονικούς αριθμούς.Οι ρουτίνες dec2flt λαμβάνουν συντηρητικά την καθολικά σωστή αργή διαδρομή (Αλγόριθμος M) για πολύ μικρούς και πολύ μεγάλους αριθμούς.
//! Αυτός ο αλγόριθμος χρειάζεται μόνο next_float() που χειρίζεται υπο-φυσιολογικά και μηδενικά.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Ένας βοηθός trait για να αποφύγετε την αναπαραγωγή βασικά όλων των κωδικών μετατροπής για `f32` και `f64`.
///
/// Ανατρέξτε στο σχόλιο εγγράφου της γονικής μονάδας για γιατί είναι απαραίτητο.
///
/// Δεν θα πρέπει ποτέ ** να εφαρμοστεί για άλλους τύπους ή να χρησιμοποιηθεί εκτός της μονάδας dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Τύπος που χρησιμοποιείται από `to_bits` και `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Εκτελεί ακατέργαστο μετασχηματισμό σε ακέραιο.
    fn to_bits(self) -> Self::Bits;

    /// Εκτελεί ακατέργαστο μετασχηματισμό από ακέραιο.
    fn from_bits(v: Self::Bits) -> Self;

    /// Επιστρέφει την κατηγορία στην οποία ανήκει αυτός ο αριθμός.
    fn classify(self) -> FpCategory;

    /// Επιστρέφει τη μάντισσα, εκθετική και υπογράφει ως ακέραιοι.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Αποκωδικοποιεί το float.
    fn unpack(self) -> Unpacked;

    /// Μετάδοση από έναν μικρό ακέραιο που μπορεί να αναπαρασταθεί ακριβώς.
    /// Panic εάν ο ακέραιος αριθμός δεν μπορεί να αναπαρασταθεί, ο άλλος κώδικας σε αυτήν την ενότητα φροντίζει να μην αφήσει ποτέ να συμβεί αυτό.
    fn from_int(x: u64) -> Self;

    /// Λαμβάνει την τιμή 10 <sup>e</sup> από έναν προ-υπολογισμένο πίνακα.
    /// Panics για `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Τι λέει το όνομα.
    /// Είναι πιο εύκολο στον σκληρό κώδικα από το ζογκλέρ εγγενές και ελπίζοντας ότι το LLVM σταθερά το διπλώνει.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Ένα συντηρητικό όριο στα δεκαδικά ψηφία των εισόδων που δεν μπορούν να παράγουν υπερχείλιση ή μηδέν ή
    /// μη φυσιολογικά.Πιθανώς το δεκαδικό εκθετικό της μέγιστης κανονικής τιμής, εξ ου και το όνομα.
    const MAX_NORMAL_DIGITS: usize;

    /// Όταν το πιο σημαντικό δεκαδικό ψηφίο έχει τιμή θέσης μεγαλύτερη από αυτήν, ο αριθμός είναι σίγουρα στρογγυλευμένος στο άπειρο.
    ///
    const INF_CUTOFF: i64;

    /// Όταν το πιο σημαντικό δεκαδικό ψηφίο έχει τιμή θέσης μικρότερη από αυτήν, ο αριθμός σίγουρα στρογγυλοποιείται στο μηδέν.
    ///
    const ZERO_CUTOFF: i64;

    /// Ο αριθμός των bits στον εκθέτη.
    const EXP_BITS: u8;

    /// Ο αριθμός των bit στην έννοια, συμπεριλαμβανομένου του κρυμμένου bit.
    const SIG_BITS: u8;

    /// Ο αριθμός των bit στη σημασία, * εξαιρουμένου του κρυμμένου bit.
    const EXPLICIT_SIG_BITS: u8;

    /// Ο μέγιστος νομικός εκφραστής στην κλασματική αναπαράσταση.
    const MAX_EXP: i16;

    /// Ο ελάχιστος νομικός εκφραστής στην κλασματική αναπαράσταση, εξαιρουμένων των μη φυσιολογικών.
    const MIN_EXP: i16;

    /// `MAX_EXP` για ολοκληρωμένη αναπαράσταση, δηλαδή, με την αλλαγή που εφαρμόζεται.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` κωδικοποιημένο (δηλ. με προκατάληψη)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` για ολοκληρωμένη αναπαράσταση, δηλαδή, με την αλλαγή που εφαρμόζεται.
    const MIN_EXP_INT: i16;

    /// Η μέγιστη ομαλοποιημένη έννοια στην ολοκληρωμένη αναπαράσταση.
    const MAX_SIG: u64;

    /// Η ελάχιστη ομαλοποιημένη έννοια στην ολοκληρωμένη αναπαράσταση.
    const MIN_SIG: u64;
}

// Κυρίως μια λύση για το #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Επιστρέφει τη μάντισσα, εκθετική και υπογράφει ως ακέραιοι.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Εκθετική προκατάληψη + μετατόπιση της μάντισσας
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // Το rkruppe δεν είναι σίγουρο εάν το `as` στρογγυλοποιείται σωστά σε όλες τις πλατφόρμες.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Επιστρέφει τη μάντισσα, εκθετική και υπογράφει ως ακέραιοι.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Εκθετική προκατάληψη + μετατόπιση της μάντισσας
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // Το rkruppe δεν είναι σίγουρο εάν το `as` στρογγυλοποιείται σωστά σε όλες τις πλατφόρμες.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Μετατρέπει ένα `Fp` στον πλησιέστερο τύπο πλωτήρα μηχανής.
/// Δεν χειρίζεται τα μη φυσιολογικά αποτελέσματα.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f είναι 64 bit, οπότε το xe έχει μια αλλαγή mantissa 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Στρογγυλοποιήστε τη σημασία 64-bit σε bit T::SIG_BITS με μισό έως ζυγό.
/// Δεν χειρίζεται την υπερχείλιση εκθετών.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Ρυθμίστε τη μετατόπιση της μάντισσας
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Αντίστροφο του `RawFloat::unpack()` για κανονικοποιημένους αριθμούς.
/// Panics εάν το σήμα ή ο εκθέτης δεν είναι έγκυροι για κανονικοποιημένους αριθμούς.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Αφαιρέστε το κρυφό κομμάτι
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Προσαρμόστε τον εκθέτη για εκθετική προκατάληψη και μετατόπιση μάντισσας
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Αφήστε το σύμβολο bit στο 0 ("+"), όλοι οι αριθμοί μας είναι θετικοί
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Κατασκευάστε ένα μη φυσιολογικό.Επιτρέπεται μάντισσα 0 και δημιουργεί μηδέν.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Ο κωδικοποιημένος εκθέτης είναι 0, το σύμβολο bit είναι 0, οπότε απλά πρέπει να ερμηνεύσουμε ξανά τα bit.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Περίπου ένα bignum με Fp.Γύρος εντός 0.5 ULP με μισό έως ζυγό.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Κόψαμε όλα τα bits πριν από το ευρετήριο `start`, δηλαδή, στρίβουμε ουσιαστικά δεξιά κατά ένα ποσό `start`, οπότε αυτός είναι και ο εκθέτης που χρειαζόμαστε.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Γύρος (half-to-even) ανάλογα με τα κομμένα κομμάτια.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Βρίσκει τον μεγαλύτερο αριθμό κινούμενου σημείου πολύ μικρότερος από το όρισμα.
/// Δεν χειρίζεται υποφυσιολογικά, μηδενικά ή εκθετικά υποροή.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Βρείτε τον μικρότερο αριθμό κινούμενου σημείου που είναι πολύ μεγαλύτερος από το όρισμα.
// Αυτή η λειτουργία είναι κορεσμένη, δηλαδή next_float(inf) ==inf.
// Σε αντίθεση με τους περισσότερους κώδικες σε αυτήν την ενότητα, αυτή η συνάρτηση χειρίζεται μηδενικά, μη κανονικά και άπειρα.
// Ωστόσο, όπως και όλοι οι άλλοι κωδικοί εδώ, δεν ασχολείται με NaN και αρνητικούς αριθμούς.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Αυτό φαίνεται πολύ καλό για να είναι αληθινό, αλλά λειτουργεί.
        // 0.0 κωδικοποιείται ως η λέξη μηδενική.Τα μη φυσιολογικά είναι 0x000m ... m όπου m είναι η μάντισσα.
        // Συγκεκριμένα, το μικρότερο υποτροπικό είναι 0x0 ... 01 και το μεγαλύτερο είναι 0x000F ... F.
        // Ο μικρότερος κανονικός αριθμός είναι 0x0010 ... 0, οπότε αυτή η γωνιακή θήκη λειτουργεί επίσης.
        // Εάν η αύξηση υπερχειλίσει τη μάντισσα, το bit μεταφοράς αυξάνει τον εκθέτη όπως θέλουμε και τα μάντισσα μπιτ γίνονται μηδέν.
        // Λόγω της κρυμμένης σύμβασης bit, αυτό είναι ακριβώς αυτό που θέλουμε!
        // Τέλος, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}