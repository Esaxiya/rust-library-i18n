//! Βοηθητικές λειτουργίες για bignums που δεν έχουν πολύ νόημα για να μετατραπούν σε μεθόδους.

// FIXME Το όνομα αυτής της μονάδας είναι λίγο ατυχές, καθώς και άλλες μονάδες εισάγουν επίσης `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Ελέγξτε εάν η περικοπή όλων των bits λιγότερο σημαντική από το `ones_place` εισάγει ένα σχετικό σφάλμα μικρότερο, ίσο ή μεγαλύτερο από το 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Εάν όλα τα υπόλοιπα bit είναι μηδέν, είναι= 0.5 ULP, διαφορετικά> 0.5 Εάν δεν υπάρχουν περισσότερα bit (half_bit==0), τα παρακάτω επιστρέφουν επίσης σωστά το Equal.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Μετατρέπει μια συμβολοσειρά ASCII που περιέχει μόνο δεκαδικά ψηφία σε `u64`.
///
/// Δεν εκτελεί ελέγχους για υπερχείλιση ή μη έγκυρους χαρακτήρες, οπότε αν ο καλών δεν είναι προσεκτικός, το αποτέλεσμα είναι ψευδές και μπορεί panic (αν και δεν θα είναι `unsafe`).
/// Επιπλέον, οι κενές συμβολοσειρές αντιμετωπίζονται ως μηδέν.
/// Αυτή η συνάρτηση υπάρχει επειδή
///
/// 1. Η χρήση του `FromStr` στο `&[u8]` απαιτεί `from_utf8_unchecked`, το οποίο είναι κακό, και
/// 2. Η συγκέντρωση των αποτελεσμάτων των `integral.parse()` και `fractional.parse()` είναι πιο περίπλοκη από αυτή ολόκληρη τη λειτουργία.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Μετατρέπει μια συμβολοσειρά ψηφίων ASCII σε bignum.
///
/// Όπως το `from_str_unchecked`, αυτή η συνάρτηση βασίζεται στον αναλυτή για την εξάλειψη των μη ψηφίων.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Ξετυλίγει ένα bignum σε ακέραιο 64 bit.Panics εάν ο αριθμός είναι πολύ μεγάλος.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Εξάγει μια σειρά από bit.

/// Ο δείκτης 0 είναι το λιγότερο σημαντικό bit και το εύρος είναι μισό ανοιχτό ως συνήθως.
/// Panics εάν σας ζητηθεί να εξαγάγετε περισσότερα bit από ό, τι ταιριάζει στον τύπο επιστροφής.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}