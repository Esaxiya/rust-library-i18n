//! Σταθερές ειδικές για τον τύπο κινητού σημείου μονής ακρίβειας `f32`
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Μαθηματικά σημαντικοί αριθμοί παρέχονται στην υποενότητα `consts`.
//!
//! Για τις σταθερές που ορίζονται απευθείας σε αυτήν την ενότητα (ως διακριτές από αυτές που ορίζονται στην υποενότητα `consts`), ο νέος κωδικός θα πρέπει αντ 'αυτού να χρησιμοποιεί τις σχετικές σταθερές που ορίζονται απευθείας στον τύπο `f32`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Η ακτίνα ή η βάση της εσωτερικής αναπαράστασης του `f32`.
/// Χρησιμοποιήστε το [`f32::RADIX`] αντ 'αυτού.
///
/// # Examples
///
/// ```rust
/// // κατεστραμμένο τρόπο
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // προβλεπόμενος τρόπος
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Αριθμός σημαντικών ψηφίων στη βάση 2.
/// Χρησιμοποιήστε το [`f32::MANTISSA_DIGITS`] αντ 'αυτού.
///
/// # Examples
///
/// ```rust
/// // κατεστραμμένο τρόπο
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // προβλεπόμενος τρόπος
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Κατά προσέγγιση αριθμός σημαντικών ψηφίων στη βάση 10.
/// Χρησιμοποιήστε το [`f32::DIGITS`] αντ 'αυτού.
///
/// # Examples
///
/// ```rust
/// // κατεστραμμένο τρόπο
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // προβλεπόμενος τρόπος
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] τιμή για `f32`.
/// Χρησιμοποιήστε το [`f32::EPSILON`] αντ 'αυτού.
///
/// Αυτή είναι η διαφορά μεταξύ του `1.0` και του επόμενου μεγαλύτερου αντιπροσωπευόμενου αριθμού.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // κατεστραμμένο τρόπο
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // προβλεπόμενος τρόπος
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Μικρότερη πεπερασμένη τιμή `f32`.
/// Χρησιμοποιήστε το [`f32::MIN`] αντ 'αυτού.
///
/// # Examples
///
/// ```rust
/// // κατεστραμμένο τρόπο
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // προβλεπόμενος τρόπος
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Μικρότερη θετική κανονική τιμή `f32`.
/// Χρησιμοποιήστε το [`f32::MIN_POSITIVE`] αντ 'αυτού.
///
/// # Examples
///
/// ```rust
/// // κατεστραμμένο τρόπο
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // προβλεπόμενος τρόπος
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Μεγαλύτερη πεπερασμένη τιμή `f32`.
/// Χρησιμοποιήστε το [`f32::MAX`] αντ 'αυτού.
///
/// # Examples
///
/// ```rust
/// // κατεστραμμένο τρόπο
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // προβλεπόμενος τρόπος
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Μία μεγαλύτερη από την ελάχιστη δυνατή κανονική ισχύ 2 εκθετών.
/// Χρησιμοποιήστε το [`f32::MIN_EXP`] αντ 'αυτού.
///
/// # Examples
///
/// ```rust
/// // κατεστραμμένο τρόπο
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // προβλεπόμενος τρόπος
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Μέγιστη δυνατή ισχύς 2 εκθετών.
/// Χρησιμοποιήστε το [`f32::MAX_EXP`] αντ 'αυτού.
///
/// # Examples
///
/// ```rust
/// // κατεστραμμένο τρόπο
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // προβλεπόμενος τρόπος
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Ελάχιστη δυνατή κανονική ισχύς 10 εκθετών.
/// Χρησιμοποιήστε το [`f32::MIN_10_EXP`] αντ 'αυτού.
///
/// # Examples
///
/// ```rust
/// // κατεστραμμένο τρόπο
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // προβλεπόμενος τρόπος
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Μέγιστη δυνατή ισχύς 10 εκθετών.
/// Χρησιμοποιήστε το [`f32::MAX_10_EXP`] αντ 'αυτού.
///
/// # Examples
///
/// ```rust
/// // κατεστραμμένο τρόπο
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // προβλεπόμενος τρόπος
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Όχι ένας αριθμός (NaN).
/// Χρησιμοποιήστε το [`f32::NAN`] αντ 'αυτού.
///
/// # Examples
///
/// ```rust
/// // κατεστραμμένο τρόπο
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // προβλεπόμενος τρόπος
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Άπειρο (∞).
/// Χρησιμοποιήστε το [`f32::INFINITY`] αντ 'αυτού.
///
/// # Examples
///
/// ```rust
/// // κατεστραμμένο τρόπο
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // προβλεπόμενος τρόπος
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Αρνητικό άπειρο (−∞).
/// Χρησιμοποιήστε το [`f32::NEG_INFINITY`] αντ 'αυτού.
///
/// # Examples
///
/// ```rust
/// // κατεστραμμένο τρόπο
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // προβλεπόμενος τρόπος
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Βασικές μαθηματικές σταθερές.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: αντικαταστήστε με μαθηματικές σταθερές από cmath.

    /// Η σταθερά (π) του Αρχιμήδη
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Η σταθερά πλήρους κύκλου (τ)
    ///
    /// Ισούται με 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Αριθμός Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Η ακτίνα ή η βάση της εσωτερικής αναπαράστασης του `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Αριθμός σημαντικών ψηφίων στη βάση 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Κατά προσέγγιση αριθμός σημαντικών ψηφίων στη βάση 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] τιμή για `f32`.
    ///
    /// Αυτή είναι η διαφορά μεταξύ του `1.0` και του επόμενου μεγαλύτερου αντιπροσωπευόμενου αριθμού.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Μικρότερη πεπερασμένη τιμή `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Μικρότερη θετική κανονική τιμή `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Μεγαλύτερη πεπερασμένη τιμή `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Μία μεγαλύτερη από την ελάχιστη δυνατή κανονική ισχύ 2 εκθετών.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Μέγιστη δυνατή ισχύς 2 εκθετών.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Ελάχιστη δυνατή κανονική ισχύς 10 εκθετών.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Μέγιστη δυνατή ισχύς 10 εκθετών.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Όχι ένας αριθμός (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Άπειρο (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Αρνητικό άπειρο (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Επιστρέφει `true` εάν αυτή η τιμή είναι `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): Το `abs` δεν είναι δημόσια διαθέσιμο στο libcore λόγω ανησυχιών σχετικά με τη φορητότητα, επομένως αυτή η εφαρμογή προορίζεται για ιδιωτική χρήση εσωτερικά.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Επιστρέφει `true` εάν αυτή η τιμή είναι θετικό άπειρο ή αρνητικό άπειρο και `false` διαφορετικά.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Επιστρέφει `true` εάν αυτός ο αριθμός δεν είναι άπειρος ούτε `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Δεν χρειάζεται να χειριστείτε το NaN ξεχωριστά: εάν ο εαυτός σας είναι NaN, η σύγκριση δεν είναι αληθινή, ακριβώς όπως επιθυμείτε.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Επιστρέφει `true` εάν ο αριθμός είναι [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Οι τιμές μεταξύ `0` και `min` είναι μη φυσιολογικές.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Επιστρέφει `true` εάν ο αριθμός δεν είναι μηδέν, άπειρος, [subnormal] ή `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Οι τιμές μεταξύ `0` και `min` είναι μη φυσιολογικές.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Επιστρέφει την κατηγορία κινητού σημείου του αριθμού.
    /// Εάν πρόκειται να ελεγχθεί μόνο μία ιδιότητα, είναι γενικά πιο γρήγορη η χρήση του συγκεκριμένου υποθέματος.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Επιστρέφει το `true` εάν το `self` έχει θετικό σημάδι, συμπεριλαμβανομένων των `+0.0`, "NaN" με θετικό bit και θετικό άπειρο.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Επιστρέφει το `true` εάν το `self` έχει αρνητικό σύμβολο, συμπεριλαμβανομένων των `-0.0`, "NaN" με αρνητικό bit και αρνητικό άπειρο.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // Το IEEE754 λέει: Το isSignMinus(x) ισχύει εάν και μόνο εάν το x έχει αρνητικό σύμβολο.
        // Το isSignMinus ισχύει και για μηδενικά και NaNs.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Παίρνει το αμοιβαίο (inverse) ενός αριθμού, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Μετατρέπει ακτίνια σε μοίρες.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Χρησιμοποιήστε μια σταθερά για καλύτερη ακρίβεια.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Μετατρέπει μοίρες σε ακτίνια.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Επιστρέφει το μέγιστο των δύο αριθμών.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Εάν ένα από τα ορίσματα είναι NaN, τότε το άλλο όρισμα επιστρέφεται.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Επιστρέφει το ελάχιστο των δύο αριθμών.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Εάν ένα από τα ορίσματα είναι NaN, τότε το άλλο όρισμα επιστρέφεται.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Στρογγυλοποιείται προς το μηδέν και μετατρέπεται σε οποιονδήποτε πρωτόγονο ακέραιο τύπο, υποθέτοντας ότι η τιμή είναι πεπερασμένη και ταιριάζει σε αυτόν τον τύπο.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Η τιμή πρέπει:
    ///
    /// * Όχι `NaN`
    /// * Να μην είναι άπειρο
    /// * Να είστε αντιπροσωπευτικοί στον τύπο επιστροφής `Int`, αφού κόψετε το κλασματικό του τμήμα
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να τηρεί τη σύμβαση ασφαλείας για το `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Ακατέργαστη μετάδοση σε `u32`.
    ///
    /// Αυτή τη στιγμή είναι ίδια με το `transmute::<f32, u32>(self)` σε όλες τις πλατφόρμες.
    ///
    /// Ανατρέξτε στο `from_bits` για κάποια συζήτηση σχετικά με τη φορητότητα αυτής της λειτουργίας (σχεδόν δεν υπάρχουν προβλήματα).
    ///
    /// Σημειώστε ότι αυτή η λειτουργία διαφέρει από τη μετάδοση `as`, η οποία προσπαθεί να διατηρήσει την τιμή *αριθμητική* και όχι την τιμή bitwise.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() δεν ρίχνει!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // ΑΣΦΑΛΕΙΑ: Το `u32` είναι ένας απλός παλιός τύπος δεδομένων, ώστε να μπορούμε πάντα να το μεταδίδουμε
        unsafe { mem::transmute(self) }
    }

    /// Ακατέργαστη μετάδοση από `u32`.
    ///
    /// Αυτή τη στιγμή είναι ίδια με το `transmute::<u32, f32>(v)` σε όλες τις πλατφόρμες.
    /// Αποδεικνύεται ότι είναι απίστευτα φορητό, για δύο λόγους:
    ///
    /// * Τα Floats και τα Ints έχουν την ίδια ακεραιότητα σε όλες τις υποστηριζόμενες πλατφόρμες.
    /// * Το IEEE-754 καθορίζει με ακρίβεια τη διάταξη bit των floats.
    ///
    /// Ωστόσο, υπάρχει μια προειδοποίηση: πριν από την έκδοση 2008 του IEEE-754, ο τρόπος ερμηνείας του bit σηματοδότησης NaN δεν προσδιορίστηκε πραγματικά.
    /// Οι περισσότερες πλατφόρμες (κυρίως x86 και ARM) επέλεξαν την ερμηνεία που τελικά τυποποιήθηκε το 2008, αλλά ορισμένες δεν το έκαναν (κυρίως το MIPS).
    /// Ως αποτέλεσμα, όλα τα NaN σηματοδότησης στο MIPS είναι ήσυχα NaNs στο x86 και το αντίστροφο.
    ///
    /// Αντί να προσπαθεί να διατηρήσει την πλατφόρμα σηματοδότησης, αυτή η εφαρμογή ευνοεί τη διατήρηση των ακριβών bit.
    /// Αυτό σημαίνει ότι τυχόν ωφέλιμα φορτία που κωδικοποιούνται σε NaNs θα διατηρηθούν ακόμη και αν το αποτέλεσμα αυτής της μεθόδου αποστέλλεται μέσω του δικτύου από ένα μηχάνημα x86 σε ένα MIPS.
    ///
    ///
    /// Εάν τα αποτελέσματα αυτής της μεθόδου χειρίζονται μόνο την ίδια αρχιτεκτονική που τα παρήγαγε, τότε δεν υπάρχει πρόβλημα φορητότητας.
    ///
    /// Εάν η είσοδος δεν είναι NaN, τότε δεν υπάρχει πρόβλημα φορητότητας.
    ///
    /// Εάν δεν σας ενδιαφέρει η σηματοδότηση (πολύ πιθανό), τότε δεν υπάρχει πρόβλημα φορητότητας.
    ///
    /// Σημειώστε ότι αυτή η λειτουργία διαφέρει από τη μετάδοση `as`, η οποία προσπαθεί να διατηρήσει την τιμή *αριθμητική* και όχι την τιμή bitwise.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // ΑΣΦΑΛΕΙΑ: Το `u32` είναι ένας απλός παλιός τύπος δεδομένων, ώστε να μπορούμε πάντα να μεταδίδουμε από αυτόν
        // Αποδεικνύεται ότι τα ζητήματα ασφάλειας με το sNaN ήταν υπερβολικά υψηλά!Ζήτω!
        unsafe { mem::transmute(v) }
    }

    /// Επιστρέψτε την αναπαράσταση της μνήμης αυτού του αριθμού κινούμενου σημείου ως πίνακα byte σε σειρά μεγάλου endian (network) byte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Επιστρέψτε την αναπαράσταση της μνήμης αυτού του αριθμού κινητής υποδιαστολής ως πίνακα byte σε σειρά byt-endian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Επιστρέψτε την αναπαράσταση της μνήμης αυτού του αριθμού κινητού σημείου ως πίνακα byte σε εγγενή σειρά byte.
    ///
    /// Καθώς χρησιμοποιείται το εγγενές endianness της πλατφόρμας στόχου, ο φορητός κώδικας θα πρέπει να χρησιμοποιεί [`to_be_bytes`] ή [`to_le_bytes`], ανάλογα με την περίπτωση.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Επιστρέψτε την αναπαράσταση της μνήμης αυτού του αριθμού κινητού σημείου ως πίνακα byte σε εγγενή σειρά byte.
    ///
    ///
    /// [`to_ne_bytes`] πρέπει να προτιμάται από αυτό όποτε είναι δυνατόν.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // ΑΣΦΑΛΕΙΑ: Το `f32` είναι ένας απλός παλιός τύπος δεδομένων, ώστε να μπορούμε πάντα να το μεταδίδουμε
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Δημιουργήστε μια τιμή κινητής υποδιαστολής από την αναπαράστασή της ως πίνακα byte σε μεγάλο endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Δημιουργήστε μια τιμή κινητής υποδιαστολής από την αναπαράστασή της ως πίνακα byte σε λίγο endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Δημιουργήστε μια τιμή κινητής υποδιαστολής από την αναπαράστασή της ως πίνακα byte στο εγγενές endian.
    ///
    /// Καθώς χρησιμοποιείται το εγγενές endianness της πλατφόρμας στόχου, ο φορητός κώδικας πιθανότατα θέλει να χρησιμοποιήσει [`from_be_bytes`] ή [`from_le_bytes`], ανάλογα με την περίπτωση.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Επιστρέφει μια παραγγελία μεταξύ του εαυτού και άλλων τιμών.
    /// Σε αντίθεση με την τυπική μερική σύγκριση μεταξύ αριθμών κυμαινόμενου σημείου, αυτή η σύγκριση παράγει πάντα μια παραγγελία σύμφωνα με το predicate totalOrder όπως ορίζεται στο πρότυπο κυμαινόμενου σημείου IEEE 754 (αναθεώρηση 2008).
    /// Οι τιμές ταξινομούνται με την ακόλουθη σειρά:
    /// - Αρνητικό ήσυχο NaN
    /// - Αρνητική σηματοδότηση NaN
    /// - Αρνητικό άπειρο
    /// - Αρνητικοί αριθμοί
    /// - Αρνητικοί μη φυσιολογικοί αριθμοί
    /// - Αρνητικό μηδέν
    /// - Θετικό μηδέν
    /// - Θετικοί μη φυσιολογικοί αριθμοί
    /// - Θετικοί αριθμοί
    /// - Θετικό άπειρο
    /// - Θετική σηματοδότηση NaN
    /// - Θετικό ήσυχο NaN
    ///
    /// Λάβετε υπόψη ότι αυτή η λειτουργία δεν συμφωνεί πάντα με τις εφαρμογές [`PartialOrd`] και [`PartialEq`] του `f32`.Συγκεκριμένα, θεωρούν το αρνητικό και το θετικό μηδέν ως ίσο, ενώ το `total_cmp` δεν το κάνει.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // Σε περίπτωση αρνητικών, γυρίστε όλα τα bits εκτός από το σύμβολο για να επιτύχετε μια παρόμοια διάταξη με τους ακέραιους αριθμούς των δύο
        //
        // Γιατί λειτουργεί αυτό;Οι πλωτήρες IEEE 754 αποτελούνται από τρία πεδία:
        // Σημάδι bit, εκθέτης και μάντισσα.Το σύνολο των εκθετικών και της mantissa πεδίων στο σύνολό του έχει την ιδιότητα ότι η bitwise σειρά τους είναι ίση με το αριθμητικό μέγεθος όπου ορίζεται το μέγεθος.
        // Το μέγεθος δεν ορίζεται κανονικά στις τιμές NaN, αλλά το IEEE 754 totalOrder καθορίζει τις τιμές NaN και για να ακολουθεί τη σειρά bitwise.Αυτό οδηγεί σε παραγγελία που εξηγείται στο σχόλιο του εγγράφου.
        // Ωστόσο, η αναπαράσταση του μεγέθους είναι η ίδια για αρνητικούς και θετικούς αριθμούς-μόνο το σύμβολο bit είναι διαφορετικό.
        // Για να συγκρίνουμε εύκολα τα float ως υπογεγραμμένους ακέραιους αριθμούς, πρέπει να γυρίσουμε τα εκθετικά και mantissa bits σε περίπτωση αρνητικών αριθμών.
        // Μετατρέπουμε αποτελεσματικά τους αριθμούς σε φόρμα "two's complement".
        //
        // Για να κάνουμε το flipping, κατασκευάζουμε μια μάσκα και XOR εναντίον της.
        // Υπολογίζουμε χωρίς διακλάδωση μια μάσκα "all-ones except for the sign bit" από αρνητικές-υπογεγραμμένες τιμές: η σωστή μετατόπιση-επεκτείνει τον ακέραιο, οπότε εμείς "fill" η μάσκα με bit σημαδιών και στη συνέχεια μετατρέπουμε σε μη υπογεγραμμένη για να πιέσουμε ένα ακόμη μηδέν bit.
        //
        // Σε θετικές τιμές, η μάσκα είναι όλα μηδενικά, οπότε δεν είναι op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Περιορίστε μια τιμή σε ένα ορισμένο διάστημα, εκτός αν είναι NaN.
    ///
    /// Επιστρέφει το `max` εάν το `self` είναι μεγαλύτερο από το `max` και το `min` εάν το `self` είναι μικρότερο από `min`.
    /// Διαφορετικά, επιστρέφει το `self`.
    ///
    /// Σημειώστε ότι αυτή η συνάρτηση επιστρέφει NaN εάν η αρχική τιμή ήταν επίσης NaN.
    ///
    /// # Panics
    ///
    /// Panics εάν `min > max`, `min` είναι NaN ή `max` είναι NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}