macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Η μικρότερη τιμή που μπορεί να αναπαρασταθεί από αυτόν τον ακέραιο τύπο.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Η μεγαλύτερη τιμή που μπορεί να αναπαρασταθεί από αυτόν τον ακέραιο τύπο.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Το μέγεθος αυτού του ακέραιου τύπου σε bits.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Μετατρέπει ένα κομμάτι συμβολοσειράς σε μια δεδομένη βάση σε ακέραιο.
        ///
        /// Η συμβολοσειρά αναμένεται να είναι ένα προαιρετικό σύμβολο `+` ακολουθούμενο από ψηφία.
        ///
        /// Ο κεντρικός και ο τελικός κενός χώρος αντιπροσωπεύει ένα σφάλμα.
        /// Τα ψηφία είναι ένα υποσύνολο αυτών των χαρακτήρων, ανάλογα με το `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Αυτή η λειτουργία panics εάν το `radix` δεν βρίσκεται στην περιοχή από 2 έως 36.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Επιστρέφει τον αριθμό αυτών στη δυαδική αναπαράσταση του `self`.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Επιστρέφει τον αριθμό μηδενικών στη δυαδική αναπαράσταση του `self`.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Επιστρέφει τον αριθμό των αρχικών μηδενικών στη δυαδική αναπαράσταση του `self`.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Επιστρέφει τον αριθμό των μηδενικών που ακολουθούν στη δυαδική αναπαράσταση του `self`.
        ///
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Επιστρέφει τον αριθμό των κορυφαίων στην δυαδική αναπαράσταση του `self`.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Επιστρέφει τον αριθμό των τελικών στη δυαδική αναπαράσταση του `self`.
        ///
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Μετατοπίζει τα bit προς τα αριστερά με καθορισμένο ποσό, `n`, τυλίγοντας τα κομμένα bit στο τέλος του ακέραιου αριθμού που προκύπτει.
        ///
        ///
        /// Λάβετε υπόψη ότι αυτή δεν είναι η ίδια λειτουργία με τον χειριστή αλλαγής `<<`!
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Μετατοπίζει τα bit προς τα δεξιά με καθορισμένο ποσό, `n`, τυλίγοντας τα κομμένα bit στην αρχή του ακέραιου αριθμού που προκύπτει.
        ///
        ///
        /// Λάβετε υπόψη ότι αυτή δεν είναι η ίδια λειτουργία με τον χειριστή αλλαγής `>>`!
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Αντιστρέφει τη σειρά byte του ακέραιου.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// ας m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Αντιστρέφει τη σειρά των bits στον ακέραιο.
        /// Το λιγότερο σημαντικό bit γίνεται το πιο σημαντικό bit, το δεύτερο λιγότερο σημαντικό bit γίνεται το δεύτερο σημαντικότερο bit, κ.λπ.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// ας m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Μετατρέπει έναν ακέραιο από μεγάλο endian στο endianness του στόχου.
        ///
        /// Στο μεγάλο endian αυτό δεν είναι op.
        /// Σε λίγο endian τα bytes ανταλλάσσονται.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// αν cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } αλλιώς {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Μετατρέπει έναν ακέραιο από λίγο endian στο endianness του στόχου.
        ///
        /// Σε λίγο endian αυτό δεν είναι op.
        /// Σε μεγάλο endian τα bytes ανταλλάσσονται.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// αν cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } αλλιώς {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Μετατρέπει το `self` σε μεγάλο endian από το endianness του στόχου.
        ///
        /// Στο μεγάλο endian αυτό δεν είναι op.
        /// Σε λίγο endian τα bytes ανταλλάσσονται.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// αν cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } αλλιώς { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // ή όχι;
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Μετατρέπει το `self` σε λίγο endian από το endianness του στόχου.
        ///
        /// Σε λίγο endian αυτό δεν είναι op.
        /// Σε μεγάλο endian τα bytes ανταλλάσσονται.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// αν cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } αλλιώς { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Ελεγμένη ακέραια προσθήκη.
        /// Υπολογίζει το `self + rhs`, επιστρέφοντας το `None` σε περίπτωση υπερχείλισης.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Μη επιλεγμένη ακέραια προσθήκη.Υπολογίζει το `self + rhs`, υποθέτοντας ότι δεν μπορεί να συμβεί υπερχείλιση.
        /// Αυτό οδηγεί σε απροσδιόριστη συμπεριφορά όταν
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να τηρεί τη σύμβαση ασφαλείας για το `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Έλεγχος ακεραίας αφαίρεσης.
        /// Υπολογίζει το `self - rhs`, επιστρέφοντας το `None` σε περίπτωση υπερχείλισης.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Μη επιλεγμένη ακέραια αφαίρεση.Υπολογίζει το `self - rhs`, υποθέτοντας ότι δεν μπορεί να συμβεί υπερχείλιση.
        /// Αυτό οδηγεί σε απροσδιόριστη συμπεριφορά όταν
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να τηρεί τη σύμβαση ασφαλείας για το `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Έλεγχος ακέραιου πολλαπλασιασμού.
        /// Υπολογίζει το `self * rhs`, επιστρέφοντας το `None` σε περίπτωση υπερχείλισης.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Μη επιλεγμένος ακέραιος πολλαπλασιασμός.Υπολογίζει το `self * rhs`, υποθέτοντας ότι δεν μπορεί να συμβεί υπερχείλιση.
        /// Αυτό οδηγεί σε απροσδιόριστη συμπεριφορά όταν
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να τηρεί τη σύμβαση ασφαλείας για το `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Ελεγμένο ακέραιο τμήμα.
        /// Υπολογίζει `self / rhs`, επιστρέφοντας `None` εάν `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // ΑΣΦΑΛΕΙΑ: έχει ελεγχθεί παραπάνω το div by zero και οι τύποι που δεν έχουν υπογραφεί δεν έχουν άλλον
                // τρόποι αποτυχίας για διαίρεση
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Έλεγξε το τμήμα Ευκλείδειας.
        /// Υπολογίζει `self.div_euclid(rhs)`, επιστρέφοντας `None` εάν `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Ελεγμένο ακέραιο υπόλοιπο.
        /// Υπολογίζει `self % rhs`, επιστρέφοντας `None` εάν `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // ΑΣΦΑΛΕΙΑ: έχει ελεγχθεί παραπάνω το div by zero και οι τύποι που δεν έχουν υπογραφεί δεν έχουν άλλον
                // τρόποι αποτυχίας για διαίρεση
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Ελεγμένο Euclidean modulo.
        /// Υπολογίζει `self.rem_euclid(rhs)`, επιστρέφοντας `None` εάν `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Επιλεγμένη άρνηση.Υπολογίζει το `-self`, επιστρέφοντας το `None` εκτός αν το «self==
        /// 0`.
        ///
        /// Σημειώστε ότι η άρνηση οποιουδήποτε θετικού ακέραιου αριθμού θα ξεχειλίσει.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ελεγμένο στροφή αριστερά.
        /// Υπολογίζει το `self << rhs`, επιστρέφοντας το `None` εάν το `rhs` είναι μεγαλύτερο ή ίσο με τον αριθμό των bit στο `self`.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ελεγμένο στροφή προς τα δεξιά.
        /// Υπολογίζει το `self >> rhs`, επιστρέφοντας το `None` εάν το `rhs` είναι μεγαλύτερο ή ίσο με τον αριθμό των bit στο `self`.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Έλεγχος εκτόνωσης.
        /// Υπολογίζει το `self.pow(exp)`, επιστρέφοντας το `None` σε περίπτωση υπερχείλισης.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // από exp!=0, τελικά το exp πρέπει να είναι 1.
            // Αντιμετωπίστε το τελικό κομμάτι του εκθέτη ξεχωριστά, καθώς το τετράγωνο της βάσης μετά δεν είναι απαραίτητο και μπορεί να προκαλέσει περιττή υπερχείλιση.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Κορεσμένη ακέραια προσθήκη.
        /// Υπολογίζει `self + rhs`, κορεσμό στα αριθμητικά όρια αντί για υπερχείλιση.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Κορεσμός ακεραίων αφαίρεσης.
        /// Υπολογίζει `self - rhs`, κορεσμό στα αριθμητικά όρια αντί για υπερχείλιση.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Κορεσμός ακέραιου πολλαπλασιασμού.
        /// Υπολογίζει `self * rhs`, κορεσμό στα αριθμητικά όρια αντί για υπερχείλιση.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Κορεσμένος ακέραιος εκθετικός.
        /// Υπολογίζει `self.pow(exp)`, κορεσμό στα αριθμητικά όρια αντί για υπερχείλιση.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Περιτύλιξη προσθήκης (modular).
        /// Υπολογίζει το `self + rhs`, τυλίγοντας στο όριο του τύπου.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Αναδίπλωση αφαίρεσης (modular).
        /// Υπολογίζει το `self - rhs`, τυλίγοντας στο όριο του τύπου.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Αναδίπλωση πολλαπλασιασμού (modular).
        /// Υπολογίζει το `self * rhs`, τυλίγοντας στο όριο του τύπου.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// Λάβετε υπόψη ότι αυτό το παράδειγμα κοινοποιείται μεταξύ ακέραιων τύπων.
        /// Αυτό εξηγεί γιατί χρησιμοποιείται το `u8` εδώ.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Περιτύλιγμα διαίρεσης (modular).Υπολογίζει `self / rhs`.
        /// Η τυλιγμένη διαίρεση σε μη υπογεγραμμένους τύπους είναι απλώς κανονική διαίρεση.
        /// Δεν υπάρχει κανένας τρόπος να μπορέσει να συμβεί.
        /// Αυτή η συνάρτηση υπάρχει, έτσι ώστε όλες οι λειτουργίες να λαμβάνονται υπόψη στις λειτουργίες αναδίπλωσης.
        ///
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Τυλίγοντας ευκλείδεια διαίρεση.Υπολογίζει `self.div_euclid(rhs)`.
        /// Η τυλιγμένη διαίρεση σε μη υπογεγραμμένους τύπους είναι απλώς κανονική διαίρεση.
        /// Δεν υπάρχει κανένας τρόπος να μπορέσει να συμβεί.
        /// Αυτή η συνάρτηση υπάρχει, έτσι ώστε όλες οι λειτουργίες να λαμβάνονται υπόψη στις λειτουργίες αναδίπλωσης.
        /// Επειδή, για τους θετικούς ακέραιους αριθμούς, όλοι οι κοινοί ορισμοί της διαίρεσης είναι ίσοι, αυτό είναι ακριβώς ίσο με το `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Τυλίγοντας το υπόλοιπο (modular).Υπολογίζει `self % rhs`.
        /// Ο υπολογισμός του τυλιγμένου υπολοίπου σε μη υπογεγραμμένους τύπους είναι απλώς ο κανονικός υπολογισμός υπολοίπου.
        ///
        /// Δεν υπάρχει κανένας τρόπος να μπορέσει να συμβεί.
        /// Αυτή η συνάρτηση υπάρχει, έτσι ώστε όλες οι λειτουργίες να λαμβάνονται υπόψη στις λειτουργίες αναδίπλωσης.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Συσκευασία Euclidean modulo.Υπολογίζει `self.rem_euclid(rhs)`.
        /// Ο τυλιγμένος υπολογισμός modulo σε μη υπογεγραμμένους τύπους είναι απλώς ο κανονικός υπόλοιπος υπολογισμός.
        /// Δεν υπάρχει κανένας τρόπος να μπορέσει να συμβεί.
        /// Αυτή η συνάρτηση υπάρχει, έτσι ώστε όλες οι λειτουργίες να λαμβάνονται υπόψη στις λειτουργίες αναδίπλωσης.
        /// Επειδή, για τους θετικούς ακέραιους αριθμούς, όλοι οι κοινοί ορισμοί της διαίρεσης είναι ίσοι, αυτό είναι ακριβώς ίσο με το `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Αναδίπλωση (modular) άρνησης.
        /// Υπολογίζει το `-self`, τυλίγοντας στο όριο του τύπου.
        ///
        /// Δεδομένου ότι οι μη υπογεγραμμένοι τύποι δεν έχουν αρνητικά ισοδύναμα, όλες οι εφαρμογές αυτής της συνάρτησης θα τυλιχτούν (εκτός από το `-0`).
        /// Για τιμές μικρότερες από το μέγιστο του αντίστοιχου υπογεγραμμένου τύπου, το αποτέλεσμα είναι το ίδιο με τη μετάδοση της αντίστοιχης υπογεγραμμένης τιμής.
        ///
        /// Τυχόν μεγαλύτερες τιμές είναι ισοδύναμες με `MAX + 1 - (val - MAX - 1)` όπου το `MAX` είναι το αντίστοιχο μέγιστο του υπογεγραμμένου τύπου.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// Λάβετε υπόψη ότι αυτό το παράδειγμα κοινοποιείται μεταξύ ακέραιων τύπων.
        /// Αυτό εξηγεί γιατί χρησιμοποιείται το `i8` εδώ.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic χωρίς δεξιόστροφη κίνηση προς τα αριστερά.
        /// αποδίδει `self << mask(rhs)`, όπου το `mask` αφαιρεί τυχόν bit υψηλής τάξης του `rhs` που θα προκαλούσαν τη μετατόπιση να υπερβεί το εύρος bit του τύπου.
        ///
        /// Σημειώστε ότι αυτό *δεν* είναι το ίδιο με μια περιστροφή-αριστερά.Το RHS ενός τυλίγματος αριστερά περιορίζεται στο εύρος του τύπου, παρά τα bit που μετατοπίζονται από το LHS επιστρέφονται στο άλλο άκρο.
        /// Οι πρωτόγονοι ακέραιοι τύποι όλοι εφαρμόζουν μια συνάρτηση [`rotate_left`](Self::rotate_left), η οποία μπορεί να είναι αυτή που θέλετε.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // ΑΣΦΑΛΕΙΑ: η κάλυψη από το bitsize του τύπου διασφαλίζει ότι δεν θα αλλάξουμε
            // εκτός ορίων
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic χωρίς δεξιόστροφη μετατόπιση δεξιά;
        /// αποδίδει `self >> mask(rhs)`, όπου το `mask` αφαιρεί τυχόν bit υψηλής τάξης του `rhs` που θα προκαλούσαν τη μετατόπιση να υπερβεί το εύρος bit του τύπου.
        ///
        /// Σημειώστε ότι αυτό *δεν* είναι το ίδιο με μια περιστροφή προς τα δεξιά.το RHS ενός περιτυλίγματος-δεξιού περιορισμού περιορίζεται στο εύρος του τύπου, αντί των bit που μετατοπίζονται από το LHS να επιστρέφονται στο άλλο άκρο.
        /// Οι πρωτόγονοι ακέραιοι τύποι όλοι εφαρμόζουν μια συνάρτηση [`rotate_right`](Self::rotate_right), η οποία μπορεί να είναι αυτή που θέλετε.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // ΑΣΦΑΛΕΙΑ: η κάλυψη από το bitsize του τύπου διασφαλίζει ότι δεν θα αλλάξουμε
            // εκτός ορίων
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Αναδίπλωση (modular) εκθετικότητας.
        /// Υπολογίζει το `self.pow(exp)`, τυλίγοντας στο όριο του τύπου.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // από exp!=0, τελικά το exp πρέπει να είναι 1.
            // Αντιμετωπίστε το τελικό κομμάτι του εκθέτη ξεχωριστά, καθώς το τετράγωνο της βάσης μετά δεν είναι απαραίτητο και μπορεί να προκαλέσει περιττή υπερχείλιση.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Υπολογίζει `self` + `rhs`
        ///
        /// Επιστρέφει μια πλειάδα της προσθήκης μαζί με ένα boolean που δείχνει εάν θα συμβεί μια αριθμητική υπερχείλιση.
        /// Εάν είχε προκύψει υπερχείλιση τότε επιστρέφεται η τυλιγμένη τιμή.
        ///
        /// # Examples
        ///
        /// Βασική χρήση
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Υπολογίζει `self`, `rhs`
        ///
        /// Επιστρέφει μια πλειάδα της αφαίρεσης μαζί με ένα boolean που υποδεικνύει εάν θα συμβεί μια αριθμητική υπερχείλιση.
        /// Εάν είχε προκύψει υπερχείλιση τότε επιστρέφεται η τυλιγμένη τιμή.
        ///
        /// # Examples
        ///
        /// Βασική χρήση
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Υπολογίζει τον πολλαπλασιασμό των `self` και `rhs`.
        ///
        /// Επιστρέφει μια πλειάδα του πολλαπλασιασμού μαζί με ένα boolean που υποδεικνύει εάν θα συμβεί μια αριθμητική υπερχείλιση.
        /// Εάν είχε προκύψει υπερχείλιση τότε επιστρέφεται η τυλιγμένη τιμή.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// Λάβετε υπόψη ότι αυτό το παράδειγμα κοινοποιείται μεταξύ ακέραιων τύπων.
        /// Αυτό εξηγεί γιατί χρησιμοποιείται το `u32` εδώ.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Υπολογίζει τον διαιρέτη όταν το `self` διαιρείται με το `rhs`.
        ///
        /// Επιστρέφει μια πλειάδα του διαιρέτη μαζί με ένα boolean που δείχνει εάν θα συμβεί μια αριθμητική υπερχείλιση.
        /// Σημειώστε ότι για μη υπογεγραμμένους ακέραιους αριθμούς δεν υπάρχει υπερχείλιση, επομένως η δεύτερη τιμή είναι πάντα `false`.
        ///
        /// # Panics
        ///
        /// Αυτή η συνάρτηση θα panic εάν το `rhs` είναι 0.
        ///
        /// # Examples
        ///
        /// Βασική χρήση
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Υπολογίζει το πηλίκο της ευκλείδειας διαίρεσης `self.div_euclid(rhs)`.
        ///
        /// Επιστρέφει μια πλειάδα του διαιρέτη μαζί με ένα boolean που δείχνει εάν θα συμβεί μια αριθμητική υπερχείλιση.
        /// Σημειώστε ότι για μη υπογεγραμμένους ακέραιους αριθμούς δεν υπάρχει υπερχείλιση, επομένως η δεύτερη τιμή είναι πάντα `false`.
        /// Επειδή, για τους θετικούς ακέραιους αριθμούς, όλοι οι κοινοί ορισμοί της διαίρεσης είναι ίσοι, αυτό είναι ακριβώς ίσο με το `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Αυτή η συνάρτηση θα panic εάν το `rhs` είναι 0.
        ///
        /// # Examples
        ///
        /// Βασική χρήση
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Υπολογίζει το υπόλοιπο όταν το `self` διαιρείται με το `rhs`.
        ///
        /// Επιστρέφει μια πλειάδα του υπολοίπου μετά τη διαίρεση μαζί με ένα boolean που υποδεικνύει εάν θα συμβεί μια αριθμητική υπερχείλιση.
        /// Σημειώστε ότι για μη υπογεγραμμένους ακέραιους αριθμούς δεν υπάρχει υπερχείλιση, επομένως η δεύτερη τιμή είναι πάντα `false`.
        ///
        /// # Panics
        ///
        /// Αυτή η συνάρτηση θα panic εάν το `rhs` είναι 0.
        ///
        /// # Examples
        ///
        /// Βασική χρήση
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Υπολογίζει το υπόλοιπο `self.rem_euclid(rhs)` σαν από την ευκλείδεια διαίρεση.
        ///
        /// Επιστρέφει μια πλειάδα του modulo μετά τη διαίρεση μαζί με ένα boolean που δείχνει εάν θα συμβεί μια αριθμητική υπερχείλιση.
        /// Σημειώστε ότι για μη υπογεγραμμένους ακέραιους αριθμούς δεν υπάρχει υπερχείλιση, επομένως η δεύτερη τιμή είναι πάντα `false`.
        /// Επειδή, για τους θετικούς ακέραιους αριθμούς, όλοι οι κοινοί ορισμοί της διαίρεσης είναι ίσοι, αυτή η λειτουργία είναι ακριβώς ίση με `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Αυτή η συνάρτηση θα panic εάν το `rhs` είναι 0.
        ///
        /// # Examples
        ///
        /// Βασική χρήση
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Αρνείται τον εαυτό με υπερχείλιση.
        ///
        /// Επιστρέφει το `!self + 1` χρησιμοποιώντας λειτουργίες αναδίπλωσης για να επιστρέψει την τιμή που αντιπροσωπεύει την άρνηση αυτής της μη υπογεγραμμένης τιμής.
        /// Σημειώστε ότι για θετικές μη υπογεγραμμένες τιμές εμφανίζεται πάντα υπερχείλιση, αλλά η άρνηση 0 δεν υπερχείλιση.
        ///
        /// # Examples
        ///
        /// Βασική χρήση
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Αλλάζει μόνος-αριστερός από `rhs` bits.
        ///
        /// Επιστρέφει μια πλειάδα της μετατοπισμένης έκδοσης του εαυτού μαζί με ένα boolean που δείχνει εάν η τιμή μετατόπισης ήταν μεγαλύτερη ή ίση με τον αριθμό των bit.
        /// Εάν η τιμή μετατόπισης είναι πολύ μεγάλη, τότε η τιμή αποκρύπτεται (N-1) όπου N είναι ο αριθμός των bit και στη συνέχεια αυτή η τιμή χρησιμοποιείται για την εκτέλεση της αλλαγής.
        ///
        /// # Examples
        ///
        /// Βασική χρήση
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Μετατοπίζεται δεξιά από bit `rhs`.
        ///
        /// Επιστρέφει μια πλειάδα της μετατοπισμένης έκδοσης του εαυτού μαζί με ένα boolean που δείχνει εάν η τιμή μετατόπισης ήταν μεγαλύτερη ή ίση με τον αριθμό των bit.
        /// Εάν η τιμή μετατόπισης είναι πολύ μεγάλη, τότε η τιμή αποκρύπτεται (N-1) όπου N είναι ο αριθμός των bit και στη συνέχεια αυτή η τιμή χρησιμοποιείται για την εκτέλεση της αλλαγής.
        ///
        /// # Examples
        ///
        /// Βασική χρήση
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Αυξάνει τον εαυτό του στη δύναμη του `exp`, χρησιμοποιώντας εκτόνωση με τετράγωνο.
        ///
        /// Επιστρέφει μια πλειάδα εκθέσεως μαζί με ένα bool που δείχνει εάν συνέβη υπερχείλιση.
        ///
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, αλήθεια));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Χώρος γρατσουνιών για την αποθήκευση αποτελεσμάτων του overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // από exp!=0, τελικά το exp πρέπει να είναι 1.
            // Αντιμετωπίστε το τελικό κομμάτι του εκθέτη ξεχωριστά, καθώς το τετράγωνο της βάσης μετά δεν είναι απαραίτητο και μπορεί να προκαλέσει περιττή υπερχείλιση.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Αυξάνει τον εαυτό του στη δύναμη του `exp`, χρησιμοποιώντας εκτόνωση με τετράγωνο.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // από exp!=0, τελικά το exp πρέπει να είναι 1.
            // Αντιμετωπίστε το τελικό κομμάτι του εκθέτη ξεχωριστά, καθώς το τετράγωνο της βάσης μετά δεν είναι απαραίτητο και μπορεί να προκαλέσει περιττή υπερχείλιση.
            //
            //
            acc * base
        }

        /// Εκτελεί ευκλείδεια διαίρεση.
        ///
        /// Επειδή, για τους θετικούς ακέραιους αριθμούς, όλοι οι κοινοί ορισμοί της διαίρεσης είναι ίσοι, αυτό είναι ακριβώς ίσο με το `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Αυτή η συνάρτηση θα panic εάν το `rhs` είναι 0.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Υπολογίζει το λιγότερο υπόλοιπο του `self (mod rhs)`.
        ///
        /// Επειδή, για τους θετικούς ακέραιους αριθμούς, όλοι οι κοινοί ορισμοί της διαίρεσης είναι ίσοι, αυτό είναι ακριβώς ίσο με το `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Αυτή η συνάρτηση θα panic εάν το `rhs` είναι 0.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Επιστρέφει `true` εάν και μόνο εάν `self == 2^k` για περίπου `k`.
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Επιστρέφει ένα λιγότερο από την επόμενη ισχύ των δύο.
        // (Για 8u8 η επόμενη ισχύς των δύο είναι 8u8 και για 6u8 είναι 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Αυτή η μέθοδος δεν μπορεί να υπερχειλίσει, καθώς στις περιπτώσεις υπερχείλισης `next_power_of_two` καταλήγει να επιστρέφει τη μέγιστη τιμή του τύπου και μπορεί να επιστρέψει 0 για 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // ΑΣΦΑΛΕΙΑ: Επειδή το `p > 0`, δεν μπορεί να αποτελείται αποκλειστικά από κορυφαία μηδενικά.
            // Αυτό σημαίνει ότι η μετατόπιση είναι πάντα εντός των ορίων και ορισμένοι επεξεργαστές (όπως το Intel pre-haswell) έχουν πιο αποτελεσματική εγγενή ctlz όταν το επιχείρημα δεν είναι μηδέν.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Επιστρέφει τη μικρότερη ισχύ δύο μεγαλύτερων ή ίσων με `self`.
        ///
        /// Όταν η τιμή επιστροφής υπερχειλίζει (δηλ. `self > (1 << (N-1))` για τον τύπο `uN`), panics σε κατάσταση εντοπισμού σφαλμάτων και η τιμή επιστροφής τυλίγεται στο 0 σε λειτουργία απελευθέρωσης (η μόνη κατάσταση στην οποία η μέθοδος μπορεί να επιστρέψει 0).
        ///
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Επιστρέφει τη μικρότερη ισχύ δύο μεγαλύτερων ή ίσων με `n`.
        /// Εάν η επόμενη ισχύς των δύο είναι μεγαλύτερη από τη μέγιστη τιμή του τύπου, επιστρέφεται το `None`, διαφορετικά η ισχύς των δύο είναι τυλιγμένη στο `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Επιστρέφει τη μικρότερη ισχύ δύο μεγαλύτερων ή ίσων με `n`.
        /// Εάν η επόμενη ισχύς των δύο είναι μεγαλύτερη από τη μέγιστη τιμή του τύπου, η τιμή επιστροφής τυλίγεται στο `0`.
        ///
        ///
        /// # Examples
        ///
        /// Βασική χρήση:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Επιστρέψτε την αναπαράσταση της μνήμης αυτού του ακέραιου ως πίνακα byte σε σειρά μεγάλου endian (network) byte.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Επιστρέψτε την αναπαράσταση της μνήμης αυτού του ακέραιου ως πίνακα byte σε σειρά byt-endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Επιστρέψτε την αναπαράσταση της μνήμης αυτού του ακέραιου ως πίνακα byte σε εγγενή σειρά byte.
        ///
        /// Καθώς χρησιμοποιείται το εγγενές endianness της πλατφόρμας στόχου, ο φορητός κώδικας θα πρέπει να χρησιμοποιεί [`to_be_bytes`] ή [`to_le_bytes`], ανάλογα με την περίπτωση.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, εάν cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } αλλιώς {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // ΑΣΦΑΛΕΙΑ: ήχος const επειδή οι ακέραιοι είναι απλοί παλιοί τύποι δεδομένων, έτσι μπορούμε πάντα
        // μεταδώστε τα σε συστοιχίες byte
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // ΑΣΦΑΛΕΙΑ: οι ακέραιοι αριθμοί είναι απλοί παλιοί τύποι δεδομένων, ώστε να μπορούμε πάντα να τους μεταδίδουμε
            // πίνακες byte
            unsafe { mem::transmute(self) }
        }

        /// Επιστρέψτε την αναπαράσταση της μνήμης αυτού του ακέραιου ως πίνακα byte σε εγγενή σειρά byte.
        ///
        ///
        /// [`to_ne_bytes`] πρέπει να προτιμάται από αυτό όποτε είναι δυνατόν.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// ας bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, εάν cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } αλλιώς {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // ΑΣΦΑΛΕΙΑ: οι ακέραιοι αριθμοί είναι απλοί παλιοί τύποι δεδομένων, ώστε να μπορούμε πάντα να τους μεταδίδουμε
            // πίνακες byte
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Δημιουργήστε μια εγγενή ακέραια τιμή endian από την αναπαράστασή του ως πίνακα byte σε μεγάλο endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// χρησιμοποιήστε το std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * είσοδος=ανάπαυση;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Δημιουργήστε μια εγγενή ακέραια τιμή endian από την αναπαράστασή του ως πίνακα byte σε λίγο endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// χρησιμοποιήστε το std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * είσοδος=ανάπαυση;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Δημιουργήστε μια εγγενή ακέραια τιμή από την αναπαράσταση της μνήμης ως πίνακα byte στο εγγενές endianness.
        ///
        /// Καθώς χρησιμοποιείται το εγγενές endianness της πλατφόρμας στόχου, ο φορητός κώδικας πιθανότατα θέλει να χρησιμοποιήσει [`from_be_bytes`] ή [`from_le_bytes`], ανάλογα με την περίπτωση.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } αλλιώς {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// χρησιμοποιήστε το std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * είσοδος=ανάπαυση;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // ΑΣΦΑΛΕΙΑ: ήχος const επειδή οι ακέραιοι είναι απλοί παλιοί τύποι δεδομένων, έτσι μπορούμε πάντα
        // μεταδώστε σε αυτούς
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // ΑΣΦΑΛΕΙΑ: οι ακέραιοι αριθμοί είναι απλοί παλιοί τύποι δεδομένων, ώστε να μπορούμε πάντα να τους μεταδίδουμε
            unsafe { mem::transmute(bytes) }
        }

        /// Ο νέος κωδικός πρέπει να προτιμά να χρησιμοποιείται
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Επιστρέφει τη μικρότερη τιμή που μπορεί να αναπαρασταθεί από αυτόν τον ακέραιο τύπο.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Ο νέος κωδικός πρέπει να προτιμά να χρησιμοποιείται
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Επιστρέφει τη μεγαλύτερη τιμή που μπορεί να αναπαρασταθεί από αυτόν τον ακέραιο τύπο.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}