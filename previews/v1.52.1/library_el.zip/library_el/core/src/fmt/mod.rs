//! Βοηθητικά προγράμματα για μορφοποίηση και εκτύπωση συμβολοσειρών.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// Πιθανές ευθυγραμμίσεις που επιστρέφονται από το `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Ένδειξη ότι τα περιεχόμενα πρέπει να ευθυγραμμιστούν αριστερά.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Ένδειξη ότι τα περιεχόμενα πρέπει να είναι σωστά ευθυγραμμισμένα.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Ένδειξη ότι τα περιεχόμενα πρέπει να είναι στοίχιση στο κέντρο.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Ο τύπος που επιστρέφεται με μεθόδους μορφοποίησης.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Ο τύπος σφάλματος που επιστρέφεται από τη μορφοποίηση ενός μηνύματος σε μια ροή.
///
/// Αυτός ο τύπος δεν υποστηρίζει τη μετάδοση σφάλματος εκτός από το ότι προέκυψε σφάλμα.
/// Οποιαδήποτε επιπλέον πληροφορία πρέπει να ρυθμιστεί ώστε να μεταδίδεται με άλλα μέσα.
///
/// Ένα σημαντικό πράγμα που πρέπει να θυμάστε είναι ότι ο τύπος `fmt::Error` δεν πρέπει να συγχέεται με το [`std::io::Error`] ή το [`std::error::Error`], το οποίο μπορεί επίσης να έχετε στο πεδίο εφαρμογής.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// Ένα trait για εγγραφή ή μορφοποίηση σε buffer ή ροές που δέχονται Unicode.
///
/// Αυτό το trait δέχεται μόνο κωδικοποιημένα δεδομένα UTF-8 και δεν είναι [flushable].
/// Εάν θέλετε μόνο να αποδεχτείτε το Unicode και δεν χρειάζεστε έξαψη, θα πρέπει να εφαρμόσετε αυτό το trait.
/// Διαφορετικά θα πρέπει να εφαρμόσετε το [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Γράφει ένα κομμάτι συμβολοσειράς σε αυτόν τον συγγραφέα, επιστρέφοντας εάν η εγγραφή πέτυχε.
    ///
    /// Αυτή η μέθοδος μπορεί να επιτύχει μόνο εάν ολόκληρο το κομμάτι συμβολοσειράς γράφτηκε με επιτυχία και αυτή η μέθοδος δεν θα επιστρέψει έως ότου όλα τα δεδομένα έχουν γραφτεί ή παρουσιαστεί σφάλμα.
    ///
    ///
    /// # Errors
    ///
    /// Αυτή η συνάρτηση θα επιστρέψει μια παρουσία [`Error`] σε σφάλμα.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Γράφει ένα [`char`] σε αυτόν τον συγγραφέα, επιστρέφοντας εάν η εγγραφή πέτυχε.
    ///
    /// Ένα μεμονωμένο [`char`] μπορεί να κωδικοποιηθεί ως περισσότερα από ένα byte.
    /// Αυτή η μέθοδος μπορεί να επιτύχει μόνο εάν ολόκληρη η ακολουθία byte γράφτηκε με επιτυχία και αυτή η μέθοδος δεν θα επιστρέψει έως ότου όλα τα δεδομένα έχουν γραφτεί ή παρουσιαστεί σφάλμα.
    ///
    ///
    /// # Errors
    ///
    /// Αυτή η συνάρτηση θα επιστρέψει μια παρουσία [`Error`] σε σφάλμα.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Κόλλα για χρήση της μακροεντολής [`write!`] με τους υλοποιητές αυτού του trait.
    ///
    /// Αυτή η μέθοδος δεν πρέπει γενικά να καλείται χειροκίνητα, αλλά μέσω της ίδιας της μακροεντολής [`write!`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Διαμόρφωση για μορφοποίηση.
///
/// Το `Formatter` αντιπροσωπεύει διάφορες επιλογές που σχετίζονται με τη μορφοποίηση.
/// Οι χρήστες δεν κατασκευάζουν απευθείας το "Formatter".μια μεταβλητή αναφορά σε μία μεταβιβάζεται στη μέθοδο `fmt` όλων των μορφοποιήσεων traits, όπως [`Debug`] και [`Display`].
///
///
/// Για να αλληλεπιδράσετε με ένα `Formatter`, θα καλέσετε διάφορες μεθόδους για να αλλάξετε τις διάφορες επιλογές που σχετίζονται με τη μορφοποίηση.
/// Για παραδείγματα, ανατρέξτε στην τεκμηρίωση των μεθόδων που ορίζονται στο `Formatter` παρακάτω.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Το επιχείρημα είναι ουσιαστικά μια βελτιστοποιημένη μερικώς εφαρμοσμένη λειτουργία μορφοποίησης, ισοδύναμη με `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// Αυτή η δομή αντιπροσωπεύει το γενικό "argument" που λαμβάνεται από την οικογένεια λειτουργιών Xprintf.Περιέχει μια συνάρτηση για τη μορφοποίηση της δεδομένης τιμής.
/// Κατά το χρόνο μεταγλώττισης διασφαλίζεται ότι η συνάρτηση και η τιμή έχουν τους σωστούς τύπους και, στη συνέχεια, αυτή η δομή χρησιμοποιείται για την κανονικοποίηση ορισμάτων σε έναν τύπο.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Αυτό εγγυάται μια σταθερή τιμή για το δείκτη συνάρτησης που σχετίζεται με το indices/counts στην υποδομή μορφοποίησης.
//
// Λάβετε υπόψη ότι μια συνάρτηση που ορίζεται ως τέτοια δεν θα ήταν σωστή, καθώς οι συναρτήσεις επισημαίνονται πάντα χωρίς όνομα_addr με την τρέχουσα μείωση σε LLVM IR, επομένως η διεύθυνσή τους δεν θεωρείται σημαντική για το LLVM και ως εκ τούτου το cast as_usize θα μπορούσε να είχε παραπλανηθεί.
//
// Στην πράξη, δεν καλούμε ποτέ as_usize σε δεδομένα που δεν χρησιμοποιούν (ως ζήτημα στατικής δημιουργίας των ορισμάτων μορφοποίησης), οπότε αυτό είναι απλώς ένας πρόσθετος έλεγχος.
//
// Θέλουμε κυρίως να διασφαλίσουμε ότι ο δείκτης συνάρτησης στο `USIZE_MARKER` έχει μια διεύθυνση που αντιστοιχεί *μόνο* σε συναρτήσεις που λαμβάνουν επίσης το `&usize` ως το πρώτο επιχείρημά τους.
// Το read_volatile εδώ διασφαλίζει ότι μπορούμε με ασφάλεια να ετοιμάσουμε ένα usize από τη διαβιβαζόμενη αναφορά και ότι αυτή η διεύθυνση δεν δείχνει μια λειτουργία μη χρήσης.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // ΑΣΦΑΛΕΙΑ: Το ptr είναι μια αναφορά
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // ΑΣΦΑΛΕΙΑ: Το `mem::transmute(x)` είναι ασφαλές επειδή
        //     1. `&'b T` διατηρεί τη διάρκεια ζωής που προήλθε από το `'b` (ώστε να μην έχει απεριόριστη διάρκεια ζωής)
        //     2.
        //     `&'b T` και `&'b Opaque` έχουν την ίδια διάταξη μνήμης (όταν το `T` είναι `Sized`, όπως είναι εδώ) `mem::transmute(f)` είναι ασφαλές, καθώς τα `fn(&T, &mut Formatter<'_>) -> Result` και `fn(&Opaque, &mut Formatter<'_>) -> Result` έχουν το ίδιο ABI (εφόσον το `T` είναι `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // ΑΣΦΑΛΕΙΑ: Το πεδίο `formatter` έχει οριστεί μόνο σε USIZE_MARKER εάν
            // η τιμή είναι ένα usize, οπότε αυτό είναι ασφαλές
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// σημαίες διαθέσιμες σε μορφή v1 του format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Όταν χρησιμοποιείτε τη μακροεντολή format_args! (), Αυτή η συνάρτηση χρησιμοποιείται για τη δημιουργία της δομής Επιχειρήσεων.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Αυτή η λειτουργία χρησιμοποιείται για τον καθορισμό παραμέτρων μη τυπικής μορφοποίησης.
    /// Ο πίνακας `pieces` πρέπει να είναι τουλάχιστον όσο `fmt` για την κατασκευή μιας έγκυρης δομής Επιχειρήσεων.
    /// Επίσης, κάθε `Count` εντός `fmt` που είναι `CountIsParam` ή `CountIsNextParam` πρέπει να οδηγεί σε ένα επιχείρημα που δημιουργήθηκε με το `argumentusize`.
    ///
    /// Ωστόσο, το να μην το κάνετε αυτό δεν προκαλεί ασφάλεια, αλλά θα αγνοήσει το άκυρο.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Υπολογίζει το μήκος του μορφοποιημένου κειμένου.
    ///
    /// Αυτό προορίζεται να χρησιμοποιηθεί για τον καθορισμό της αρχικής χωρητικότητας `String` κατά τη χρήση του `format!`.
    /// Note: αυτό δεν είναι ούτε το κατώτερο ούτε το ανώτερο όριο.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Εάν η συμβολοσειρά μορφής ξεκινά με ένα όρισμα, μην προκαταχωρίσετε τίποτα, εκτός εάν το μήκος των κομματιών είναι σημαντικό.
            //
            //
            0
        } else {
            // Υπάρχουν ορισμένα επιχειρήματα, οπότε οποιαδήποτε επιπλέον ώθηση θα ανακατανείμει τη συμβολοσειρά.
            //
            // Για να το αποφύγουμε, είμαστε "pre-doubling" εδώ.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Αυτή η δομή αντιπροσωπεύει μια ασφαλή προ-μεταγλωττισμένη έκδοση μιας συμβολοσειράς μορφής και των ορισμάτων της.
/// Αυτό δεν μπορεί να δημιουργηθεί κατά το χρόνο εκτέλεσης, επειδή δεν μπορεί να γίνει με ασφάλεια, οπότε δεν δίνονται κατασκευαστές και τα πεδία είναι ιδιωτικά για την αποφυγή τροποποίησης.
///
///
/// Η μακροεντολή [`format_args!`] θα δημιουργήσει με ασφάλεια μια παρουσία αυτής της δομής.
/// Η μακροεντολή επικυρώνει τη συμβολοσειρά μορφής κατά το χρόνο μεταγλώττισης, ώστε η χρήση των συναρτήσεων [`write()`] και [`format()`] να μπορεί να εκτελεστεί με ασφάλεια.
///
/// Μπορείτε να χρησιμοποιήσετε το `Arguments<'a>` που επιστρέφει το [`format_args!`] σε περιβάλλον `Debug` και `Display` όπως φαίνεται παρακάτω.
/// Το παράδειγμα δείχνει επίσης ότι η μορφή `Debug` και `Display` στο ίδιο πράγμα: η συμβολοσειρά παρεμβολής μορφής στο `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Μορφοποιήστε κομμάτια συμβολοσειράς για εκτύπωση.
    pieces: &'a [&'static str],

    // Προδιαγραφές placeholder ή `None` εάν όλες οι προδιαγραφές είναι προεπιλεγμένες (όπως στο "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // Δυναμικά ορίσματα για παρεμβολή, που θα παρεμβληθούν με κομμάτια συμβολοσειράς.
    // (Σε κάθε επιχείρημα προηγείται ένα κομμάτι συμβολοσειράς.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Αποκτήστε τη μορφοποιημένη συμβολοσειρά, εάν δεν έχει ορίσματα για μορφοποίηση.
    ///
    /// Αυτό μπορεί να χρησιμοποιηθεί για την αποφυγή κατανομών στην πιο ασήμαντη περίπτωση.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` θα πρέπει να μορφοποιήσει την έξοδο σε περιβάλλον προγραμματισμού και εντοπισμού σφαλμάτων.
///
/// Σε γενικές γραμμές, θα πρέπει απλώς `derive` μια εφαρμογή `Debug`.
///
/// Όταν χρησιμοποιείται με τον προσδιοριστή εναλλακτικής μορφής `#?`, η έξοδος είναι αρκετά τυπωμένη.
///
/// Για περισσότερες πληροφορίες σχετικά με τους μορφοποιητές, ανατρέξτε στο [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// Αυτό το trait μπορεί να χρησιμοποιηθεί με `#[derive]` εάν όλα τα πεδία εφαρμόζουν `Debug`.
/// Όταν `derive`d για δομές, θα χρησιμοποιεί το όνομα του `struct`, έπειτα του `{`, έπειτα μια λίστα διαχωρισμένη με κόμμα για το όνομα κάθε πεδίου και την τιμή `Debug` και έπειτα το `}`.
/// Για το «enum`s, θα χρησιμοποιεί το όνομα της παραλλαγής και, εάν υπάρχει, `(`, τότε τις τιμές `Debug` των πεδίων και στη συνέχεια `)`.
///
/// # Stability
///
/// Οι παράγωγες μορφές `Debug` δεν είναι σταθερές και έτσι μπορεί να αλλάξουν με τις εκδόσεις future Rust.
/// Επιπλέον, οι υλοποιήσεις `Debug` τύπων που παρέχονται από την τυπική βιβλιοθήκη (`libstd`, `libcore`, `liballoc` κ.λπ.) δεν είναι σταθερές και ενδέχεται επίσης να αλλάξουν με τις εκδόσεις future Rust.
///
///
/// # Examples
///
/// Δημιουργία εφαρμογής:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Μη αυτόματη εφαρμογή:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Υπάρχουν διάφορες βοηθητικές μέθοδοι στη δομή [`Formatter`] για να σας βοηθήσουν με χειροκίνητες υλοποιήσεις, όπως το [`debug_struct`].
///
/// `Debug` Οι υλοποιήσεις που χρησιμοποιούν είτε το `derive` είτε το API εντοπισμού σφαλμάτων στο [`Formatter`] υποστηρίζουν την όμορφη εκτύπωση χρησιμοποιώντας την εναλλακτική σημαία: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Όμορφη εκτύπωση με `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Μορφοποιεί την τιμή χρησιμοποιώντας τον δεδομένο μορφοποιητή.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// Ξεχωριστή ενότητα για επανεξαγωγή της μακροεντολής `Debug` από prelude χωρίς το trait `Debug`.
pub(crate) mod macros {
    /// Παράγει μακροεντολή που δημιουργεί ένα impl του trait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Μορφή trait για μια κενή μορφή, `{}`.
///
/// `Display` είναι παρόμοιο με το [`Debug`], αλλά το `Display` προορίζεται για έξοδο που βλέπει ο χρήστης και έτσι δεν μπορεί να προκύψει.
///
///
/// Για περισσότερες πληροφορίες σχετικά με τους μορφοποιητές, ανατρέξτε στο [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Εφαρμογή `Display` σε έναν τύπο:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Μορφοποιεί την τιμή χρησιμοποιώντας τον δεδομένο μορφοποιητή.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// Το `Octal` trait θα πρέπει να μορφοποιήσει την έξοδο του ως αριθμό στο base-8.
///
/// Για πρωτόγονους υπογεγραμμένους ακέραιους αριθμούς (`i8` έως `i128` και `isize`), οι αρνητικές τιμές μορφοποιούνται ως παράσταση συμπληρώματος των δύο.
///
///
/// Η εναλλακτική σημαία, `#`, προσθέτει ένα `0o` μπροστά από την έξοδο.
///
/// Για περισσότερες πληροφορίες σχετικά με τους μορφοποιητές, ανατρέξτε στο [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Βασική χρήση με `i32`:
///
/// ```
/// let x = 42; // Το 42 είναι '52' σε οκτάλη
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// Εφαρμογή `Octal` σε έναν τύπο:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // αναθέστε την υλοποίηση του i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Μορφοποιεί την τιμή χρησιμοποιώντας τον δεδομένο μορφοποιητή.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// Το `Binary` trait θα πρέπει να μορφοποιήσει την έξοδο του ως αριθμό σε δυαδικό.
///
/// Για πρωτόγονους υπογεγραμμένους ακέραιους αριθμούς ([`i8`] έως [`i128`] και [`isize`]), οι αρνητικές τιμές μορφοποιούνται ως παράσταση συμπληρώματος των δύο.
///
///
/// Η εναλλακτική σημαία, `#`, προσθέτει ένα `0b` μπροστά από την έξοδο.
///
/// Για περισσότερες πληροφορίες σχετικά με τους μορφοποιητές, ανατρέξτε στο [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Βασική χρήση με [`i32`]:
///
/// ```
/// let x = 42; // 42 είναι '101010' σε δυαδικό
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// Εφαρμογή `Binary` σε έναν τύπο:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // αναθέστε την υλοποίηση του i32
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Μορφοποιεί την τιμή χρησιμοποιώντας τον δεδομένο μορφοποιητή.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// Το `LowerHex` trait θα πρέπει να μορφοποιήσει την έξοδο του ως αριθμό σε δεκαεξαδικό, με `a` έως `f` σε πεζά γράμματα.
///
/// Για πρωτόγονους υπογεγραμμένους ακέραιους αριθμούς (`i8` έως `i128` και `isize`), οι αρνητικές τιμές μορφοποιούνται ως παράσταση συμπληρώματος των δύο.
///
///
/// Η εναλλακτική σημαία, `#`, προσθέτει ένα `0x` μπροστά από την έξοδο.
///
/// Για περισσότερες πληροφορίες σχετικά με τους μορφοποιητές, ανατρέξτε στο [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Βασική χρήση με `i32`:
///
/// ```
/// let x = 42; // 42 είναι '2a' σε δεκαεξαδικό
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// Εφαρμογή `LowerHex` σε έναν τύπο:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // αναθέστε την υλοποίηση του i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Μορφοποιεί την τιμή χρησιμοποιώντας τον δεδομένο μορφοποιητή.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// Το `UpperHex` trait θα πρέπει να μορφοποιεί την έξοδο του ως αριθμό σε δεκαεξαδικό, με `A` έως `F` στην κεφαλαία.
///
/// Για πρωτόγονους υπογεγραμμένους ακέραιους αριθμούς (`i8` έως `i128` και `isize`), οι αρνητικές τιμές μορφοποιούνται ως παράσταση συμπληρώματος των δύο.
///
///
/// Η εναλλακτική σημαία, `#`, προσθέτει ένα `0x` μπροστά από την έξοδο.
///
/// Για περισσότερες πληροφορίες σχετικά με τους μορφοποιητές, ανατρέξτε στο [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Βασική χρήση με `i32`:
///
/// ```
/// let x = 42; // 42 είναι '2A' σε δεκαεξαδικό
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// Εφαρμογή `UpperHex` σε έναν τύπο:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // αναθέστε την υλοποίηση του i32
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Μορφοποιεί την τιμή χρησιμοποιώντας τον δεδομένο μορφοποιητή.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// Το `Pointer` trait θα πρέπει να διαμορφώσει την έξοδο του ως θέση μνήμης.
/// Αυτό παρουσιάζεται συνήθως ως δεκαεξαδικό.
///
/// Για περισσότερες πληροφορίες σχετικά με τους μορφοποιητές, ανατρέξτε στο [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Βασική χρήση με `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // αυτό παράγει κάτι σαν το '0x7f06092ac6d0'
/// ```
///
/// Εφαρμογή `Pointer` σε έναν τύπο:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // χρησιμοποιήστε το `as` για να μετατρέψετε σε `*const T`, το οποίο εφαρμόζει το δείκτη, το οποίο μπορούμε να χρησιμοποιήσουμε
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Μορφοποιεί την τιμή χρησιμοποιώντας τον δεδομένο μορφοποιητή.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// Το `LowerExp` trait θα πρέπει να μορφοποιήσει την έξοδο του σε επιστημονική σημειογραφία με πεζά `e`.
///
/// Για περισσότερες πληροφορίες σχετικά με τους μορφοποιητές, ανατρέξτε στο [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Βασική χρήση με `f64`:
///
/// ```
/// let x = 42.0; // 42.0 είναι '4.2e1' στην επιστημονική σημειογραφία
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// Εφαρμογή `LowerExp` σε έναν τύπο:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // αναθέστε στην εφαρμογή του f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Μορφοποιεί την τιμή χρησιμοποιώντας τον δεδομένο μορφοποιητή.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// Το `UpperExp` trait θα πρέπει να μορφοποιήσει την έξοδο του σε επιστημονική σημειογραφία με κεφαλαία `E`.
///
/// Για περισσότερες πληροφορίες σχετικά με τους μορφοποιητές, ανατρέξτε στο [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Βασική χρήση με `f64`:
///
/// ```
/// let x = 42.0; // 42.0 είναι '4.2E1' στην επιστημονική σημειογραφία
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// Εφαρμογή `UpperExp` σε έναν τύπο:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // αναθέστε στην εφαρμογή του f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Μορφοποιεί την τιμή χρησιμοποιώντας τον δεδομένο μορφοποιητή.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// Η συνάρτηση `write` παίρνει μια ροή εξόδου και μια δομή `Arguments` που μπορεί να προρυθμιστεί με τη μακροεντολή `format_args!`.
///
///
/// Τα ορίσματα θα μορφοποιηθούν σύμφωνα με την καθορισμένη συμβολοσειρά μορφής στη παρεχόμενη ροή εξόδου.
///
/// # Examples
///
/// Βασική χρήση:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Λάβετε υπόψη ότι η χρήση του [`write!`] μπορεί να είναι προτιμότερη.Παράδειγμα:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Μπορούμε να χρησιμοποιήσουμε τις προεπιλεγμένες παραμέτρους μορφοποίησης για όλα τα ορίσματα.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Κάθε προδιαγραφή έχει ένα αντίστοιχο όρισμα στο οποίο προηγείται ένα κομμάτι συμβολοσειράς.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // ΑΣΦΑΛΕΙΑ: το arg και το args.args προέρχονται από τα ίδια επιχειρήματα,
                // που εγγυάται ότι τα ευρετήρια είναι πάντα εντός ορίων.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Απομένει μόνο ένα κομμάτι ακολουθίας χορδών.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // ΑΣΦΑΛΕΙΑ: τα arg και args προέρχονται από τα ίδια επιχειρήματα,
    // που εγγυάται ότι τα ευρετήρια είναι πάντα εντός ορίων.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Εξαγάγετε το σωστό όρισμα
    debug_assert!(arg.position < args.len());
    // ΑΣΦΑΛΕΙΑ: τα arg και args προέρχονται από τα ίδια επιχειρήματα,
    // που εγγυάται ότι ο δείκτης είναι πάντα εντός ορίων.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Στη συνέχεια, κάντε κάποια εκτύπωση
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // ΑΣΦΑΛΕΙΑ: cnt και args προέρχονται από τα ίδια επιχειρήματα,
            // που εγγυάται ότι αυτός ο δείκτης είναι πάντα εντός ορίων.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Να γεμίσει μετά το τέλος του κάτι.Επιστράφηκε από `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Γράψτε αυτήν την ανάρτηση.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Θέλουμε να το αλλάξουμε αυτό
            buf: wrap(self.buf),

            // Και διατηρήστε τα
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Βοηθητικές μέθοδοι που χρησιμοποιούνται για το padding και την επεξεργασία ορισμάτων μορφοποίησης που μπορούν να χρησιμοποιήσουν όλες οι μορφές traits.
    //

    /// Εκτελεί τη σωστή επένδυση για έναν ακέραιο που έχει ήδη εκπεμφθεί σε ένα str.
    /// Το str δεν πρέπει * να περιέχει το σύμβολο για τον ακέραιο, που θα προστεθεί με αυτήν τη μέθοδο.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, αν ο αρχικός ακέραιος ήταν θετικός ή μηδέν.
    /// * πρόθεμα, εάν παρέχεται ο χαρακτήρας '#' (Alternate), αυτό είναι το πρόθεμα που πρέπει να τοποθετήσετε μπροστά από τον αριθμό.
    ///
    /// * buf, ο πίνακας byte στον οποίο έχει διαμορφωθεί ο αριθμός
    ///
    /// Αυτή η λειτουργία αντιστοιχεί σωστά στις παρεχόμενες σημαίες καθώς και στο ελάχιστο πλάτος.
    /// Δεν θα ληφθεί υπόψη η ακρίβεια.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // Πρέπει να αφαιρέσουμε το "-" από την έξοδο αριθμού.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Γράφει το σύμβολο εάν υπάρχει και έπειτα το πρόθεμα εάν ζητήθηκε
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // Το πεδίο `width` είναι περισσότερο παράμετρος `min-width` σε αυτό το σημείο.
        match self.width {
            // Εάν δεν υπάρχουν απαιτήσεις ελάχιστου μήκους, τότε μπορούμε απλά να γράψουμε τα byte.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Ελέγξτε εάν υπερβαίνουμε το ελάχιστο πλάτος, αν ναι, μπορούμε επίσης να γράψουμε τα byte.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Το πρόσημο και το πρόθεμα πηγαίνουν πριν από την επένδυση εάν ο χαρακτήρας πλήρωσης είναι μηδέν
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Διαφορετικά, το σύμβολο και το πρόθεμα πηγαίνουν μετά την επένδυση
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Αυτή η συνάρτηση παίρνει ένα κομμάτι συμβολοσειράς και το εκπέμπει στο εσωτερικό buffer μετά την εφαρμογή των σχετικών σημαιών μορφοποίησης που έχουν καθοριστεί.
    /// Οι σημαίες που αναγνωρίζονται για γενικές χορδές είναι:
    ///
    /// * πλάτος, το ελάχιστο πλάτος του τι πρέπει να εκπέμπει
    /// * fill/align - τι να εκπέμψετε και πού να το εκπέμψετε εάν η παρεχόμενη συμβολοσειρά πρέπει να είναι γεμισμένη
    /// * ακρίβεια, το μέγιστο μήκος που εκπέμπεται, η συμβολοσειρά περικόπτεται εάν είναι μεγαλύτερη από αυτό το μήκος
    ///
    /// Συγκεκριμένα, αυτή η λειτουργία αγνοεί τις παραμέτρους `flag`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Βεβαιωθείτε ότι υπάρχει μια γρήγορη διαδρομή μπροστά
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // Το πεδίο `precision` μπορεί να ερμηνευτεί ως `max-width` για τη συμβολοσειρά που μορφοποιείται.
        //
        let s = if let Some(max) = self.precision {
            // Εάν η συμβολοσειρά μας είναι μεγαλύτερη από την ακρίβεια, τότε πρέπει να έχουμε περικοπή.
            // Ωστόσο, άλλες σημαίες όπως `fill`, `width` και `align` πρέπει να λειτουργούν όπως πάντα.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // Το LLVM εδώ δεν μπορεί να αποδείξει ότι το `..i` δεν θα panic `&s[..i]`, αλλά γνωρίζουμε ότι δεν μπορεί να το panic.
                // Χρησιμοποιήστε το `get` + `unwrap_or` για να αποφύγετε το `unsafe` και αλλιώς μην εκπέμψετε κανένα κώδικα που σχετίζεται με το panic εδώ.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // Το πεδίο `width` είναι περισσότερο παράμετρος `min-width` σε αυτό το σημείο.
        match self.width {
            // Εάν είμαστε κάτω από το μέγιστο μήκος και δεν υπάρχουν απαιτήσεις ελάχιστου μήκους, τότε μπορούμε απλά να εκπέμψουμε τη συμβολοσειρά
            //
            None => self.buf.write_str(s),
            // Εάν είμαστε κάτω από το μέγιστο πλάτος, ελέγξτε αν υπερβαίνουμε το ελάχιστο πλάτος, αν ναι είναι τόσο εύκολο όσο η εκπομπή της συμβολοσειράς.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Εάν είμαστε κάτω από το μέγιστο και το ελάχιστο πλάτος, τότε συμπληρώστε το ελάχιστο πλάτος με την καθορισμένη συμβολοσειρά + κάποια ευθυγράμμιση.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Γράψτε το pre-padding και επιστρέψτε το άγραφο post-padding.
    /// Οι καλούντες είναι υπεύθυνοι για τη διασφάλιση της εγγραφής μετά την επένδυση μετά το πράγμα που είναι γεμισμένο.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Παίρνει τα μορφοποιημένα μέρη και εφαρμόζει την επένδυση.
    /// Υποθέτει ότι ο καλών έχει ήδη αποδώσει τα εξαρτήματα με την απαιτούμενη ακρίβεια, έτσι ώστε το `self.precision` να μπορεί να αγνοηθεί.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // για το μηδενικό μηδενικό παραγέμισμα, αποδίδουμε πρώτα το σημάδι και συμπεριφερόμαστε σαν να μην είχαμε κανένα σημάδι από την αρχή.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // ένα σημάδι πηγαίνει πάντα πρώτο
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // αφαιρέστε το σύμβολο από τα μορφοποιημένα μέρη
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // Τα υπόλοιπα μέρη περνούν από τη συνήθη διαδικασία γεμίσματος.
            let len = formatted.len();
            let ret = if width <= len {
                // χωρίς επένδυση
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // αυτή είναι η κοινή περίπτωση και παίρνουμε μια συντόμευση
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // ΑΣΦΑΛΕΙΑ: Χρησιμοποιείται για `flt2dec::Part::Num` και `flt2dec::Part::Copy`.
            // Είναι ασφαλές να χρησιμοποιηθεί για `flt2dec::Part::Num`, καθώς κάθε char `c` είναι μεταξύ `b'0'` και `b'9'`, πράγμα που σημαίνει ότι το `s` είναι έγκυρο UTF-8.
            // Είναι μάλλον ασφαλές στην πράξη να χρησιμοποιείται για το `flt2dec::Part::Copy(buf)`, καθώς το `buf` πρέπει να είναι απλό ASCII, αλλά είναι πιθανό κάποιος να περάσει σε μια κακή τιμή για το `buf` στο `flt2dec::to_shortest_str`, καθώς είναι μια δημόσια λειτουργία.
            //
            // FIXME: Προσδιορίστε εάν αυτό θα μπορούσε να οδηγήσει σε UB.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 μηδενικά
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Γράφει ορισμένα δεδομένα στο υποκείμενο buffer που περιέχεται σε αυτόν τον μορφοποιητή.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Αυτό ισοδυναμεί με:
    ///         // γράψτε! (μορφοποιητής, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Γράφει ορισμένες μορφοποιημένες πληροφορίες σε αυτήν την παρουσία.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Σημαίες για μορφοποίηση
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Ο χαρακτήρας χρησιμοποιείται ως 'fill' όποτε υπάρχει ευθυγράμμιση.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Ρυθμίζουμε την ευθυγράμμιση προς τα δεξιά με το ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Επισήμανση που υποδεικνύει ποια μορφή ευθυγράμμισης ζητήθηκε.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Προαιρετικά καθορισμένο ακέραιο πλάτος που πρέπει να είναι η έξοδος.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Εάν λάβαμε πλάτος, το χρησιμοποιούμε
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Διαφορετικά δεν κάνουμε τίποτα το ιδιαίτερο
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Προαιρετικά καθορισμένη ακρίβεια για αριθμητικούς τύπους.
    /// Εναλλακτικά, το μέγιστο πλάτος για τύπους συμβολοσειρών.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Εάν λάβαμε μια ακρίβεια, τη χρησιμοποιούμε.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Διαφορετικά είμαστε προεπιλεγμένοι στο 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Καθορίζει εάν έχει καθοριστεί η σημαία `+`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Καθορίζει εάν έχει καθοριστεί η σημαία `-`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Θέλετε ένα σύμβολο μείον;Πάρε ένα!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Καθορίζει εάν έχει καθοριστεί η σημαία `#`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Καθορίζει εάν έχει καθοριστεί η σημαία `0`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Αγνοούμε τις επιλογές του μορφοποιητή.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Αποφασίστε ποιο δημόσιο API θέλουμε για αυτές τις δύο σημαίες.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Δημιουργεί ένα πρόγραμμα δημιουργίας [`DebugStruct`] σχεδιασμένο να βοηθά στη δημιουργία εφαρμογών [`fmt::Debug`] για δομές.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Δημιουργεί ένα πρόγραμμα δημιουργίας `DebugTuple` σχεδιασμένο για να βοηθά στη δημιουργία εφαρμογών `fmt::Debug` για δομές tuple.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Δημιουργεί ένα πρόγραμμα δημιουργίας `DebugList` σχεδιασμένο να βοηθά στη δημιουργία εφαρμογών `fmt::Debug` για δομές που μοιάζουν με λίστα.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Δημιουργεί ένα πρόγραμμα δημιουργίας `DebugSet` που έχει σχεδιαστεί για να βοηθά στη δημιουργία εφαρμογών `fmt::Debug` για δομές τύπου set.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// Σε αυτό το πιο περίπλοκο παράδειγμα, χρησιμοποιούμε τα [`format_args!`] και `.debug_set()` για να δημιουργήσουμε μια λίστα με τα χέρια που ταιριάζουν:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Δημιουργεί ένα πρόγραμμα δημιουργίας `DebugMap` σχεδιασμένο για να βοηθά στη δημιουργία εφαρμογών `fmt::Debug` για δομές που μοιάζουν με χάρτη.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Εφαρμογές του πυρήνα μορφοποίησης traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Εάν ο char χρειάζεται διαφυγή, ξεκλειδώστε τα καθήκοντα μέχρι τώρα και γράψτε, αλλιώς παραλείψτε
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Η εναλλακτική σημαία αντιμετωπίζεται ήδη από το LowerHex ως ειδική-υποδηλώνει αν θα προθέσετε με 0x.
        // Το χρησιμοποιούμε για να δούμε αν θα επεκταθεί ή όχι και μετά θα το ρυθμίσουμε άνευ όρων για να λάβουμε το πρόθεμα.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Υλοποίηση του Display/Debug για διάφορους βασικούς τύπους

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // Το RefCell δανείζεται μεταβλητά, οπότε δεν μπορούμε να δούμε την αξία του εδώ.
                // Αντιθέτως, δείξτε ένα σύμβολο κράτησης θέσης.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Αν περιμένατε ότι οι δοκιμές θα είναι εδώ, δείτε το αρχείο core/tests/fmt.rs, είναι πολύ πιο εύκολο από το να δημιουργήσετε όλες τις δομές rt::Piece εδώ.
//
// Υπάρχουν επίσης δοκιμές στην κατανομή crate, για εκείνους που χρειάζονται εκχωρήσεις.