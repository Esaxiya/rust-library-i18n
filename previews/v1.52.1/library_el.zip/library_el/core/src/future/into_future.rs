use crate::future::Future;

/// Μετατροπή σε `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Η έξοδος που θα παράγει το future μετά την ολοκλήρωση.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Σε ποιο είδος future το μετατρέπουμε σε;
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Δημιουργεί ένα future από μια τιμή.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}