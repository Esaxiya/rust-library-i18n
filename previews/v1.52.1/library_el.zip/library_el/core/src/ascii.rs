//! Λειτουργίες σε συμβολοσειρές και χαρακτήρες ASCII.
//!
//! Οι περισσότερες λειτουργίες συμβολοσειράς στο Rust ενεργούν σε χορδές UTF-8.
//! Ωστόσο, κατά καιρούς είναι πιο λογικό να λαμβάνετε υπόψη το σύνολο χαρακτήρων ASCII για μια συγκεκριμένη λειτουργία.
//!
//! Η συνάρτηση [`escape_default`] παρέχει μια επανάληψη πάνω από τα byte μιας διαφυγής έκδοσης του δεδομένου χαρακτήρα.
//!
//!

#![stable(feature = "core_ascii", since = "1.26.0")]

use crate::fmt;
use crate::iter::FusedIterator;
use crate::ops::Range;
use crate::str::from_utf8_unchecked;

/// Ένας επαναληπτής πάνω από τη διαφυγή έκδοση ενός byte.
///
/// Αυτό το `struct` δημιουργείται από τη συνάρτηση [`escape_default`].
/// Δείτε την τεκμηρίωσή του για περισσότερα.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct EscapeDefault {
    range: Range<usize>,
    data: [u8; 4],
}

/// Επιστρέφει έναν επαναληπτικό που παράγει μια διαφυγή έκδοση του `u8`.
///
/// Η προεπιλογή επιλέγεται με προκατάληψη για την παραγωγή γραμματοσειρών που είναι νόμιμες σε μια ποικιλία γλωσσών, συμπεριλαμβανομένων των C++ 11 και παρόμοιων γ-γ-γλωσσών.
/// Οι ακριβείς κανόνες είναι:
///
/// * Η καρτέλα διαγράφεται ως `\t`.
/// * Η επιστροφή μεταφοράς διαφυλάσσεται ως `\r`.
/// * Η τροφοδοσία γραμμής διαγράφεται ως `\n`.
/// * Ένα μόνο απόσπασμα διαφυλάσσεται ως `\'`.
/// * Η διπλή προσφορά διαγράφεται ως `\"`.
/// * Η ανάστροφη κάθετο διαφεύγει ως `\\`.
/// * Οποιοσδήποτε χαρακτήρας στην περιοχή "εκτυπώσιμη ASCII" `0x20` .. `0x7e` inclusive δεν διαφυλάσσεται.
/// * Σε οποιονδήποτε άλλο χαρακτήρα δίνονται δεκαεξαδικές διαφυγές της φόρμας '\xNN'.
/// * Οι διαφυγές Unicode δεν δημιουργούνται ποτέ από αυτήν τη λειτουργία.
///
/// # Examples
///
/// ```
/// use std::ascii;
///
/// let escaped = ascii::escape_default(b'0').next().unwrap();
/// assert_eq!(b'0', escaped);
///
/// let mut escaped = ascii::escape_default(b'\t');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b't', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\r');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'r', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\n');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'n', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\'');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\'', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'"');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'"', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\\');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\\', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\x9d');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'x', escaped.next().unwrap());
/// assert_eq!(b'9', escaped.next().unwrap());
/// assert_eq!(b'd', escaped.next().unwrap());
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn escape_default(c: u8) -> EscapeDefault {
    let (data, len) = match c {
        b'\t' => ([b'\\', b't', 0, 0], 2),
        b'\r' => ([b'\\', b'r', 0, 0], 2),
        b'\n' => ([b'\\', b'n', 0, 0], 2),
        b'\\' => ([b'\\', b'\\', 0, 0], 2),
        b'\'' => ([b'\\', b'\'', 0, 0], 2),
        b'"' => ([b'\\', b'"', 0, 0], 2),
        b'\x20'..=b'\x7e' => ([c, 0, 0, 0], 1),
        _ => ([b'\\', b'x', hexify(c >> 4), hexify(c & 0xf)], 4),
    };

    return EscapeDefault { range: 0..len, data };

    fn hexify(b: u8) -> u8 {
        match b {
            0..=9 => b'0' + b,
            _ => b'a' + b - 10,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Iterator for EscapeDefault {
    type Item = u8;
    fn next(&mut self) -> Option<u8> {
        self.range.next().map(|i| self.data[i])
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.range.size_hint()
    }
    fn last(mut self) -> Option<u8> {
        self.next_back()
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl DoubleEndedIterator for EscapeDefault {
    fn next_back(&mut self) -> Option<u8> {
        self.range.next_back().map(|i| self.data[i])
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ExactSizeIterator for EscapeDefault {}
#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for EscapeDefault {}

#[stable(feature = "ascii_escape_display", since = "1.39.0")]
impl fmt::Display for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // ΑΣΦΑΛΕΙΑ: εντάξει επειδή το `escape_default` δημιούργησε μόνο έγκυρα δεδομένα utf-8
        f.write_str(unsafe { from_utf8_unchecked(&self.data[self.range.clone()]) })
    }
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("EscapeDefault { .. }")
    }
}