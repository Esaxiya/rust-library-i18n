//! Αυτή η ενότητα εφαρμόζει το `Any` trait, το οποίο επιτρέπει τη δυναμική πληκτρολόγηση οποιουδήποτε τύπου `'static` μέσω της αντανάκλασης χρόνου εκτέλεσης.
//!
//! `Any` το ίδιο μπορεί να χρησιμοποιηθεί για να πάρει ένα `TypeId`, και έχει περισσότερες δυνατότητες όταν χρησιμοποιείται ως αντικείμενο trait.
//! Ως `&dyn Any` (ένα αντικείμενο δανεισμού trait), έχει τις μεθόδους `is` και `downcast_ref`, για να ελέγξει εάν η περιορισμένη τιμή είναι δεδομένου τύπου και για να πάρει μια αναφορά στην εσωτερική τιμή ως τύπο.
//! Ως `&mut dyn Any`, υπάρχει επίσης η μέθοδος `downcast_mut`, για να υπάρχει μια μεταβλητή αναφορά στην εσωτερική τιμή.
//! `Box<dyn Any>` προσθέτει τη μέθοδο `downcast`, η οποία επιχειρεί να μετατραπεί σε `Box<T>`.
//! Ανατρέξτε στην τεκμηρίωση [`Box`] για όλες τις λεπτομέρειες.
//!
//! Σημειώστε ότι το `&dyn Any` περιορίζεται στη δοκιμή εάν μια τιμή είναι συγκεκριμένου τύπου σκυροδέματος και δεν μπορεί να χρησιμοποιηθεί για να ελέγξει εάν ένας τύπος εφαρμόζει ένα trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Έξυπνοι δείκτες και `dyn Any`
//!
//! Ένα κομμάτι συμπεριφοράς που πρέπει να θυμάστε όταν χρησιμοποιείτε το `Any` ως αντικείμενο trait, ειδικά με τύπους όπως `Box<dyn Any>` ή `Arc<dyn Any>`, είναι ότι απλά το να καλέσετε το `.type_id()` στην τιμή θα παράγει το `TypeId` του *container*, όχι το υποκείμενο αντικείμενο trait.
//!
//! Αυτό μπορεί να αποφευχθεί μετατρέποντας τον έξυπνο δείκτη σε `&dyn Any` αντ 'αυτού, το οποίο θα επιστρέψει το `TypeId` του αντικειμένου.
//! Για παράδειγμα:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Είναι πιο πιθανό να το θέλετε:
//! let actual_id = (&*boxed).type_id();
//! // ... από αυτό:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Σκεφτείτε μια κατάσταση όπου θέλουμε να αποσυνδεθεί μια τιμή που μεταβιβάστηκε σε μια συνάρτηση.
//! Γνωρίζουμε την αξία που εργαζόμαστε εφαρμόζει το Debug, αλλά δεν γνωρίζουμε τον συγκεκριμένο τύπο του.Θέλουμε να δώσουμε ειδική μεταχείριση σε συγκεκριμένους τύπους: σε αυτήν την περίπτωση εκτυπώνουμε το μήκος των τιμών String πριν από την τιμή τους.
//! Δεν γνωρίζουμε τον συγκεκριμένο τύπο της αξίας μας κατά τη στιγμή της μεταγλώττισης, επομένως πρέπει να χρησιμοποιήσουμε την αντανάκλαση χρόνου εκτέλεσης.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Λειτουργία καταγραφέα για κάθε τύπο που εφαρμόζει το Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Προσπαθήστε να μετατρέψετε την αξία μας σε `String`.
//!     // Εάν είναι επιτυχής, θέλουμε να εξάγουμε το μήκος του String καθώς και την αξία του.
//!     // Εάν όχι, είναι διαφορετικός τύπος: απλώς εκτυπώστε το χωρίς διακόσμηση.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Αυτή η συνάρτηση θέλει να αποσυνδέσει την παράμετρο πριν από την εργασία με αυτήν.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... κάνε κάποια άλλη δουλειά
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Οποιοδήποτε trait
///////////////////////////////////////////////////////////////////////////////

/// Ένα trait για προσομοίωση δυναμικής πληκτρολόγησης.
///
/// Οι περισσότεροι τύποι εφαρμόζουν το `Any`.Ωστόσο, οποιοσδήποτε τύπος που περιέχει μια μη «στατική» αναφορά δεν το κάνει.
/// Δείτε το [module-level documentation][mod] για περισσότερες λεπτομέρειες.
///
/// [mod]: crate::any
// Αυτό το trait δεν είναι μη ασφαλές, αν και βασίζουμε στις ιδιαιτερότητες της μοναδικής λειτουργίας `type_id` του impl σε μη ασφαλή κώδικα (π.χ. `downcast`).Κανονικά, αυτό θα αποτελούσε πρόβλημα, αλλά επειδή το μόνο impl του `Any` είναι μια ολοκληρωμένη εφαρμογή, κανένας άλλος κώδικας δεν μπορεί να εφαρμόσει το `Any`.
//
// Θα μπορούσαμε εύλογα να κάνουμε αυτό το trait μη ασφαλές-δεν θα προκαλούσε θραύση, καθώς ελέγχουμε όλες τις υλοποιήσεις-αλλά επιλέγουμε να μην το κάνουμε και αυτό δεν είναι τόσο απαραίτητο και μπορεί να προκαλέσει σύγχυση στους χρήστες σχετικά με τη διάκριση μη ασφαλών traits και μη ασφαλών μεθόδων (δηλαδή, Το `type_id` θα εξακολουθούσε να είναι ασφαλές για κλήση, αλλά πιθανότατα θα θέλαμε να το υποδείξουμε στην τεκμηρίωση).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Παίρνει το `TypeId` του `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Μέθοδοι επέκτασης για οποιαδήποτε αντικείμενα trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Βεβαιωθείτε ότι το αποτέλεσμα π.χ. της σύνδεσης ενός νήματος μπορεί να εκτυπωθεί και ως εκ τούτου να χρησιμοποιηθεί με το `unwrap`.
// Ενδέχεται τελικά να μην χρειάζεται πλέον εάν η αποστολή λειτουργεί με αναβάθμιση.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Επιστρέφει `true` εάν ο τύπος με κουτί είναι ίδιος με `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Λάβετε `TypeId` του τύπου με τον οποίο δημιουργείται αυτή η λειτουργία.
        let t = TypeId::of::<T>();

        // Λάβετε `TypeId` του τύπου στο αντικείμενο trait (`self`).
        let concrete = self.type_id();

        // Συγκρίνετε και τα δύο "TypeId" στην ισότητα.
        t == concrete
    }

    /// Επιστρέφει κάποια αναφορά στην τετραγωνική τιμή εάν είναι τύπου `T` ή `None` εάν δεν είναι.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // ΑΣΦΑΛΕΙΑ: απλώς ελέγξαμε αν δείχνουμε τον σωστό τύπο και μπορούμε να βασιστούμε
            // που ελέγχουν για την ασφάλεια της μνήμης, επειδή έχουμε εφαρμόσει Οποιοδήποτε για όλους τους τύπους.δεν μπορούν να υπάρξουν άλλα υπονοούμενα όπως θα έρχονταν σε σύγκρουση με τα εμφυτεύματά μας.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Επιστρέφει κάποια μεταβλητή αναφορά στην τετραγωνική τιμή εάν είναι τύπου `T` ή `None` εάν δεν είναι.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // ΑΣΦΑΛΕΙΑ: απλώς ελέγξαμε αν δείχνουμε τον σωστό τύπο και μπορούμε να βασιστούμε
            // που ελέγχουν για την ασφάλεια της μνήμης, επειδή έχουμε εφαρμόσει Οποιοδήποτε για όλους τους τύπους.δεν μπορούν να υπάρξουν άλλα υπονοούμενα όπως θα έρχονταν σε σύγκρουση με τα εμφυτεύματά μας.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Προώθηση στη μέθοδο που ορίζεται στον τύπο `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Προώθηση στη μέθοδο που ορίζεται στον τύπο `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Προώθηση στη μέθοδο που ορίζεται στον τύπο `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Προώθηση στη μέθοδο που ορίζεται στον τύπο `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Προώθηση στη μέθοδο που ορίζεται στον τύπο `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Προώθηση στη μέθοδο που ορίζεται στον τύπο `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID και οι μέθοδοι του
///////////////////////////////////////////////////////////////////////////////

/// Το `TypeId` αντιπροσωπεύει ένα παγκοσμίως μοναδικό αναγνωριστικό για έναν τύπο.
///
/// Κάθε `TypeId` είναι ένα αδιαφανές αντικείμενο που δεν επιτρέπει την επιθεώρηση του τι υπάρχει μέσα, αλλά επιτρέπει βασικές λειτουργίες όπως κλωνοποίηση, σύγκριση, εκτύπωση και εμφάνιση.
///
///
/// Ένα `TypeId` είναι προς το παρόν διαθέσιμο μόνο για τύπους που αποδίδονται στο `'static`, αλλά αυτός ο περιορισμός μπορεί να καταργηθεί στο future.
///
/// Ενώ το `TypeId` εφαρμόζει `Hash`, `PartialOrd` και `Ord`, αξίζει να σημειωθεί ότι οι κατακερματισμοί και η σειρά θα διαφέρουν μεταξύ των κυκλοφοριών Rust.
/// Προσέξτε να βασίζεστε σε αυτά μέσα στον κωδικό σας!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Επιστρέφει το `TypeId` του τύπου με τον οποίο δημιουργήθηκε αυτή η γενική συνάρτηση.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Επιστρέφει το όνομα ενός τύπου ως φέτα συμβολοσειράς.
///
/// # Note
///
/// Αυτό προορίζεται για διαγνωστική χρήση.
/// Τα ακριβή περιεχόμενα και η μορφή της συμβολοσειράς που επιστρέφονται δεν καθορίζονται, εκτός από την περιγραφή της καλύτερης προσπάθειας του τύπου.
/// Για παράδειγμα, μεταξύ των χορδών που μπορεί να επιστρέψει το `type_name::<Option<String>>()` είναι τα `"Option<String>"` και `"std::option::Option<std::string::String>"`.
///
///
/// Η επιστρεφόμενη συμβολοσειρά δεν πρέπει να θεωρείται μοναδικό αναγνωριστικό ενός τύπου, καθώς πολλοί τύποι ενδέχεται να αντιστοιχούν στο ίδιο όνομα ονόματος.
/// Ομοίως, δεν υπάρχει καμία εγγύηση ότι όλα τα μέρη ενός τύπου θα εμφανιστούν στην επιστρεφόμενη συμβολοσειρά: για παράδειγμα, οι προσδιοριστές διάρκειας ζωής δεν περιλαμβάνονται αυτήν τη στιγμή.
/// Επιπλέον, η έξοδος μπορεί να αλλάξει μεταξύ των εκδόσεων του μεταγλωττιστή.
///
/// Η τρέχουσα εφαρμογή χρησιμοποιεί την ίδια υποδομή με τα διαγνωστικά μεταγλωττιστή και το debuginfo, αλλά αυτό δεν είναι εγγυημένο.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Επιστρέφει το όνομα του τύπου της τιμής point-to ως string string.
/// Αυτό είναι το ίδιο με το `type_name::<T>()`, αλλά μπορεί να χρησιμοποιηθεί όταν ο τύπος μιας μεταβλητής δεν είναι εύκολα διαθέσιμος.
///
/// # Note
///
/// Αυτό προορίζεται για διαγνωστική χρήση.Το ακριβές περιεχόμενο και η μορφή της συμβολοσειράς δεν καθορίζονται, εκτός από την περιγραφή της καλύτερης προσπάθειας του τύπου.
/// Για παράδειγμα, το `type_name_of_val::<Option<String>>(None)` θα μπορούσε να επιστρέψει `"Option<String>"` ή `"std::option::Option<std::string::String>"`, αλλά όχι `"foobar"`.
///
/// Επιπλέον, η έξοδος μπορεί να αλλάξει μεταξύ των εκδόσεων του μεταγλωττιστή.
///
/// Αυτή η συνάρτηση δεν επιλύει αντικείμενα trait, που σημαίνει ότι το `type_name_of_val(&7u32 as &dyn Debug)` μπορεί να επιστρέψει `"dyn Debug"`, αλλά όχι το `"u32"`.
///
/// Το όνομα τύπου δεν πρέπει να θεωρείται μοναδικό αναγνωριστικό ενός τύπου.
/// πολλοί τύποι μπορεί να έχουν το ίδιο όνομα.
///
/// Η τρέχουσα εφαρμογή χρησιμοποιεί την ίδια υποδομή με τα διαγνωστικά μεταγλωττιστή και το debuginfo, αλλά αυτό δεν είναι εγγυημένο.
///
/// # Examples
///
/// Εκτυπώνει τους προεπιλεγμένους τύπους ακέραιου και αιωρούμενου.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}