use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Ένας τύπος περιτυλίγματος για την κατασκευή μη αρχικοποιημένων παρουσιών `T`.
///
/// # Αμετάβλητη αρχικοποίηση
///
/// Ο μεταγλωττιστής, γενικά, υποθέτει ότι μια μεταβλητή αρχικοποιείται σωστά σύμφωνα με τις απαιτήσεις του τύπου της μεταβλητής.Για παράδειγμα, μια μεταβλητή τύπου αναφοράς πρέπει να είναι ευθυγραμμισμένη και μη NULL.
/// Αυτό είναι ένα αμετάβλητο που πρέπει *πάντα* να τηρείται, ακόμη και σε μη ασφαλή κώδικα.
/// Κατά συνέπεια, η μηδενική προετοιμασία μιας μεταβλητής τύπου αναφοράς προκαλεί στιγμιαίο [undefined behavior][ub], ανεξάρτητα από το αν αυτή η αναφορά χρησιμοποιείται ποτέ για πρόσβαση στη μνήμη:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // απροσδιόριστη συμπεριφορά!⚠️
/// // Ο ισοδύναμος κωδικός με `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // απροσδιόριστη συμπεριφορά!⚠️
/// ```
///
/// Αυτό το εκμεταλλεύεται ο μεταγλωττιστής για διάφορες βελτιστοποιήσεις, όπως ο έλεγχος χρόνου εκτέλεσης και η βελτιστοποίηση της διάταξης `enum`.
///
/// Ομοίως, εντελώς μη αρχικοποιημένη μνήμη μπορεί να έχει οποιοδήποτε περιεχόμενο, ενώ ένα `bool` πρέπει πάντα να είναι `true` ή `false`.Ως εκ τούτου, η δημιουργία ενός μη αρχικοποιημένου `bool` είναι απροσδιόριστη συμπεριφορά:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // απροσδιόριστη συμπεριφορά!⚠️
/// // Ο ισοδύναμος κωδικός με `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // απροσδιόριστη συμπεριφορά!⚠️
/// ```
///
/// Επιπλέον, η μη αρχικοποιημένη μνήμη είναι ειδική στο ότι δεν έχει σταθερή τιμή ("fixed" που σημαίνει "it won't change without being written to").Η ανάγνωση του ίδιου μη αρχικοποιημένου byte πολλές φορές μπορεί να δώσει διαφορετικά αποτελέσματα.
/// Αυτό καθιστά απροσδιόριστη συμπεριφορά να έχει μη αρχικοποιημένα δεδομένα σε μια μεταβλητή, ακόμη και αν αυτή η μεταβλητή έχει ακέραιο τύπο, ο οποίος διαφορετικά μπορεί να περιέχει οποιοδήποτε *σταθερό* bit μοτίβο:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // απροσδιόριστη συμπεριφορά!⚠️
/// // Ο ισοδύναμος κωδικός με `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // απροσδιόριστη συμπεριφορά!⚠️
/// ```
/// (Σημειώστε ότι οι κανόνες σχετικά με τους μη αρχικοποιημένους ακέραιους αριθμούς δεν έχουν ακόμη οριστικοποιηθεί, αλλά μέχρι να είναι, συνιστάται να τους αποφύγετε.)
///
/// Επιπλέον, να θυμάστε ότι οι περισσότεροι τύποι έχουν πρόσθετα αναλλοίωτα πέρα από το να θεωρούνται αρχικοποιημένα σε επίπεδο τύπου.
/// Για παράδειγμα, ένα [`Vec<T>`] που έχει αρχικοποιηθεί «1» θεωρείται αρχικοποιημένο (υπό την τρέχουσα εφαρμογή, αυτό δεν αποτελεί σταθερή εγγύηση) επειδή η μόνη απαίτηση που γνωρίζει ο μεταγλωττιστής είναι ότι ο δείκτης δεδομένων πρέπει να είναι μηδενικός.
/// Η δημιουργία ενός τέτοιου `Vec<T>` δεν προκαλεί *άμεση* απροσδιόριστη συμπεριφορά, αλλά θα προκαλέσει απροσδιόριστη συμπεριφορά με τις περισσότερες ασφαλείς λειτουργίες (συμπεριλαμβανομένης της απόρριψης).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` χρησιμεύει για να επιτρέψει τον μη ασφαλή κώδικα για την αντιμετώπιση μη αρχικοποιημένων δεδομένων.
/// Είναι ένα σήμα προς τον μεταγλωττιστή που υποδεικνύει ότι τα δεδομένα εδώ *δεν* μπορούν να αρχικοποιηθούν:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Δημιουργήστε μια ρητά μη αρχικοποιημένη αναφορά.
/// // Ο μεταγλωττιστής γνωρίζει ότι τα δεδομένα σε ένα `MaybeUninit<T>` ενδέχεται να μην είναι έγκυρα, και ως εκ τούτου δεν είναι UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Ορίστε το σε μια έγκυρη τιμή.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Εξαγάγετε τα αρχικοποιημένα δεδομένα-επιτρέπεται μόνο *μετά από* σωστή προετοιμασία του `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Στη συνέχεια, ο μεταγλωττιστής γνωρίζει ότι δεν κάνει λανθασμένες παραδοχές ή βελτιστοποιήσεις σε αυτόν τον κώδικα.
///
/// Μπορείτε να σκεφτείτε ότι το `MaybeUninit<T>` μοιάζει λίγο με το `Option<T>`, αλλά χωρίς καμία παρακολούθηση χρόνου εκτέλεσης και χωρίς κανένα έλεγχο ασφαλείας.
///
/// ## out-pointers
///
/// Μπορείτε να χρησιμοποιήσετε το `MaybeUninit<T>` για να εφαρμόσετε το "out-pointers": αντί να επιστρέψετε δεδομένα από μια συνάρτηση, μεταβιβάστε τον δείκτη σε κάποια μνήμη (uninitialized) για να βάλετε το αποτέλεσμα.
/// Αυτό μπορεί να είναι χρήσιμο όταν είναι σημαντικό για τον καλούντα να ελέγξει πώς κατανέμεται η μνήμη που αποθηκεύεται το αποτέλεσμα και θέλετε να αποφύγετε περιττές κινήσεις.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` δεν αφήνει τα παλιά περιεχόμενα, κάτι που είναι σημαντικό.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Τώρα γνωρίζουμε ότι το `v` έχει αρχικοποιηθεί!Αυτό διασφαλίζει επίσης ότι το vector πέφτει σωστά.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Αρχικοποίηση ενός πίνακα από στοιχείο προς στοιχείο
///
/// `MaybeUninit<T>` μπορεί να χρησιμοποιηθεί για την προετοιμασία ενός μεγάλου πίνακα από στοιχείο προς στοιχείο:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Δημιουργήστε έναν μη αρχικοποιημένο πίνακα `MaybeUninit`.
///     // Το `assume_init` είναι ασφαλές, επειδή ο τύπος που ισχυριζόμαστε ότι έχουμε αρχικοποιήσει εδώ είναι ένα μάτσο "MaybeUninit", τα οποία δεν απαιτούν αρχικοποίηση.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Η πτώση ενός `MaybeUninit` δεν κάνει τίποτα.
///     // Συνεπώς, η χρήση εκχώρησης ακατέργαστου δείκτη αντί του `ptr::write` δεν προκαλεί την πτώση της παλιάς μη αρχικοποιημένης τιμής.
/////
///     // Επίσης, εάν υπάρχει panic κατά τη διάρκεια αυτού του βρόχου, έχουμε διαρροή μνήμης, αλλά δεν υπάρχει πρόβλημα ασφάλειας μνήμης.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Όλα αρχικοποιούνται.
///     // Μεταδώστε τον πίνακα στον αρχικοποιημένο τύπο.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Μπορείτε επίσης να εργαστείτε με μερικώς αρχικοποιημένους πίνακες, οι οποίοι θα μπορούσαν να βρεθούν σε υποδομές χαμηλού επιπέδου.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Δημιουργήστε έναν μη αρχικοποιημένο πίνακα `MaybeUninit`.
/// // Το `assume_init` είναι ασφαλές, επειδή ο τύπος που ισχυριζόμαστε ότι έχουμε αρχικοποιήσει εδώ είναι ένα μάτσο "MaybeUninit", τα οποία δεν απαιτούν αρχικοποίηση.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Μετρήστε τον αριθμό των στοιχείων που έχουμε εκχωρήσει.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Για κάθε στοιχείο του πίνακα, αποθέστε εάν το διαθέσαμε.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Αρχικοποίηση δομής πεδίου ανά πεδίο
///
/// Μπορείτε να χρησιμοποιήσετε το `MaybeUninit<T>` και τη μακροεντολή [`std::ptr::addr_of_mut`], για να προετοιμάσετε το πεδίο δομών ανά πεδίο:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Αρχικοποίηση του πεδίου `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Αρχικοποίηση του πεδίου `list` Εάν υπάρχει panic εδώ, τότε το `String` στο πεδίο `name` διαρρέει.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Όλα τα πεδία έχουν αρχικοποιηθεί, επομένως καλούμε το `assume_init` για να λάβουμε ένα αρχικοποιημένο Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` είναι εγγυημένο ότι έχει το ίδιο μέγεθος, ευθυγράμμιση και ABI με το `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Ωστόσο, θυμηθείτε ότι ένας τύπος *που περιέχει* ένα `MaybeUninit<T>` δεν είναι απαραίτητα η ίδια διάταξη.Το Rust γενικά δεν εγγυάται ότι τα πεδία ενός `Foo<T>` έχουν την ίδια σειρά με το `Foo<U>`, ακόμη και αν τα `T` και `U` έχουν το ίδιο μέγεθος και ευθυγράμμιση.
///
/// Επιπλέον, επειδή οποιαδήποτε τιμή bit ισχύει για ένα `MaybeUninit<T>`, ο μεταγλωττιστής δεν μπορεί να εφαρμόσει βελτιστοποιήσεις non-zero/niche-filling, πιθανόν να έχει ως αποτέλεσμα μεγαλύτερο μέγεθος:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Εάν το `T` είναι ασφαλές για το FFI, τότε το ίδιο ισχύει και για το `MaybeUninit<T>`.
///
/// Ενώ το `MaybeUninit` είναι `#[repr(transparent)]` (υποδεικνύοντας ότι εγγυάται το ίδιο μέγεθος, ευθυγράμμιση και ABI με το `T`), αυτό *δεν* δεν αλλάζει καμία από τις προηγούμενες προειδοποιήσεις.
/// `Option<T>` και το `Option<MaybeUninit<T>>` ενδέχεται να εξακολουθούν να έχουν διαφορετικά μεγέθη, και οι τύποι που περιέχουν ένα πεδίο τύπου `T` μπορούν να διαμορφωθούν (και να έχουν μέγεθος) διαφορετικά από ότι εάν το πεδίο ήταν `MaybeUninit<T>`.
/// `MaybeUninit` είναι ένας τύπος ένωσης και το `#[repr(transparent)]` στα συνδικάτα είναι ασταθές (βλέπε [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Με την πάροδο του χρόνου, οι ακριβείς εγγυήσεις του `#[repr(transparent)]` στα συνδικάτα μπορεί να εξελιχθούν και το `MaybeUninit` μπορεί ή όχι να παραμείνει `#[repr(transparent)]`.
/// Ωστόσο, το `MaybeUninit<T>`*θα* πάντα * εγγυάται ότι έχει το ίδιο μέγεθος, ευθυγράμμιση και ABI με το `T`.είναι ακριβώς ο τρόπος με τον οποίο το `MaybeUninit` εφαρμόζει την εγγύηση μπορεί να εξελιχθεί.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Στοιχείο Lang ώστε να μπορούμε να τυλίγουμε άλλους τύπους σε αυτό.Αυτό είναι χρήσιμο για γεννήτριες.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Χωρίς να καλέσετε το `T::clone()`, δεν μπορούμε να ξέρουμε αν έχουμε αρκετά αρχικοποιηθεί για αυτό.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Δημιουργεί ένα νέο `MaybeUninit<T>` που έχει αρχικοποιηθεί με τη δεδομένη τιμή.
    /// Είναι ασφαλές να καλέσετε το [`assume_init`] στην τιμή επιστροφής αυτής της λειτουργίας.
    ///
    /// Σημειώστε ότι η πτώση ενός `MaybeUninit<T>` δεν θα καλέσει ποτέ τον κωδικό πτώσης του "T".
    /// Είναι δική σας ευθύνη να βεβαιωθείτε ότι το `T` θα πέσει εάν αρχικοποιηθεί.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Δημιουργεί ένα νέο `MaybeUninit<T>` σε μη αρχικοποιημένη κατάσταση.
    ///
    /// Σημειώστε ότι η πτώση ενός `MaybeUninit<T>` δεν θα καλέσει ποτέ τον κωδικό πτώσης του "T".
    /// Είναι δική σας ευθύνη να βεβαιωθείτε ότι το `T` θα πέσει εάν αρχικοποιηθεί.
    ///
    /// Δείτε το [type-level documentation][MaybeUninit] για μερικά παραδείγματα.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Δημιουργήστε έναν νέο πίνακα αντικειμένων `MaybeUninit<T>`, σε μη αρχικοποιημένη κατάσταση.
    ///
    /// Note: σε μια έκδοση future Rust, αυτή η μέθοδος μπορεί να καταστεί περιττή όταν η κυριολεκτική σύνταξη του πίνακα επιτρέπει το [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Το παρακάτω παράδειγμα θα μπορούσε στη συνέχεια να χρησιμοποιήσει το `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Επιστρέφει ένα (πιθανώς μικρότερο) κομμάτι δεδομένων που έχει διαβαστεί
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // ΑΣΦΑΛΕΙΑ: Ένα μη αρχικοποιημένο `[MaybeUninit<_>; LEN]` είναι έγκυρο.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Δημιουργεί ένα νέο `MaybeUninit<T>` σε μη αρχικοποιημένη κατάσταση, με τη μνήμη να γεμίζει με `0` bytes.Εξαρτάται από το `T` εάν αυτό ήδη κάνει σωστή προετοιμασία.
    ///
    /// Για παράδειγμα, το `MaybeUninit<usize>::zeroed()` έχει αρχικοποιηθεί, αλλά το `MaybeUninit<&'static i32>::zeroed()` δεν συμβαίνει επειδή οι αναφορές δεν πρέπει να είναι μηδενικές.
    ///
    /// Σημειώστε ότι η πτώση ενός `MaybeUninit<T>` δεν θα καλέσει ποτέ τον κωδικό πτώσης του "T".
    /// Είναι δική σας ευθύνη να βεβαιωθείτε ότι το `T` θα πέσει εάν αρχικοποιηθεί.
    ///
    /// # Example
    ///
    /// Σωστή χρήση αυτής της συνάρτησης: αρχικοποίηση μιας δομής με μηδέν, όπου όλα τα πεδία της δομής μπορούν να κρατήσουν το μοτίβο bit 0 ως έγκυρη τιμή.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Λανθασμένη* χρήση αυτής της λειτουργίας: η κλήση του `x.zeroed().assume_init()` όταν το `0` δεν είναι έγκυρο μοτίβο bit για τον τύπο:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Μέσα σε ένα ζεύγος, δημιουργούμε ένα `NotZero` που δεν έχει έγκυρο διακριτικό.
    /// // Αυτή είναι απροσδιόριστη συμπεριφορά.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // ΑΣΦΑΛΕΙΑ: Το `u.as_mut_ptr()` δείχνει την εκχωρημένη μνήμη.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Ορίζει την τιμή του `MaybeUninit<T>`.
    /// Αυτό αντικαθιστά οποιαδήποτε προηγούμενη τιμή χωρίς να την ρίξετε, οπότε προσέξτε να μην τη χρησιμοποιήσετε δύο φορές εκτός εάν θέλετε να παραλείψετε την εκτέλεση του καταστροφικού.
    ///
    /// Για τη δική σας ευκολία, αυτό επιστρέφει επίσης μια μεταβλητή αναφορά στα περιεχόμενα του `self` (που έχουν πλέον αρχικοποιηθεί με ασφάλεια).
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // ΑΣΦΑΛΕΙΑ: Αρχικοποιήσαμε αυτήν την τιμή.
        unsafe { self.assume_init_mut() }
    }

    /// Παίρνει ένα δείκτη στην περιορισμένη τιμή.
    /// Η ανάγνωση από αυτόν το δείκτη ή η μετατροπή του σε αναφορά είναι απροσδιόριστη συμπεριφορά, εκτός εάν το `MaybeUninit<T>` έχει αρχικοποιηθεί.
    /// Η εγγραφή στη μνήμη που δείχνει αυτός ο δείκτης (non-transitively) είναι απροσδιόριστη συμπεριφορά (εκτός από το `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Σωστή χρήση αυτής της μεθόδου:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Δημιουργήστε μια αναφορά στο `MaybeUninit<T>`.Αυτό είναι εντάξει γιατί το αρχικοποιήσαμε.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Λανθασμένη* χρήση αυτής της μεθόδου:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Έχουμε δημιουργήσει μια αναφορά σε ένα μη αρχικοποιημένο vector!Αυτή είναι απροσδιόριστη συμπεριφορά.⚠️
    /// ```
    ///
    /// (Σημειώστε ότι οι κανόνες σχετικά με τις αναφορές σε μη αρχικοποιημένα δεδομένα δεν έχουν ακόμη οριστικοποιηθεί, αλλά μέχρι να είναι, συνιστάται να τα αποφύγετε.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` και `ManuallyDrop` είναι και τα δύο `repr(transparent)`, ώστε να μπορούμε να ρίξουμε το δείκτη.
        self as *const _ as *const T
    }

    /// Παίρνει έναν μεταβλητό δείκτη στην περιορισμένη τιμή.
    /// Η ανάγνωση από αυτόν το δείκτη ή η μετατροπή του σε αναφορά είναι απροσδιόριστη συμπεριφορά, εκτός εάν το `MaybeUninit<T>` έχει αρχικοποιηθεί.
    ///
    /// # Examples
    ///
    /// Σωστή χρήση αυτής της μεθόδου:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Δημιουργήστε μια αναφορά στο `MaybeUninit<Vec<u32>>`.
    /// // Αυτό είναι εντάξει γιατί το αρχικοποιήσαμε.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Λανθασμένη* χρήση αυτής της μεθόδου:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Έχουμε δημιουργήσει μια αναφορά σε ένα μη αρχικοποιημένο vector!Αυτή είναι απροσδιόριστη συμπεριφορά.⚠️
    /// ```
    ///
    /// (Σημειώστε ότι οι κανόνες σχετικά με τις αναφορές σε μη αρχικοποιημένα δεδομένα δεν έχουν ακόμη οριστικοποιηθεί, αλλά μέχρι να είναι, συνιστάται να τα αποφύγετε.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` και `ManuallyDrop` είναι και τα δύο `repr(transparent)`, ώστε να μπορούμε να ρίξουμε το δείκτη.
        self as *mut _ as *mut T
    }

    /// Εξάγει την τιμή από το κοντέινερ `MaybeUninit<T>`.Αυτός είναι ένας πολύ καλός τρόπος για να διασφαλιστεί ότι τα δεδομένα θα πέσουν, επειδή το `T` που προκύπτει υπόκειται στον συνηθισμένο χειρισμό πτώσης.
    ///
    /// # Safety
    ///
    /// Εναπόκειται στον καλούντα να εγγυηθεί ότι το `MaybeUninit<T>` είναι πραγματικά σε αρχικοποιημένη κατάσταση.Το να το καλέσετε αυτό όταν το περιεχόμενο δεν έχει ακόμη πλήρως προετοιμαστεί προκαλεί άμεση απροσδιόριστη συμπεριφορά.
    /// Το [type-level documentation][inv] περιέχει περισσότερες πληροφορίες σχετικά με αυτήν την αναλλοίωτη αρχικοποίηση.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Επιπλέον, να θυμάστε ότι οι περισσότεροι τύποι έχουν πρόσθετα αναλλοίωτα πέρα από το να θεωρούνται αρχικοποιημένα σε επίπεδο τύπου.
    /// Για παράδειγμα, ένα [`Vec<T>`] που έχει αρχικοποιηθεί «1» θεωρείται αρχικοποιημένο (υπό την τρέχουσα εφαρμογή, αυτό δεν αποτελεί σταθερή εγγύηση) επειδή η μόνη απαίτηση που γνωρίζει ο μεταγλωττιστής είναι ότι ο δείκτης δεδομένων πρέπει να είναι μηδενικός.
    ///
    /// Η δημιουργία ενός τέτοιου `Vec<T>` δεν προκαλεί *άμεση* απροσδιόριστη συμπεριφορά, αλλά θα προκαλέσει απροσδιόριστη συμπεριφορά με τις περισσότερες ασφαλείς λειτουργίες (συμπεριλαμβανομένης της απόρριψης).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Σωστή χρήση αυτής της μεθόδου:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Λανθασμένη* χρήση αυτής της μεθόδου:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` δεν είχε αρχικοποιηθεί ακόμη, οπότε αυτή η τελευταία γραμμή προκάλεσε απροσδιόριστη συμπεριφορά.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να εγγυηθεί ότι το `self` έχει αρχικοποιηθεί.
        // Αυτό σημαίνει επίσης ότι το `self` πρέπει να είναι μια παραλλαγή `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Διαβάζει την τιμή από το κοντέινερ `MaybeUninit<T>`.Το `T` που προκύπτει υπόκειται στον συνηθισμένο χειρισμό πτώσης.
    ///
    /// Όποτε είναι δυνατόν, είναι προτιμότερο να χρησιμοποιείτε το [`assume_init`], το οποίο αποτρέπει την αναπαραγωγή του περιεχομένου του `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Εναπόκειται στον καλούντα να εγγυηθεί ότι το `MaybeUninit<T>` είναι πραγματικά σε αρχικοποιημένη κατάσταση.Το να το καλέσετε αυτό όταν το περιεχόμενο δεν έχει ακόμη πλήρως προετοιμαστεί προκαλεί απροσδιόριστη συμπεριφορά.
    /// Το [type-level documentation][inv] περιέχει περισσότερες πληροφορίες σχετικά με αυτήν την αναλλοίωτη αρχικοποίηση.
    ///
    /// Επιπλέον, αυτό αφήνει ένα αντίγραφο των ίδιων δεδομένων πίσω στο `MaybeUninit<T>`.
    /// Όταν χρησιμοποιείτε πολλαπλά αντίγραφα των δεδομένων (καλώντας το `assume_init_read` πολλές φορές, ή πρώτα καλέστε το `assume_init_read` και μετά το [`assume_init`]), είναι δική σας ευθύνη να διασφαλίσετε ότι αυτά τα δεδομένα μπορούν πράγματι να αναπαραχθούν.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Σωστή χρήση αυτής της μεθόδου:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` είναι `Copy`, επομένως μπορούμε να διαβάζουμε πολλές φορές.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Η αναπαραγωγή μιας τιμής `None` είναι εντάξει, επομένως ενδέχεται να διαβάζουμε πολλές φορές.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Λανθασμένη* χρήση αυτής της μεθόδου:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Δημιουργήσαμε τώρα δύο αντίγραφα του ίδιου vector, οδηγώντας σε double️ διπλού δωρεάν όταν και οι δύο πέσουν!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να εγγυηθεί ότι το `self` έχει αρχικοποιηθεί.
        // Η ανάγνωση από το `self.as_ptr()` είναι ασφαλής αφού το `self` πρέπει να αρχικοποιηθεί.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Σταματά την περιεχόμενη τιμή στη θέση της.
    ///
    /// Εάν έχετε την κυριότητα του `MaybeUninit`, μπορείτε να χρησιμοποιήσετε το [`assume_init`] αντ 'αυτού.
    ///
    /// # Safety
    ///
    /// Εναπόκειται στον καλούντα να εγγυηθεί ότι το `MaybeUninit<T>` είναι πραγματικά σε αρχικοποιημένη κατάσταση.Το να το καλέσετε αυτό όταν το περιεχόμενο δεν έχει ακόμη πλήρως προετοιμαστεί προκαλεί απροσδιόριστη συμπεριφορά.
    ///
    /// Επιπλέον, όλα τα πρόσθετα αναλλοίωτα του τύπου `T` πρέπει να ικανοποιούνται, καθώς η εφαρμογή `Drop` του `T` (ή τα μέλη της) μπορεί να βασιστεί σε αυτό.
    /// Για παράδειγμα, ένα [`Vec<T>`] που έχει αρχικοποιηθεί «1» θεωρείται αρχικοποιημένο (υπό την τρέχουσα εφαρμογή, αυτό δεν αποτελεί σταθερή εγγύηση) επειδή η μόνη απαίτηση που γνωρίζει ο μεταγλωττιστής είναι ότι ο δείκτης δεδομένων πρέπει να είναι μηδενικός.
    ///
    /// Η πτώση ενός τέτοιου `Vec<T>` ωστόσο θα προκαλέσει απροσδιόριστη συμπεριφορά.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να εγγυηθεί ότι το `self` έχει αρχικοποιηθεί και
        // ικανοποιεί όλα τα αναλλοίωτα του `T`.
        // Η πτώση της τιμής στη θέση της είναι ασφαλής εάν συμβαίνει αυτό.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Παίρνει μια κοινή αναφορά στην περιορισμένη τιμή.
    ///
    /// Αυτό μπορεί να είναι χρήσιμο όταν θέλουμε να αποκτήσουμε πρόσβαση σε ένα `MaybeUninit` που έχει αρχικοποιηθεί αλλά δεν έχουμε ιδιοκτησία του `MaybeUninit` (αποτρέποντας τη χρήση του `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Το να καλείτε αυτό όταν το περιεχόμενο δεν έχει ακόμη αρχικοποιηθεί πλήρως προκαλεί απροσδιόριστη συμπεριφορά: εναπόκειται στον καλούντα να εγγυηθεί ότι το `MaybeUninit<T>` είναι πραγματικά σε αρχικοποιημένη κατάσταση.
    ///
    ///
    /// # Examples
    ///
    /// ### Σωστή χρήση αυτής της μεθόδου:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Αρχικοποιήστε το `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Τώρα που το `MaybeUninit<_>` μας είναι γνωστό ότι έχει αρχικοποιηθεί, είναι εντάξει να δημιουργήσουμε μια κοινή αναφορά σε αυτό:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // ΑΣΦΑΛΕΙΑ: Το `x` έχει αρχικοποιηθεί.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Λανθασμένες* χρήσεις αυτής της μεθόδου:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Έχουμε δημιουργήσει μια αναφορά σε ένα μη αρχικοποιημένο vector!Αυτή είναι απροσδιόριστη συμπεριφορά.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Αρχικοποιήστε το `MaybeUninit` χρησιμοποιώντας `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Αναφορά σε ένα μη αρχικοποιημένο `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να εγγυηθεί ότι το `self` έχει αρχικοποιηθεί.
        // Αυτό σημαίνει επίσης ότι το `self` πρέπει να είναι μια παραλλαγή `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Λαμβάνει μια μεταβλητή αναφορά (unique) στην περιορισμένη τιμή.
    ///
    /// Αυτό μπορεί να είναι χρήσιμο όταν θέλουμε να αποκτήσουμε πρόσβαση σε ένα `MaybeUninit` που έχει αρχικοποιηθεί αλλά δεν έχουμε ιδιοκτησία του `MaybeUninit` (αποτρέποντας τη χρήση του `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Το να καλείτε αυτό όταν το περιεχόμενο δεν έχει ακόμη αρχικοποιηθεί πλήρως προκαλεί απροσδιόριστη συμπεριφορά: εναπόκειται στον καλούντα να εγγυηθεί ότι το `MaybeUninit<T>` είναι πραγματικά σε αρχικοποιημένη κατάσταση.
    /// Για παράδειγμα, το `.assume_init_mut()` δεν μπορεί να χρησιμοποιηθεί για την προετοιμασία ενός `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Σωστή χρήση αυτής της μεθόδου:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Αρχικοποιεί *όλα* τα byte του buffer εισόδου.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Αρχικοποιήστε το `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Τώρα γνωρίζουμε ότι το `buf` έχει αρχικοποιηθεί, έτσι θα μπορούσαμε να το `.assume_init()`.
    /// // Ωστόσο, η χρήση `.assume_init()` μπορεί να προκαλέσει `memcpy` των 2048 byte.
    /// // Για να επιβεβαιώσουμε ότι το buffer μας έχει αρχικοποιηθεί χωρίς να το αντιγράψουμε, αναβαθμίζουμε το `&mut MaybeUninit<[u8; 2048]>` σε `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // ΑΣΦΑΛΕΙΑ: Το `buf` έχει αρχικοποιηθεί.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Τώρα μπορούμε να χρησιμοποιήσουμε το `buf` ως κανονικό κομμάτι:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Λανθασμένες* χρήσεις αυτής της μεθόδου:
    ///
    /// Δεν μπορείτε να χρησιμοποιήσετε το `.assume_init_mut()` για να ξεκινήσετε μια τιμή:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Δημιουργήσαμε μια αναφορά (mutable) σε ένα μη αρχικοποιημένο `bool`!
    ///     // Αυτή είναι απροσδιόριστη συμπεριφορά.⚠️
    /// }
    /// ```
    ///
    /// Για παράδειγμα, δεν μπορείτε να [`Read`] σε ένα μη αρχικοποιημένο buffer:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) αναφορά σε μη αρχικοποιημένη μνήμη!
    ///                             // Αυτή είναι απροσδιόριστη συμπεριφορά.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Ούτε μπορείτε να χρησιμοποιήσετε άμεση πρόσβαση πεδίου για να κάνετε σταδιακή προετοιμασία πεδίου-πεδίου:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) αναφορά σε μη αρχικοποιημένη μνήμη!
    ///                  // Αυτή είναι απροσδιόριστη συμπεριφορά.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) αναφορά σε μη αρχικοποιημένη μνήμη!
    ///                  // Αυτή είναι απροσδιόριστη συμπεριφορά.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Επί του παρόντος βασίζουμε ότι τα παραπάνω είναι λανθασμένα, δηλαδή έχουμε αναφορές σε μη αρχικοποιημένα δεδομένα (π.χ. στο `libcore/fmt/float.rs`).
    // Πρέπει να λάβουμε μια τελική απόφαση σχετικά με τους κανόνες πριν από τη σταθεροποίηση.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να εγγυηθεί ότι το `self` έχει αρχικοποιηθεί.
        // Αυτό σημαίνει επίσης ότι το `self` πρέπει να είναι μια παραλλαγή `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Εξάγει τις τιμές από μια σειρά κοντέινερ `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Εναπόκειται στον καλούντα να εγγυηθεί ότι όλα τα στοιχεία του πίνακα βρίσκονται σε αρχική κατάσταση.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // ΑΣΦΑΛΕΙΑ: Τώρα ασφαλής καθώς ξεκινήσαμε όλα τα στοιχεία
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Ο καλών εγγυάται ότι όλα τα στοιχεία του πίνακα έχουν αρχικοποιηθεί
        // * `MaybeUninit<T>` και το T είναι εγγυημένο ότι έχουν την ίδια διάταξη
        // * Ίσως το Unint δεν πέφτει, οπότε δεν υπάρχουν διπλά ελευθερώματα και έτσι η μετατροπή είναι ασφαλής
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Υποθέτοντας ότι όλα τα στοιχεία έχουν αρχικοποιηθεί, πάρτε ένα κομμάτι σε αυτά.
    ///
    /// # Safety
    ///
    /// Εναπόκειται στον καλούντα να εγγυηθεί ότι τα στοιχεία `MaybeUninit<T>` είναι πραγματικά σε αρχικοποιημένη κατάσταση.
    ///
    /// Το να το καλέσετε αυτό όταν το περιεχόμενο δεν έχει ακόμη αρχικοποιηθεί πλήρως προκαλεί απροσδιόριστη συμπεριφορά.
    ///
    /// Δείτε το [`assume_init_ref`] για περισσότερες λεπτομέρειες και παραδείγματα.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // ΑΣΦΑΛΕΙΑ: η χύτευση σε ένα `*const [T]` είναι ασφαλής, καθώς ο καλών το εγγυάται
        // `slice` έχει αρχικοποιηθεί και το "MaybeUninit" είναι εγγυημένο ότι έχει την ίδια διάταξη με το `T`.
        // Ο δείκτης που λαμβάνεται είναι έγκυρος, δεδομένου ότι αναφέρεται στη μνήμη που ανήκει στο `slice`, η οποία αποτελεί αναφορά και επομένως εγγυάται ότι είναι έγκυρη για αναγνώσεις.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Υποθέτοντας ότι όλα τα στοιχεία έχουν αρχικοποιηθεί, πάρτε ένα μεταβλητό κομμάτι σε αυτά.
    ///
    /// # Safety
    ///
    /// Εναπόκειται στον καλούντα να εγγυηθεί ότι τα στοιχεία `MaybeUninit<T>` είναι πραγματικά σε αρχικοποιημένη κατάσταση.
    ///
    /// Το να το καλέσετε αυτό όταν το περιεχόμενο δεν έχει ακόμη αρχικοποιηθεί πλήρως προκαλεί απροσδιόριστη συμπεριφορά.
    ///
    /// Δείτε το [`assume_init_mut`] για περισσότερες λεπτομέρειες και παραδείγματα.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // ΑΣΦΑΛΕΙΑ: παρόμοια με τις σημειώσεις ασφαλείας για το `slice_get_ref`, αλλά έχουμε
        // μεταβλητή αναφορά η οποία είναι επίσης εγγυημένη ότι είναι έγκυρη για εγγραφές.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Παίρνει ένα δείκτη στο πρώτο στοιχείο του πίνακα.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Παίρνει έναν μεταβλητό δείκτη στο πρώτο στοιχείο του πίνακα.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Αντιγράφει τα στοιχεία από το `src` στο `this`, επιστρέφοντας μια μεταβλητή αναφορά στα τώρα αδρανοποιημένα περιεχόμενα του `this`.
    ///
    /// Εάν το `T` δεν εφαρμόζει το `Copy`, χρησιμοποιήστε το [`write_slice_cloned`]
    ///
    /// Αυτό είναι παρόμοιο με το [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Αυτή η συνάρτηση θα panic εάν οι δύο φέτες έχουν διαφορετικά μήκη.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ΑΣΦΑΛΕΙΑ: μόλις αντιγράψαμε όλα τα στοιχεία του len στην πλεονάζουσα χωρητικότητα
    /// // τα πρώτα στοιχεία src.len() του vec ισχύουν τώρα.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // ΑΣΦΑΛΕΙΑ: &[T] και&[MaybeUninit<T>] έχουν την ίδια διάταξη
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // ΑΣΦΑΛΕΙΑ: Τα έγκυρα στοιχεία μόλις αντιγράφηκαν στο `this`, ώστε να είναι αρχικοποιημένα
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Κλωνοποιεί τα στοιχεία από το `src` στο `this`, επιστρέφοντας μια μεταβλητή αναφορά στα τώρα αδρανοποιημένα περιεχόμενα του `this`.
    /// Τυχόν στοιχεία που δεν έχουν ήδη ενσωματωθεί δεν θα απορριφθούν.
    ///
    /// Εάν το `T` εφαρμόζει το `Copy`, χρησιμοποιήστε το [`write_slice`]
    ///
    /// Αυτό είναι παρόμοιο με το [`slice::clone_from_slice`] αλλά δεν απορρίπτει υπάρχοντα στοιχεία.
    ///
    /// # Panics
    ///
    /// Αυτή η συνάρτηση θα panic εάν οι δύο φέτες έχουν διαφορετικά μήκη ή εάν η εφαρμογή του `Clone` panics.
    ///
    /// Εάν υπάρχει panic, τα ήδη κλωνοποιημένα στοιχεία θα πέσουν.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ΑΣΦΑΛΕΙΑ: μόλις κλωνοποιήσαμε όλα τα στοιχεία του len στην πλεονάζουσα χωρητικότητα
    /// // τα πρώτα στοιχεία src.len() του vec ισχύουν τώρα.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // Σε αντίθεση με το copy_from_slice αυτό δεν καλεί το clone_from_slice στο slice, αυτό συμβαίνει επειδή το `MaybeUninit<T: Clone>` δεν εφαρμόζει το Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // ΑΣΦΑΛΕΙΑ: αυτό το ακατέργαστο κομμάτι θα περιέχει μόνο αρχικοποιημένα αντικείμενα
                // γι 'αυτό, επιτρέπεται να το ρίξει.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Πρέπει να τα κόψουμε ρητά στο ίδιο μήκος
        // για να ελεγχθεί ο έλεγχος ορίων και ο βελτιστοποιητής θα δημιουργήσει memcpy για απλές περιπτώσεις (για παράδειγμα T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // απαιτείται προφυλακτήρας b/c panic ενδέχεται να συμβεί κατά τη διάρκεια ενός κλώνου
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // ΑΣΦΑΛΕΙΑ: Έγκυρα στοιχεία μόλις γράφτηκαν στο `this`, ώστε να είναι αρχικοποιημένα
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}