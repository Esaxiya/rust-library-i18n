#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Επεκτείνεται σε `$crate::panic::panic_2015` ή `$crate::panic::panic_2021` ανάλογα με την έκδοση του καλούντος.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Ισχυρίζεται ότι δύο εκφράσεις είναι ίσες μεταξύ τους (χρησιμοποιώντας [`PartialEq`]).
///
/// Στο panic, αυτή η μακροεντολή θα εκτυπώσει τις τιμές των εκφράσεων με τις αναπαραστάσεις εντοπισμού σφαλμάτων.
///
///
/// Όπως το [`assert!`], αυτή η μακροεντολή έχει μια δεύτερη φόρμα, όπου μπορεί να παρέχεται ένα προσαρμοσμένο μήνυμα panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Τα παρακάτω reborrows είναι εκούσια.
                    // Χωρίς αυτά, η θέση στοίβας για το δανεισμό αρχικοποιείται ακόμη και πριν συγκριθούν οι τιμές, οδηγώντας σε αισθητή επιβράδυνση.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Τα παρακάτω reborrows είναι εκούσια.
                    // Χωρίς αυτά, η θέση στοίβας για το δανεισμό αρχικοποιείται ακόμη και πριν συγκριθούν οι τιμές, οδηγώντας σε αισθητή επιβράδυνση.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Ισχυρίζεται ότι δύο εκφράσεις δεν είναι ίσες μεταξύ τους (χρησιμοποιώντας [`PartialEq`]).
///
/// Στο panic, αυτή η μακροεντολή θα εκτυπώσει τις τιμές των εκφράσεων με τις αναπαραστάσεις εντοπισμού σφαλμάτων.
///
///
/// Όπως το [`assert!`], αυτή η μακροεντολή έχει μια δεύτερη φόρμα, όπου μπορεί να παρέχεται ένα προσαρμοσμένο μήνυμα panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Τα παρακάτω reborrows είναι εκούσια.
                    // Χωρίς αυτά, η θέση στοίβας για το δανεισμό αρχικοποιείται ακόμη και πριν συγκριθούν οι τιμές, οδηγώντας σε αισθητή επιβράδυνση.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Τα παρακάτω reborrows είναι εκούσια.
                    // Χωρίς αυτά, η θέση στοίβας για το δανεισμό αρχικοποιείται ακόμη και πριν συγκριθούν οι τιμές, οδηγώντας σε αισθητή επιβράδυνση.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Υποστηρίζει ότι μια δυαδική έκφραση είναι `true` κατά το χρόνο εκτέλεσης.
///
/// Αυτό θα επικαλεστεί τη μακροεντολή [`panic!`] εάν η παρεχόμενη έκφραση δεν μπορεί να αξιολογηθεί σε `true` κατά το χρόνο εκτέλεσης.
///
/// Όπως το [`assert!`], αυτή η μακροεντολή έχει επίσης μια δεύτερη έκδοση, όπου μπορεί να παρέχεται ένα προσαρμοσμένο μήνυμα panic.
///
/// # Uses
///
/// Σε αντίθεση με το [`assert!`], οι δηλώσεις `debug_assert!` ενεργοποιούνται μόνο σε μη βελτιστοποιημένες εκδόσεις από προεπιλογή.
/// Μια βελτιστοποιημένη έκδοση δεν θα εκτελέσει δηλώσεις `debug_assert!`, εκτός εάν το `-C debug-assertions` περάσει στον μεταγλωττιστή.
/// Αυτό καθιστά το `debug_assert!` χρήσιμο για ελέγχους που είναι πολύ ακριβοί για να υπάρχουν σε μια έκδοση κυκλοφορίας, αλλά μπορεί να είναι χρήσιμες κατά την ανάπτυξη.
/// Το αποτέλεσμα της επέκτασης του `debug_assert!` ελέγχεται πάντα με τον τύπο.
///
/// Ένας ανεξέλεγκτος ισχυρισμός επιτρέπει σε ένα πρόγραμμα σε μια ασυνεπή κατάσταση να συνεχίσει να λειτουργεί, το οποίο μπορεί να έχει απρόσμενες συνέπειες, αλλά δεν εισάγει ανασφάλεια εφόσον αυτό συμβαίνει μόνο σε ασφαλή κώδικα.
///
/// Το κόστος απόδοσης των ισχυρισμών, ωστόσο, δεν είναι γενικά μετρήσιμο.
/// Η αντικατάσταση του [`assert!`] με `debug_assert!` ενθαρρύνεται επομένως μόνο μετά από διεξοδικό προφίλ, και το πιο σημαντικό, μόνο σε ασφαλή κώδικα!
///
/// # Examples
///
/// ```
/// // το μήνυμα panic για αυτούς τους ισχυρισμούς είναι η τιμημένη τιμή της έκφρασης που δίνεται.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // μια πολύ απλή λειτουργία
/// debug_assert!(some_expensive_computation());
///
/// // επιβεβαιώστε με ένα προσαρμοσμένο μήνυμα
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Ισχυρίζεται ότι δύο εκφράσεις είναι ίσες μεταξύ τους.
///
/// Στο panic, αυτή η μακροεντολή θα εκτυπώσει τις τιμές των εκφράσεων με τις αναπαραστάσεις εντοπισμού σφαλμάτων.
///
/// Σε αντίθεση με το [`assert_eq!`], οι δηλώσεις `debug_assert_eq!` ενεργοποιούνται μόνο σε μη βελτιστοποιημένες εκδόσεις από προεπιλογή.
/// Μια βελτιστοποιημένη έκδοση δεν θα εκτελέσει δηλώσεις `debug_assert_eq!`, εκτός εάν το `-C debug-assertions` περάσει στον μεταγλωττιστή.
/// Αυτό καθιστά το `debug_assert_eq!` χρήσιμο για ελέγχους που είναι πολύ ακριβοί για να υπάρχουν σε μια έκδοση κυκλοφορίας, αλλά μπορεί να είναι χρήσιμες κατά την ανάπτυξη.
///
/// Το αποτέλεσμα της επέκτασης του `debug_assert_eq!` ελέγχεται πάντα με τον τύπο.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Ισχυρίζεται ότι δύο εκφράσεις δεν είναι ίσες μεταξύ τους.
///
/// Στο panic, αυτή η μακροεντολή θα εκτυπώσει τις τιμές των εκφράσεων με τις αναπαραστάσεις εντοπισμού σφαλμάτων.
///
/// Σε αντίθεση με το [`assert_ne!`], οι δηλώσεις `debug_assert_ne!` ενεργοποιούνται μόνο σε μη βελτιστοποιημένες εκδόσεις από προεπιλογή.
/// Μια βελτιστοποιημένη έκδοση δεν θα εκτελέσει δηλώσεις `debug_assert_ne!`, εκτός εάν το `-C debug-assertions` περάσει στον μεταγλωττιστή.
/// Αυτό καθιστά το `debug_assert_ne!` χρήσιμο για ελέγχους που είναι πολύ ακριβοί για να υπάρχουν σε μια έκδοση κυκλοφορίας, αλλά μπορεί να είναι χρήσιμες κατά την ανάπτυξη.
///
/// Το αποτέλεσμα της επέκτασης του `debug_assert_ne!` ελέγχεται πάντα με τον τύπο.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Επιστρέφει εάν η δεδομένη έκφραση ταιριάζει με κάποιο από τα συγκεκριμένα μοτίβα.
///
/// Όπως σε μια έκφραση `match`, το μοτίβο μπορεί προαιρετικά να ακολουθείται από το `if` και μια έκφραση προστατευτικού που έχει πρόσβαση σε ονόματα που δεσμεύονται από το μοτίβο.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Ξετυλίγει ένα αποτέλεσμα ή διαδίδει το σφάλμα του.
///
/// Ο χειριστής `?` προστέθηκε για να αντικαταστήσει το `try!` και θα έπρεπε να χρησιμοποιηθεί αντ 'αυτού.
/// Επιπλέον, το `try` είναι μια δεσμευμένη λέξη στο Rust 2018, οπότε αν πρέπει να τη χρησιμοποιήσετε, θα πρέπει να χρησιμοποιήσετε το [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` ταιριάζει με το δεδομένο [`Result`].Στην περίπτωση της παραλλαγής `Ok`, η έκφραση έχει την τιμή της τυλιγμένης τιμής.
///
/// Στην περίπτωση της παραλλαγής `Err`, ανακτά το εσωτερικό σφάλμα.Στη συνέχεια, το `try!` εκτελεί μετατροπή χρησιμοποιώντας το `From`.
/// Αυτό παρέχει αυτόματη μετατροπή μεταξύ εξειδικευμένων σφαλμάτων και πιο γενικών.
/// Το προκύπτον σφάλμα επιστρέφεται αμέσως.
///
/// Λόγω της πρώιμης επιστροφής, το `try!` μπορεί να χρησιμοποιηθεί μόνο σε λειτουργίες που επιστρέφουν το [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Η προτιμώμενη μέθοδος γρήγορης επιστροφής σφαλμάτων
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Η προηγούμενη μέθοδος γρήγορης επιστροφής σφαλμάτων
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Αυτό ισοδυναμεί με:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Γράφει μορφοποιημένα δεδομένα σε buffer.
///
/// Αυτή η μακροεντολή δέχεται ένα 'writer', μια συμβολοσειρά μορφής και μια λίστα ορισμάτων.
/// Τα επιχειρήματα θα μορφοποιηθούν σύμφωνα με την καθορισμένη συμβολοσειρά μορφής και το αποτέλεσμα θα μεταδοθεί στον συγγραφέα.
/// Ο συγγραφέας μπορεί να έχει οποιαδήποτε αξία με μια μέθοδο `write_fmt`.Γενικά αυτό προέρχεται από την εφαρμογή είτε του [`fmt::Write`] είτε του [`io::Write`] trait.
/// Η μακροεντολή επιστρέφει ό, τι επιστρέφει η μέθοδος `write_fmt`.συνήθως [`fmt::Result`] ή [`io::Result`].
///
/// Ανατρέξτε στο [`std::fmt`] για περισσότερες πληροφορίες σχετικά με τη σύνταξη συμβολοσειράς μορφής.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Μια λειτουργική μονάδα μπορεί να εισαγάγει και τα `std::fmt::Write` και `std::io::Write` και να καλέσει `write!` σε αντικείμενα που εφαρμόζουν, καθώς τα αντικείμενα δεν εφαρμόζουν συνήθως και τα δύο.
///
/// Ωστόσο, η ενότητα πρέπει να εισαγάγει το traits με πιστοποίηση, ώστε τα ονόματά τους να μην έρχονται σε διένεξη:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // χρησιμοποιεί fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // χρησιμοποιεί io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Αυτή η μακροεντολή μπορεί να χρησιμοποιηθεί και στις ρυθμίσεις `no_std`.
/// Σε μια εγκατάσταση `no_std` είστε υπεύθυνοι για τις λεπτομέρειες υλοποίησης των στοιχείων.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Γράψτε τα διαμορφωμένα δεδομένα σε ένα buffer, με μια νέα γραμμή που επισυνάπτεται.
///
/// Σε όλες τις πλατφόρμες, η νέα γραμμή είναι μόνο ο χαρακτήρας LINE FEED (`\n`/`U+000A`) (χωρίς πρόσθετο CARRIAGE RETURN (`\r`/`U+000D`).
///
/// Για περισσότερες πληροφορίες, ανατρέξτε στο [`write!`].Για πληροφορίες σχετικά με τη σύνταξη συμβολοσειράς μορφής, ανατρέξτε στο [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Μια λειτουργική μονάδα μπορεί να εισαγάγει και τα `std::fmt::Write` και `std::io::Write` και να καλέσει `write!` σε αντικείμενα που εφαρμόζουν, καθώς τα αντικείμενα δεν εφαρμόζουν συνήθως και τα δύο.
/// Ωστόσο, η ενότητα πρέπει να εισαγάγει το traits με πιστοποίηση, ώστε τα ονόματά τους να μην έρχονται σε διένεξη:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // χρησιμοποιεί fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // χρησιμοποιεί io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Υποδεικνύει μη προσβάσιμο κωδικό.
///
/// Αυτό είναι χρήσιμο κάθε φορά που ο μεταγλωττιστής δεν μπορεί να προσδιορίσει ότι κάποιος κωδικός δεν είναι προσβάσιμος.Για παράδειγμα:
///
/// * Ταιριάξτε τα χέρια με τις συνθήκες προστασίας.
/// * Βρόχους που τερματίζονται δυναμικά.
/// * Επαναληπτές που τερματίζουν δυναμικά.
///
/// Εάν ο προσδιορισμός ότι ο κωδικός δεν είναι προσβάσιμος αποδειχθεί λανθασμένος, το πρόγραμμα τερματίζεται αμέσως με [`panic!`].
///
/// Το μη ασφαλές αντίστοιχο αυτής της μακροεντολής είναι η συνάρτηση [`unreachable_unchecked`], η οποία θα προκαλέσει απροσδιόριστη συμπεριφορά εάν επιτευχθεί ο κωδικός.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Αυτό θα είναι πάντα [`panic!`].
///
/// # Examples
///
/// Ταιριάξτε τα χέρια:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // μεταγλωττίστε το σφάλμα εάν σχολιάσετε
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // μία από τις φτωχότερες εφαρμογές του x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Υποδεικνύει τον μη εφαρμοσμένο κώδικα πατώντας με ένα μήνυμα "not implemented".
///
/// Αυτό επιτρέπει στον κωδικό σας να ελέγχει τον τύπο, ο οποίος είναι χρήσιμος εάν κάνετε πρωτότυπο ή εφαρμόζετε ένα trait που απαιτεί πολλές μεθόδους τις οποίες δεν σκοπεύετε να χρησιμοποιήσετε όλες.
///
/// Η διαφορά μεταξύ `unimplemented!` και [`todo!`] είναι ότι ενώ το `todo!` μεταδίδει την πρόθεση εφαρμογής της λειτουργικότητας αργότερα και το μήνυμα είναι "not yet implemented", το `unimplemented!` δεν προβάλλει τέτοιες αξιώσεις.
/// Το μήνυμά του είναι "not implemented".
/// Επίσης, ορισμένα IDE θα επισημάνουν το "todo!" S.
///
/// # Panics
///
/// Αυτό θα είναι πάντα [`panic!`] επειδή το `unimplemented!` είναι απλώς ένα σύντομο για το `panic!` με ένα σταθερό, συγκεκριμένο μήνυμα.
///
/// Όπως το `panic!`, αυτή η μακροεντολή έχει μια δεύτερη φόρμα για την εμφάνιση προσαρμοσμένων τιμών.
///
/// # Examples
///
/// Ας πούμε ότι έχουμε ένα trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Θέλουμε να εφαρμόσουμε το `Foo` για 'MyStruct', αλλά για κάποιο λόγο έχει νόημα να εφαρμόσουμε τη λειτουργία `bar()`.
/// `baz()` και το `qux()` θα πρέπει να καθοριστεί κατά την εφαρμογή του `Foo`, αλλά μπορούμε να χρησιμοποιήσουμε το `unimplemented!` στους ορισμούς τους για να επιτρέψουμε στον κώδικα μας να μεταγλωττιστεί.
///
/// Εξακολουθούμε να θέλουμε να σταματήσει να λειτουργεί το πρόγραμμά μας εάν επιτευχθούν οι μη εκτελεσμένες μέθοδοι.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Δεν έχει νόημα να `baz` ένα `MyStruct`, επομένως δεν έχουμε καμία λογική εδώ.
/////
///         // Θα εμφανιστεί το "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Έχουμε κάποια λογική εδώ, Μπορούμε να προσθέσουμε ένα μήνυμα στο μη υλοποιημένο!για να εμφανιστεί η παράλειψή μας.
///         // Αυτό θα εμφανίσει: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Υποδεικνύει ημιτελή κωδικό.
///
/// Αυτό μπορεί να είναι χρήσιμο εάν κάνετε πρωτότυπο και θέλετε απλώς να ελέγξετε τον κωδικό σας.
///
/// Η διαφορά μεταξύ [`unimplemented!`] και `todo!` είναι ότι ενώ το `todo!` μεταδίδει την πρόθεση εφαρμογής της λειτουργικότητας αργότερα και το μήνυμα είναι "not yet implemented", το `unimplemented!` δεν προβάλλει τέτοιες αξιώσεις.
/// Το μήνυμά του είναι "not implemented".
/// Επίσης, ορισμένα IDE θα επισημάνουν το "todo!" S.
///
/// # Panics
///
/// Αυτό θα είναι πάντα [`panic!`].
///
/// # Examples
///
/// Ακολουθεί ένα παράδειγμα κάποιου κώδικα σε εξέλιξη.Έχουμε ένα trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Θέλουμε να εφαρμόσουμε το `Foo` σε έναν από τους τύπους μας, αλλά θέλουμε επίσης να δουλέψουμε μόνο με το `bar()` πρώτα.Για να μεταγλωττιστεί ο κώδικάς μας, πρέπει να εφαρμόσουμε το `baz()`, ώστε να μπορούμε να χρησιμοποιήσουμε το `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // η εφαρμογή πηγαίνει εδώ
///     }
///
///     fn baz(&self) {
///         // μην ανησυχείτε για την εφαρμογή του baz() προς το παρόν
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // δεν χρησιμοποιούμε καν baz(), οπότε αυτό είναι εντάξει.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Ορισμοί των ενσωματωμένων μακροεντολών.
///
/// Οι περισσότερες από τις ιδιότητες μακροεντολής (σταθερότητα, ορατότητα κ.λπ.) λαμβάνονται από τον πηγαίο κώδικα εδώ, με εξαίρεση τις συναρτήσεις επέκτασης που μετατρέπουν τις εισόδους μακροεντολών σε εξόδους, αυτές οι λειτουργίες παρέχονται από τον μεταγλωττιστή.
///
///
pub(crate) mod builtin {

    /// Προκαλεί την αποτυχία της συλλογής με το δεδομένο μήνυμα σφάλματος όταν συναντάτε.
    ///
    /// Αυτή η μακροεντολή πρέπει να χρησιμοποιείται όταν ένα crate χρησιμοποιεί μια στρατηγική σύνταξης υπό όρους για να παρέχει καλύτερα μηνύματα σφάλματος για εσφαλμένες συνθήκες.
    ///
    /// Είναι η μορφή σε επίπεδο μεταγλωττιστή του [`panic!`], αλλά εκπέμπει σφάλμα κατά τη διάρκεια του *compilation* και όχι στο *runtime*.
    ///
    /// # Examples
    ///
    /// Δύο τέτοια παραδείγματα είναι περιβάλλοντα μακροεντολών και `#[cfg]`.
    ///
    /// Εκπέμψτε καλύτερο σφάλμα μεταγλωττιστή εάν μια μακροεντολή περάσει μη έγκυρες τιμές.
    /// Χωρίς το τελικό branch, ο μεταγλωττιστής θα εξακολουθούσε να εκπέμπει σφάλμα, αλλά το μήνυμα σφάλματος δεν θα αναφέρει τις δύο έγκυρες τιμές.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Εκπέμψτε σφάλμα μεταγλωττιστή εάν ένα από τα πολλά χαρακτηριστικά δεν είναι διαθέσιμο.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Κατασκευάζει παραμέτρους για τις άλλες μακροεντολές μορφοποίησης συμβολοσειρών.
    ///
    /// Αυτή η μακροεντολή λειτουργεί λαμβάνοντας μια κυριολεκτική συμβολοσειρά μορφοποίησης που περιέχει `{}` για κάθε επιπλέον όρισμα που περνά.
    /// `format_args!` προετοιμάζει τις πρόσθετες παραμέτρους για να εξασφαλίσει ότι η έξοδος μπορεί να ερμηνευθεί ως συμβολοσειρά και να κανονικοποιήσει τα ορίσματα σε έναν μόνο τύπο.
    /// Οποιαδήποτε τιμή που εφαρμόζει το [`Display`] trait μπορεί να περάσει στο `format_args!`, όπως και οποιαδήποτε εφαρμογή [`Debug`] μπορεί να περάσει σε `{:?}` μέσα στη συμβολοσειρά μορφοποίησης.
    ///
    ///
    /// Αυτή η μακροεντολή παράγει μια τιμή τύπου [`fmt::Arguments`].Αυτή η τιμή μπορεί να μεταφερθεί στις μακροεντολές εντός του [`std::fmt`] για την εκτέλεση χρήσιμης ανακατεύθυνσης.
    /// Όλες οι άλλες μακροεντολές μορφοποίησης (["format!"], [`write!`], [`println!`], κ.λπ.) παρέχονται μέσω αυτού.
    /// `format_args!`, Σε αντίθεση με τις παραγόμενες μακροεντολές του, αποφεύγει τις κατανομές σωρού.
    ///
    /// Μπορείτε να χρησιμοποιήσετε την τιμή [`fmt::Arguments`] που επιστρέφει το `format_args!` σε περιβάλλον `Debug` και `Display` όπως φαίνεται παρακάτω.
    /// Το παράδειγμα δείχνει επίσης ότι η μορφή `Debug` και `Display` στο ίδιο πράγμα: η συμβολοσειρά παρεμβολής μορφής στο `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Για περισσότερες πληροφορίες, ανατρέξτε στην τεκμηρίωση στο [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Το ίδιο με το `format_args`, αλλά προσθέτει μια νέα γραμμή στο τέλος.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Επιθεωρεί μια μεταβλητή περιβάλλοντος κατά το χρόνο μεταγλώττισης.
    ///
    /// Αυτή η μακροεντολή θα επεκταθεί στην τιμή της ονομασμένης μεταβλητής περιβάλλοντος κατά το χρόνο μεταγλώττισης, αποδίδοντας μια έκφραση του τύπου `&'static str`.
    ///
    ///
    /// Εάν η μεταβλητή περιβάλλοντος δεν έχει οριστεί, θα εκπέμπεται ένα σφάλμα συλλογής.
    /// Για να μην εκπέμψετε σφάλμα μεταγλώττισης, χρησιμοποιήστε τη μακροεντολή [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Μπορείτε να προσαρμόσετε το μήνυμα σφάλματος μεταβιβάζοντας μια συμβολοσειρά ως δεύτερη παράμετρο:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Εάν η μεταβλητή περιβάλλοντος `documentation` δεν έχει οριστεί, θα λάβετε το ακόλουθο σφάλμα:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Προαιρετικά επιθεωρεί μια μεταβλητή περιβάλλοντος κατά το χρόνο μεταγλώττισης.
    ///
    /// Εάν η ονομαζόμενη μεταβλητή περιβάλλοντος υπάρχει στο χρόνο μεταγλώττισης, αυτή θα επεκταθεί σε μια έκφραση του τύπου `Option<&'static str>` της οποίας η τιμή είναι `Some` της τιμής της μεταβλητής περιβάλλοντος.
    /// Εάν η μεταβλητή περιβάλλοντος δεν υπάρχει, τότε αυτό θα επεκταθεί σε `None`.
    /// Ανατρέξτε στο [`Option<T>`][Option] για περισσότερες πληροφορίες σχετικά με αυτόν τον τύπο.
    ///
    /// Ένα σφάλμα μεταγλώττισης δεν εκπέμπεται ποτέ κατά τη χρήση αυτής της μακροεντολής, ανεξάρτητα από το εάν η μεταβλητή περιβάλλοντος υπάρχει ή όχι.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Συνενώνει τα αναγνωριστικά σε ένα αναγνωριστικό.
    ///
    /// Αυτή η μακροεντολή παίρνει οποιονδήποτε αριθμό αναγνωριστικών διαχωρισμένων με κόμμα και τα συνδυάζει όλα σε ένα, αποδίδοντας μια έκφραση που είναι ένα νέο αναγνωριστικό.
    /// Σημειώστε ότι η υγιεινή το καθιστά τέτοιο ώστε αυτή η μακροεντολή να μην καταγράφει τοπικές μεταβλητές.
    /// Επίσης, κατά γενικό κανόνα, οι μακροεντολές επιτρέπονται μόνο σε θέση, δήλωση ή θέση έκφρασης.
    /// Αυτό σημαίνει ότι ενώ μπορείτε να χρησιμοποιήσετε αυτήν τη μακροεντολή για αναφορά σε υπάρχουσες μεταβλητές, συναρτήσεις ή λειτουργικές μονάδες κ.λπ., δεν μπορείτε να ορίσετε μια νέα με αυτήν.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (νέο, διασκεδαστικό, όνομα) { }//δεν μπορεί να χρησιμοποιηθεί με αυτόν τον τρόπο!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Συνδυάζει κυριολεκτικά σε ένα στατικό κομμάτι χορδών.
    ///
    /// Αυτή η μακροεντολή λαμβάνει οποιονδήποτε αριθμό γραμμάτων διαχωρισμένων με κόμμα, αποδίδοντας μια έκφραση του τύπου `&'static str` που αντιπροσωπεύει όλες τις κυριολεκτικές συνενώσεις από αριστερά προς τα δεξιά.
    ///
    ///
    /// Οι ακέραιοι ακέραιοι και κυμαινόμενοι βαθμοί είναι αυστηροί προκειμένου να συνδυαστούν.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Επεκτείνεται στον αριθμό γραμμής στον οποίο κλήθηκε.
    ///
    /// Με τα [`column!`] και [`file!`], αυτές οι μακροεντολές παρέχουν πληροφορίες εντοπισμού σφαλμάτων για προγραμματιστές σχετικά με την τοποθεσία στην πηγή.
    ///
    /// Η εκτεταμένη έκφραση έχει τύπο `u32` και βασίζεται σε 1, οπότε η πρώτη γραμμή σε κάθε αρχείο αξιολογείται σε 1, η δεύτερη σε 2 κ.λπ.
    /// Αυτό συμβαδίζει με μηνύματα σφάλματος από κοινού συντάκτες ή δημοφιλείς συντάκτες.
    /// Η επιστρεφόμενη γραμμή είναι *όχι απαραίτητα* η γραμμή της ίδιας της επίκλησης `line!`, αλλά μάλλον η πρώτη επίκληση μακροεντολής που οδηγεί στην επίκληση της μακροεντολής `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Επεκτείνεται στον αριθμό στήλης στην οποία κλήθηκε.
    ///
    /// Με τα [`line!`] και [`file!`], αυτές οι μακροεντολές παρέχουν πληροφορίες εντοπισμού σφαλμάτων για προγραμματιστές σχετικά με την τοποθεσία στην πηγή.
    ///
    /// Η εκτεταμένη έκφραση έχει τύπο `u32` και βασίζεται σε 1, οπότε η πρώτη στήλη σε κάθε γραμμή αξιολογείται σε 1, η δεύτερη σε 2 κ.λπ.
    /// Αυτό συμβαδίζει με μηνύματα σφάλματος από κοινού συντάκτες ή δημοφιλείς συντάκτες.
    /// Η επιστρεφόμενη στήλη είναι *όχι απαραίτητα* η γραμμή της ίδιας επίκλησης `column!`, αλλά μάλλον η πρώτη επίκληση μακροεντολής που οδηγεί στην επίκληση της μακροεντολής `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Επεκτείνεται στο όνομα του αρχείου στο οποίο κλήθηκε.
    ///
    /// Με τα [`line!`] και [`column!`], αυτές οι μακροεντολές παρέχουν πληροφορίες εντοπισμού σφαλμάτων για προγραμματιστές σχετικά με την τοποθεσία στην πηγή.
    ///
    /// Η εκτεταμένη έκφραση έχει τύπο `&'static str` και το επιστρεφόμενο αρχείο δεν είναι η επίκληση της ίδιας της μακροεντολής `file!`, αλλά η πρώτη επίκληση μακροεντολής που οδηγεί στην επίκληση της μακροεντολής `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Δείχνει τα επιχειρήματά του.
    ///
    /// Αυτή η μακροεντολή θα αποδώσει μια έκφραση του τύπου `&'static str`, η οποία είναι η αλληλουχία όλων των tokens που έχουν περάσει στη μακροεντολή.
    /// Δεν τίθενται περιορισμοί στη σύνταξη της ίδιας της μακροεντολής επίκλησης.
    ///
    /// Σημειώστε ότι τα εκτεταμένα αποτελέσματα της εισόδου tokens ενδέχεται να αλλάξουν στο future.Πρέπει να είστε προσεκτικοί εάν βασίζεστε στην έξοδο.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Περιλαμβάνει ένα κωδικοποιημένο αρχείο UTF-8 ως συμβολοσειρά.
    ///
    /// Το αρχείο βρίσκεται σε σχέση με το τρέχον αρχείο (παρόμοια με τον τρόπο εύρεσης των ενοτήτων).
    /// Η παρεχόμενη διαδρομή ερμηνεύεται με συγκεκριμένο τρόπο πλατφόρμας κατά το χρόνο μεταγλώττισης.
    /// Έτσι, για παράδειγμα, μια επίκληση με διαδρομή Windows που περιέχει ανάστροφη κάθετη `\` δεν θα μεταγλωττίστηκε σωστά στο Unix.
    ///
    ///
    /// Αυτή η μακροεντολή θα δώσει μια έκφραση του τύπου `&'static str` που είναι το περιεχόμενο του αρχείου.
    ///
    /// # Examples
    ///
    /// Ας υποθέσουμε ότι υπάρχουν δύο αρχεία στον ίδιο κατάλογο με τα ακόλουθα περιεχόμενα:
    ///
    /// Αρχείο 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Αρχείο 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Αν συγκεντρώσετε το 'main.rs' και εκτελέσετε το προκύπτον δυαδικό θα εκτυπώσετε το "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Περιλαμβάνει ένα αρχείο ως αναφορά σε έναν πίνακα byte.
    ///
    /// Το αρχείο βρίσκεται σε σχέση με το τρέχον αρχείο (παρόμοια με τον τρόπο εύρεσης των ενοτήτων).
    /// Η παρεχόμενη διαδρομή ερμηνεύεται με συγκεκριμένο τρόπο πλατφόρμας κατά το χρόνο μεταγλώττισης.
    /// Έτσι, για παράδειγμα, μια επίκληση με διαδρομή Windows που περιέχει ανάστροφη κάθετη `\` δεν θα μεταγλωττίστηκε σωστά στο Unix.
    ///
    ///
    /// Αυτή η μακροεντολή θα δώσει μια έκφραση του τύπου `&'static [u8; N]` που είναι το περιεχόμενο του αρχείου.
    ///
    /// # Examples
    ///
    /// Ας υποθέσουμε ότι υπάρχουν δύο αρχεία στον ίδιο κατάλογο με τα ακόλουθα περιεχόμενα:
    ///
    /// Αρχείο 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Αρχείο 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Αν συγκεντρώσετε το 'main.rs' και εκτελέσετε το προκύπτον δυαδικό θα εκτυπώσετε το "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Επεκτείνεται σε μια συμβολοσειρά που αντιπροσωπεύει την τρέχουσα διαδρομή λειτουργικής μονάδας.
    ///
    /// Η τρέχουσα διαδρομή ενότητας μπορεί να θεωρηθεί ως η ιεραρχία των ενοτήτων που οδηγούν πίσω στο crate root.
    /// Το πρώτο στοιχείο της διαδρομής που επιστρέφεται είναι το όνομα του crate που βρίσκεται σε εξέλιξη.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Αξιολογεί δυαδικούς συνδυασμούς σημαιών διαμόρφωσης στο χρόνο μεταγλώττισης.
    ///
    /// Εκτός από το χαρακτηριστικό `#[cfg]`, αυτή η μακροεντολή παρέχεται για να επιτρέψει την αξιολόγηση δυαδικής έκφρασης των σημαιών διαμόρφωσης.
    /// Αυτό συχνά οδηγεί σε λιγότερο διπλότυπο κώδικα.
    ///
    /// Η σύνταξη που δίνεται σε αυτήν τη μακροεντολή είναι η ίδια σύνταξη με το χαρακτηριστικό [`cfg`].
    ///
    /// `cfg!`, Σε αντίθεση με το `#[cfg]`, δεν αφαιρεί κανένα κώδικα και αξιολογείται μόνο σε αληθές ή ψευδές.
    /// Για παράδειγμα, όλα τα μπλοκ σε μια έκφραση if/else πρέπει να είναι έγκυρα όταν το `cfg!` χρησιμοποιείται για την κατάσταση, ανεξάρτητα από το τι αξιολογεί το `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Αναλύει ένα αρχείο ως παράσταση ή στοιχείο σύμφωνα με το περιβάλλον.
    ///
    /// Το αρχείο βρίσκεται σε σχέση με το τρέχον αρχείο (παρόμοια με τον τρόπο εύρεσης των ενοτήτων).Η παρεχόμενη διαδρομή ερμηνεύεται με συγκεκριμένο τρόπο πλατφόρμας κατά το χρόνο μεταγλώττισης.
    /// Έτσι, για παράδειγμα, μια επίκληση με διαδρομή Windows που περιέχει ανάστροφη κάθετη `\` δεν θα μεταγλωττίστηκε σωστά στο Unix.
    ///
    /// Η χρήση αυτής της μακροεντολής είναι συχνά μια κακή ιδέα, επειδή εάν το αρχείο αναλύεται ως έκφραση, θα τοποθετηθεί στον περιβάλλοντα κώδικα ανθυγιεινά.
    /// Αυτό θα μπορούσε να έχει ως αποτέλεσμα οι μεταβλητές ή οι συναρτήσεις να είναι διαφορετικές από τις αναμενόμενες στο αρχείο, εάν υπάρχουν μεταβλητές ή συναρτήσεις που έχουν το ίδιο όνομα στο τρέχον αρχείο.
    ///
    ///
    /// # Examples
    ///
    /// Ας υποθέσουμε ότι υπάρχουν δύο αρχεία στον ίδιο κατάλογο με τα ακόλουθα περιεχόμενα:
    ///
    /// Αρχείο 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Αρχείο 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Αν συγκεντρώσετε το 'main.rs' και εκτελέσετε το προκύπτον δυαδικό θα εκτυπώσετε το "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Υποστηρίζει ότι μια δυαδική έκφραση είναι `true` κατά το χρόνο εκτέλεσης.
    ///
    /// Αυτό θα επικαλεστεί τη μακροεντολή [`panic!`] εάν η παρεχόμενη έκφραση δεν μπορεί να αξιολογηθεί σε `true` κατά το χρόνο εκτέλεσης.
    ///
    /// # Uses
    ///
    /// Οι ισχυρισμοί ελέγχονται πάντοτε τόσο σε εντοπισμό σφαλμάτων όσο και σε εκδόσεις κυκλοφορίας και δεν μπορούν να απενεργοποιηθούν.
    /// Ανατρέξτε στο [`debug_assert!`] για ισχυρισμούς που δεν είναι ενεργοποιημένες στις εκδόσεις έκδοσης από προεπιλογή.
    ///
    /// Ο μη ασφαλής κώδικας μπορεί να βασίζεται στο `assert!` για την επιβολή αναλλοίωτων χρόνου εκτέλεσης που, εάν παραβιαστούν θα μπορούσαν να οδηγήσουν σε μη ασφαλή.
    ///
    /// Άλλες περιπτώσεις χρήσης του `assert!` περιλαμβάνουν δοκιμή και επιβολή αναλλοίωτων χρόνου εκτέλεσης σε ασφαλή κώδικα (η παραβίαση των οποίων δεν μπορεί να οδηγήσει σε μη ασφαλή).
    ///
    ///
    /// # Προσαρμοσμένα μηνύματα
    ///
    /// Αυτή η μακροεντολή έχει μια δεύτερη φόρμα, όπου ένα προσαρμοσμένο μήνυμα panic μπορεί να παρέχεται με ή χωρίς ορίσματα για μορφοποίηση.
    /// Ανατρέξτε στο [`std::fmt`] για σύνταξη για αυτήν τη φόρμα.
    /// Οι εκφράσεις που χρησιμοποιούνται ως ορίσματα μορφής θα αξιολογούνται μόνο εάν ο ισχυρισμός αποτύχει.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // το μήνυμα panic για αυτούς τους ισχυρισμούς είναι η τιμημένη τιμή της έκφρασης που δίνεται.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // μια πολύ απλή λειτουργία
    ///
    /// assert!(some_computation());
    ///
    /// // επιβεβαιώστε με ένα προσαρμοσμένο μήνυμα
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Ενσωματωμένο συγκρότημα.
    ///
    /// Διαβάστε το [unstable book] για τη χρήση.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Ενσωματωμένο συγκρότημα τύπου LLVM.
    ///
    /// Διαβάστε το [unstable book] για τη χρήση.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Ενσωματωμένο συγκρότημα επιπέδου μονάδας.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Οι εκτυπώσεις πέρασαν το tokens στην τυπική έξοδο.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Ενεργοποιεί ή απενεργοποιεί τη λειτουργία εντοπισμού που χρησιμοποιείται για τον εντοπισμό σφαλμάτων άλλων μακροεντολών.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Μακροεντολή χαρακτηριστικών που χρησιμοποιείται για την εφαρμογή μακροεντολών παράγωγου.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Η μακροεντολή χαρακτηριστικών εφαρμόζεται σε μια συνάρτηση για να τη μετατρέψει σε δοκιμή μονάδας.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Η μακροεντολή χαρακτηριστικών εφαρμόζεται σε μια συνάρτηση για να τη μετατρέψει σε δοκιμή αναφοράς.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Λεπτομέρεια εφαρμογής των μακροεντολών `#[test]` και `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Η μακροεντολή χαρακτηριστικών εφαρμόζεται σε μια στατική για να την καταχωρίσει ως καθολική κατανομή.
    ///
    /// Δείτε επίσης [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Διατηρεί το στοιχείο στο οποίο εφαρμόζεται εάν η διαδρομή που έχει περάσει είναι προσβάσιμη και το καταργεί διαφορετικά.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Επεκτείνει όλα τα χαρακτηριστικά `#[cfg]` και `#[cfg_attr]` στο τμήμα κώδικα στο οποίο εφαρμόζεται.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Ασταθής λεπτομέρεια εφαρμογής του μεταγλωττιστή `rustc`, μην το χρησιμοποιείτε.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Ασταθής λεπτομέρεια εφαρμογής του μεταγλωττιστή `rustc`, μην το χρησιμοποιείτε.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}