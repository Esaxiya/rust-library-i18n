// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Περιστρέφει το εύρος `[mid-left, mid+right)` έτσι ώστε το στοιχείο στο `mid` να γίνει το πρώτο στοιχείο.Επίσης, περιστρέφει τα στοιχεία εύρους `left` προς τα αριστερά ή τα στοιχεία `right` προς τα δεξιά.
///
/// # Safety
///
/// Το καθορισμένο εύρος πρέπει να ισχύει για ανάγνωση και γραφή.
///
/// # Algorithm
///
/// Ο αλγόριθμος 1 χρησιμοποιείται για μικρές τιμές `left + right` ή για μεγάλες `T`.
/// Τα στοιχεία μετακινούνται στις τελικές τους θέσεις μία κάθε φορά ξεκινώντας από το `mid - left` και προχωρώντας με τα βήματα `right` modulo `left + right`, έτσι ώστε να απαιτείται μόνο ένα προσωρινό.
/// Τελικά, επιστρέφουμε στο `mid - left`.
/// Ωστόσο, εάν το `gcd(left + right, right)` δεν είναι 1, τα παραπάνω βήματα παραλείπουν τα στοιχεία.
/// Για παράδειγμα:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Ευτυχώς, ο αριθμός των παραλειφθέντων στοιχείων μεταξύ των οριστικοποιημένων στοιχείων είναι πάντα ίσος, έτσι μπορούμε απλώς να αντισταθμίσουμε τη θέση εκκίνησης και να κάνουμε περισσότερους γύρους (ο συνολικός αριθμός γύρων είναι το `gcd(left + right, right)` value).
///
/// Το τελικό αποτέλεσμα είναι ότι όλα τα στοιχεία οριστικοποιούνται μία και μόνο μία φορά.
///
/// Ο αλγόριθμος 2 χρησιμοποιείται αν το `left + right` είναι μεγάλο, αλλά το `min(left, right)` είναι αρκετά μικρό για να χωρέσει σε ένα buffer στοίβας.
/// Τα στοιχεία `min(left, right)` αντιγράφονται στο buffer, το `memmove` εφαρμόζεται στα άλλα, και αυτά στο buffer μετακινούνται πίσω στην τρύπα στην αντίθετη πλευρά από όπου προήλθαν.
///
/// Αλγόριθμοι που μπορούν να διανυσματικοποιηθούν ξεπερνούν τα παραπάνω μόλις το `left + right` γίνει αρκετά μεγάλο.
/// Ο αλγόριθμος 1 μπορεί να διανυσματικοποιηθεί με chunking και εκτελώντας πολλούς γύρους ταυτόχρονα, αλλά υπάρχουν πάρα πολλοί γύροι κατά μέσο όρο έως ότου το `left + right` είναι τεράστιο και η χειρότερη περίπτωση ενός γύρου είναι πάντα εκεί.
/// Αντ 'αυτού, ο αλγόριθμος 3 χρησιμοποιεί επαναλαμβανόμενη εναλλαγή στοιχείων `min(left, right)` έως ότου παραμείνει ένα μικρότερο πρόβλημα περιστροφής.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// όταν `left < right` η ανταλλαγή συμβαίνει από τα αριστερά.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. οι παρακάτω αλγόριθμοι μπορεί να αποτύχουν εάν δεν ελέγχονται αυτές οι περιπτώσεις
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Οι αλγόριθμοι 1 Microbenchmark δείχνουν ότι η μέση απόδοση για τυχαίες μετατοπίσεις είναι καλύτερη σε όλη τη διάρκεια μέχρι περίπου το `left + right == 32`, αλλά η χειρότερη απόδοση φτάνει το 16.
            // Το 24 επιλέχθηκε ως μεσαίο έδαφος.
            // Εάν το μέγεθος του `T` είναι μεγαλύτερο από 4 "usize", αυτός ο αλγόριθμος ξεπερνά επίσης άλλους αλγορίθμους.
            //
            //
            let x = unsafe { mid.sub(left) };
            // αρχή του πρώτου γύρου
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` μπορεί να βρεθεί πριν από το χέρι με τον υπολογισμό του `gcd(left + right, right)`, αλλά είναι πιο γρήγορο να κάνετε έναν βρόχο που υπολογίζει το gcd ως παρενέργεια και μετά να κάνετε το υπόλοιπο κομμάτι
            //
            //
            let mut gcd = right;
            // τα σημεία αναφοράς αποκαλύπτουν ότι είναι πιο γρήγορο να αλλάζετε προσωρινά αντί να διαβάζετε ένα προσωρινό μία φορά, να αντιγράφετε προς τα πίσω και μετά να γράφετε αυτό το προσωρινό στο τέλος.
            // Αυτό οφείλεται πιθανώς στο γεγονός ότι η εναλλαγή ή η αντικατάσταση προσωρινών χρησιμοποιεί μόνο μία διεύθυνση μνήμης στο βρόχο αντί να χρειάζεται να διαχειριστεί δύο.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // αντί να αυξήσουμε το `i` και στη συνέχεια να ελέγξουμε εάν είναι εκτός ορίων, ελέγξουμε εάν το `i` θα πάει έξω από τα όρια στο επόμενο βήμα.
                // Αυτό αποτρέπει οποιαδήποτε περιτύλιξη δεικτών ή `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // τέλος του πρώτου γύρου
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // αυτός ο όρος πρέπει να είναι εδώ αν `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // τελειώστε το κομμάτι με περισσότερους γύρους
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` δεν είναι τύπου μηδενικού μεγέθους, επομένως είναι εντάξει να διαιρείται με το μέγεθός του.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Αλγόριθμος 2 Το `[T; 0]` εδώ είναι να διασφαλίσει ότι αυτό είναι σωστά ευθυγραμμισμένο για το Τ
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Αλγόριθμος 3 Υπάρχει ένας εναλλακτικός τρόπος ανταλλαγής που περιλαμβάνει την εύρεση της τελευταίας ανταλλαγής αυτού του αλγορίθμου και την εναλλαγή χρησιμοποιώντας αυτό το τελευταίο κομμάτι αντί της ανταλλαγής γειτονικών κομματιών όπως κάνει αυτός ο αλγόριθμος, αλλά αυτός ο τρόπος είναι ακόμα πιο γρήγορος.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Αλγόριθμος 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}