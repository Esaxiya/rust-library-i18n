//! Μακροεντολές που χρησιμοποιούνται από τους επαναληπτές του slice.

// Το inlining is_empty και το len κάνει μια τεράστια διαφορά απόδοσης
macro_rules! is_empty {
    // Ο τρόπος με τον οποίο κωδικοποιούμε το μήκος ενός επαναληπτικού ZST, λειτουργεί τόσο για ZST όσο και για μη ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Για να απαλλαγούμε από ορισμένους οριακούς ελέγχους (βλ. `position`), υπολογίζουμε το μήκος με κάπως απροσδόκητο τρόπο.
// (Δοκιμασμένο από το «codegen/slice-position-bounds-check».)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // μερικές φορές χρησιμοποιούνται σε ένα μη ασφαλές μπλοκ

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Αυτό το _cannot_ χρησιμοποιεί το `unchecked_sub` επειδή εξαρτάται από το περιτύλιγμα για να αντιπροσωπεύει το μήκος των μακρών επαναληπτικών φετών ZST.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Γνωρίζουμε ότι το `start <= end`, έτσι μπορεί να κάνει καλύτερα από το `offset_from`, το οποίο πρέπει να ασχοληθεί με την υπογραφή.
            // Με τον καθορισμό κατάλληλων σημαιών εδώ μπορούμε να το πούμε στο LLVM, κάτι που το βοηθά να αφαιρεί τους οριακούς ελέγχους.
            // ΑΣΦΑΛΕΙΑ: Από τον αναλλοίωτο τύπο, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Λέγοντας επίσης στο LLVM ότι οι δείκτες διαχωρίζονται από ένα ακριβές πολλαπλάσιο του μεγέθους τύπου, μπορεί να βελτιστοποιήσει το `len() == 0` έως το `start == end` αντί για το `(end - start) < size`.
            //
            // ΑΣΦΑΛΕΙΑ: Από τον αμετάβλητο τύπο, οι δείκτες ευθυγραμμίζονται έτσι
            //         Η απόσταση μεταξύ τους πρέπει να είναι πολλαπλάσιο του μεγέθους pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Ο κοινός ορισμός των επαναληπτικών `Iter` και `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Επιστρέφει το πρώτο στοιχείο και μετακινεί την αρχή του επαναληπτικού προς τα εμπρός κατά 1.
        // Βελτιώνει πολύ την απόδοση σε σύγκριση με μια ενσωματωμένη λειτουργία.
        // Η επανάληψη δεν πρέπει να είναι κενή.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Επιστρέφει το τελευταίο στοιχείο και μετακινεί το άκρο του επαναληπτικού προς τα πίσω κατά 1.
        // Βελτιώνει πολύ την απόδοση σε σύγκριση με μια ενσωματωμένη λειτουργία.
        // Η επανάληψη δεν πρέπει να είναι κενή.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Συρρικνώνει τον επαναληπτή όταν το T είναι ZST, μετακινώντας το άκρο του επαναληπτικού προς τα πίσω κατά `n`.
        // `n` δεν πρέπει να υπερβαίνει το `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Βοηθητική λειτουργία για τη δημιουργία ενός slice από τον επαναληπτή.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // ΑΣΦΑΛΕΙΑ: ο επαναλήπτης δημιουργήθηκε από ένα slice με δείκτη
                // `self.ptr` και μήκος `len!(self)`.
                // Αυτό εγγυάται ότι πληρούνται όλες οι προϋποθέσεις για το `from_raw_parts`.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Βοήθεια για τη μετακίνηση της εκκίνησης του επαναληπτικού προς τα εμπρός με στοιχεία `offset`, επιστρέφοντας την παλιά εκκίνηση.
            //
            // Μη ασφαλές επειδή το όφσετ δεν πρέπει να υπερβαίνει το `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // ΑΣΦΑΛΕΙΑ: ο καλών εγγυάται ότι το `offset` δεν υπερβαίνει το `self.len()`,
                    // οπότε αυτός ο νέος δείκτης βρίσκεται μέσα στο `self` και εγγυάται ότι είναι μηδενικός.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Βοηθητική λειτουργία για μετακίνηση του άκρου του επαναληπτικού προς τα πίσω από στοιχεία `offset`, επιστρέφοντας το νέο άκρο.
            //
            // Μη ασφαλές επειδή το όφσετ δεν πρέπει να υπερβαίνει το `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // ΑΣΦΑΛΕΙΑ: ο καλών εγγυάται ότι το `offset` δεν υπερβαίνει το `self.len()`,
                    // το οποίο είναι εγγυημένο ότι δεν θα ξεχειλίζει `isize`.
                    // Επίσης, ο δείκτης που προκύπτει βρίσκεται στα όρια του `slice`, το οποίο πληροί τις άλλες απαιτήσεις για το `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // θα μπορούσε να εφαρμοστεί με φέτες, αλλά αυτό αποφεύγει οριακούς ελέγχους

                // ΑΣΦΑΛΕΙΑ: Οι κλήσεις `assume` είναι ασφαλείς από την αρχή του δείκτη
                // πρέπει να είναι μη-μηδενικές και οι φέτες σε σχέση με τις μη ZST πρέπει επίσης να έχουν μη μηδενικό τελικό δείκτη.
                // Η κλήση στο `next_unchecked!` είναι ασφαλής αφού ελέγξουμε εάν ο επαναληπτής είναι άδειος πρώτα.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Αυτός ο επαναληπτής είναι τώρα άδειος.
                    if mem::size_of::<T>() == 0 {
                        // Πρέπει να το κάνουμε με αυτόν τον τρόπο καθώς το `ptr` μπορεί να μην είναι ποτέ 0, αλλά το `end` θα μπορούσε να είναι (λόγω του περιτυλίγματος).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // ΑΣΦΑΛΕΙΑ: το τέλος δεν μπορεί να είναι 0 εάν το T δεν είναι ZST επειδή το ptr δεν είναι 0 και το τέλος>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // ΑΣΦΑΛΕΙΑ: Είμαστε όρια.Το `post_inc_start` κάνει το σωστό ακόμη και για ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Παρακάμπτουμε την προεπιλεγμένη εφαρμογή, η οποία χρησιμοποιεί το `try_fold`, επειδή αυτή η απλή υλοποίηση παράγει λιγότερο LLVM IR και είναι πιο γρήγορη στη μεταγλώττιση.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Παρακάμπτουμε την προεπιλεγμένη εφαρμογή, η οποία χρησιμοποιεί το `try_fold`, επειδή αυτή η απλή υλοποίηση παράγει λιγότερο LLVM IR και είναι πιο γρήγορη στη μεταγλώττιση.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Παρακάμπτουμε την προεπιλεγμένη εφαρμογή, η οποία χρησιμοποιεί το `try_fold`, επειδή αυτή η απλή υλοποίηση παράγει λιγότερο LLVM IR και είναι πιο γρήγορη στη μεταγλώττιση.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Παρακάμπτουμε την προεπιλεγμένη εφαρμογή, η οποία χρησιμοποιεί το `try_fold`, επειδή αυτή η απλή υλοποίηση παράγει λιγότερο LLVM IR και είναι πιο γρήγορη στη μεταγλώττιση.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Παρακάμπτουμε την προεπιλεγμένη εφαρμογή, η οποία χρησιμοποιεί το `try_fold`, επειδή αυτή η απλή υλοποίηση παράγει λιγότερο LLVM IR και είναι πιο γρήγορη στη μεταγλώττιση.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Παρακάμπτουμε την προεπιλεγμένη εφαρμογή, η οποία χρησιμοποιεί το `try_fold`, επειδή αυτή η απλή υλοποίηση παράγει λιγότερο LLVM IR και είναι πιο γρήγορη στη μεταγλώττιση.
            // Επίσης, το `assume` αποφεύγει τον έλεγχο ορίων.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // ΑΣΦΑΛΕΙΑ: διασφαλίζουμε ότι είμαστε όρια από τον αμετάβλητο βρόχο:
                        // όταν το `i >= n`, το `self.next()` επιστρέφει το `None` και ο βρόχος σπάει.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Παρακάμπτουμε την προεπιλεγμένη εφαρμογή, η οποία χρησιμοποιεί το `try_fold`, επειδή αυτή η απλή υλοποίηση παράγει λιγότερο LLVM IR και είναι πιο γρήγορη στη μεταγλώττιση.
            // Επίσης, το `assume` αποφεύγει τον έλεγχο ορίων.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // ΑΣΦΑΛΕΙΑ: Το `i` πρέπει να είναι χαμηλότερο από το `n` αφού ξεκινά από το `n`
                        // και μειώνεται μόνο.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να εγγυηθεί ότι το `i` βρίσκεται σε όρια
                // το υποκείμενο slice, επομένως το `i` δεν μπορεί να ξεχειλίσει ένα `isize`, και οι επιστρεφόμενες αναφορές είναι εγγυημένες ότι αναφέρονται σε ένα στοιχείο του slice και επομένως εγγυώνται ότι είναι έγκυρες.
                //
                // Σημειώστε επίσης ότι ο καλών εγγυάται επίσης ότι δεν καλούμαστε ποτέ ξανά με το ίδιο ευρετήριο και ότι δεν καλούνται άλλες μέθοδοι που θα έχουν πρόσβαση σε αυτό το δευτερεύον υποσύνολο, επομένως ισχύει για την επιστρεφόμενη αναφορά να είναι μεταβλητή στην περίπτωση
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // θα μπορούσε να εφαρμοστεί με φέτες, αλλά αυτό αποφεύγει οριακούς ελέγχους

                // ΑΣΦΑΛΕΙΑ: Οι κλήσεις `assume` είναι ασφαλείς, καθώς ο δείκτης έναρξης ενός slice πρέπει να είναι μηδενικός,
                // και οι φέτες πάνω από τα μη ZST πρέπει επίσης να έχουν ένα μη μηδενικό τελικό δείκτη.
                // Η κλήση στο `next_back_unchecked!` είναι ασφαλής αφού ελέγξουμε εάν ο επαναληπτής είναι άδειος πρώτα.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Αυτός ο επαναληπτής είναι τώρα άδειος.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // ΑΣΦΑΛΕΙΑ: Είμαστε όρια.Το `pre_dec_end` κάνει το σωστό ακόμη και για ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}