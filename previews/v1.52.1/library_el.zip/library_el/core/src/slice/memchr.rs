// Η αρχική εφαρμογή λήφθηκε από το rust-memchr.
// Πνευματικά δικαιώματα 2015 Andrew Gallant, bluss και Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Χρησιμοποιήστε περικοπή.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Επιστρέφει `true` εάν το `x` περιέχει μηδέν byte.
///
/// Από *Matters Computational*, J. Arndt:
///
/// "Η ιδέα είναι να αφαιρέσουμε ένα από κάθε ένα από τα byte και στη συνέχεια να αναζητήσουμε bytes όπου το δάνειο διαδόθηκε μέχρι το πιο σημαντικό
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Επιστρέφει το πρώτο ευρετήριο που ταιριάζει με το byte `x` στο `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Γρήγορη διαδρομή για μικρές φέτες
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Σάρωση για τιμή ενός byte διαβάζοντας δύο λέξεις `usize` κάθε φορά.
    //
    // Χωρίστε το `text` σε τρία μέρη
    // - μη ευθυγραμμισμένο αρχικό μέρος, πριν από την ευθυγραμμισμένη πρώτη λέξη διεύθυνση στο κείμενο
    // - σώμα, σάρωση με 2 λέξεις τη φορά
    // - το τελευταίο υπόλοιπο μέρος, <2 μέγεθος λέξης

    // αναζήτηση μέχρι ένα ευθυγραμμισμένο όριο
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // αναζήτηση στο κύριο μέρος του κειμένου
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // ΑΣΦΑΛΕΙΑ: το κατηγορημα του στιγμιότυπου εγγυάται απόσταση τουλάχιστον 2 * usize_bytes
        // μεταξύ της μετατόπισης και του άκρου της φέτας.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // διακοπή εάν υπάρχει αντίστοιχο byte
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Βρείτε το byte μετά το σημείο που σταμάτησε ο βρόχος σώματος.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Επιστρέφει το τελευταίο ευρετήριο που ταιριάζει με το byte `x` στο `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Σάρωση για τιμή ενός byte διαβάζοντας δύο λέξεις `usize` κάθε φορά.
    //
    // Διαχωρίστε το `text` σε τρία μέρη:
    // - μη ευθυγραμμισμένη ουρά, μετά την τελευταία λέξη ευθυγραμμισμένη διεύθυνση σε κείμενο,
    // - σώμα, σαρώθηκε με 2 λέξεις τη φορά,
    // - τα πρώτα εναπομείναντα byte, <2 λέξεις μέγεθος.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Αυτό το ονομάζουμε μόνο για να λάβουμε το μήκος του προθέματος και του επιθήματος.
        // Στη μέση επεξεργαζόμαστε πάντα δύο κομμάτια ταυτόχρονα.
        // ΑΣΦΑΛΕΙΑ: η μετάδοση `[u8]` σε `[usize]` είναι ασφαλής εκτός από τις διαφορές μεγέθους που χειρίζονται το `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Αναζήτηση στο κύριο μέρος του κειμένου, βεβαιωθείτε ότι δεν διασχίζουμε το min_aligned_offset.
    // Η μετατόπιση είναι πάντα ευθυγραμμισμένη, οπότε η απλή δοκιμή `>` είναι αρκετή και αποφεύγει πιθανή υπερχείλιση.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // ΑΣΦΑΛΕΙΑ: η μετατόπιση ξεκινά από το len, suffix.len(), αρκεί να είναι μεγαλύτερη από
        // min_aligned_offset (prefix.len()) η απομένουσα απόσταση είναι τουλάχιστον 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Διακοπή εάν υπάρχει αντίστοιχο byte.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Βρείτε το byte πριν από τη διακοπή του βρόχου σώματος.
    text[..offset].iter().rposition(|elt| *elt == x)
}