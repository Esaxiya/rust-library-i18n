//! Διαλογή φετών
//!
//! Αυτή η ενότητα περιέχει έναν αλγόριθμο ταξινόμησης που βασίζεται στη γρήγορη ταξινόμηση μοτίβων του Orson Peters, που δημοσιεύτηκε στη διεύθυνση: <https://github.com/orlp/pdqsort>
//!
//!
//! Η ασταθής ταξινόμηση είναι συμβατή με το libcore επειδή δεν εκχωρεί μνήμη, σε αντίθεση με την εφαρμογή σταθερής ταξινόμησης.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Όταν πέσει, αντιγράφονται από το `src` σε `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // ΑΣΦΑΛΕΙΑ: Αυτή είναι μια τάξη βοηθού.
        //          Ανατρέξτε στη χρήση του για ορθότητα.
        //          Δηλαδή, πρέπει να είμαστε σίγουροι ότι τα `src` και `dst` δεν αλληλεπικαλύπτονται όπως απαιτείται από το `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Μετατοπίζει το πρώτο στοιχείο προς τα δεξιά έως ότου συναντήσει ένα μεγαλύτερο ή ίσο στοιχείο.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ΑΣΦΑΛΕΙΑ: Οι παρακάτω μη ασφαλείς λειτουργίες περιλαμβάνουν ευρετηρίαση χωρίς δεσμευμένο έλεγχο (`get_unchecked` και `get_unchecked_mut`)
    // και αντιγραφή μνήμης (`ptr::copy_nonoverlapping`).
    //
    // ένα.Ευρετηρίαση:
    //  1. Ελέγξαμε το μέγεθος του πίνακα σε>=2.
    //  2. Όλο το ευρετήριο που θα κάνουμε είναι πάντα μεταξύ {0 <= index < len} το πολύ.
    //
    // σι.Αντιγραφή μνήμης
    //  1. Λαμβάνουμε δείκτες σε αναφορές που είναι εγγυημένες ότι είναι έγκυρες.
    //  2. Δεν μπορούν να αλληλεπικαλύπτονται επειδή λαμβάνουμε δείκτες για τους δείκτες διαφοράς του slice.
    //     Δηλαδή, `i` και `i-1`.
    //  3. Εάν η φέτα είναι σωστά ευθυγραμμισμένη, τα στοιχεία ευθυγραμμίζονται σωστά.
    //     Είναι ευθύνη του καλούντος να διασφαλίσει ότι η φέτα είναι σωστά ευθυγραμμισμένη.
    //
    // Δείτε παρακάτω σχόλια για περισσότερες λεπτομέρειες.
    unsafe {
        // Εάν τα δύο πρώτα στοιχεία είναι εκτός λειτουργίας ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Διαβάστε το πρώτο στοιχείο σε μια μεταβλητή που έχει εκχωρηθεί στοίβα.
            // Εάν μια ακόλουθη λειτουργία σύγκρισης panics, το `hole` θα πέσει και θα γράψει αυτόματα το στοιχείο πίσω στη φέτα.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Μετακινήστε το στοιχείο «i`-th ένα μέρος προς τα αριστερά, μετατοπίζοντας έτσι την τρύπα προς τα δεξιά.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` πέφτει και έτσι αντιγράφει το `tmp` στην υπόλοιπη τρύπα στο `v`.
        }
    }
}

/// Μετατοπίζει το τελευταίο στοιχείο προς τα αριστερά έως ότου συναντήσει ένα μικρότερο ή ίσο στοιχείο.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ΑΣΦΑΛΕΙΑ: Οι παρακάτω μη ασφαλείς λειτουργίες περιλαμβάνουν ευρετηρίαση χωρίς δεσμευμένο έλεγχο (`get_unchecked` και `get_unchecked_mut`)
    // και αντιγραφή μνήμης (`ptr::copy_nonoverlapping`).
    //
    // ένα.Ευρετηρίαση:
    //  1. Ελέγξαμε το μέγεθος του πίνακα σε>=2.
    //  2. Όλο το ευρετήριο που θα κάνουμε είναι πάντα μεταξύ `0 <= index < len-1` το πολύ.
    //
    // σι.Αντιγραφή μνήμης
    //  1. Λαμβάνουμε δείκτες σε αναφορές που είναι εγγυημένες ότι είναι έγκυρες.
    //  2. Δεν μπορούν να αλληλεπικαλύπτονται επειδή λαμβάνουμε δείκτες για τους δείκτες διαφοράς του slice.
    //     Δηλαδή, `i` και `i+1`.
    //  3. Εάν η φέτα είναι σωστά ευθυγραμμισμένη, τα στοιχεία ευθυγραμμίζονται σωστά.
    //     Είναι ευθύνη του καλούντος να διασφαλίσει ότι η φέτα είναι σωστά ευθυγραμμισμένη.
    //
    // Δείτε παρακάτω σχόλια για περισσότερες λεπτομέρειες.
    unsafe {
        // Εάν τα δύο τελευταία στοιχεία είναι εκτός λειτουργίας ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Διαβάστε το τελευταίο στοιχείο σε μια μεταβλητή που έχει εκχωρηθεί στοίβα.
            // Εάν μια ακόλουθη λειτουργία σύγκρισης panics, το `hole` θα πέσει και θα γράψει αυτόματα το στοιχείο πίσω στη φέτα.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Μετακινήστε το στοιχείο «i`-th ένα μέρος προς τα δεξιά, μετατοπίζοντας έτσι την τρύπα προς τα αριστερά.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` πέφτει και έτσι αντιγράφει το `tmp` στην υπόλοιπη τρύπα στο `v`.
        }
    }
}

/// Μερικώς ταξινομεί ένα κομμάτι μετατοπίζοντας διάφορα στοιχεία εκτός τάξης.
///
/// Επιστρέφει το `true` εάν η φέτα έχει ταξινομηθεί στο τέλος.Αυτή η λειτουργία είναι *O*(*n*) στη χειρότερη περίπτωση.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Μέγιστος αριθμός παρακείμενων ζευγών εκτός παραγγελίας που θα μετατοπιστούν.
    const MAX_STEPS: usize = 5;
    // Εάν η φέτα είναι μικρότερη από αυτήν, μην μετατοπίζετε στοιχεία.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // ΑΣΦΑΛΕΙΑ: Έχουμε ήδη κάνει ρητά τον δεσμευμένο έλεγχο με το `i < len`.
        // Όλη η επόμενη ευρετηρίασή μας είναι μόνο στην περιοχή `0 <= index < len`
        unsafe {
            // Βρείτε το επόμενο ζευγάρι γειτονικών στοιχείων εκτός παραγγελίας.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Τελειώσαμε?
        if i == len {
            return true;
        }

        // Μην μετατοπίζετε στοιχεία σε μικρές συστοιχίες, με κόστος απόδοσης.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Ανταλλάξτε το ζεύγος στοιχείων που βρέθηκαν.Αυτό τα θέτει σε σωστή σειρά.
        v.swap(i - 1, i);

        // Μετακινήστε το μικρότερο στοιχείο προς τα αριστερά.
        shift_tail(&mut v[..i], is_less);
        // Μετακινήστε το μεγαλύτερο στοιχείο προς τα δεξιά.
        shift_head(&mut v[i..], is_less);
    }

    // Δεν κατάφερε να ταξινομήσει το κομμάτι στον περιορισμένο αριθμό βημάτων.
    false
}

/// Ταξινομήσει ένα κομμάτι χρησιμοποιώντας είδος εισαγωγής, το οποίο είναι *O*(*n*^ 2) στη χειρότερη περίπτωση.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Ταξινόμηση `v` χρησιμοποιώντας heapsort, το οποίο εγγυάται τη χειρότερη περίπτωση *O*(*n*\*log(* n*)).
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Αυτός ο δυαδικός σωρός σέβεται το αμετάβλητο `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Παιδιά `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Επιλέξτε το μεγαλύτερο παιδί.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Σταματήστε εάν το αμετάβλητο διατηρείται στο `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Ανταλλάξτε το `node` με το μεγαλύτερο παιδί, μετακινήστε ένα βήμα προς τα κάτω και συνεχίστε το κοσκίνισμα.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Φτιάξτε το σωρό σε γραμμικό χρόνο.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Βάλτε τα μέγιστα στοιχεία από το σωρό.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Χωρίζει `v` σε στοιχεία μικρότερα από `pivot`, ακολουθούμενα από στοιχεία μεγαλύτερα από ή ίσα με `pivot`.
///
///
/// Επιστρέφει τον αριθμό των στοιχείων μικρότερο από `pivot`.
///
/// Η διαμέριση πραγματοποιείται ανά μπλοκ για να ελαχιστοποιηθεί το κόστος των λειτουργιών διακλάδωσης.
/// Αυτή η ιδέα παρουσιάζεται στο χαρτί [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Αριθμός στοιχείων σε ένα τυπικό μπλοκ.
    const BLOCK: usize = 128;

    // Ο αλγόριθμος διαμέρισης επαναλαμβάνει τα ακόλουθα βήματα μέχρι την ολοκλήρωση:
    //
    // 1. Εντοπίστε ένα μπλοκ από την αριστερή πλευρά για να εντοπίσετε στοιχεία μεγαλύτερα ή ίσα με τον άξονα.
    // 2. Εντοπίστε ένα μπλοκ από τη δεξιά πλευρά για να εντοπίσετε στοιχεία μικρότερα από τον άξονα.
    // 3. Ανταλλάξτε τα αναγνωρισμένα στοιχεία μεταξύ της αριστεράς και της δεξιάς πλευράς.
    //
    // Διατηρούμε τις ακόλουθες μεταβλητές για ένα μπλοκ στοιχείων:
    //
    // 1. `block` - Αριθμός στοιχείων στο μπλοκ.
    // 2. `start` - Ξεκινήστε το δείκτη στη σειρά `offsets`.
    // 3. `end` - Τερματίστε το δείκτη στη συστοιχία `offsets`.
    // 4. "αντισταθμίσεις, δείκτες στοιχείων εκτός λειτουργίας εντός του μπλοκ.

    // Το τρέχον μπλοκ στην αριστερή πλευρά (από `l` έως `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Το τρέχον μπλοκ στη δεξιά πλευρά (από το `r.sub(block_r)` to `r`).
    // ΑΣΦΑΛΕΙΑ: Η τεκμηρίωση για το .add() αναφέρει συγκεκριμένα ότι το `vec.as_ptr().add(vec.len())` είναι πάντα ασφαλές »
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Όταν λαμβάνουμε VLA, δοκιμάστε να δημιουργήσετε έναν πίνακα μήκους `min(v.len(), 2 * BLOCK) "
    // από δύο συστοιχίες σταθερού μεγέθους μήκους `BLOCK`.Τα VLA ενδέχεται να είναι πιο αποδοτικά στην προσωρινή μνήμη.

    // Επιστρέφει τον αριθμό των στοιχείων μεταξύ των δεικτών `l` (inclusive) και `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Τελειώσαμε με το διαχωρισμό block-by-block όταν τα `l` και `r` πλησιάσουν πολύ.
        // Στη συνέχεια, κάνουμε κάποια δουλειά για να χωρίσουμε τα υπόλοιπα στοιχεία στο μεταξύ.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Αριθμός υπολειπόμενων στοιχείων (εξακολουθεί να μην συγκρίνεται με τον άξονα).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Προσαρμόστε τα μεγέθη μπλοκ έτσι ώστε το αριστερό και το δεξί μπλοκ να μην αλληλεπικαλύπτονται, αλλά ευθυγραμμίζετε τέλεια για να καλύψετε ολόκληρο το εναπομένον κενό.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Εντοπίστε στοιχεία `block_l` από την αριστερή πλευρά.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // ΑΣΦΑΛΕΙΑ: Οι παρακάτω ενέργειες μη ασφάλειας περιλαμβάνουν τη χρήση του `offset`.
                //         Σύμφωνα με τους όρους που απαιτούνται από τη συνάρτηση, τους ικανοποιούμε γιατί:
                //         1. `offsets_l` κατανέμεται στοίβα, και ως εκ τούτου θεωρείται ξεχωριστό αντικείμενο.
                //         2. Η συνάρτηση `is_less` επιστρέφει ένα `bool`.
                //            Η μετάδοση `bool` δεν θα υπερχειλίσει ποτέ το `isize`.
                //         3. Έχουμε εγγυηθεί ότι το `block_l` θα είναι `<= BLOCK`.
                //            Επιπλέον, το `end_l` ορίστηκε αρχικά στο δείκτη έναρξης του `offsets_` που δηλώθηκε στη στοίβα.
                //            Έτσι, γνωρίζουμε ότι ακόμα και στη χειρότερη περίπτωση (όλες οι επικλήσεις του `is_less` επιστρέφουν ψευδείς) θα έχουμε μόνο το πολύ 1 byte στο τέλος.
                //        Μια άλλη λειτουργία μη ασφάλειας εδώ είναι η αποπροσανατολισμός του `elem`.
                //        Ωστόσο, το `elem` ήταν αρχικά ο δείκτης έναρξης του slice που ισχύει πάντα.
                unsafe {
                    // Σύγκριση χωρίς κλαδιά.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Εντοπίστε στοιχεία `block_r` από τη δεξιά πλευρά.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // ΑΣΦΑΛΕΙΑ: Οι παρακάτω ενέργειες μη ασφάλειας περιλαμβάνουν τη χρήση του `offset`.
                //         Σύμφωνα με τους όρους που απαιτούνται από τη συνάρτηση, τους ικανοποιούμε γιατί:
                //         1. `offsets_r` κατανέμεται στοίβα, και ως εκ τούτου θεωρείται ξεχωριστό αντικείμενο.
                //         2. Η συνάρτηση `is_less` επιστρέφει ένα `bool`.
                //            Η μετάδοση `bool` δεν θα υπερχειλίσει ποτέ το `isize`.
                //         3. Έχουμε εγγυηθεί ότι το `block_r` θα είναι `<= BLOCK`.
                //            Επιπλέον, το `end_r` ορίστηκε αρχικά στο δείκτη έναρξης του `offsets_` που δηλώθηκε στη στοίβα.
                //            Έτσι, γνωρίζουμε ότι ακόμη και στη χειρότερη περίπτωση (όλες οι επικλήσεις του `is_less` επιστρέφουν αληθινές) θα έχουμε μόνο το πολύ 1 byte στο τέλος.
                //        Μια άλλη λειτουργία μη ασφάλειας εδώ είναι η αποπροσανατολισμός του `elem`.
                //        Ωστόσο, το `elem` ήταν αρχικά `1 *sizeof(T)` μετά το τέλος και το μειώσαμε κατά `1* sizeof(T)` πριν το αποκτήσουμε.
                //        Επιπλέον, το `block_r` ισχυρίστηκε ότι είναι μικρότερο από το `BLOCK` και το `elem` ως εκ τούτου θα έδειχνε το πολύ στην αρχή του slice.
                unsafe {
                    // Σύγκριση χωρίς κλαδιά.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Αριθμός στοιχείων εκτός παραγγελίας για εναλλαγή μεταξύ της αριστεράς και της δεξιάς πλευράς.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Αντί να ανταλλάσσετε ένα ζευγάρι κάθε φορά, είναι πιο αποτελεσματικό να εκτελείτε κυκλική μετάθεση.
            // Αυτό δεν είναι αυστηρά ισοδύναμο με την ανταλλαγή, αλλά παράγει ένα παρόμοιο αποτέλεσμα χρησιμοποιώντας λιγότερες λειτουργίες μνήμης.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Μετακινήθηκαν όλα τα εκτός λειτουργίας στοιχεία στο αριστερό μπλοκ.Μεταβείτε στο επόμενο μπλοκ.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Μετακινήθηκαν όλα τα εκτός λειτουργίας στοιχεία στο δεξιό μπλοκ.Μετακίνηση στο προηγούμενο μπλοκ.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Το μόνο που μένει τώρα είναι το πολύ ένα μπλοκ (είτε αριστερά είτε δεξιά) με στοιχεία εκτός παραγγελίας που πρέπει να μετακινηθούν.
    // Τέτοια εναπομείναντα στοιχεία μπορούν απλά να μετατοπιστούν στο τέλος εντός του μπλοκ τους.
    //

    if start_l < end_l {
        // Το αριστερό μπλοκ παραμένει.
        // Μετακινήστε τα υπόλοιπα εκτός παραγγελίας στοιχεία στην άκρη δεξιά.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Το σωστό μπλοκ παραμένει.
        // Μετακινήστε τα υπόλοιπα εκτός παραγγελίας στοιχεία προς τα αριστερά.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Τίποτα άλλο να κάνουμε, τελειώσαμε.
        width(v.as_mut_ptr(), l)
    }
}

/// Χωρίζει `v` σε στοιχεία μικρότερα από `v[pivot]`, ακολουθούμενα από στοιχεία μεγαλύτερα από ή ίσα με `v[pivot]`.
///
///
/// Επιστρέφει μια πλειάδα:
///
/// 1. Αριθμός στοιχείων μικρότερο από `v[pivot]`.
/// 2. Αληθές αν το `v` είχε ήδη διαχωριστεί.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Τοποθετήστε τον άξονα στην αρχή της φέτας.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Διαβάστε τον άξονα σε μια μεταβλητή που έχει εκχωρηθεί στοίβα για αποδοτικότητα.
        // Εάν μια ακόλουθη λειτουργία σύγκρισης panics, ο άξονας θα εγγραφεί αυτόματα στο slice.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Βρείτε το πρώτο ζευγάρι στοιχείων εκτός παραγγελίας.
        let mut l = 0;
        let mut r = v.len();

        // ΑΣΦΑΛΕΙΑ: Η παρακάτω αβεβαιότητα περιλαμβάνει την ευρετηρίαση ενός πίνακα.
        // Για το πρώτο: Κάνουμε ήδη τον έλεγχο ορίων εδώ με `l < r`.
        // Για το δεύτερο: Έχουμε αρχικά `l == 0` και `r == v.len()` και ελέγξαμε ότι `l < r` σε κάθε λειτουργία ευρετηρίου.
        //                     Από εδώ γνωρίζουμε ότι το `r` πρέπει να είναι τουλάχιστον `r == l` το οποίο αποδείχθηκε ότι είναι έγκυρο από το πρώτο.
        unsafe {
            // Βρείτε το πρώτο στοιχείο μεγαλύτερο ή ίσο με τον άξονα.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Βρείτε το τελευταίο στοιχείο μικρότερο από τον άξονα.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` βγαίνει εκτός εμβέλειας και γράφει τον άξονα (που είναι μια μεταβλητή που έχει εκχωρηθεί στοίβα) πίσω στο slice όπου ήταν αρχικά.
        // Αυτό το βήμα είναι κρίσιμο για τη διασφάλιση της ασφάλειας!
        //
    };

    // Τοποθετήστε τον άξονα μεταξύ των δύο κατατμήσεων.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Χωρίζει `v` σε στοιχεία ίσο με `v[pivot]` ακολουθούμενο από στοιχεία μεγαλύτερα από `v[pivot]`.
///
/// Επιστρέφει τον αριθμό των στοιχείων που είναι ίσοι με τον άξονα.
/// Υποτίθεται ότι το `v` δεν περιέχει στοιχεία μικρότερα από τον άξονα.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Τοποθετήστε τον άξονα στην αρχή της φέτας.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Διαβάστε τον άξονα σε μια μεταβλητή που έχει εκχωρηθεί στοίβα για αποδοτικότητα.
    // Εάν μια ακόλουθη λειτουργία σύγκρισης panics, ο άξονας θα εγγραφεί αυτόματα στο slice.
    // ΑΣΦΑΛΕΙΑ: Ο δείκτης εδώ είναι έγκυρος επειδή προέρχεται από μια αναφορά σε ένα κομμάτι.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Τώρα χωρίστε το slice.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // ΑΣΦΑΛΕΙΑ: Η παρακάτω αβεβαιότητα περιλαμβάνει την ευρετηρίαση ενός πίνακα.
        // Για το πρώτο: Κάνουμε ήδη τον έλεγχο ορίων εδώ με `l < r`.
        // Για το δεύτερο: Έχουμε αρχικά `l == 0` και `r == v.len()` και ελέγξαμε ότι `l < r` σε κάθε λειτουργία ευρετηρίου.
        //                     Από εδώ γνωρίζουμε ότι το `r` πρέπει να είναι τουλάχιστον `r == l` το οποίο αποδείχθηκε ότι είναι έγκυρο από το πρώτο.
        unsafe {
            // Βρείτε το πρώτο στοιχείο μεγαλύτερο από τον άξονα.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Βρείτε το τελευταίο στοιχείο ίσο με τον άξονα.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Τελειώσαμε?
            if l >= r {
                break;
            }

            // Ανταλλάξτε το ζεύγος των στοιχείων εκτός παραγγελίας.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Βρήκαμε στοιχεία `l` ίσο με τον άξονα.Προσθέστε 1 για λογαριασμό του ίδιου του άξονα.
    l + 1

    // `_pivot_guard` βγαίνει εκτός εμβέλειας και γράφει τον άξονα (που είναι μια μεταβλητή που έχει εκχωρηθεί στοίβα) πίσω στο slice όπου ήταν αρχικά.
    // Αυτό το βήμα είναι κρίσιμο για τη διασφάλιση της ασφάλειας!
}

/// Διασκορπίζει ορισμένα στοιχεία σε μια προσπάθεια να σπάσει μοτίβα που μπορεί να προκαλέσουν ανισορροπημένες κατατμήσεις στο quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Ψευδοτυχαία γεννήτρια αριθμών από το χαρτί "Xorshift RNGs" του George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Πάρτε τυχαίους αριθμούς modulo αυτόν τον αριθμό.
        // Ο αριθμός ταιριάζει στο `usize` επειδή το `len` δεν είναι μεγαλύτερο από το `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Ορισμένοι συγκεντρωτικοί υποψήφιοι θα βρίσκονται στο κοντινό αυτού του ευρετηρίου.Ας τους τυχαιοποιήσουμε.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Δημιουργήστε έναν τυχαίο αριθμό modulo `len`.
            // Ωστόσο, για να αποφευχθούν δαπανηρές λειτουργίες, το παίρνουμε αρχικά με ισχύ δύο, και στη συνέχεια μειώνονται κατά `len` έως ότου ταιριάζει στην περιοχή `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` είναι εγγυημένο ότι είναι μικρότερο από `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Επιλέγει έναν άξονα στο `v` και επιστρέφει το ευρετήριο και το `true` εάν το slice είναι πιθανότατα ήδη ταξινομημένο.
///
/// Τα στοιχεία στο `v` ενδέχεται να αναδιατάσσονται κατά τη διαδικασία.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ελάχιστο μήκος για να επιλέξετε τη μέθοδο του διάμεσου.
    // Οι μικρότερες φέτες χρησιμοποιούν την απλή μέθοδο διάμεσου-τριών.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Μέγιστος αριθμός ανταλλαγών που μπορούν να εκτελεστούν σε αυτήν τη λειτουργία.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Τρεις δείκτες κοντά στους οποίους θα επιλέξουμε έναν άξονα.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Μετρά τον συνολικό αριθμό ανταλλαγών που πρόκειται να εκτελέσουμε κατά την ταξινόμηση δεικτών.
    let mut swaps = 0;

    if len >= 8 {
        // Ανταλλάσσει δείκτες έτσι ώστε `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Ανταλλάσσει δείκτες έτσι ώστε `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Βρίσκει τη διάμεση τιμή του `v[a - 1], v[a], v[a + 1]` και αποθηκεύει το ευρετήριο στο `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Βρείτε διάμεσους στις γειτονιές `a`, `b` και `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Βρείτε τη διάμεση τιμή μεταξύ των `a`, `b` και `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Πραγματοποιήθηκε ο μέγιστος αριθμός ανταλλαγών.
        // Οι πιθανότητες είναι ότι η φέτα είναι φθίνουσα ή ως επί το πλείστον φθίνουσα, οπότε η αντιστροφή πιθανότατα θα σας βοηθήσει να τακτοποιήσετε πιο γρήγορα.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Ταξινόμηση `v` αναδρομικά.
///
/// Εάν το slice είχε προκάτοχο στον αρχικό πίνακα, καθορίζεται ως `pred`.
///
/// `limit` είναι ο αριθμός των επιτρεπόμενων ανισορροπημένων κατατμήσεων πριν από τη μετάβαση στο `heapsort`.
/// Εάν μηδέν, αυτή η λειτουργία θα μεταβεί αμέσως στο heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Οι φέτες έως και αυτού του μήκους ταξινομούνται χρησιμοποιώντας την ένταξη εισαγωγής.
    const MAX_INSERTION: usize = 20;

    // Είναι αλήθεια αν το τελευταίο διαμέρισμα ήταν λογικά ισορροπημένο.
    let mut was_balanced = true;
    // Είναι αλήθεια αν το τελευταίο διαμέρισμα δεν ανακατέψει στοιχεία (το slice είχε ήδη διαχωριστεί).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Οι πολύ μικρές φέτες ταξινομούνται χρησιμοποιώντας την ένθεση εισαγωγής.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Εάν έγιναν πάρα πολλές κακές επιλογές περιστροφής, απλώς επιστρέψτε στο σωρό για να εγγυηθείτε τη χειρότερη περίπτωση του `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Εάν το τελευταίο διαμέρισμα δεν ήταν ισορροπημένο, δοκιμάστε να σπάσετε τα μοτίβα στο slice ανακατεύοντας ορισμένα στοιχεία.
        // Ας ελπίσουμε ότι θα επιλέξουμε έναν καλύτερο άξονα αυτή τη φορά.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Επιλέξτε έναν άξονα και δοκιμάστε να μαντέψετε εάν το κομμάτι έχει ήδη ταξινομηθεί.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Εάν το τελευταίο διαμέρισμα ήταν αξιοπρεπώς ισορροπημένο και δεν ανακάτεμα στοιχεία, και αν η επιλογή περιστροφής προβλέπει ότι το slice πιθανότατα έχει ήδη ταξινομηθεί ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Προσπαθήστε να εντοπίσετε πολλά στοιχεία εκτός παραγγελίας και να τα αλλάξετε για να διορθώσετε τις θέσεις.
            // Εάν η φέτα καταλήξει να ταξινομηθεί πλήρως, τελειώσαμε.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Εάν το επιλεγμένο άξονα είναι ίσο με τον προκάτοχό του, τότε είναι το μικρότερο στοιχείο του slice.
        // Διαχωρίστε τη φέτα σε στοιχεία ίσο με και στοιχεία μεγαλύτερα από τον άξονα.
        // Αυτή η περίπτωση συνήθως χτυπιέται όταν η φέτα περιέχει πολλά διπλά στοιχεία.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Συνεχίστε την ταξινόμηση στοιχείων μεγαλύτερων από τον άξονα.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Χωρίστε το κομμάτι.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Χωρίστε τη φέτα σε `left`, `pivot` και `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Επανάληψη στη μικρότερη πλευρά μόνο για ελαχιστοποίηση του συνολικού αριθμού αναδρομικών κλήσεων και κατανάλωση λιγότερου χώρου στοίβας.
        // Στη συνέχεια, συνεχίστε με τη μεγαλύτερη πλευρά (αυτό είναι παρόμοιο με την αναδρομή της ουράς).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Ταξινομήσει το `v` χρησιμοποιώντας τη γρήγορη ταξινόμηση μοτίβου, που είναι *O*(*n*\*log(* n*)) στη χειρότερη περίπτωση.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Η ταξινόμηση δεν έχει σημαντική συμπεριφορά σε τύπους μηδενικού μεγέθους.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Περιορίστε τον αριθμό των μη ισορροπημένων κατατμήσεων σε `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Για φέτες έως και αυτού του μήκους είναι πιθανώς πιο γρήγορο να τα ταξινομήσετε.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Επιλέξτε έναν άξονα
        let (pivot, _) = choose_pivot(v, is_less);

        // Εάν το επιλεγμένο άξονα είναι ίσο με τον προκάτοχό του, τότε είναι το μικρότερο στοιχείο του slice.
        // Διαχωρίστε τη φέτα σε στοιχεία ίσο με και στοιχεία μεγαλύτερα από τον άξονα.
        // Αυτή η περίπτωση συνήθως χτυπιέται όταν η φέτα περιέχει πολλά διπλά στοιχεία.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Εάν περάσουμε το ευρετήριό μας, τότε είμαστε καλοί.
                if mid > index {
                    return;
                }

                // Διαφορετικά, συνεχίστε την ταξινόμηση στοιχείων μεγαλύτερων από τον άξονα.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Χωρίστε τη φέτα σε `left`, `pivot` και `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Αν ο μέσος δείκτης==, τότε έχουμε τελειώσει, καθώς το partition() εγγυάται ότι όλα τα στοιχεία μετά τα μέσα είναι μεγαλύτερα από ή ίσα με τα μέσα.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Η ταξινόμηση δεν έχει σημαντική συμπεριφορά σε τύπους μηδενικού μεγέθους.Μην κάνεις τίποτα.
    } else if index == v.len() - 1 {
        // Βρείτε το μέγιστο στοιχείο και τοποθετήστε το στην τελευταία θέση του πίνακα.
        // Είμαστε ελεύθεροι να χρησιμοποιήσουμε το `unwrap()` εδώ, επειδή γνωρίζουμε ότι το v δεν πρέπει να είναι κενό.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Βρείτε min στοιχείο και τοποθετήστε το στην πρώτη θέση του πίνακα.
        // Είμαστε ελεύθεροι να χρησιμοποιήσουμε το `unwrap()` εδώ, επειδή γνωρίζουμε ότι το v δεν πρέπει να είναι κενό.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}