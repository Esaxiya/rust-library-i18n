use crate::fmt;

/// Δημιουργεί ένα νέο επαναληπτικό όπου κάθε επανάληψη καλεί το παρεχόμενο κλείσιμο `F: FnMut() -> Option<T>`.
///
/// Αυτό επιτρέπει τη δημιουργία ενός προσαρμοσμένου επαναληπτικού με οποιαδήποτε συμπεριφορά χωρίς τη χρήση της πιο ριζικής σύνταξης της δημιουργίας ενός ειδικού τύπου και της εφαρμογής του [`Iterator`] trait για αυτό.
///
/// Σημειώστε ότι ο επαναληπτής `FromFn` δεν κάνει υποθέσεις σχετικά με τη συμπεριφορά του κλεισίματος και επομένως συντηρητικά δεν εφαρμόζει το [`FusedIterator`] ή παρακάμπτει το [`Iterator::size_hint()`] από το προεπιλεγμένο `(0, None)`.
///
///
/// Το κλείσιμο μπορεί να χρησιμοποιήσει λήψεις και το περιβάλλον του για να παρακολουθεί την κατάσταση σε όλες τις επαναλήψεις.Ανάλογα με τον τρόπο χρήσης του επαναληπτικού, ενδέχεται να απαιτείται καθορισμός της λέξης-κλειδιού [`move`] στο κλείσιμο.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Ας ξαναρχίσουμε τον επαναληπτικό μετρητή από το [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Αυξήστε τον αριθμό μας.Γι 'αυτό ξεκινήσαμε στο μηδέν.
///     count += 1;
///
///     // Ελέγξτε αν έχουμε ολοκληρώσει τη μέτρηση ή όχι.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Ένας επαναληπτής όπου κάθε επανάληψη καλεί το παρεχόμενο κλείσιμο `F: FnMut() -> Option<T>`.
///
/// Αυτό το `struct` δημιουργείται από τη συνάρτηση [`iter::from_fn()`].
/// Δείτε την τεκμηρίωσή του για περισσότερα.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}