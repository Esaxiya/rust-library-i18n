use crate::iter::{FusedIterator, TrustedLen};

/// Δημιουργεί ένα νέο επαναληπτικό που επαναλαμβάνει στοιχεία του τύπου `A` ατελείωτα εφαρμόζοντας το παρεχόμενο κλείσιμο, τον επαναλήπτη, `F: FnMut() -> A`.
///
/// Η συνάρτηση `repeat_with()` καλεί τον επαναλήπτη ξανά και ξανά.
///
/// Απεριόριστα επαναληπτικά όπως το `repeat_with()` χρησιμοποιούνται συχνά με προσαρμογείς όπως το [`Iterator::take()`], για να τα καταστήσουν πεπερασμένα.
///
/// Εάν ο τύπος στοιχείου του επαναληπτικού που χρειάζεστε εφαρμόζει το [`Clone`] και είναι εντάξει να διατηρήσετε το στοιχείο προέλευσης στη μνήμη, θα πρέπει αντ 'αυτού να χρησιμοποιήσετε τη συνάρτηση [`repeat()`].
///
///
/// Ένας επαναληπτικός παράγοντας που παράγεται από το `repeat_with()` δεν είναι [`DoubleEndedIterator`].
/// Εάν χρειάζεστε `repeat_with()` για να επιστρέψετε ένα [`DoubleEndedIterator`], ανοίξτε ένα ζήτημα GitHub που εξηγεί την περίπτωση χρήσης σας.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Βασική χρήση:
///
/// ```
/// use std::iter;
///
/// // ας υποθέσουμε ότι έχουμε κάποια αξία ενός τύπου που δεν είναι `Clone` ή που δεν θέλουμε να έχουμε στη μνήμη ακόμα επειδή είναι ακριβό:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // μια συγκεκριμένη τιμή για πάντα:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Χρησιμοποιώντας τη μετάλλαξη και πηγαίνοντας πεπερασμένα:
///
/// ```rust
/// use std::iter;
///
/// // Από το μηδέν στην τρίτη δύναμη των δύο:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... και τώρα τελειώσαμε
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Επανάληψη που επαναλαμβάνει στοιχεία του τύπου `A` ατελείωτα εφαρμόζοντας το παρεχόμενο κλείσιμο `F: FnMut() -> A`.
///
///
/// Αυτό το `struct` δημιουργείται από τη συνάρτηση [`repeat_with()`].
/// Δείτε την τεκμηρίωσή του για περισσότερα.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}