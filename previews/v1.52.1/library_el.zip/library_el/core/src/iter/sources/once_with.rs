use crate::iter::{FusedIterator, TrustedLen};

/// Δημιουργεί έναν επαναληπτικό που παράγει τεμπέλα μια τιμή ακριβώς μία φορά επικαλούμενος το παρεχόμενο κλείσιμο.
///
/// Αυτό χρησιμοποιείται συνήθως για την προσαρμογή μιας γεννήτριας μίας αξίας σε [`chain()`] άλλων ειδών επανάληψης.
/// Ίσως έχετε έναν επαναληπτικό που να καλύπτει σχεδόν τα πάντα, αλλά χρειάζεστε μια επιπλέον ειδική περίπτωση.
/// Ίσως έχετε μια συνάρτηση που λειτουργεί σε επαναληπτικούς, αλλά χρειάζεται μόνο να επεξεργαστείτε μία τιμή.
///
/// Σε αντίθεση με το [`once()`], αυτή η λειτουργία θα δημιουργήσει τεμπέλης την τιμή κατόπιν αιτήματος.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Βασική χρήση:
///
/// ```
/// use std::iter;
///
/// // ένας είναι ο πιο μοναχικός αριθμός
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // μόνο ένα, το μόνο που έχουμε
/// assert_eq!(None, one.next());
/// ```
///
/// Αλυσίδα μαζί με έναν άλλο επαναληπτή.
/// Ας πούμε ότι θέλουμε να επαναλάβουμε κάθε αρχείο του καταλόγου `.foo`, αλλά και ένα αρχείο διαμόρφωσης,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // πρέπει να μετατρέψουμε από έναν επαναληπτή του DirEntry-s σε έναν επαναληπτή του PathBufs, οπότε χρησιμοποιούμε χάρτη
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // τώρα, ο επαναληπτής μας μόνο για το αρχείο ρυθμίσεων
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // αλυσίδα των δύο επαναληπτών μαζί σε ένα μεγάλο επαναληπτικό
/// let files = dirs.chain(config);
///
/// // Αυτό θα μας δώσει όλα τα αρχεία στο .foo καθώς και το .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Ένας επαναληπτής που αποδίδει ένα μόνο στοιχείο τύπου `A` εφαρμόζοντας το παρεχόμενο κλείσιμο `F: FnOnce() -> A`.
///
///
/// Αυτό το `struct` δημιουργείται από τη συνάρτηση [`once_with()`].
/// Δείτε την τεκμηρίωσή του για περισσότερα.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}