use crate::iter::{FusedIterator, TrustedLen};

/// Δημιουργεί έναν επαναληπτικό που αποδίδει ένα στοιχείο ακριβώς μία φορά.
///
/// Συνήθως χρησιμοποιείται για την προσαρμογή μιας μεμονωμένης τιμής σε [`chain()`] άλλων ειδών επανάληψης.
/// Ίσως έχετε έναν επαναληπτικό που να καλύπτει σχεδόν τα πάντα, αλλά χρειάζεστε μια επιπλέον ειδική περίπτωση.
/// Ίσως έχετε μια συνάρτηση που λειτουργεί σε επαναληπτικούς, αλλά χρειάζεται μόνο να επεξεργαστείτε μία τιμή.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Βασική χρήση:
///
/// ```
/// use std::iter;
///
/// // ένας είναι ο πιο μοναχικός αριθμός
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // μόνο ένα, το μόνο που έχουμε
/// assert_eq!(None, one.next());
/// ```
///
/// Αλυσίδα μαζί με έναν άλλο επαναληπτή.
/// Ας πούμε ότι θέλουμε να επαναλάβουμε κάθε αρχείο του καταλόγου `.foo`, αλλά και ένα αρχείο διαμόρφωσης,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // πρέπει να μετατρέψουμε από έναν επαναληπτή του DirEntry-s σε έναν επαναληπτή του PathBufs, οπότε χρησιμοποιούμε χάρτη
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // τώρα, ο επαναληπτής μας μόνο για το αρχείο ρυθμίσεων
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // αλυσίδα των δύο επαναληπτών μαζί σε ένα μεγάλο επαναληπτικό
/// let files = dirs.chain(config);
///
/// // Αυτό θα μας δώσει όλα τα αρχεία στο .foo καθώς και το .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Ένας επαναληπτής που αποδίδει ένα στοιχείο ακριβώς μία φορά.
///
/// Αυτό το `struct` δημιουργείται από τη συνάρτηση [`once()`].Δείτε την τεκμηρίωσή του για περισσότερα.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}