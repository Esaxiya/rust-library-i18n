use crate::iter::{FusedIterator, TrustedLen};

/// Δημιουργεί ένα νέο επαναληπτικό που επαναλαμβάνει ατέλειωτα ένα στοιχείο.
///
/// Η συνάρτηση `repeat()` επαναλαμβάνει μία μόνο τιμή ξανά και ξανά.
///
/// Απεριόριστα επαναληπτικά όπως το `repeat()` χρησιμοποιούνται συχνά με προσαρμογείς όπως το [`Iterator::take()`], για να τα καταστήσουν πεπερασμένα.
///
/// Εάν ο τύπος στοιχείου του επαναληπτικού που χρειάζεστε δεν εφαρμόζει το `Clone` ή εάν δεν θέλετε να διατηρήσετε το επαναλαμβανόμενο στοιχείο στη μνήμη, μπορείτε αντ 'αυτού να χρησιμοποιήσετε τη λειτουργία [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Βασική χρήση:
///
/// ```
/// use std::iter;
///
/// // το νούμερο τέσσερα 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // Ναι, ακόμα τέσσερα
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Πηγαίνοντας πεπερασμένα με [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // αυτό το τελευταίο παράδειγμα ήταν πάρα πολλά.Ας έχουμε μόνο τέσσερα τετράγωνα.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... και τώρα τελειώσαμε
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Επανάληψη που επαναλαμβάνει ένα στοιχείο ατελείωτα.
///
/// Αυτό το `struct` δημιουργείται από τη συνάρτηση [`repeat()`].Δείτε την τεκμηρίωσή του για περισσότερα.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}