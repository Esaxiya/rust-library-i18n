// ign-tidy-filelength Αυτό το αρχείο αποτελείται σχεδόν αποκλειστικά από τον ορισμό του `Iterator`.
// Δεν μπορούμε να το χωρίσουμε σε πολλά αρχεία.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Μια διεπαφή για την αντιμετώπιση των επαναληπτών.
///
/// Αυτό είναι το κύριο επαναληπτικό trait.
/// Για περισσότερες πληροφορίες σχετικά με την έννοια των επαναληπτών γενικά, ανατρέξτε στο [module-level documentation].
/// Συγκεκριμένα, ίσως θέλετε να μάθετε πώς να [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Ο τύπος των στοιχείων που επαναλαμβάνονται.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Προωθεί τον επαναληπτικό και επιστρέφει την επόμενη τιμή.
    ///
    /// Επιστρέφει το [`None`] όταν ολοκληρωθεί η επανάληψη.
    /// Οι μεμονωμένες υλοποιήσεις του iterator μπορούν να επιλέξουν να συνεχίσουν την επανάληψη και επομένως να καλέσετε ξανά το `next()` μπορεί ή να μην αρχίσει τελικά να επιστρέφει ξανά το [`Some(Item)`] σε κάποιο σημείο.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Μια κλήση στο next() επιστρέφει την επόμενη τιμή ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... και μετά Κανένας μόλις τελειώσει.
    /// assert_eq!(None, iter.next());
    ///
    /// // Περισσότερες κλήσεις μπορεί ή όχι να επιστρέψουν `None`.Εδώ, πάντα θα.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Επιστρέφει τα όρια στο υπόλοιπο μήκος του επαναληπτικού.
    ///
    /// Συγκεκριμένα, το `size_hint()` επιστρέφει μια πλειάδα όπου το πρώτο στοιχείο είναι το κατώτερο όριο και το δεύτερο στοιχείο είναι το ανώτερο όριο.
    ///
    /// Το δεύτερο μισό της πλειάδας που επιστρέφεται είναι ένα ["Option"] "<" ["usize"] ">".
    /// Ένα [`None`] εδώ σημαίνει ότι είτε δεν υπάρχει γνωστό άνω όριο, είτε το ανώτερο όριο είναι μεγαλύτερο από το [`usize`].
    ///
    /// # Σημειώσεις εφαρμογής
    ///
    /// Δεν επιβάλλεται ότι μια εφαρμογή επανάληψης αποδίδει τον δηλωμένο αριθμό στοιχείων.Ένας επαναληπτικός με λάθη μπορεί να αποδώσει λιγότερο από το κατώτερο όριο ή περισσότερο από το ανώτερο όριο των στοιχείων.
    ///
    /// `size_hint()` προορίζεται πρωτίστως να χρησιμοποιηθεί για βελτιστοποιήσεις, όπως η κράτηση χώρου για τα στοιχεία του επαναληπτικού, αλλά δεν πρέπει να είναι αξιόπιστο, για παράδειγμα, να παραλείπονται οριακοί έλεγχοι σε μη ασφαλή κώδικα.
    /// Η εσφαλμένη εφαρμογή του `size_hint()` δεν θα πρέπει να οδηγήσει σε παραβιάσεις της ασφάλειας της μνήμης.
    ///
    /// Τούτου λεχθέντος, η εφαρμογή θα πρέπει να παρέχει μια σωστή εκτίμηση, διότι διαφορετικά θα ήταν παραβίαση του πρωτοκόλλου του trait.
    ///
    /// Η προεπιλεγμένη εφαρμογή επιστρέφει "(0," [None "]") "που είναι σωστό για κάθε επαναληπτικό.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Ένα πιο περίπλοκο παράδειγμα:
    ///
    /// ```
    /// // Οι ζυγοί αριθμοί από μηδέν έως δέκα.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Μπορεί να επαναλαμβάνουμε από μηδέν έως δέκα φορές.
    /// // Γνωρίζοντας ότι είναι πέντε ακριβώς δεν θα ήταν δυνατό χωρίς την εκτέλεση του filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Ας προσθέσουμε πέντε ακόμη αριθμούς με το chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // Τώρα και τα δύο όρια αυξάνονται κατά πέντε
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Επιστροφή `None` για ανώτερο όριο:
    ///
    /// ```
    /// // ένα άπειρο επαναληπτικό δεν έχει ανώτερο όριο και το μέγιστο δυνατό κατώτερο όριο
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Καταναλώνει την επανάληψη, μετρά τον αριθμό των επαναλήψεων και επιστρέφει.
    ///
    /// Αυτή η μέθοδος θα καλέσει επανειλημμένα το [`next`] έως ότου συναντηθεί το [`None`], επιστρέφοντας τον αριθμό των φορών που είδε το [`Some`].
    /// Σημειώστε ότι το [`next`] πρέπει να κληθεί τουλάχιστον μία φορά ακόμη και αν ο επαναληπτής δεν έχει στοιχεία.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Συμπεριφορά υπερχείλισης
    ///
    /// Η μέθοδος δεν προστατεύει από υπερχείλιση, οπότε η μέτρηση στοιχείων ενός επαναληπτικού με περισσότερα από [`usize::MAX`] στοιχεία είτε παράγει λάθος αποτέλεσμα είτε panics.
    ///
    /// Εάν οι ισχυρισμοί εντοπισμού σφαλμάτων είναι ενεργοποιημένοι, ένα panic είναι εγγυημένο.
    ///
    /// # Panics
    ///
    /// Αυτή η συνάρτηση μπορεί να panic εάν ο επαναληπτής έχει περισσότερα από [`usize::MAX`] στοιχεία.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Καταναλώνει την επανάληψη, επιστρέφοντας το τελευταίο στοιχείο.
    ///
    /// Αυτή η μέθοδος θα αξιολογήσει τον επαναληπτή έως ότου επιστρέψει [`None`].
    /// Με αυτόν τον τρόπο, παρακολουθεί το τρέχον στοιχείο.
    /// Μετά την επιστροφή του [`None`], το `last()` θα επιστρέψει το τελευταίο στοιχείο που είδε.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Προωθεί την επανάληψη με στοιχεία `n`.
    ///
    /// Αυτή η μέθοδος θα παραλείψει με ανυπομονησία τα στοιχεία `n` καλώντας το [`next`] έως `n` φορές έως ότου συναντηθεί το [`None`].
    ///
    /// `advance_by(n)` θα επιστρέψει το [`Ok(())`][Ok] εάν ο επαναληπτής προχωρήσει επιτυχώς με στοιχεία `n` ή [`Err(k)`][Err] εάν συναντηθεί το [`None`], όπου το `k` είναι ο αριθμός των στοιχείων που προχωρά ο επαναληπτής πριν εξαντληθούν τα στοιχεία (π.χ.
    /// το μήκος της επανάληψης).
    /// Σημειώστε ότι το `k` είναι πάντα μικρότερο από `n`.
    ///
    /// Η κλήση του `advance_by(0)` δεν καταναλώνει στοιχεία και επιστρέφει πάντα το [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // παραλείφθηκε μόνο το `&4`
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Επιστρέφει το στοιχείο «n» του επαναληπτικού.
    ///
    /// Όπως και οι περισσότερες λειτουργίες ευρετηρίασης, η μέτρηση ξεκινά από το μηδέν, έτσι το `nth(0)` επιστρέφει την πρώτη τιμή, το `nth(1)` το δεύτερο και ούτω καθεξής.
    ///
    /// Σημειώστε ότι όλα τα προηγούμενα στοιχεία, καθώς και το επιστρεφόμενο στοιχείο, θα καταναλωθούν από την επανάληψη.
    /// Αυτό σημαίνει ότι τα προηγούμενα στοιχεία θα απορριφθούν και επίσης ότι η κλήση του `nth(0)` πολλές φορές στον ίδιο επαναληπτή θα επιστρέψει διαφορετικά στοιχεία.
    ///
    ///
    /// `nth()` θα επιστρέψει το [`None`] εάν το `n` είναι μεγαλύτερο ή ίσο με το μήκος του επαναληπτικού.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Η κλήση του `nth()` πολλές φορές δεν επαναφέρει τον επαναλήπτη:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Επιστροφή `None` εάν υπάρχουν λιγότερα από `n + 1` στοιχεία:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Δημιουργεί έναν επαναληπτικό ξεκινώντας από το ίδιο σημείο, αλλά προχωρώντας από το δεδομένο ποσό σε κάθε επανάληψη.
    ///
    /// Σημείωση 1: Το πρώτο στοιχείο του επαναληπτικού θα επιστρέφεται πάντα, ανεξάρτητα από το βήμα που έχει δοθεί.
    ///
    /// Σημείωση 2: Ο χρόνος κατά τον οποίο τραβούνται τα αγνοούμενα στοιχεία δεν είναι σταθερός.
    /// `StepBy` συμπεριφέρεται όπως η ακολουθία `next(), nth(step-1), nth(step-1),…`, αλλά είναι επίσης ελεύθερη να συμπεριφέρεται όπως η ακολουθία
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Ο τρόπος που χρησιμοποιείται μπορεί να αλλάξει για ορισμένους επαναληπτικούς λόγους για λόγους απόδοσης.
    /// Ο δεύτερος τρόπος θα προωθήσει τον επαναληπτή νωρίτερα και μπορεί να καταναλώσει περισσότερα στοιχεία.
    ///
    /// `advance_n_and_return_first` είναι το ισοδύναμο:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Η μέθοδος θα panic εάν το δεδομένο βήμα είναι `0`.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Παίρνει δύο επαναληπτικούς και δημιουργεί ένα νέο επαναληπτικό και στα δύο στη σειρά.
    ///
    /// `chain()` θα επιστρέψει έναν νέο επαναληπτικό που θα επαναλάβει πρώτα τις τιμές από τον πρώτο επαναληπτή και έπειτα πέρα από τις τιμές από τον δεύτερο επαναληπτικό.
    ///
    /// Με άλλα λόγια, συνδέει δύο επαναληπτές μεταξύ τους, σε μια αλυσίδα.🔗
    ///
    /// [`once`] χρησιμοποιείται συνήθως για την προσαρμογή μιας μεμονωμένης τιμής σε μια αλυσίδα άλλων ειδών επανάληψης.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Δεδομένου ότι το επιχείρημα για το `chain()` χρησιμοποιεί το [`IntoIterator`], μπορούμε να περάσουμε οτιδήποτε μπορεί να μετατραπεί σε [`Iterator`], όχι μόνο το ίδιο το [`Iterator`].
    /// Για παράδειγμα, οι φέτες (`&[T]`) υλοποιούν το [`IntoIterator`] και έτσι μπορούν να μεταδοθούν απευθείας στο `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Εάν εργάζεστε με το Windows API, ίσως θέλετε να μετατρέψετε το [`OsStr`] σε `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips up' δύο επαναληπτές σε ένα μόνο επαναληπτικό ζευγών.
    ///
    /// `zip()` επιστρέφει έναν νέο επαναληπτικό που θα επαναλάβει δύο άλλους επαναληπτικούς, επιστρέφοντας μια πλειάδα όπου το πρώτο στοιχείο προέρχεται από τον πρώτο επαναληπτή και το δεύτερο στοιχείο προέρχεται από το δεύτερο επαναληπτικό.
    ///
    ///
    /// Με άλλα λόγια, συνδέει δύο επαναλήπτες μαζί, σε ένα μόνο.
    ///
    /// Εάν ένας από τους επαναληπτές επιστρέψει [`None`], το [`next`] από τον επαναληπτικό με φερμουάρ θα επιστρέψει [`None`].
    /// Εάν ο πρώτος επαναληπτής επιστρέψει το [`None`], το `zip` θα βραχυκυκλώσει και το `next` δεν θα κληθεί στο δεύτερο επαναληπτικό.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Δεδομένου ότι το επιχείρημα για το `zip()` χρησιμοποιεί το [`IntoIterator`], μπορούμε να περάσουμε οτιδήποτε μπορεί να μετατραπεί σε [`Iterator`], όχι μόνο το ίδιο το [`Iterator`].
    /// Για παράδειγμα, οι φέτες (`&[T]`) υλοποιούν το [`IntoIterator`] και έτσι μπορούν να μεταδοθούν απευθείας στο `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` χρησιμοποιείται συχνά για να φερμουάρ ένα άπειρο επαναληπτικό σε ένα πεπερασμένο.
    /// Αυτό λειτουργεί επειδή το πεπερασμένο επαναληπτικό θα επιστρέψει τελικά το [`None`], τερματίζοντας το φερμουάρ.Το φερμουάρ με το `(0..)` μοιάζει πολύ με το [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Δημιουργεί ένα νέο επαναληπτικό που τοποθετεί ένα αντίγραφο `separator` μεταξύ παρακείμενων αντικειμένων του αρχικού επαναληπτικού.
    ///
    /// Σε περίπτωση που το `separator` δεν εφαρμόζει το [`Clone`] ή πρέπει να υπολογίζεται κάθε φορά, χρησιμοποιήστε το [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Το πρώτο στοιχείο από το `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ο διαχωριστής.
    /// assert_eq!(a.next(), Some(&1));   // Το επόμενο στοιχείο από το `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ο διαχωριστής.
    /// assert_eq!(a.next(), Some(&2));   // Το τελευταίο στοιχείο από το `a`.
    /// assert_eq!(a.next(), None);       // Ο επαναλήπτης έχει ολοκληρωθεί.
    /// ```
    ///
    /// `intersperse` μπορεί να είναι πολύ χρήσιμο να ενταχθούν σε αντικείμενα επαναληπτικού χρησιμοποιώντας ένα κοινό στοιχείο:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Δημιουργεί ένα νέο επαναληπτικό που τοποθετεί ένα στοιχείο που δημιουργείται από το `separator` μεταξύ γειτονικών στοιχείων του αρχικού επαναληπτικού.
    ///
    /// Το κλείσιμο θα καλείται ακριβώς μία φορά κάθε φορά που ένα αντικείμενο τοποθετείται μεταξύ δύο παρακείμενων αντικειμένων από τον υποκείμενο επαναληπτικό.
    /// Συγκεκριμένα, το κλείσιμο δεν καλείται εάν ο υποκείμενος επαναληπτής αποδίδει λιγότερα από δύο αντικείμενα και μετά την τελευταία παράδοση.
    ///
    ///
    /// Εάν το αντικείμενο του επαναληπτικού εφαρμόζει το [`Clone`], μπορεί να είναι ευκολότερο να χρησιμοποιήσετε το [`intersperse`].
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Το πρώτο στοιχείο από το `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ο διαχωριστής.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Το επόμενο στοιχείο από το `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ο διαχωριστής.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Το τελευταίο στοιχείο από το `v`.
    /// assert_eq!(it.next(), None);               // Ο επαναλήπτης έχει ολοκληρωθεί.
    /// ```
    ///
    /// `intersperse_with` μπορεί να χρησιμοποιηθεί σε καταστάσεις όπου ο διαχωριστής πρέπει να υπολογιστεί:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Το κλείσιμο δανείζεται μεταβλητά το περιβάλλον του για τη δημιουργία ενός αντικειμένου.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Παίρνει ένα κλείσιμο και δημιουργεί έναν επαναληπτικό που καλεί αυτό το κλείσιμο σε κάθε στοιχείο.
    ///
    /// `map()` μετατρέπει έναν επαναληπτικό σε έναν άλλο, μέσω του επιχειρήματός του:
    /// κάτι που εφαρμόζει το [`FnMut`].Παράγει ένα νέο επαναληπτικό που καλεί αυτό το κλείσιμο σε κάθε στοιχείο του αρχικού επαναληπτικού.
    ///
    /// Εάν είστε καλοί στο να σκέφτεστε σε τύπους, μπορείτε να σκεφτείτε το `map()` έτσι:
    /// Εάν έχετε έναν επαναληπτικό που σας δίνει στοιχεία κάποιου τύπου `A` και θέλετε μια επανάληψη κάποιου άλλου τύπου `B`, μπορείτε να χρησιμοποιήσετε το `map()`, περνώντας ένα κλείσιμο που παίρνει ένα `A` και επιστρέφει ένα `B`.
    ///
    ///
    /// `map()` είναι εννοιολογικά παρόμοιο με ένα βρόχο [`for`].Ωστόσο, καθώς το `map()` είναι τεμπέλης, χρησιμοποιείται καλύτερα όταν εργάζεστε ήδη με άλλους επαναληπτές.
    /// Εάν κάνετε κάποιο είδος βρόχου για παρενέργεια, θεωρείται πιο ιδιωματικό να χρησιμοποιείτε το [`for`] από το `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Εάν κάνετε κάποια παρενέργεια, προτιμήστε το [`for`] από το `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // μην το κάνεις αυτό:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // δεν θα εκτελεστεί καν, καθώς είναι τεμπέλης.Το Rust θα σας προειδοποιήσει για αυτό.
    ///
    /// // Αντ 'αυτού, χρησιμοποιήστε για:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Καλεί ένα κλείσιμο σε κάθε στοιχείο ενός επαναληπτικού.
    ///
    /// Αυτό ισοδυναμεί με τη χρήση βρόχου [`for`] στον επαναληπτικό, αν και τα `break` και `continue` δεν είναι δυνατά από το κλείσιμο.
    /// Είναι γενικά πιο ιδιωματική η χρήση βρόχου `for`, αλλά το `for_each` μπορεί να είναι πιο ευανάγνωστο κατά την επεξεργασία αντικειμένων στο τέλος των μακρύτερων αλυσίδων επαναληπτών.
    ///
    /// Σε ορισμένες περιπτώσεις, το `for_each` μπορεί επίσης να είναι πιο γρήγορο από ένα βρόχο, επειδή θα χρησιμοποιεί εσωτερική επανάληψη σε προσαρμογείς όπως το `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Για ένα τόσο μικρό παράδειγμα, ένας βρόχος `for` μπορεί να είναι καθαρότερος, αλλά το `for_each` μπορεί να είναι προτιμότερο να διατηρηθεί ένα λειτουργικό στυλ με μακρύτερους επαναληπτές:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Δημιουργεί έναν επαναληπτικό που χρησιμοποιεί ένα κλείσιμο για να προσδιορίσει εάν πρέπει να παραχθεί ένα στοιχείο.
    ///
    /// Δεδομένου ενός στοιχείου, το κλείσιμο πρέπει να επιστρέψει `true` ή `false`.Ο επαναλαμβανόμενος επαναληπτής θα αποδώσει μόνο τα στοιχεία για τα οποία το κλείσιμο επιστρέφει αληθές.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Επειδή το κλείσιμο που μεταβιβάστηκε στο `filter()` παίρνει μια αναφορά και πολλοί επαναληπτικοί επαναλαμβάνουν τις αναφορές, αυτό οδηγεί σε μια πιθανώς συγκεχυμένη κατάσταση, όπου ο τύπος του κλεισίματος είναι διπλή αναφορά:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // χρειάζεστε δύο * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Είναι συνηθισμένο να χρησιμοποιείτε το destructuring στο επιχείρημα για να αφαιρέσετε ένα:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // και τα δύο και *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ή και τα δύο:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // δύο &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// αυτών των επιπέδων.
    ///
    /// Σημειώστε ότι το `iter.filter(f).next()` είναι ισοδύναμο με το `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Δημιουργεί έναν επαναληπτικό που φιλτράρει και χάρτες.
    ///
    /// Ο επαναλαμβανόμενος επαναληπτής αποδίδει μόνο την «τιμή» για την οποία το παρεχόμενο κλείσιμο επιστρέφει `Some(value)`.
    ///
    /// `filter_map` μπορεί να χρησιμοποιηθεί για να κάνει τις αλυσίδες των [`filter`] και [`map`] πιο συνοπτικές.
    /// Το παρακάτω παράδειγμα δείχνει πώς ένα `map().filter().map()` μπορεί να συντομευτεί σε μία κλήση στο `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Εδώ είναι το ίδιο παράδειγμα, αλλά με [`filter`] και [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Δημιουργεί έναν επαναληπτικό που δίνει τον τρέχοντα αριθμό επαναλήψεων καθώς και την επόμενη τιμή.
    ///
    /// Ο επαναληπτικός παράγοντας αποδίδει ζεύγη `(i, val)`, όπου το `i` είναι ο τρέχων δείκτης επανάληψης και το `val` είναι η τιμή που επιστρέφεται από τον επαναληπτή.
    ///
    ///
    /// `enumerate()` διατηρεί τον αριθμό του ως [`usize`].
    /// Εάν θέλετε να μετρήσετε με ακέραιο διαφορετικό μέγεθος, η συνάρτηση [`zip`] παρέχει παρόμοια λειτουργικότητα.
    ///
    /// # Συμπεριφορά υπερχείλισης
    ///
    /// Η μέθοδος δεν προστατεύει από υπερχείλιση, οπότε η απαρίθμηση περισσότερων από [`usize::MAX`] στοιχείων είτε παράγει λάθος αποτέλεσμα είτε panics.
    /// Εάν οι ισχυρισμοί εντοπισμού σφαλμάτων είναι ενεργοποιημένοι, ένα panic είναι εγγυημένο.
    ///
    /// # Panics
    ///
    /// Ο επαναλαμβανόμενος επαναληπτής ενδέχεται να panic εάν ο δείκτης προς επιστροφή θα υπερέβαινε ένα [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Δημιουργεί έναν επαναληπτικό που μπορεί να χρησιμοποιήσει το [`peek`] για να δει το επόμενο στοιχείο του επαναληπτικού χωρίς να το καταναλώσει.
    ///
    /// Προσθέτει μια μέθοδο [`peek`] σε έναν επαναληπτικό.Δείτε την τεκμηρίωσή του για περισσότερες πληροφορίες.
    ///
    /// Σημειώστε ότι ο υποκείμενος επαναληπτής εξακολουθεί να είναι προχωρημένος όταν καλείται για πρώτη φορά το [`peek`]: Για να ανακτήσετε το επόμενο στοιχείο, το [`next`] καλείται στον υποκείμενο επαναληπτικό, επομένως τυχόν παρενέργειες (π.χ.
    ///
    /// θα συμβεί οτιδήποτε άλλο εκτός από την ανάκτηση της επόμενης τιμής) της μεθόδου [`next`].
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ας δούμε το future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // μπορούμε peek() πολλές φορές, ο επαναληπτικός δεν θα προχωρήσει
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // μετά την ολοκλήρωση του επαναληπτικού, το ίδιο ισχύει και για το peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Δημιουργεί έναν επαναληπτικό που [`skip`] τα στοιχεία βασίζονται σε ένα predicate.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` παίρνει ένα κλείσιμο ως επιχείρημα.Θα καλέσει αυτό το κλείσιμο σε κάθε στοιχείο της επανάληψης και θα αγνοήσει τα στοιχεία μέχρι να επιστρέψει το `false`.
    ///
    /// Μετά την επιστροφή του `false`, η εργασία `skip_while()`'s έχει τελειώσει και τα υπόλοιπα στοιχεία παράγονται.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Επειδή το κλείσιμο που μεταβιβάστηκε στο `skip_while()` παίρνει μια αναφορά και πολλοί επαναληπτικοί επαναλαμβάνουν τις αναφορές, αυτό οδηγεί σε μια πιθανώς συγκεχυμένη κατάσταση, όπου ο τύπος του ορίσματος κλεισίματος είναι διπλή αναφορά:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // χρειάζεστε δύο * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Διακοπή μετά από ένα αρχικό `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // ενώ αυτό θα ήταν ψευδές, δεδομένου ότι έχουμε ήδη λάθος, το skip_while() δεν χρησιμοποιείται πλέον
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Δημιουργεί έναν επαναληπτικό που αποδίδει στοιχεία βάσει ενός κατηγορήματος.
    ///
    /// `take_while()` παίρνει ένα κλείσιμο ως επιχείρημα.Θα ονομάσει αυτό το κλείσιμο σε κάθε στοιχείο της επανάληψης και θα αποδώσει στοιχεία ενώ επιστρέφει `true`.
    ///
    /// Μετά την επιστροφή του `false`, η εργασία `take_while()`'s τελείωσε και τα υπόλοιπα στοιχεία αγνοούνται.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Επειδή το κλείσιμο που μεταβιβάστηκε στο `take_while()` παίρνει μια αναφορά και πολλοί επαναληπτικοί επαναλαμβάνουν τις αναφορές, αυτό οδηγεί σε μια πιθανώς συγκεχυμένη κατάσταση, όπου ο τύπος του κλεισίματος είναι διπλή αναφορά:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // χρειάζεστε δύο * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Διακοπή μετά από ένα αρχικό `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Έχουμε περισσότερα στοιχεία που είναι μικρότερα από το μηδέν, αλλά επειδή έχουμε ήδη ένα ψεύτικο, το take_while() δεν χρησιμοποιείται πλέον
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Επειδή το `take_while()` πρέπει να εξετάσει την τιμή για να δει εάν πρέπει να συμπεριληφθεί ή όχι, οι καταναλωτές που θα επαναλάβουν την κατανάλωση θα δουν ότι έχει αφαιρεθεί:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Το `3` δεν είναι πλέον εκεί, επειδή καταναλώθηκε για να δει αν η επανάληψη πρέπει να σταματήσει, αλλά δεν τοποθετήθηκε ξανά στον επαναληπτή.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Δημιουργεί έναν επαναληπτικό που παράγει και τα δύο στοιχεία βασισμένα σε ένα κατηγορηματικό και χάρτες.
    ///
    /// `map_while()` παίρνει ένα κλείσιμο ως επιχείρημα.
    /// Θα ονομάσει αυτό το κλείσιμο σε κάθε στοιχείο της επανάληψης και θα αποδώσει στοιχεία ενώ επιστρέφει [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Εδώ είναι το ίδιο παράδειγμα, αλλά με [`take_while`] και [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Διακοπή μετά από ένα αρχικό [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Έχουμε περισσότερα στοιχεία που θα μπορούσαν να χωρέσουν στο u32 (4, 5), αλλά το `map_while` επέστρεψε το `None` για το `-3` (όπως το `predicate` επέστρεψε το `None`) και το `collect` σταματά στο πρώτο `None`.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Επειδή το `map_while()` πρέπει να εξετάσει την τιμή για να δει εάν πρέπει να συμπεριληφθεί ή όχι, οι καταναλωτές που θα επαναλάβουν την κατανάλωση θα δουν ότι έχει αφαιρεθεί:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Το `-3` δεν είναι πλέον εκεί, επειδή καταναλώθηκε για να δει αν η επανάληψη πρέπει να σταματήσει, αλλά δεν τοποθετήθηκε ξανά στον επαναληπτή.
    ///
    /// Λάβετε υπόψη ότι σε αντίθεση με το [`take_while`], αυτός ο επαναληπτής δεν είναι ** συγχωνευμένος.
    /// Επίσης, δεν καθορίζεται τι επιστρέφει αυτός ο επαναληπτικός μετά την επιστροφή του πρώτου [`None`].
    /// Εάν χρειάζεστε επαναλαμβανόμενο συνδυασμό, χρησιμοποιήστε το [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Δημιουργεί έναν επαναληπτικό που παραλείπει τα πρώτα στοιχεία `n`.
    ///
    /// Αφού καταναλωθούν, τα υπόλοιπα στοιχεία παράγονται.
    /// Αντί να παρακάμψετε αυτήν τη μέθοδο απευθείας, αντί να παρακάμψετε τη μέθοδο `nth`.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Δημιουργεί έναν επαναληπτικό που αποδίδει τα πρώτα του στοιχεία `n`.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` χρησιμοποιείται συχνά με έναν άπειρο επαναληπτικό, για να το κάνει πεπερασμένο:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Εάν υπάρχουν λιγότερα από `n` στοιχεία, το `take` θα περιοριστεί στο μέγεθος του υποκείμενου επαναληπτικού:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Ένας επαναληπτικός προσαρμογέας παρόμοιος με το [`fold`] που διατηρεί εσωτερική κατάσταση και παράγει ένα νέο επαναληπτικό.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` παίρνει δύο ορίσματα: μια αρχική τιμή που δημιουργεί την εσωτερική κατάσταση και ένα κλείσιμο με δύο ορίσματα, το πρώτο είναι μια μεταβλητή αναφορά στην εσωτερική κατάσταση και το δεύτερο ένα στοιχείο επαναληπτικής.
    ///
    /// Το κλείσιμο μπορεί να εκχωρήσει στην εσωτερική κατάσταση για κοινή χρήση μεταξύ επαναλήψεων.
    ///
    /// Κατά την επανάληψη, το κλείσιμο θα εφαρμοστεί σε κάθε στοιχείο της επανάληψης και η τιμή επιστροφής από το κλείσιμο, ένα [`Option`], θα αποδίδεται από τον επαναληπτή.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // κάθε επανάληψη, πολλαπλασιάζουμε την κατάσταση με το στοιχείο
    ///     *state = *state * x;
    ///
    ///     // τότε, θα αποδώσουμε την άρνηση του κράτους
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Δημιουργεί έναν επαναληπτικό που λειτουργεί σαν χάρτης, αλλά ισοπεδώνει την ένθετη δομή.
    ///
    /// Ο προσαρμογέας [`map`] είναι πολύ χρήσιμος, αλλά μόνο όταν το όρισμα κλεισίματος παράγει τιμές.
    /// Αν παράγει ένα επαναληπτικό αντίθετο, υπάρχει ένα επιπλέον επίπεδο έμμεσης.
    /// `flat_map()` θα αφαιρέσει αυτό το επιπλέον στρώμα από μόνο του.
    ///
    /// Μπορείτε να σκεφτείτε το `flat_map(f)` ως το σημασιολογικό ισοδύναμο του [`map`] ping και, στη συνέχεια, το [« flatten »] όπως στο `map(f).flatten()`.
    ///
    /// Ένας άλλος τρόπος σκέψης για το `flat_map()`: Το κλείσιμο του ["map"] επιστρέφει ένα στοιχείο για κάθε στοιχείο και το κλείσιμο `flat_map()`'s επιστρέφει έναν επαναληπτικό για κάθε στοιχείο.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() επιστρέφει έναν επαναληπτικό
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Δημιουργεί έναν επαναληπτικό που ισοπεδώνει την ένθετη δομή.
    ///
    /// Αυτό είναι χρήσιμο όταν έχετε έναν επαναληπτικό επαναληπτών ή έναν επαναληπτικό πραγμάτων που μπορούν να μετατραπούν σε επαναληπτικούς και θέλετε να καταργήσετε ένα επίπεδο έμμεσης.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Χαρτογράφηση και στη συνέχεια ισοπέδωση:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() επιστρέφει έναν επαναληπτικό
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Μπορείτε επίσης να το ξαναγράψετε σε όρους [`flat_map()`], το οποίο είναι προτιμότερο σε αυτήν την περίπτωση, δεδομένου ότι μεταφέρει την πρόθεση με μεγαλύτερη σαφήνεια:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() επιστρέφει έναν επαναληπτικό
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Η ισοπέδωση αφαιρεί μόνο ένα επίπεδο ένθεσης κάθε φορά:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Εδώ βλέπουμε ότι το `flatten()` δεν εκτελεί ισοπέδωση "deep".
    /// Αντ 'αυτού, καταργείται μόνο ένα επίπεδο ένθεσης.Δηλαδή, αν έχετε `flatten()` μια τρισδιάστατη συστοιχία, το αποτέλεσμα θα είναι δισδιάστατο και όχι μονοδιάστατο.
    /// Για να αποκτήσετε μια μονοδιάστατη δομή, πρέπει να πάρετε ξανά το `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Δημιουργεί έναν επαναληπτικό που τελειώνει μετά το πρώτο [`None`].
    ///
    /// Αφού ο επαναληπτής επιστρέψει [`None`], οι κλήσεις future ενδέχεται να αποδώσουν ξανά ή όχι [`Some(T)`].
    /// `fuse()` προσαρμόζει έναν επαναληπτικό, διασφαλίζοντας ότι μετά τη χορήγηση ενός [`None`], θα επιστρέφει πάντα το [`None`] για πάντα.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// // έναν επαναληπτικό που εναλλάσσεται μεταξύ ορισμένων και Κανένας
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // αν είναι ακόμη, Some(i32), αλλιώς Κανένα
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // μπορούμε να δούμε τον επαναληπτικό μας να πηγαίνει μπρος-πίσω
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // Ωστόσο, μόλις το συντήξουμε ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // θα επιστρέφει πάντα το `None` μετά την πρώτη φορά.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Κάνει κάτι με κάθε στοιχείο ενός επαναληπτικού, μεταβιβάζοντας την τιμή.
    ///
    /// Κατά τη χρήση επαναληπτικών, συχνά συνδέετε πολλά από αυτά μαζί.
    /// Ενώ εργάζεστε σε έναν τέτοιο κώδικα, ίσως θελήσετε να δείτε τι συμβαίνει σε διάφορα μέρη του αγωγού.Για να το κάνετε αυτό, εισαγάγετε μια κλήση στο `inspect()`.
    ///
    /// Είναι πιο συνηθισμένο το `inspect()` να χρησιμοποιείται ως εργαλείο εντοπισμού σφαλμάτων από το να υπάρχει στον τελικό σας κώδικα, αλλά οι εφαρμογές μπορεί να το βρίσκουν χρήσιμο σε ορισμένες περιπτώσεις, όταν πρέπει να καταγραφούν σφάλματα πριν από την απόρριψή τους.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // αυτή η επαναληπτική ακολουθία είναι περίπλοκη.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // ας προσθέσουμε μερικές κλήσεις inspect() για να διερευνήσουμε τι συμβαίνει
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Αυτό θα εκτυπώσει:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Σφάλματα καταγραφής πριν από την απόρριψή τους:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Αυτό θα εκτυπώσει:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Δανείζεται έναν επαναληπτικό, αντί να το καταναλώνει.
    ///
    /// Αυτό είναι χρήσιμο για να επιτρέψετε την εφαρμογή προσαρμογέα επαναληπτικού προγράμματος διατηρώντας ταυτόχρονα την ιδιοκτησία του αρχικού επαναληπτικού.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // αν προσπαθήσουμε να το χρησιμοποιήσουμε ξανά, δεν θα λειτουργήσει.
    /// // Η ακόλουθη γραμμή δίνει "σφάλμα: χρήση μετακινημένης τιμής: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // ας το δοκιμάσουμε ξανά
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Αντ 'αυτού, προσθέτουμε ένα .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // τώρα είναι μια χαρά:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Μετατρέπει έναν επαναληπτικό σε μια συλλογή.
    ///
    /// `collect()` μπορεί να πάρει οτιδήποτε επαναλαμβάνεται και να το μετατρέψει σε σχετική συλλογή.
    /// Αυτή είναι μια από τις πιο ισχυρές μεθόδους της τυπικής βιβλιοθήκης, που χρησιμοποιείται σε διάφορα περιβάλλοντα.
    ///
    /// Το πιο βασικό μοτίβο στο οποίο χρησιμοποιείται το `collect()` είναι να μετατρέψετε μια συλλογή σε άλλη.
    /// Παίρνετε μια συλλογή, καλέστε το [`iter`] σε αυτήν, κάνετε μια δέσμη μετασχηματισμών και, στη συνέχεια, το `collect()` στο τέλος.
    ///
    /// `collect()` μπορεί επίσης να δημιουργήσει παρουσίες τύπων που δεν είναι τυπικές συλλογές.
    /// Για παράδειγμα, ένα [`String`] μπορεί να δημιουργηθεί από [`char`] s και ένας επαναληπτικός χαρακτήρας των [`Result<T, E>`][`Result`] στοιχείων μπορεί να συλλεχθεί σε `Result<Collection<T>, E>`.
    ///
    /// Δείτε τα παρακάτω παραδείγματα για περισσότερα.
    ///
    /// Επειδή το `collect()` είναι τόσο γενικό, μπορεί να προκαλέσει προβλήματα με την εξαγωγή τύπου.
    /// Ως εκ τούτου, το `collect()` είναι μία από τις λίγες φορές που θα δείτε τη σύνταξη γνωστή ως 'turbofish': `::<>`.
    /// Αυτό βοηθά τον αλγόριθμο συμπερασμάτων να κατανοήσει συγκεκριμένα σε ποια συλλογή προσπαθείτε να συλλέξετε.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Σημειώστε ότι χρειαζόμασταν το `: Vec<i32>` στην αριστερή πλευρά.Αυτό συμβαίνει επειδή θα μπορούσαμε να συλλέξουμε, για παράδειγμα, ένα [`VecDeque<T>`] αντί:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Χρησιμοποιώντας το 'turbofish' αντί για σχολιασμό `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Επειδή το `collect()` ενδιαφέρεται μόνο για αυτό που συλλέγετε, μπορείτε ακόμα να χρησιμοποιήσετε μια υπόδειξη μερικού τύπου, `_`, με το turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Χρησιμοποιώντας το `collect()` για να δημιουργήσετε ένα [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Εάν έχετε μια λίστα με [Αποτέλεσμα<T, E>"][" Αποτέλεσμα "], μπορείτε να χρησιμοποιήσετε το `collect()` για να δείτε εάν κάποιο από αυτά απέτυχε:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // μας δίνει το πρώτο σφάλμα
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // μας δίνει τον κατάλογο των απαντήσεων
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Καταναλώνει έναν επαναληπτικό, δημιουργώντας δύο συλλογές από αυτό.
    ///
    /// Το υπόθετο που μεταβιβάστηκε στο `partition()` μπορεί να επιστρέψει `true` ή `false`.
    /// `partition()` επιστρέφει ένα ζεύγος, όλα τα στοιχεία για τα οποία επέστρεψε `true` και όλα τα στοιχεία για τα οποία επέστρεψε `false`.
    ///
    ///
    /// Δείτε επίσης [`is_partitioned()`] και [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Αναδιατάσσει τα στοιχεία αυτού του επαναληπτικού *στη θέση του* σύμφωνα με τη δεδομένη κατηγορία, έτσι ώστε όλα αυτά που επιστρέφουν `true` να προηγούνται όλων εκείνων που επιστρέφουν `false`.
    ///
    /// Επιστρέφει τον αριθμό των στοιχείων `true` που βρέθηκαν.
    ///
    /// Η σχετική σειρά των κατατμημένων στοιχείων δεν διατηρείται.
    ///
    /// Δείτε επίσης [`is_partitioned()`] και [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Διαχωρισμός στη θέση μεταξύ των αποτελεσμάτων και των αποδόσεων
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: πρέπει να ανησυχούμε για την καταμέτρηση του αριθμού;Ο μόνος τρόπος για να έχετε περισσότερα από
        // `usize::MAX` μεταβλητές αναφορές είναι με ZST, τα οποία δεν είναι χρήσιμα για το διαμέρισμα ...

        // Αυτές οι λειτουργίες κλεισίματος "factory" υπάρχουν για την αποφυγή γενικότητας στο `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Βρείτε επανειλημμένα το πρώτο `false` και ανταλλάξτε το με το τελευταίο `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Ελέγχει εάν τα στοιχεία αυτού του επαναληπτικού διαχωρίζονται σύμφωνα με τη δεδομένη κατηγορία, έτσι ώστε όλα αυτά που επιστρέφουν `true` να προηγούνται όλων εκείνων που επιστρέφουν `false`.
    ///
    ///
    /// Δείτε επίσης [`partition()`] και [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Είτε όλα τα στοιχεία δοκιμάζουν το `true`, είτε η πρώτη ρήτρα σταματά στο `false` και ελέγχουμε ότι δεν υπάρχουν πλέον αντικείμενα `true` μετά από αυτό.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Μια επαναληπτική μέθοδος που εφαρμόζει μια συνάρτηση εφ 'όσον επιστρέφει με επιτυχία, παράγοντας μία, τελική τιμή.
    ///
    /// `try_fold()` παίρνει δύο ορίσματα: μια αρχική τιμή και ένα κλείσιμο με δύο ορίσματα: ένα 'accumulator' και ένα στοιχείο.
    /// Το κλείσιμο είτε επιστρέφει επιτυχώς, με την τιμή που πρέπει να έχει ο συσσωρευτής για την επόμενη επανάληψη, ή επιστρέφει αποτυχία, με μια τιμή σφάλματος που μεταδίδεται πίσω στον καλούντα αμέσως (short-circuiting).
    ///
    ///
    /// Η αρχική τιμή είναι η τιμή που θα έχει ο συσσωρευτής στην πρώτη κλήση.Εάν εφαρμόσετε το κλείσιμο με επιτυχία σε κάθε στοιχείο του επαναληπτικού, το `try_fold()` επιστρέφει τον τελικό συσσωρευτή ως επιτυχία.
    ///
    /// Το δίπλωμα είναι χρήσιμο κάθε φορά που έχετε μια συλλογή από κάτι και θέλετε να δημιουργήσετε μία μόνο τιμή από αυτό.
    ///
    /// # Σημείωση για τους εκτελεστές
    ///
    /// Αρκετές από τις άλλες μεθόδους (forward) έχουν προεπιλεγμένες εφαρμογές σε σχέση με αυτήν, οπότε προσπαθήστε να την εφαρμόσετε ρητά εάν μπορεί να κάνει κάτι καλύτερο από την προεπιλεγμένη εφαρμογή βρόχου `for`.
    ///
    /// Συγκεκριμένα, προσπαθήστε να πραγματοποιήσετε αυτήν την κλήση `try_fold()` στα εσωτερικά μέρη από τα οποία συντίθεται αυτός ο επαναληπτής.
    /// Εάν απαιτούνται πολλές κλήσεις, ο χειριστής `?` μπορεί να είναι βολικός για την αλυσίδα της τιμής συσσωρευτή, αλλά προσέξτε τυχόν αναλλοίωτα που πρέπει να διατηρηθούν πριν από αυτές τις πρώτες επιστροφές.
    /// Αυτή είναι μια μέθοδος `&mut self`, οπότε η επανάληψη πρέπει να επαναληφθεί αφού εμφανιστεί ένα σφάλμα εδώ.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // το επιλεγμένο άθροισμα όλων των στοιχείων του πίνακα
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Αυτό το άθροισμα ξεχειλίζει κατά την προσθήκη του στοιχείου 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Επειδή βραχυκυκλώθηκε, τα υπόλοιπα στοιχεία εξακολουθούν να είναι διαθέσιμα μέσω της επανάληψης.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Μια μέθοδος επανάληψης που εφαρμόζει μια πλάνη συνάρτησης σε κάθε στοιχείο του επαναληπτικού, σταματώντας στο πρώτο σφάλμα και επιστρέφοντας αυτό το σφάλμα.
    ///
    ///
    /// Αυτό μπορεί επίσης να θεωρηθεί ως η πλάνη του [`for_each()`] ή ως η απάτριδα έκδοση του [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Βραχυκύκλωσε, οπότε τα υπόλοιπα αντικείμενα βρίσκονται ακόμη στο επαναληπτικό:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Διπλώνει κάθε στοιχείο σε έναν συσσωρευτή εφαρμόζοντας μια λειτουργία, επιστρέφοντας το τελικό αποτέλεσμα.
    ///
    /// `fold()` παίρνει δύο ορίσματα: μια αρχική τιμή και ένα κλείσιμο με δύο ορίσματα: ένα 'accumulator' και ένα στοιχείο.
    /// Το κλείσιμο επιστρέφει την τιμή που πρέπει να έχει ο συσσωρευτής για την επόμενη επανάληψη.
    ///
    /// Η αρχική τιμή είναι η τιμή που θα έχει ο συσσωρευτής στην πρώτη κλήση.
    ///
    /// Μετά την εφαρμογή αυτού του κλεισίματος σε κάθε στοιχείο του επαναληπτικού, το `fold()` επιστρέφει τον συσσωρευτή.
    ///
    /// Αυτή η λειτουργία ονομάζεται μερικές φορές 'reduce' ή 'inject'.
    ///
    /// Το δίπλωμα είναι χρήσιμο κάθε φορά που έχετε μια συλλογή από κάτι και θέλετε να δημιουργήσετε μία μόνο τιμή από αυτό.
    ///
    /// Note: Το `fold()` και παρόμοιες μέθοδοι που διασχίζουν ολόκληρο τον επαναληπτικό, ενδέχεται να μην τερματιστούν για άπειρες επαναλήψεις, ακόμη και σε traits για τα οποία το αποτέλεσμα είναι καθορισμένο σε πεπερασμένο χρόνο.
    ///
    /// Note: Το [`reduce()`] μπορεί να χρησιμοποιηθεί για τη χρήση του πρώτου στοιχείου ως αρχικής τιμής, εάν ο τύπος συσσωρευτή και ο τύπος στοιχείου είναι ίδιοι.
    ///
    /// # Σημείωση για τους εκτελεστές
    ///
    /// Αρκετές από τις άλλες μεθόδους (forward) έχουν προεπιλεγμένες εφαρμογές σε σχέση με αυτήν, οπότε προσπαθήστε να την εφαρμόσετε ρητά εάν μπορεί να κάνει κάτι καλύτερο από την προεπιλεγμένη εφαρμογή βρόχου `for`.
    ///
    ///
    /// Συγκεκριμένα, προσπαθήστε να πραγματοποιήσετε αυτήν την κλήση `fold()` στα εσωτερικά μέρη από τα οποία συντίθεται αυτός ο επαναληπτής.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // το άθροισμα όλων των στοιχείων του πίνακα
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ας ακολουθήσουμε κάθε βήμα της επανάληψης εδώ:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Και έτσι, το τελικό μας αποτέλεσμα, `6`.
    ///
    /// Είναι συνηθισμένο για άτομα που δεν έχουν χρησιμοποιήσει πολλές επαναλήψεις να χρησιμοποιούν βρόχο `for` με μια λίστα πραγμάτων για τη δημιουργία ενός αποτελέσματος.Αυτά μπορούν να μετατραπούν σε `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // για βρόχο:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // είναι τα ίδια
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Μειώνει τα στοιχεία σε ένα, εφαρμόζοντας επανειλημμένα μια λειτουργία μείωσης.
    ///
    /// Εάν ο επαναληπτής είναι κενός, επιστρέφει [`None`].Διαφορετικά, επιστρέφει το αποτέλεσμα της μείωσης.
    ///
    /// Για επαναληπτικούς με τουλάχιστον ένα στοιχείο, αυτό είναι το ίδιο με το [`fold()`] με το πρώτο στοιχείο του επαναληπτικού με την αρχική τιμή, αναδιπλώνοντας κάθε επόμενο στοιχείο σε αυτό.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Βρείτε τη μέγιστη τιμή:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Ελέγχει εάν κάθε στοιχείο του επαναληπτικού ταιριάζει με ένα υπόθετο.
    ///
    /// `all()` παίρνει ένα κλείσιμο που επιστρέφει `true` ή `false`.Εφαρμόζει αυτό το κλείσιμο σε κάθε στοιχείο του επαναληπτικού προγράμματος και αν όλα επιστρέφουν `true`, τότε το ίδιο ισχύει και για το `all()`.
    /// Εάν κάποιο από αυτά επιστρέψει `false`, επιστρέφει `false`.
    ///
    /// `all()` είναι βραχυκύκλωμα.Με άλλα λόγια, θα σταματήσει την επεξεργασία μόλις βρει `false`, δεδομένου ότι ανεξάρτητα από το τι άλλο συμβαίνει, το αποτέλεσμα θα είναι επίσης `false`.
    ///
    ///
    /// Ένας άδειος επαναληπτής επιστρέφει `true`.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Διακοπή στο πρώτο `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // μπορούμε ακόμα να χρησιμοποιήσουμε το `iter`, καθώς υπάρχουν περισσότερα στοιχεία.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Ελέγχει εάν οποιοδήποτε στοιχείο του επαναληπτικού ταιριάζει με ένα υπόθετο.
    ///
    /// `any()` παίρνει ένα κλείσιμο που επιστρέφει `true` ή `false`.Εφαρμόζει αυτό το κλείσιμο σε κάθε στοιχείο της επανάληψης, και αν κάποιο από αυτά επιστρέφει `true`, τότε το ίδιο ισχύει και για το `any()`.
    /// Εάν επιστρέψουν όλοι `false`, επιστρέφει `false`.
    ///
    /// `any()` είναι βραχυκύκλωμα.Με άλλα λόγια, θα σταματήσει την επεξεργασία μόλις βρει ένα `true`, δεδομένου ότι ανεξάρτητα από το τι άλλο συμβαίνει, το αποτέλεσμα θα είναι επίσης `true`.
    ///
    ///
    /// Ένας άδειος επαναληπτής επιστρέφει `false`.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Διακοπή στο πρώτο `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // μπορούμε ακόμα να χρησιμοποιήσουμε το `iter`, καθώς υπάρχουν περισσότερα στοιχεία.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Αναζητά ένα στοιχείο επαναληπτικού που ικανοποιεί ένα κατηγορηματικό.
    ///
    /// `find()` παίρνει ένα κλείσιμο που επιστρέφει `true` ή `false`.
    /// Εφαρμόζει αυτό το κλείσιμο σε κάθε στοιχείο του επαναληπτικού προγράμματος και αν κάποιο από αυτά επιστρέφει `true`, τότε το `find()` επιστρέφει το [`Some(element)`].
    /// Εάν επιστρέψουν όλοι `false`, επιστρέφει [`None`].
    ///
    /// `find()` είναι βραχυκύκλωμα.Με άλλα λόγια, θα σταματήσει την επεξεργασία μόλις το κλείσιμο επιστρέψει `true`.
    ///
    /// Επειδή το `find()` παίρνει μια αναφορά και πολλοί επαναληπτικοί επαναλαμβάνουν τις αναφορές, αυτό οδηγεί σε μια πιθανώς συγκεχυμένη κατάσταση όπου το επιχείρημα είναι διπλή αναφορά.
    ///
    /// Μπορείτε να δείτε αυτό το εφέ στα παρακάτω παραδείγματα, με το `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Διακοπή στο πρώτο `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // μπορούμε ακόμα να χρησιμοποιήσουμε το `iter`, καθώς υπάρχουν περισσότερα στοιχεία.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Σημειώστε ότι το `iter.find(f)` είναι ισοδύναμο με το `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Εφαρμόζει τη λειτουργία στα στοιχεία του επαναληπτικού και επιστρέφει το πρώτο μη μηδενικό αποτέλεσμα.
    ///
    ///
    /// `iter.find_map(f)` είναι ισοδύναμο με `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Εφαρμόζει τη λειτουργία στα στοιχεία του επαναληπτικού και επιστρέφει το πρώτο πραγματικό αποτέλεσμα ή το πρώτο σφάλμα.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Αναζητά ένα στοιχείο σε έναν επαναληπτικό, επιστρέφοντας το ευρετήριό του.
    ///
    /// `position()` παίρνει ένα κλείσιμο που επιστρέφει `true` ή `false`.
    /// Εφαρμόζει αυτό το κλείσιμο σε κάθε στοιχείο της επανάληψης και εάν ένα από αυτά επιστρέφει `true`, τότε το `position()` επιστρέφει [`Some(index)`].
    /// Εάν όλοι επιστρέψουν `false`, επιστρέφει [`None`].
    ///
    /// `position()` είναι βραχυκύκλωμα.Με άλλα λόγια, θα σταματήσει την επεξεργασία μόλις βρει `true`.
    ///
    /// # Συμπεριφορά υπερχείλισης
    ///
    /// Η μέθοδος δεν προστατεύει από υπερχείλιση, οπότε αν υπάρχουν περισσότερα από [`usize::MAX`] στοιχεία που δεν ταιριάζουν, είτε παράγει λάθος αποτέλεσμα είτε panics.
    ///
    /// Εάν οι ισχυρισμοί εντοπισμού σφαλμάτων είναι ενεργοποιημένοι, ένα panic είναι εγγυημένο.
    ///
    /// # Panics
    ///
    /// Αυτή η συνάρτηση ενδέχεται να panic εάν ο επαναληπτής έχει περισσότερα από `usize::MAX` στοιχεία που δεν ταιριάζουν.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Διακοπή στο πρώτο `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // μπορούμε ακόμα να χρησιμοποιήσουμε το `iter`, καθώς υπάρχουν περισσότερα στοιχεία.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Το επιστρεφόμενο ευρετήριο εξαρτάται από την κατάσταση επαναλήψεων
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Αναζητά ένα στοιχείο σε έναν επαναληπτικό από τα δεξιά, επιστρέφοντας το ευρετήριό του.
    ///
    /// `rposition()` παίρνει ένα κλείσιμο που επιστρέφει `true` ή `false`.
    /// Εφαρμόζει αυτό το κλείσιμο σε κάθε στοιχείο του επαναληπτικού, ξεκινώντας από το τέλος και εάν ένα από αυτά επιστρέφει `true`, τότε το `rposition()` επιστρέφει [`Some(index)`].
    ///
    /// Εάν όλοι επιστρέψουν `false`, επιστρέφει [`None`].
    ///
    /// `rposition()` είναι βραχυκύκλωμα.Με άλλα λόγια, θα σταματήσει την επεξεργασία μόλις βρει `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Διακοπή στο πρώτο `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // μπορούμε ακόμα να χρησιμοποιήσουμε το `iter`, καθώς υπάρχουν περισσότερα στοιχεία.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Δεν χρειάζεται έλεγχος υπερχείλισης εδώ, επειδή το `ExactSizeIterator` σημαίνει ότι ο αριθμός των στοιχείων ταιριάζει σε ένα `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Επιστρέφει το μέγιστο στοιχείο ενός επαναληπτικού.
    ///
    /// Εάν πολλά στοιχεία είναι εξίσου μέγιστα, επιστρέφεται το τελευταίο στοιχείο.
    /// Εάν ο επαναληπτής είναι κενός, επιστρέφεται το [`None`].
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Επιστρέφει το ελάχιστο στοιχείο ενός επαναληπτικού.
    ///
    /// Εάν πολλά στοιχεία είναι εξίσου ελάχιστα, επιστρέφεται το πρώτο στοιχείο.
    /// Εάν ο επαναληπτής είναι κενός, επιστρέφεται το [`None`].
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Επιστρέφει το στοιχείο που δίνει τη μέγιστη τιμή από την καθορισμένη συνάρτηση.
    ///
    ///
    /// Εάν πολλά στοιχεία είναι εξίσου μέγιστα, επιστρέφεται το τελευταίο στοιχείο.
    /// Εάν ο επαναληπτής είναι κενός, επιστρέφεται το [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Επιστρέφει το στοιχείο που δίνει τη μέγιστη τιμή σε σχέση με την καθορισμένη συνάρτηση σύγκρισης.
    ///
    ///
    /// Εάν πολλά στοιχεία είναι εξίσου μέγιστα, επιστρέφεται το τελευταίο στοιχείο.
    /// Εάν ο επαναληπτής είναι κενός, επιστρέφεται το [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Επιστρέφει το στοιχείο που δίνει την ελάχιστη τιμή από την καθορισμένη συνάρτηση.
    ///
    ///
    /// Εάν πολλά στοιχεία είναι εξίσου ελάχιστα, επιστρέφεται το πρώτο στοιχείο.
    /// Εάν ο επαναληπτής είναι κενός, επιστρέφεται το [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Επιστρέφει το στοιχείο που δίνει την ελάχιστη τιμή σε σχέση με την καθορισμένη συνάρτηση σύγκρισης.
    ///
    ///
    /// Εάν πολλά στοιχεία είναι εξίσου ελάχιστα, επιστρέφεται το πρώτο στοιχείο.
    /// Εάν ο επαναληπτής είναι κενός, επιστρέφεται το [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Αντιστρέφει την επανάληψη της κατεύθυνσης.
    ///
    /// Συνήθως, επαναλαμβάνονται από αριστερά προς τα δεξιά.
    /// Μετά τη χρήση του `rev()`, ένας επαναληπτής θα επαναλάβει από δεξιά προς τα αριστερά.
    ///
    /// Αυτό είναι δυνατό μόνο εάν ο επαναληπτής έχει τέλος, οπότε το `rev()` λειτουργεί μόνο σε ["DoubleEndedIterator"] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Μετατρέπει έναν επαναληπτικό ζεύγη σε ένα ζευγάρι κοντέινερ.
    ///
    /// `unzip()` καταναλώνει έναν ολόκληρο επαναλήπτη ζευγών, παράγοντας δύο συλλογές: μία από τα αριστερά στοιχεία των ζευγαριών και μία από τα σωστά στοιχεία.
    ///
    ///
    /// Αυτή η λειτουργία είναι, κατά κάποιον τρόπο, το αντίθετο του [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Δημιουργεί έναν επαναληπτικό που αντιγράφει όλα τα στοιχεία του.
    ///
    /// Αυτό είναι χρήσιμο όταν έχετε έναν επαναληπτικό πάνω από `&T`, αλλά χρειάζεστε έναν επαναληπτικό πάνω από `T`.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // αντιγράφεται το ίδιο με το .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Δημιουργεί έναν επαναληπτικό που ["κλωνοποιεί"] όλα τα στοιχεία του.
    ///
    /// Αυτό είναι χρήσιμο όταν έχετε έναν επαναληπτικό πάνω από `&T`, αλλά χρειάζεστε έναν επαναληπτικό πάνω από `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // Το κλωνοποιημένο είναι το ίδιο με το .map(|&x| x), για ακέραιους αριθμούς
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Επαναλαμβάνει έναν επαναληπτικό ατελείωτα.
    ///
    /// Αντί να σταματήσει στο [`None`], ο επαναληπτής θα ξεκινήσει από την αρχή.Μετά την επανάληψη, θα ξεκινήσει ξανά στην αρχή.Και ξανα.
    /// Και ξανα.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Αθροίζει τα στοιχεία ενός επαναληπτικού.
    ///
    /// Λαμβάνει κάθε στοιχείο, τα προσθέτει μαζί και επιστρέφει το αποτέλεσμα.
    ///
    /// Ένα κενό επαναληπτικό επιστρέφει τη μηδενική τιμή του τύπου.
    ///
    /// # Panics
    ///
    /// Όταν καλείτε το `sum()` και έναν πρωτόγονο ακέραιο τύπο επιστρέφεται, αυτή η μέθοδος θα panic εάν είναι ενεργοποιημένη η υπερχείλιση υπολογισμού και οι εντολές εντοπισμού σφαλμάτων.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Επαναλαμβάνεται σε ολόκληρο τον επαναληπτικό, πολλαπλασιάζοντας όλα τα στοιχεία
    ///
    /// Ένας κενός επαναληπτής επιστρέφει τη μία τιμή του τύπου.
    ///
    /// # Panics
    ///
    /// Όταν καλείτε το `product()` και έναν πρωτόγονο ακέραιο τύπο επιστρέφεται, η μέθοδος θα panic εάν είναι ενεργοποιημένες οι υπολογισμοί υπερχείλιση και οι εντολές εντοπισμού σφαλμάτων.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) συγκρίνει τα στοιχεία αυτού του [`Iterator`] με εκείνα ενός άλλου.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) συγκρίνει τα στοιχεία αυτού του [`Iterator`] με εκείνα ενός άλλου σε σχέση με την καθορισμένη λειτουργία σύγκρισης.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) συγκρίνει τα στοιχεία αυτού του [`Iterator`] με εκείνα ενός άλλου.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) συγκρίνει τα στοιχεία αυτού του [`Iterator`] με εκείνα ενός άλλου σε σχέση με την καθορισμένη λειτουργία σύγκρισης.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Καθορίζει εάν τα στοιχεία αυτού του [`Iterator`] είναι ίδια με αυτά ενός άλλου.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Καθορίζει εάν τα στοιχεία αυτού του [`Iterator`] είναι ίδια με εκείνα ενός άλλου σε σχέση με την καθορισμένη συνάρτηση ισότητας.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Καθορίζει εάν τα στοιχεία αυτού του [`Iterator`] είναι άνισα με εκείνα ενός άλλου.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Καθορίζει εάν τα στοιχεία αυτού του [`Iterator`] είναι [lexicographically](Ord#lexicographical-comparison) λιγότερο από εκείνα ενός άλλου.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Καθορίζει εάν τα στοιχεία αυτού του [`Iterator`] είναι [lexicographically](Ord#lexicographical-comparison) μικρότερα ή ίδια με αυτά ενός άλλου.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Καθορίζει εάν τα στοιχεία αυτού του [`Iterator`] είναι [lexicographically](Ord#lexicographical-comparison) μεγαλύτερα από εκείνα ενός άλλου.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Καθορίζει εάν τα στοιχεία αυτού του [`Iterator`] είναι [lexicographically](Ord#lexicographical-comparison) μεγαλύτερα από ή ίδια με εκείνα ενός άλλου.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Ελέγχει εάν τα στοιχεία αυτού του επαναληπτικού έχουν ταξινομηθεί.
    ///
    /// Δηλαδή, για κάθε στοιχείο `a` και το ακόλουθο στοιχείο `b`, το `a <= b` πρέπει να διατηρείται.Εάν ο επαναληπτής αποδίδει ακριβώς μηδέν ή ένα στοιχείο, επιστρέφεται το `true`.
    ///
    /// Σημειώστε ότι εάν το `Self::Item` είναι μόνο `PartialOrd`, αλλά όχι το `Ord`, ο παραπάνω ορισμός υπονοεί ότι αυτή η συνάρτηση επιστρέφει το `false` εάν δύο διαδοχικά στοιχεία δεν είναι συγκρίσιμα.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Ελέγχει εάν τα στοιχεία αυτού του επαναληπτικού ταξινομούνται χρησιμοποιώντας τη δεδομένη συνάρτηση σύγκρισης.
    ///
    /// Αντί να χρησιμοποιεί το `PartialOrd::partial_cmp`, αυτή η συνάρτηση χρησιμοποιεί τη δεδομένη συνάρτηση `compare` για να καθορίσει τη σειρά δύο στοιχείων.
    /// Εκτός από αυτό, είναι ισοδύναμο με [`is_sorted`].δείτε την τεκμηρίωσή του για περισσότερες πληροφορίες.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Ελέγχει εάν τα στοιχεία αυτού του επαναληπτικού ταξινομούνται χρησιμοποιώντας τη δεδομένη συνάρτηση εξαγωγής κλειδιού.
    ///
    /// Αντί να συγκρίνει τα στοιχεία του επαναληπτή απευθείας, αυτή η συνάρτηση συγκρίνει τα πλήκτρα των στοιχείων, όπως καθορίζεται από το `f`.
    /// Εκτός από αυτό, είναι ισοδύναμο με [`is_sorted`].δείτε την τεκμηρίωσή του για περισσότερες πληροφορίες.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Βλέπε [TrustedRandomAccess]
    // Το ασυνήθιστο όνομα είναι να αποφευχθούν συγκρούσεις ονομάτων στην ανάλυση μεθόδου βλέπε #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}