/// Μετατροπή από [`Iterator`].
///
/// Εφαρμόζοντας το `FromIterator` για έναν τύπο, καθορίζετε πώς θα δημιουργηθεί από έναν επαναληπτικό.
/// Αυτό είναι κοινό για τύπους που περιγράφουν μια συλλογή κάποιου είδους.
///
/// [`FromIterator::from_iter()`] καλείται σπάνια ρητά και αντ 'αυτού χρησιμοποιείται μέσω της μεθόδου [`Iterator::collect()`].
///
/// Δείτε την τεκμηρίωση [`Iterator::collect()`]'s για περισσότερα παραδείγματα.
///
/// Δείτε επίσης: [`IntoIterator`].
///
/// # Examples
///
/// Βασική χρήση:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Χρησιμοποιώντας το [`Iterator::collect()`] για έμμεση χρήση του `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Υλοποίηση `FromIterator` για τον τύπο σας:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Μια συλλογή δειγμάτων, που είναι απλώς ένα περιτύλιγμα πάνω από το Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ας δώσουμε μερικές μεθόδους, ώστε να μπορούμε να δημιουργήσουμε μία και να προσθέσουμε πράγματα σε αυτό.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // και θα εφαρμόσουμε το FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Τώρα μπορούμε να κάνουμε ένα νέο επαναληπτικό ...
/// let iter = (0..5).into_iter();
///
/// // ... και δημιουργήστε ένα MyCollection από αυτό
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // συλλέξτε έργα επίσης!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Δημιουργεί μια τιμή από έναν επαναληπτή.
    ///
    /// Δείτε το [module-level documentation] για περισσότερα.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Μετατροπή σε [`Iterator`].
///
/// Εφαρμόζοντας το `IntoIterator` για έναν τύπο, καθορίζετε πώς θα μετατραπεί σε επαναληπτικό.
/// Αυτό είναι κοινό για τύπους που περιγράφουν μια συλλογή κάποιου είδους.
///
/// Ένα πλεονέκτημα της εφαρμογής του `IntoIterator` είναι ότι ο τύπος σας θα [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Δείτε επίσης: [`FromIterator`].
///
/// # Examples
///
/// Βασική χρήση:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Υλοποίηση `IntoIterator` για τον τύπο σας:
///
/// ```
/// // Μια συλλογή δειγμάτων, που είναι απλώς ένα περιτύλιγμα πάνω από το Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ας δώσουμε μερικές μεθόδους, ώστε να μπορούμε να δημιουργήσουμε μία και να προσθέσουμε πράγματα σε αυτό.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // και θα εφαρμόσουμε το IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Τώρα μπορούμε να κάνουμε μια νέα συλλογή ...
/// let mut c = MyCollection::new();
///
/// // ... προσθέστε κάποια πράγματα σε αυτό ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... και μετά να το μετατρέψουμε σε Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Είναι κοινό να χρησιμοποιείτε το `IntoIterator` ως trait bound.Αυτό επιτρέπει στον τύπο συλλογής εισόδου να αλλάξει, εφόσον εξακολουθεί να είναι επαναληπτικός.
/// Πρόσθετα όρια μπορούν να καθοριστούν περιορίζοντας την
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Ο τύπος των στοιχείων που επαναλαμβάνονται.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Σε ποιο είδος επανάληψης το μετατρέπουμε σε αυτό;
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Δημιουργεί έναν επαναληπτικό από μια τιμή.
    ///
    /// Δείτε το [module-level documentation] για περισσότερα.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Επεκτείνετε μια συλλογή με τα περιεχόμενα ενός επαναληπτικού.
///
/// Οι επαναληπτές παράγουν μια σειρά τιμών και οι συλλογές μπορούν επίσης να θεωρηθούν ως μια σειρά τιμών.
/// Το `Extend` trait γεφυρώνει αυτό το κενό, επιτρέποντάς σας να επεκτείνετε μια συλλογή συμπεριλαμβάνοντας τα περιεχόμενα αυτού του επαναληπτικού.
/// Κατά την επέκταση μιας συλλογής με ένα ήδη υπάρχον κλειδί, αυτή η καταχώρηση ενημερώνεται ή, στην περίπτωση συλλογών που επιτρέπουν πολλές καταχωρίσεις με ίσα κλειδιά, εισάγεται αυτή η καταχώριση.
///
///
/// # Examples
///
/// Βασική χρήση:
///
/// ```
/// // Μπορείτε να επεκτείνετε μια συμβολοσειρά με μερικούς χαρακτήρες:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Εφαρμογή `Extend`:
///
/// ```
/// // Μια συλλογή δειγμάτων, που είναι απλώς ένα περιτύλιγμα πάνω από το Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ας δώσουμε μερικές μεθόδους, ώστε να μπορούμε να δημιουργήσουμε μία και να προσθέσουμε πράγματα σε αυτό.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // δεδομένου ότι το MyCollection έχει μια λίστα i32s, εφαρμόζουμε το Extend for i32
/// impl Extend<i32> for MyCollection {
///
///     // Αυτό είναι λίγο πιο απλό με την υπογραφή τύπου σκυροδέματος: μπορούμε να καλέσουμε επέκταση σε οτιδήποτε μπορεί να μετατραπεί σε Iterator που μας δίνει i32s.
///     // Επειδή χρειαζόμαστε i32s για να βάλουμε στο MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Η υλοποίηση είναι πολύ απλή: μεταβείτε στον επαναληπτικό και add() κάθε στοιχείο στους εαυτούς μας.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // ας επεκτείνουμε τη συλλογή μας με τρεις ακόμη αριθμούς
/// c.extend(vec![1, 2, 3]);
///
/// // έχουμε προσθέσει αυτά τα στοιχεία στο τέλος
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Επεκτείνει μια συλλογή με τα περιεχόμενα ενός επαναληπτικού.
    ///
    /// Δεδομένου ότι αυτή είναι η μόνη απαιτούμενη μέθοδος για αυτό το trait, τα έγγραφα [trait-level] περιέχουν περισσότερες λεπτομέρειες.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// // Μπορείτε να επεκτείνετε μια συμβολοσειρά με μερικούς χαρακτήρες:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Επεκτείνει μια συλλογή με ακριβώς ένα στοιχείο.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Διατηρεί χωρητικότητα σε μια συλλογή για τον δεδομένο αριθμό πρόσθετων στοιχείων.
    ///
    /// Η προεπιλεγμένη εφαρμογή δεν κάνει τίποτα.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}