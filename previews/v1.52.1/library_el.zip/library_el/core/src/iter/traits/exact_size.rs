/// Επανάληψη που γνωρίζει το ακριβές μήκος του.
///
/// Πολλοί [«Iterator»] δεν ξέρουν πόσες φορές θα επαναλάβουν, αλλά κάποιες.
/// Εάν ένας επαναληπτής γνωρίζει πόσες φορές μπορεί να επαναλάβει, η παροχή πρόσβασης σε αυτές τις πληροφορίες μπορεί να είναι χρήσιμη.
/// Για παράδειγμα, εάν θέλετε να επαναλάβετε προς τα πίσω, μια καλή αρχή είναι να μάθετε πού είναι το τέλος.
///
/// Κατά την εφαρμογή ενός `ExactSizeIterator`, πρέπει επίσης να εφαρμόσετε το [`Iterator`].
/// Όταν το κάνετε αυτό, η εφαρμογή του [`Iterator::size_hint`]*πρέπει* να επιστρέψει το ακριβές μέγεθος της επανάληψης.
///
/// Η μέθοδος [`len`] έχει μια προεπιλεγμένη εφαρμογή, επομένως συνήθως δεν πρέπει να την εφαρμόσετε.
/// Ωστόσο, ενδέχεται να μπορείτε να παρέχετε μια πιο αποτελεσματική εφαρμογή από την προεπιλογή, επομένως η παράκαμψή της σε αυτήν την περίπτωση έχει νόημα.
///
///
/// Σημειώστε ότι αυτό το trait είναι ένα ασφαλές trait και ως τέτοιο *δεν* και *δεν μπορεί* να εγγυηθεί ότι το επιστρεφόμενο μήκος είναι σωστό.
/// Αυτό σημαίνει ότι ο κωδικός `unsafe`**δεν πρέπει** να βασίζεται στην ορθότητα του [`Iterator::size_hint`].
/// Το ασταθές και μη ασφαλές [`TrustedLen`](super::marker::TrustedLen) trait παρέχει αυτήν την πρόσθετη εγγύηση.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Βασική χρήση:
///
/// ```
/// // ένα πεπερασμένο εύρος ξέρει ακριβώς πόσες φορές θα επαναληφθεί
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Στο [module-level docs], εφαρμόσαμε ένα [`Iterator`], `Counter`.
/// Ας εφαρμόσουμε επίσης το `ExactSizeIterator`:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Μπορούμε εύκολα να υπολογίσουμε τον υπόλοιπο αριθμό επαναλήψεων.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Και τώρα μπορούμε να το χρησιμοποιήσουμε!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Επιστρέφει το ακριβές μήκος του επαναληπτικού.
    ///
    /// Η εφαρμογή διασφαλίζει ότι ο επαναληπτής θα επιστρέψει ακριβώς `len()` περισσότερες φορές μια τιμή [`Some(T)`], πριν επιστρέψει το [`None`].
    ///
    /// Αυτή η μέθοδος έχει μια προεπιλεγμένη εφαρμογή, επομένως συνήθως δεν πρέπει να την εφαρμόσετε απευθείας.
    /// Ωστόσο, εάν μπορείτε να παρέχετε μια πιο αποτελεσματική εφαρμογή, μπορείτε να το κάνετε.
    /// Δείτε τα έγγραφα [trait-level] για παράδειγμα.
    ///
    /// Αυτή η λειτουργία έχει τις ίδιες εγγυήσεις ασφαλείας με τη λειτουργία [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// // ένα πεπερασμένο εύρος ξέρει ακριβώς πόσες φορές θα επαναληφθεί
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Αυτός ο ισχυρισμός είναι υπερβολικά αμυντικός, αλλά ελέγχει το αμετάβλητο
        // εγγυημένη από το trait.
        // Εάν αυτό το trait ήταν rust-εσωτερικό, θα μπορούσαμε να χρησιμοποιήσουμε το debug_assert !;διαβεβαιώστε_eq!θα ελέγξει και όλες τις εφαρμογές χρήστη Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Επιστρέφει `true` εάν ο επαναληπτής είναι κενός.
    ///
    /// Αυτή η μέθοδος έχει μια προεπιλεγμένη εφαρμογή χρησιμοποιώντας το [`ExactSizeIterator::len()`], επομένως δεν χρειάζεται να την εφαρμόσετε μόνοι σας.
    ///
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}