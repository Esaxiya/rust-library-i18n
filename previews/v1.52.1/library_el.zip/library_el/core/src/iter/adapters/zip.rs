use crate::cmp;
use crate::fmt::{self, Debug};
use crate::iter::{DoubleEndedIterator, ExactSizeIterator, FusedIterator, Iterator};
use crate::iter::{InPlaceIterable, SourceIter, TrustedLen};

/// Επανάληψη που επαναλαμβάνει δύο άλλους επαναλήπτες ταυτόχρονα.
///
/// Αυτό το `struct` δημιουργήθηκε από το [`Iterator::zip`].
/// Δείτε την τεκμηρίωσή του για περισσότερα.
#[derive(Clone)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Zip<A, B> {
    a: A,
    b: B,
    // index, len και a_len χρησιμοποιούνται μόνο από την εξειδικευμένη έκδοση του zip
    index: usize,
    len: usize,
    a_len: usize,
}
impl<A: Iterator, B: Iterator> Zip<A, B> {
    pub(in crate::iter) fn new(a: A, b: B) -> Zip<A, B> {
        ZipImpl::new(a, b)
    }
    fn super_nth(&mut self, mut n: usize) -> Option<(A::Item, B::Item)> {
        while let Some(x) = Iterator::next(self) {
            if n == 0 {
                return Some(x);
            }
            n -= 1;
        }
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> Iterator for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        ZipImpl::next(self)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        ZipImpl::size_hint(self)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        ZipImpl::nth(self, n)
    }

    #[inline]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        // ΑΣΦΑΛΕΙΑ: Το `ZipImpl::__iterator_get_unchecked` έχει την ίδια ασφάλεια
        // απαιτήσεις ως `Iterator::__iterator_get_unchecked`.
        unsafe { ZipImpl::get_unchecked(self, idx) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> DoubleEndedIterator for Zip<A, B>
where
    A: DoubleEndedIterator + ExactSizeIterator,
    B: DoubleEndedIterator + ExactSizeIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)> {
        ZipImpl::next_back(self)
    }
}

// Zip εξειδίκευση trait
#[doc(hidden)]
trait ZipImpl<A, B> {
    type Item;
    fn new(a: A, b: B) -> Self;
    fn next(&mut self) -> Option<Self::Item>;
    fn size_hint(&self) -> (usize, Option<usize>);
    fn nth(&mut self, n: usize) -> Option<Self::Item>;
    fn next_back(&mut self) -> Option<Self::Item>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator;
    // Αυτό έχει τις ίδιες απαιτήσεις ασφαλείας με το `Iterator::__iterator_get_unchecked`
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item
    where
        Self: Iterator + TrustedRandomAccess;
}

// Στρατηγός Zip impl
#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);
    default fn new(a: A, b: B) -> Self {
        Zip {
            a,
            b,
            index: 0, // unused
            len: 0,   // unused
            a_len: 0, // unused
        }
    }

    #[inline]
    default fn next(&mut self) -> Option<(A::Item, B::Item)> {
        let x = self.a.next()?;
        let y = self.b.next()?;
        Some((x, y))
    }

    #[inline]
    default fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.super_nth(n)
    }

    #[inline]
    default fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        let a_sz = self.a.len();
        let b_sz = self.b.len();
        if a_sz != b_sz {
            // Ρυθμίστε a, b στο ίδιο μήκος
            if a_sz > b_sz {
                for _ in 0..a_sz - b_sz {
                    self.a.next_back();
                }
            } else {
                for _ in 0..b_sz - a_sz {
                    self.b.next_back();
                }
            }
        }
        match (self.a.next_back(), self.b.next_back()) {
            (Some(x), Some(y)) => Some((x, y)),
            (None, None) => None,
            _ => unreachable!(),
        }
    }

    #[inline]
    default fn size_hint(&self) -> (usize, Option<usize>) {
        let (a_lower, a_upper) = self.a.size_hint();
        let (b_lower, b_upper) = self.b.size_hint();

        let lower = cmp::min(a_lower, b_lower);

        let upper = match (a_upper, b_upper) {
            (Some(x), Some(y)) => Some(cmp::min(x, y)),
            (Some(x), None) => Some(x),
            (None, Some(y)) => Some(y),
            (None, None) => None,
        };

        (lower, upper)
    }

    default unsafe fn get_unchecked(&mut self, _idx: usize) -> <Self as Iterator>::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: TrustedRandomAccess + Iterator,
    B: TrustedRandomAccess + Iterator,
{
    fn new(a: A, b: B) -> Self {
        let a_len = a.size();
        let len = cmp::min(a_len, b.size());
        Zip { a, b, index: 0, len, a_len }
    }

    #[inline]
    fn next(&mut self) -> Option<(A::Item, B::Item)> {
        if self.index < self.len {
            let i = self.index;
            self.index += 1;
            // ΑΣΦΑΛΕΙΑ: Το `i` είναι μικρότερο από το `self.len`, επομένως μικρότερο από το `self.a.len()` και το `self.b.len()`
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else if A::MAY_HAVE_SIDE_EFFECT && self.index < self.a_len {
            let i = self.index;
            self.index += 1;
            self.len += 1;
            // ταιριάζει με τις πιθανές παρενέργειες της βάσης ΑΣΦΑΛΕΙΑ: μόλις ελέγξαμε ότι `i` <`self.a.len()`
            //
            unsafe {
                self.a.__iterator_get_unchecked(i);
            }
            None
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len - self.index;
        (len, Some(len))
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let delta = cmp::min(n, self.len - self.index);
        let end = self.index + delta;
        while self.index < end {
            let i = self.index;
            self.index += 1;
            if A::MAY_HAVE_SIDE_EFFECT {
                // ΑΣΦΑΛΕΙΑ: η χρήση του `cmp::min` για τον υπολογισμό του `delta`
                // διασφαλίζει ότι το `end` είναι μικρότερο ή ίσο με το `self.len`, επομένως το `i` είναι επίσης μικρότερο από το `self.len`.
                //
                unsafe {
                    self.a.__iterator_get_unchecked(i);
                }
            }
            if B::MAY_HAVE_SIDE_EFFECT {
                // ΑΣΦΑΛΕΙΑ: όπως και παραπάνω.
                unsafe {
                    self.b.__iterator_get_unchecked(i);
                }
            }
        }

        self.super_nth(n - delta)
    }

    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        if A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT {
            let sz_a = self.a.size();
            let sz_b = self.b.size();
            // Προσαρμόστε το a, b στο ίδιο μήκος, βεβαιωθείτε ότι μόνο η πρώτη κλήση του `next_back` το κάνει, διαφορετικά θα παραβλέψουμε τον περιορισμό των κλήσεων στο `self.next_back()` μετά την κλήση του `get_unchecked()`.
            //
            //
            if sz_a != sz_b {
                let sz_a = self.a.size();
                if A::MAY_HAVE_SIDE_EFFECT && sz_a > self.len {
                    for _ in 0..sz_a - self.len {
                        self.a.next_back();
                    }
                    self.a_len = self.len;
                }
                let sz_b = self.b.size();
                if B::MAY_HAVE_SIDE_EFFECT && sz_b > self.len {
                    for _ in 0..sz_b - self.len {
                        self.b.next_back();
                    }
                }
            }
        }
        if self.index < self.len {
            self.len -= 1;
            self.a_len -= 1;
            let i = self.len;
            // ΑΣΦΑΛΕΙΑ: Το `i` είναι μικρότερο από την προηγούμενη τιμή του `self.len`,
            // που είναι επίσης μικρότερο ή ίσο με `self.a.len()` και `self.b.len()`
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else {
            None
        }
    }

    #[inline]
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item {
        let idx = self.index + idx;
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να τηρήσει το συμβόλαιο για το `Iterator::__iterator_get_unchecked`.
        //
        unsafe { (self.a.__iterator_get_unchecked(idx), self.b.__iterator_get_unchecked(idx)) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> ExactSizeIterator for Zip<A, B>
where
    A: ExactSizeIterator,
    B: ExactSizeIterator,
{
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<A, B> TrustedRandomAccess for Zip<A, B>
where
    A: TrustedRandomAccess,
    B: TrustedRandomAccess,
{
    const MAY_HAVE_SIDE_EFFECT: bool = A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT;
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A, B> FusedIterator for Zip<A, B>
where
    A: FusedIterator,
    B: FusedIterator,
{
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, B> TrustedLen for Zip<A, B>
where
    A: TrustedLen,
    B: TrustedLen,
{
}

// Επιλέγει αυθαίρετα την αριστερή πλευρά της επανάληψης φερμουάρ ως εξαγώγιμο "source" θα απαιτούσε αρνητικό trait bounds για να μπορεί να δοκιμάσει και τα δύο
//
#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S, A, B> SourceIter for Zip<A, B>
where
    A: SourceIter<Source = S>,
    B: Iterator,
    S: Iterator,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // ΑΣΦΑΛΕΙΑ: προώθηση μη ασφαλούς λειτουργίας σε μη ασφαλή λειτουργία με τις ίδιες απαιτήσεις
        unsafe { SourceIter::as_inner(&mut self.a) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
// Περιορίζεται σε στοιχείο: Αντιγραφή, καθώς η αλληλεπίδραση μεταξύ της χρήσης του TrustedRandomAccess και της εφαρμογής Drop από την πηγή είναι ασαφής.
//
// Μια πρόσθετη μέθοδος που επιστρέφει τον αριθμό των φορών που η πηγή έχει προχωρήσει λογικά (χωρίς να χρειαστεί να καλέσετε το next()), θα χρειαστεί να πέσετε σωστά το υπόλοιπο της πηγής.
//
//
unsafe impl<A: InPlaceIterable, B: Iterator> InPlaceIterable for Zip<A, B> where A::Item: Copy {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Debug, B: Debug> Debug for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        ZipFmt::fmt(self, f)
    }
}

trait ZipFmt<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result;
}

impl<A: Debug, B: Debug> ZipFmt<A, B> for Zip<A, B> {
    default fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Zip").field("a", &self.a).field("b", &self.b).finish()
    }
}

impl<A: Debug + TrustedRandomAccess, B: Debug + TrustedRandomAccess> ZipFmt<A, B> for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // *Δεν είναι ασφαλές* να καλέσετε το fmt στα περιεχόμενα επαναληπτικά, αφού μόλις ξεκινήσουμε να επαναλαμβάνουμε, βρίσκονται σε περίεργες, δυνητικά μη ασφαλείς, καταστάσεις.
        //
        f.debug_struct("Zip").finish()
    }
}

/// Ένας επαναληπτής του οποίου τα αντικείμενα είναι τυχαία προσβάσιμα αποτελεσματικά
///
/// # Safety
///
/// Το επαναληπτικό `size_hint` πρέπει να είναι ακριβές και φθηνό για κλήση.
///
/// `size` μπορεί να μην παρακαμφθεί.
///
/// `<Self as Iterator>::__iterator_get_unchecked` πρέπει να είναι ασφαλές να καλέσετε υπό τον όρο ότι πληρούνται οι ακόλουθες προϋποθέσεις
///
/// 1. `0 <= idx` και `idx < self.size()`.
/// 2. Εάν `self: !Clone`, τότε το `get_unchecked` δεν καλείται ποτέ με το ίδιο ευρετήριο στο `self` περισσότερες από μία φορές.
/// 3. Μετά την κλήση του `self.get_unchecked(idx)` τότε το `next_back` θα κληθεί μόνο το πολύ `self.size() - idx - 1` φορές.
/// 4. Μετά την κλήση του `get_unchecked`, τότε θα απαιτηθούν μόνο οι ακόλουθες μέθοδοι στο `self`:
///     * `std::clone::Clone::clone()`
///     * `std::iter::Iterator::size_hint()`
///     * `std::iter::Iterator::next_back()`
///     * `std::iter::Iterator::__iterator_get_unchecked()`
///     * `std::iter::TrustedRandomAccess::size()`
///
/// Επιπλέον, δεδομένου ότι πληρούνται αυτές οι προϋποθέσεις, πρέπει να εγγυηθεί ότι:
///
/// * Δεν αλλάζει την τιμή που επιστρέφεται από το `size_hint`
/// * Πρέπει να είναι ασφαλές να καλέσετε τις μεθόδους που αναφέρονται παραπάνω στο `self` αφού καλέσετε το `get_unchecked`, υποθέτοντας ότι έχουν εφαρμοστεί οι απαιτούμενες traits.
///
/// * Πρέπει επίσης να είναι ασφαλές να αποθέσετε το `self` μετά την κλήση του `get_unchecked`.
///
///
///
///
#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
#[rustc_specialization_trait]
pub unsafe trait TrustedRandomAccess: Sized {
    // Μέθοδος ευκολίας.
    fn size(&self) -> usize
    where
        Self: Iterator,
    {
        self.size_hint().0
    }
    /// `true` εάν λάβετε ένα στοιχείο επανάληψης μπορεί να έχει παρενέργειες.
    /// Θυμηθείτε να λάβετε υπόψη τους εσωτερικούς επαναληπτές.
    const MAY_HAVE_SIDE_EFFECT: bool;
}

/// Όπως το `Iterator::__iterator_get_unchecked`, αλλά δεν απαιτεί από τον μεταγλωττιστή να γνωρίζει ότι το `U: TrustedRandomAccess`.
///
///
/// ## Safety
///
/// Οι ίδιες απαιτήσεις καλούν απευθείας το `get_unchecked`.
#[doc(hidden)]
pub(in crate::iter::adapters) unsafe fn try_get_unchecked<I>(it: &mut I, idx: usize) -> I::Item
where
    I: Iterator,
{
    // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να τηρήσει το συμβόλαιο για το `Iterator::__iterator_get_unchecked`.
    //
    unsafe { it.try_get_unchecked(idx) }
}

unsafe trait SpecTrustedRandomAccess: Iterator {
    /// Εάν `Self: TrustedRandomAccess`, πρέπει να είναι ασφαλές να καλέσετε ένα `Iterator::__iterator_get_unchecked(self, index)`.
    ///
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item;
}

unsafe impl<I: Iterator> SpecTrustedRandomAccess for I {
    default unsafe fn try_get_unchecked(&mut self, _: usize) -> Self::Item {
        panic!("Should only be called on TrustedRandomAccess iterators");
    }
}

unsafe impl<I: Iterator + TrustedRandomAccess> SpecTrustedRandomAccess for I {
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item {
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να τηρήσει το συμβόλαιο για το `Iterator::__iterator_get_unchecked`.
        //
        unsafe { self.__iterator_get_unchecked(index) }
    }
}