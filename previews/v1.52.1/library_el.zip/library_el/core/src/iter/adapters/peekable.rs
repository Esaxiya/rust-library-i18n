use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// Επαναληπτής με `peek()` που επιστρέφει μια προαιρετική αναφορά στο επόμενο στοιχείο.
///
///
/// Αυτό το `struct` δημιουργήθηκε με τη μέθοδο [`peekable`] στο [`Iterator`].
/// Δείτε την τεκμηρίωσή του για περισσότερα.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// Θυμηθείτε μια τιμημένη τιμή, ακόμα κι αν δεν ήταν καμία.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Η δυνατότητα παρακολούθησης πρέπει να θυμάται εάν δεν έχει δει κανείς στη μέθοδο `.peek()`.
// Διασφαλίζει ότι `.peek() .peek();` ή `.peek();Το .next();` προωθεί μόνο τον υποκείμενο επαναληπτικό το πολύ μία φορά.
// Αυτό από μόνο του δεν κάνει τον επαναληπτή να συντήκεται.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// Επιστρέφει μια αναφορά στην τιμή next() χωρίς να προχωρήσει ο επαναληπτικός.
    ///
    /// Όπως το [`next`], αν υπάρχει τιμή, είναι τυλιγμένο σε `Some(T)`.
    /// Αλλά αν η επανάληψη τελειώσει, επιστρέφεται το `None`.
    ///
    /// [`next`]: Iterator::next
    ///
    /// Επειδή το `peek()` επιστρέφει μια αναφορά και πολλοί επαναληπτικοί επαναλαμβάνουν τις αναφορές, μπορεί να υπάρξει μια πιθανή σύγχυση κατά την οποία η τιμή επιστροφής είναι διπλή αναφορά.
    /// Μπορείτε να δείτε αυτό το αποτέλεσμα στα παρακάτω παραδείγματα.
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ας δούμε το future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // Ο επαναληπτής δεν προχωρά ακόμα κι αν κάνουμε `peek` πολλές φορές
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Μετά την ολοκλήρωση του επαναληπτικού, το ίδιο ισχύει και για το `peek()`
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// Επιστρέφει μια μεταβλητή αναφορά στην τιμή next() χωρίς να προχωρήσει ο επαναληπτικός.
    ///
    /// Όπως το [`next`], αν υπάρχει τιμή, είναι τυλιγμένο σε `Some(T)`.
    /// Αλλά αν η επανάληψη τελειώσει, επιστρέφεται το `None`.
    ///
    /// Επειδή το `peek_mut()` επιστρέφει μια αναφορά και πολλοί επαναληπτικοί επαναλαμβάνουν τις αναφορές, μπορεί να υπάρξει μια πιθανή σύγχυση κατά την οποία η τιμή επιστροφής είναι διπλή αναφορά.
    /// Μπορείτε να δείτε αυτό το αποτέλεσμα στα παρακάτω παραδείγματα.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Βασική χρήση:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // Όπως και με το `peek()`, μπορούμε να δούμε το future χωρίς να προχωρήσουμε στον επαναληπτικό.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Ρίξτε μια ματιά στον επαναληπτικό και ορίστε την τιμή πίσω από την μεταβλητή αναφορά.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // Η τιμή που βάζουμε επανεμφανίζεται καθώς συνεχίζεται η επανάληψη.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// Καταναλώστε και επιστρέψτε την επόμενη τιμή αυτού του επαναληπτικού, εάν ισχύει μια συνθήκη.
    /// Εάν το `func` επιστρέψει το `true` για την επόμενη τιμή αυτού του επαναληπτικού, καταναλώστε το και επιστρέψτε το.
    /// Διαφορετικά, επιστρέψτε το `None`.
    /// # Examples
    /// Καταναλώστε έναν αριθμό αν είναι 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Το πρώτο στοιχείο του επαναληπτικού είναι 0;καταναλώστε το.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // Το επόμενο στοιχείο που επιστρέφεται είναι τώρα 1, οπότε το `consume` θα επιστρέψει το `false`.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` αποθηκεύει την τιμή του επόμενου αντικειμένου εάν δεν ήταν ίσο με `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// Καταναλώστε οποιονδήποτε αριθμό μικρότερο από 10.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // Καταναλώστε όλους τους αριθμούς κάτω των 10
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // Η επόμενη τιμή που επιστρέφεται θα είναι 10
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // Δεδομένου ότι ονομάσαμε `self.next()`, καταναλώσαμε `self.peeked`.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// Καταναλώστε και επιστρέψτε το επόμενο στοιχείο εάν είναι ίσο με `expected`.
    /// # Example
    /// Καταναλώστε έναν αριθμό αν είναι 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Το πρώτο στοιχείο του επαναληπτικού είναι 0;καταναλώστε το.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // Το επόμενο στοιχείο που επιστρέφεται είναι τώρα 1, οπότε το `consume` θα επιστρέψει το `false`.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` αποθηκεύει την τιμή του επόμενου αντικειμένου εάν δεν ήταν ίσο με `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // ΑΣΦΑΛΕΙΑ: προώθηση μη ασφαλούς λειτουργίας σε μη ασφαλή λειτουργία με τις ίδιες απαιτήσεις
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}