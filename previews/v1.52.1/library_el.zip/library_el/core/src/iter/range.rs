use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Αντικείμενα που έχουν την έννοια των *διαδόχων* και *προκατόχων* λειτουργιών.
///
/// Η λειτουργία *διάδοχος* κινείται προς τιμές που συγκρίνονται μεγαλύτερες.
/// Η λειτουργία *προκάτοχος* κινείται προς τιμές που συγκρίνονται λιγότερο.
///
/// # Safety
///
/// Αυτό το trait είναι `unsafe` επειδή η εφαρμογή του πρέπει να είναι σωστή για την ασφάλεια των εφαρμογών `unsafe trait TrustedLen` και τα αποτελέσματα της χρήσης αυτού του trait μπορούν διαφορετικά να εμπιστευθούν από τον κωδικό `unsafe` για να είναι σωστά και να εκπληρώνουν τις αναφερόμενες υποχρεώσεις.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Επιστρέφει τον αριθμό των *διαδόχων* που απαιτούνται για τη μετάβαση από το `start` στο `end`.
    ///
    /// Επιστρέφει το `None` εάν ο αριθμός των βημάτων υπερχείλιση `usize` (ή είναι άπειρος ή εάν δεν θα επιτευχθεί ποτέ το `end`).
    ///
    ///
    /// # Invariants
    ///
    /// Για οποιαδήποτε `a`, `b` και `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` εάν και μόνο εάν `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` εάν και μόνο εάν `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` μόνο αν `a <= b`
    ///   * Συνέπεια: `steps_between(&a, &b) == Some(0)` εάν και μόνο αν `a == b`
    ///   * Σημειώστε ότι το `a <= b` σημαίνει _not_ σημαίνει `steps_between(&a, &b) != None`.
    ///     Αυτό συμβαίνει όταν θα απαιτούν περισσότερα από `usize::MAX` βήματα για να φτάσετε στο `b`
    /// * `steps_between(&a, &b) == None` εάν `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Επιστρέφει την τιμή που θα αποκτηθεί λαμβάνοντας τον *διάδοχο*`self` `count` φορές.
    ///
    /// Εάν αυτό ξεχειλίζει το εύρος τιμών που υποστηρίζονται από το `Self`, επιστρέφει το `None`.
    ///
    /// # Invariants
    ///
    /// Για οποιαδήποτε `a`, `n` και `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Για οποιαδήποτε `a`, `n` και `m` όπου το `n + m` δεν υπερχειλίζει:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Για οποιοδήποτε `a` και `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Επιστρέφει την τιμή που θα αποκτηθεί λαμβάνοντας τον *διάδοχο*`self` `count` φορές.
    ///
    /// Εάν αυτό θα υπερέβαινε το εύρος τιμών που υποστηρίζονται από το `Self`, αυτή η συνάρτηση επιτρέπεται να panic, περιτύλιγμα ή κορεσμό.
    ///
    /// Η προτεινόμενη συμπεριφορά είναι να panic όταν είναι ενεργοποιημένες οι ισχυρισμοί εντοπισμού σφαλμάτων και να τυλίξετε ή να κορεστεί διαφορετικά.
    ///
    /// Ο μη ασφαλής κώδικας δεν πρέπει να βασίζεται στην ορθότητα της συμπεριφοράς μετά από υπερχείλιση.
    ///
    /// # Invariants
    ///
    /// Για οποιαδήποτε `a`, `n` και `m`, όπου δεν υπάρχει υπερχείλιση:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Για οποιαδήποτε `a` και `n`, όπου δεν υπάρχει υπερχείλιση:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Επιστρέφει την τιμή που θα αποκτηθεί λαμβάνοντας τον *διάδοχο*`self` `count` φορές.
    ///
    /// # Safety
    ///
    /// Είναι απροσδιόριστη συμπεριφορά για αυτήν τη λειτουργία να ξεχειλίζει το εύρος τιμών που υποστηρίζονται από το `Self`.
    /// Εάν δεν μπορείτε να εγγυηθείτε ότι αυτό δεν θα ξεχειλίζει, χρησιμοποιήστε `forward` ή `forward_checked` αντ 'αυτού.
    ///
    /// # Invariants
    ///
    /// Για οποιοδήποτε `a`:
    ///
    /// * εάν υπάρχει `b` έτσι ώστε `b > a`, είναι ασφαλές να καλέσετε το `Step::forward_unchecked(a, 1)`
    /// * εάν υπάρχει `b`, `n` έτσι ώστε `steps_between(&a, &b) == Some(n)`, είναι ασφαλές να καλέσετε το `Step::forward_unchecked(a, m)` για οποιοδήποτε `m <= n`.
    ///
    ///
    /// Για οποιαδήποτε `a` και `n`, όπου δεν υπάρχει υπερχείλιση:
    ///
    /// * `Step::forward_unchecked(a, n)` είναι ισοδύναμο με `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Επιστρέφει την τιμή που θα ληφθεί λαμβάνοντας τον *προκάτοχο*`self` `count` φορές.
    ///
    /// Εάν αυτό ξεχειλίζει το εύρος τιμών που υποστηρίζονται από το `Self`, επιστρέφει το `None`.
    ///
    /// # Invariants
    ///
    /// Για οποιαδήποτε `a`, `n` και `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Για οποιοδήποτε `a` και `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Επιστρέφει την τιμή που θα ληφθεί λαμβάνοντας τον *προκάτοχο*`self` `count` φορές.
    ///
    /// Εάν αυτό θα υπερέβαινε το εύρος τιμών που υποστηρίζονται από το `Self`, αυτή η συνάρτηση επιτρέπεται να panic, περιτύλιγμα ή κορεσμό.
    ///
    /// Η προτεινόμενη συμπεριφορά είναι να panic όταν είναι ενεργοποιημένες οι ισχυρισμοί εντοπισμού σφαλμάτων και να τυλίξετε ή να κορεστεί διαφορετικά.
    ///
    /// Ο μη ασφαλής κώδικας δεν πρέπει να βασίζεται στην ορθότητα της συμπεριφοράς μετά από υπερχείλιση.
    ///
    /// # Invariants
    ///
    /// Για οποιαδήποτε `a`, `n` και `m`, όπου δεν υπάρχει υπερχείλιση:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Για οποιαδήποτε `a` και `n`, όπου δεν υπάρχει υπερχείλιση:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Επιστρέφει την τιμή που θα ληφθεί λαμβάνοντας τον *προκάτοχο*`self` `count` φορές.
    ///
    /// # Safety
    ///
    /// Είναι απροσδιόριστη συμπεριφορά για αυτήν τη λειτουργία να ξεχειλίζει το εύρος τιμών που υποστηρίζονται από το `Self`.
    /// Εάν δεν μπορείτε να εγγυηθείτε ότι αυτό δεν θα ξεχειλίζει, χρησιμοποιήστε `backward` ή `backward_checked` αντ 'αυτού.
    ///
    /// # Invariants
    ///
    /// Για οποιοδήποτε `a`:
    ///
    /// * εάν υπάρχει `b` έτσι ώστε `b < a`, είναι ασφαλές να καλέσετε το `Step::backward_unchecked(a, 1)`
    /// * εάν υπάρχει `b`, `n` έτσι ώστε `steps_between(&b, &a) == Some(n)`, είναι ασφαλές να καλέσετε το `Step::backward_unchecked(a, m)` για οποιοδήποτε `m <= n`.
    ///
    ///
    /// Για οποιαδήποτε `a` και `n`, όπου δεν υπάρχει υπερχείλιση:
    ///
    /// * `Step::backward_unchecked(a, n)` είναι ισοδύναμο με `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Αυτά εξακολουθούν να δημιουργούνται μακροεντολές, επειδή οι ακέραιοι κυριολεκτικοί αριθμοί καταλήγουν σε διαφορετικούς τύπους.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να εγγυηθεί ότι το `start + n` δεν ξεχειλίζει.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να εγγυηθεί ότι το `start - n` δεν ξεχειλίζει.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Στην έκδοση εντοπισμού σφαλμάτων, ενεργοποιήστε ένα panic στην υπερχείλιση.
            // Αυτό θα πρέπει να βελτιστοποιηθεί πλήρως στις εκδόσεις κυκλοφορίας.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Κάντε τυλίγοντας μαθηματικά για να επιτρέψετε π.χ. `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Στην έκδοση εντοπισμού σφαλμάτων, ενεργοποιήστε ένα panic στην υπερχείλιση.
            // Αυτό θα πρέπει να βελτιστοποιηθεί πλήρως στις εκδόσεις κυκλοφορίας.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Κάντε τυλίγοντας μαθηματικά για να επιτρέψετε π.χ. `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Αυτό βασίζεται στο $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // αν το n είναι εκτός εμβέλειας, το `unsigned_start + n` είναι επίσης
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // αν το n είναι εκτός εμβέλειας, το `unsigned_start - n` είναι επίσης
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Αυτό βασίζεται στο $i_narrower <=usize
                        //
                        // Η μετάδοση σε isize επεκτείνει το πλάτος αλλά διατηρεί το σύμβολο.
                        // Χρησιμοποιήστε το wrapping_sub σε χώρο isize και κάντε cast για να χρησιμοποιήσετε για να υπολογίσετε τη διαφορά που μπορεί να μην ταιριάζει στο εύρος του isize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Το τύλιγμα χειρίζεται θήκες όπως το `Step::forward(-120_i8, 200) == Some(80_i8)`, παρόλο που το 200 είναι εκτός εμβέλειας για το i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Η προσθήκη ξεχειλίζει
                            }
                        }
                        // Εάν το n είναι εκτός εύρους π.χ.
                        // u8, τότε είναι μεγαλύτερο από ολόκληρο το εύρος για το i8 είναι ευρύ, οπότε το `any_i8 + n` ξεχειλίζει απαραίτητα το i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Το τύλιγμα χειρίζεται θήκες όπως το `Step::forward(-120_i8, 200) == Some(80_i8)`, παρόλο που το 200 είναι εκτός εμβέλειας για το i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Υπερχείλιση αφαίρεσης
                            }
                        }
                        // Εάν το n είναι εκτός εύρους π.χ.
                        // u8, τότε είναι μεγαλύτερο από ολόκληρο το εύρος για το i8 είναι ευρύ, οπότε το `any_i8 - n` ξεχειλίζει απαραίτητα το i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Εάν η διαφορά είναι πολύ μεγάλη για παράδειγμα
                            // i128, θα είναι επίσης πολύ μεγάλο για χρήση με λιγότερα bit.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // ΑΣΦΑΛΕΙΑ: το res είναι ένα έγκυρο κλιμάκιο unicode
            // (κάτω από 0x110000 και όχι σε 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // ΑΣΦΑΛΕΙΑ: το res είναι ένα έγκυρο κλιμάκιο unicode
        // (κάτω από 0x110000 και όχι σε 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να εγγυηθεί ότι αυτό δεν ξεχειλίζει
        // το εύρος τιμών για ένα char.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να εγγυηθεί ότι αυτό δεν ξεχειλίζει
            // το εύρος τιμών για ένα char.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // ΑΣΦΑΛΕΙΑ: λόγω της προηγούμενης σύμβασης, αυτό είναι εγγυημένο
        // από τον καλούντα να είναι έγκυρος χαρακτήρας.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να εγγυηθεί ότι αυτό δεν ξεχειλίζει
        // το εύρος τιμών για ένα char.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να εγγυηθεί ότι αυτό δεν ξεχειλίζει
            // το εύρος τιμών για ένα char.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // ΑΣΦΑΛΕΙΑ: λόγω της προηγούμενης σύμβασης, αυτό είναι εγγυημένο
        // από τον καλούντα να είναι έγκυρος χαρακτήρας.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // ΑΣΦΑΛΕΙΑ: μόλις ελεγχθεί η προϋπόθεση
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // ΑΣΦΑΛΕΙΑ: μόλις ελεγχθεί η προϋπόθεση
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Αυτές οι μακροεντολές δημιουργούν εμφυτεύματα `ExactSizeIterator` για διάφορους τύπους εύρους.
//
// * `ExactSizeIterator::len` απαιτείται να επιστρέφετε πάντα ένα ακριβές `usize`, επομένως κανένα εύρος δεν μπορεί να είναι μεγαλύτερο από το `usize::MAX`.
//
// * Για ακέραιους τύπους στο `Range<_>` αυτό ισχύει για τύπους στενότερους από ή ευρύτερους του `usize`.
//   Για ακέραιους τύπους στο `RangeInclusive<_>` αυτό ισχύει για τύπους *αυστηρά στενότερους* από το `usize` από π.χ.
//   `(0..=u64::MAX).len()` θα ήταν `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Αυτά είναι ατελή σύμφωνα με το παραπάνω σκεπτικό, αλλά η κατάργησή τους θα ήταν μια σημαντική αλλαγή καθώς σταθεροποιήθηκαν στο Rust 1.0.0.
    // Έτσι π.χ.
    // `(0..66_000_u32).len()` Για παράδειγμα, θα μεταγλωττιστεί χωρίς σφάλμα ή προειδοποιήσεις σε πλατφόρμες 16-bit, αλλά θα συνεχίσει να δίνει λάθος αποτέλεσμα.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Αυτά είναι ατελή σύμφωνα με το παραπάνω σκεπτικό, αλλά η κατάργησή τους θα ήταν μια σημαντική αλλαγή καθώς σταθεροποιήθηκαν στο Rust 1.26.0.
    // Έτσι π.χ.
    // `(0..=u16::MAX).len()` Για παράδειγμα, θα μεταγλωττιστεί χωρίς σφάλμα ή προειδοποιήσεις σε πλατφόρμες 16-bit, αλλά θα συνεχίσει να δίνει λάθος αποτέλεσμα.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // ΑΣΦΑΛΕΙΑ: μόλις ελεγχθεί η προϋπόθεση
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // ΑΣΦΑΛΕΙΑ: μόλις ελεγχθεί η προϋπόθεση
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // ΑΣΦΑΛΕΙΑ: μόλις ελεγχθεί η προϋπόθεση
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // ΑΣΦΑΛΕΙΑ: μόλις ελεγχθεί η προϋπόθεση
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // ΑΣΦΑΛΕΙΑ: μόλις ελεγχθεί η προϋπόθεση
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // ΑΣΦΑΛΕΙΑ: μόλις ελεγχθεί η προϋπόθεση
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}