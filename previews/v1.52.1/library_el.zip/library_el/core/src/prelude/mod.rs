//! Το libcore prelude
//!
//! Αυτή η ενότητα προορίζεται για χρήστες του libcore που δεν συνδέονται επίσης με το libstd.
//! Αυτή η ενότητα εισάγεται από προεπιλογή όταν το `#![no_std]` χρησιμοποιείται με τον ίδιο τρόπο όπως το prelude της τυπικής βιβλιοθήκης.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Η έκδοση 2015 του πυρήνα prelude.
///
/// Δείτε το [module-level documentation](self) για περισσότερα.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Η έκδοση 2018 του πυρήνα prelude.
///
/// Δείτε το [module-level documentation](self) για περισσότερα.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Η έκδοση 2021 του πυρήνα prelude.
///
/// Δείτε το [module-level documentation](self) για περισσότερα.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Προσθέστε περισσότερα πράγματα.
}