use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` αλλά μη μηδενική και συνδιαλλακτική.
///
/// Αυτό είναι συχνά το σωστό να χρησιμοποιείται όταν δημιουργείτε δομές δεδομένων χρησιμοποιώντας ακατέργαστους δείκτες, αλλά είναι τελικά πιο επικίνδυνο στη χρήση λόγω των πρόσθετων ιδιοτήτων του.Εάν δεν είστε σίγουροι αν πρέπει να χρησιμοποιήσετε το `NonNull<T>`, απλώς χρησιμοποιήστε το `*mut T`!
///
/// Σε αντίθεση με το `*mut T`, ο δείκτης δεν πρέπει πάντα να είναι μηδενικός, ακόμη και αν ο δείκτης δεν παραπέμπεται ποτέ.Αυτό συμβαίνει ώστε τα enums να χρησιμοποιούν αυτήν την απαγορευμένη τιμή ως διακριτικό-το `Option<NonNull<T>>` έχει το ίδιο μέγεθος με το `* mut T`.
/// Ωστόσο, ο δείκτης μπορεί να παραμείνει ασταθής, εάν δεν είναι αναφερόμενος.
///
/// Σε αντίθεση με το `*mut T`, το `NonNull<T>` επιλέχθηκε να είναι συνδιαλλακτικό έναντι του `T`.Αυτό καθιστά δυνατή τη χρήση του `NonNull<T>` κατά την κατασκευή τύπων συνδιαλλαγής, αλλά εισάγει τον κίνδυνο αβεβαιότητας, εάν χρησιμοποιείται σε τύπο που δεν θα έπρεπε πραγματικά να είναι συνδιαλλαγής.
/// (Η αντίθετη επιλογή έγινε για το `*mut T`, παρόλο που τεχνικά η αβεβαιότητα μπορούσε να προκληθεί μόνο με την κλήση μη ασφαλών λειτουργιών.)
///
/// Η συνδιακύμανση είναι σωστή για τις περισσότερες ασφαλείς αφαιρέσεις, όπως `Box`, `Rc`, `Arc`, `Vec` και `LinkedList`.Αυτό συμβαίνει επειδή παρέχουν ένα δημόσιο API που ακολουθεί τους κανονικούς κοινόχρηστους XOR μεταβλητούς κανόνες του Rust.
///
/// Εάν ο τύπος σας δεν μπορεί να είναι με ακρίβεια συνδιαλλαγής, πρέπει να βεβαιωθείτε ότι περιέχει κάποιο επιπλέον πεδίο για την παροχή αμετάβλητων.Συχνά αυτό το πεδίο θα είναι τύπου [`PhantomData`] όπως `PhantomData<Cell<T>>` ή `PhantomData<&'a mut T>`.
///
/// Σημειώστε ότι το `NonNull<T>` έχει μια παρουσία `From` για το `&T`.Ωστόσο, αυτό δεν αλλάζει το γεγονός ότι η μετάλλαξη μέσω ενός (δείκτη που προέρχεται από α) κοινόχρηστη αναφορά είναι απροσδιόριστη συμπεριφορά, εκτός εάν η μετάλλαξη συμβαίνει μέσα σε ένα [`UnsafeCell<T>`].Το ίδιο ισχύει και για τη δημιουργία μιας μεταβλητής αναφοράς από μια κοινή αναφορά.
///
/// Όταν χρησιμοποιείτε αυτήν την παρουσία `From` χωρίς `UnsafeCell<T>`, είναι δική σας ευθύνη να διασφαλίσετε ότι το `as_mut` δεν καλείται ποτέ και το `as_ptr` δεν χρησιμοποιείται ποτέ για μετάλλαξη.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` Οι δείκτες δεν είναι `Send` επειδή τα δεδομένα που αναφέρονται ενδέχεται να είναι ψευδώνυμα.
// Σημείωση, αυτό το impl είναι περιττό, αλλά θα πρέπει να παρέχει καλύτερα μηνύματα σφάλματος.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` Οι δείκτες δεν είναι `Sync` επειδή τα δεδομένα που αναφέρονται ενδέχεται να είναι ψευδώνυμα.
// Σημείωση, αυτό το impl είναι περιττό, αλλά θα πρέπει να παρέχει καλύτερα μηνύματα σφάλματος.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Δημιουργεί ένα νέο `NonNull` που κρέμεται, αλλά είναι καλά ευθυγραμμισμένο.
    ///
    /// Αυτό είναι χρήσιμο για την προετοιμασία τύπων που εκχωρούν τεμπέληδες, όπως το `Vec::new`.
    ///
    /// Σημειώστε ότι η τιμή του δείκτη ενδέχεται ενδεχομένως να αντιπροσωπεύει έναν έγκυρο δείκτη σε ένα `T`, πράγμα που σημαίνει ότι αυτό δεν πρέπει να χρησιμοποιείται ως τιμή φρουρού "not yet initialized".
    /// Οι τύποι που εκχωρούν με τεράστιο τρόπο πρέπει να παρακολουθούν την αρχικοποίηση με κάποιο άλλο τρόπο.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // ΑΣΦΑΛΕΙΑ: Το mem::align_of() επιστρέφει μη μηδενική χρήση που στη συνέχεια μεταδίδεται
        // σε ένα * mut T.
        // Επομένως, το `ptr` δεν είναι μηδενικό και τηρούνται οι προϋποθέσεις για την κλήση του new_unchecked().
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Επιστρέφει κοινόχρηστες αναφορές στην τιμή.Σε αντίθεση με το [`as_ref`], αυτό δεν απαιτεί την αρχικοποίηση της τιμής.
    ///
    /// Για το μεταβλητό αντίστοιχο βλέπε [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Όταν καλείτε αυτήν τη μέθοδο, πρέπει να βεβαιωθείτε ότι ισχύουν όλα τα ακόλουθα:
    ///
    /// * Ο δείκτης πρέπει να είναι σωστά ευθυγραμμισμένος.
    ///
    /// * Πρέπει να είναι "dereferencable" με την έννοια που ορίζεται στο [the module documentation].
    ///
    /// * Πρέπει να εφαρμόσετε τους κανόνες ψευδώνυμου του Rust, καθώς το `'a` διάρκειας ζωής που επιστρέφεται επιλέγεται αυθαίρετα και δεν αντικατοπτρίζει απαραίτητα την πραγματική διάρκεια ζωής των δεδομένων.
    ///
    ///   Ειδικότερα, για τη διάρκεια αυτής της διάρκειας ζωής, η μνήμη που δείχνει ο δείκτης δεν πρέπει να μεταλλαχθεί (εκτός από το `UnsafeCell`).
    ///
    /// Αυτό ισχύει ακόμη και αν το αποτέλεσμα αυτής της μεθόδου δεν χρησιμοποιείται!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να εγγυηθεί ότι το `self` πληροί όλα τα
        // απαιτήσεις για αναφορά.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Επιστρέφει μοναδικές αναφορές στην τιμή.Σε αντίθεση με το [`as_mut`], αυτό δεν απαιτεί την αρχικοποίηση της τιμής.
    ///
    /// Για το κοινόχρηστο αντίστοιχο δείτε [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Όταν καλείτε αυτήν τη μέθοδο, πρέπει να βεβαιωθείτε ότι ισχύουν όλα τα ακόλουθα:
    ///
    /// * Ο δείκτης πρέπει να είναι σωστά ευθυγραμμισμένος.
    ///
    /// * Πρέπει να είναι "dereferencable" με την έννοια που ορίζεται στο [the module documentation].
    ///
    /// * Πρέπει να εφαρμόσετε τους κανόνες ψευδώνυμου του Rust, καθώς το `'a` διάρκειας ζωής που επιστρέφεται επιλέγεται αυθαίρετα και δεν αντικατοπτρίζει απαραίτητα την πραγματική διάρκεια ζωής των δεδομένων.
    ///
    ///   Συγκεκριμένα, κατά τη διάρκεια αυτής της διάρκειας ζωής, η μνήμη που δείχνει ο δείκτης δεν πρέπει να έχει πρόσβαση (ανάγνωση ή γραφή) μέσω οποιουδήποτε άλλου δείκτη.
    ///
    /// Αυτό ισχύει ακόμη και αν το αποτέλεσμα αυτής της μεθόδου δεν χρησιμοποιείται!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να εγγυηθεί ότι το `self` πληροί όλα τα
        // απαιτήσεις για αναφορά.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Δημιουργεί ένα νέο `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` πρέπει να είναι μηδενικό.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να εγγυηθεί ότι το `ptr` είναι μηδενικό.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Δημιουργεί ένα νέο `NonNull` εάν το `ptr` είναι μηδενικό.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // ΑΣΦΑΛΕΙΑ: Ο δείκτης έχει ήδη ελεγχθεί και δεν είναι μηδενικός
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Εκτελεί την ίδια λειτουργικότητα με το [`std::ptr::from_raw_parts`], εκτός από το ότι επιστρέφεται ένας δείκτης `NonNull`, σε αντίθεση με έναν ακατέργαστο δείκτη `*const`.
    ///
    ///
    /// Δείτε την τεκμηρίωση του [`std::ptr::from_raw_parts`] για περισσότερες λεπτομέρειες.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // ΑΣΦΑΛΕΙΑ: Το αποτέλεσμα του `ptr::from::raw_parts_mut` δεν είναι μηδενικό επειδή το `data_address` είναι.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Αποσύνθεση ενός (πιθανώς ευρέως) δείκτη σε στοιχεία διεύθυνσης και μεταδεδομένων.
    ///
    /// Ο δείκτης μπορεί αργότερα να ανακατασκευαστεί με [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Λαμβάνει τον υποκείμενο δείκτη `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Επιστρέφει μια κοινόχρηστη αναφορά στην τιμή.Εάν η τιμή ενδέχεται να μην είναι αρχικοποιημένη, πρέπει να χρησιμοποιηθεί το [`as_uninit_ref`].
    ///
    /// Για το μεταβλητό αντίστοιχο βλέπε [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Όταν καλείτε αυτήν τη μέθοδο, πρέπει να βεβαιωθείτε ότι ισχύουν όλα τα ακόλουθα:
    ///
    /// * Ο δείκτης πρέπει να είναι σωστά ευθυγραμμισμένος.
    ///
    /// * Πρέπει να είναι "dereferencable" με την έννοια που ορίζεται στο [the module documentation].
    ///
    /// * Ο δείκτης πρέπει να δείχνει μια αρχικοποιημένη παρουσία του `T`.
    ///
    /// * Πρέπει να εφαρμόσετε τους κανόνες ψευδώνυμου του Rust, καθώς το `'a` διάρκειας ζωής που επιστρέφεται επιλέγεται αυθαίρετα και δεν αντικατοπτρίζει απαραίτητα την πραγματική διάρκεια ζωής των δεδομένων.
    ///
    ///   Ειδικότερα, για τη διάρκεια αυτής της διάρκειας ζωής, η μνήμη που δείχνει ο δείκτης δεν πρέπει να μεταλλαχθεί (εκτός από το `UnsafeCell`).
    ///
    /// Αυτό ισχύει ακόμη και αν το αποτέλεσμα αυτής της μεθόδου δεν χρησιμοποιείται!
    /// (Το μέρος της αρχικοποίησης δεν έχει ακόμη αποφασιστεί πλήρως, αλλά μέχρι να γίνει, η μόνη ασφαλής προσέγγιση είναι να διασφαλιστεί ότι πράγματι έχουν αρχικοποιηθεί.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να εγγυηθεί ότι το `self` πληροί όλα τα
        // απαιτήσεις για αναφορά.
        unsafe { &*self.as_ptr() }
    }

    /// Επιστρέφει μια μοναδική αναφορά στην τιμή.Εάν η τιμή ενδέχεται να μην είναι αρχικοποιημένη, πρέπει να χρησιμοποιηθεί το [`as_uninit_mut`].
    ///
    /// Για το κοινόχρηστο αντίστοιχο δείτε [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Όταν καλείτε αυτήν τη μέθοδο, πρέπει να βεβαιωθείτε ότι ισχύουν όλα τα ακόλουθα:
    ///
    /// * Ο δείκτης πρέπει να είναι σωστά ευθυγραμμισμένος.
    ///
    /// * Πρέπει να είναι "dereferencable" με την έννοια που ορίζεται στο [the module documentation].
    ///
    /// * Ο δείκτης πρέπει να δείχνει μια αρχικοποιημένη παρουσία του `T`.
    ///
    /// * Πρέπει να εφαρμόσετε τους κανόνες ψευδώνυμου του Rust, καθώς το `'a` διάρκειας ζωής που επιστρέφεται επιλέγεται αυθαίρετα και δεν αντικατοπτρίζει απαραίτητα την πραγματική διάρκεια ζωής των δεδομένων.
    ///
    ///   Συγκεκριμένα, κατά τη διάρκεια αυτής της διάρκειας ζωής, η μνήμη που δείχνει ο δείκτης δεν πρέπει να έχει πρόσβαση (ανάγνωση ή γραφή) μέσω οποιουδήποτε άλλου δείκτη.
    ///
    /// Αυτό ισχύει ακόμη και αν το αποτέλεσμα αυτής της μεθόδου δεν χρησιμοποιείται!
    /// (Το μέρος της αρχικοποίησης δεν έχει ακόμη αποφασιστεί πλήρως, αλλά μέχρι να γίνει, η μόνη ασφαλής προσέγγιση είναι να διασφαλιστεί ότι πράγματι έχουν αρχικοποιηθεί.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να εγγυηθεί ότι το `self` πληροί όλα τα
        // απαιτήσεις για μεταβλητή αναφορά.
        unsafe { &mut *self.as_ptr() }
    }

    /// Μεταδίδει σε δείκτη άλλου τύπου.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // ΑΣΦΑΛΕΙΑ: Το `self` είναι δείκτης `NonNull` που είναι απαραιτήτως μηδενικός
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Δημιουργεί μια μη μηδενική ακατέργαστη φέτα από ένα λεπτό δείκτη και μήκος.
    ///
    /// Το όρισμα `len` είναι ο αριθμός των **στοιχείων** και όχι ο αριθμός των byte.
    ///
    /// Αυτή η συνάρτηση είναι ασφαλής, αλλά η επαναφορά της τιμής επιστροφής δεν είναι ασφαλής.
    /// Ανατρέξτε στην τεκμηρίωση του [`slice::from_raw_parts`] για τις απαιτήσεις ασφαλείας σε φέτες.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // δημιουργήστε ένα δείκτη slice όταν ξεκινάτε με ένα δείκτη στο πρώτο στοιχείο
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Σημειώστε ότι αυτό το παράδειγμα δείχνει τεχνητά τη χρήση αυτής της μεθόδου, αλλά "let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // ΑΣΦΑΛΕΙΑ: Το `data` είναι δείκτης `NonNull` που είναι απαραιτήτως μηδενικός
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Επιστρέφει το μήκος μιας μη μηδενικής ακατέργαστης φέτας.
    ///
    /// Η επιστρεφόμενη τιμή είναι ο αριθμός των **στοιχείων** και όχι ο αριθμός των byte.
    ///
    /// Αυτή η λειτουργία είναι ασφαλής, ακόμα και όταν το μη μηδενικό ακατέργαστο κομμάτι δεν μπορεί να αναφερθεί σε ένα κομμάτι επειδή ο δείκτης δεν έχει έγκυρη διεύθυνση.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Επιστρέφει ένα μη μηδενικό δείκτη στο buffer του slice.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // ΑΣΦΑΛΕΙΑ: Γνωρίζουμε ότι το `self` είναι μηδενικό.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Επιστρέφει έναν ακατέργαστο δείκτη στο buffer του slice.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Επιστρέφει μια κοινόχρηστη αναφορά σε ένα κομμάτι πιθανώς μη αρχικοποιημένων τιμών.Σε αντίθεση με το [`as_ref`], αυτό δεν απαιτεί την αρχικοποίηση της τιμής.
    ///
    /// Για το μεταβλητό αντίστοιχο βλέπε [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Όταν καλείτε αυτήν τη μέθοδο, πρέπει να βεβαιωθείτε ότι ισχύουν όλα τα ακόλουθα:
    ///
    /// * Ο δείκτης πρέπει να είναι [valid] για αναγνώσεις για `ptr.len() * mem::size_of::<T>()` πολλά byte και πρέπει να ευθυγραμμιστεί σωστά.Αυτό σημαίνει συγκεκριμένα:
    ///
    ///     * Όλη η περιοχή μνήμης αυτού του slice πρέπει να περιέχεται σε ένα μόνο αντικείμενο που έχει εκχωρηθεί!
    ///       Οι φέτες δεν μπορούν ποτέ να εκτείνονται σε πολλά εκχωρημένα αντικείμενα.
    ///
    ///     * Ο δείκτης πρέπει να ευθυγραμμιστεί ακόμη και για φέτες μηδενικού μήκους.
    ///     Ένας λόγος γι 'αυτό είναι ότι οι βελτιστοποιήσεις διάταξης enum μπορεί να βασίζονται σε ευθυγράμμιση αναφορών (συμπεριλαμβανομένων φετών οποιουδήποτε μήκους) και μη-μηδενικής για τη διάκρισή τους από άλλα δεδομένα.
    ///
    ///     Μπορείτε να αποκτήσετε ένα δείκτη που μπορεί να χρησιμοποιηθεί ως `data` για φέτες μηδενικού μήκους χρησιμοποιώντας το [`NonNull::dangling()`].
    ///
    /// * Το συνολικό μέγεθος `ptr.len() * mem::size_of::<T>()` της φέτας δεν πρέπει να είναι μεγαλύτερο από `isize::MAX`.
    ///   Δείτε την τεκμηρίωση ασφαλείας του [`pointer::offset`].
    ///
    /// * Πρέπει να εφαρμόσετε τους κανόνες ψευδώνυμου του Rust, καθώς το `'a` διάρκειας ζωής που επιστρέφεται επιλέγεται αυθαίρετα και δεν αντικατοπτρίζει απαραίτητα την πραγματική διάρκεια ζωής των δεδομένων.
    ///   Ειδικότερα, για τη διάρκεια αυτής της διάρκειας ζωής, η μνήμη που δείχνει ο δείκτης δεν πρέπει να μεταλλαχθεί (εκτός από το `UnsafeCell`).
    ///
    /// Αυτό ισχύει ακόμη και αν το αποτέλεσμα αυτής της μεθόδου δεν χρησιμοποιείται!
    ///
    /// Δείτε επίσης [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να τηρεί τη σύμβαση ασφαλείας για το `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Επιστρέφει μια μοναδική αναφορά σε ένα κομμάτι πιθανώς μη αρχικοποιημένων τιμών.Σε αντίθεση με το [`as_mut`], αυτό δεν απαιτεί την αρχικοποίηση της τιμής.
    ///
    /// Για το κοινόχρηστο αντίστοιχο δείτε [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Όταν καλείτε αυτήν τη μέθοδο, πρέπει να βεβαιωθείτε ότι ισχύουν όλα τα ακόλουθα:
    ///
    /// * Ο δείκτης πρέπει να είναι [valid] για ανάγνωση και εγγραφή για `ptr.len() * mem::size_of::<T>()` πολλά byte και πρέπει να ευθυγραμμιστεί σωστά.Αυτό σημαίνει συγκεκριμένα:
    ///
    ///     * Όλη η περιοχή μνήμης αυτού του slice πρέπει να περιέχεται σε ένα μόνο αντικείμενο που έχει εκχωρηθεί!
    ///       Οι φέτες δεν μπορούν ποτέ να εκτείνονται σε πολλά εκχωρημένα αντικείμενα.
    ///
    ///     * Ο δείκτης πρέπει να ευθυγραμμιστεί ακόμη και για φέτες μηδενικού μήκους.
    ///     Ένας λόγος γι 'αυτό είναι ότι οι βελτιστοποιήσεις διάταξης enum μπορεί να βασίζονται σε ευθυγράμμιση αναφορών (συμπεριλαμβανομένων φετών οποιουδήποτε μήκους) και μη-μηδενικής για τη διάκρισή τους από άλλα δεδομένα.
    ///
    ///     Μπορείτε να αποκτήσετε ένα δείκτη που μπορεί να χρησιμοποιηθεί ως `data` για φέτες μηδενικού μήκους χρησιμοποιώντας το [`NonNull::dangling()`].
    ///
    /// * Το συνολικό μέγεθος `ptr.len() * mem::size_of::<T>()` της φέτας δεν πρέπει να είναι μεγαλύτερο από `isize::MAX`.
    ///   Δείτε την τεκμηρίωση ασφαλείας του [`pointer::offset`].
    ///
    /// * Πρέπει να εφαρμόσετε τους κανόνες ψευδώνυμου του Rust, καθώς το `'a` διάρκειας ζωής που επιστρέφεται επιλέγεται αυθαίρετα και δεν αντικατοπτρίζει απαραίτητα την πραγματική διάρκεια ζωής των δεδομένων.
    ///   Συγκεκριμένα, κατά τη διάρκεια αυτής της διάρκειας ζωής, η μνήμη που δείχνει ο δείκτης δεν πρέπει να έχει πρόσβαση (ανάγνωση ή γραφή) μέσω οποιουδήποτε άλλου δείκτη.
    ///
    /// Αυτό ισχύει ακόμη και αν το αποτέλεσμα αυτής της μεθόδου δεν χρησιμοποιείται!
    ///
    /// Δείτε επίσης [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Αυτό είναι ασφαλές καθώς το `memory` ισχύει για διαβάσεις και εγγραφές για `memory.len()` πολλά byte.
    /// // Λάβετε υπόψη ότι η κλήση του `memory.as_mut()` δεν επιτρέπεται εδώ, καθώς το περιεχόμενο ενδέχεται να μην έχει αρχικοποιηθεί.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // ΑΣΦΑΛΕΙΑ: ο καλών πρέπει να τηρεί τη σύμβαση ασφαλείας για το `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Επιστρέφει έναν ακατέργαστο δείκτη σε ένα στοιχείο ή υποσύνολο, χωρίς να κάνει οριακό έλεγχο.
    ///
    /// Η κλήση αυτής της μεθόδου με ευρετήριο εκτός ορίων ή όταν το `self` δεν μπορεί να διαγραφεί είναι *[απροσδιόριστη συμπεριφορά]* ακόμη και αν ο προκύπτων δείκτης δεν χρησιμοποιείται.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // ΑΣΦΑΛΕΙΑ: ο καλών διασφαλίζει ότι το `self` δεν είναι δυνατό να διαγραφεί και το `index` εντός ορίων.
        // Κατά συνέπεια, ο δείκτης που προκύπτει δεν μπορεί να είναι NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // ΑΣΦΑΛΕΙΑ: Ένας μοναδικός δείκτης δεν μπορεί να είναι μηδενικός, επομένως οι προϋποθέσεις για
        // new_unchecked() γίνονται σεβαστά.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ΑΣΦΑΛΕΙΑ: Μια μεταβλητή αναφορά δεν μπορεί να είναι μηδενική.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // ΑΣΦΑΛΕΙΑ: Μια αναφορά δεν μπορεί να είναι άκυρη, επομένως οι προϋποθέσεις για
        // new_unchecked() γίνονται σεβαστά.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}