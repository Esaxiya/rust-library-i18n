//! Κοινοποιήσιμα μεταβλητά κοντέινερ.
//!
//! Η ασφάλεια μνήμης Rust βασίζεται σε αυτόν τον κανόνα: Δεδομένου ενός αντικειμένου `T`, είναι δυνατό μόνο να έχετε ένα από τα ακόλουθα:
//!
//! - Έχοντας αρκετές αμετάβλητες αναφορές (`&T`) στο αντικείμενο (επίσης γνωστό ως **aliasing**).
//! - Έχοντας μια μεταβλητή αναφορά (`&mut T`) στο αντικείμενο (επίσης γνωστό ως **mutability**).
//!
//! Αυτό επιβάλλεται από τον μεταγλωττιστή Rust.Ωστόσο, υπάρχουν καταστάσεις όπου αυτός ο κανόνας δεν είναι αρκετά ευέλικτος.Μερικές φορές απαιτείται να έχετε πολλές αναφορές σε ένα αντικείμενο και να το μεταλλάξετε.
//!
//! Υπάρχουν κοινόχρηστα μεταβλητά δοχεία που επιτρέπουν τη μεταβλητότητα με ελεγχόμενο τρόπο, ακόμη και παρουσία ψευδωνύμου.Τόσο το [`Cell<T>`] όσο και το [`RefCell<T>`] επιτρέπουν να το κάνετε αυτό με μονό σπείρωμα.
//! Ωστόσο, ούτε το `Cell<T>` ούτε το `RefCell<T>` είναι ασφαλές για νήματα (δεν εφαρμόζουν το [`Sync`]).
//! Εάν πρέπει να κάνετε ψευδώνυμο και μετάλλαξη μεταξύ πολλών νημάτων, μπορείτε να χρησιμοποιήσετε τύπους [`Mutex<T>`], [`RwLock<T>`] ή [`atomic`].
//!
//! Οι τιμές των τύπων `Cell<T>` και `RefCell<T>` μπορούν να μεταλλαχθούν μέσω κοινόχρηστων αναφορών (π.χ.
//! ο κοινός τύπος `&T`), ενώ οι περισσότεροι τύποι Rust μπορούν να μεταλλαχθούν μόνο μέσω μοναδικών αναφορών («&mut T»).
//! Λέμε ότι τα `Cell<T>` και `RefCell<T>` παρέχουν «εσωτερική μεταβλητότητα», σε αντίθεση με τους τυπικούς τύπους Rust που εμφανίζουν «κληρονομική μεταβλητότητα».
//!
//! Οι τύποι κυττάρων διατίθενται σε δύο γεύσεις: `Cell<T>` και `RefCell<T>`.Το `Cell<T>` εφαρμόζει εσωτερική μεταβλητότητα μετακινώντας τιμές μέσα και έξω από το `Cell<T>`.
//! Για να χρησιμοποιήσετε αναφορές αντί για τιμές, πρέπει να χρησιμοποιήσετε τον τύπο `RefCell<T>`, αποκτώντας ένα κλείδωμα εγγραφής πριν από τη μετάλλαξη.Το `Cell<T>` παρέχει μεθόδους ανάκτησης και αλλαγής της τρέχουσας εσωτερικής τιμής:
//!
//!  - Για τύπους που εφαρμόζουν [`Copy`], η μέθοδος [`get`](Cell::get) ανακτά την τρέχουσα εσωτερική τιμή.
//!  - Για τύπους που εφαρμόζουν [`Default`], η μέθοδος [`take`](Cell::take) αντικαθιστά την τρέχουσα εσωτερική τιμή με [`Default::default()`] και επιστρέφει την αντικατασταθείσα τιμή.
//!  - Για όλους τους τύπους, η μέθοδος [`replace`](Cell::replace) αντικαθιστά την τρέχουσα εσωτερική τιμή και επιστρέφει την αντικατασταθείσα τιμή και η μέθοδος [`into_inner`](Cell::into_inner) καταναλώνει το `Cell<T>` και επιστρέφει την εσωτερική τιμή.
//!  Επιπλέον, η μέθοδος [`set`](Cell::set) αντικαθιστά την εσωτερική τιμή, μειώνοντας την τιμή που αντικαταστάθηκε.
//!
//! `RefCell<T>` χρησιμοποιεί τη διάρκεια ζωής του Rust για την εφαρμογή «δυναμικού δανεισμού», μιας διαδικασίας με την οποία μπορεί κανείς να διεκδικήσει προσωρινή, αποκλειστική, μεταβλητή πρόσβαση στην εσωτερική αξία.
//! Δανείζεται για το «RefCell<T>Τα "s παρακολουθούνται" κατά το χρόνο εκτέλεσης ", σε αντίθεση με τους εγγενείς τύπους αναφοράς του Rust που παρακολουθούνται πλήρως στατικά, κατά το χρόνο μεταγλώττισης.
//! Επειδή τα `RefCell<T>` δανεισμού είναι δυναμικά, είναι δυνατόν να επιχειρήσετε να δανειστείτε μια τιμή που έχει ήδη δανειστεί αμοιβαία.όταν συμβεί αυτό έχει ως αποτέλεσμα το νήμα panic.
//!
//! # Πότε να επιλέξετε εσωτερική μεταβλητότητα
//!
//! Η πιο κοινή κληρονομική μεταβλητότητα, όπου κάποιος πρέπει να έχει μοναδική πρόσβαση για να μεταλλάξει μια τιμή, είναι ένα από τα βασικά γλωσσικά στοιχεία που επιτρέπει στο Rust να συλλογιστεί έντονα το ψευδώνυμο του δείκτη, αποτρέποντας στατικά τα σφάλματα σφάλματος.
//! Εξαιτίας αυτού, προτιμάται η κληρονομική μεταβλητότητα και η εσωτερική μεταβλητότητα είναι κάτι έσχατο.
//! Δεδομένου ότι οι τύποι κυττάρων επιτρέπουν τη μετάλλαξη όπου διαφορετικά θα απαγορευόταν, υπάρχουν περιπτώσεις όπου η εσωτερική μεταβλητότητα μπορεί να είναι κατάλληλη, ή ακόμη και *πρέπει* να χρησιμοποιηθεί, π.χ.
//!
//! * Παρουσιάζουμε την αμετάβλητη 'inside' κάτι αμετάβλητο
//! * Λεπτομέρειες εφαρμογής των λογικά αμετάβλητων μεθόδων.
//! * Μεταλλαγή υλοποιήσεων του [`Clone`].
//!
//! ## Παρουσιάζουμε την αμετάβλητη 'inside' κάτι αμετάβλητο
//!
//! Πολλοί κοινόχρηστοι τύποι έξυπνου δείκτη, συμπεριλαμβανομένων των [`Rc<T>`] και [`Arc<T>`], παρέχουν κοντέινερ που μπορούν να κλωνοποιηθούν και να μοιραστούν μεταξύ πολλών μερών.
//! Επειδή οι περιορισμένες τιμές μπορεί να είναι πολλαπλά ψευδώνυμο, μπορούν να δανειστούν μόνο με `&` και όχι `&mut`.
//! Χωρίς κελιά θα ήταν αδύνατο να μεταλλαχθούν δεδομένα μέσα σε αυτούς τους έξυπνους δείκτες.
//!
//! Είναι πολύ συνηθισμένο να τοποθετείτε ένα `RefCell<T>` σε κοινόχρηστους τύπους δείκτη για να επαναφέρετε τη μεταβλητότητα:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Δημιουργήστε ένα νέο μπλοκ για να περιορίσετε το εύρος του δυναμικού δανεισμού
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Σημειώστε ότι εάν δεν είχαμε αφήσει το προηγούμενο δανεισμό της προσωρινής μνήμης να μην πέσει στο πεδίο εφαρμογής, τότε το επόμενο δανεισμό θα προκαλούσε ένα δυναμικό νήμα panic.
//!     //
//!     // Αυτός είναι ο μεγαλύτερος κίνδυνος χρήσης του `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Σημειώστε ότι αυτό το παράδειγμα χρησιμοποιεί `Rc<T>` και όχι `Arc<T>`."RefCell<T>Είναι για σενάρια ενός νήματος.Εξετάστε το ενδεχόμενο να χρησιμοποιήσετε το [`RwLock<T>`] ή το [`Mutex<T>`] εάν χρειάζεστε κοινή μεταβλητότητα σε μια κατάσταση πολλαπλών νημάτων.
//!
//! ## Λεπτομέρειες εφαρμογής των λογικά αμετάβλητων μεθόδων
//!
//! Περιστασιακά μπορεί να είναι επιθυμητό να μην εκθέσουμε σε ένα API ότι υπάρχει μετάλλαξη "under the hood".
//! Αυτό μπορεί να οφείλεται στο γεγονός ότι η λειτουργία είναι λογικά αμετάβλητη, αλλά π.χ. η προσωρινή αποθήκευση αναγκάζει την εφαρμογή να πραγματοποιήσει μετάλλαξη.ή επειδή πρέπει να χρησιμοποιήσετε τη μετάλλαξη για να εφαρμόσετε μια μέθοδο trait που αρχικά ορίστηκε για να πάρει το `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Ο ακριβός υπολογισμός πηγαίνει εδώ
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Μεταλλαγή υλοποιήσεων του `Clone`
//!
//! Αυτή είναι απλώς μια ειδική, αλλά κοινή, περίπτωση της προηγούμενης: απόκρυψη της μεταβλητότητας για λειτουργίες που φαίνεται να είναι αμετάβλητες.
//! Η μέθοδος [`clone`](Clone::clone) αναμένεται να μην αλλάξει την τιμή προέλευσης και δηλώνεται ότι λαμβάνει το `&self` και όχι το `&mut self`.
//! Επομένως, οποιαδήποτε μετάλλαξη που συμβαίνει στη μέθοδο `clone` πρέπει να χρησιμοποιεί τύπους κελιών.
//! Για παράδειγμα, το [`Rc<T>`] διατηρεί τους αριθμούς αναφοράς του σε ένα `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Μια μεταβλητή θέση μνήμης.
///
/// # Examples
///
/// Σε αυτό το παράδειγμα, μπορείτε να δείτε ότι το `Cell<T>` επιτρέπει τη μετάλλαξη μέσα σε μια αμετάβλητη δομή.
/// Με άλλα λόγια, επιτρέπει το "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ΣΦΑΛΜΑ: Το `my_struct` είναι αμετάβλητο
/// // my_struct.regular_field =νέα_τιμή;
///
/// // ΛΕΙΤΟΥΡΓΕΙ: αν και το `my_struct` είναι αμετάβλητο, το `special_field` είναι `Cell`,
/// // που μπορεί πάντα να μεταλλαχθεί
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Δείτε το [module-level documentation](self) για περισσότερα.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Δημιουργεί ένα `Cell<T>`, με την τιμή `Default` για T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Δημιουργεί ένα νέο `Cell` που περιέχει τη δεδομένη τιμή.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Ορίζει την περιορισμένη τιμή.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Ανταλλάσσει τις τιμές δύο κελιών.
    /// Η διαφορά με το `std::mem::swap` είναι ότι αυτή η συνάρτηση δεν απαιτεί αναφορά `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // ΑΣΦΑΛΕΙΑ: Αυτό μπορεί να είναι επικίνδυνο εάν καλείται από ξεχωριστά νήματα, αλλά `Cell`
        // είναι `!Sync`, οπότε αυτό δεν θα συμβεί.
        // Αυτό επίσης δεν θα ακυρώσει κανένα δείκτη δεδομένου ότι το `Cell` διασφαλίζει ότι τίποτα άλλο δεν θα δείχνει σε κανένα από αυτά τα «Cell».
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Αντικαθιστά την περιορισμένη τιμή με `val` και επιστρέφει την παλιά περιεχόμενη τιμή.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // ΑΣΦΑΛΕΙΑ: Αυτό μπορεί να προκαλέσει αγώνες δεδομένων, εάν κληθούν από ξεχωριστό νήμα,
        // αλλά το `Cell` είναι `!Sync`, οπότε αυτό δεν θα συμβεί.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Ξετυλίγει την τιμή.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Επιστρέφει ένα αντίγραφο της περιορισμένης τιμής.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // ΑΣΦΑΛΕΙΑ: Αυτό μπορεί να προκαλέσει αγώνες δεδομένων, εάν κληθούν από ξεχωριστό νήμα,
        // αλλά το `Cell` είναι `!Sync`, οπότε αυτό δεν θα συμβεί.
        unsafe { *self.value.get() }
    }

    /// Ενημερώνει την περιορισμένη τιμή χρησιμοποιώντας μια συνάρτηση και επιστρέφει τη νέα τιμή.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Επιστρέφει έναν ακατέργαστο δείκτη στα υποκείμενα δεδομένα σε αυτό το κελί.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Επιστρέφει μια μεταβλητή αναφορά στα υποκείμενα δεδομένα.
    ///
    /// Αυτή η κλήση δανείζεται `Cell` αμετάβλητα (κατά το χρόνο μεταγλώττισης) που εγγυάται ότι διαθέτουμε τη μοναδική αναφορά.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Επιστρέφει `&Cell<T>` από `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // ΑΣΦΑΛΕΙΑ: Το `&mut` εξασφαλίζει μοναδική πρόσβαση.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Παίρνει την τιμή του κελιού, αφήνοντας το `Default::default()` στη θέση του.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Επιστρέφει `&[Cell<T>]` από `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // ΑΣΦΑΛΕΙΑ: Το `Cell<T>` έχει την ίδια διάταξη μνήμης με το `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Μια μεταβλητή τοποθεσία μνήμης με δυναμικά ελεγμένους κανόνες δανεισμού
///
/// Δείτε το [module-level documentation](self) για περισσότερα.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Παρουσιάστηκε σφάλμα από το [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Παρουσιάστηκε σφάλμα από το [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Οι θετικές τιμές αντιπροσωπεύουν τον αριθμό των ενεργών `Ref`.Οι αρνητικές τιμές αντιπροσωπεύουν τον αριθμό των ενεργών `RefMut`.
// Πολλαπλά «RefMut`s μπορούν να είναι ενεργά κάθε φορά, εάν αναφέρονται σε διακριτά, μη επικαλυπτόμενα στοιχεία ενός `RefCell` (π.χ., διαφορετικά εύρη μιας φέτας).
//
// `Ref` και το `RefMut` έχουν και τις δύο λέξεις σε μέγεθος, και έτσι πιθανότατα δεν θα υπάρχει ποτέ αρκετό "Ref" ή "RefMut" για να ξεχειλίζει το ήμισυ του εύρους `usize`.
// Έτσι, ένα `BorrowFlag` πιθανότατα δεν θα ξεχειλίσει ή θα ξεχειλίσει.
// Ωστόσο, αυτό δεν αποτελεί εγγύηση, καθώς ένα παθολογικό πρόγραμμα θα μπορούσε να δημιουργήσει επανειλημμένα και στη συνέχεια mem::forget "Ref`s ή"RefMut".
// Επομένως, όλοι οι κώδικες πρέπει να ελέγχουν ρητά την υπερχείλιση και την υπερχείλιση, προκειμένου να αποφευχθεί η ασφάλεια, ή τουλάχιστον να συμπεριφέρεται σωστά σε περίπτωση που προκύψει υπερχείλιση ή υπερχείλιση (π.χ. βλ. BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Δημιουργεί ένα νέο `RefCell` που περιέχει `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Καταναλώνει το `RefCell`, επιστρέφοντας την τυλιγμένη τιμή.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Δεδομένου ότι αυτή η συνάρτηση παίρνει το `self` (το `RefCell`) από την τιμή, ο μεταγλωττιστής επαληθεύει στατικά ότι δεν είναι προς το παρόν δανεισμένος.
        //
        self.value.into_inner()
    }

    /// Αντικαθιστά την τυλιγμένη τιμή με μια νέα, επιστρέφοντας την παλιά τιμή, χωρίς να απενεργοποιήσετε καμία.
    ///
    ///
    /// Αυτή η λειτουργία αντιστοιχεί στο [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics εάν η αξία είναι δανεισμένη αυτήν τη στιγμή.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Αντικαθιστά την τυλιγμένη τιμή με μια νέα υπολογισμένη από το `f`, επιστρέφοντας την παλιά τιμή, χωρίς να απενεργοποιήσετε καμία.
    ///
    ///
    /// # Panics
    ///
    /// Panics εάν η αξία είναι δανεισμένη αυτήν τη στιγμή.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Ανταλλάσσει την τυλιγμένη τιμή του `self` με την τιμή περιτυλίγματος του `other`, χωρίς να απενεργοποιήσει κανένα.
    ///
    ///
    /// Αυτή η λειτουργία αντιστοιχεί στο [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics εάν η τιμή και στα δύο `RefCell` είναι προς το παρόν δανεισμένη.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Δανείζεται αμετάβλητα την αναδιπλούμενη αξία.
    ///
    /// Το δάνειο διαρκεί μέχρι το `Ref` να επιστρέψει.
    /// Πολλά αμετάβλητα δάνεια μπορούν να αφαιρεθούν ταυτόχρονα.
    ///
    /// # Panics
    ///
    /// Panics εάν η αξία αυτή τη στιγμή δανείζεται αμοιβαία.
    /// Για παραλλαγή χωρίς πανικό, χρησιμοποιήστε το [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Ένα παράδειγμα panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Δανείζεται αμετάβλητα την αναδιπλούμενη τιμή, επιστρέφοντας ένα σφάλμα εάν η τιμή αυτή τη στιγμή δανείζεται αμοιβαία.
    ///
    ///
    /// Το δάνειο διαρκεί μέχρι το `Ref` να επιστρέψει.
    /// Πολλά αμετάβλητα δάνεια μπορούν να αφαιρεθούν ταυτόχρονα.
    ///
    /// Αυτή είναι η μη πανικοβλημένη παραλλαγή του [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // ΑΣΦΑΛΕΙΑ: Το `BorrowRef` διασφαλίζει ότι υπάρχει μόνο αμετάβλητη πρόσβαση
            // στην αξία ενώ δανείστηκε.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Δανείζεται αμοιβαία την αναδιπλούμενη αξία.
    ///
    /// Το δάνειο διαρκεί μέχρι το επιστρεφόμενο `RefMut` ή όλα τα «RefMut» που προέρχονται από το πεδίο εξόδου.
    ///
    /// Η τιμή δεν μπορεί να δανειστεί ενώ αυτό το δάνειο είναι ενεργό.
    ///
    /// # Panics
    ///
    /// Panics εάν η αξία είναι δανεισμένη αυτήν τη στιγμή.
    /// Για παραλλαγή χωρίς πανικό, χρησιμοποιήστε το [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Ένα παράδειγμα panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Δανείζεται αμοιβαία την αναδιπλούμενη τιμή, επιστρέφοντας ένα σφάλμα εάν η τιμή είναι δανεισμένη.
    ///
    ///
    /// Το δάνειο διαρκεί μέχρι το επιστρεφόμενο `RefMut` ή όλα τα «RefMut» που προέρχονται από το πεδίο εξόδου.
    /// Η τιμή δεν μπορεί να δανειστεί ενώ αυτό το δάνειο είναι ενεργό.
    ///
    /// Αυτή είναι η μη πανικοβλημένη παραλλαγή του [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // ΑΣΦΑΛΕΙΑ: Το `BorrowRef` εγγυάται μοναδική πρόσβαση.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Επιστρέφει έναν ακατέργαστο δείκτη στα υποκείμενα δεδομένα σε αυτό το κελί.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Επιστρέφει μια μεταβλητή αναφορά στα υποκείμενα δεδομένα.
    ///
    /// Αυτή η κλήση δανείζεται `RefCell` μεταβλητά (κατά το χρόνο μεταγλώττισης), επομένως δεν υπάρχει ανάγκη για δυναμικούς ελέγχους.
    ///
    /// Ωστόσο, να είστε προσεκτικοί: αυτή η μέθοδος αναμένει ότι το `self` είναι μεταβλητό, κάτι που γενικά δεν συμβαίνει όταν χρησιμοποιείτε `RefCell`.
    ///
    /// Αντ 'αυτού, ρίξτε μια ματιά στη μέθοδο [`borrow_mut`] εάν το `self` δεν είναι μεταβλητό.
    ///
    /// Επίσης, λάβετε υπόψη ότι αυτή η μέθοδος είναι μόνο για ειδικές περιστάσεις και συνήθως δεν είναι αυτό που θέλετε.
    /// Σε περίπτωση αμφιβολίας, χρησιμοποιήστε το [`borrow_mut`] αντ 'αυτού.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Αναίρεση της επίδρασης διαρροών φρουρών στην κατάσταση δανεισμού του `RefCell`.
    ///
    /// Αυτή η κλήση είναι παρόμοια με το [`get_mut`] αλλά πιο εξειδικευμένη.
    /// Δανείζεται `RefCell` αμετάβλητα για να διασφαλίσει ότι δεν υφίστανται δάνεια και, στη συνέχεια, επαναφέρει την κατάσταση παρακολούθησης κοινόχρηστων δανείων.
    /// Αυτό ισχύει εάν έχουν διαρρεύσει ορισμένα δάνεια `Ref` ή `RefMut`.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Δανείζεται αμετάβλητα την αναδιπλούμενη τιμή, επιστρέφοντας ένα σφάλμα εάν η τιμή αυτή τη στιγμή δανείζεται αμοιβαία.
    ///
    /// # Safety
    ///
    /// Σε αντίθεση με το `RefCell::borrow`, αυτή η μέθοδος δεν είναι ασφαλής επειδή δεν επιστρέφει `Ref`, αφήνοντας άθικτη τη σημαία δανεισμού.
    /// Ο αμοιβαίος δανεισμός του `RefCell` ενώ η αναφορά που επιστρέφεται με αυτήν τη μέθοδο είναι ζωντανή είναι απροσδιόριστη συμπεριφορά.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // ΑΣΦΑΛΕΙΑ: Ελέγουμε ότι κανείς δεν γράφει ενεργά τώρα, αλλά είναι
            // την ευθύνη του καλούντος να διασφαλίσει ότι κανείς δεν θα γράψει έως ότου η επιστρεφόμενη αναφορά δεν χρησιμοποιείται πλέον.
            // Επίσης, το `self.value.get()` αναφέρεται στην τιμή που ανήκει στο `self` και επομένως είναι εγγυημένο ότι ισχύει για τη διάρκεια ζωής του `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Παίρνει την τυλιγμένη τιμή, αφήνοντας το `Default::default()` στη θέση του.
    ///
    /// # Panics
    ///
    /// Panics εάν η αξία είναι δανεισμένη αυτήν τη στιγμή.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics εάν η αξία αυτή τη στιγμή δανείζεται αμοιβαία.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Δημιουργεί ένα `RefCell<T>`, με την τιμή `Default` για T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics εάν η τιμή και στα δύο `RefCell` είναι προς το παρόν δανεισμένη.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics εάν η τιμή και στα δύο `RefCell` είναι προς το παρόν δανεισμένη.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics εάν η τιμή και στα δύο `RefCell` είναι προς το παρόν δανεισμένη.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics εάν η τιμή και στα δύο `RefCell` είναι προς το παρόν δανεισμένη.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics εάν η τιμή και στα δύο `RefCell` είναι προς το παρόν δανεισμένη.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics εάν η τιμή και στα δύο `RefCell` είναι προς το παρόν δανεισμένη.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics εάν η τιμή και στα δύο `RefCell` είναι προς το παρόν δανεισμένη.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Η αύξηση του δανεισμού μπορεί να οδηγήσει σε τιμή μη ανάγνωσης (<=0) σε αυτές τις περιπτώσεις:
            // 1. Ήταν <0, δηλ. Υπάρχουν δανεισμοί, οπότε δεν μπορούμε να επιτρέψουμε ένα δανεισμό ανάγνωσης λόγω των κανόνων ψευδώνυμου αναφοράς του Rust
            // 2.
            // Ήταν isize::MAX (το μέγιστο ποσό ανάγνωσης δανείων) και υπερχείλιση σε isize::MIN (το μέγιστο ποσό δανεισμού δανεισμού), επομένως δεν μπορούμε να επιτρέψουμε ένα επιπλέον δανεισμό ανάγνωσης, επειδή το isize δεν μπορεί να αντιπροσωπεύει τόσα πολλά αναγνωσμένα δάνεια (αυτό μπορεί να συμβεί μόνο εάν εσείς mem::forget περισσότερο από μια μικρή σταθερή ποσότητα "Ref`s, η οποία δεν είναι καλή πρακτική)
            //
            //
            //
            //
            None
        } else {
            // Η αύξηση του δανεισμού μπορεί να οδηγήσει σε τιμή ανάγνωσης (> 0) σε αυτές τις περιπτώσεις:
            // 1. Ήταν=0, δηλαδή δεν δανείστηκε, και παίρνουμε το πρώτο ανάγνωση δανεισμού
            // 2. Ήταν> 0 και <isize::MAX, δηλαδή
            // υπήρχαν αναγνωσμένα δάνεια, και το μέγεθος είναι αρκετά μεγάλο για να αντιπροσωπεύει ένα ακόμη ανάγνωση δανεισμού
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Εφόσον υπάρχει αυτό το Ref, γνωρίζουμε ότι η σημαία δανεισμού είναι δανεισμός ανάγνωσης.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Αποτρέψτε το μετρητή δανεισμού να ξεχειλίζει σε δανεισμό.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Αναδιπλώνει μια δανεισμένη αναφορά σε μια τιμή σε ένα πλαίσιο `RefCell`.
/// Ένας τύπος περιτυλίγματος για μια αμετάβλητα δανεισμένη αξία από ένα `RefCell<T>`.
///
/// Δείτε το [module-level documentation](self) για περισσότερα.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Αντιγράφει ένα `Ref`.
    ///
    /// Το `RefCell` έχει ήδη δανειστεί αμετάβλητα, οπότε αυτό δεν μπορεί να αποτύχει.
    ///
    /// Αυτή είναι μια συσχετισμένη λειτουργία που πρέπει να χρησιμοποιηθεί ως `Ref::clone(...)`.
    /// Μια εφαρμογή `Clone` ή μια μέθοδος θα επηρεάσει την ευρεία χρήση του `r.borrow().clone()` για την κλωνοποίηση των περιεχομένων ενός `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Δημιουργεί ένα νέο `Ref` για ένα στοιχείο των δανεισμένων δεδομένων.
    ///
    /// Το `RefCell` έχει ήδη δανειστεί αμετάβλητα, οπότε αυτό δεν μπορεί να αποτύχει.
    ///
    /// Αυτή είναι μια συσχετισμένη λειτουργία που πρέπει να χρησιμοποιηθεί ως `Ref::map(...)`.
    /// Μια μέθοδος θα παρεμβαίνει σε μεθόδους του ίδιου ονόματος στα περιεχόμενα ενός `RefCell` που χρησιμοποιείται μέσω του `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Δημιουργεί ένα νέο `Ref` για ένα προαιρετικό στοιχείο των δανεισμένων δεδομένων.
    /// Το αρχικό προστατευτικό επιστρέφεται ως `Err(..)` εάν το κλείσιμο επιστρέφει `None`.
    ///
    /// Το `RefCell` έχει ήδη δανειστεί αμετάβλητα, οπότε αυτό δεν μπορεί να αποτύχει.
    ///
    /// Αυτή είναι μια συσχετισμένη λειτουργία που πρέπει να χρησιμοποιηθεί ως `Ref::filter_map(...)`.
    /// Μια μέθοδος θα παρεμβαίνει σε μεθόδους του ίδιου ονόματος στα περιεχόμενα ενός `RefCell` που χρησιμοποιείται μέσω του `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Διαχωρίζει ένα `Ref` σε πολλαπλά «Ref`s για διαφορετικά στοιχεία των δανεισμένων δεδομένων.
    ///
    /// Το `RefCell` έχει ήδη δανειστεί αμετάβλητα, οπότε αυτό δεν μπορεί να αποτύχει.
    ///
    /// Αυτή είναι μια συσχετισμένη λειτουργία που πρέπει να χρησιμοποιηθεί ως `Ref::map_split(...)`.
    /// Μια μέθοδος θα παρεμβαίνει σε μεθόδους του ίδιου ονόματος στα περιεχόμενα ενός `RefCell` που χρησιμοποιείται μέσω του `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Μετατροπή σε αναφορά στα υποκείμενα δεδομένα.
    ///
    /// Το υποκείμενο `RefCell` δεν μπορεί ποτέ να δανειστεί αμοιβαία και θα εμφανίζεται πάντα ήδη αμετάβλητα δανεισμένο.
    ///
    /// Δεν είναι καλή ιδέα να διαρρεύσετε περισσότερο από έναν σταθερό αριθμό αναφορών.
    /// Το `RefCell` μπορεί να δανειστεί αμετάβλητα εάν έχει συμβεί μόνο μικρότερος αριθμός διαρροών.
    ///
    /// Αυτή είναι μια συσχετισμένη λειτουργία που πρέπει να χρησιμοποιηθεί ως `Ref::leak(...)`.
    /// Μια μέθοδος θα παρεμβαίνει σε μεθόδους του ίδιου ονόματος στα περιεχόμενα ενός `RefCell` που χρησιμοποιείται μέσω του `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Ξεχνώντας αυτό το Ref διασφαλίζουμε ότι ο μετρητής δανεισμού στο RefCell δεν μπορεί να επιστρέψει σε Αχρησιμοποίητο εντός της διάρκειας ζωής `'b`.
        // Η επαναφορά της κατάστασης παρακολούθησης αναφοράς απαιτεί μια μοναδική αναφορά στο δανεισμένο RefCell.
        // Δεν μπορούν να δημιουργηθούν περαιτέρω μεταβλητές αναφορές από το αρχικό κελί.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Δημιουργεί ένα νέο `RefMut` για ένα στοιχείο των δανεισμένων δεδομένων, π.χ. μια παραλλαγή enum.
    ///
    /// Το `RefCell` έχει ήδη δανειστεί αμοιβαία, οπότε αυτό δεν μπορεί να αποτύχει.
    ///
    /// Αυτή είναι μια συσχετισμένη λειτουργία που πρέπει να χρησιμοποιηθεί ως `RefMut::map(...)`.
    /// Μια μέθοδος θα παρεμβαίνει σε μεθόδους του ίδιου ονόματος στα περιεχόμενα ενός `RefCell` που χρησιμοποιείται μέσω του `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): επιδιόρθωση δανείου-επιταγής
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Δημιουργεί ένα νέο `RefMut` για ένα προαιρετικό στοιχείο των δανεισμένων δεδομένων.
    /// Το αρχικό προστατευτικό επιστρέφεται ως `Err(..)` εάν το κλείσιμο επιστρέφει `None`.
    ///
    /// Το `RefCell` έχει ήδη δανειστεί αμοιβαία, οπότε αυτό δεν μπορεί να αποτύχει.
    ///
    /// Αυτή είναι μια συσχετισμένη λειτουργία που πρέπει να χρησιμοποιηθεί ως `RefMut::filter_map(...)`.
    /// Μια μέθοδος θα παρεμβαίνει σε μεθόδους του ίδιου ονόματος στα περιεχόμενα ενός `RefCell` που χρησιμοποιείται μέσω του `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): επιδιόρθωση δανείου-επιταγής
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // ΑΣΦΑΛΕΙΑ: η λειτουργία διατηρεί μια αποκλειστική αναφορά για τη διάρκεια
        // της κλήσης μέσω `orig` και ο δείκτης δεν αναφέρεται μόνο στο εσωτερικό της κλήσης λειτουργίας, επιτρέποντας ποτέ στην αποκλειστική αναφορά να διαφύγει.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // ΑΣΦΑΛΕΙΑ: όπως και παραπάνω.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Διαχωρίζει ένα `RefMut` σε πολλά «RefMut» για διαφορετικά στοιχεία των δανεισμένων δεδομένων.
    ///
    /// Το υποκείμενο `RefCell` θα παραμείνει αμοιβαία δανεισμένο έως ότου και οι δύο που επέστρεψαν το «RefMut» να βγουν εκτός εμβέλειας.
    ///
    /// Το `RefCell` έχει ήδη δανειστεί αμοιβαία, οπότε αυτό δεν μπορεί να αποτύχει.
    ///
    /// Αυτή είναι μια συσχετισμένη λειτουργία που πρέπει να χρησιμοποιηθεί ως `RefMut::map_split(...)`.
    /// Μια μέθοδος θα παρεμβαίνει σε μεθόδους του ίδιου ονόματος στα περιεχόμενα ενός `RefCell` που χρησιμοποιείται μέσω του `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Μετατροπή σε μεταβλητή αναφορά στα υποκείμενα δεδομένα.
    ///
    /// Το υποκείμενο `RefCell` δεν μπορεί να δανειστεί ξανά και θα εμφανίζεται πάντα ήδη αμοιβαία δανεισμένο, κάνοντας την επιστρεφόμενη αναφορά το μοναδικό στο εσωτερικό.
    ///
    ///
    /// Αυτή είναι μια συσχετισμένη λειτουργία που πρέπει να χρησιμοποιηθεί ως `RefMut::leak(...)`.
    /// Μια μέθοδος θα παρεμβαίνει σε μεθόδους του ίδιου ονόματος στα περιεχόμενα ενός `RefCell` που χρησιμοποιείται μέσω του `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Ξεχνώντας αυτό το BorrowRefMut διασφαλίζουμε ότι ο μετρητής δανεισμού στο RefCell δεν μπορεί να επιστρέψει στο UNUSED εντός της διάρκειας ζωής `'b`.
        // Η επαναφορά της κατάστασης παρακολούθησης αναφοράς απαιτεί μια μοναδική αναφορά στο δανεισμένο RefCell.
        // Δεν μπορούν να δημιουργηθούν περαιτέρω αναφορές από το αρχικό κελί εντός αυτής της διάρκειας ζωής, καθιστώντας το τρέχον δανεισμό τη μόνη αναφορά για την υπόλοιπη διάρκεια ζωής.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Σε αντίθεση με το BorrowRefMut::clone, το νέο καλείται για τη δημιουργία του αρχικού
        // μεταβλητή αναφορά, και επομένως δεν πρέπει να υπάρχουν υπάρχουσες αναφορές.
        // Έτσι, ενώ ο κλώνος αυξάνει τη μεταβλητή αναμέτρηση, εδώ επιτρέπουμε ρητά τη μετάβαση από το UNUSED στο UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Κλωνοποιεί ένα `BorrowRefMut`.
    //
    // Αυτό ισχύει μόνο εάν κάθε `BorrowRefMut` χρησιμοποιείται για την παρακολούθηση μιας μεταβλητής αναφοράς σε ένα ξεχωριστό, μη επικαλυπτόμενο εύρος του αρχικού αντικειμένου.
    //
    // Αυτό δεν είναι σε ένα Clone impl, οπότε ο κώδικας δεν το αποκαλεί σιωπηρά.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Αποτρέψτε την εκροή του μετρητή δανεισμού.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Ένας τύπος περιτυλίγματος για μια μεταβλητά δανεισμένη αξία από ένα `RefCell<T>`.
///
/// Δείτε το [module-level documentation](self) για περισσότερα.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Το βασικό πρωτόγονο για την εσωτερική μεταβλητότητα στο Rust.
///
/// Εάν έχετε μια αναφορά `&T`, τότε κανονικά στο Rust ο μεταγλωττιστής εκτελεί βελτιστοποιήσεις με βάση τη γνώση ότι το `&T` δείχνει αμετάβλητα δεδομένα.Η μετάλλαξη αυτών των δεδομένων, για παράδειγμα μέσω ψευδωνύμου ή μετάδοσης ενός `&T` σε `&mut T`, θεωρείται απροσδιόριστη συμπεριφορά.
/// `UnsafeCell<T>` εξαίρεση από την εγγύηση αμετάβλητης για το `&T`: μια κοινή αναφορά `&UnsafeCell<T>` ενδέχεται να δείχνει σε δεδομένα που μεταλλάσσονται.Αυτό ονομάζεται "interior mutability".
///
/// Όλοι οι άλλοι τύποι που επιτρέπουν εσωτερική μεταβλητότητα, όπως `Cell<T>` και `RefCell<T>`, χρησιμοποιούν εσωτερικά το `UnsafeCell` για να τυλίξουν τα δεδομένα τους.
///
/// Σημειώστε ότι μόνο η εγγύηση αμετάβλητης για κοινόχρηστες αναφορές επηρεάζεται από το `UnsafeCell`.Η εγγύηση μοναδικότητας για μεταβλητές αναφορές δεν επηρεάζεται.Δεν υπάρχει νόμιμος τρόπος για να αποκτήσετε το ψευδώνυμο `&mut`, ούτε καν με το `UnsafeCell<T>`.
///
/// Το ίδιο το `UnsafeCell` API είναι τεχνικά πολύ απλό: το [`.get()`] σας δίνει έναν ακατέργαστο δείκτη `*mut T` στο περιεχόμενό του.Εναπόκειται στο _you_ ως σχεδιαστής αφαίρεσης να χρησιμοποιήσει σωστά αυτόν τον ακατέργαστο δείκτη.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Οι ακριβείς κανόνες ψευδωνύμου Rust είναι κάπως σε εξέλιξη, αλλά τα κύρια σημεία δεν είναι αμφιλεγόμενα:
///
/// - Εάν δημιουργήσετε μια ασφαλή αναφορά με `'a` διάρκειας ζωής (είτε μια αναφορά `&T` ή `&mut T`) που είναι προσβάσιμη μέσω ασφαλούς κώδικα (για παράδειγμα, επειδή την επιστρέψατε), τότε δεν πρέπει να έχετε πρόσβαση στα δεδομένα με οποιονδήποτε τρόπο που έρχεται σε αντίθεση με αυτήν την αναφορά για το υπόλοιπο του `'a`.
/// Για παράδειγμα, αυτό σημαίνει ότι αν πάρετε το `*mut T` από ένα `UnsafeCell<T>` και το μεταδώσετε σε ένα `&T`, τότε τα δεδομένα στο `T` πρέπει να παραμείνουν αμετάβλητα (modulo τυχόν δεδομένα `UnsafeCell` που βρίσκονται μέσα στο `T`, φυσικά) έως ότου λήξει η διάρκεια ζωής της αναφοράς.
/// Ομοίως, εάν δημιουργήσετε μια αναφορά `&mut T` που έχει κυκλοφορήσει σε ασφαλή κώδικα, τότε δεν πρέπει να έχετε πρόσβαση στα δεδομένα εντός του `UnsafeCell` έως ότου λήξει αυτή η αναφορά.
///
/// - Πρέπει πάντα να αποφεύγετε τους αγώνες δεδομένων.Εάν πολλά νήματα έχουν πρόσβαση στο ίδιο `UnsafeCell`, τότε οποιεσδήποτε εγγραφές πρέπει να έχουν το σωστό συμβάν-πριν από τη σχέση με όλες τις άλλες προσβάσεις (ή χρησιμοποιήστε atomics).
///
/// Για να βοηθήσετε στη σωστή σχεδίαση, τα ακόλουθα σενάρια δηλώνονται ρητά νόμιμα για μονόστροφο κώδικα:
///
/// 1. Μια αναφορά `&T` μπορεί να κυκλοφορήσει σε ασφαλή κώδικα και εκεί μπορεί να συνυπάρχει με άλλες αναφορές `&T`, αλλά όχι με `&mut T`
///
/// 2. Μια αναφορά `&mut T` μπορεί να αποδεσμευτεί σε ασφαλή κώδικα υπό την προϋπόθεση ότι δεν συνυπάρχουν άλλα `&mut T` ούτε `&T`.Ένα `&mut T` πρέπει πάντα να είναι μοναδικό.
///
/// Λάβετε υπόψη ότι ενώ η μετάλλαξη των περιεχομένων ενός `&UnsafeCell<T>` (ακόμη και ενώ άλλες αναφορές `&UnsafeCell<T>` ψευδώνυμο το κελί) είναι εντάξει (υπό την προϋπόθεση ότι εφαρμόζετε τα παραπάνω αναλλοίωτα με άλλο τρόπο), εξακολουθεί να είναι απροσδιόριστη συμπεριφορά να έχετε πολλά ψευδώνυμα `&mut UnsafeCell<T>`.
/// Δηλαδή, το `UnsafeCell` είναι ένα περιτύλιγμα που έχει σχεδιαστεί για να έχει μια ειδική αλληλεπίδραση με το _shared_ accesses (_i.e._, μέσω μιας αναφοράς `&UnsafeCell<_>`).δεν υπάρχει καμία απολύτως μαγεία όταν ασχολείστε με το _exclusive_ accesses (_e.g._, μέσω ενός `&mut UnsafeCell<_>`): ούτε το κελί ούτε η τυλιγμένη τιμή μπορεί να αφαιρεθούν κατά τη διάρκεια αυτού του `&mut` δανεισμού.
///
/// Αυτό παρουσιάζεται από το [`.get_mut()`] accessor, το οποίο είναι ένα _safe_ getter που αποδίδει ένα `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Ακολουθεί ένα παράδειγμα που δείχνει πώς να μεταλλαχθούν σωστά τα περιεχόμενα ενός `UnsafeCell<_>` παρά το γεγονός ότι υπάρχουν πολλές αναφορές που απομακρύνουν το κελί:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Λάβετε πολλές/ταυτόχρονες/κοινόχρηστες αναφορές στο ίδιο `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // ΑΣΦΑΛΕΙΑ: σε αυτό το πεδίο δεν υπάρχουν άλλες αναφορές στα περιεχόμενα του «x»,
///     // έτσι το δικό μας είναι πραγματικά μοναδικό.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- δανεισμός-+
///     *p1_exclusive += 27; // |
/// } // <---------- δεν μπορεί να υπερβεί αυτό το σημείο -------------------+
///
/// unsafe {
///     // ΑΣΦΑΛΕΙΑ: στο πλαίσιο αυτό κανείς δεν περιμένει να έχει αποκλειστική πρόσβαση στα περιεχόμενα του «x»,
///     // έτσι μπορούμε να έχουμε πολλές κοινόχρηστες προσβάσεις ταυτόχρονα.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Το ακόλουθο παράδειγμα δείχνει το γεγονός ότι η αποκλειστική πρόσβαση σε ένα `UnsafeCell<T>` συνεπάγεται αποκλειστική πρόσβαση στο `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // με αποκλειστικές προσβάσεις,
///                         // `UnsafeCell` είναι ένα διαφανές περιτύλιγμα no-op, οπότε δεν υπάρχει ανάγκη για `unsafe` εδώ.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Αποκτήστε μια μοναδική αναφορά ελέγχου-χρόνου ελέγχου στο `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Με αποκλειστική αναφορά, μπορούμε να μεταλλάξουμε το περιεχόμενο δωρεάν.
/// *p_unique.get_mut() = 0;
/// // Ή, ισοδύναμα:
/// x = UnsafeCell::new(0);
///
/// // Όταν κατέχουμε την τιμή, μπορούμε να εξαγάγουμε το περιεχόμενο δωρεάν.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Κατασκευάζει μια νέα παρουσία του `UnsafeCell` που θα περιτυλίξει την καθορισμένη τιμή.
    ///
    ///
    /// Όλη η πρόσβαση στην εσωτερική τιμή μέσω μεθόδων είναι `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Ξετυλίγει την τιμή.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Παίρνει έναν μεταβλητό δείκτη στην αναδιπλούμενη τιμή.
    ///
    /// Αυτό μπορεί να μεταφερθεί σε οποιοδήποτε δείκτη.
    /// Βεβαιωθείτε ότι η πρόσβαση είναι μοναδική (χωρίς ενεργές αναφορές, μεταβλητές ή όχι) κατά τη μετάδοση στο `&mut T` και βεβαιωθείτε ότι δεν υπάρχουν μεταλλάξεις ή μεταβλητά ψευδώνυμα κατά τη μετάδοση στο `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Μπορούμε απλώς να μεταδώσουμε το δείκτη από το `UnsafeCell<T>` στο `T` λόγω του #[repr(transparent)].
        // Αυτό εκμεταλλεύεται την ειδική κατάσταση του libstd, δεν υπάρχει καμία εγγύηση για τον κωδικό χρήστη ότι αυτό θα λειτουργεί σε εκδόσεις future του μεταγλωττιστή!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Επιστρέφει μια μεταβλητή αναφορά στα υποκείμενα δεδομένα.
    ///
    /// Αυτή η κλήση δανείζεται το `UnsafeCell` αμετάβλητα (κατά το χρόνο μεταγλώττισης) που εγγυάται ότι διαθέτουμε τη μοναδική αναφορά.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Παίρνει έναν μεταβλητό δείκτη στην αναδιπλούμενη τιμή.
    /// Η διαφορά στο [`get`] είναι ότι αυτή η συνάρτηση δέχεται έναν ακατέργαστο δείκτη, ο οποίος είναι χρήσιμος για να αποφευχθεί η δημιουργία προσωρινών αναφορών.
    ///
    /// Το αποτέλεσμα μπορεί να μεταφερθεί σε οποιοδήποτε δείκτη.
    /// Βεβαιωθείτε ότι η πρόσβαση είναι μοναδική (χωρίς ενεργές αναφορές, μεταβλητές ή όχι) κατά τη μετάδοση στο `&mut T` και βεβαιωθείτε ότι δεν υπάρχουν μεταλλάξεις ή μεταβλητά ψευδώνυμα κατά τη μετάδοση στο `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Η σταδιακή εκκίνηση ενός `UnsafeCell` απαιτεί `raw_get`, καθώς η κλήση του `get` θα απαιτούσε τη δημιουργία αναφοράς σε μη αρχικοποιημένα δεδομένα:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Μπορούμε απλώς να μεταδώσουμε το δείκτη από το `UnsafeCell<T>` στο `T` λόγω του #[repr(transparent)].
        // Αυτό εκμεταλλεύεται την ειδική κατάσταση του libstd, δεν υπάρχει καμία εγγύηση για τον κωδικό χρήστη ότι αυτό θα λειτουργεί σε εκδόσεις future του μεταγλωττιστή!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Δημιουργεί ένα `UnsafeCell`, με την τιμή `Default` για T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}