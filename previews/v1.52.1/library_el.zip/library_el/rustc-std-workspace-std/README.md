# Το `rustc-std-workspace-std` crate

Δείτε την τεκμηρίωση για το `rustc-std-workspace-core` crate.