//! Implementación de panics a través do desenrolo de pila
//!
//! Este crate é unha implementación de panics en Rust usando o mecanismo de desenrolo da pila "most native" da plataforma para a que se está a compilar.
//! Isto básicamente clasifícase actualmente en tres cubos:
//!
//! 1. Os obxectivos MSVC usan SEH no ficheiro `seh.rs`.
//! 2. Emscripten usa excepcións C++ no ficheiro `emcc.rs`.
//! 3. Os demais obxectivos usan libunwind/libgcc no ficheiro `gcc.rs`.
//!
//! Pódese atopar máis documentación sobre cada implementación no módulo respectivo.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` non se usa con Miri, polo que silenciar as advertencias.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Os obxectos de inicio do tempo de execución de Rust dependen destes símbolos, así que fágaos públicos.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Obxectivos que non admiten desconectar.
        // - arch=wasm32
        // - os=none (obxectivos "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Usa o tempo de execución de Miri.
        // Aínda necesitamos cargar o tempo de execución normal anterior, xa que rustc espera que se definan certos elementos de lang a partir de aí.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Usa o tempo de execución real.
        use real_imp as imp;
    }
}

extern "C" {
    /// Chamouse o manipulador en libstd cando se deixa caer un obxecto panic fóra de `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Chamouse a manipulador en libstd cando se captura unha excepción estranxeira.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Punto de entrada para levantar unha excepción, só delegue na implementación específica da plataforma.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}