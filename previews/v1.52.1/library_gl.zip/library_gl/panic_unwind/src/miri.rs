//! Desconectando panics para Miri.
use alloc::boxed::Box;
use core::any::Any;

// O tipo de carga útil que o motor Miri propaga a través do desenrolo para nós.
// Debe ter o tamaño do punteiro.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Función externa proporcionada por Miri para comezar a desconectar.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // A carga útil que pasamos a `miri_start_panic` será exactamente o argumento que obtemos en `cleanup` a continuación.
    // Entón, só o encaixamos unha vez para conseguir algo do tamaño dun punteiro.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Recupere o `Box` subxacente.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}