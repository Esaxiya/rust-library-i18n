//! Windows SEH
//!
//! En Windows (actualmente só en MSVC), o mecanismo de xestión de excepcións predeterminado é Structured Exception Handling (SEH).
//! Isto é bastante diferente ao manexo de excepcións baseado en ananos (por exemplo, o que usan outras plataformas unix) en termos de compoñentes internos, polo que LLVM ten que ter unha boa cantidade de soporte adicional para SEH.
//!
//! En poucas palabras, o que acontece aquí é:
//!
//! 1. A función `panic` chama á función Windows estándar `_CxxThrowException` para lanzar unha excepción similar a C++ , desencadeando o proceso de desenrolo.
//! 2.
//! Todas as almofadas xeradas polo compilador utilizan a función de personalidade `__CxxFrameHandler3`, unha función no CRT, e o código de desenrolo en Windows usará esta función de personalidade para executar todo o código de limpeza da pila.
//!
//! 3. Todas as chamadas xeradas polo compilador a `invoke` teñen unha pista de aterraxe configurada como unha instrución `cleanuppad` LLVM, que indica o inicio da rutina de limpeza.
//! A personalidade (no paso 2, definida no CRT) é a responsable de executar as rutinas de limpeza.
//! 4. Finalmente execútase o código "catch" no `try` intrínseco (xerado polo compilador) e indica que o control debería volver a Rust.
//! Isto faise mediante unha instrución `catchswitch` máis unha `catchpad` en termos IR LLVM, devolvendo finalmente o control normal ao programa cunha instrución `catchret`.
//!
//! Algunhas diferenzas específicas do tratamento de excepcións baseado en gcc son:
//!
//! * Rust non ten ningunha función de personalidade personalizada, senón que é *sempre*`__CxxFrameHandler3`.Ademais, non se realiza ningún filtro adicional, polo que acabamos capturando calquera excepción de C++ que pareza do tipo que estamos lanzando.
//! Ten en conta que lanzar unha excepción a Rust é un comportamento indefinido de todos os xeitos, polo que debería estar ben.
//! * Temos algúns datos que transmitir a través do límite de desenrolo, concretamente un `Box<dyn Any + Send>`.Como ocorre coas excepcións de Dwarf, estes dous punteiros almacénanse como carga útil na propia excepción.
//! Non obstante, en MSVC non hai necesidade dunha asignación de pila adicional porque a pila de chamadas consérvase mentres se executan as funcións de filtro.
//! Isto significa que os punteiros pasan directamente a `_CxxThrowException` que logo se recuperan na función de filtro para escribilos no cadro de pila do `try` intrínseco.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Esta ten que ser unha opción porque capturamos a excepción por referencia e o seu destructor é executado polo tempo de execución C++ .
    // Cando sacamos a caixa da excepción, debemos deixar a excepción nun estado válido para que o seu destructor funcione sen soltar a caixa dúas veces.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// En primeiro lugar, unha chea de definicións de tipos.Aquí hai algunhas rarezas específicas da plataforma e moitas que se copian descaradamente de LLVM.O propósito de todo isto é implementar a seguinte función `panic` mediante unha chamada a `_CxxThrowException`.
//
// Esta función leva dous argumentos.O primeiro é un punteiro aos datos que estamos pasando, que neste caso é o noso obxecto trait.Moi sinxelo de atopar.O seguinte, con todo, é máis complicado.
// Este é un punteiro cara a unha estrutura `_ThrowInfo` e, polo xeral, só pretende describir a excepción que se está lanzando.
//
// Actualmente a definición deste tipo [1] é un pouco peluda e a rareza principal (e a diferenza do artigo en liña) é que en 32 bits os punteiros son punteiros pero en 64 bits os punteiros exprésanse como compensacións de 32 bits Símbolo `__ImageBase`.
//
// A macro `ptr_t` e `ptr!` dos módulos de abaixo úsanse para expresalo.
//
// O labirinto de definicións de tipos tamén segue de preto o que LLVM emite para este tipo de operacións.Por exemplo, se compila este código C++ en MSVC e emite o IR LLVM:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      void foo() { rust_panic a = {0, 1};
//          botar un;}
//
// Iso é esencialmente o que intentamos imitar.A maioría dos valores constantes a continuación acaban de copiarse de LLVM,
//
// En calquera caso, todas estas estruturas están construídas dun xeito similar e son algo detalladas para nós.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Teña en conta que aquí ignoramos intencionadamente as regras de manipulación de nomes: non queremos que C++ poida capturar Rust panics simplemente declarando un `struct rust_panic`.
//
//
// Ao modificar, asegúrese de que a cadea de nome do tipo coincida exactamente coa usada en `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // O byte principal `\x01` aquí é en realidade un sinal máxico para que LLVM non aplique ningún outro mangle como o prefixo cun carácter `_`.
    //
    //
    // Este símbolo é a táboa vt utilizada polo `std::type_info` de C++ .
    // Os obxectos do tipo `std::type_info`, descritores de tipos, teñen un punteiro para esta táboa.
    // Os descritores de tipos fan referencia ás estruturas C++ EH definidas anteriormente e que construimos a continuación.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Este descriptor de tipo só se usa cando se lanza unha excepción.
// A parte de captura está xestionada polo try intrínseco, que xera o seu propio TypeDescriptor.
//
// Está ben xa que o tempo de execución de MSVC usa a comparación de cadeas no nome do tipo para coincidir con TypeDescriptors en lugar da igualdade do punteiro.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor usado se o código C++ decide capturar a excepción e soltala sen propagala.
// A parte de captura do try intrínseco establecerá a primeira palabra do obxecto de excepción en 0 para que o destrúa o salte.
//
// Teña en conta que x86 Windows usa a convención de chamada "thiscall" para funcións de membro C++ en lugar da convención de chamadas "C" predeterminada.
//
// A función exception_copy é un pouco especial aquí: é invocada polo tempo de execución MSVC baixo un bloque try/catch e o panic que xeramos aquí usarase como resultado da copia de excepción.
//
// Este é o tempo de execución de C++ para soportar a captura de excepcións con std::exception_ptr, que non podemos soportar porque Box<dyn Any>non é clonable.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException execútase enteiramente neste marco de pila, polo que non é necesario transferir `data` ao montón.
    // Só pasamos un punteiro de pila a esta función.
    //
    // O ManuallyDrop é necesario aquí porque non queremos que caia a excepción ao desconectar.
    // En vez diso, caerá en exception_cleanup que é invocado polo tempo de execución C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Isto ... pode parecer sorprendente e xustificadamente.En MSVC de 32 bits, os punteiros entre estas estruturas son só iso, os punteiros.
    // No MSVC de 64 bits, con todo, os punteiros entre estruturas exprésanse máis ben como compensacións de 32 bits de `__ImageBase`.
    //
    // En consecuencia, en MSVC de 32 bits podemos declarar todos estes punteiros no `estático` anterior.
    // En MSVC de 64 bits, teriamos que expresar a resta de punteiros en estatica, o que Rust non permite actualmente, polo que non podemos facelo.
    //
    // A seguinte mellor cousa é encher estas estruturas en tempo de execución (o pánico xa é o "slow path").
    // Entón, aquí reinterpretamos todos estes campos de punteiro como enteiros de 32 bits e logo almacenamos o valor relevante nel (atómicamente, xa que pode estar a suceder panics concorrente).
    //
    // Tecnicamente, o tempo de execución probablemente fará unha lectura non atómica destes campos, pero en teoría nunca len o valor *incorrecto* polo que non debería estar moi mal ...
    //
    // En calquera caso, basicamente necesitamos facer algo así ata que poidamos expresar máis operacións en estática (e quizais nunca sexamos capaces de facelo).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Unha carga útil NULL aquí significa que chegamos aquí pola captura (...) de __rust_try.
    // Isto ocorre cando se captura unha excepción estranxeira que non é Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// O compilador esixe isto para existir (por exemplo, é un elemento lang), pero nunca o chama o compilador porque __C_specific_handler ou_except_handler3 é a función de personalidade que sempre se usa.
//
// Por iso, isto é só un talón abortante.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}