# O `rustc-std-workspace-std` crate

Consulte a documentación para o `rustc-std-workspace-core` crate.