//! Un módulo para axudar na xestión de enlaces dbghelp en Windows
//!
//! As pistas traseiras de Windows (polo menos para MSVC) son alimentadas en gran parte a través de `dbghelp.dll` e as distintas funcións que contén.
//! Estas funcións están cargadas *dinámicamente* en lugar de ligalas a `dbghelp.dll` de xeito estático.
//! Isto faino actualmente na biblioteca estándar (e en teoría é necesario alí), pero é un esforzo para axudar a reducir as dependencias estáticas de dll dunha biblioteca xa que as trazas de fondo normalmente son bastante opcionais.
//!
//! Dito isto, `dbghelp.dll` case sempre se carga con éxito en Windows.
//!
//! Teña en conta que, dado que estamos cargando todo este soporte de forma dinámica, non podemos realmente usar as definicións en bruto de `winapi`, senón que precisamos definir nós mesmos os tipos de punteiro de función e usalo.
//! Realmente non queremos estar no negocio de duplicar winapi, polo que temos unha función Cargo `verify-winapi` que afirma que todas as combinacións coinciden coas de winapi e esta función está habilitada en CI.
//!
//! Finalmente, observarás aquí que a dll para `dbghelp.dll` nunca se descarga, e que actualmente é intencionada.
//! O pensamento é que podemos almacenalo en caché a nivel mundial e usalo entre chamadas á API, evitando o caro loads/unloads.
//! Se isto é un problema para os detectores de fugas ou algo así podemos cruzar a ponte cando cheguemos alí.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Traballa en torno a `SymGetOptions` e `SymSetOptions` sen estar presente no propio winapi.
// Se non, isto só se usa cando comprobamos de novo os tipos contra winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Aínda non está definido en winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Isto defínese en winapi, pero é incorrecto (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Aínda non está definido en winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Esta macro úsase para definir unha estrutura `Dbghelp` que contén internamente todos os indicadores de función que poderiamos cargar.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// A DLL cargada para `dbghelp.dll`
            dll: HMODULE,

            // Podemos usar cada punteiro de función para cada función
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Inicialmente non cargamos a DLL
            dll: 0 as *mut _,
            // Inicialmente todas as funcións están definidas a cero para dicir que deben cargarse dinámicamente.
            //
            $($name: 0,)*
        };

        // Comodidade tipificada para cada tipo de función.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Tenta abrir `dbghelp.dll`.
            /// Devolve o éxito se funciona ou o erro se falla `LoadLibraryW`.
            ///
            /// Panics se a biblioteca xa está cargada.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Función para cada método que nos gustaría empregar.
            // Cando se chama, lerá o punteiro de función na caché ou cargará e devolverá o valor cargado.
            // Afírmase cargas para ter éxito.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Conveniente proxy para usar os bloqueos de limpeza para facer referencia ás funcións de dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Inicialice todo o soporte necesario para acceder ás funcións da API `dbghelp` dende este crate.
///
///
/// Teña en conta que esta función é **segura**, ten internamente a súa propia sincronización.
/// Teña en conta tamén que é seguro chamar esta función varias veces recursivamente.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // O primeiro que debemos facer é sincronizar esta función.Isto pódese chamar simultaneamente desde outros fíos ou recursivamente nun fío.
        // Teña en conta que é máis complicado que iso porque o que estamos a usar aquí, `dbghelp`,*tamén* ten que estar sincronizado con todos os demais que chaman a `dbghelp` neste proceso.
        //
        // Normalmente non hai moitas chamadas a `dbghelp` dentro do mesmo proceso e probablemente podemos asumir con seguridade que somos os únicos que accedemos a el.
        // Non obstante, hai outro usuario principal co que nos preocupamos, ironicamente, pero na biblioteca estándar.
        // A biblioteca estándar Rust depende deste crate para a compatibilidade coa traza de fondo, e este crate tamén existe en crates.io.
        // Isto significa que se a biblioteca estándar está a imprimir unha traza traseira panic pode correr con este crate procedente de crates.io, causando fallos.
        //
        // Para axudar a resolver este problema de sincronización empregamos aquí un truco específico de Windows (é, ao cabo, unha restrición específica de Windows sobre a sincronización).
        // Creamos un *session-local* chamado mutex para protexer esta chamada.
        // A intención aquí é que a biblioteca estándar e este crate non teñan que compartir as API de nivel Rust para sincronizalos aquí, senón que poden traballar entre bastidores para asegurarse de que se están a sincronizar entre si.
        //
        // Deste xeito, cando se chama esta función a través da biblioteca estándar ou a través de crates.io, podemos estar seguros de que se está a adquirir o mesmo mutex.
        //
        // Entón, todo isto é dicir que o primeiro que facemos aquí é crear atomicamente un `HANDLE` que é un mutex chamado en Windows.
        // Sincronizamos un pouco con outros fíos que comparten esta función específicamente e aseguramos que só se crea un identificador por instancia desta función.
        // Teña en conta que o identificador nunca se pecha unha vez que se garda no global.
        //
        // Despois de pasar o bloqueo, simplemente adquirímolo e o mango `Init` que repartimos será o responsable de soltalo eventualmente.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Agora que estamos sincronizados con seguridade, imos comezar a procesar todo.
        // Primeiro debemos asegurarnos de que `dbghelp.dll` está realmente cargado neste proceso.
        // Facémolo dinámicamente para evitar unha dependencia estática.
        // Historicamente, isto fíxose para solucionar problemas de conexión estraños e está destinado a facer os binarios un pouco máis portátiles, xa que en gran parte só é unha utilidade de depuración.
        //
        //
        // Unha vez que abrimos `dbghelp.dll`, necesitamos chamar a algunhas funcións de inicialización, e iso detállase máis abaixo.
        // Non obstante, só o facemos unha vez, polo que temos un booleano global que indica se acabamos ou non.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Asegúrese de que a bandeira `SYMOPT_DEFERRED_LOADS` está configurada, porque segundo os propios documentos de MSVC sobre isto: "This is the fastest, most efficient way to use the symbol handler.", entón imos facelo.
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Realice inicialmente os símbolos con MSVC.Teña en conta que isto pode fallar, pero ignorámolo.
        // Non hai unha tonelada de arte anterior para si per se, pero LLVM internamente parece ignorar o valor de retorno aquí e unha das bibliotecas de desinfectante de LLVM imprime unha advertencia de medo se falla pero basicamente ignóraa a longo prazo.
        //
        //
        // Un caso que sae moito para Rust é que a biblioteca estándar e este crate en crates.io queren competir por `SymInitializeW`.
        // A biblioteca estándar quería inicializar e despois limpar a maior parte do tempo, pero agora que está a usar este crate significa que alguén chegará primeiro á inicialización e o outro recollerá esa inicialización.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}