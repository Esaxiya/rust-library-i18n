use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr recibe unha devolución de chamada que recibirá un punteiro dl_phdr_info por cada DSO ligado ao proceso.
    // dl_iterate_phdr tamén garante que o enlazador dinámico estea bloqueado de principio a fin da iteración.
    // Se a devolución de chamada devolve un valor diferente de cero, a iteración terminará antes.
    // 'data' pasarase como terceiro argumento á devolución de chamada en cada chamada.
    // 'size' dá o tamaño do dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Necesitamos analizar a ID de compilación e algúns datos básicos da cabeceira do programa, o que significa que tamén necesitamos un pouco de información da especificación ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Agora temos que replicar, bit por bit, a estrutura do tipo dl_phdr_info usado polo ligador dinámico actual de fucsia.
// Chromium tamén ten este límite ABI e crashpad.
// Finalmente, gustaríanos mover estes casos para usar elf-search, pero teriamos que proporcionalo no SDK e iso aínda non se fixo.
//
// Así, nós (e eles) quedamos atrapados tendo que usar este método que incorre nun acoplamento axustado co libc fucsia.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Non temos forma de saber comprobar se e_phoff e e_phnum son válidos.
    // libc debería asegurarnos para nós, polo que é seguro formar unha porción aquí.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr representa un encabezado de programa ELF de 64 bits no endianness da arquitectura de destino.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr representa unha cabeceira de programa ELF válida e o seu contido.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Non temos forma de comprobar se p_addr ou p_memsz son válidos.
    // O libc de Fuchsia analiza as notas primeiro, por iso, en virtude de estar aquí estas cabeceiras deben ser válidas.
    //
    // NoteIter non require que os datos subxacentes sexan válidos pero si os límites para que sexan válidos.
    // Confiamos en que libc asegurou que este é o noso caso aquí.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// O tipo de nota para os ID de compilación.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr representa un encabezado de nota ELF no destino do destino.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// A nota representa unha nota ELF (cabeceira + contido).
// O nome déixase como unha porción u8 porque non sempre está rematada nulo e rust facilita o suficiente para comprobar que os bytes coinciden de calquera xeito.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter permítelle repetir con seguridade un segmento de nota.
// Remata en canto se produce un erro ou xa non hai máis notas.
// Se itera sobre datos non válidos, funcionará coma se non se atopasen notas.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // É unha función invariante que o punteiro e o tamaño indicados denotan un rango válido de bytes que se poden ler todos.
    // O contido destes bytes pode ser calquera, pero o intervalo debe ser válido para que isto sexa seguro.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to aliña 'x' ao aliñamento de "a" bytes asumindo que 'to' é unha potencia de 2.
// Isto segue un patrón estándar no código de análise ELF C/C ++ onde se usa (x + to, 1) e -to.
// Rust non che permite negar usize polo que eu uso
// Conversión do complemento de 2 para recrear iso.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 consume num bytes da porción (se está presente) e garante ademais que a porción final estea correctamente aliñada.
// Se o número de bytes solicitados é demasiado grande ou despois non se pode reasignar a porción debido a que non existen suficientes bytes restantes, devólvese Ningún e a porción non se modifica.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Esta función non ten invariantes reais que o interlocutor debe manter, agás que 'bytes' debería estar aliñado para o seu rendemento (e con algunhas arquitecturas).
// Os valores nos campos Elf_Nhdr poden ser un disparate pero esta función non garante tal cousa.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Isto é seguro sempre que haxa espazo suficiente e acabamos de confirmar que na declaración if anterior non debería ser seguro.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Teña en conta que sice_of: :<Elf_Nhdr>() sempre está aliñado de 4 bytes.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Comproba se chegamos ao final.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Transmutamos un nhdr pero consideramos detidamente a estrutura resultante.
        // Non confiamos no namesz ou descsz e non tomamos decisións inseguras en función do tipo.
        //
        // Entón, aínda que saquemos lixo completo, deberiamos estar seguros.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Indica que un segmento é executable.
const PERM_X: u32 = 0b00000001;
/// Indica que un segmento é escribible.
const PERM_W: u32 = 0b00000010;
/// Indica que un segmento é lexible.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Representa un segmento ELF en tempo de execución.
struct Segment {
    /// Ofrece o enderezo virtual de execución dos contidos deste segmento.
    addr: usize,
    /// Dá o tamaño da memoria do contido deste segmento.
    size: usize,
    /// Ofrece o enderezo virtual do módulo deste segmento co ficheiro ELF.
    mod_rel_addr: usize,
    /// Ofrece os permisos atopados no ficheiro ELF.
    /// Non obstante, estes permisos non son necesariamente os permisos presentes no tempo de execución.
    flags: Perm,
}

/// Permite repetir os segmentos dun DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Representa un ELF DSO (Dynamic Shared Object).
/// Este tipo fai referencia aos datos almacenados no DSO real en lugar de facer a súa propia copia.
struct Dso<'a> {
    /// O ligador dinámico sempre nos dá un nome, aínda que o nome estea baleiro.
    /// No caso do executable principal este nome estará baleiro.
    /// No caso dun obxecto compartido será o soname (ver DT_SONAME).
    name: &'a str,
    /// En Fuchsia, practicamente todos os binarios teñen ID de compilación, pero este non é un requirimento estricto.
    /// Non hai ningunha forma de emparellar a información DSO cun ficheiro ELF real despois se non hai build_id polo que requirimos que cada DSO teña aquí.
    ///
    /// Os DSO sen build_id son ignorados.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Devolve un iterador sobre segmentos neste DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Estes erros codifican os problemas que xorden ao analizar información sobre cada DSO.
///
enum Error {
    /// NameError significa que se produciu un erro ao converter unha cadea de estilo C nunha cadea rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError significa que non atopamos un ID de compilación.
    /// Isto podería deberse a que o DSO non tiña ningún ID de compilación ou porque o segmento que contén o ID de compilación estaba mal formado.
    ///
    BuildIDError,
}

/// Chama 'dso' ou 'error' para cada DSO ligado ao proceso polo ligador dinámico.
///
///
/// # Arguments
///
/// * `visitor` - Un DsoPrinter que terá un dos métodos de consumo chamado foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr garante que info.name apuntará a unha localización válida.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Esta función imprime a marca do simbolizador fucsia para toda a información contida nun DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}