use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Resolve un enderezo a un símbolo, pasándoo ao peche especificado.
///
/// Esta función buscará o enderezo indicado en áreas como a táboa de símbolos local, a táboa de símbolos dinámica ou a información de depuración DWARF (dependendo da implementación activada) para atopar símbolos que ceder.
///
///
/// O peche non se pode chamar se non se puido realizar a resolución e tamén se pode chamar máis dunha vez no caso de funcións en liña.
///
/// Os símbolos producidos representan a execución no `addr` especificado, devolvendo pares file/line para ese enderezo (se está dispoñible).
///
/// Teña en conta que se ten un `Frame`, recoméndase usar a función `resolve_frame` no canto desta.
///
/// # Funcións necesarias
///
/// Esta función require que a función `std` do `backtrace` crate estea habilitada e a función `std` estea habilitada de xeito predeterminado.
///
/// # Panics
///
/// Esta función procura nunca panic, pero se o `cb` proporcionou panics, entón algunhas plataformas obrigarán a un panic dobre para abortar o proceso.
/// Algunhas plataformas usan unha biblioteca C que utiliza internamente devolucións de chamada que non se poden desfacer, polo que o pánico de `cb` pode provocar un proceso de interrupción.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // só mire o cadro superior
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Resolve un marco de captura previamente a un símbolo, pasándoo ao peche especificado.
///
/// Esta función realiza a mesma función que `resolve`, excepto que toma un `Frame` como argumento no canto de enderezo.
/// Isto pode permitir que algunhas implementacións de plataforma de retrotrasado proporcionen información de símbolos máis precisa ou información sobre marcos en liña, por exemplo.
///
/// Recoméndase usar isto se pode.
///
/// # Funcións necesarias
///
/// Esta función require que a función `std` do `backtrace` crate estea habilitada e a función `std` estea habilitada de xeito predeterminado.
///
/// # Panics
///
/// Esta función procura nunca panic, pero se o `cb` proporcionou panics, entón algunhas plataformas obrigarán a un panic dobre para abortar o proceso.
/// Algunhas plataformas usan unha biblioteca C que utiliza internamente devolucións de chamada que non se poden desfacer, polo que o pánico de `cb` pode provocar un proceso de interrupción.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // só mire o cadro superior
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Os valores IP dos cadros de pila adoitan ser (always?) a instrución *despois da* chamada que é o trazado de pila real.
// Simbolizando isto, o número filename/line estará un por diante e quizais no baleiro se está preto do final da función.
//
// Parece que isto ocorre basicamente en todas as plataformas, polo que sempre restamos un dunha ip resolta para resolvela á instrución de chamada anterior en lugar de devolver a instrución.
//
//
// O ideal non sería facer isto.
// O ideal sería que aquí requirísemos aos chamadores das API `resolve` para que fagan manualmente o -1 e teñan en conta que queren información de localización para a instrución *anterior*, non a actual.
// O ideal sería que expuxeramos o `Frame` se realmente somos a dirección da seguinte instrución ou a actual.
//
// Por agora, aínda que isto é un problema de nicho, só internamente restamos un.
// Os consumidores deberían seguir traballando e obter resultados bastante bos, polo que deberiamos ser o suficientemente bos.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Igual que `resolve`, só non seguro xa que non está sincronizado.
///
/// Esta función non ten garantidos de sincronización pero está dispoñible cando a función `std` deste crate non se compila.
/// Consulte a función `resolve` para obter máis documentación e exemplos.
///
/// # Panics
///
/// Consulte a información sobre `resolve` para obter advertencias sobre o pánico de `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Igual que `resolve_frame`, só non seguro xa que non está sincronizado.
///
/// Esta función non ten garantidos de sincronización pero está dispoñible cando a función `std` deste crate non se compila.
/// Consulte a función `resolve_frame` para obter máis documentación e exemplos.
///
/// # Panics
///
/// Consulte a información sobre `resolve_frame` para obter advertencias sobre o pánico de `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Un trait que representa a resolución dun símbolo nun ficheiro.
///
/// Este trait cédese como obxecto trait ao peche dado á función `backtrace::resolve` e está practicamente enviado xa que se descoñece que implementación hai detrás.
///
///
/// Un símbolo pode dar información contextual sobre unha función, por exemplo o nome, nome de ficheiro, número de liña, enderezo preciso, etc.
/// Non obstante, non sempre está dispoñible toda a información nun símbolo, polo que todos os métodos devolven un `Option`.
///
///
pub struct Symbol {
    // TODO: este límite de toda a vida debe persistirse eventualmente ata `Symbol`,
    // pero iso é un cambio actual.
    // Por agora isto é seguro xa que `Symbol` só se entrega por referencia e non se pode clonar.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Devolve o nome desta función.
    ///
    /// A estrutura devolta pode usarse para consultar varias propiedades sobre o nome do símbolo:
    ///
    ///
    /// * A implementación `Display` imprimirá o símbolo desmangado.
    /// * Pódese acceder ao valor bruto `str` do símbolo (se é utf-8 válido).
    /// * Pódese acceder aos bytes en bruto para o nome do símbolo.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Devolve o enderezo inicial desta función.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Devolve o nome de ficheiro en bruto como unha porción.
    /// Isto é útil principalmente para ambientes `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Devolve o número de columna onde se está executando este símbolo.
    ///
    /// Na actualidade, só gimli proporciona un valor aquí e aínda entón só se `filename` devolve `Some`, polo que está suxeito a advertencias similares.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Devolve o número de liña onde se está executando este símbolo.
    ///
    /// Este valor devolto é normalmente `Some` se `filename` devolve `Some` e, en consecuencia, está suxeito a advertencias similares.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Devolve o nome do ficheiro onde se definiu esta función.
    ///
    /// Isto só está dispoñible actualmente cando se está a usar libbacktrace ou gimli (por exemplo
    /// unix outras plataformas) e cando se compila un binario con debuginfo.
    /// Se non se cumpre ningunha destas condicións, é probable que devolva `None`.
    ///
    /// # Funcións necesarias
    ///
    /// Esta función require que a función `std` do `backtrace` crate estea habilitada e a función `std` estea habilitada de xeito predeterminado.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Quizais un símbolo C++ analizado, se se analizou o símbolo alterado como Rust fallou.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Asegúrate de manter este tamaño cero para que a función `cpp_demangle` non teña ningún custo cando está desactivada.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Un envoltorio arredor dun nome de símbolo para proporcionar accesores ergonómicos ao nome desmangulado, os bytes en bruto, a cadea en bruto, etc.
///
// Permitir código morto cando a función `cpp_demangle` non estea habilitada.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Crea un novo nome de símbolo a partir dos bytes subxacentes en bruto.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Devolve o nome sinxelo do símbolo (mangled) como `str` se o símbolo é utf-8 válido.
    ///
    /// Utilice a implementación `Display` se desexa a versión desenredada.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Devolve o nome do símbolo en bruto como unha lista de bytes
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Isto pode imprimirse se o símbolo desenredado non é realmente válido, así que controle con graza o erro non propagándoo cara a fóra.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Tenta recuperar esa memoria caché usada para simbolizar enderezos.
///
/// Este método intentará liberar as estruturas de datos globais que doutro xeito estivesen almacenadas en caché globalmente ou no fío que normalmente representan información analizada de DWARF ou similar.
///
///
/// # Caveats
///
/// Aínda que esta función está sempre dispoñible, en realidade non fai nada na maioría das implementacións.
/// Bibliotecas como dbghelp ou libbacktrace non proporcionan facilidades para deslocalizar o estado e xestionar a memoria asignada.
/// Por agora a función `gimli-symbolize` deste crate é a única característica onde esta función ten algún efecto.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}