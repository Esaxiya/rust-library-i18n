//! Estratexia de simbolización usando o código de análise DWARF en libbacktrace.
//!
//! A biblioteca libbacktrace C, normalmente distribuída con gcc, admite non só xerar un retrotrastro (que realmente non usamos), senón tamén simbolizar a traza traseira e manexar información de depuración anana sobre cousas como marcos en liña e calquera outra cousa.
//!
//!
//! Isto é relativamente complicado debido a moitas preocupacións aquí, pero a idea básica é:
//!
//! * Primeiro chamamos `backtrace_syminfo`.Se obtemos información de símbolos da táboa de símbolos dinámica, se podemos.
//! * A continuación chamámoslle `backtrace_pcinfo`.Isto analizará as táboas de debuginfo se están dispoñibles e permítenos recuperar información sobre marcos en liña, nomes de ficheiros, números de liña, etc.
//!
//! Hai moitos trucos sobre como meter as táboas ananas en libbacktrace, pero espero que non sexa o fin do mundo e que estea o suficientemente claro ao ler a continuación.
//!
//! Esta é a estratexia de simbolización predeterminada para plataformas non MSVC e non OSX.En libstd esta é a estratexia predeterminada para OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Se é posible, prefire o nome `function` que provén de debuginfo e normalmente pode ser máis preciso para cadros en liña, por exemplo.
                // Se non está presente, volva ao nome da táboa de símbolos especificado en `symname`.
                //
                // Teña en conta que ás veces `function` pode parecer algo menos preciso, por exemplo, estar listado como `try<i32,closure>` non é `std::panicking::try::do_call`.
                //
                // Non está moi claro por que, pero en xeral o nome `function` parece máis preciso.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // non fagas nada polo de agora
}

/// Tipo do punteiro `data` pasado a `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Unha vez que se invoca esta devolución de chamada desde `backtrace_syminfo` cando comezamos a resolver, imos máis alá para chamar a `backtrace_pcinfo`.
    // A función `backtrace_pcinfo` consultará información de depuración e tentará facer cousas como recuperar información file/line, así como marcos en liña.
    // Ten en conta que `backtrace_pcinfo` pode fallar ou non facer moito se non hai información de depuración, polo que, se isto ocorre, seguro que chamaremos á devolución de chamada con polo menos un símbolo do `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Tipo do punteiro `data` pasado a `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// A API libbacktrace admite a creación dun estado, pero non admite destruír un estado.
// Eu persoalmente considero que isto significa que se quere crear un estado e logo vivir para sempre.
//
// Encantaríame rexistrar un controlador at_exit() que limpe este estado, pero libbacktrace non ofrece ningunha maneira de facelo.
//
// Con estas restricións, esta función ten un estado de caché estático que se calcula a primeira vez que se solicita.
//
// Lembre que o retrotrastro ocorre en serie (un bloqueo global).
//
// Teña en conta que a falta de sincronización aquí débese ao requisito de que `resolve` estea sincronizado externamente.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Non exerza as capacidades fiables de libbacktrace xa que sempre o estamos chamando de xeito sincronizado.
        //
        0,
        error_cb,
        ptr::null_mut(), // sen datos adicionais
    );

    return STATE;

    // Teña en conta que para que libbacktrace funcione, precisa atopar a información de depuración DWARF para o executable actual.Normalmente faino mediante unha serie de mecanismos que inclúen, pero non se limitan a:
    //
    // * /proc/self/exe en plataformas compatibles
    // * O nome do ficheiro entrou explícitamente ao crear o estado
    //
    // A biblioteca libbacktrace é unha gran parte do código C.Isto significa naturalmente que ten vulnerabilidades de seguridade na memoria, especialmente cando se manexa debuginfo mal formado.
    // Libstd atopou moitos destes historicamente.
    //
    // Se se usa /proc/self/exe, normalmente podemos ignoralos xa que supoñemos que libbacktrace é "mostly correct" e doutro xeito non fai cousas estrañas coa información de depuración anana "attempted to be correct".
    //
    //
    // Non obstante, se pasamos un nome de ficheiro, é posible nalgunhas plataformas (como BSD) nas que un actor malicioso pode facer que se coloque un ficheiro arbitrario nese lugar.
    // Isto significa que se lle dicimos a libbacktrace un nome de ficheiro pode estar usando un ficheiro arbitrario, posiblemente causando fallos.
    // Se non lle dicimos nada a libbacktrace, non fará nada en plataformas que non admitan camiños como /proc/self/exe.
    //
    // Dado todo o que nos esforzamos todo o posible para *non* pasar nun nome de ficheiro, pero debemos facelo en plataformas que non admiten /proc/self/exe en absoluto.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Teña en conta que o ideal sería usar `std::env::current_exe`, pero non podemos requirir `std` aquí.
            //
            // Use `_NSGetExecutablePath` para cargar a ruta executable actual nunha área estática (que se é demasiado pequena simplemente renuncia).
            //
            //
            // Ten en conta que aquí confiamos seriamente en libbacktrace para non morrer en executables corrompidos, pero seguramente si ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ten un modo de abrir ficheiros onde despois de abrir non se pode eliminar.
            // Iso é en xeral o que queremos aquí porque queremos asegurarnos de que o noso executable non cambie de abaixo despois de entregalo a libbacktrace, con esperanza de mitigar a capacidade de pasar datos arbitrarios a libbacktrace (que pode ser mal tratado).
            //
            //
            // Dado que aquí bailamos un pouco para intentar conseguir unha especie de bloqueo na nosa propia imaxe:
            //
            // * Obter un control do proceso actual, cargar o seu nome de ficheiro.
            // * Abra un ficheiro a ese nome de ficheiro coas bandeiras correctas.
            // * Recargue o nome do ficheiro do proceso actual, asegurándose de que sexa o mesmo
            //
            // Se todo isto pasa, en teoría abrimos o ficheiro do noso proceso e temos a garantía de que non cambiará.FWIW históricamente copiouse unha chea diso de libstd, polo que esta é a miña mellor interpretación do que estaba a suceder.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Isto vive na memoria estática para que poidamos devolvelo ..
                static mut BUF: [i8; N] = [0; N];
                // ... e isto vive na pila xa que é temporal
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // baleira intencionadamente `handle` aquí porque telo aberto debería preservar o bloqueo deste nome de ficheiro.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Queremos devolver unha porción que está rematada nulo, polo que se todo se enche e é igual á lonxitude total, iguala a falla.
                //
                //
                // Se non, ao devolver o éxito, asegúrese de que o byte nul está incluído na porción.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // os erros de trazado traseiro están actualmente barridos baixo a alfombra
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Chame á API `backtrace_syminfo` que (a partir da lectura do código) debería chamar a `syminfo_cb` exactamente unha vez (ou fallar cun erro presuntamente).
    // Despois manexamos máis dentro do `syminfo_cb`.
    //
    // Teña en conta que facemos isto xa que `syminfo` consultará a táboa de símbolos, atopando nomes de símbolos aínda que non haxa información de depuración no binario.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}