#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Un formato para retroceso.
///
/// Este tipo pódese usar para imprimir unha traza traseira independentemente de onde provén a traza traseira en si.
/// Se tes un tipo `Backtrace`, a súa implementación `Debug` xa usa este formato de impresión.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Os estilos de impresión que podemos imprimir
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Imprime un retrotraso terser que idealmente só contén información relevante
    Short,
    /// Imprime un rastro traseiro que contén toda a información posible
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Crea un novo `BacktraceFmt` que escribirá a saída no `fmt` fornecido.
    ///
    /// O argumento `format` controlará o estilo no que se imprime a traza traseira e o argumento `print_path` usarase para imprimir as instancias `BytesOrWideString` de nomes de ficheiro.
    /// Este tipo en si non imprime os nomes dos ficheiros, pero é necesaria esta devolución de chamada.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Imprime un preámbulo para a traza traseira a piques de imprimirse.
    ///
    /// Isto é necesario nalgunhas plataformas para que as trazas de fondo sexan completamente simbolizadas máis tarde e, se non, este debería ser o primeiro método que chame despois de crear un `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Engade un marco á saída de traza traseira.
    ///
    /// Este commit devolve unha instancia RAII dun `BacktraceFrameFmt` que se pode usar para imprimir realmente un marco e, ao destruílo, incrementará o contador de cadros.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Completa a saída de traza traseira.
    ///
    /// Actualmente non funciona, pero engádese para a compatibilidade con future cos formatos de traza traseira.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Actualmente un non-op-- incluído este hook para permitir adicións future.
        Ok(())
    }
}

/// Un formato para só un cadro dunha traza traseira.
///
/// Este tipo créase coa función `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Imprime un `BacktraceFrame` con este formato de cadros.
    ///
    /// Isto imprimirá recursivamente todas as instancias `BacktraceSymbol` dentro do `BacktraceFrame`.
    ///
    /// # Funcións necesarias
    ///
    /// Esta función require que a función `std` do `backtrace` crate estea habilitada e a función `std` estea habilitada de xeito predeterminado.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Imprime un `BacktraceSymbol` dentro dun `BacktraceFrame`.
    ///
    /// # Funcións necesarias
    ///
    /// Esta función require que a función `std` do `backtrace` crate estea habilitada e a función `std` estea habilitada de xeito predeterminado.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: isto non é estupendo que non acabemos imprimindo nada
            // con nomes de ficheiro non utf8.
            // Afortunadamente case todo é utf8, polo que non debería ser demasiado malo.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Imprime un `Frame` e `Symbol` trazados en bruto, normalmente dende as devolucións de chamadas en bruto deste crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Engade un marco bruto á saída de traza traseira.
    ///
    /// Este método, a diferenza do anterior, toma os argumentos en bruto no caso de que sexan fonte de diferentes lugares.
    /// Teña en conta que isto pódese chamar varias veces para un cadro.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Engade un marco bruto á saída de traza traseira, incluída a información da columna.
    ///
    /// Este método, como o anterior, toma os argumentos en bruto no caso de que estean a ser orixinarios de diferentes localizacións.
    /// Teña en conta que isto pódese chamar varias veces para un cadro.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fucsia non pode simbolizar dentro dun proceso, polo que ten un formato especial que se pode usar para simbolizar máis tarde.
        // Imprimir aquí en vez de imprimir enderezos no noso propio formato.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Non fai falta imprimir marcos "null", basicamente só significa que a traza traseira do sistema estaba un pouco ansiosa por remontar moi lonxe.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Para reducir o tamaño de TCB no enclave Sgx, non queremos implementar a función de resolución de símbolos.
        // Pola contra, podemos imprimir o desprazamento do enderezo aquí, que posteriormente podería mapearse para que funcione correctamente.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Imprime o índice do marco así como o punteiro de instrución opcional do marco.
        // Se estamos máis alá do primeiro símbolo deste marco, aínda que só imprimimos un espazo en branco adecuado.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // A continuación escriba o nome do símbolo, usando o formato alternativo para obter máis información se somos un retroceso completo.
        // Aquí tamén manexamos símbolos que non teñen nome,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // E por último, imprime o número filename/line se están dispoñibles.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line imprímense en liñas baixo o nome do símbolo, así que imprima un espazo en branco adecuado para clasificarnos á dereita.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegar na nosa devolución de chamada interna para imprimir o nome do ficheiro e despois imprimir o número de liña.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Engade o número de columna, se está dispoñible.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Só nos preocupa o primeiro símbolo dun marco
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}