use core::ffi::c_void;
use core::fmt;

/// Inspecciona a pila de chamadas actual, pasando todos os fotogramas activos ao peche proporcionado para calcular un trazo da pila.
///
/// Esta función é o cabalo de batalla desta biblioteca no cálculo das trazas de pila dun programa.O peche `cb` dado prodúcese instancias dun `Frame` que representan información sobre ese marco de chamada na pila.
/// O peche prodúcese en cadros de xeito descendente (máis recentemente chamáronse funcións primeiro).
///
/// O valor de retorno do peche é unha indicación de se a traza traseira debería continuar.Un valor de retorno de `false` finalizará a traza traseira e volverá inmediatamente.
///
/// Unha vez que se adquira un `Frame`, é probable que queira chamar a `backtrace::resolve` para converter o `ip` (punteiro de instrución) ou o enderezo do símbolo a un `Symbol` a través do cal se pode aprender o nome e/ou o nome do ficheiro/número de liña.
///
///
/// Teña en conta que se trata dunha función de nivel relativamente baixo e se desexa, por exemplo, capturar un rastro traseiro para ser inspeccionado posteriormente, o tipo `Backtrace` pode ser máis adecuado.
///
/// # Funcións necesarias
///
/// Esta función require que a función `std` do `backtrace` crate estea habilitada e a función `std` estea habilitada de xeito predeterminado.
///
/// # Panics
///
/// Esta función procura nunca panic, pero se o `cb` proporcionou panics, entón algunhas plataformas obrigarán a un panic dobre para abortar o proceso.
/// Algunhas plataformas usan unha biblioteca C que utiliza internamente devolucións de chamada que non se poden desfacer, polo que o pánico de `cb` pode provocar un proceso de interrupción.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // continúa a traza traseira
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Igual que `trace`, só non seguro xa que non está sincronizado.
///
/// Esta función non ten garantidos de sincronización pero está dispoñible cando a función `std` deste crate non se compila.
/// Consulte a función `trace` para obter máis documentación e exemplos.
///
/// # Panics
///
/// Consulte a información sobre `trace` para obter advertencias sobre o pánico de `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Un trait que representa un cadro dunha traza traseira, cedeu á función `trace` deste crate.
///
/// O peche da función de rastrexo producirase cadros, e o cadro envíase practicamente xa que a implementación subxacente non sempre se coñece ata o tempo de execución.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Devolve o punteiro de instrución actual deste marco.
    ///
    /// Esta é normalmente a seguinte instrución para executar no marco, pero non todas as implementacións listan isto cun 100% de precisión (pero xeralmente é bastante próxima).
    ///
    ///
    /// Recoméndase pasar este valor a `backtrace::resolve` para convertelo nun nome de símbolo.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Devolve o punteiro de pila actual deste marco.
    ///
    /// No caso de que un backend non poida recuperar o punteiro de pila para este marco, devólvese un punteiro nulo.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Devolve o enderezo do símbolo inicial do marco desta función.
    ///
    /// Isto tentará rebobinar o punteiro de instrución devolto por `ip` ao inicio da función, devolvendo ese valor.
    ///
    /// Non obstante, nalgúns casos os backends só devolverán `ip` desde esta función.
    ///
    /// O valor devolto pódese usar ás veces se fallou `backtrace::resolve` no `ip` indicado anteriormente.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Devolve o enderezo base do módulo ao que pertence o marco.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Isto ten que ser o primeiro para garantir que Miri teña prioridade sobre a plataforma de acollida
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // só se usa en dbghelp simboliza
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}