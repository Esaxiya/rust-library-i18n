# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Unha biblioteca para adquirir trazas traseiras en tempo de execución para Rust.
Esta biblioteca ten como obxectivo mellorar o soporte da biblioteca estándar proporcionando unha interface programática coa que traballar, pero tamén admite imprimir facilmente o trazado actual como o panics de libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Para simplemente capturar un rastro traseiro e aprazalo ata un momento posterior, pode utilizar o tipo `Backtrace` de nivel superior.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Non obstante, se desexa un acceso máis bruto á funcionalidade de rastrexo real, pode usar as funcións `trace` e `resolve` directamente.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Resolva este punteiro de instrución cun nome de símbolo
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // continúa co seguinte cadro
    });
}
```

# License

Este proxecto ten licenza baixo calquera dos dous

 * Licenza Apache, versión 2.0, ([LICENSE-APACHE](LICENSE-APACHE) ou http://www.apache.org/licenses/LICENSE-2.0)
 * Licenza MIT ([LICENSE-MIT](LICENSE-MIT) ou http://opensource.org/licenses/MIT)

á súa elección.

### Contribution

A non ser que explique expresamente o contrario, calquera contribución enviada intencionalmente para a súa inclusión en backtrace-rs, tal e como se define na licenza Apache-2.0, terá unha licenza dobre como a anterior, sen termos ou condicións adicionais.







