# O `rustc-std-workspace-core` crate

Este crate é un crate escaso e baleiro que simplemente depende de `libcore` e reexporta todo o seu contido.
O crate é o núcleo de capacitar á biblioteca estándar para depender de crates de crates.io

Crates en crates.io que depende da biblioteca estándar precisa depender do `rustc-std-workspace-core` crate de crates.io, que está baleiro.

Usamos `[patch]` para anularlo a este crate neste repositorio.
Como resultado, crates en crates.io debuxará unha dependencia edge a `libcore`, a versión definida neste repositorio.
Isto debería debuxar todos os bordos de dependencia para garantir que Cargo constrúe crates con éxito.

Teña en conta que crates en crates.io debe depender deste crate co nome `core` para que todo funcione correctamente.Para iso poden usar:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Mediante o uso da tecla `package` o crate pasa a denominarse `core`, o que significa que parecerá

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

cando Cargo invoca o compilador, cumprindo a directiva `extern crate core` implícita inxectada polo compilador.




