// rsbegin.o e rsend.o son os chamados "compiler runtime startup objects".
// Conteñen o código necesario para inicializar correctamente o tempo de execución do compilador.
//
// Cando unha imaxe executable ou dylib está ligada, todos os códigos de usuario e bibliotecas están "sandwiched" entre estes dous ficheiros obxecto, polo que o código ou os datos de rsbegin.o pasan a ser os primeiros nas seccións respectivas da imaxe, mentres que o código e os datos de rsend.o convértense nos últimos.
// Este efecto pódese empregar para colocar símbolos ao comezo ou ao final dunha sección, así como para inserir as cabeceiras ou pés de páxina necesarios.
//
// Teña en conta que o punto de entrada do módulo real está situado no obxecto de inicio de tempo de execución C (normalmente chamado `crtX.o`), que entón invoca devolucións de chamada doutros compoñentes de tempo de execución (rexistrados a través doutra sección de imaxe especial).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Marca o comezo do marco de pila para desenrolar a sección de información
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Espazo para raspar para a contabilidade interna do desenrollador.
    // Isto defínese como `struct object` en $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Desenrolar as rutinas de información registration/deregistration.
    // Vexa os documentos de libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // rexistrar información de desconexión ao iniciar o módulo
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // dar de baixa no apagado
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Rexistro de rutina específico de MinGW init/uninit
    pub mod mingw_init {
        // Os obxectos de inicio de MinGW (crt0.o/dllcrt0.o) invocarán construtores globais nas seccións .ctors e .dtors ao iniciar e saír.
        // No caso das DLL, isto faise cando se carga e descarga a DLL.
        //
        // O ligador ordenará as seccións, o que garante que as devolucións de chamada se atopen ao final da lista.
        // Dado que os construtores se executan en orde inversa, isto garante que as nosas devolucións de chamada sexan a primeira e a última executada.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: devolución de chamadas de inicialización C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: devolución de chamadas de terminación C.
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}