use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Un envoltorio para impedir que o compilador chame automaticamente ao destructor de `T`.
/// Este envoltorio ten un custo de 0.
///
/// `ManuallyDrop<T>` está suxeito ás mesmas optimizacións de deseño que `T`.
/// Como consecuencia, non ten *ningún efecto* nos supostos que o compilador fai sobre o seu contido.
/// Por exemplo, inicializar un `ManuallyDrop<&mut T>` con [`mem::zeroed`] é un comportamento indefinido.
/// Se precisa xestionar datos non inicializados, use [`MaybeUninit<T>`] no seu lugar.
///
/// Ten en conta que acceder ao valor dentro dun `ManuallyDrop<T>` é seguro.
/// Isto significa que un `ManuallyDrop<T>` cuxo contido se eliminou non debe estar exposto a través dunha API de seguridade pública.
/// Correspondentemente, `ManuallyDrop::drop` non é seguro.
///
/// # `ManuallyDrop` e soltar orde.
///
/// Rust ten un [drop order] de valores ben definido.
/// Para asegurarse de que os campos ou locais se deixan caer nunha orde específica, reordene as declaracións de xeito que a orde de solta implícita sexa a correcta.
///
/// É posible usar `ManuallyDrop` para controlar a orde de caída, pero isto require un código non seguro e é difícil de facer correctamente en presenza de desenrolo.
///
///
/// Por exemplo, se desexa asegurarse de que se deixa caer un campo específico despois dos demais, convérteo no último campo dunha estrutura:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` eliminarase despois do `children`.
///     // Rust garante que os campos se eliminan na orde de declaración.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Axuste un valor que se cae manualmente.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Aínda podes operar con seguridade no valor
    /// assert_eq!(*x, "Hello");
    /// // Pero `Drop` non se executará aquí
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Extrae o valor do contedor `ManuallyDrop`.
    ///
    /// Isto permite que o valor caia de novo.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Isto deixa caer o `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Elimina o valor do contedor `ManuallyDrop<T>`.
    ///
    /// Este método está pensado principalmente para mover valores caídos.
    /// En lugar de usar [`ManuallyDrop::drop`] para eliminar manualmente o valor, pode usar este método para tomar o valor e usalo como queira.
    ///
    /// Sempre que sexa posible, é preferible empregar [`into_inner`][`ManuallyDrop::into_inner`] no seu lugar, o que impide duplicar o contido do `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Esta función move semánticamente o valor contido sen impedir máis uso, deixando sen cambios o estado deste contedor.
    /// É a súa responsabilidade asegurarse de que este `ManuallyDrop` non se volva usar.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SEGURIDADE: estamos lendo desde unha referencia, que está garantida
        // para ser válido para as lecturas.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Elimina manualmente o valor contido.Isto é exactamente equivalente a chamar a [`ptr::drop_in_place`] cun punteiro ao valor contido.
    /// Polo tanto, a non ser que o valor contido sexa unha estrutura empaquetada, o destrutor chamarase no lugar sen mover o valor e, polo tanto, pode usarse para eliminar con seguridade os datos [pinned].
    ///
    /// Se ten a propiedade do valor, pode usar [`ManuallyDrop::into_inner`] no seu lugar.
    ///
    /// # Safety
    ///
    /// Esta función executa o destructor do valor contido.
    /// Ademais dos cambios feitos polo propio destructor, a memoria non se modifica, polo que, no que se refire ao compilador, aínda ten un patrón de bits válido para o tipo `T`.
    ///
    ///
    /// Non obstante, este valor "zombie" non debe estar exposto a código seguro e esta función non se debe chamar máis dunha vez.
    /// Usar un valor despois de que se elimine ou caer un valor varias veces pode provocar un comportamento indefinido (dependendo do que faga `drop`).
    /// O sistema de tipo normalmente impídeo, pero os usuarios de `ManuallyDrop` deben manter esas garantías sen a asistencia do compilador.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SEGURIDADE: estamos caendo o valor sinalado por unha referencia mutable
        // que está garantido para que sexa válido para as escrituras.
        // Depende do interlocutor asegurarse de que `slot` non se volve a deixar caer.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}