//! Funcións básicas para tratar a memoria.
//!
//! Este módulo contén funcións para consultar o tamaño e aliñamento dos tipos, inicializar e manipular a memoria.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Toma a propiedade e "forgets" sobre o valor **sen executar o seu destructor**.
///
/// Calquera recurso que xestione o valor, como a memoria heap ou un controlador de ficheiros, permanecerá para sempre nun estado inalcanzable.Non obstante, non garante que os indicadores desta memoria sigan sendo válidos.
///
/// * Se desexa filtrar memoria, consulte [`Box::leak`].
/// * Se desexa obter un punteiro en bruto na memoria, consulte [`Box::into_raw`].
/// * Se desexa eliminar un valor correctamente, executando o seu destructor, consulte [`mem::drop`].
///
/// # Safety
///
/// `forget` non está marcado como `unsafe`, porque as garantías de seguridade de Rust non inclúen a garantía de que os destrutores funcionarán sempre.
/// Por exemplo, un programa pode crear un ciclo de referencia usando [`Rc`][rc] ou chamar ao [`process::exit`][exit] para saír sen executar destrutores.
/// Así, permitir `mem::forget` a partir de código seguro non modifica fundamentalmente as garantías de seguridade de Rust.
///
/// Dito isto, a filtración de recursos como memoria ou obxectos I/O normalmente non é desexable.
/// A necesidade xorde nalgúns casos de uso especializados para FFI ou código non seguro, pero aínda así normalmente prefírese [`ManuallyDrop`].
///
/// Debido a que se permite esquecer un valor, calquera código `unsafe` que escriba debe permitir esta posibilidade.Non pode devolver un valor e esperar que o interlocutor necesariamente execute o destructor do valor.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// O uso canónico seguro de `mem::forget` é evitar o destructor dun valor implementado polo `Drop` trait.Por exemplo, isto filtrará un `File`, é dicir
/// recuperar o espazo ocupado pola variable pero nunca pechar o recurso do sistema subxacente:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Isto é útil cando a propiedade do recurso subxacente foi previamente transferida a código fóra de Rust, por exemplo, transmitindo o descriptor de ficheiro en bruto ao código C.
///
/// # Relación con `ManuallyDrop`
///
/// Aínda que `mem::forget` tamén se pode usar para transferir a propiedade da *memoria*, facelo é propenso a erros.
/// [`ManuallyDrop`] debería usarse no seu lugar.Considere, por exemplo, este código:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Construír un `String` usando o contido de `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // baleirar `v` porque a súa memoria agora está xestionada por `s`
/// mem::forget(v);  // ERRO, v non é válido e non se debe pasar a unha función
/// assert_eq!(s, "Az");
/// // `s` cae implícitamente e deslocalízase a súa memoria.
/// ```
///
/// Hai dous problemas co exemplo anterior:
///
/// * Se se engadise máis código entre a construción de `String` e a invocación de `mem::forget()`, un panic dentro produciría un dobre libre porque a mesma memoria é manexada tanto por `v` como por `s`.
/// * Despois de chamar a `v.as_mut_ptr()` e transmitir a propiedade dos datos a `s`, o valor `v` non é válido.
/// Mesmo cando se acaba de mover un valor a `mem::forget` (que non o inspeccionará), algúns tipos teñen requisitos estritos nos seus valores que os fan inválidos cando están colgados ou xa non son de propiedade.
/// Usar valores non válidos de calquera xeito, incluíndo pasalos ou devolvelos de funcións, constitúe un comportamento indefinido e pode romper as suposicións feitas polo compilador.
///
/// Cambiar a `ManuallyDrop` evita os dous problemas:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Antes de desmontar `v` nas súas pezas en bruto, asegúrese de que non caia.
/////
/// let mut v = ManuallyDrop::new(v);
/// // Agora desmonta `v`.Estas operacións non poden panic, polo que non pode haber unha fuga.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Finalmente, constrúe un `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` cae implícitamente e deslocalízase a súa memoria.
/// ```
///
/// `ManuallyDrop` evita de forma robusta o dobre libre porque desactivamos o destructor de `v` antes de facer outra cousa.
/// `mem::forget()` non o permite porque consume o seu argumento, obrigándonos a chamalo só despois de extraer calquera cousa que necesitemos de `v`.
/// Mesmo se se introducise un panic entre a construción de `ManuallyDrop` e a construción da cadea (o que non pode ocorrer no código como se mostra), resultaría unha fuga e non un dobre libre.
/// Noutras palabras, `ManuallyDrop` erra no lado de caer en vez de errar no lado de (dobre) caer.
///
/// Ademais, `ManuallyDrop` impídenos ter que "touch" `v` despois de transferir a propiedade a `s`; o paso final de interactuar con `v` para desfacelo sen executar o seu destructor é totalmente evitado.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Como [`forget`], pero tamén acepta valores sen tamaño.
///
/// Esta función é só unha capa destinada a ser eliminada cando a función `unsized_locals` se estabiliza.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Devolve o tamaño dun tipo en bytes.
///
/// Máis concretamente, este é o desprazamento en bytes entre elementos sucesivos nunha matriz con ese tipo de elemento incluído o recheo de aliñamento.
///
/// Así, para calquera tipo `T` e lonxitude `n`, `[T; n]` ten un tamaño de `n * size_of::<T>()`.
///
/// En xeral, o tamaño dun tipo non é estable entre as compilacións, pero si tipos específicos como os primitivos.
///
/// A seguinte táboa dá o tamaño das primitivas.
///
/// Tipo |tamaño_de: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 caracteres4
///
/// Ademais, `usize` e `isize` teñen o mesmo tamaño.
///
/// Todos os tipos `*const T`, `&T`, `Box<T>`, `Option<&T>` e `Option<Box<T>>` teñen o mesmo tamaño.
/// Se `T` é de tamaño, todos eses tipos teñen o mesmo tamaño que `usize`.
///
/// A mutabilidade dun punteiro non cambia o seu tamaño.Polo tanto, `&T` e `&mut T` teñen o mesmo tamaño.
/// Do mesmo xeito para `*const T` e `* mut T`.
///
/// # Tamaño de elementos `#[repr(C)]`
///
/// A representación `C` para elementos ten un deseño definido.
/// Con este deseño, o tamaño dos elementos tamén é estable sempre que todos os campos teñan un tamaño estable.
///
/// ## Tamaño das estruturas
///
/// Para `structs`, o tamaño está determinado polo seguinte algoritmo.
///
/// Para cada campo da estrutura ordenado por orde de declaración:
///
/// 1. Engade o tamaño do campo.
/// 2. Redondea o tamaño actual ao múltiplo máis próximo do [alignment] do seguinte campo.
///
/// Finalmente, redondea o tamaño da estrutura ao múltiplo máis próximo do seu [alignment].
/// O aliñamento da estrutura adoita ser o maior aliñamento de todos os seus campos;isto pódese cambiar co uso de `repr(align(N))`.
///
/// A diferenza do `C`, as estruturas de tamaño cero non son redondeadas ata un byte de tamaño.
///
/// ## Tamaño das enumeracións
///
/// As enumeracións que non levan datos distintos do discriminante teñen o mesmo tamaño que as enumeracións C na plataforma para a que son compiladas.
///
/// ## Tamaño dos sindicatos
///
/// O tamaño dunha unión é o tamaño do seu campo máis grande.
///
/// A diferenza do `C`, as unións de tamaño cero non son redondeadas ata un byte de tamaño.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Algúns primitivos
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Algunhas matrices
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Igualdade do tamaño do punteiro
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Usando `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // O tamaño do primeiro campo é 1, así que engade 1 ao tamaño.O tamaño é 1.
/// // A aliñación do segundo campo é 2, así que engade 1 ao tamaño para o recheo.O tamaño é 2.
/// // O tamaño do segundo campo é 2, así que engade 2 ao tamaño.O tamaño é 4.
/// // O aliñamento do terceiro campo é 1, así que engade 0 ao tamaño para o recheo.O tamaño é 4.
/// // O tamaño do terceiro campo é 1, así que engade 1 ao tamaño.O tamaño é de 5.
/// // Finalmente, o aliñamento da estrutura é 2 (porque o maior aliñamento entre os seus campos é 2), polo que engade 1 ao tamaño para o recheo.
/// // O tamaño é de 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // As estruturas de tuplas seguen as mesmas regras.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Teña en conta que reordenar os campos pode reducir o tamaño.
/// // Podemos eliminar ambos bytes de recheo poñendo `third` antes de `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // O tamaño da unión é o tamaño do campo máis grande.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Devolve o tamaño do valor apuntado en bytes.
///
/// Normalmente é o mesmo que `size_of::<T>()`.
/// Non obstante, cando `T`*non ten* un tamaño estáticamente coñecido, por exemplo, unha porción [`[T]`][slice] ou un [trait object], entón pódese usar `size_of_val` para obter o tamaño coñecido dinámicamente.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SEGURIDADE: `val` é unha referencia, polo que é un punteiro en bruto válido
    unsafe { intrinsics::size_of_val(val) }
}

/// Devolve o tamaño do valor apuntado en bytes.
///
/// Normalmente é o mesmo que `size_of::<T>()`.Non obstante, cando `T`*non ten* un tamaño estáticamente coñecido, por exemplo, unha porción [`[T]`][slice] ou un [trait object], entón pódese usar `size_of_val_raw` para obter o tamaño coñecido dinámicamente.
///
/// # Safety
///
/// Esta función só se pode chamar con seguridade se se cumpren as seguintes condicións:
///
/// - Se `T` é `Sized`, sempre se pode chamar con seguridade a esta función.
/// - Se a cola sen tamaño de `T` é:
///     - un [slice], entón a lonxitude da cola da porción debe ser un número enteiro inicializado e o tamaño do *valor enteiro*(lonxitude da cola dinámica + prefixo de tamaño estático) debe caber en `isize`.
///     - un [trait object], entón a parte vtable do punteiro debe apuntar a unha vtable válida adquirida por unha coerción sen dimensionar e o tamaño do *valor enteiro*(lonxitude da cola dinámica + prefixo de tamaño estático) debe caber en `isize`.
///
///     - un (unstable) [extern type], entón esta función é sempre segura para chamar, pero pode que panic ou outra volta devolva o valor incorrecto, xa que non se coñece o deseño do tipo externo.
///     Este é o mesmo comportamento que [`size_of_val`] nunha referencia a un tipo cunha cola tipo externo.
///     - se non, non se pode conservar esta función.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SEGURIDADE: o interlocutor debe proporcionar un punteiro en bruto válido
    unsafe { intrinsics::size_of_val(val) }
}

/// Devolve o aliñamento mínimo requirido por [ABI] dun tipo.
///
/// Cada referencia a un valor do tipo `T` debe ser múltiplo deste número.
///
/// Este é o aliñamento empregado para os campos struct.Pode ser menor que o aliñamento preferido.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Devolve o aliñamento mínimo requirido por [ABI] do tipo de valor ao que apunta `val`.
///
/// Cada referencia a un valor do tipo `T` debe ser múltiplo deste número.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SEGURIDADE: val é unha referencia, polo que é un punteiro en bruto válido
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Devolve o aliñamento mínimo requirido por [ABI] dun tipo.
///
/// Cada referencia a un valor do tipo `T` debe ser múltiplo deste número.
///
/// Este é o aliñamento empregado para os campos struct.Pode ser menor que o aliñamento preferido.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Devolve o aliñamento mínimo requirido por [ABI] do tipo de valor ao que apunta `val`.
///
/// Cada referencia a un valor do tipo `T` debe ser múltiplo deste número.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SEGURIDADE: val é unha referencia, polo que é un punteiro en bruto válido
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Devolve o aliñamento mínimo requirido por [ABI] do tipo de valor ao que apunta `val`.
///
/// Cada referencia a un valor do tipo `T` debe ser múltiplo deste número.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Esta función só se pode chamar con seguridade se se cumpren as seguintes condicións:
///
/// - Se `T` é `Sized`, sempre se pode chamar con seguridade a esta función.
/// - Se a cola sen tamaño de `T` é:
///     - un [slice], entón a lonxitude da cola da porción debe ser un número enteiro inicializado e o tamaño do *valor enteiro*(lonxitude da cola dinámica + prefixo de tamaño estático) debe caber en `isize`.
///     - un [trait object], entón a parte vtable do punteiro debe apuntar a unha vtable válida adquirida por unha coerción sen dimensionar e o tamaño do *valor enteiro*(lonxitude da cola dinámica + prefixo de tamaño estático) debe caber en `isize`.
///
///     - un (unstable) [extern type], entón esta función é sempre segura para chamar, pero pode que panic ou outra volta devolva o valor incorrecto, xa que non se coñece o deseño do tipo externo.
///     Este é o mesmo comportamento que [`align_of_val`] nunha referencia a un tipo cunha cola tipo externo.
///     - se non, non se pode conservar esta función.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SEGURIDADE: o interlocutor debe proporcionar un punteiro en bruto válido
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Devolve `true` se importa a caída de valores do tipo `T`.
///
/// Este é puramente un consello de optimización e pode implementarse de xeito conservador:
/// pode devolver `true` para tipos que non precisan ser eliminados.
/// Como tal, sempre devolver `true` sería unha implementación válida desta función.Non obstante, se esta función devolve `false`, pode estar seguro de que caer `T` non ten ningún efecto secundario.
///
/// As implementacións de baixo nivel de cousas como coleccións, que precisan eliminar manualmente os seus datos, deberían usar esta función para evitar intentar innecesariamente deixar caer todo o seu contido cando se destrúen.
///
/// Isto pode non marcar a diferenza nas versións de lanzamento (onde se detecta e elimina facilmente un bucle que non ten efectos secundarios), pero a miúdo supón un gran triunfo para as versións de depuración.
///
/// Teña en conta que [`drop_in_place`] xa realiza esta comprobación, polo que se a súa carga de traballo pode reducirse a un número reducido de chamadas [`drop_in_place`], non é necesario o seu uso.
/// Ten en conta especialmente que podes [`drop_in_place`] unha porción, e que fará unha única comprobación de necesidades_gota de todos os valores.
///
/// Tipos como Vec, polo tanto, só `drop_in_place(&mut self[..])` sen usar `needs_drop` de xeito explícito.
/// Tipos como [`HashMap`], por outra banda, teñen que deixar caer valores un por un e deberían usar esta API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Aquí tes un exemplo de como unha colección pode facer uso de `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // solte os datos
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Devolve o valor do tipo `T` representado polo patrón de bytes totalmente cero.
///
/// Isto significa que, por exemplo, o byte de recheo en `(u8, u16)` non está necesariamente a cero.
///
/// Non hai garantía de que un patrón de bytes totalmente cero represente un valor válido dalgún tipo `T`.
/// Por exemplo, o patrón de bytes totalmente cero non é un valor válido para tipos de referencia (`&T`, `&mut T`) e punteiros de funcións.
/// Usar `zeroed` nestes tipos provoca [undefined behavior][ub] inmediato porque [the Rust compiler assumes][inv] sempre ten un valor válido nunha variable que considera inicializada.
///
///
/// Isto ten o mesmo efecto que [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Ás veces é útil para FFI, pero polo xeral débese evitar.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Uso correcto desta función: inicializar un enteiro con cero.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Uso incorrecto* desta función: inicializar unha referencia con cero.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Comportamento sen definir.
/// let _y: fn() = unsafe { mem::zeroed() }; // E de novo!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SEGURIDADE: o interlocutor debe garantir que un valor totalmente cero é válido para `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Ignora as comprobacións normais de inicialización de memoria de Rust finxindo que produce un valor do tipo `T`, sen facer nada.
///
/// **Esta función está obsoleta.** Use [`MaybeUninit<T>`] no seu lugar.
///
/// O motivo da desvalorización é que a función basicamente non se pode usar correctamente: ten o mesmo efecto que [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Como explica o [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv] que os valores se inicializan correctamente.
/// Como consecuencia, chamar por exemplo
/// `mem::uninitialized::<bool>()` provoca un comportamento indefinido inmediato ao devolver un `bool` que definitivamente non é `true` nin `false`.
/// Peor, a memoria verdadeiramente non inicializada como a que se devolve aquí é especial porque o compilador sabe que non ten un valor fixo.
/// Isto fai que o comportamento non definido conteña datos non inicializados nunha variable aínda que esa variable teña un tipo enteiro.
/// (Teña en conta que as regras arredor dos números enteiros non inicializados aínda non están finalizadas, pero ata que se aconsellen é recomendable evitalas.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SEGURIDADE: o interlocutor debe garantir que un valor unitario é válido para `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Intercambia os valores en dúas localizacións mudables, sen desinicializar ningunha.
///
/// * Se desexa cambiar cun valor predeterminado ou falso, consulte [`take`].
/// * Se desexa cambiar cun valor pasado, devolvendo o valor anterior, consulte [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SEGURIDADE: os punteiros en bruto creáronse a partir de referencias seguras e mudables que satisfacen todos os
    // restricións en `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Substitúe `dest` polo valor predeterminado de `T`, devolvendo o valor anterior de `dest`.
///
/// * Se desexa substituír os valores de dúas variables, consulte [`swap`].
/// * Se desexa substituílo por un valor pasado no canto do valor predeterminado, consulte [`replace`].
///
/// # Examples
///
/// Un exemplo sinxelo:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` permite facerse cargo dun campo struct substituíndoo por un valor "empty".
/// Sen `take` podes atopar problemas como estes:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Teña en conta que `T` non necesariamente implementa [`Clone`], polo que nin sequera pode clonar e restablecer `self.buf`.
/// Pero `take` pode usarse para desvincular o valor orixinal de `self.buf` de `self`, permitindo devolvelo:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Move `src` ao `dest` referenciado, devolvendo o valor anterior `dest`.
///
/// Non se baixa ningún valor.
///
/// * Se desexa substituír os valores de dúas variables, consulte [`swap`].
/// * Se desexa substituílo por un valor predeterminado, consulte [`take`].
///
/// # Examples
///
/// Un exemplo sinxelo:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` permite o consumo dun campo struct substituíndoo por outro valor.
/// Sen `replace` podes atopar problemas como estes:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Teña en conta que `T` non necesariamente implementa [`Clone`], polo que nin sequera podemos clonar `self.buf[i]` para evitar o movemento.
/// Pero `replace` pode usarse para desvincular o valor orixinal dese índice de `self`, permitindo devolvelo:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SEGURIDADE: Lemos desde `dest` pero despois escribimos directamente `src`,
    // de tal xeito que o valor antigo non se duplica.
    // Non se deixa caer nada e aquí nada pode panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Dispón dun valor.
///
/// Isto faino chamando á implementación do argumento de [`Drop`][drop].
///
/// Isto efectivamente non fai nada para os tipos que implementan `Copy`, por exemplo
/// integers.
/// Estes valores copíanse e _then_ móvese á función, polo que o valor persiste despois desta chamada de función.
///
///
/// Esta función non é máxica;literalmente defínese como
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Debido a que `_x` se move á función, cae automaticamente antes de que volva a función.
///
/// [drop]: Drop
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // solte explicitamente o vector
/// ```
///
/// Dado que [`RefCell`] aplica as regras de préstamo en tempo de execución, `drop` pode liberar un préstamo [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // renuncia ao préstamo mutable nesta franxa
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Os números enteiros e outros tipos que implementan [`Copy`] non están afectados por `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // móvese e solta unha copia de `x`
/// drop(y); // móvese e solta unha copia de `y`
///
/// println!("x: {}, y: {}", x, y.0); // aínda dispoñible
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpreta que `src` ten o tipo `&U` e logo le `src` sen mover o valor contido.
///
/// Esta función asumirá de xeito seguro que o punteiro `src` é válido para bytes [`size_of::<U>`][size_of] transmutando `&T` a `&U` e logo lendo o `&U` (excepto que isto faise dun xeito correcto incluso cando `&U` fai que os requisitos de aliñamento sexan máis estritos que `&T`).
/// Tamén creará de xeito seguro unha copia do valor contido en lugar de saír de `src`.
///
/// Non é un erro no tempo de compilación se `T` e `U` teñen tamaños diferentes, pero recoméndase invocar só esta función onde `T` e `U` teñen o mesmo tamaño.Esta función activa [undefined behavior][ub] se `U` é maior que `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Copia os datos de 'foo_array' e trátalos como un 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Modifique os datos copiados
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // O contido de 'foo_array' non debería ter cambiado
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Se U ten un requisito de aliñamento máis alto, é posible que src non estea aliñado adecuadamente.
    if align_of::<U>() > align_of::<T>() {
        // SEGURIDADE: `src` é unha referencia que se garante que é válida para as lecturas.
        // O interlocutor debe garantir que a transmutación real é segura.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SEGURIDADE: `src` é unha referencia que se garante que é válida para as lecturas.
        // Acabamos de comprobar que `src as *const U` estaba correctamente aliñado.
        // O interlocutor debe garantir que a transmutación real é segura.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Tipo opaco que representa o discriminante dunha enum.
///
/// Consulte a función [`discriminant`] neste módulo para obter máis información.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Estas implementacións trait non se poden derivar porque non queremos límites en T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Devolve un valor que identifica de xeito único a variante enum en `v`.
///
/// Se `T` non é unha enum, chamar a esta función non producirá un comportamento indefinido, pero o valor de retorno non se especifica.
///
///
/// # Stability
///
/// O discriminante dunha variante enum pode cambiar se cambia a definición de enum.
/// Un discriminante dalgunha variante non cambiará entre compilacións co mesmo compilador.
///
/// # Examples
///
/// Isto pódese usar para comparar as enumeracións que transportan datos, sen ter en conta os datos reais:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Devolve o número de variantes do enum tipo `T`.
///
/// Se `T` non é unha enum, chamar a esta función non producirá un comportamento indefinido, pero o valor de retorno non se especifica.
/// Igualmente, se `T` é un número con máis variantes que `usize::MAX`, o valor de retorno non se especifica.
/// Contabilizaranse as variantes deshabitadas.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}