use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Un tipo de envoltura para construír instancias non inicializadas de `T`.
///
/// # Invariante de inicialización
///
/// O compilador, en xeral, asume que unha variable está inicializada correctamente segundo os requisitos do tipo de variable.Por exemplo, unha variable de tipo de referencia debe estar aliñada e non NULA.
/// Este é un invariante que debe *sempre* manterse, incluso en código non seguro.
/// Como consecuencia, a inicialización cero dunha variable de tipo de referencia provoca [undefined behavior][ub] instantáneo, non importa se esa referencia se acostuma a acceder á memoria:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // comportamento indefinido!⚠️
/// // O código equivalente con `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // comportamento indefinido!⚠️
/// ```
///
/// Isto é aproveitado polo compilador para varias optimizacións, como eludir as comprobacións en tempo de execución e optimizar o deseño `enum`.
///
/// Do mesmo xeito, a memoria totalmente non inicializada pode ter calquera contido, mentres que un `bool` sempre debe ser `true` ou `false`.Polo tanto, crear un `bool` non inicializado é un comportamento indefinido:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // comportamento indefinido!⚠️
/// // O código equivalente con `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // comportamento indefinido!⚠️
/// ```
///
/// Ademais, a memoria non inicializada é especial porque non ten un valor fixo ("fixed" significa "it won't change without being written to").Ler o mesmo byte non iniciado varias veces pode dar resultados diferentes.
/// Isto fai que o comportamento non definido conteña datos non inicializados nunha variable aínda que esa variable teña un tipo enteiro, que doutro xeito pode manter calquera patrón de bits *fixo*:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // comportamento indefinido!⚠️
/// // O código equivalente con `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // comportamento indefinido!⚠️
/// ```
/// (Teña en conta que as regras arredor dos números enteiros non inicializados aínda non están finalizadas, pero ata que se aconsellen é recomendable evitalas.)
///
/// Ademais diso, lembre que a maioría dos tipos teñen invariantes adicionais máis aló de considerarse inicializados a nivel de tipo.
/// Por exemplo, un [`Vec<T>`] inicializado con "1" considérase inicializado (baixo a implementación actual; isto non constitúe unha garantía estable) porque o único requisito que o compilador coñece é que o punteiro de datos non debe ser nulo.
/// A creación deste `Vec<T>` non provoca un comportamento *inmediato* indefinido, pero provocará un comportamento indefinido coas operacións máis seguras (incluído o solto).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` serve para habilitar código non seguro para tratar datos non inicializados.
/// É un sinal para o compilador que indica que os datos aquí poden *non* ser inicializados:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Crea unha referencia explícitamente non inicializada.
/// // O compilador sabe que os datos dentro dun `MaybeUninit<T>` poden non ser válidos e, polo tanto, non son UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Configúreo nun valor válido.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Extrae os datos inicializados-isto só se permite *despois de* inicializar correctamente `x`.
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// O compilador sabe entón non facer suposicións ou optimizacións incorrectas sobre este código.
///
/// Podes pensar en `MaybeUninit<T>` como un pouco como `Option<T>` pero sen ningún seguimento do tempo de execución e sen ningunha das comprobacións de seguridade.
///
/// ## out-pointers
///
/// Podes usar `MaybeUninit<T>` para implementar "out-pointers": en vez de devolver datos dunha función, pásao un punteiro a algunha memoria (uninitialized) para poñer o resultado.
/// Isto pode ser útil cando é importante para o interlocutor controlar como se asigna a memoria no que se almacena o resultado e quere evitar movementos innecesarios.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` non deixa caer o contido antigo, o que é importante.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Agora sabemos que `v` está inicializado.Isto tamén garante que o vector caia correctamente.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Inicialización dunha matriz elemento por elemento
///
/// `MaybeUninit<T>` pódese usar para inicializar unha matriz grande elemento por elemento:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Crea unha matriz non inicializada de `MaybeUninit`.
///     // O `assume_init` é seguro porque o tipo que pretendemos inicializar aquí é unha chea de `MaybeUninit`s, que non requiren inicialización.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Soltar un `MaybeUninit` non fai nada.
///     // Así, o uso de asignación de punteiro en bruto no canto de `ptr::write` non provoca a caída do antigo valor non inicializado.
/////
///     // Ademais, se hai un panic durante este bucle, temos unha fuga de memoria, pero non hai ningún problema de seguridade da memoria.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Todo está inicializado.
///     // Transmuta a matriz ao tipo inicializado.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Tamén podes traballar con matrices parcialmente inicializadas, que se poderían atopar en estruturas de datos de baixo nivel.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Crea unha matriz non inicializada de `MaybeUninit`.
/// // O `assume_init` é seguro porque o tipo que pretendemos inicializar aquí é unha chea de `MaybeUninit`s, que non requiren inicialización.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Conta o número de elementos que asignamos.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Para cada elemento da matriz, solte se o asignamos.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Inicializando unha estrutura campo por campo
///
/// Podes usar `MaybeUninit<T>` e a macro [`std::ptr::addr_of_mut`] para inicializar as estruturas campo por campo:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inicialización do campo `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Inicialización do campo `list` Se hai un panic aquí, o `String` no campo `name` fuga.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Todos os campos están inicializados, polo que chamamos ao `assume_init` para obter un Foo inicializado.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` ten o mesmo tamaño, aliñamento e ABI que `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Non obstante, lembre que un tipo *que contén* un `MaybeUninit<T>` non é necesariamente o mesmo deseño;Rust non garante en xeral que os campos dun `Foo<T>` teñan a mesma orde que un `Foo<U>` aínda que `T` e `U` teñan o mesmo tamaño e aliñamento.
///
/// Ademais, porque calquera valor de bit é válido para un `MaybeUninit<T>`, o compilador non pode aplicar optimizacións non-zero/niche-filling, o que pode producir un tamaño maior:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Se `T` é seguro para FFI, tamén o será `MaybeUninit<T>`.
///
/// Aínda que `MaybeUninit` é `#[repr(transparent)]` (o que indica que garante o mesmo tamaño, aliñamento e ABI que `T`), isto *non* modifica ningunha das advertencias anteriores.
/// `Option<T>` e `Option<MaybeUninit<T>>` aínda poden ter diferentes tamaños e os tipos que conteñan un campo do tipo `T` poden presentarse (e dimensionarse) de xeito diferente que se ese campo fose `MaybeUninit<T>`.
/// `MaybeUninit` é un tipo de unión e `#[repr(transparent)]` nas unións é inestable (ver [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Co paso do tempo, as garantías exactas de `#[repr(transparent)]` nos sindicatos poden evolucionar e `MaybeUninit` pode seguir sendo `#[repr(transparent)]` ou non.
/// Dito isto, `MaybeUninit<T>`*sempre* garantirá que ten o mesmo tamaño, aliñamento e ABI que `T`;é só que pode evolucionar o xeito no que `MaybeUninit` implementa esa garantía.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Artigo de Lang para poder envolver nel outros tipos.Isto é útil para os xeradores.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Non chamando ao `T::clone()`, non podemos saber se estamos inicializados o suficiente para iso.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Crea un novo `MaybeUninit<T>` inicializado co valor indicado.
    /// É seguro chamar ao [`assume_init`] polo valor devolto desta función.
    ///
    /// Ten en conta que caer un `MaybeUninit<T>` nunca chamará o código de caída de `T`.
    /// É a súa responsabilidade asegurarse de que se elimina `T` se se inicializou.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Crea un novo `MaybeUninit<T>` nun estado non inicializado.
    ///
    /// Ten en conta que caer un `MaybeUninit<T>` nunca chamará o código de caída de `T`.
    /// É a súa responsabilidade asegurarse de que se elimina `T` se se inicializou.
    ///
    /// Vexa o [type-level documentation][MaybeUninit] para algúns exemplos.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Crea unha nova matriz de elementos `MaybeUninit<T>`, nun estado non inicializado.
    ///
    /// Note: nunha versión future Rust este método pode ser innecesario cando a sintaxe literal da matriz permite [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// O seguinte exemplo pode entón usar `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Devolve unha porción de datos (posiblemente máis pequena) que se leu realmente
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SEGURIDADE: un `[MaybeUninit<_>; LEN]` non inicializado é válido.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Crea un novo `MaybeUninit<T>` nun estado non inicializado, coa memoria enchéndose de bytes `0`.Depende de `T` se iso xa permite a inicialización adecuada.
    ///
    /// Por exemplo, `MaybeUninit<usize>::zeroed()` está inicializado, pero `MaybeUninit<&'static i32>::zeroed()` non porque as referencias non deben ser nulas.
    ///
    /// Ten en conta que caer un `MaybeUninit<T>` nunca chamará o código de caída de `T`.
    /// É a súa responsabilidade asegurarse de que se elimina `T` se se inicializou.
    ///
    /// # Example
    ///
    /// Uso correcto desta función: inicializar unha estrutura con cero, onde todos os campos da estrutura poden manter o patrón de bits 0 como un valor válido.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Uso incorrecto* desta función: chamar a `x.zeroed().assume_init()` cando `0` non é un patrón de bits válido para o tipo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Dentro dun par, creamos un `NotZero` que non ten un discriminante válido.
    /// // Este é un comportamento indefinido.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SEGURIDADE: `u.as_mut_ptr()` apunta á memoria asignada.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Define o valor do `MaybeUninit<T>`.
    /// Isto sobrescribe calquera valor anterior sen deixalo caer, polo que teña coidado de non empregalo dúas veces a non ser que queira saltar a execución do destructor.
    ///
    /// Para a súa comodidade, isto tamén devolve unha referencia mutable aos contidos (agora inicializados con seguridade) de `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SEGURIDADE: Acabamos de inicializar este valor.
        unsafe { self.assume_init_mut() }
    }

    /// Obtén un punteiro ao valor contido.
    /// Ler dende este punteiro ou convertelo nunha referencia é un comportamento indefinido a menos que se inicialice o `MaybeUninit<T>`.
    /// Escribir na memoria que apunta este punteiro (non-transitively) é un comportamento indefinido (excepto dentro dun `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Uso correcto deste método:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Crea unha referencia no `MaybeUninit<T>`.Está ben porque o inicializamos.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Uso incorrecto* deste método:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Creamos unha referencia a un vector non inicializado.Este é un comportamento indefinido.⚠️
    /// ```
    ///
    /// (Teña en conta que as regras en torno ás referencias a datos non inicializados aínda non están finalizadas, pero ata o momento é recomendable evitalas.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` e `ManuallyDrop` son ambos `repr(transparent)` polo que podemos lanzar o punteiro.
        self as *const _ as *const T
    }

    /// Obtén un punteiro mudable ao valor contido.
    /// Ler dende este punteiro ou convertelo nunha referencia é un comportamento indefinido a menos que se inicialice o `MaybeUninit<T>`.
    ///
    /// # Examples
    ///
    /// Uso correcto deste método:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Crea unha referencia no `MaybeUninit<Vec<u32>>`.
    /// // Está ben porque o inicializamos.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Uso incorrecto* deste método:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Creamos unha referencia a un vector non inicializado.Este é un comportamento indefinido.⚠️
    /// ```
    ///
    /// (Teña en conta que as regras en torno ás referencias a datos non inicializados aínda non están finalizadas, pero ata o momento é recomendable evitalas.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` e `ManuallyDrop` son ambos `repr(transparent)` polo que podemos lanzar o punteiro.
        self as *mut _ as *mut T
    }

    /// Extrae o valor do contedor `MaybeUninit<T>`.Esta é unha boa forma de asegurarse de que os datos se eliminarán porque o `T` resultante está suxeito ao tratamento habitual de caída.
    ///
    /// # Safety
    ///
    /// Corresponde ao interlocutor garantir que o `MaybeUninit<T>` realmente se atopa nun estado inicializado.Chamar a isto cando o contido aínda non está completamente inicializado provoca un comportamento indefinido inmediato.
    /// O [type-level documentation][inv] contén máis información sobre esta invariante de inicialización.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Ademais diso, lembre que a maioría dos tipos teñen invariantes adicionais máis aló de considerarse inicializados a nivel de tipo.
    /// Por exemplo, un [`Vec<T>`] inicializado con "1" considérase inicializado (baixo a implementación actual; isto non constitúe unha garantía estable) porque o único requisito que o compilador coñece é que o punteiro de datos non debe ser nulo.
    ///
    /// A creación deste `Vec<T>` non provoca un comportamento *inmediato* indefinido, pero provocará un comportamento indefinido coas operacións máis seguras (incluído o solto).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Uso correcto deste método:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Uso incorrecto* deste método:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` aínda non se inicializara, polo que esta última liña provocou un comportamento indefinido.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SEGURIDADE: o interlocutor debe garantir que se inicializa `self`.
        // Isto tamén significa que `self` debe ser unha variante `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Le o valor do contedor `MaybeUninit<T>`.O `T` resultante está suxeito á manipulación habitual das caídas.
    ///
    /// Sempre que sexa posible, é preferible empregar [`assume_init`] no seu lugar, o que impide duplicar o contido do `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Corresponde ao interlocutor garantir que o `MaybeUninit<T>` realmente se atopa nun estado inicializado.Chamar a isto cando o contido aínda non está completamente inicializado provoca un comportamento indefinido.
    /// O [type-level documentation][inv] contén máis información sobre esta invariante de inicialización.
    ///
    /// Ademais, isto deixa unha copia dos mesmos datos no `MaybeUninit<T>`.
    /// Cando empregue varias copias dos datos (chamando varias veces a `assume_init_read` ou primeiro chamando a `assume_init_read` e despois a [`assume_init`]), é a súa responsabilidade asegurarse de que eses datos se poden duplicar.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Uso correcto deste método:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` é `Copy`, polo que podemos ler varias veces.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Duplicar un valor `None` está ben, polo que podemos ler varias veces.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Uso incorrecto* deste método:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Agora creamos dúas copias do mesmo vector, o que leva a un double️ dobre de balde cando os dous caen.
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SEGURIDADE: o interlocutor debe garantir que se inicializa `self`.
        // A lectura desde `self.as_ptr()` é segura xa que se debería inicializar `self`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Solta o valor contido no lugar.
    ///
    /// Se ten a propiedade do `MaybeUninit`, pode usar [`assume_init`] no seu lugar.
    ///
    /// # Safety
    ///
    /// Corresponde ao interlocutor garantir que o `MaybeUninit<T>` realmente se atopa nun estado inicializado.Chamar a isto cando o contido aínda non está completamente inicializado provoca un comportamento indefinido.
    ///
    /// Ademais, todos os invariantes adicionais do tipo `T` deben cumprirse, xa que a implementación `Drop` de `T` (ou os seus membros) pode confiar niso.
    /// Por exemplo, un [`Vec<T>`] inicializado con "1" considérase inicializado (baixo a implementación actual; isto non constitúe unha garantía estable) porque o único requisito que o compilador coñece é que o punteiro de datos non debe ser nulo.
    ///
    /// Non obstante, caer tal `Vec<T>` causará un comportamento indefinido.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SEGURIDADE: o interlocutor debe garantir que se inicializa `self` e
        // satisfai todos os invariantes de `T`.
        // Soltar o valor no lugar é seguro se é así.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Obtén unha referencia compartida ao valor contido.
    ///
    /// Isto pode ser útil cando queremos acceder a un `MaybeUninit` inicializado pero que non ten a propiedade do `MaybeUninit` (impedindo o uso de `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Chamar a isto cando o contido aínda non está completamente inicializado provoca un comportamento indefinido: correspóndelle ao interlocutor garantir que o `MaybeUninit<T>` realmente está nun estado inicializado.
    ///
    ///
    /// # Examples
    ///
    /// ### Uso correcto deste método:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Inicializar `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Agora que se sabe que o noso `MaybeUninit<_>` está inicializado, está ben crear unha referencia compartida ao mesmo:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SEGURIDADE: `x` foi inicializado.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Usos *incorrectos* deste método:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Creamos unha referencia a un vector non inicializado.Este é un comportamento indefinido.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Inicialice o `MaybeUninit` usando `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Referencia a un `Cell<bool>` non inicializado: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SEGURIDADE: o interlocutor debe garantir que se inicializa `self`.
        // Isto tamén significa que `self` debe ser unha variante `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Obtén unha referencia (unique) mutable ao valor contido.
    ///
    /// Isto pode ser útil cando queremos acceder a un `MaybeUninit` inicializado pero que non ten a propiedade do `MaybeUninit` (impedindo o uso de `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Chamar a isto cando o contido aínda non está completamente inicializado provoca un comportamento indefinido: correspóndelle ao interlocutor garantir que o `MaybeUninit<T>` realmente está nun estado inicializado.
    /// Por exemplo, `.assume_init_mut()` non se pode usar para inicializar un `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Uso correcto deste método:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inicializa *todos* os bytes do búfer de entrada.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Inicializar `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Agora sabemos que se inicializou `buf`, polo que poderiamos `.assume_init()`.
    /// // Non obstante, usar `.assume_init()` pode provocar un `memcpy` dos 2048 bytes.
    /// // Para afirmar que o noso búfer foi inicializado sen copialo, actualizamos o `&mut MaybeUninit<[u8; 2048]>` a un `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SEGURIDADE: `buf` foi inicializado.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Agora podemos usar `buf` como unha porción normal:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Usos *incorrectos* deste método:
    ///
    /// Non pode usar `.assume_init_mut()` para inicializar un valor:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Creamos unha referencia (mutable) a un `bool` non inicializado.
    ///     // Este é un comportamento indefinido.⚠️
    /// }
    /// ```
    ///
    /// Por exemplo, non pode [`Read`] nun buffer non inicializado:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) referencia á memoria non inicializada!
    ///                             // Este é un comportamento indefinido.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Tampouco podes usar o acceso directo a un campo para facer unha inicialización gradual campo a campo:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referencia á memoria non inicializada!
    ///                  // Este é un comportamento indefinido.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referencia á memoria non inicializada!
    ///                  // Este é un comportamento indefinido.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Actualmente confiamos en que o anterior é incorrecto, é dicir, temos referencias a datos non inicializados (por exemplo, en `libcore/fmt/float.rs`).
    // Deberiamos tomar unha decisión final sobre as regras antes da estabilización.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SEGURIDADE: o interlocutor debe garantir que se inicializa `self`.
        // Isto tamén significa que `self` debe ser unha variante `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Extrae os valores dunha matriz de contedores `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Corresponde ao interlocutor garantir que todos os elementos da matriz están nun estado inicializado.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SEGURIDADE: Agora seguro xa que inicializamos todos os elementos
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * O interlocutor garante que se inicializan todos os elementos da matriz
        // * `MaybeUninit<T>` e T están garantidos para ter o mesmo deseño
        // * Quizais Unint non caia, polo que non hai dobre libre. Así, a conversión é segura
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Supoñendo que todos os elementos están inicializados, obtén unha porción.
    ///
    /// # Safety
    ///
    /// Corresponde ao interlocutor garantir que os elementos `MaybeUninit<T>` realmente están nun estado inicializado.
    ///
    /// Chamar a isto cando o contido aínda non está completamente inicializado provoca un comportamento indefinido.
    ///
    /// Vexa [`assume_init_ref`] para obter máis detalles e exemplos.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SEGURIDADE: lanzar unha porción a un `*const [T]` é seguro xa que o interlocutor garante iso
        // `slice` inicialízase e garante que "MayBayUninit" terá o mesmo deseño que `T`.
        // O punteiro obtido é válido xa que se refire á memoria propiedade de `slice` que é unha referencia e, polo tanto, está garantida para que sexa válida para as lecturas.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Supoñendo que todos os elementos están inicializados, obtén unha porción mutable.
    ///
    /// # Safety
    ///
    /// Corresponde ao interlocutor garantir que os elementos `MaybeUninit<T>` realmente están nun estado inicializado.
    ///
    /// Chamar a isto cando o contido aínda non está completamente inicializado provoca un comportamento indefinido.
    ///
    /// Vexa [`assume_init_mut`] para obter máis detalles e exemplos.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SEGURIDADE: semellante ás notas de seguridade para `slice_get_ref`, pero temos un
        // referencia mutable que tamén se garante que é válida para as escrituras.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Obtén un punteiro para o primeiro elemento da matriz.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Obtén un punteiro mudable ao primeiro elemento da matriz.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Copia os elementos de `src` a `this`, devolvendo unha referencia mutable aos contidos agora initalizados de `this`.
    ///
    /// Se `T` non implementa `Copy`, use [`write_slice_cloned`]
    ///
    /// Isto é similar ao [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Esta función será panic se as dúas franxas teñen lonxitudes diferentes.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SEGURIDADE: acabamos de copiar todos os elementos de len na capacidade de reserva
    /// // os primeiros elementos src.len() do vec son válidos agora.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SEGURIDADE: &[T] e&[MaybeUninit<T>] teñen o mesmo deseño
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SEGURIDADE: Os elementos válidos acaban de copiarse en `this` polo que se inicia
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clona os elementos de `src` a `this`, devolvendo unha referencia mutable aos contidos agora initalizados de `this`.
    /// Non se eliminará ningún elemento xa inicializado.
    ///
    /// Se `T` implementa `Copy`, use [`write_slice`]
    ///
    /// Isto é similar ao [`slice::clone_from_slice`] pero non elimina os elementos existentes.
    ///
    /// # Panics
    ///
    /// Esta función será panic se as dúas franxas teñen lonxitudes diferentes ou se a implementación de `Clone` panics.
    ///
    /// Se hai un panic, os elementos xa clonados serán eliminados.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SEGURIDADE: acabamos de clonar todos os elementos de len na capacidade de reposición
    /// // os primeiros elementos src.len() do vec son válidos agora.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // a diferenza de copy_from_slice, isto non se chama clone_from_slice na porción, porque `MaybeUninit<T: Clone>` non implementa Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SEGURIDADE: esta porción en bruto só conterá obxectos inicializados
                // por iso, está permitido soltalo.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Necesitamos cortalos explicitamente na mesma lonxitude
        // para que se eliminen as comprobacións de límites e o optimizador xerará memcpy para casos sinxelos (por exemplo T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // Necesítase garda b/c panic pode ocorrer durante un clon
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SEGURIDADE: Os elementos válidos acaban de escribirse en `this` polo que se inicia
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}