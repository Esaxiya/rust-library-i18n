#![stable(feature = "core_hint", since = "1.27.0")]

//! Consellos para o compilador que afectan a forma de emitir ou optimizar o código.
//! As suxestións poden ser tempo de compilación ou tempo de execución.

use crate::intrinsics;

/// Informa ao compilador de que non se pode alcanzar este punto do código, o que permite novas optimizacións.
///
/// # Safety
///
/// Alcanzar esta función é completamente *comportamento indefinido*(UB).En particular, o compilador asume que non debe ocorrer nunca toda UB e, polo tanto, eliminará todas as ramas que chegan a unha chamada a `unreachable_unchecked()`.
///
/// Como todas as instancias de UB, se esta suposición resulta errónea, é dicir, a chamada `unreachable_unchecked()` é realmente accesible entre todos os fluxos de control posibles, o compilador aplicará a estratexia de optimización incorrecta e ás veces pode incluso corromper código aparentemente non relacionado, provocando dificultades. problemas de depuración.
///
///
/// Use esta función só cando poida demostrar que o código nunca o chamará.
/// En caso contrario, considere usar a macro [`unreachable!`], que non permite optimizacións pero que panic cando se execute.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` sempre é positivo (non cero), polo tanto `checked_div` nunca devolverá `None`.
/////
///     // Polo tanto, a outra branch non é accesible.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SEGURIDADE: o contrato de seguridade para `intrinsics::unreachable` debe
    // ser confirmado polo interlocutor.
    unsafe { intrinsics::unreachable() }
}

/// Emite unha instrución da máquina para indicarlle ao procesador que se está executando nun ciclo de xiro ocupado ("bloqueo de xiro").
///
/// Ao recibir o sinal de spin-loop, o procesador pode optimizar o seu comportamento, por exemplo, aforrando enerxía ou cambiando os fíos hyper.
///
/// Esta función é diferente de [`thread::yield_now`] que cede directamente ao planificador do sistema, mentres que `spin_loop` non interactúa co sistema operativo.
///
/// Un caso de uso común para `spin_loop` é a implementación de xiros optimistas acotados nun bucle CAS en primitivas de sincronización.
/// Para evitar problemas como a inversión de prioridades, recoméndase encarecidamente que o ciclo de xiro se termine despois dunha cantidade finita de iteracións e se faga unha chamada de bloqueo adecuada.
///
///
/// **Nota**: Nas plataformas que non admiten recibir consellos de spin-loop esta función non fai nada.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Un valor atómico compartido que os fíos usarán para coordinar
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Nun fío de fondo eventualmente estableceremos o valor
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Faga un traballo e logo faga vivir o valor
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // De volta ao noso fío actual, esperamos a que se estableza o valor
/// while !live.load(Ordering::Acquire) {
///     // O ciclo de rotación é un indicio para a CPU que estamos esperando, pero probablemente non por moito tempo
/////
///     hint::spin_loop();
/// }
///
/// // O valor xa está definido
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SEGURIDADE: o `cfg` attr garante que só o executemos nos obxectivos x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SEGURIDADE: o `cfg` attr garante que só o executemos nos obxectivos x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SEGURIDADE: o `cfg` attr garante que só o executemos nos obxectivos aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SEGURIDADE: o `cfg` attr garante que só o executemos nos obxectivos do brazo
            // con soporte para a función v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Unha función de identidade que *__ insinúa __* ao compilador para ser o máximo pesimista sobre o que `black_box` podería facer.
///
/// A diferenza de [`std::convert::identity`], anímase a un compilador Rust a asumir que `black_box` pode usar `dummy` de calquera xeito válido posible ao que se permite o código Rust sen introducir un comportamento indefinido no código de chamada.
///
/// Esta propiedade fai que `black_box` sexa útil para escribir código no que non se desexen certas optimizacións, como puntos de referencia.
///
/// Non obstante, teña en conta que `black_box` só (e só se pode fornecer) en base a "best-effort".A medida en que pode bloquear as optimizacións pode variar dependendo da plataforma e do backend de código xen empregado.
/// Os programas non poden confiar en `black_box` para a *corrección* de ningún xeito.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Necesitamos "use" dalgún xeito o argumento que LLVM non pode introspectar e, en obxectivos que o admitan, normalmente podemos aproveitar a montaxe en liña para facelo.
    // A interpretación de LLVM do conxunto en liña é que, ben, é unha caixa negra.
    // Esta non é a mellor implementación xa que probablemente desoptimice máis do que queremos, pero ata agora é o suficientemente boa.
    //
    //

    #[cfg(not(miri))] // Isto só é un consello, polo que está ben saltalo en Miri.
    // SEGURIDADE: o conxunto en liña é sen operacións.
    unsafe {
        // FIXME: Non se pode usar `asm!` porque non admite MIPS e outras arquitecturas.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}