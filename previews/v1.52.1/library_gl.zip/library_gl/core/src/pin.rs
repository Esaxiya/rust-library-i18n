//! Tipos que fixan os datos na súa localización na memoria.
//!
//! Ás veces é útil ter obxectos garantidos para non moverse, no sentido de que a súa colocación na memoria non cambia e, polo tanto, pode confiarse.
//! Un primeiro exemplo deste tipo de escenarios sería a construción de estruturas autoreferenciais, xa que mover un obxecto con punteiros a si mesmos invalidaraas, o que podería provocar un comportamento indefinido.
//!
//! A un nivel alto, un [`Pin<P>`] garante que o apuntador de calquera tipo de punteiro `P` teña unha localización estable na memoria, o que significa que non se pode mover a ningún outro lugar e que a súa memoria non se pode repartir ata que cae.Dicimos que o punto é "pinned".As cousas son máis sutís cando se discuten tipos que combinan datos fixados con datos non fixados;[see below](#projections-and-structural-pinning) para máis detalles.
//!
//! Por defecto, todos os tipos en Rust son móbiles.
//! Rust permite pasar todos os tipos por valor, e os tipos comúns de punteiros intelixentes como [`Box<T>`] e `&mut T` permiten substituír e mover os valores que conteñen: pode saír dun [`Box<T>`] ou pode usar [`mem::swap`].
//! [`Pin<P>`] envolve un punteiro tipo `P`, polo que [`Pin`]`<`[`Box`] `<T>>`funciona como un habitual
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`cae, tamén o fai o seu contido e a memoria queda
//!
//! deslocalizado.Do mesmo xeito, [`Pin ']` <&mut T> `é moi parecido a `&mut T`.Non obstante, [`Pin<P>`] non permite que os clientes obteñan realmente un [`Box<T>`] ou `&mut T` a datos fixados, o que implica que non pode usar operacións como [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` precisa `&mut T`, pero non podemos conseguilo.
//!     // Estamos atascados, non podemos intercambiar o contido destas referencias.
//!     // Poderiamos usar `Pin::get_unchecked_mut`, pero iso non é seguro por unha razón:
//!     // non nos está permitido usalo para sacar cousas do `Pin`.
//! }
//! ```
//!
//! Paga a pena reiterar que [`Pin<P>`]*non* cambia o feito de que un compilador Rust considera que todos os tipos son móbiles.[`mem::swap`] permanece chamable a calquera `T`.Pola contra, [`Pin<P>`] impide mover certos *valores*(apuntados por punteiros envoltos en [`Pin<P>`]) facendo imposible chamar a métodos que requiran `&mut T` (como [`mem::swap`]).
//!
//! [`Pin<P>`] pódese usar para envolver calquera punteiro tipo `P` e, como tal, interactúa con [`Deref`] e [`DerefMut`].Un [`Pin<P>`] onde `P: Deref` debe considerarse como un "`P`-style pointer" a un `P::Target` fixado-polo tanto, un [`Pin`]`<`[`Box`] `<T>>`é un punteiro propiedade dun `T` fixado e un [`Pin`] `<` [`Rc`]`<T>>`é un punteiro con referencia a un `T` fixado.
//! Para a súa corrección, [`Pin<P>`] confía nas implementacións de [`Deref`] e [`DerefMut`] para non saír do seu parámetro `self` e só para devolver un punteiro aos datos fixados cando se chama a un punteiro fixado.
//!
//! # `Unpin`
//!
//! Moitos tipos sempre se poden mover libremente, incluso cando están fixados, porque non dependen de ter un enderezo estable.Isto inclúe todos os tipos básicos (como [`bool`], [`i32`] e referencias), así como os tipos que consisten exclusivamente nestes tipos.Os tipos aos que non lles importa fixar implementan o [`Unpin`] auto-trait, que cancela o efecto de [`Pin<P>`].
//! Para `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`e [`Box<T>`] funcionan de xeito idéntico, do mesmo xeito que [`Pin`] `<&mut T>` e `&mut T`.
//!
//! Teña en conta que a fixación e [`Unpin`] só afectan ao tipo apuntado `P::Target`, non ao punteiro tipo `P` que se envolveu en [`Pin<P>`].Por exemplo, se [`Box<T>`] é [`Unpin`] ou non non ten efecto no comportamento de [`Pin`]`<`[`Box`] `<T>>`(aquí, `T` é o tipo apuntado).
//!
//! # Exemplo: estrutura autorreferencial
//!
//! Antes de entrar en máis detalles para explicar as garantías e opcións asociadas a `Pin<T>`, comentamos algúns exemplos de como se podería usar.
//! Non dubides en [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Esta é unha estrutura autoreferencial porque o campo da porción apunta ao campo de datos.
//! // Non podemos informar ao compilador diso cunha referencia normal, xa que este patrón non se pode describir coas regras habituais de endebedamento.
//! //
//! // En vez diso, usamos un punteiro en bruto, aínda que se sabe que non é nulo, xa que sabemos que apunta á cadea.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Para asegurarnos de que os datos non se moven cando volve a función, colocámolos no montón onde permanecerá durante a vida do obxecto e a única forma de acceder a eles sería a través dun punteiro.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // só creamos o punteiro unha vez que os datos están no seu lugar, xa que se movera antes de comezar
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // sabemos que isto é seguro porque modificar un campo non move toda a estrutura
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // O punteiro debería apuntar cara á situación correcta, sempre que a estrutura non se moveu.
//! //
//! // Mentres tanto, somos libres de mover o punteiro.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Dado que o noso tipo non implementa Unpin, isto fallará ao compilar:
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Exemplo: lista intrusiva dobremente ligada
//!
//! Nunha lista intrusiva dobremente ligada, a colección non asigna realmente a memoria para os elementos en si.
//! A asignación está controlada polos clientes e os elementos poden vivir nun marco de pila que ten unha vida máis curta do que fai a colección.
//!
//! Para que este traballo funcione, cada elemento ten indicacións sobre o seu predecesor e sucesor na lista.Os elementos só se poden engadir cando están fixados porque o movemento dos elementos invalidaría os punteiros.Ademais, a implementación [`Drop`] dun elemento de lista ligada parcheará os indicadores do seu predecesor e sucesor para eliminarse da lista.
//!
//! Fundamentalmente, temos que ser capaces de confiar en que se chame a [`drop`].Se un elemento podería ser repartido ou invalidado doutro xeito sen chamar ao [`drop`], os punteiros dos elementos adxacentes faríanse inválidos, o que rompería a estrutura de datos.
//!
//! Polo tanto, fixar tamén inclúe unha garantía relacionada con [`drop`].
//!
//! # `Drop` guarantee
//!
//! O propósito de fixar é poder contar coa colocación dalgúns datos na memoria.
//! Para que isto funcione, non só se restrinxen os datos;tamén está restrinxida a deslocalización, reutilización ou invalidación da memoria usada para almacenar os datos.
//! Concretamente, para os datos fixados hai que manter o invariante de que *a súa memoria non quedará invalidada nin reutilizada desde o momento en que se fixa ata que se chama [`drop`]*.Só unha vez que [`drop`] devolva ou panics, a memoria pode ser reutilizada.
//!
//! A memoria pode ser "invalidated" mediante deslocalización, pero tamén substituíndo un [`Some(v)`] por [`None`] ou chamando a [`Vec::set_len`] a "kill" algúns elementos dun vector.Pode reutilizarse usando [`ptr::write`] para sobrescribilo sen chamar primeiro ao destructor.Nada disto está permitido para os datos fixados sen chamar ao [`drop`].
//!
//! Este é exactamente o tipo de garantía de que a intrusiva lista ligada da sección anterior precisa para funcionar correctamente.
//!
//! Teña en conta que esta garantía non significa que a memoria non baleire.Aínda está completamente ben non chamar nunca a [`drop`] nun elemento fixado (por exemplo, aínda se pode chamar a [`mem::forget`] cun [`Pin`]`<`[`Box`] `<T>>`).No exemplo da lista dobremente vinculada, ese elemento só quedaría na lista.Non obstante, non pode liberar nin reutilizar o almacenamento *sen chamar a [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Se o teu tipo usa fixación (como os dous exemplos anteriores), debes ter coidado ao implementar [`Drop`].A función [`drop`] leva `&mut self`, pero chámase *aínda que o seu tipo estivese fixado previamente*.É coma se o compilador chamase automaticamente [`Pin::get_unchecked_mut`].
//!
//! Isto nunca pode causar un problema no código seguro porque a implementación dun tipo que depende da fixación require un código non seguro, pero teña en conta que decidir facer uso da fixación no seu tipo (por exemplo, implementando algunha operación en [`Pin`]`<&Self>`ou [`Pin ']`<&mut Self>`) tamén ten consecuencias para a súa implementación de [`Drop`]: se un elemento do seu tipo podería terse fixado, debe tratar a [`Drop`] como implícitamente tomar [`Pin`]` <&mut Auto> `.
//!
//!
//! Por exemplo, podería implementar `Drop` do seguinte xeito:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` está ben porque sabemos que este valor nunca máis se volve a usar despois de ser eliminado.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // O código de caída real vai aquí.
//!         }
//!     }
//! }
//! ```
//!
//! A función `inner_drop` ten o tipo que debería ter [`drop`] *, polo que isto garante que non use `self`/`this` accidentalmente dun xeito que estea en conflito coa fixación.
//!
//! Ademais, se o teu tipo é `#[repr(packed)]`, o compilador moverá automaticamente os campos para poder soltalos.Incluso pode facelo para campos que están suficientemente aliñados.Como consecuencia, non podes usar fixar cun tipo `#[repr(packed)]`.
//!
//! # Proxeccións e fixación estrutural
//!
//! Cando se traballa con estruturas fixadas, xorde a pregunta de como se pode acceder aos campos desa estrutura nun método que só leva [`Pin ']` <&mut Struct> `.
//! O enfoque habitual é escribir métodos auxiliares (chamados *proxeccións*) que converten [`Pin`]`<&mut Struct>`nunha referencia ao campo, pero que tipo debería ter esa referencia?É [`Pin ']` <&mut Field> `ou `&mut Field`?
//! A mesma pregunta xorde cos campos dun `enum`, e tamén ao considerar tipos container/wrapper como [`Vec<T>`], [`Box<T>`] ou [`RefCell<T>`].
//! (Esta pregunta aplícase tanto ás referencias mutables como ás compartidas, só empregamos o caso máis común das referencias mutables aquí como ilustración).
//!
//! Resulta que realmente é o autor da estrutura de datos o que debe decidir se a proxección fixada dun campo concreto converte [`Pin ']` <&mut Struct> `en [` Pin`]`<&mut Field>` ou `&mut Field`.Non obstante, hai algunhas restricións e a restrición máis importante é a *consistencia*:
//! todos os campos poden *proxectarse* cunha referencia fixada, ou * eliminar a fixación como parte da proxección.
//! Se se realizan os dous para o mesmo campo, probablemente non sexa correcto.
//!
//! Como autor dunha estrutura de datos, podes decidir por cada campo se fixas "propagates" a este campo ou non.
//! A fixación que se propaga tamén se chama "structural", porque segue a estrutura do tipo.
//! Nas subseccións seguintes, describimos as consideracións que hai que tomar para calquera elección.
//!
//! ## Fixar *non é* estrutural para `field`
//!
//! Pode parecer contra-intuitivo que o campo dunha estrutura fixada poida que non estea fixado, pero esa é a opción máis sinxela: se nunca se crea un [`Pin`]`<&mut Field>`, nada pode fallar.Entón, se decides que algún campo non ten fixación estrutural, o único que tes que asegurarte é que nunca creas unha referencia fixada a ese campo.
//!
//! Os campos sen fixación estrutural poden ter un método de proxección que converta [`Pin ']` <&mut Struct> `en `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Está ben porque `field` nunca se considera fixado.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Tamén podes `impl Unpin for Struct`*aínda que* o tipo de `field` non sexa [`Unpin`].O que pensa ese tipo sobre a fixación non é relevante cando nunca se crea [[Pin]] `<&mut Field>`.
//!
//! ## Fixar *é* estrutural para `field`
//!
//! A outra opción é decidir que fixar é "structural" para `field`, o que significa que se a estrutura está fixada tamén o é o campo.
//!
//! Isto permite escribir unha proxección que crea un [`Pin`]`<&mut Field>`, testemuñando así que o campo está fixado:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Está ben porque `field` está fixado cando `self` está.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Non obstante, a fixación estrutural inclúe algúns requisitos adicionais:
//!
//! 1. A estrutura só debe ser [`Unpin`] se todos os campos estruturais son [`Unpin`].Este é o valor predeterminado, pero [`Unpin`] é un trait seguro, polo que como autor da estrutura é responsabilidade *non* engadir algo así como `impl<T> Unpin for Struct<T>`.
//! (Teña en conta que para engadir unha operación de proxección é necesario un código non seguro, polo que o feito de que [`Unpin`] sexa un trait seguro non rompe o principio de que só ten que preocuparse por algo disto se usa `non seguro '.)
//! 2. O destructor da estrutura non debe sacar campos estruturais do seu argumento.Este é o punto exacto que se plantexou no [previous section][drop-impl]: `drop` leva `&mut self`, pero a estrutura (e, polo tanto, os seus campos) podería estar fixada antes.
//!     Ten que garantir que non move un campo dentro da súa implementación [`Drop`].
//!     En particular, como se explicou anteriormente, isto significa que a súa estrutura *non* debe ser `#[repr(packed)]`.
//!     Vexa esa sección para saber como escribir [`drop`] dun xeito que o compilador pode axudarlle a non romper accidentalmente a fixación.
//! 3. Debe asegurarse de manter o [`Drop` guarantee][drop-guarantee]:
//!     unha vez fixada a estrutura, a memoria que contén o contido non se sobrescribe nin se deslocala sen chamar aos destrutores do contido.
//!     Isto pode ser complicado, como testemuña [`VecDeque<T>`]: o destructor de [`VecDeque<T>`] pode deixar de chamar a [`drop`] en todos os elementos se un dos destrutores panics.Isto viola a garantía [`Drop`], porque pode provocar a deslocalización de elementos sen que se chame ao seu destructor.([`VecDeque<T>`] non ten proxeccións fixadoras, polo que isto non causa insolencia.)
//! 4. Non debe ofrecer ningunha outra operación que poida levar aos datos a saír dos campos estruturais cando se fixa o seu tipo.Por exemplo, se a estrutura contén un [`Option<T>`] e hai unha operación tipo "take" co tipo `fn(Pin<&mut Struct<T>>) -> Option<T>`, esa operación pódese usar para sacar un `T` dun `Struct<T>` fixado-o que significa que o fixar non pode ser estrutural para o campo que contén este datos.
//!
//!     Para un exemplo máis complexo de sacar datos dun tipo fixado, imaxina se [`RefCell<T>`] tiña un método `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Despois poderiamos facer o seguinte:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Isto é catastrófico, significa que primeiro podemos fixar o contido do [`RefCell<T>`] (usando `RefCell::get_pin_mut`) e despois mover ese contido usando a referencia mutable que obtivemos máis tarde.
//!
//! ## Examples
//!
//! Para un tipo como [`Vec<T>`], ambas as posibilidades (fixación estrutural ou non) teñen sentido.
//! Un [`Vec<T>`] con fixación estrutural podería ter métodos `get_pin`/`get_pin_mut` para obter referencias fixadas a elementos.Non obstante, non podía * permitir chamar a [`pop`][Vec::pop] nun [`Vec<T>`] fixado porque iso movería o contido (fixado estruturalmente).Tampouco podería permitir o [`push`][Vec::push], que podería reasignar e así tamén mover o contido.
//!
//! Un [`Vec<T>`] sen fixación estrutural podería `impl<T> Unpin for Vec<T>`, porque o contido nunca se fixa e o propio [`Vec<T>`] tamén está ben con movelo.
//! Nese momento a fixación non ten ningún efecto sobre o vector.
//!
//! Na biblioteca estándar, os tipos de punteiro xeralmente non teñen fixación estrutural e, polo tanto, non ofrecen proxeccións de fixación.É por iso que `Box<T>: Unpin` ten validez para todos os `T`.
//! Ten sentido facelo para os tipos de punteiro, porque o movemento do `Box<T>` non move o `T`: o [`Box<T>`] pode moverse libremente (tamén coñecido como `Unpin`) aínda que o `T` non o sexa.De feito, incluso [`Pin`]`<`[`Box`] `<T>>`e [`Pin ']`<&mut T>` sempre son os propios [`Unpin`], pola mesma razón: o seu contido (o `T`) está fixado, pero os propios punteiros pódense mover sen mover os datos fixados.
//! Tanto para [`Box<T>`] como para [[Pin]] `<` [`Box`]`<T>>`, se o contido está fixado é totalmente independente de que o punteiro estea fixado, o que significa que fixar non é * estrutural.
//!
//! Ao implementar un combinador [`Future`], normalmente necesitará fixación estrutural para o futures aniñado, xa que precisa obter referencias fixadas a elas para chamar ao [`poll`].
//! Pero se o seu combinador contén outros datos que non precisan fixarse, pode facer que eses campos non sexan estruturais e, polo tanto, acceder a eles libremente cunha referencia mutable incluso cando só ten [`Pin ']` <&mut Self> `(tal como na súa propia implementación [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Un punteiro fixado.
///
/// Este é un envoltorio ao redor dunha especie de punteiro que fai que o punteiro "pin" sexa o seu valor no seu lugar, evitando que se mova o valor a que fai referencia ese punteiro a menos que implante [`Unpin`].
///
///
/// *Consulte a documentación do [`pin` module] para obter unha explicación sobre como fixar.*
///
/// [`pin` module]: self
///
// Note: o `Clone` derivado a continuación provoca insolencia xa que é posible implementalo
// `Clone` para referencias mutables.
// Vexa <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> para máis detalles.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// As seguintes implementacións non se derivan para evitar problemas de solidez.
// `&self.pointer` non debería ser accesible para implementacións trait non fiables.
//
// Vexa <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> para máis detalles.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Constrúe un novo `Pin<P>` arredor dun punteiro para algúns datos dun tipo que implemente [`Unpin`].
    ///
    /// A diferenza de `Pin::new_unchecked`, este método é seguro porque o punteiro `P` desferencia a un tipo [`Unpin`], o que cancela as garantías de fixación.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SEGURIDADE: o valor sinalado é `Unpin`, polo que non ten requisitos
        // arredor de fixación.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Desenvolve este `Pin<P>` devolvendo o punteiro subxacente.
    ///
    /// Isto require que os datos dentro deste `Pin` sexan [`Unpin`] para que poidamos ignorar os invariantes de fixación cando os desembrulles.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Constrúe un novo `Pin<P>` en torno a unha referencia a algúns datos dun tipo que poida ou non implementar `Unpin`.
    ///
    /// Se `pointer` desferencia a un tipo `Unpin`, debería empregarse `Pin::new`.
    ///
    /// # Safety
    ///
    /// Este constructor non é seguro porque non podemos garantir que os datos apuntados por `pointer` estean fixados, o que significa que os datos non se moverán nin se invalidará o seu almacenamento ata que non se caian.
    /// Se o `Pin<P>` construído non garante que os datos aos que apunta `P` estean fixados, iso supón unha violación do contrato API e pode levar a un comportamento indefinido en operacións (safe) posteriores.
    ///
    /// Ao usar este método, fará un promise sobre as implementacións `P::Deref` e `P::DerefMut`, se existen.
    /// O máis importante é que non deben saír dos seus argumentos `self`: `Pin::as_mut` e `Pin::as_ref` chamarán a `DerefMut::deref_mut` e `Deref::deref`*no punteiro fixado* e esperan que estes métodos defendan os invariantes fixados.
    /// Ademais, chamando a este método, promise que as referencias `P` ás referencias non se moverán de novo;en particular, non debe ser posible obter un `&mut P::Target` e despois saír desa referencia (usando, por exemplo, [`mem::swap`]).
    ///
    ///
    /// Por exemplo, chamar a `Pin::new_unchecked` nun `&'a mut T` non é seguro porque, aínda que pode fixalo durante o período de vida determinado `'a`, non ten control sobre se se mantén fixado unha vez que `'a` remata:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Isto debería significar que o punteiro `a` nunca pode moverse de novo.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // O enderezo de `a` cambiou á ranura de pila de "b", polo que `a` cambiou a pesar de que o fixamos previamente.Infrinximos o contrato da API de fixación.
    /////
    /// }
    /// ```
    ///
    /// Un valor, unha vez fixado, debe permanecer fixado para sempre (a non ser que o seu tipo implemente `Unpin`).
    ///
    /// Do mesmo xeito, chamar a `Pin::new_unchecked` nun `Rc<T>` non é seguro porque pode haber alias aos mesmos datos que non están suxeitos ás restricións de fixación:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Isto debería significar que o apuntador nunca pode moverse de novo.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Agora, se `x` era a única referencia, temos unha referencia mutable a datos que fixamos máis arriba, que poderiamos empregar para movelos como vimos no exemplo anterior.
    ///     // Infrinximos o contrato da API de fixación.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Obtén unha referencia compartida fixada desde este punteiro fixado.
    ///
    /// Este é un método xenérico para ir de `&Pin<Pointer<T>>` a `Pin<&T>`.
    /// É seguro porque, como parte do contrato de `Pin::new_unchecked`, o apuntador non pode moverse despois de que se creou `Pin<Pointer<T>>`.
    ///
    /// "Malicious" as implementacións de `Pointer::Deref` tamén están descartadas polo contrato de `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SEGURIDADE: consulte a documentación sobre esta función
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Desenvolve este `Pin<P>` devolvendo o punteiro subxacente.
    ///
    /// # Safety
    ///
    /// Esta función non é segura.Debe garantir que seguirá tratando o punteiro `P` como fixado despois de chamar a esta función, para que se poidan manter os invariantes do tipo `Pin`.
    /// Se o código que usa o `P` resultante non continúa mantendo os invariantes de fixación, iso supón unha violación do contrato API e pode levar a un comportamento indefinido en operacións (safe) posteriores.
    ///
    ///
    /// Se os datos subxacentes son [`Unpin`], debería empregarse [`Pin::into_inner`].
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Obtén unha referencia mutable fixada desde este punteiro fixado.
    ///
    /// Este é un método xenérico para ir de `&mut Pin<Pointer<T>>` a `Pin<&mut T>`.
    /// É seguro porque, como parte do contrato de `Pin::new_unchecked`, o apuntador non pode moverse despois de que se creou `Pin<Pointer<T>>`.
    ///
    /// "Malicious" as implementacións de `Pointer::DerefMut` tamén están descartadas polo contrato de `Pin::new_unchecked`.
    ///
    /// Este método é útil cando se realizan varias chamadas a funcións que consumen o tipo fixado.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // facer algo
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` consume `self`, así que volve pedir o `Pin<&mut Self>` a través de `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SEGURIDADE: consulte a documentación sobre esta función
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Asigna un novo valor á memoria detrás da referencia fixada.
    ///
    /// Isto sobrescribe os datos fixados, pero está ben: o seu destructor execútase antes de sobreescribilo, polo que non se incumpre ningunha garantía de fixación.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Constrúe un novo pin mapeando o valor interior.
    ///
    /// Por exemplo, se quería obter un `Pin` dun campo de algo, podería usalo para acceder a ese campo nunha liña de código.
    /// Non obstante, hai varios gotchas con estes "pinning projections";
    /// consulte a documentación [`pin` module] para máis detalles sobre este tema.
    ///
    /// # Safety
    ///
    /// Esta función non é segura.
    /// Debe garantir que os datos que devolva non se moverán mentres o valor do argumento non se mova (por exemplo, porque é un dos campos dese valor), e tamén que non saia do argumento que reciba a a función interior.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SEGURIDADE: o contrato de seguridade para `new_unchecked` debe ser
        // confirmado polo interlocutor.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Obtén unha referencia compartida dun pin.
    ///
    /// Isto é seguro porque non é posible saír dunha referencia compartida.
    /// Pode parecer que hai un problema aquí coa mutabilidade interior: de feito,*é* posible sacar un `T` dun `&RefCell<T>`.
    /// Non obstante, este non é un problema mentres non exista tamén un `Pin<&T>` que apunte aos mesmos datos e `RefCell<T>` non che permita crear unha referencia fixada ao seu contido.
    ///
    /// Vexa a discusión sobre ["pinning projections"] para máis detalles.
    ///
    /// Note: `Pin` tamén implementa `Deref` no destino, que se pode usar para acceder ao valor interno.
    /// Non obstante, `Deref` só proporciona unha referencia que se mantén durante o tempo que leva o préstamo do `Pin`, non a vida do `Pin` en si.
    /// Este método permite converter o `Pin` nunha referencia coa mesma vida útil que o `Pin` orixinal.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Converte este `Pin<&mut T>` nun `Pin<&T>` coa mesma vida útil.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Obtén unha referencia mutable aos datos dentro deste `Pin`.
    ///
    /// Isto require que os datos deste `Pin` sexan `Unpin`.
    ///
    /// Note: `Pin` tamén implementa `DerefMut` nos datos, que se poden usar para acceder ao valor interno.
    /// Non obstante, `DerefMut` só proporciona unha referencia que se mantén durante o tempo que leva o préstamo do `Pin`, non a vida do `Pin` en si.
    ///
    /// Este método permite converter o `Pin` nunha referencia coa mesma vida útil que o `Pin` orixinal.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Obtén unha referencia mutable aos datos dentro deste `Pin`.
    ///
    /// # Safety
    ///
    /// Esta función non é segura.
    /// Debe garantir que nunca moverá os datos da referencia mutable que recibe cando chama a esta función, para que se poidan manter os invariantes do tipo `Pin`.
    ///
    ///
    /// Se os datos subxacentes son `Unpin`, debería empregarse `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Constrúe un novo pin mapeando o valor interior.
    ///
    /// Por exemplo, se quería obter un `Pin` dun campo de algo, podería usalo para acceder a ese campo nunha liña de código.
    /// Non obstante, hai varios gotchas con estes "pinning projections";
    /// consulte a documentación [`pin` module] para máis detalles sobre este tema.
    ///
    /// # Safety
    ///
    /// Esta función non é segura.
    /// Debe garantir que os datos que devolva non se moverán mentres o valor do argumento non se mova (por exemplo, porque é un dos campos dese valor), e tamén que non saia do argumento que reciba a a función interior.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SEGURIDADE: o interlocutor é responsable de non mover o
        // valor desta referencia.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SEGURIDADE: xa que o valor de `this` está garantido para non ter
        // fora de casa, esta chamada ao `new_unchecked` é segura.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Obtén unha referencia fixada a partir dunha referencia estática.
    ///
    /// Isto é seguro, porque `T` está prestado para a vida útil de `'static`, que nunca remata.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SEGURIDADE: O préstamo estático garante que os datos non serán
        // moved/invalidated ata que cae (que nunca é).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Obtén unha referencia mutable fixada a partir dunha referencia mutable estática.
    ///
    /// Isto é seguro, porque `T` está prestado para a vida útil de `'static`, que nunca remata.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SEGURIDADE: O préstamo estático garante que os datos non serán
        // moved/invalidated ata que cae (que nunca é).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: isto significa que calquera impl de `CoerceUnsized` que permita coaccionar desde
// un tipo que implica `Deref<Target=impl !Unpin>` a un tipo que implica `Deref<Target=Unpin>` non é correcto.
// Calquera tipo de implícito probablemente non tería razón por outras razóns, polo que só precisamos ter coidado de non permitir que estes implícitos aterren en std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}