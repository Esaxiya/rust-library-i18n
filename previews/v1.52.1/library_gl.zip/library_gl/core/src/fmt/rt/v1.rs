//! Este é un módulo interno usado polo ifmt!tempo de execución.Estas estruturas emítense a matrices estáticas para precompilar cadeas de formato antes de tempo.
//!
//! Estas definicións son similares aos seus equivalentes `ct`, pero difiren en que se poden asignar estáticamente e están lixeiramente optimizadas para o tempo de execución.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Posibles aliñacións que se poden solicitar como parte dunha directiva de formato.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Indicación de que os contidos deben aliñarse á esquerda.
    Left,
    /// Indicación de que os contidos deben estar aliñados á dereita.
    Right,
    /// Indicación de que os contidos deben estar aliñados ao centro.
    Center,
    /// Non se solicitou aliñación.
    Unknown,
}

/// Usado polos especificadores [width](https://doc.rust-lang.org/std/fmt/#width) e [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Especificado cun número literal, almacena o valor
    Is(usize),
    /// Especificado mediante sintaxis `$` e `*`, almacena o índice en `args`
    Param(usize),
    /// Non especificado
    Implied,
}