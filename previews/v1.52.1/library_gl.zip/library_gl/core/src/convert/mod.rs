//! Traits para conversións entre tipos.
//!
//! O traits deste módulo proporciona un xeito de converter dun tipo a outro.
//! Cada trait ten un propósito diferente:
//!
//! - Implemente o [`AsRef`] trait para conversións baratas de referencia a referencia
//! - Implemente o [`AsMut`] trait para conversións baratas de mutable a mutable
//! - Implemente o [`From`] trait para consumir conversións de valor a valor
//! - Implemente o [`Into`] trait para consumir conversións valor-valor a tipos alleos ao crate actual
//! - Os [`TryFrom`] e [`TryInto`] traits compórtanse como [`From`] e [`Into`], pero deberían implementarse cando a conversión poida fallar.
//!
//! O traits deste módulo úsase a miúdo como trait bounds para funcións xenéricas de tal xeito que se admiten argumentos de varios tipos.Vexa a documentación de cada trait para ver exemplos.
//!
//! Como autor da biblioteca, sempre deberías preferir implementar [`From<T>`][`From`] ou [`TryFrom<T>`][`TryFrom`] en lugar de [`Into<U>`][`Into`] ou [`TryInto<U>`][`TryInto`], xa que [`From`] e [`TryFrom`] proporcionan maior flexibilidade e ofrecen implementacións equivalentes de [`Into`] ou [`TryInto`] de balde, grazas a unha implementación de manta na biblioteca estándar.
//! Cando se orienta a unha versión anterior a Rust 1.41, pode ser necesario implementar [`Into`] ou [`TryInto`] directamente ao converter a un tipo fóra do crate actual.
//!
//! # Implementacións xenéricas
//!
//! - [`AsRef`] e autodereferencia [`AsMut`] se o tipo interno é unha referencia
//! - [`De`]`<U>para T` implica [`Into`]`</u><T><U>para U`</u>
//! - [`TryFrom`]`<U>para T` implica [`TryInto`]`</u><T><U>para U`</u>
//! - [`From`] e [`Into`] son reflexivos, o que significa que todos os tipos poden `into` por si mesmos e `from` por si mesmos
//!
//! Vexa cada trait para ver exemplos de uso.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// A función identitaria.
///
/// Dúas cousas son importantes a ter en conta sobre esta función:
///
/// - Non sempre equivale a un peche como `|x| x`, xa que o peche pode coaccionar a `x` nun tipo diferente.
///
/// - Move a entrada `x` pasada á función.
///
/// Aínda que poida parecer estraño ter unha función que só devolve a entrada, hai algúns usos interesantes.
///
///
/// # Examples
///
/// Usar `identity` para non facer nada nunha secuencia doutras funcións interesantes:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Pretendamos que engadir un é unha función interesante.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Usando `identity` como caso base "do nothing" nun condicional:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Fai cousas máis interesantes ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Usando `identity` para manter as variantes `Some` dun iterador de `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Adoitaba facer unha conversión barata de referencia a referencia.
///
/// Este trait é similar ao [`AsMut`] que se usa para converter entre referencias mutables.
/// Se precisa facer unha custosa conversión, é mellor implementar [`From`] co tipo `&T` ou escribir unha función personalizada.
///
/// `AsRef` ten a mesma sinatura que [`Borrow`], pero [`Borrow`] é diferente en poucos aspectos:
///
/// - A diferenza de `AsRef`, [`Borrow`] ten un implante de manta para calquera `T` e pode usarse para aceptar unha referencia ou un valor.
/// - [`Borrow`] tamén require que [`Hash`], [`Eq`] e [`Ord`] para o valor prestado sexan equivalentes aos do valor posuído.
/// Por esta razón, se queres pedir prestado só un único campo dunha estrutura, podes implementar `AsRef`, pero non [`Borrow`].
///
/// **Note: Este trait non debe fallar **.Se a conversión pode fallar, use un método dedicado que devolve un [`Option<T>`] ou un [`Result<T, E>`].
///
/// # Implementacións xenéricas
///
/// - `AsRef` autoreferencias se o tipo interno é unha referencia ou unha referencia mutable (por exemplo: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Ao usar trait bounds podemos aceptar argumentos de diferentes tipos sempre que se poidan converter ao tipo especificado `T`.
///
/// Por exemplo: Ao crear unha función xenérica que leva un `AsRef<str>`, expresamos que queremos aceptar todas as referencias que se poden converter a [`&str`] como argumento.
/// Dado que [`String`] e [`&str`] implementan `AsRef<str>` podemos aceptalos como argumento de entrada.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Realiza a conversión.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Adoitaba facer unha conversión de referencia mutable a mutable barata.
///
/// Este trait é similar ao [`AsRef`] pero úsase para converter entre referencias mutables.
/// Se precisa facer unha custosa conversión, é mellor implementar [`From`] co tipo `&mut T` ou escribir unha función personalizada.
///
/// **Note: Este trait non debe fallar **.Se a conversión pode fallar, use un método dedicado que devolve un [`Option<T>`] ou un [`Result<T, E>`].
///
/// # Implementacións xenéricas
///
/// - `AsMut` autoreferencias se o tipo interno é unha referencia mutable (por exemplo: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Usando `AsMut` como trait bound para unha función xenérica podemos aceptar todas as referencias mutables que se poden converter ao tipo `&mut T`.
/// Debido a que [`Box<T>`] implementa `AsMut<T>` podemos escribir unha función `add_one` que leva todos os argumentos que se poden converter a `&mut u64`.
/// Debido a que [`Box<T>`] implementa `AsMut<T>`, `add_one` tamén acepta argumentos do tipo `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Realiza a conversión.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Unha conversión de valor a valor que consume o valor de entrada.O contrario que [`From`].
///
/// Débese evitar implementar [`Into`] e implementar [`From`] no seu lugar.
/// A implementación de [`From`] proporciona automaticamente unha implementación de [`Into`] grazas á implementación da manta na biblioteca estándar.
///
/// Prefire usar [`Into`] sobre [`From`] cando especifique trait bounds nunha función xenérica para garantir que tamén se poidan usar tipos que só implementan [`Into`].
///
/// **Note: Este trait non debe fallar **.Se a conversión pode fallar, use [`TryInto`].
///
/// # Implementacións xenéricas
///
/// - [`De`]`<T>para U` implica `Into<U> for T`
/// - [`Into`] é reflexivo, o que significa que `Into<T> for T` está implementado
///
/// # Implementando [`Into`] para conversións a tipos externos en versións antigas de Rust
///
/// Antes do Rust 1.41, se o tipo de destino non formaba parte do crate actual, entón non se podería implementar [`From`] directamente.
/// Por exemplo, tome este código:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Isto fallará ao compilarse en versións máis antigas do idioma porque as regras de orfandade de Rust adoitaban ser un pouco máis estritas.
/// Para evitar isto, podería implementar [`Into`] directamente:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// É importante entender que [`Into`] non proporciona unha implementación [`From`] (como fai [`From`] con [`Into`]).
/// Polo tanto, sempre debe intentar implementar [`From`] e despois volver a [`Into`] se [`From`] non se pode implementar.
///
/// # Examples
///
/// [`String`] implementa [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Para expresar que queremos que unha función xenérica tome todos os argumentos que se poidan converter nun tipo especificado `T`, podemos usar un trait bound de [`Into`]`<T>`.
///
/// Por exemplo: A función `is_hello` leva todos os argumentos que se poden converter nun [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Realiza a conversión.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Úsase para facer conversións de valor a valor mentres se consume o valor de entrada.É o recíproco de [`Into`].
///
/// Sempre se prefire implementar `From` sobre [`Into`] porque a implementación de `From` proporciona automaticamente unha implementación de [`Into`] grazas á implementación de manta na biblioteca estándar.
///
///
/// Implemente [`Into`] só cando oriente unha versión anterior a Rust 1.41 e se converta a un tipo fóra do crate actual.
/// `From` non foi capaz de facer este tipo de conversións en versións anteriores debido ás regras de orfandade de Rust.
/// Vexa [`Into`] para máis detalles.
///
/// Preferir usar [`Into`] antes que usar `From` cando se especifica trait bounds nunha función xenérica.
/// Deste xeito, os tipos que implementan directamente [`Into`] tamén se poden usar como argumentos.
///
/// O `From` tamén é moi útil cando se realiza o tratamento de erros.Ao construír unha función capaz de fallar, o tipo de retorno xeralmente será da forma `Result<T, E>`.
/// O `From` trait simplifica o tratamento de erros permitindo que unha función devolva un único tipo de erro que encapsule varios tipos de erro.Vexa a sección "Examples" e [the book][book] para máis detalles.
///
/// **Note: Este trait non debe fallar **.Se a conversión pode fallar, use [`TryFrom`].
///
/// # Implementacións xenéricas
///
/// - `From<T> for U` implica [`Into`]`<U>para T`</u>
/// - `From` é reflexivo, o que significa que `From<T> for T` está implementado
///
/// # Examples
///
/// [`String`] implementa `From<&str>`:
///
/// Unha conversión explícita dun `&str` a unha cadea faise do seguinte xeito:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Ao realizar o tratamento de erros, a miúdo é útil implementar `From` para o seu propio tipo de erro.
/// Ao converter os tipos de erro subxacentes ao noso propio tipo de erro personalizado que encapsula o tipo de erro subxacente, podemos devolver un único tipo de erro sen perder información sobre a causa subxacente.
/// O operador '?' converte automaticamente o tipo de erro subxacente ao noso tipo de erro personalizado chamando ao `Into<CliError>::into` que se proporciona automaticamente ao implementar `From`.
/// A continuación, o compilador deduce que implementación de `Into` debería usarse.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Realiza a conversión.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Un intento de conversión que consume `self`, que pode ser caro ou non.
///
/// Os autores das bibliotecas normalmente non deberían implementar directamente este trait, pero deberían preferir implementar o [`TryFrom`] trait, que ofrece maior flexibilidade e ofrece unha implementación equivalente de `TryInto` de balde, grazas a unha implementación de manta na biblioteca estándar.
/// Para obter máis información ao respecto, consulte a documentación de [`Into`].
///
/// # Implementando `TryInto`
///
/// Isto sofre as mesmas restricións e razoamentos que a implementación de [`Into`]; consulte alí para máis detalles.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// O tipo devolto en caso de erro de conversión.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Realiza a conversión.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Conversións de tipo sinxelas e seguras que poden fallar dun xeito controlado nalgunhas circunstancias.É o recíproco de [`TryInto`].
///
/// Isto é útil cando está a facer unha conversión de tipo que pode ter éxito trivialmente pero tamén pode necesitar un tratamento especial.
/// Por exemplo, non hai ningunha forma de converter un [`i64`] nun [`i32`] usando o [`From`] trait, porque un [`i64`] pode conter un valor que un [`i32`] non pode representar e polo tanto a conversión perdería datos.
///
/// Isto pode resolverse truncando o [`i64`] a un [`i32`] (dando esencialmente o módulo de valor de [`i64`] [`i32::MAX`]) ou simplemente devolvendo [`i32::MAX`], ou por algún outro método.
/// O [`From`] trait está destinado a conversións perfectas, polo que o `TryFrom` trait informa ao programador cando unha conversión de tipo pode ir mal e permítelle decidir como manexala.
///
/// # Implementacións xenéricas
///
/// - `TryFrom<T> for U` implica [`TryInto`]`<U>para T`</u>
/// - [`try_from`] é reflexivo, o que significa que `TryFrom<T> for T` está implementado e non pode fallar; o tipo `Error` asociado para chamar a `T::try_from()` cun valor do tipo `T` é [`Infallible`].
/// Cando o tipo [`!`] está estabilizado [`Infallible`] e [`!`] serán equivalentes.
///
/// `TryFrom<T>` pódese implementar do seguinte xeito:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Como se describe, [`i32`] implementa `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Truncar en silencio `big_number`, require detectar e tratar o truncamento despois do feito.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Devolve un erro porque `big_number` é demasiado grande para caber nun `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Devolve `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// O tipo devolto en caso de erro de conversión.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Realiza a conversión.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS XENÉRICOS
////////////////////////////////////////////////////////////////////////////////

// Como se levanta
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Como ascensores superiores a &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): substitúe os impls anteriores por&/&mut polo seguinte máis xeral:
// // Como ascensores sobre Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Tamaño> AsRef <U>para D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut levanta máis de &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): substitúe o anterior impl por &mut polo seguinte máis xeral:
// // AsMut levanta sobre DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Tamaño> AsMut <U>para D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// De implica Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (e, polo tanto, Into) é reflexivo
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Nota de estabilidade:** Esta aplicación aínda non existe, pero somos "reserving space" para engadila no future.
/// Vexa [rust-lang/rust#64715][#64715] para máis detalles.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): no seu lugar faga unha corrección de principios.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom implica TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// As conversións infalibles son semanticamente equivalentes ás conversións falibles cun tipo de erro deshabitado.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS DE FORMIGÓN
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// O TIPO DE ERRO SEN ERROS
////////////////////////////////////////////////////////////////////////////////

/// O tipo de erro para erros que nunca poden ocorrer.
///
/// Dado que esta enumeración non ten ningunha variante, nunca pode existir un valor deste tipo.
/// Isto pode ser útil para as API xenéricas que usan [`Result`] e parametrizan o tipo de erro, para indicar que o resultado sempre é [`Ok`].
///
/// Por exemplo, o [`TryFrom`] trait (conversión que devolve un [`Result`]) ten unha implementación global para todos os tipos onde existe unha implementación [`Into`] inversa.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Compatibilidade con Future
///
/// Esta enum ten o mesmo papel que [the `!`“never”type][never], que é inestable nesta versión de Rust.
/// Cando `!` está estabilizado, planeamos facer de `Infallible` un alias tipo:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... e finalmente desaproveitará o `Infallible`.
///
/// Non obstante, hai un caso no que a sintaxe `!` pode usarse antes de que `!` se estabilice como un tipo completo: na posición do tipo de retorno dunha función.
/// En concreto, son posibles implementacións para dous tipos de punteiros de función diferentes:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Como `Infallible` é unha enumeración, este código é válido.
/// Non obstante, cando `Infallible` se converta nun alias para o never type, os dous `impl`s comezarán a superpoñerse e, polo tanto, serán anulados polas regras de coherencia do idioma trait.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}