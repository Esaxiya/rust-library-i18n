#![stable(feature = "futures_api", since = "1.36.0")]

//! Valores asíncronos.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Este tipo é necesario porque:
///
/// a) Os xeradores non poden implementar `for<'a, 'b> Generator<&'a mut Context<'b>>`, polo que necesitamos pasar un punteiro en bruto (ver <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Os punteiros en bruto e `NonNull` non son `Send` ou `Sync`, polo que iso tamén faría que cada future sexa non-Send/Sync e iso non o queremos.
///
/// Tamén simplifica a redución HIR de `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Envolve un xerador nun future.
///
/// Esta función devolve un `GenFuture` debaixo, pero ocúltao en `impl Trait` para dar mellores mensaxes de erro (`impl Future` en lugar de `GenFuture<[closure.....]>`).
///
// Este é `const` para evitar erros adicionais despois de recuperarnos de `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Confiamos no feito de que async/await futures son inamovibles para crear préstamos autorreferenciais no xerador subxacente.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SEGURIDADE: Seguro porque somos !Unpin + !Drop, e isto só é unha proxección de campo.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Reanude o xerador convertendo o `&mut Context` nun punteiro en bruto `NonNull`.
            // A baixada do `.await` devolverá con seguridade a un `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SEGURIDADE: o interlocutor debe garantir que `cx.0` é un punteiro válido
    // que cumpre todos os requisitos para unha referencia mutable.
    unsafe { &mut *cx.0.as_ptr().cast() }
}