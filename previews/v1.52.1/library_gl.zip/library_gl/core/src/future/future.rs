#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Un future representa un cálculo asíncrono.
///
/// Un future é un valor que pode que aínda non remate de computar.
/// Este tipo de "asynchronous value" fai posible que un fío siga facendo un traballo útil mentres espera a que o valor estea dispoñible.
///
///
/// # O método `poll`
///
/// O método principal de future, `poll`,*intenta* resolver o future nun valor final.
/// Este método non se bloquea se o valor non está preparado.
/// Pola contra, a tarefa actual está programada para ser espertada cando sexa posible avanzar máis facendo "sondaxe" de novo.
/// O `context` pasado ao método `poll` pode proporcionar un [`Waker`], que é un identificador para espertar a tarefa actual.
///
/// Ao usar un future, normalmente non chamará directamente ao `poll`, senón ao valor `.await`.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// O tipo de valor producido ao finalizar.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Tente resolver o future ata un valor final, rexistrando a tarefa actual para o despertar se o valor aínda non está dispoñible.
    ///
    /// # Valor de devolución
    ///
    /// Esta función devolve:
    ///
    /// - [`Poll::Pending`] se o future aínda non está listo
    /// - [`Poll::Ready(val)`] co resultado `val` deste future se rematou con éxito.
    ///
    /// Unha vez que remate un future, os clientes non deberían volvelo `poll`.
    ///
    /// Cando un future aínda non está listo, `poll` devolve `Poll::Pending` e almacena un clon do [`Waker`] copiado do [`Context`] actual.
    /// Este [`Waker`] espértase unha vez que o future pode avanzar.
    /// Por exemplo, un future á espera de que se poida ler un socket chamaría ao `.clone()` no [`Waker`] e almacenábao.
    /// Cando chega un sinal noutro lugar que indica que o socket é lexible, chámase [`Waker::wake`] e espértase a tarefa do socket future.
    /// Unha vez espertada unha tarefa, debería intentar `poll` o future de novo, o que pode producir ou non un valor final.
    ///
    /// Teña en conta que en varias chamadas a `poll`, só o [`Waker`] do [`Context`] pasado á chamada máis recente debería estar programado para recibir un aviso.
    ///
    /// # Características do tempo de execución
    ///
    /// Futures só é *inerte*;deben facerse * enquisas "activas" para avanzar, o que significa que cada vez que se desperta a tarefa actual, debería volver activarse de xeito continuo pendente de futures que aínda ten interese.
    ///
    /// A función `poll` non se chama repetidamente nun circuíto axustado; en vez diso, só se debe chamar cando o future indica que está preparado para avanzar (chamando ao `wake()`).
    /// Se está familiarizado coas descargas `poll(2)` ou `select(2)` en Unix, vale a pena notar que futures normalmente *non* sofre os mesmos problemas de "all wakeups must poll all events";son máis parecidos ao `epoll(4)`.
    ///
    /// Unha implementación de `poll` debe esforzarse por volver rapidamente e non debe bloquearse.Volver rapidamente evita obstruír innecesariamente fíos ou bucles de eventos.
    /// Se se sabe con antelación que unha chamada a `poll` pode acabar tardando un tempo, o traballo debería descargarse a un grupo de fíos (ou algo similar) para garantir que `poll` poida volver rapidamente.
    ///
    /// # Panics
    ///
    /// Unha vez que completou un future (devolveu `Ready` de `poll`), chamar de novo ao seu método `poll` pode panic, bloquearse para sempre ou causar outro tipo de problemas;o `Future` trait non aplica ningún requisito aos efectos de tal chamada.
    /// Non obstante, como o método `poll` non está marcado como `unsafe`, aplícanse as regras habituais de Rust: as chamadas nunca deben causar un comportamento indefinido (corrupción da memoria, uso incorrecto das funcións `unsafe` ou similares), independentemente do estado do future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}