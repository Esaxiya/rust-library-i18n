//! Compilación intrínseca.
//!
//! As definicións correspondentes están en `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! As implementacións const correspondentes están en `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrínsecos
//!
//! Note: calquera cambio na constancia dos intrínsecos debe ser discutido co equipo de idiomas.
//! Isto inclúe cambios na estabilidade da constancia.
//!
//! Para facer un intrínseco utilizable no tempo de compilación, cómpre copiar a implementación de <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> a `compiler/rustc_mir/src/interpret/intrinsics.rs` e engadir un `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ao intrínseco.
//!
//!
//! Se se supón que se usa un intrínseco a partir dun `const fn` cun atributo `rustc_const_stable`, o atributo intrínseco tamén debe ser `rustc_const_stable`.
//! Este cambio non se debería facer sen consulta T-lang, porque fornece unha característica no idioma que non se pode replicar no código de usuario sen o soporte do compilador.
//!
//! # Volatiles
//!
//! Os intrínsecos volátiles proporcionan operacións destinadas a actuar sobre a memoria I/O, que o compilador garante que non será reordenado a través doutros intrínsecos volátiles.Consulte a documentación LLVM en [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Os intrínsecos atómicos proporcionan operacións atómicas comúns nas palabras da máquina, con múltiples ordenacións de memoria posibles.Obedecen á mesma semántica que C++ 11.Consulte a documentación LLVM en [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Unha actualización rápida sobre a orde de memoria:
//!
//! * Adquirir, unha barreira para adquirir un peche.As lecturas e escrituras posteriores teñen lugar despois da barreira.
//! * Liberación, unha barreira para liberar unha pechadura.As lecturas e escrituras anteriores teñen lugar antes da barreira.
//! * As operacións secuencialmente consistentes, secuencialmente consistentes están garantidas para que ocorran en orde.Este é o modo estándar para traballar con tipos atómicos e equivale ao `volatile` de Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Estas importacións úsanse para simplificar as ligazóns intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SEGURIDADE: ver `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, estes intrínsecos toman punteiros sen procesar porque mutan a memoria alias, o que non é válido nin para `&` nin para `&mut`.
    //

    /// Almacena un valor se o valor actual é o mesmo que o valor `old`.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `compare_exchange` pasando [`Ordering::SeqCst`] como parámetros `success` e `failure`.
    ///
    /// Por exemplo, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor se o valor actual é o mesmo que o valor `old`.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `compare_exchange` pasando [`Ordering::Acquire`] como parámetros `success` e `failure`.
    ///
    /// Por exemplo, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor se o valor actual é o mesmo que o valor `old`.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `compare_exchange` pasando [`Ordering::Release`] como `success` e [`Ordering::Relaxed`] como parámetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor se o valor actual é o mesmo que o valor `old`.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `compare_exchange` pasando [`Ordering::AcqRel`] como `success` e [`Ordering::Acquire`] como parámetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor se o valor actual é o mesmo que o valor `old`.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `compare_exchange` pasando [`Ordering::Relaxed`] como parámetros `success` e `failure`.
    ///
    /// Por exemplo, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor se o valor actual é o mesmo que o valor `old`.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `compare_exchange` pasando [`Ordering::SeqCst`] como `success` e [`Ordering::Relaxed`] como parámetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor se o valor actual é o mesmo que o valor `old`.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `compare_exchange` pasando [`Ordering::SeqCst`] como `success` e [`Ordering::Acquire`] como parámetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor se o valor actual é o mesmo que o valor `old`.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `compare_exchange` pasando [`Ordering::Acquire`] como `success` e [`Ordering::Relaxed`] como parámetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor se o valor actual é o mesmo que o valor `old`.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `compare_exchange` pasando [`Ordering::AcqRel`] como `success` e [`Ordering::Relaxed`] como parámetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Almacena un valor se o valor actual é o mesmo que o valor `old`.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `compare_exchange_weak` pasando [`Ordering::SeqCst`] como parámetros `success` e `failure`.
    ///
    /// Por exemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor se o valor actual é o mesmo que o valor `old`.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `compare_exchange_weak` pasando [`Ordering::Acquire`] como parámetros `success` e `failure`.
    ///
    /// Por exemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor se o valor actual é o mesmo que o valor `old`.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `compare_exchange_weak` pasando [`Ordering::Release`] como `success` e [`Ordering::Relaxed`] como parámetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor se o valor actual é o mesmo que o valor `old`.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `compare_exchange_weak` pasando [`Ordering::AcqRel`] como `success` e [`Ordering::Acquire`] como parámetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor se o valor actual é o mesmo que o valor `old`.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `compare_exchange_weak` pasando [`Ordering::Relaxed`] como parámetros `success` e `failure`.
    ///
    /// Por exemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor se o valor actual é o mesmo que o valor `old`.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `compare_exchange_weak` pasando [`Ordering::SeqCst`] como `success` e [`Ordering::Relaxed`] como parámetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor se o valor actual é o mesmo que o valor `old`.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `compare_exchange_weak` pasando [`Ordering::SeqCst`] como `success` e [`Ordering::Acquire`] como parámetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor se o valor actual é o mesmo que o valor `old`.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `compare_exchange_weak` pasando [`Ordering::Acquire`] como `success` e [`Ordering::Relaxed`] como parámetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Almacena un valor se o valor actual é o mesmo que o valor `old`.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `compare_exchange_weak` pasando [`Ordering::AcqRel`] como `success` e [`Ordering::Relaxed`] como parámetros `failure`.
    /// Por exemplo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Carga o valor actual do punteiro.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `load` pasando [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Carga o valor actual do punteiro.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `load` pasando [`Ordering::Acquire`] como `order`.
    /// Por exemplo, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Carga o valor actual do punteiro.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `load` pasando [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Almacena o valor na localización de memoria especificada.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `store` pasando [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Almacena o valor na localización de memoria especificada.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `store` pasando [`Ordering::Release`] como `order`.
    /// Por exemplo, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Almacena o valor na localización de memoria especificada.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `store` pasando [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Almacena o valor na localización de memoria especificada, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `swap` pasando [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Almacena o valor na localización de memoria especificada, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `swap` pasando [`Ordering::Acquire`] como `order`.
    /// Por exemplo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Almacena o valor na localización de memoria especificada, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `swap` pasando [`Ordering::Release`] como `order`.
    /// Por exemplo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Almacena o valor na localización de memoria especificada, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `swap` pasando [`Ordering::AcqRel`] como `order`.
    /// Por exemplo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Almacena o valor na localización de memoria especificada, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `swap` pasando [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Engádese ao valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_add` pasando [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Engádese ao valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_add` pasando [`Ordering::Acquire`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Engádese ao valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_add` pasando [`Ordering::Release`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Engádese ao valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_add` pasando [`Ordering::AcqRel`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Engádese ao valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_add` pasando [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Restar do valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_sub` pasando [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Restar do valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_sub` pasando [`Ordering::Acquire`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Restar do valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_sub` pasando [`Ordering::Release`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Restar do valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_sub` pasando [`Ordering::AcqRel`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Restar do valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_sub` pasando [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// A bits e co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_and` pasando [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// A bits e co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_and` pasando [`Ordering::Acquire`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// A bits e co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_and` pasando [`Ordering::Release`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// A bits e co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_and` pasando [`Ordering::AcqRel`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// A bits e co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_and` pasando [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Nand a bits e co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible no tipo [`AtomicBool`] a través do método `fetch_nand` pasando [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand a bits e co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible no tipo [`AtomicBool`] a través do método `fetch_nand` pasando [`Ordering::Acquire`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand a bits e co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible no tipo [`AtomicBool`] a través do método `fetch_nand` pasando [`Ordering::Release`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand a bits e co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible no tipo [`AtomicBool`] a través do método `fetch_nand` pasando [`Ordering::AcqRel`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand a bits e co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible no tipo [`AtomicBool`] a través do método `fetch_nand` pasando [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// A bits ou co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_or` pasando [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// A bits ou co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_or` pasando [`Ordering::Acquire`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// A bits ou co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_or` pasando [`Ordering::Release`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// A bits ou co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_or` pasando [`Ordering::AcqRel`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// A bits ou co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_or` pasando [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Xor a bit co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_xor` pasando [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Xor a bit co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_xor` pasando [`Ordering::Acquire`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Xor a bit co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_xor` pasando [`Ordering::Release`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Xor a bit co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_xor` pasando [`Ordering::AcqRel`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Xor a bit co valor actual, devolvendo o valor anterior.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos [`atomic`] a través do método `fetch_xor` pasando [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Máximo co valor actual usando unha comparación asinada.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros asinados [`atomic`] a través do método `fetch_max` pasando [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo co valor actual usando unha comparación asinada.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros asinados [`atomic`] a través do método `fetch_max` pasando [`Ordering::Acquire`] como `order`.
    /// Por exemplo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo co valor actual usando unha comparación asinada.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros asinados [`atomic`] a través do método `fetch_max` pasando [`Ordering::Release`] como `order`.
    /// Por exemplo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo co valor actual usando unha comparación asinada.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros asinados [`atomic`] a través do método `fetch_max` pasando [`Ordering::AcqRel`] como `order`.
    /// Por exemplo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo co valor actual.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros asinados [`atomic`] a través do método `fetch_max` pasando [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Mínimo co valor actual usando unha comparación asinada.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros asinados [`atomic`] a través do método `fetch_min` pasando [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo co valor actual usando unha comparación asinada.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros asinados [`atomic`] a través do método `fetch_min` pasando [`Ordering::Acquire`] como `order`.
    /// Por exemplo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo co valor actual usando unha comparación asinada.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros asinados [`atomic`] a través do método `fetch_min` pasando [`Ordering::Release`] como `order`.
    /// Por exemplo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo co valor actual usando unha comparación asinada.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros asinados [`atomic`] a través do método `fetch_min` pasando [`Ordering::AcqRel`] como `order`.
    /// Por exemplo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo co valor actual usando unha comparación asinada.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros asinados [`atomic`] a través do método `fetch_min` pasando [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Mínimo co valor actual usando unha comparación sen asinar.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros sen asinar [`atomic`] a través do método `fetch_min` pasando [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo co valor actual usando unha comparación sen asinar.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros sen asinar [`atomic`] a través do método `fetch_min` pasando [`Ordering::Acquire`] como `order`.
    /// Por exemplo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo co valor actual usando unha comparación sen asinar.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros sen asinar [`atomic`] a través do método `fetch_min` pasando [`Ordering::Release`] como `order`.
    /// Por exemplo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo co valor actual usando unha comparación sen asinar.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros sen asinar [`atomic`] a través do método `fetch_min` pasando [`Ordering::AcqRel`] como `order`.
    /// Por exemplo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínimo co valor actual usando unha comparación sen asinar.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros sen asinar [`atomic`] a través do método `fetch_min` pasando [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Máximo co valor actual usando unha comparación sen asinar.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros sen asinar [`atomic`] a través do método `fetch_max` pasando [`Ordering::SeqCst`] como `order`.
    /// Por exemplo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo co valor actual usando unha comparación sen asinar.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros sen asinar [`atomic`] a través do método `fetch_max` pasando [`Ordering::Acquire`] como `order`.
    /// Por exemplo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo co valor actual usando unha comparación sen asinar.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros sen asinar [`atomic`] a través do método `fetch_max` pasando [`Ordering::Release`] como `order`.
    /// Por exemplo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo co valor actual usando unha comparación sen asinar.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros sen asinar [`atomic`] a través do método `fetch_max` pasando [`Ordering::AcqRel`] como `order`.
    /// Por exemplo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Máximo co valor actual usando unha comparación sen asinar.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible nos tipos enteiros sen asinar [`atomic`] a través do método `fetch_max` pasando [`Ordering::Relaxed`] como `order`.
    /// Por exemplo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// O `prefetch` intrínseco é un indicio para o xerador de código para inserir unha instrución de prefetch se é compatible;se non, é un non-op.
    /// Os prefetches non teñen ningún efecto sobre o comportamento do programa pero poden cambiar as súas características de rendemento.
    ///
    /// O argumento `locality` debe ser un número enteiro constante e é un especificador de localidade temporal que vai desde (0), sen localidade, ata (3), manténdose na caché extremadamente local.
    ///
    ///
    /// Este intrínseco non ten unha contraparte estable.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// O `prefetch` intrínseco é un indicio para o xerador de código para inserir unha instrución de prefetch se é compatible;se non, é un non-op.
    /// Os prefetches non teñen ningún efecto sobre o comportamento do programa pero poden cambiar as súas características de rendemento.
    ///
    /// O argumento `locality` debe ser un número enteiro constante e é un especificador de localidade temporal que vai desde (0), sen localidade, ata (3), manténdose na caché extremadamente local.
    ///
    ///
    /// Este intrínseco non ten unha contraparte estable.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// O `prefetch` intrínseco é un indicio para o xerador de código para inserir unha instrución de prefetch se é compatible;se non, é un non-op.
    /// Os prefetches non teñen ningún efecto sobre o comportamento do programa pero poden cambiar as súas características de rendemento.
    ///
    /// O argumento `locality` debe ser un número enteiro constante e é un especificador de localidade temporal que vai desde (0), sen localidade, ata (3), manténdose na caché extremadamente local.
    ///
    ///
    /// Este intrínseco non ten unha contraparte estable.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// O `prefetch` intrínseco é un indicio para o xerador de código para inserir unha instrución de prefetch se é compatible;se non, é un non-op.
    /// Os prefetches non teñen ningún efecto sobre o comportamento do programa pero poden cambiar as súas características de rendemento.
    ///
    /// O argumento `locality` debe ser un número enteiro constante e é un especificador de localidade temporal que vai desde (0), sen localidade, ata (3), manténdose na caché extremadamente local.
    ///
    ///
    /// Este intrínseco non ten unha contraparte estable.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Unha cerca atómica.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible en [`atomic::fence`] pasando [`Ordering::SeqCst`] como `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Unha cerca atómica.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible en [`atomic::fence`] pasando [`Ordering::Acquire`] como `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Unha cerca atómica.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible en [`atomic::fence`] pasando [`Ordering::Release`] como `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Unha cerca atómica.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible en [`atomic::fence`] pasando [`Ordering::AcqRel`] como `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Unha barreira de memoria só para compilador.
    ///
    /// Os accesos á memoria nunca serán reordenados a través desta barreira polo compilador, pero non se emitirán instrucións para iso.
    /// Isto é apropiado para operacións no mesmo fío que se poden evitar, como cando se interactúa con controladores de sinal.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible en [`atomic::compiler_fence`] pasando [`Ordering::SeqCst`] como `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Unha barreira de memoria só para compilador.
    ///
    /// Os accesos á memoria nunca serán reordenados a través desta barreira polo compilador, pero non se emitirán instrucións para iso.
    /// Isto é apropiado para operacións no mesmo fío que se poden evitar, como cando se interactúa con controladores de sinal.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible en [`atomic::compiler_fence`] pasando [`Ordering::Acquire`] como `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Unha barreira de memoria só para compilador.
    ///
    /// Os accesos á memoria nunca serán reordenados a través desta barreira polo compilador, pero non se emitirán instrucións para iso.
    /// Isto é apropiado para operacións no mesmo fío que se poden evitar, como cando se interactúa con controladores de sinal.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible en [`atomic::compiler_fence`] pasando [`Ordering::Release`] como `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Unha barreira de memoria só para compilador.
    ///
    /// Os accesos á memoria nunca serán reordenados a través desta barreira polo compilador, pero non se emitirán instrucións para iso.
    /// Isto é apropiado para operacións no mesmo fío que se poden evitar, como cando se interactúa con controladores de sinal.
    ///
    /// A versión estabilizada deste intrínseco está dispoñible en [`atomic::compiler_fence`] pasando [`Ordering::AcqRel`] como `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Maxia intrínseca que deriva o seu significado a partir de atributos ligados á función.
    ///
    /// Por exemplo, dataflow usa isto para inxectar afirmacións estáticas para que `rustc_peek(potentially_uninitialized)` comprobe de novo que o fluxo de datos calculou que non está inicializado nese punto do fluxo de control.
    ///
    ///
    /// Este intrínseco non se debe usar fóra do compilador.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Interrompe a execución do proceso.
    ///
    /// Unha versión máis fácil de usar e estable desta operación é [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informa ao optimizador de que non se pode alcanzar este punto do código, o que permite novas optimizacións.
    ///
    /// NB, isto é moi diferente da macro `unreachable!()`: A diferenza da macro, que panics cando se executa, é un *comportamento indefinido* chegar ao código marcado con esta función.
    ///
    ///
    /// A versión estabilizada deste intrínseco é [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informa ao optimizador de que unha condición sempre é certa.
    /// Se a condición é falsa, o comportamento non está definido.
    ///
    /// Non se xera ningún código para este intrínseco, pero o optimizador intentará preservalo (e a súa condición) entre pasadas, o que pode interferir coa optimización do código circundante e reducir o rendemento.
    /// Non se debe empregar se o optimizador pode descubrir o invariante por si só ou se non habilita optimizacións significativas.
    ///
    /// Este intrínseco non ten unha contraparte estable.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Consellos para o compilador de que é probable que a condición branch sexa certa.
    /// Devolve o valor que se lle pasou.
    ///
    /// Calquera uso que non sexa con instrucións `if` probablemente non teña efecto.
    ///
    /// Este intrínseco non ten unha contraparte estable.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Consellos para o compilador de que é probable que a condición branch sexa falsa.
    /// Devolve o valor que se lle pasou.
    ///
    /// Calquera uso que non sexa con instrucións `if` probablemente non teña efecto.
    ///
    /// Este intrínseco non ten unha contraparte estable.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Executa unha trampa de punto de interrupción, para inspección por un depurador.
    ///
    /// Este intrínseco non ten unha contraparte estable.
    pub fn breakpoint();

    /// O tamaño dun tipo en bytes.
    ///
    /// Máis concretamente, trátase da compensación en bytes entre elementos sucesivos do mesmo tipo, incluído o recheo de aliñamento.
    ///
    ///
    /// A versión estabilizada deste intrínseco é [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// O aliñamento mínimo dun tipo.
    ///
    /// A versión estabilizada deste intrínseco é [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// O aliñamento preferido dun tipo.
    ///
    /// Este intrínseco non ten unha contraparte estable.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// O tamaño do valor referenciado en bytes.
    ///
    /// A versión estabilizada deste intrínseco é [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// O aliñamento requirido do valor referenciado.
    ///
    /// A versión estabilizada deste intrínseco é [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Obtén unha porción de cadea estática que contén o nome dun tipo.
    ///
    /// A versión estabilizada deste intrínseco é [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Obtén un identificador globalmente único para o tipo especificado.
    /// Esta función devolverá o mesmo valor a un tipo independentemente do crate en que se invoque.
    ///
    ///
    /// A versión estabilizada deste intrínseco é [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Un protector para funcións inseguras que nunca se poden executar se `T` está deshabitado:
    /// Isto fará estáticamente panic ou non fará nada.
    ///
    /// Este intrínseco non ten unha contraparte estable.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Unha protección para funcións inseguras que nunca se poden executar se `T` non permite a inicialización cero: isto fará estáticamente panic ou non fará nada.
    ///
    ///
    /// Este intrínseco non ten unha contraparte estable.
    pub fn assert_zero_valid<T>();

    /// Unha protección para funcións inseguras que nunca se poden executar se `T` ten patróns de bits non válidos: isto fará estáticamente panic ou non fará nada.
    ///
    ///
    /// Este intrínseco non ten unha contraparte estable.
    pub fn assert_uninit_valid<T>();

    /// Obtén unha referencia a un `Location` estático que indica onde foi chamado.
    ///
    /// Considere usar [`core::panic::Location::caller`](crate::panic::Location::caller) no seu lugar.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Elimina un valor fóra do alcance sen executar pegamento.
    ///
    /// Isto existe exclusivamente para [`mem::forget_unsized`];o `forget` normal usa `ManuallyDrop` no seu lugar.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterpreta os bits dun valor dun tipo como outro tipo.
    ///
    /// Os dous tipos deben ter o mesmo tamaño.
    /// Nin o orixinal nin o resultado poden ser un [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` semanticamente equivale a un movemento bit a bit dun tipo a outro.Copia os bits do valor de orixe no valor de destino e despois esquece o orixinal.
    /// É equivalente a C's `memcpy` baixo o capó, igual que `transmute_copy`.
    ///
    /// Debido a que `transmute` é unha operación de valor secundario, o aliñamento dos *valores transmutados en si mesmos* non é un problema.
    /// Como con calquera outra función, o compilador xa garante que `T` e `U` estean correctamente aliñados.
    /// Non obstante, cando transmuta valores que *apuntan noutro lugar*(como punteiros, referencias, caixas ...), o interlocutor debe asegurar un correcto aliñamento dos valores apuntados.
    ///
    /// `transmute` é **increíblemente** inseguro.Hai unha gran cantidade de formas de causar [undefined behavior][ub] con esta función.`transmute` debería ser o último recurso.
    ///
    /// O [nomicon](../../nomicon/transmutes.html) ten documentación adicional.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Hai algunhas cousas para as que `transmute` é realmente útil.
    ///
    /// Converter un punteiro nun punteiro de función.Isto non é * portátil para máquinas onde os punteiros de función e os punteiros de datos teñen diferentes tamaños.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Ampliar a vida útil ou acurtar unha vida invariante.Isto é avanzado, moi inseguro Rust.
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Non te desesperes: moitos usos de `transmute` pódense conseguir por outros medios.
    /// Abaixo amósanse aplicacións comúns de `transmute` que se poden substituír por construcións máis seguras.
    ///
    /// Cambiando bytes(`&[u8]`) en bruto a `u32`, `f64`, etc.:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // use `u32::from_ne_bytes` no seu lugar
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // ou use `u32::from_le_bytes` ou `u32::from_be_bytes` para especificar o endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Converter un punteiro nun `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // No seu lugar, use un reparto `as`
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Converter un `*mut T` nun `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // No seu lugar, use un novo préstamo
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Converter un `&mut T` nun `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Agora, xunta `as` e reborrowing, teña en conta que o encadeamento de `as` `as` non é transitivo
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Converter un `&str` nun `&[u8]`:
    ///
    /// ```
    /// // esta non é unha boa forma de facelo.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Podería usar `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Ou simplemente usa unha cadea de bytes se tes control sobre a cadea literal
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Converter un `Vec<&T>` nun `Vec<Option<&T>>`.
    ///
    /// Para transmutar o tipo interno do contido dun contedor, debes asegurarte de non violar ningunha das invariantes do contedor.
    /// Para `Vec`, isto significa que tanto o tamaño *como o aliñamento* dos tipos internos teñen que coincidir.
    /// Outros contedores poden depender do tamaño do tipo, do aliñamento ou incluso do `TypeId`, nese caso a transmutación non sería posible sen violar os invariantes dos contedores.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // clonar o vector xa que os reutilizaremos máis adiante
    /// let v_clone = v_orig.clone();
    ///
    /// // Usando transmutación: isto depende do deseño de datos non especificado de `Vec`, que é unha mala idea e pode provocar un comportamento indefinido.
    /////
    /// // Non obstante, non é copia.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Este é o xeito suxerido e seguro.
    /// // Non obstante, copia todo o vector nunha nova matriz.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Este é o xeito seguro e seguro de copiar de "transmuting" a `Vec`, sen depender do deseño de datos.
    /// // En vez de chamar literalmente a `transmute`, realizamos un reparto de punteiro, pero en canto a converter o tipo interior orixinal (`&i32`) ao novo (`Option<&i32>`), ten as mesmas advertencias.
    /////
    /// // Ademais da información proporcionada anteriormente, tamén consulte a documentación [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Actualízao cando vec_into_raw_parts estabilice.
    ///     // Asegúrese de que o vector orixinal non se caia.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implementando `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Hai varias formas de facelo e hai varios problemas co seguinte xeito (transmute).
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // primeiro: transmutar non é tipo seguro;o único que comproba é que T e
    ///         // U son do mesmo tamaño.
    ///         // En segundo lugar, aquí mesmo, tes dúas referencias mutables que apuntan á mesma memoria.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Isto elimina os problemas de seguridade do tipo;`&mut *`* só *daralle un `&mut T` dun `&mut T` ou `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // con todo, aínda ten dúas referencias mudables que apuntan á mesma memoria.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Así o fai a biblioteca estándar.
    /// // Este é o mellor método, se precisas facer algo así
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Agora ten tres referencias mudables que apuntan cara á mesma memoria.`slice`, o rvalue ret.0 e o rvalue ret.1.
    ///         // `slice` nunca se usa despois de `let ptr = ...`, polo que se pode tratar como "dead" e, polo tanto, só tes dúas franxas mutables reais.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Aínda que isto fai que a const intrínseca sexa estable, temos algún código personalizado en const fn
    // comprobacións que impiden o seu uso dentro de `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Devolve `true` se o tipo real indicado como `T` require cola de caída;devolve `false` se o tipo real proporcionado para `T` implementa `Copy`.
    ///
    ///
    /// Se o tipo real nin require pegamento nin implementa `Copy`, o valor devolto desta función non se especifica.
    ///
    /// A versión estabilizada deste intrínseco é [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Calcula o desprazamento dun punteiro.
    ///
    /// Isto implántase como intrínseco para evitar a conversión a e dende un enteiro, xa que a conversión botaría a información de aliasing.
    ///
    /// # Safety
    ///
    /// Tanto o punteiro inicial como o resultante deben estar entre límites ou un byte máis que o final dun obxecto asignado.
    /// Se un dos dous punteiros está fóra dos límites ou se produce un desbordamento aritmético, calquera outro uso do valor devolto producirá un comportamento indefinido.
    ///
    ///
    /// A versión estabilizada deste intrínseco é [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Calcula o desprazamento dun punteiro, potencialmente axustado.
    ///
    /// Isto implántase como intrínseco para evitar converter a un número enteiro, xa que a conversión inhibe certas optimizacións.
    ///
    /// # Safety
    ///
    /// A diferenza do intrínseco `offset`, este intrínseco non restrinxe o punteiro resultante para apuntar ou pasar un byte ao final dun obxecto asignado e envólvese coa aritmética do complemento de dous.
    /// O valor resultante non é necesariamente válido para ser usado para acceder realmente á memoria.
    ///
    /// A versión estabilizada deste intrínseco é [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Equivalente ao `llvm.memcpy.p0i8.0i8.*` intrínseco apropiado, cun tamaño de `count`*`size_of::<T>()` e un aliñamento de
    ///
    /// `min_align_of::<T>()`
    ///
    /// O parámetro volátil está configurado en `true`, polo que non se optimizará a menos que o tamaño sexa igual a cero.
    ///
    /// Este intrínseco non ten unha contraparte estable.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Equivalente ao intrínseco apropiado `llvm.memmove.p0i8.0i8.*`, cun tamaño de `count* size_of::<T>()` e un aliñamento de
    ///
    /// `min_align_of::<T>()`
    ///
    /// O parámetro volátil está configurado en `true`, polo que non se optimizará a menos que o tamaño sexa igual a cero.
    ///
    /// Este intrínseco non ten unha contraparte estable.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Equivalente ao `llvm.memset.p0i8.*` intrínseco apropiado, cun tamaño de `count* size_of::<T>()` e un aliñamento de `min_align_of::<T>()`.
    ///
    ///
    /// O parámetro volátil está configurado en `true`, polo que non se optimizará a menos que o tamaño sexa igual a cero.
    ///
    /// Este intrínseco non ten unha contraparte estable.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Realiza unha carga volátil desde o punteiro `src`.
    ///
    /// A versión estabilizada deste intrínseco é [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Realiza un almacén volátil co punteiro `dst`.
    ///
    /// A versión estabilizada deste intrínseco é [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Realiza unha carga volátil desde o punteiro `src` Non é necesario que o punteiro estea aliñado.
    ///
    ///
    /// Este intrínseco non ten unha contraparte estable.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Realiza un almacén volátil co punteiro `dst`.
    /// Non se precisa aliñar o punteiro.
    ///
    /// Este intrínseco non ten unha contraparte estable.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Devolve a raíz cadrada dun `f32`
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Devolve a raíz cadrada dun `f64`
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Eleva un `f32` a unha potencia enteira.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Eleva un `f64` a unha potencia enteira.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Devolve o seno dun `f32`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Devolve o seno dun `f64`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Devolve o coseno dun `f32`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Devolve o coseno dun `f64`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Aumenta un `f32` a un poder `f32`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Aumenta un `f64` a un poder `f64`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Devolve a exponencial dun `f32`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Devolve a exponencial dun `f64`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Devolve 2 elevado á potencia dun `f32`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Devolve 2 elevado á potencia dun `f64`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Devolve o logaritmo natural dun `f32`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Devolve o logaritmo natural dun `f64`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Devolve o logaritmo base 10 dun `f32`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Devolve o logaritmo base 10 dun `f64`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Devolve o logaritmo base 2 dun `f32`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Devolve o logaritmo base 2 dun `f64`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Devolve `a * b + c` para valores `f32`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Devolve `a * b + c` para valores `f64`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Devolve o valor absoluto dun `f32`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Devolve o valor absoluto dun `f64`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Devolve o mínimo de dous valores `f32`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Devolve o mínimo de dous valores `f64`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Devolve o máximo de dous valores `f32`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Devolve o máximo de dous valores `f64`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Copia o signo de `y` a `x` para valores `f32`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Copia o signo de `y` a `x` para valores `f64`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Devolve o maior enteiro menor ou igual a un `f32`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Devolve o maior enteiro menor ou igual a un `f64`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Devolve o número enteiro máis pequeno maior ou igual a un `f32`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Devolve o número enteiro máis pequeno maior ou igual a un `f64`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Devolve a parte enteira dun `f32`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Devolve a parte enteira dun `f64`.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Devolve o enteiro máis próximo a un `f32`.
    /// Pode xerar unha excepción de punto flotante inexacta se o argumento non é un número enteiro.
    pub fn rintf32(x: f32) -> f32;
    /// Devolve o enteiro máis próximo a un `f64`.
    /// Pode xerar unha excepción de punto flotante inexacta se o argumento non é un número enteiro.
    pub fn rintf64(x: f64) -> f64;

    /// Devolve o enteiro máis próximo a un `f32`.
    ///
    /// Este intrínseco non ten unha contraparte estable.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Devolve o enteiro máis próximo a un `f64`.
    ///
    /// Este intrínseco non ten unha contraparte estable.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Devolve o enteiro máis próximo a un `f32`.Redondea casos a medio camiño de cero.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Devolve o enteiro máis próximo a un `f64`.Redondea casos a medio camiño de cero.
    ///
    /// A versión estabilizada deste intrínseco é
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Adición flotante que permite optimizacións baseadas en regras alxébricas.
    /// Pode asumir que as entradas son finitas.
    ///
    /// Este intrínseco non ten unha contraparte estable.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Subtracción flotante que permite optimizacións baseadas en regras alxébricas.
    /// Pode asumir que as entradas son finitas.
    ///
    /// Este intrínseco non ten unha contraparte estable.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Multiplicación flotante que permite optimizacións baseadas en regras alxébricas.
    /// Pode asumir que as entradas son finitas.
    ///
    /// Este intrínseco non ten unha contraparte estable.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// División flotante que permite optimizacións baseadas en regras alxébricas.
    /// Pode asumir que as entradas son finitas.
    ///
    /// Este intrínseco non ten unha contraparte estable.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Restante flotante que permite optimizacións baseadas en regras alxébricas.
    /// Pode asumir que as entradas son finitas.
    ///
    /// Este intrínseco non ten unha contraparte estable.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Converta co fptoui/fptosi de LLVM, que pode volver indefinido para valores fóra do rango
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Estabilizado como [`f32::to_int_unchecked`] e [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Devolve o número de bits establecidos nun tipo enteiro `T`
    ///
    /// As versións estabilizadas deste intrínseco están dispoñibles nas primitivas enteiras a través do método `count_ones`.
    /// Por exemplo,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Devolve o número de bits non definidos principais (zeroes) nun tipo enteiro `T`.
    ///
    /// As versións estabilizadas deste intrínseco están dispoñibles nas primitivas enteiras a través do método `leading_zeros`.
    /// Por exemplo,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Un `x` co valor `0` devolverá o ancho de bits de `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Como `ctlz`, pero non é seguro xa que devolve `undef` cando se lle dá un `x` co valor `0`.
    ///
    ///
    /// Este intrínseco non ten unha contraparte estable.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Devolve o número de bits non definidos finais (zeroes) nun tipo enteiro `T`.
    ///
    /// As versións estabilizadas deste intrínseco están dispoñibles nas primitivas enteiras a través do método `trailing_zeros`.
    /// Por exemplo,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Un `x` co valor `0` devolverá o ancho de bits de `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Como `cttz`, pero non é seguro xa que devolve `undef` cando se lle dá un `x` co valor `0`.
    ///
    ///
    /// Este intrínseco non ten unha contraparte estable.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Inverte os bytes nun enteiro tipo `T`.
    ///
    /// As versións estabilizadas deste intrínseco están dispoñibles nas primitivas enteiras a través do método `swap_bytes`.
    /// Por exemplo,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Inverte os bits nun tipo enteiro `T`.
    ///
    /// As versións estabilizadas deste intrínseco están dispoñibles nas primitivas enteiras a través do método `reverse_bits`.
    /// Por exemplo,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Realiza a adición enteira comprobada.
    ///
    /// As versións estabilizadas deste intrínseco están dispoñibles nas primitivas enteiras a través do método `overflowing_add`.
    /// Por exemplo,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Realiza a resta enteira comprobada
    ///
    /// As versións estabilizadas deste intrínseco están dispoñibles nas primitivas enteiras a través do método `overflowing_sub`.
    /// Por exemplo,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Realiza a multiplicación enteira comprobada
    ///
    /// As versións estabilizadas deste intrínseco están dispoñibles nas primitivas enteiras a través do método `overflowing_mul`.
    /// Por exemplo,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Realiza unha división exacta, dando lugar a un comportamento indefinido onde `x % y != 0` ou `y == 0` ou `x == T::MIN && y == -1`
    ///
    ///
    /// Este intrínseco non ten unha contraparte estable.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Realiza unha división sen comprobar, dando lugar a un comportamento indefinido cando `y == 0` ou `x == T::MIN && y == -1`
    ///
    ///
    /// Os envoltorios seguros para este intrínseco están dispoñibles nas primitivas enteiras a través do método `checked_div`.
    /// Por exemplo,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Devolve o resto dunha división sen comprobar, o que resulta nun comportamento indefinido cando `y == 0` ou `x == T::MIN && y == -1`
    ///
    ///
    /// Os envoltorios seguros para este intrínseco están dispoñibles nas primitivas enteiras a través do método `checked_rem`.
    /// Por exemplo,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Realiza un desprazamento á esquerda sen comprobar, dando lugar a un comportamento indefinido cando `y < 0` ou `y >= N`, onde N é o ancho de T en bits.
    ///
    ///
    /// Os envoltorios seguros para este intrínseco están dispoñibles nas primitivas enteiras a través do método `checked_shl`.
    /// Por exemplo,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Realiza un desprazamento á dereita sen comprobar, dando lugar a un comportamento indefinido cando `y < 0` ou `y >= N`, onde N é o ancho de T en bits.
    ///
    ///
    /// Os envoltorios seguros para este intrínseco están dispoñibles nas primitivas enteiras a través do método `checked_shr`.
    /// Por exemplo,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Devolve o resultado dunha adición sen comprobar, o que resulta nun comportamento indefinido cando `x + y > T::MAX` ou `x + y < T::MIN`.
    ///
    ///
    /// Este intrínseco non ten unha contraparte estable.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Devolve o resultado dunha resta sen comprobar, o que resulta nun comportamento indefinido cando `x - y > T::MAX` ou `x - y < T::MIN`.
    ///
    ///
    /// Este intrínseco non ten unha contraparte estable.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Devolve o resultado dunha multiplicación sen comprobar, dando lugar a un comportamento indefinido cando `x *y > T::MAX` ou `x* y < T::MIN`.
    ///
    ///
    /// Este intrínseco non ten unha contraparte estable.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Realiza xirar á esquerda.
    ///
    /// As versións estabilizadas deste intrínseco están dispoñibles nas primitivas enteiras a través do método `rotate_left`.
    /// Por exemplo,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Realiza xirar á dereita.
    ///
    /// As versións estabilizadas deste intrínseco están dispoñibles nas primitivas enteiras a través do método `rotate_right`.
    /// Por exemplo,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Devolve (a + b) o mod 2 <sup>N</sup>, onde N é o ancho de T en bits.
    ///
    /// As versións estabilizadas deste intrínseco están dispoñibles nas primitivas enteiras a través do método `wrapping_add`.
    /// Por exemplo,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Devolve (a, b) o mod 2 <sup>N</sup>, onde N é o ancho de T en bits.
    ///
    /// As versións estabilizadas deste intrínseco están dispoñibles nas primitivas enteiras a través do método `wrapping_sub`.
    /// Por exemplo,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Devolve (a * b) o mod 2 <sup>N</sup>, onde N é o ancho de T en bits.
    ///
    /// As versións estabilizadas deste intrínseco están dispoñibles nas primitivas enteiras a través do método `wrapping_mul`.
    /// Por exemplo,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Calcula `a + b`, saturándose en límites numéricos.
    ///
    /// As versións estabilizadas deste intrínseco están dispoñibles nas primitivas enteiras a través do método `saturating_add`.
    /// Por exemplo,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Calcula `a - b`, saturándose en límites numéricos.
    ///
    /// As versións estabilizadas deste intrínseco están dispoñibles nas primitivas enteiras a través do método `saturating_sub`.
    /// Por exemplo,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Devolve o valor do discriminante para a variante en 'v';
    /// se `T` non ten discriminante, devolve `0`.
    ///
    /// A versión estabilizada deste intrínseco é [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Devolve o número de variantes do tipo `T` emitido a un `usize`;
    /// se `T` non ten variantes, devolve `0`.Contabilizaranse as variantes deshabitadas.
    ///
    /// A versión estabilizada deste intrínseco é [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Construción "try catch" de Rust que invoca o punteiro de función `try_fn` co punteiro de datos `data`.
    ///
    /// O terceiro argumento é unha función chamada se se produce un panic.
    /// Esta función leva o punteiro de datos e un punteiro ao obxecto de excepción específico do destino que foi capturado.
    ///
    /// Para obter máis información, consulte a fonte do compilador, así como a implementación de capturas de std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Emite unha tenda `!nontemporal` segundo LLVM (consulte os seus documentos).
    /// Probablemente nunca se volva estable.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Consulte a documentación de `<*const T>::offset_from` para máis detalles.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Consulte a documentación de `<*const T>::guaranteed_eq` para máis detalles.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Consulte a documentación de `<*const T>::guaranteed_ne` para máis detalles.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Asignar no momento da compilación.Non se debe chamar ao tempo de execución.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Aquí defínense algunhas funcións porque accidentalmente quedaron dispoñibles neste módulo en stable.
// Vexa <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` tamén entra nesta categoría, pero non se pode empaquetar debido á comprobación de que `T` e `U` teñen o mesmo tamaño.)
//

/// Comproba se `ptr` está correctamente aliñado con respecto a `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Copia bytes `count *size_of::<T>()` de `src` a `dst`.A fonte e o destino* non *deben* superpoñerse.
///
/// Para rexións de memoria que se poidan solapar, use [`copy`] no seu lugar.
///
/// `copy_nonoverlapping` é semanticamente equivalente a C's [`memcpy`], pero coa orde de argumentos trocada.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// O comportamento non está definido se se incumpre algunha das seguintes condicións:
///
/// * `src` debe ser [valid] para lecturas de bytes `count * size_of::<T>()`.
///
/// * `dst` debe ser [valid] para escrituras de bytes `count * size_of::<T>()`.
///
/// * Tanto `src` como `dst` deben estar correctamente aliñados.
///
/// * A rexión da memoria que comeza en `src` cun tamaño de `count *
///   tamaño_de: :<T>() `Os bytes *non* deben * superpoñerse á rexión de memoria que comeza en `dst` co mesmo tamaño.
///
/// Do mesmo xeito que [`read`], `copy_nonoverlapping` crea unha copia a bit de `T`, independentemente de que `T` sexa [`Copy`].
/// Se `T` non é [`Copy`], usando *ambos* os valores da rexión que comecen por `*src` e a rexión que comeza por `* dst` poden ser [violate memory safety][read-ownership].
///
///
/// Teña en conta que, aínda que o tamaño efectivamente copiado (`count * size_of: :<T>()`) é `0`, os punteiros non deben ser NULOS e están correctamente aliñados.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Implementar manualmente [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Move todos os elementos de `src` a `dst`, deixando `src` baleiro.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Asegúrese de que o `dst` ten capacidade suficiente para soportar todo o `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // A chamada para compensar sempre é segura porque `Vec` nunca asignará máis de `isize::MAX` bytes.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Trunque `src` sen deixar caer o seu contido.
///         // Facemos isto primeiro, para evitar problemas por se hai algo máis abaixo en panics.
///         src.set_len(0);
///
///         // As dúas rexións non poden superpoñerse porque as referencias mutables non son alias e dous vectors diferentes non poden posuír a mesma memoria.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Notifique a `dst` que agora contén o contido de `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Realice estas comprobacións só en tempo de execución
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Non entrar en pánico para manter o impacto do codegen menor.
        abort();
    }*/

    // SEGURIDADE: o contrato de seguridade para `copy_nonoverlapping` debe ser
    // confirmado polo interlocutor.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Copia bytes `count * size_of::<T>()` de `src` a `dst`.A fonte e o destino poden superpoñerse.
///
/// Se a fonte e o destino *nunca* se superpoñen, pódese usar [`copy_nonoverlapping`].
///
/// `copy` é semanticamente equivalente a C's [`memmove`], pero coa orde de argumentos trocada.
/// A copia ten lugar coma se os bytes se copiasen de `src` a unha matriz temporal e logo copiásense da matriz a `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// O comportamento non está definido se se incumpre algunha das seguintes condicións:
///
/// * `src` debe ser [valid] para lecturas de bytes `count * size_of::<T>()`.
///
/// * `dst` debe ser [valid] para escrituras de bytes `count * size_of::<T>()`.
///
/// * Tanto `src` como `dst` deben estar correctamente aliñados.
///
/// Do mesmo xeito que [`read`], `copy` crea unha copia a bit de `T`, independentemente de que `T` sexa [`Copy`].
/// Se `T` non é [`Copy`], pode usar [violate memory safety][read-ownership] tanto os valores da rexión que comecen por `*src` como a rexión que comeza por `* dst`.
///
///
/// Teña en conta que, aínda que o tamaño efectivamente copiado (`count * size_of: :<T>()`) é `0`, os punteiros non deben ser NULOS e están correctamente aliñados.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Cree eficientemente un Rust vector a partir dun búfer non seguro:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` debe estar aliñado correctamente para o seu tipo e non ser cero.
/// /// * `ptr` debe ser válido para lecturas de elementos contiguos `elts` do tipo `T`.
/// /// * Non se deben empregar eses elementos despois de chamar a esta función a non ser que `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SEGURIDADE: a nosa condición previa garante que a fonte estea aliñada e válida,
///     // e `Vec::with_capacity` garante que temos espazo útil para escribilas.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SEGURIDADE: Creamos con esta capacidade antes,
///     // e o anterior `copy` inicializou estes elementos.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Realice estas comprobacións só en tempo de execución
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Non entrar en pánico para manter o impacto do codegen menor.
        abort();
    }*/

    // SEGURIDADE: o contratante de seguridade para `copy` debe ser confirmado polo interlocutor.
    unsafe { copy(src, dst, count) }
}

/// Establece `count * size_of::<T>()` bytes de memoria a partir de `dst` a `val`.
///
/// `write_bytes` é semellante ao C's [`memset`], pero establece `count * size_of::<T>()` bytes en `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// O comportamento non está definido se se incumpre algunha das seguintes condicións:
///
/// * `dst` debe ser [valid] para escrituras de bytes `count * size_of::<T>()`.
///
/// * `dst` debe estar correctamente aliñado.
///
/// Ademais, o interlocutor debe asegurarse de que a escritura de bytes `count * size_of::<T>()` na rexión de memoria dada resulta nun valor válido de `T`.
/// O comportamento non definido é o uso dunha rexión de memoria escrita como `T` que contén un valor non válido de `T`.
///
/// Teña en conta que, aínda que o tamaño efectivamente copiado (`count * size_of: :<T>()`) é `0`, o punteiro non debe ser NULO e está correctamente aliñado.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Creación dun valor non válido:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Fuga do valor mantido anteriormente sobrescribindo o `Box<T>` cun punteiro nulo.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Neste momento, usar ou deixar caer `v` resulta nun comportamento indefinido.
/// // drop(v); // ERROR
///
/// // Incluso o filtrou `v` "uses" e, polo tanto, é un comportamento indefinido.
/// // mem::forget(v); // ERROR
///
/// // De feito, `v` non é válido segundo os invariantes de deseño de tipo básico, polo que *calquera* operación que o toque é un comportamento indefinido.
/////
/// // deixe v2 =v;//ERRO
///
/// unsafe {
///     // Poñamos un valor válido
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Agora a caixa está ben
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SEGURIDADE: o contratante de seguridade para `write_bytes` debe ser confirmado polo interlocutor.
    unsafe { write_bytes(dst, val, count) }
}