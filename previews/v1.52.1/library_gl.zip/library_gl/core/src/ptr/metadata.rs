#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Ofrece o tipo de metadatos do punteiro de calquera tipo apuntado.
///
/// # Metadatos do punteiro
///
/// Os tipos de punteiros en bruto e os tipos de referencia en Rust pódense considerar feitos en dúas partes:
/// un punteiro de datos que contén a dirección de memoria do valor e algúns metadatos.
///
/// Para os tipos de tamaño estático (que implementan o `Sized` traits), así como para os tipos `extern`, dise que os punteiros son "finos": os metadatos teñen un tamaño cero e o seu tipo é `()`.
///
///
/// Dise que os punteiros a [dynamically-sized types][dst] son "anchos" ou "gordos", teñen metadatos de tamaño non cero:
///
/// * Para as estruturas cuxo último campo é DST, os metadatos son os metadatos do último campo
/// * Para o tipo `str`, os metadatos son a lonxitude en bytes como `usize`
/// * Para tipos de porción como `[T]`, os metadatos son a lonxitude dos elementos como `usize`
/// * Para obxectos trait como `dyn SomeTrait`, os metadatos son [`DynMetadata<Self>`][DynMetadata] (por exemplo, `DynMetadata<dyn SomeTrait>`)
///
/// No future, a linguaxe Rust pode gañar novos tipos de tipos que teñen metadatos de punteiro diferentes.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # O `Pointee` trait
///
/// O punto deste trait é o seu tipo asociado a `Metadata`, que é `()` ou `usize` ou `DynMetadata<_>` como se describiu anteriormente.
/// Implementase automaticamente para todos os tipos.
/// Pódese supor que está implementado nun contexto xenérico, mesmo sen un correspondente límite.
///
/// # Usage
///
/// Os punteiros en bruto pódense descompoñer no enderezo de datos e compoñentes de metadatos co seu método [`to_raw_parts`].
///
/// Alternativamente, os metadatos só se poden extraer coa función [`metadata`].
/// Pódese pasar unha referencia a [`metadata`] e implicitamente coaccionar.
///
/// Un punteiro (possibly-wide) pódese xuntar de novo desde o seu enderezo e metadatos con [`from_raw_parts`] ou [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// O tipo de metadatos en punteiros e referencias a `Self`.
    #[lang = "metadata_type"]
    // NOTE: Mantén trait bounds en `static_assert_expected_bounds_for_metadata`
    //
    // en `library/core/src/ptr/metadata.rs` sincronizado cos de aquí:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Os indicadores de tipos que implementan este alias trait son "delgados".
///
/// Isto inclúe os tipos "tamaño" estático e os tipos `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: Non estabilice isto antes de que os alias trait sexan estables no idioma?
pub trait Thin = Pointee<Metadata = ()>;

/// Extrae o compoñente de metadatos dun punteiro.
///
/// Os valores do tipo `*mut T`, `&T` ou `&mut T` pódense pasar directamente a esta función xa que implicitamente coaccionan a `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SEGURIDADE: acceder ao valor desde a unión `PtrRepr` é seguro dende * const T
    // e PtrComponents<T>teñen os mesmos deseños de memoria.
    // Só std pode facer esta garantía.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Forma un punteiro en bruto (possibly-wide) a partir dun enderezo de datos e metadatos.
///
/// Esta función é segura pero o punteiro devolto non é necesariamente seguro para a desreferencia.
/// Para ver segmentos, consulte a documentación de [`slice::from_raw_parts`] para os requisitos de seguridade.
/// Para os obxectos trait, os metadatos deben proceder dun punteiro ao mesmo tipo subxacente eliminado.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SEGURIDADE: acceder ao valor desde a unión `PtrRepr` é seguro dende * const T
    // e PtrComponents<T>teñen os mesmos deseños de memoria.
    // Só std pode facer esta garantía.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Realiza a mesma funcionalidade que [`from_raw_parts`], excepto que se devolve un punteiro `*mut` en bruto, en oposición a un punteiro `* const` en bruto.
///
///
/// Consulte a documentación de [`from_raw_parts`] para máis detalles.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SEGURIDADE: acceder ao valor desde a unión `PtrRepr` é seguro dende * const T
    // e PtrComponents<T>teñen os mesmos deseños de memoria.
    // Só std pode facer esta garantía.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Necesítase unha aplicación manual para evitar o límite `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Necesítase unha aplicación manual para evitar o límite `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Os metadatos dun tipo de obxecto `Dyn = dyn SomeTrait` trait.
///
/// É un punteiro a unha táboa virtual (táboa de chamadas virtual) que representa toda a información necesaria para manipular o tipo de formigón almacenado dentro dun obxecto trait.
/// A mesa vtable que contén en particular:
///
/// * tamaño do tipo
/// * aliñamento de tipos
/// * un punteiro ao impl `drop_in_place` do tipo (pode ser un non-op para plain-old-data)
/// * indicadores de todos os métodos para a implementación do tipo de trait
///
/// Teña en conta que os tres primeiros son especiais porque son necesarios para asignar, soltar e repartir calquera obxecto trait.
///
/// É posible nomear esta estrutura cun parámetro tipo que non sexa un obxecto `dyn` trait (por exemplo `DynMetadata<u64>`) pero non obter un valor significativo desa estrutura.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// O prefixo común de todas as táboas.Séguenlle indicadores de función para os métodos trait.
///
/// Detalle de implementación privada de `DynMetadata::size_of` etc.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Devolve o tamaño do tipo asociado a esta mesa.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Devolve o aliñamento do tipo asociado a esta mesa.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Devolve o tamaño e o aliñamento xuntos como un `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SEGURIDADE: o compilador emitiu esta táboa para un tipo concreto de Rust que
        // sábese que ten un deseño válido.O mesmo razoamento que en `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Necesítanse implícitos manuais para evitar límites `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}