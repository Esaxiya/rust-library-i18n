use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Devolve `true` se o punteiro é nulo.
    ///
    /// Teña en conta que os tipos sen tamaño teñen moitos posibles punteiros nulos, xa que só se considera o punteiro de datos en bruto, non a súa lonxitude, táboa, etc.
    /// Polo tanto, dous indicadores que son nulos poden non compararse iguais entre si.
    ///
    /// ## Comportamento durante a avaliación do const
    ///
    /// Cando se usa esta función durante a avaliación de const, pode devolver `false` para punteiros que resulten nulos no tempo de execución.
    /// En concreto, cando un punteiro a algunha memoria se despraza máis alá dos seus límites de tal xeito que o punteiro resultante é nulo, a función aínda devolverá `false`.
    ///
    /// Non hai forma de que CTFE saiba a posición absoluta desa memoria, polo que non podemos saber se o punteiro é nulo ou non.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Compara a través dun elenco cun punteiro fino, polo que os punteiros gordos só están a considerar a súa parte "data" como nulidade.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Lánzase a un punteiro doutro tipo.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Descompoña un punteiro (posiblemente ancho) en compoñentes de enderezos e metadatos.
    ///
    /// O punteiro pode reconstruírse posteriormente con [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Devolve `None` se o punteiro é nulo, ou ben devolve unha referencia compartida ao valor axustado en `Some`.Se o valor pode non ser inicializado, no seu lugar debe usarse [`as_uninit_ref`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Ao chamar a este método, ten que asegurarse de que *ou* o punteiro é NULO *ou* todo o seguinte é certo:
    ///
    /// * O punteiro debe estar correctamente aliñado.
    ///
    /// * Debe ser "dereferencable" no sentido definido en [the module documentation].
    ///
    /// * O punteiro debe apuntar a unha instancia inicializada de `T`.
    ///
    /// * Debe facer cumprir as regras de aliasing de Rust, xa que a vida útil retornada `'a` é elixida arbitrariamente e non reflicte necesariamente a vida real dos datos.
    ///   En particular, durante a duración desta vida, a memoria á que apunta o punteiro non debe mutarse (excepto dentro de `UnsafeCell`).
    ///
    /// Isto aplícase aínda que o resultado deste método non se use.
    /// (A parte sobre a inicialización aínda non está completamente decidida, pero ata que o faga, o único enfoque seguro é asegurarse de que se inicialicen.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Versión sen comprobar
    ///
    /// Se está seguro de que o punteiro nunca pode ser nulo e está a buscar algún tipo de `as_ref_unchecked` que devolva o `&T` no canto de `Option<&T>`, sabe que pode desferenciar o punteiro directamente.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SEGURIDADE: o interlocutor debe garantir que o `self` é válido
        // para unha referencia se non é nula.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Devolve `None` se o punteiro é nulo, ou ben devolve unha referencia compartida ao valor axustado en `Some`.
    /// A diferenza do [`as_ref`], isto non require que se inicialice o valor.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Ao chamar a este método, ten que asegurarse de que *ou* o punteiro é NULO *ou* todo o seguinte é certo:
    ///
    /// * O punteiro debe estar correctamente aliñado.
    ///
    /// * Debe ser "dereferencable" no sentido definido en [the module documentation].
    ///
    /// * Debe facer cumprir as regras de aliasing de Rust, xa que a vida útil retornada `'a` é elixida arbitrariamente e non reflicte necesariamente a vida real dos datos.
    ///
    ///   En particular, durante a duración desta vida, a memoria á que apunta o punteiro non debe mutarse (excepto dentro de `UnsafeCell`).
    ///
    /// Isto aplícase aínda que o resultado deste método non se use.
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SEGURIDADE: o interlocutor debe garantir que `self` cumpre todos os requisitos
        // requisitos para unha referencia.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Calcula o desprazamento dun punteiro.
    ///
    /// `count` está en unidades de T;por exemplo, un `count` de 3 representa un desprazamento de punteiro de bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Se se incumpre algunha das seguintes condicións, o resultado é Comportamento indefinido:
    ///
    /// * Tanto o punteiro inicial como o resultante deben estar entre límites ou un byte máis aló do final do mesmo obxecto asignado.
    /// Teña en conta que en Rust, cada variable (stack-allocated) considérase un obxecto asignado por separado.
    ///
    /// * A compensación computada,**en bytes**, non pode desbordar un `isize`.
    ///
    /// * O desprazamento dentro dos límites non pode depender de "wrapping around" no espazo de enderezos.É dicir, a suma de precisión infinita,**en bytes**, debe caber nun uso.
    ///
    /// O compilador e a biblioteca estándar normalmente intentan que as asignacións nunca alcancen un tamaño onde o desprazamento é un problema.
    /// Por exemplo, `Vec` e `Box` aseguran que nunca asignan máis de `isize::MAX` bytes, polo que `vec.as_ptr().add(vec.len())` sempre é seguro.
    ///
    /// A maioría das plataformas fundamentalmente non poden construír tal asignación.
    /// Por exemplo, ningunha plataforma coñecida de 64 bits pode atender unha petición de 2 <sup>63</sup> bytes debido ás limitacións da táboa de páxinas ou ao dividir o espazo de enderezos.
    /// Non obstante, algunhas plataformas de 32 e 16 bits poden servir con éxito unha solicitude de máis de `isize::MAX` bytes con cousas como a extensión de enderezo físico.
    ///
    /// Como tal, a memoria adquirida directamente de asignadores ou ficheiros mapeados de memoria *pode* ser demasiado grande para manexala con esta función.
    ///
    /// Considere usar [`wrapping_offset`] no seu lugar se estas restricións son difíciles de satisfacer.
    /// A única vantaxe deste método é que permite optimizar máis agresivamente os compiladores.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Calcula o desprazamento dun punteiro usando aritmética de envoltura.
    ///
    /// `count` está en unidades de T;por exemplo, un `count` de 3 representa un desprazamento de punteiro de bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Esta operación en si sempre é segura, pero o uso do punteiro resultante non.
    ///
    /// O punteiro resultante permanece unido ao mesmo obxecto asignado ao que apunta `self`.
    /// *Non* pode usarse para acceder a un obxecto asignado diferente.Teña en conta que en Rust, cada variable (stack-allocated) considérase un obxecto asignado por separado.
    ///
    /// Noutras palabras, `let z = x.wrapping_offset((y as isize) - (x as isize))`*non* fai que `z` sexa o mesmo que `y` aínda que supoñamos que `T` ten o tamaño `1` e non hai desbordamento: `z` segue unido ao obxecto ao que está unido `x` e a súa derivación é un comportamento indefinido a menos que `x` e `y` apunta ao mesmo obxecto asignado.
    ///
    /// Comparado con [`offset`], este método retrasa basicamente o requisito de permanecer dentro do mesmo obxecto asignado: [`offset`] é un comportamento indefinido inmediato ao cruzar os límites do obxecto;`wrapping_offset` produce un punteiro pero aínda leva a un comportamento indefinido se un punteiro se desferencia cando está fóra dos límites do obxecto ao que está unido.
    /// [`offset`] pódese optimizar mellor e, polo tanto, é preferible no código sensible ao rendemento.
    ///
    /// A comprobación retardada só ten en conta o valor do punteiro que se referenciou, non os valores intermedios empregados durante o cálculo do resultado final.
    /// Por exemplo, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` é sempre o mesmo que `x`.Noutras palabras, permítese deixar o obxecto asignado e volvelo a introducir máis tarde.
    ///
    /// Se precisa cruzar os límites dos obxectos, coloque o punteiro nun número enteiro e faga a aritmética alí.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // Iterar usando un punteiro en bruto en incrementos de dous elementos
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Este bucle imprime "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SEGURIDADE: o `arith_offset` intrínseco non ten requisitos previos para ser chamado.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Calcula a distancia entre dous punteiros.O valor devolto está en unidades de T: a distancia en bytes divídese por `mem::size_of::<T>()`.
    ///
    /// Esta función é a inversa de [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Se se incumpre algunha das seguintes condicións, o resultado é Comportamento indefinido:
    ///
    /// * Tanto o punteiro inicial como o outro deben estar entre límites ou un byte pasado o final do mesmo obxecto asignado.
    /// Teña en conta que en Rust, cada variable (stack-allocated) considérase un obxecto asignado por separado.
    ///
    /// * Os dous punteiros deben *derivarse dun* punteiro cara ao mesmo obxecto.
    ///   (Vexa a continuación un exemplo.)
    ///
    /// * A distancia entre os punteiros, en bytes, debe ser un múltiplo exacto do tamaño de `T`.
    ///
    /// * A distancia entre os punteiros,**en bytes**, non pode rebordar un `isize`.
    ///
    /// * A distancia entre límites non pode depender de "wrapping around" no espazo de enderezos.
    ///
    /// Os tipos Rust nunca son maiores que as asignacións `isize::MAX` e Rust nunca arrodean o espazo de enderezos, polo que dous punteiros dentro dalgún valor de calquera tipo Rust `T` sempre cumprirán as dúas últimas condicións.
    ///
    /// A biblioteca estándar tamén garante que as asignacións nunca alcanzan un tamaño onde o desprazamento é un problema.
    /// Por exemplo, `Vec` e `Box` aseguran que nunca asignan máis de `isize::MAX` bytes, polo que `ptr_into_vec.offset_from(vec.as_ptr())` sempre cumpre as dúas últimas condicións.
    ///
    /// A maioría das plataformas fundamentalmente nin sequera poden construír unha asignación tan grande.
    /// Por exemplo, ningunha plataforma coñecida de 64 bits pode atender unha petición de 2 <sup>63</sup> bytes debido ás limitacións da táboa de páxinas ou ao dividir o espazo de enderezos.
    /// Non obstante, algunhas plataformas de 32 e 16 bits poden servir con éxito unha solicitude de máis de `isize::MAX` bytes con cousas como a extensión de enderezo físico.
    /// Como tal, a memoria adquirida directamente de asignadores ou ficheiros mapeados de memoria *pode* ser demasiado grande para manexala con esta función.
    /// (Teña en conta que [`offset`] e [`add`] tamén teñen unha limitación similar e, polo tanto, tampouco se poden usar en asignacións tan grandes.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Esta función panics se `T` é un tipo de tamaño cero ("ZST").
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Uso incorrecto*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Fai ptr2_other un "alias" de ptr2, pero derivado de ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Dado que ptr2_other e ptr2 son derivados de punteiros a diferentes obxectos, o cálculo do seu desprazamento é un comportamento indefinido, aínda que apunten ao mesmo enderezo.
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Comportamento sen definir
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Devolve se hai dous punteiros iguais.
    ///
    /// No tempo de execución esta función compórtase como `self == other`.
    /// Non obstante, nalgúns contextos (por exemplo, a avaliación en tempo de compilación), non sempre é posible determinar a igualdade de dous punteiros, polo que esta función pode devolver espuriosamente `false` para os punteiros que despois resulten iguais.
    ///
    /// Pero cando devolve `true`, os punteiros están garantidos para ser iguais.
    ///
    /// Esta función é o espello de [`guaranteed_ne`], pero non a súa inversa.Hai comparacións de punteiros para as que ambas funcións devolven `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// O valor de retorno pode cambiar dependendo da versión do compilador e o código non seguro pode non depender do resultado desta función para ter solidez.
    /// Suxírese usar esta función só para optimizacións de rendemento onde os valores de retorno `false` falsos por esta función non afectan o resultado, senón só o rendemento.
    /// Non se exploraron as consecuencias de usar este método para facer que o tempo de execución e o código de compilación se comporten de xeito diferente.
    /// Este método non se debe empregar para introducir esas diferenzas e tampouco debe estabilizarse antes de que entendamos mellor este problema.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Devolve se se garante que dous indicadores son desiguais.
    ///
    /// No tempo de execución esta función compórtase como `self != other`.
    /// Non obstante, nalgúns contextos (por exemplo, a avaliación en tempo de compilación), non sempre é posible determinar a desigualdade de dous punteiros, polo que esta función pode devolver `false` de forma espúrea para os punteiros que despois resulten desiguais.
    ///
    /// Pero cando devolve `true`, os punteiros están garantidos para ser desiguais.
    ///
    /// Esta función é o espello de [`guaranteed_eq`], pero non a súa inversa.Hai comparacións de punteiros para as que ambas funcións devolven `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// O valor de retorno pode cambiar dependendo da versión do compilador e o código non seguro pode non depender do resultado desta función para ter solidez.
    /// Suxírese usar esta función só para optimizacións de rendemento onde os valores de retorno `false` falsos por esta función non afectan o resultado, senón só o rendemento.
    /// Non se exploraron as consecuencias de usar este método para facer que o tempo de execución e o código de compilación se comporten de xeito diferente.
    /// Este método non se debe empregar para introducir esas diferenzas e tampouco debe estabilizarse antes de que entendamos mellor este problema.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Calcula o desprazamento dun punteiro (conveniencia para `.offset(count as isize)`).
    ///
    /// `count` está en unidades de T;por exemplo, un `count` de 3 representa un desprazamento de punteiro de bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Se se incumpre algunha das seguintes condicións, o resultado é Comportamento indefinido:
    ///
    /// * Tanto o punteiro inicial como o resultante deben estar entre límites ou un byte máis aló do final do mesmo obxecto asignado.
    /// Teña en conta que en Rust, cada variable (stack-allocated) considérase un obxecto asignado por separado.
    ///
    /// * A compensación computada,**en bytes**, non pode desbordar un `isize`.
    ///
    /// * O desprazamento no límite non pode depender de "wrapping around" o espazo de enderezos.É dicir, a suma de precisión infinita debe caber nun `usize`.
    ///
    /// O compilador e a biblioteca estándar normalmente intentan que as asignacións nunca alcancen un tamaño onde o desprazamento é un problema.
    /// Por exemplo, `Vec` e `Box` aseguran que nunca asignan máis de `isize::MAX` bytes, polo que `vec.as_ptr().add(vec.len())` sempre é seguro.
    ///
    /// A maioría das plataformas fundamentalmente non poden construír tal asignación.
    /// Por exemplo, ningunha plataforma coñecida de 64 bits pode atender unha petición de 2 <sup>63</sup> bytes debido ás limitacións da táboa de páxinas ou ao dividir o espazo de enderezos.
    /// Non obstante, algunhas plataformas de 32 e 16 bits poden servir con éxito unha solicitude de máis de `isize::MAX` bytes con cousas como a extensión de enderezo físico.
    ///
    /// Como tal, a memoria adquirida directamente de asignadores ou ficheiros mapeados de memoria *pode* ser demasiado grande para manexala con esta función.
    ///
    /// Considere usar [`wrapping_add`] no seu lugar se estas restricións son difíciles de satisfacer.
    /// A única vantaxe deste método é que permite optimizar máis agresivamente os compiladores.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Calcula o desprazamento dun punteiro (conveniencia para `.offset ((contar como isize).wrapping_neg())`).
    ///
    /// `count` está en unidades de T;por exemplo, un `count` de 3 representa un desprazamento de punteiro de bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Se se incumpre algunha das seguintes condicións, o resultado é Comportamento indefinido:
    ///
    /// * Tanto o punteiro inicial como o resultante deben estar entre límites ou un byte máis aló do final do mesmo obxecto asignado.
    /// Teña en conta que en Rust, cada variable (stack-allocated) considérase un obxecto asignado por separado.
    ///
    /// * A compensación computada non pode superar `isize::MAX`**bytes**.
    ///
    /// * O desprazamento dentro dos límites non pode depender de "wrapping around" no espazo de enderezos.É dicir, a suma de precisión infinita debe encaixar nun uso.
    ///
    /// O compilador e a biblioteca estándar normalmente intentan que as asignacións nunca alcancen un tamaño onde o desprazamento é un problema.
    /// Por exemplo, `Vec` e `Box` aseguran que nunca asignan máis de `isize::MAX` bytes, polo que `vec.as_ptr().add(vec.len()).sub(vec.len())` sempre é seguro.
    ///
    /// A maioría das plataformas fundamentalmente non poden construír tal asignación.
    /// Por exemplo, ningunha plataforma coñecida de 64 bits pode atender unha petición de 2 <sup>63</sup> bytes debido ás limitacións da táboa de páxinas ou ao dividir o espazo de enderezos.
    /// Non obstante, algunhas plataformas de 32 e 16 bits poden servir con éxito unha solicitude de máis de `isize::MAX` bytes con cousas como a extensión de enderezo físico.
    ///
    /// Como tal, a memoria adquirida directamente de asignadores ou ficheiros mapeados de memoria *pode* ser demasiado grande para manexala con esta función.
    ///
    /// Considere usar [`wrapping_sub`] no seu lugar se estas restricións son difíciles de satisfacer.
    /// A única vantaxe deste método é que permite optimizar máis agresivamente os compiladores.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Calcula o desprazamento dun punteiro usando aritmética de envoltura.
    /// (comodidade para `.wrapping_offset(count as isize)`)
    ///
    /// `count` está en unidades de T;por exemplo, un `count` de 3 representa un desprazamento de punteiro de bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Esta operación en si sempre é segura, pero o uso do punteiro resultante non.
    ///
    /// O punteiro resultante permanece unido ao mesmo obxecto asignado ao que apunta `self`.
    /// *Non* pode usarse para acceder a un obxecto asignado diferente.Teña en conta que en Rust, cada variable (stack-allocated) considérase un obxecto asignado por separado.
    ///
    /// Noutras palabras, `let z = x.wrapping_add((y as usize) - (x as usize))`*non* fai que `z` sexa o mesmo que `y` aínda que supoñamos que `T` ten o tamaño `1` e non hai desbordamento: `z` segue unido ao obxecto ao que está unido `x` e a súa derivación é un comportamento indefinido a menos que `x` e `y` apunta ao mesmo obxecto asignado.
    ///
    /// Comparado con [`add`], este método retrasa basicamente o requisito de permanecer dentro do mesmo obxecto asignado: [`add`] é un comportamento indefinido inmediato ao cruzar os límites do obxecto;`wrapping_add` produce un punteiro pero aínda leva a un comportamento indefinido se un punteiro se desferencia cando está fóra dos límites do obxecto ao que está unido.
    /// [`add`] pódese optimizar mellor e, polo tanto, é preferible no código sensible ao rendemento.
    ///
    /// A comprobación retardada só ten en conta o valor do punteiro que se referenciou, non os valores intermedios empregados durante o cálculo do resultado final.
    /// Por exemplo, `x.wrapping_add(o).wrapping_sub(o)` é sempre o mesmo que `x`.Noutras palabras, permítese deixar o obxecto asignado e volvelo a introducir máis tarde.
    ///
    /// Se precisa cruzar os límites dos obxectos, coloque o punteiro nun número enteiro e faga a aritmética alí.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // Iterar usando un punteiro en bruto en incrementos de dous elementos
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Este bucle imprime "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Calcula o desprazamento dun punteiro usando aritmética de envoltura.
    /// (comodidade para `.wrapping_offset ((contar como isize).wrapping_neg())`)
    ///
    /// `count` está en unidades de T;por exemplo, un `count` de 3 representa un desprazamento de punteiro de bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Esta operación en si sempre é segura, pero o uso do punteiro resultante non.
    ///
    /// O punteiro resultante permanece unido ao mesmo obxecto asignado ao que apunta `self`.
    /// *Non* pode usarse para acceder a un obxecto asignado diferente.Teña en conta que en Rust, cada variable (stack-allocated) considérase un obxecto asignado por separado.
    ///
    /// Noutras palabras, `let z = x.wrapping_sub((x as usize) - (y as usize))`*non* fai que `z` sexa o mesmo que `y` aínda que supoñamos que `T` ten o tamaño `1` e non hai desbordamento: `z` segue unido ao obxecto ao que está unido `x` e a súa derivación é Comportamento indefinido a menos que `x` e `y` apunta ao mesmo obxecto asignado.
    ///
    /// Comparado con [`sub`], este método retrasa basicamente o requisito de permanecer dentro do mesmo obxecto asignado: [`sub`] é un comportamento indefinido inmediato ao cruzar os límites do obxecto;`wrapping_sub` produce un punteiro pero aínda leva a un comportamento indefinido se un punteiro se desferencia cando está fóra dos límites do obxecto ao que está unido.
    /// [`sub`] pódese optimizar mellor e, polo tanto, é preferible no código sensible ao rendemento.
    ///
    /// A comprobación retardada só ten en conta o valor do punteiro que se referenciou, non os valores intermedios empregados durante o cálculo do resultado final.
    /// Por exemplo, `x.wrapping_add(o).wrapping_sub(o)` é sempre o mesmo que `x`.Noutras palabras, permítese deixar o obxecto asignado e volvelo a introducir máis tarde.
    ///
    /// Se precisa cruzar os límites dos obxectos, coloque o punteiro nun número enteiro e faga a aritmética alí.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // Iterar usando un punteiro en bruto en incrementos de dous elementos (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Este bucle imprime "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Establece o valor do punteiro en `ptr`.
    ///
    /// No caso de que `self` sexa un punteiro (fat) a un tipo sen tamaño, esta operación só afectará á parte do punteiro, mentres que para os punteiros (thin) a tipos de tamaño, isto ten o mesmo efecto que unha simple asignación.
    ///
    /// O punteiro resultante terá a procedencia de `val`, é dicir, para un punteiro de graxa, esta operación é semánticamente a mesma que crear un novo punteiro de graxa co valor do punteiro de datos de `val` pero os metadatos de `self`.
    ///
    ///
    /// # Examples
    ///
    /// Esta función é útil principalmente para permitir a aritmética do punteiro con byte en punteiros potencialmente gordos:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // imprimirá "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // SEGURIDADE: no caso dun punteiro fino, estas operacións son idénticas
        // a unha tarefa sinxela.
        // No caso dun punteiro de graxa, coa implementación actual do deseño de punteiro de graxa, o primeiro campo deste punteiro sempre é o punteiro de datos, que tamén se asigna.
        //
        unsafe { *thin = val };
        self
    }

    /// Le o valor de `self` sen movelo.
    /// Isto deixa a memoria en `self` inalterada.
    ///
    /// Vexa [`ptr::read`] para obter dúbidas e exemplos de seguridade.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `read`.
        unsafe { read(self) }
    }

    /// Realiza unha lectura volátil do valor de `self` sen movelo.Isto deixa a memoria en `self` inalterada.
    ///
    /// As operacións volátiles están destinadas a actuar na memoria I/O e están garantidas por que o compilador non elide nin reordena outras operacións volátiles.
    ///
    ///
    /// Vexa [`ptr::read_volatile`] para obter dúbidas e exemplos de seguridade.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Le o valor de `self` sen movelo.
    /// Isto deixa a memoria en `self` inalterada.
    ///
    /// A diferenza de `read`, o punteiro pode non estar aliñado.
    ///
    /// Vexa [`ptr::read_unaligned`] para obter dúbidas e exemplos de seguridade.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Copia bytes `count * size_of<T>` de `self` a `dest`.
    /// A fonte e o destino poden superpoñerse.
    ///
    /// NOTE: ten a mesma orde de argumentos que [`ptr::copy`].
    ///
    /// Vexa [`ptr::copy`] para obter dúbidas e exemplos de seguridade.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Copia bytes `count * size_of<T>` de `self` a `dest`.
    /// A fonte e o destino poden *non* superpoñerse.
    ///
    /// NOTE: ten a mesma orde de argumentos que [`ptr::copy_nonoverlapping`].
    ///
    /// Vexa [`ptr::copy_nonoverlapping`] para obter dúbidas e exemplos de seguridade.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Calcula o desprazamento que hai que aplicar ao punteiro para facelo aliñado con `align`.
    ///
    /// Se non é posible aliñar o punteiro, a implementación devolve `usize::MAX`.
    /// É permitido que a implementación *sempre* devolva `usize::MAX`.
    /// Só o rendemento do seu algoritmo pode depender de obter unha compensación útil aquí, non da súa corrección.
    ///
    /// A compensación exprésase en número de elementos `T` e non en bytes.O valor devolto pódese usar co método `wrapping_add`.
    ///
    /// Non hai ningunha garantía de que a compensación do punteiro non se desborde nin vaia máis alá da asignación á que apunta o punteiro.
    ///
    /// Depende do interlocutor asegurarse de que o desprazamento devolto é correcto en todos os termos distintos do aliñamento.
    ///
    /// # Panics
    ///
    /// A función panics se `align` non é unha potencia de dous.
    ///
    /// # Examples
    ///
    /// Acceso a `u8` adxacente como `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // mentres que o punteiro pode aliñarse a través de `offset`, apuntaría fóra da asignación
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SEGURIDADE: comprobouse que `align` ten unha potencia 2 superior
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Devolve a lonxitude dunha porción en bruto.
    ///
    /// O valor devolto é o número de **elementos**, non o número de bytes.
    ///
    /// Esta función é segura, incluso cando a porción en bruto non se pode converter nunha referencia de porción porque o punteiro é nulo ou non aliñado.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SEGURIDADE: isto é seguro porque `*const [T]` e `FatPtr<T>` teñen o mesmo deseño.
            // Só `std` pode facer esta garantía.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Devolve un punteiro en bruto ao búfer da porción.
    ///
    /// Isto equivale a lanzar `self` a `*const T`, pero é máis seguro para o tipo.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Devolve un punteiro en bruto a un elemento ou subslice, sen facer comprobación de límites.
    ///
    /// Chamar a este método cun índice fóra dos límites ou cando `self` non se pode referenciar é *[comportamento indefinido]* aínda que non se use o punteiro resultante.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SEGURIDADE: o interlocutor garante que `self` é desfase de referencia e `index` está dentro dos límites.
        unsafe { index.get_unchecked(self) }
    }

    /// Devolve `None` se o punteiro é nulo, ou ben devolve unha porción compartida ao valor envolto en `Some`.
    /// A diferenza do [`as_ref`], isto non require que se inicialice o valor.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Ao chamar a este método, ten que asegurarse de que *ou* o punteiro é NULO *ou* todo o seguinte é certo:
    ///
    /// * O punteiro debe ser [valid] para lecturas para moitos bytes `ptr.len() * mem::size_of::<T>()` e debe estar correctamente aliñado.Isto significa en particular:
    ///
    ///     * Todo o intervalo de memoria desta porción debe estar contido nun único obxecto asignado.
    ///       As franxas nunca poden abarcar varios obxectos asignados.
    ///
    ///     * O punteiro debe estar aliñado incluso para franxas de lonxitude cero.
    ///     Unha das razóns para iso é que as optimizacións de deseño enum poden depender de que as referencias (incluídas as franxas de calquera lonxitude) estean aliñadas e non nulas para distinguilas doutros datos.
    ///
    ///     Podes obter un punteiro que se poida usar como `data` para franxas de lonxitude cero usando [`NonNull::dangling()`].
    ///
    /// * O tamaño total `ptr.len() * mem::size_of::<T>()` da porción non debe ser maior que `isize::MAX`.
    ///   Consulte a documentación de seguridade de [`pointer::offset`].
    ///
    /// * Debe facer cumprir as regras de aliasing de Rust, xa que a vida útil retornada `'a` é elixida arbitrariamente e non reflicte necesariamente a vida real dos datos.
    ///   En particular, durante a duración desta vida, a memoria á que apunta o punteiro non debe mutarse (excepto dentro de `UnsafeCell`).
    ///
    /// Isto aplícase aínda que o resultado deste método non se use.
    ///
    /// Vexa tamén [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Igualdade para os punteiros
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Comparación para punteiros
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}