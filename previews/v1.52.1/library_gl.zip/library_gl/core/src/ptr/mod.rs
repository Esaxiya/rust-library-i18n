//! Xestionar manualmente a memoria a través de punteiros en bruto.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Moitas funcións deste módulo toman punteiros en bruto como argumentos e len ou escriben neles.Para que isto sexa seguro, estes indicadores deben ser *válidos*.
//! Se un punteiro é válido depende da operación para a que se usa (ler ou escribir) e da extensión da memoria á que se accede (é dicir, cantos bytes son read/written).
//! A maioría das funcións utilizan `*mut T` e `* const T` para acceder só a un único valor, nese caso a documentación omite o tamaño e supón implícitamente que son bytes `size_of::<T>()`.
//!
//! As regras precisas de validez aínda non están determinadas.As garantías que se proporcionan neste momento son moi mínimas:
//!
//! * Un punteiro [null] é *nunca* válido, nin sequera para accesos a [size zero][zst].
//! * Para que un punteiro sexa válido, é necesario, pero non sempre, que o punteiro sexa *desferenciable*: o intervalo de memoria do tamaño dado comezando polo punteiro debe estar dentro dos límites dun único obxecto asignado.
//!
//! Teña en conta que en Rust, cada variable (stack-allocated) considérase un obxecto asignado por separado.
//! * Mesmo para operacións de [size zero][zst], o punteiro non debe estar apuntando cara á memoria deslocalizada, é dicir, a deslocalización fai que os punteiros non sexan válidos incluso para operacións de tamaño cero.
//! Non obstante, enviar calquera punto enteiro non literal *literal* a un punteiro é válido para accesos de tamaño cero, aínda que haxa algunha memoria nese enderezo e se deslocue.
//! Isto corresponde a escribir o seu propio asignador: asignar obxectos de tamaño cero non é moi difícil.
//! O xeito canónico de obter un punteiro válido para accesos de tamaño cero é [`NonNull::dangling`].
//! * Todos os accesos realizados polas funcións deste módulo son *non atómicos* no sentido de [atomic operations] usado para sincronizar entre fíos.
//! Isto significa que é un comportamento indefinido realizar dous accesos simultáneos á mesma situación desde fíos diferentes a non ser que os dous accesos só lean desde memoria.
//! Teña en conta que isto inclúe explícitamente [`read_volatile`] e [`write_volatile`]: os accesos volátiles non se poden usar para a sincronización entre fíos.
//! * O resultado de enviar unha referencia a un punteiro é válido mentres o obxecto subxacente estea vivo e non se utilice ningunha referencia (só punteiros en bruto) para acceder á mesma memoria.
//!
//! Estes axiomas, xunto co uso coidadoso de [`offset`] para a aritmética do punteiro, son suficientes para implementar correctamente moitas cousas útiles en código non seguro.
//! Finalmente proporcionaranse garantías máis fortes, xa que se están determinando as regras [aliasing].
//! Para obter máis información, consulte o [book], así como a sección da referencia dedicada a [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Os punteiros en bruto válidos como se definiron anteriormente non están necesariamente aliñados correctamente (onde o aliñamento "proper" está definido polo tipo de punta, é dicir, `*const T` debe aliñarse a `mem::align_of::<T>()`).
//! Non obstante, a maioría das funcións requiren que os seus argumentos estean correctamente aliñados e farán constar de xeito explícito este requisito na súa documentación.
//! Existen notables excepcións a isto: [`read_unaligned`] e [`write_unaligned`].
//!
//! Cando unha función require un aliñamento axeitado, faino aínda que o acceso teña o tamaño 0, é dicir, aínda que a memoria non se toque realmente.Considere usar [`NonNull::dangling`] nestes casos.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Executa o destructor (se o hai) do valor apuntado.
///
/// Isto equivale semanticamente a chamar ao [`ptr::read`] e descartar o resultado, pero ten as seguintes vantaxes:
///
/// * *É obrigatorio* usar `drop_in_place` para soltar tipos sen tamaño como obxectos trait, porque non se poden ler na pila e deixalos caer normalmente.
///
/// * É máis amigable co optimizador facelo con [`ptr::read`] ao soltar a memoria asignada manualmente (por exemplo, nas implementacións de `Box`/`Rc`/`Vec`), xa que o compilador non necesita demostrar que é só elidir a copia.
///
///
/// * Pode usarse para eliminar datos [pinned] cando `T` non é `repr(packed)` (os datos fixados non se deben mover antes de que caian).
///
/// Non se poden deixar caer os valores non aliñados no seu lugar, primeiro deben copiarse nun lugar aliñado usando [`ptr::read_unaligned`].Para as estruturas empaquetadas, este movemento realízase automaticamente polo compilador.
/// Isto significa que os campos das estruturas empaquetadas non se deixan caer no lugar.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// O comportamento non está definido se se incumpre algunha das seguintes condicións:
///
/// * `to_drop` debe ser [valid] tanto para as lecturas como para as escrituras.
///
/// * `to_drop` debe estar correctamente aliñado.
///
/// * O valor `to_drop` puntos a debe ser válido para caer, o que pode significar que debe manter invariantes adicionais, isto depende do tipo.
///
/// Ademais, se `T` non é [`Copy`], usar o valor apuntado despois de chamar a `drop_in_place` pode causar un comportamento indefinido.Teña en conta que `*to_drop = foo` conta como un uso porque fará que o valor se caia de novo.
/// [`write()`] pódese usar para sobrescribir datos sen provocar a súa caída.
///
/// Teña en conta que, aínda que `T` teña o tamaño `0`, o punteiro debe ser non NULO e aliñado correctamente.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Elimina manualmente o último elemento dun vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Obtén un punteiro en bruto ata o último elemento en `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Acurta `v` para evitar que se caia o último elemento.
///     // Facemos isto primeiro, para evitar problemas se o `drop_in_place` está por baixo de panics.
///     v.set_len(1);
///     // Sen unha chamada `drop_in_place`, o último elemento nunca caería e a memoria que xestiona filtraríase.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Asegúrese de que se eliminou o último elemento.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Teña en conta que o compilador realiza esta copia automaticamente ao soltar as estruturas empaquetadas, é dicir, non adoita preocuparse por tales problemas a menos que chame ao `drop_in_place` manualmente.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Aquí o código non importa, isto é substituído pola cola de gota real do compilador.
    //

    // SEGURIDADE: ver comentario anterior
    unsafe { drop_in_place(to_drop) }
}

/// Crea un punteiro en bruto nulo.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Crea un punteiro en bruto mutable nulo.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Necesítase unha aplicación manual para evitar o límite `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Necesítase unha aplicación manual para evitar o límite `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Forma unha porción bruta a partir dun punteiro e unha lonxitude.
///
/// O argumento `len` é o número de **elementos**, non o número de bytes.
///
/// Esta función é segura, pero o feito de usar o valor devolto non é seguro.
/// Consulte a documentación de [`slice::from_raw_parts`] para os requisitos de seguridade do sector.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // cree un punteiro de corte cando comece cun punteiro ao primeiro elemento
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SEGURIDADE: acceder ao valor desde a unión `Repr` é seguro dende * const [T]
        //
        // e FatPtr teñen os mesmos deseños de memoria.Só std pode facer esta garantía.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Realiza a mesma funcionalidade que [`slice_from_raw_parts`], excepto que se devolve unha porción mutable en bruto, en oposición a unha porción inmutable en bruto.
///
///
/// Consulte a documentación de [`slice_from_raw_parts`] para máis detalles.
///
/// Esta función é segura, pero o feito de usar o valor devolto non é seguro.
/// Consulte a documentación de [`slice::from_raw_parts_mut`] para os requisitos de seguridade do sector.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // asigna un valor a un índice da porción
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SEGURIDADE: acceder ao valor desde a unión `Repr` é seguro xa que * mut [T]
        // e FatPtr teñen os mesmos deseños de memoria
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Intercambia os valores en dúas localizacións mudables do mesmo tipo, sen desinicializar ningunha.
///
/// Pero para as seguintes dúas excepcións, esta función é semanticamente equivalente a [`mem::swap`]:
///
///
/// * Funciona con punteiros en bruto no canto de referencias.
/// Cando as referencias estean dispoñibles, debería preferirse [`mem::swap`].
///
/// * Os dous valores apuntados poden superpoñerse.
/// Se os valores se superpoñen, empregarase a rexión de memoria superposta de `x`.
/// Isto demóstrase no segundo exemplo a continuación.
///
/// # Safety
///
/// O comportamento non está definido se se incumpre algunha das seguintes condicións:
///
/// * Tanto `x` como `y` deben ser [valid] tanto para as lecturas como para as escrituras.
///
/// * Tanto `x` como `y` deben estar correctamente aliñados.
///
/// Teña en conta que, aínda que `T` teña o tamaño `0`, os punteiros non deben ser NULOS e están aliñados correctamente.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Intercambio de dúas rexións que non se superpoñen:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // isto é `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // isto é `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Intercambio de dúas rexións superpostas:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // isto é `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // isto é `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Os índices `1..3` da porción se superpoñen entre `x` e `y`.
///     // Os resultados razoables serían para eles `[2, 3]`, polo que os índices `0..3` son `[1, 2, 3]` (coinciden con `y` antes que `swap`);ou para que sexan `[0, 1]` para que os índices `1..4` sexan `[0, 1, 2]` (coinciden con `x` antes que `swap`).
/////
///     // Esta implementación defínese para facer esta última elección.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Dámonos un pouco de espazo para traballar.
    // Non nos preocupamos polas caídas: `MaybeUninit` non fai nada cando se cae.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Realice o intercambio de SEGURIDADE: o interlocutor debe garantir que `x` e `y` son válidos para escrituras e están correctamente aliñados.
    // `tmp` Non se poden superpoñer `x` nin `y` porque `tmp` só se asignou na pila como un obxecto asignado por separado.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` e `y` poden superpoñerse
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Intercambia bytes `count * size_of::<T>()` entre as dúas rexións de memoria a partir de `x` e `y`.
/// As dúas rexións non deben * superpoñerse.
///
/// # Safety
///
/// O comportamento non está definido se se incumpre algunha das seguintes condicións:
///
/// * Tanto `x` como `y` deben ser [valid] tanto para as lecturas como para as escrituras de `count *
///   tamaño_de: :<T>() `bytes.
///
/// * Tanto `x` como `y` deben estar correctamente aliñados.
///
/// * A rexión da memoria que comeza en `x` cun tamaño de `count *
///   tamaño_de: :<T>() `Os bytes *non* deben * superpoñerse á rexión de memoria que comeza en `y` co mesmo tamaño.
///
/// Teña en conta que, aínda que o tamaño efectivamente copiado (`count * size_of: :<T>()`) é `0`, os punteiros non deben ser NULOS e están correctamente aliñados.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SEGURIDADE: o interlocutor debe garantir que o son `x` e `y`
    // válido para escrituras e correctamente aliñado.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Para os tipos máis pequenos que a optimización de bloques de abaixo, basta con intercambiar directamente para evitar pesimizar o codegen.
    //
    if mem::size_of::<T>() < 32 {
        // SEGURIDADE: o interlocutor debe garantir que `x` e `y` son válidos
        // para escrituras, correctamente aliñadas e sen superposición.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // O enfoque aquí é empregar simd para intercambiar de forma eficiente xy.
    // A proba revela que o intercambio de 32 ou 64 bytes á vez é o máis eficiente para os procesadores Intel Haswell E.
    // LLVM é máis capaz de optimizar se lle damos a unha estrutura un #[repr(simd)], aínda que realmente non a empregamos directamente.
    //
    //
    // FIXME repr(simd) roto en emscripten e redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Pasa por xy y, copiándoos `Block` á vez. O optimizador debería desenrolar completamente o lazo para a maioría dos tipos. NB
    // Non podemos usar un bucle for xa que o `range` impl chama recursivamente a `mem::swap`
    //
    let mut i = 0;
    while i + block_size <= len {
        // Crear memoria non inicializada como espazo de cero Declarar `t` aquí evita aliñar a pila cando non se usa este bucle
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SEGURIDADE: como `i < len` e como o interlocutor debe garantir que `x` e `y` son válidos
        // para bytes `len`, `x + i` e `y + i` deben ser enderezos válidos, o que cumpre o contrato de seguridade para `add`.
        //
        // Ademais, o interlocutor debe garantir que `x` e `y` son válidos para escrituras, correctamente aliñados e sen superposición, o que cumpre o contrato de seguridade para `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Cambia un bloque de bytes de xy y, usando t como búfer temporal Isto debería optimizarse en operacións SIMD eficientes cando estean dispoñibles
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Intercambia os bytes restantes
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SEGURIDADE: ver comentario de seguridade anterior.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Move `src` ao `dst` apuntado, devolvendo o valor `dst` anterior.
///
/// Non se baixa ningún valor.
///
/// Esta función é semanticamente equivalente a [`mem::replace`], excepto que opera en punteiros en bruto no canto de referencias.
/// Cando as referencias estean dispoñibles, debería preferirse [`mem::replace`].
///
/// # Safety
///
/// O comportamento non está definido se se incumpre algunha das seguintes condicións:
///
/// * `dst` debe ser [valid] tanto para as lecturas como para as escrituras.
///
/// * `dst` debe estar correctamente aliñado.
///
/// * `dst` debe apuntar a un valor correctamente inicializado do tipo `T`.
///
/// Teña en conta que, aínda que `T` teña o tamaño `0`, o punteiro debe ser non NULO e aliñado correctamente.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` tería o mesmo efecto sen requirir o bloqueo non seguro.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SEGURIDADE: o interlocutor debe garantir que `dst` é válido
    // emitido a unha referencia mudable (válido para escrituras, aliñado, inicializado) e non pode superpoñerse a `src` xa que `dst` debe apuntar a un obxecto asignado distinto.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // non se pode solapar
    }
    src
}

/// Le o valor de `src` sen movelo.Isto deixa a memoria en `src` inalterada.
///
/// # Safety
///
/// O comportamento non está definido se se incumpre algunha das seguintes condicións:
///
/// * `src` debe ser [valid] para as lecturas.
///
/// * `src` debe estar correctamente aliñado.Use [`read_unaligned`] se este non é o caso.
///
/// * `src` debe apuntar a un valor correctamente inicializado do tipo `T`.
///
/// Teña en conta que, aínda que `T` teña o tamaño `0`, o punteiro debe ser non NULO e aliñado correctamente.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Implementar manualmente [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Crea unha copia bit a bit do valor en `a` en `tmp`.
///         let tmp = ptr::read(a);
///
///         // Saír neste punto (xa sexa retornando de forma explícita ou chamando a unha función que panics) faría que o valor en `tmp` fose eliminado mentres `a` aínda fai referencia ao mesmo valor.
///         // Isto pode desencadear un comportamento indefinido se `T` non é `Copy`.
/////
/////
///
///         // Crea unha copia bit a bit do valor en `b` en `a`.
///         // Isto é seguro porque as referencias mutables non poden alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Como anteriormente, saír aquí podería desencadear un comportamento indefinido porque `a` e `b` fan referencia ao mesmo valor.
/////
///
///         // Move `tmp` a `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` foi movido (`write` faise co seu segundo argumento), polo que nada se deixa implícito aquí.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Propiedade do valor devolto
///
/// `read` crea unha copia bit a bit de `T`, independentemente de que `T` sexa [`Copy`].
/// Se `T` non é [`Copy`], usar tanto o valor devolto como o valor en `*src` pode violar a seguridade da memoria.
/// Teña en conta que asignar a `*src` conta como un uso porque intentará baixar o valor en `* src`.
///
/// [`write()`] pódese usar para sobrescribir datos sen provocar a súa caída.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` agora apunta á mesma memoria subxacente que `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // A asignación a `s2` fai que se elimine o seu valor orixinal.
///     // Máis aló deste punto, `s` xa non debe usarse, xa que se liberou a memoria subxacente.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Se se asigna a `s`, o valor anterior caerá de novo, dando lugar a un comportamento indefinido.
/////
///     // s= String::from("bar");//ERRO
///
///     // `ptr::write` pódese usar para sobrescribir un valor sen deixalo caer.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SEGURIDADE: o interlocutor debe garantir que `src` é válido para lecturas.
    // `src` non se pode superpoñer a `tmp` porque `tmp` só se asignou na pila como un obxecto asignado por separado.
    //
    //
    // Ademais, dado que acabamos de escribir un valor válido en `tmp`, está garantido que se inicialice correctamente.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Le o valor de `src` sen movelo.Isto deixa a memoria en `src` inalterada.
///
/// A diferenza de [`read`], `read_unaligned` funciona con punteiros non aliñados.
///
/// # Safety
///
/// O comportamento non está definido se se incumpre algunha das seguintes condicións:
///
/// * `src` debe ser [valid] para as lecturas.
///
/// * `src` debe apuntar a un valor correctamente inicializado do tipo `T`.
///
/// Do mesmo xeito que [`read`], `read_unaligned` crea unha copia a bit de `T`, independentemente de que `T` sexa [`Copy`].
/// Se `T` non é [`Copy`], usando tanto o valor devolto como o valor en `*src` pode [violate memory safety][read-ownership].
///
/// Teña en conta que aínda que `T` teña o tamaño `0`, o punteiro non debe ser NULO.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## En estruturas `packed`
///
/// Actualmente é imposible crear punteiros en bruto para campos non aliñados dunha estrutura empaquetada.
///
/// Intentar crear un punteiro en bruto a un campo de estrutura `unaligned` cunha expresión como `&packed.unaligned as *const FieldType` crea unha referencia intermedia sen aliñar antes de convertelo nun punteiro en bruto.
///
/// Que esta referencia sexa temporal e emitida de inmediato non ten importancia xa que o compilador sempre espera que as referencias estean correctamente aliñadas.
/// Como resultado, usar `&packed.unaligned as *const FieldType` provoca un comportamento* indefinido * inmediato no seu programa.
///
/// Un exemplo do que non hai que facer e de como se relaciona isto con `read_unaligned` é:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Aquí intentamos tomar o enderezo dun enteiro de 32 bits que non está aliñado.
///     let unaligned =
///         // Aquí créase unha referencia temporal sen aliñar que resulta nun comportamento indefinido independentemente de que se use ou non a referencia.
/////
///         &packed.unaligned
///         // Emitir a un punteiro en bruto non axuda;o erro xa ocorreu.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Non obstante, é seguro acceder a campos non aliñados directamente por exemplo con `packed.unaligned`.
///
///
///
///
///
///
// FIXME: Actualice documentos baseados no resultado de RFC #2582 e amigos.
/// # Examples
///
/// Lea un valor de uso dun buffer de bytes:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SEGURIDADE: o interlocutor debe garantir que `src` é válido para lecturas.
    // `src` non se pode superpoñer a `tmp` porque `tmp` só se asignou na pila como un obxecto asignado por separado.
    //
    //
    // Ademais, dado que acabamos de escribir un valor válido en `tmp`, está garantido que se inicialice correctamente.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Sobrescribe unha localización de memoria co valor dado sen ler nin soltar o valor anterior.
///
/// `write` non deixa caer o contido de `dst`.
/// Isto é seguro, pero pode filtrar asignacións ou recursos, polo que hai que ter coidado de non sobrescribir un obxecto que se debería deixar caer.
///
///
/// Ademais, non cae `src`.Semanticamente, `src` móvese ao lugar indicado por `dst`.
///
/// Isto é apropiado para inicializar memoria non inicializada ou sobreescribir memoria que xa foi [`read`].
///
/// # Safety
///
/// O comportamento non está definido se se incumpre algunha das seguintes condicións:
///
/// * `dst` debe ser [valid] para as escrituras.
///
/// * `dst` debe estar correctamente aliñado.Use [`write_unaligned`] se este non é o caso.
///
/// Teña en conta que, aínda que `T` teña o tamaño `0`, o punteiro debe ser non NULO e aliñado correctamente.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Implementar manualmente [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Crea unha copia bit a bit do valor en `a` en `tmp`.
///         let tmp = ptr::read(a);
///
///         // Saír neste punto (xa sexa retornando de forma explícita ou chamando a unha función que panics) faría que o valor en `tmp` fose eliminado mentres `a` aínda fai referencia ao mesmo valor.
///         // Isto pode desencadear un comportamento indefinido se `T` non é `Copy`.
/////
/////
///
///         // Crea unha copia bit a bit do valor en `b` en `a`.
///         // Isto é seguro porque as referencias mutables non poden alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Como anteriormente, saír aquí podería desencadear un comportamento indefinido porque `a` e `b` fan referencia ao mesmo valor.
/////
///
///         // Move `tmp` a `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` foi movido (`write` faise co seu segundo argumento), polo que nada se deixa implícito aquí.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Chamamos aos intrínsecos directamente para evitar chamadas de función no código xerado xa que `intrinsics::copy_nonoverlapping` é unha función de envoltura.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SEGURIDADE: o interlocutor debe garantir que `dst` é válido para escrituras.
    // `dst` non se pode superpoñer a `src` porque o interlocutor ten acceso mutable a `dst` mentres `src` é propiedade desta función.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Sobrescribe unha localización de memoria co valor dado sen ler nin soltar o valor anterior.
///
/// A diferenza de [`write()`], o punteiro pode non estar aliñado.
///
/// `write_unaligned` non deixa caer o contido de `dst`.Isto é seguro, pero pode filtrar asignacións ou recursos, polo que hai que ter coidado de non sobrescribir un obxecto que se debería deixar caer.
///
/// Ademais, non cae `src`.Semanticamente, `src` móvese ao lugar indicado por `dst`.
///
/// Isto é apropiado para inicializar memoria non inicializada ou sobreescribir memoria que xa se leu con [`read_unaligned`].
///
/// # Safety
///
/// O comportamento non está definido se se incumpre algunha das seguintes condicións:
///
/// * `dst` debe ser [valid] para as escrituras.
///
/// Teña en conta que aínda que `T` teña o tamaño `0`, o punteiro non debe ser NULO.
///
/// [valid]: self#safety
///
/// ## En estruturas `packed`
///
/// Actualmente é imposible crear punteiros en bruto para campos non aliñados dunha estrutura empaquetada.
///
/// Intentar crear un punteiro en bruto a un campo de estrutura `unaligned` cunha expresión como `&packed.unaligned as *const FieldType` crea unha referencia intermedia sen aliñar antes de convertelo nun punteiro en bruto.
///
/// Que esta referencia sexa temporal e emitida de inmediato non ten importancia xa que o compilador sempre espera que as referencias estean correctamente aliñadas.
/// Como resultado, usar `&packed.unaligned as *const FieldType` provoca un comportamento* indefinido * inmediato no seu programa.
///
/// Un exemplo do que non hai que facer e de como se relaciona isto con `write_unaligned` é:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Aquí intentamos tomar o enderezo dun enteiro de 32 bits que non está aliñado.
///     let unaligned =
///         // Aquí créase unha referencia temporal sen aliñar que resulta nun comportamento indefinido independentemente de que se use ou non a referencia.
/////
///         &mut packed.unaligned
///         // Emitir a un punteiro en bruto non axuda;o erro xa ocorreu.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Non obstante, é seguro acceder a campos non aliñados directamente por exemplo con `packed.unaligned`.
///
///
///
///
///
///
///
///
///
// FIXME: Actualice documentos baseados no resultado de RFC #2582 e amigos.
/// # Examples
///
/// Escribe un valor de usize nun buffer de bytes:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SEGURIDADE: o interlocutor debe garantir que `dst` é válido para escrituras.
    // `dst` non se pode superpoñer a `src` porque o interlocutor ten acceso mutable a `dst` mentres `src` é propiedade desta función.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Chamamos ao intrínseco directamente para evitar chamadas de función no código xerado.
        intrinsics::forget(src);
    }
}

/// Realiza unha lectura volátil do valor de `src` sen movelo.Isto deixa a memoria en `src` inalterada.
///
/// As operacións volátiles están destinadas a actuar na memoria I/O e están garantidas por que o compilador non elide nin reordena outras operacións volátiles.
///
/// # Notes
///
/// Rust non ten actualmente un modelo de memoria rigorosamente e formalmente definido, polo que a semántica precisa do que significa "volatile" aquí está suxeita a cambios co paso do tempo.
/// Dito isto, a semántica case sempre acabará bastante parecida a [C11's definition of volatile][c11].
///
/// O compilador non debería cambiar a orde relativa ou o número de operacións de memoria volátil.
/// Non obstante, as operacións de memoria volátil en tipos de tamaño cero (por exemplo, se se pasa un tipo de tamaño cero a `read_volatile`) son noops e poden ignorarse.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// O comportamento non está definido se se incumpre algunha das seguintes condicións:
///
/// * `src` debe ser [valid] para as lecturas.
///
/// * `src` debe estar correctamente aliñado.
///
/// * `src` debe apuntar a un valor correctamente inicializado do tipo `T`.
///
/// Do mesmo xeito que [`read`], `read_volatile` crea unha copia a bit de `T`, independentemente de que `T` sexa [`Copy`].
/// Se `T` non é [`Copy`], usando tanto o valor devolto como o valor en `*src` pode [violate memory safety][read-ownership].
/// Non obstante, almacenar tipos que non [[Copiar]] na memoria volátil é case certamente incorrecto.
///
/// Teña en conta que, aínda que `T` teña o tamaño `0`, o punteiro debe ser non NULO e aliñado correctamente.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Do mesmo xeito que en C, se unha operación é volátil non ten ningunha influencia en cuestións que impliquen acceso simultáneo desde múltiples fíos.Os accesos volátiles compórtanse exactamente como os accesos non atómicos nese sentido.
///
/// En particular, unha carreira entre un `read_volatile` e calquera operación de escritura no mesmo lugar ten un comportamento indefinido.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Non entrar en pánico para manter o impacto do codegen menor.
        abort();
    }
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Realiza unha escritura volátil dunha localización de memoria co valor dado sen ler nin deixar caer o valor anterior.
///
/// As operacións volátiles están destinadas a actuar na memoria I/O e están garantidas por que o compilador non elide nin reordena outras operacións volátiles.
///
/// `write_volatile` non deixa caer o contido de `dst`.Isto é seguro, pero pode filtrar asignacións ou recursos, polo que hai que ter coidado de non sobrescribir un obxecto que se debería deixar caer.
///
/// Ademais, non cae `src`.Semanticamente, `src` móvese ao lugar indicado por `dst`.
///
/// # Notes
///
/// Rust non ten actualmente un modelo de memoria rigorosamente e formalmente definido, polo que a semántica precisa do que significa "volatile" aquí está suxeita a cambios co paso do tempo.
/// Dito isto, a semántica case sempre acabará bastante parecida a [C11's definition of volatile][c11].
///
/// O compilador non debería cambiar a orde relativa ou o número de operacións de memoria volátil.
/// Non obstante, as operacións de memoria volátil en tipos de tamaño cero (por exemplo, se se pasa un tipo de tamaño cero a `write_volatile`) son noops e poden ignorarse.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// O comportamento non está definido se se incumpre algunha das seguintes condicións:
///
/// * `dst` debe ser [valid] para as escrituras.
///
/// * `dst` debe estar correctamente aliñado.
///
/// Teña en conta que, aínda que `T` teña o tamaño `0`, o punteiro debe ser non NULO e aliñado correctamente.
///
/// [valid]: self#safety
///
/// Do mesmo xeito que en C, se unha operación é volátil non ten ningunha influencia en cuestións que impliquen acceso simultáneo desde múltiples fíos.Os accesos volátiles compórtanse exactamente como os accesos non atómicos nese sentido.
///
/// En particular, unha carreira entre un `write_volatile` e calquera outra operación (lectura ou escritura) no mesmo lugar é un comportamento indefinido.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Non entrar en pánico para manter o impacto do codegen menor.
        abort();
    }
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Aliñar o punteiro `p`.
///
/// Calcula a compensación (en termos de elementos de paso `stride`) que ten que aplicarse ao punteiro `p` para que o punteiro `p` se aliñe a `a`.
///
/// Note: Esta implementación adaptouse coidadosamente para non panic.É UB para isto a panic.
/// O único cambio real que se pode facer aquí é o cambio de `INV_TABLE_MOD_16` e as constantes asociadas.
///
/// Se algunha vez decidimos facer posible chamar ao intrínseco con `a` que non é un poder de dous, probablemente será máis prudente cambiar a unha implementación inxenua en lugar de intentar adaptalo para acomodalo.
///
///
/// Calquera dúbida vai a@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): O uso directo destes intrínsecos mellora significativamente o codegen a nivel opt <=
    // 1, onde as versións de método destas operacións non están subliñadas.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Calcular inversa modular multiplicativa de `x` módulo `m`.
    ///
    /// Esta implementación está adaptada a `align_offset` e ten as seguintes condicións previas:
    ///
    /// * `m` é un poder de dous;
    /// * `x < m`; (se `x ≥ m`, no `x % m`)
    ///
    /// A implementación desta función non será panic.Sempre.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Táboa inversa modular multiplicativa módulo 2⁴=16.
        ///
        /// Teña en conta que esta táboa non contén valores onde non existe a inversa (é dicir, para `0⁻¹ mod 16`, `2⁻¹ mod 16`, etc.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Módulo ao que está destinado o `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SEGURIDADE: é necesario que `m` sexa unha potencia de dous, polo tanto, non sexa nula.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Iteramos "up" usando a seguinte fórmula:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // ata 2²ⁿ ≥ m.Despois podemos reducir ao `m` desexado tomando o resultado `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Teña en conta que aquí usamos as operacións de envoltura de xeito intencionado: a fórmula orixinal utiliza por exemplo, a resta `mod n`.
                // Está ben facelos `mod usize::MAX` no seu lugar, porque ao final tomamos o resultado `mod n`.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SEGURIDADE: `a` é un poder de dous, polo tanto, non é cero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` case se pode calcular de xeito máis sinxelo a través de `-p (mod a)`, pero facelo inhibe a capacidade de LLVM para seleccionar instrucións como `lea`.En vez diso, calculamos
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // que distribúe operacións ao redor do soporte de carga, pero pesimizando o `and` o suficiente para que LLVM poida utilizar as diversas optimizacións que coñece.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Xa aliñado.¡Si!
        return 0;
    } else if stride == 0 {
        // Se o punteiro non está aliñado e o elemento ten un tamaño cero, entón ningunha cantidade de elementos aliñará o punteiro.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SEGURIDADE: a é a potencia de dous, polo tanto, non é nula.stride==0 caso manéxase máis arriba.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SEGURIDADE: gcdpow ten un límite superior que é como máximo o número de bits nun uso.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SEGURIDADE: o mcd sempre é maior ou igual a 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Este branch resolve a seguinte ecuación de congruencia lineal:
        //
        // ` p + so = 0 mod a `
        //
        // `p` aquí está o valor do punteiro, `s`, paso de `T`, offset `o` en `T`s e `a`, a aliñación solicitada.
        //
        // Con `g = gcd(a, s)`, e a condición anterior que afirma que `p` tamén é divisible por `g`, podemos denotar `a' = a/g`, `s' = s/g`, `p' = p/g`, entón isto faise equivalente a:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // O primeiro termo é "the relative alignment of `p` to `a`" (dividido polo `g`), o segundo termo é "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (de novo dividido por `g`).
        //
        // A división por `g` é necesaria para facer a inversa ben formada se `a` e `s` non son coprimos.
        //
        // Ademais, o resultado producido por esta solución non é "minimal", polo que é necesario tomar o resultado `o mod lcm(s, a)`.Podemos substituír `lcm(s, a)` por só un `a'`.
        //
        //
        //
        //
        //

        // SEGURIDADE: `gcdpow` ten un límite superior non superior ao número de 0 bits finais en `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SEGURIDADE: `a2` non é cero.Cambiar `a` por `gcdpow` non pode desprazar ningún dos bits definidos
        // en `a` (dos cales ten exactamente un).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SEGURIDADE: `gcdpow` ten un límite superior non superior ao número de 0 bits finais en `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SEGURIDADE: `gcdpow` ten un límite superior non superior ao número de 0 bits finais
        // `a`.
        // Ademais, a resta non pode desbordarse, porque `a2 = a >> gcdpow` sempre será estritamente maior que `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SEGURIDADE: `a2` é un poder de dous, como se demostrou anteriormente.`s2` é estritamente inferior a `a2`
        // porque `(s % a) >> gcdpow` é estritamente inferior a `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Non se pode aliñar en absoluto.
    usize::MAX
}

/// Compara os puntos crues para a igualdade.
///
/// Isto é o mesmo que usar o operador `==`, pero menos xenérico:
/// os argumentos teñen que ser punteiros en bruto `*const T`, non nada que implemente `PartialEq`.
///
/// Isto pódese usar para comparar as referencias `&T` (que coaccionan a `*const T` implicitamente) polo seu enderezo en lugar de comparar os valores aos que apuntan (que é o que fai a implementación `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// As lonchas tamén se comparan pola súa lonxitude (punteiros de graxa):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits tamén se compara coa súa implementación:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Os punteiros teñen enderezos iguais.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Os obxectos teñen enderezos iguais, pero `Trait` ten implementacións diferentes.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Converter a referencia nun `*const u8` compárase por enderezo.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash un punteiro en bruto.
///
/// Isto pódese usar para hashear unha referencia `&T` (que coacciona a `*const T` implicitamente) polo seu enderezo en lugar do valor ao que apunta (que é o que fai a implementación `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls para punteiros de función
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: O reparto intermedio como uso é necesario para AVR
                // de xeito que o espazo de dirección do punteiro de función de orixe se conserve no punteiro de función final.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: O reparto intermedio como uso é necesario para AVR
                // de xeito que o espazo de dirección do punteiro de función de orixe se conserve no punteiro de función final.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Non hai funcións variadicas con 0 parámetros
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Crea un punteiro en bruto `const` a un lugar, sen crear unha referencia intermedia.
///
/// A creación dunha referencia con `&`/`&mut` só se permite se o punteiro está correctamente aliñado e apunta aos datos inicializados.
/// Para os casos en que eses requisitos non se cumpren, deberíanse usar punteiros en bruto.
/// Non obstante, `&expr as *const _` crea unha referencia antes de lanzala a un punteiro en bruto, e esa referencia está suxeita ás mesmas regras que as demais referencias.
///
/// Esta macro pode crear un punteiro en bruto *sen* primeiro crear unha referencia.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` crearía unha referencia non aliñada e, polo tanto, sería un comportamento indefinido.
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Crea un punteiro en bruto `mut` a un lugar, sen crear unha referencia intermedia.
///
/// A creación dunha referencia con `&`/`&mut` só se permite se o punteiro está correctamente aliñado e apunta aos datos inicializados.
/// Para os casos en que eses requisitos non se cumpren, deberíanse usar punteiros en bruto.
/// Non obstante, `&mut expr as *mut _` crea unha referencia antes de lanzala a un punteiro en bruto, e esa referencia está suxeita ás mesmas regras que as demais referencias.
///
/// Esta macro pode crear un punteiro en bruto *sen* primeiro crear unha referencia.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` crearía unha referencia non aliñada e, polo tanto, sería un comportamento indefinido.
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` obriga a copiar o campo en lugar de crear unha referencia.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}