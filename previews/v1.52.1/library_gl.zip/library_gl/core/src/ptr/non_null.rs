use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` pero non cero e covariante.
///
/// A miúdo isto é o correcto que se emprega cando se constrúen estruturas de datos usando punteiros en bruto, pero ao final é máis perigoso de usar debido ás súas propiedades adicionais.Se non está seguro de se debería usar `NonNull<T>`, simplemente use `*mut T`.
///
/// A diferenza de `*mut T`, o punteiro debe ser sempre nulo, aínda que o punteiro nunca se derreferencia.Isto é así para que as enumeracións poidan usar este valor prohibido como discriminante: `Option<NonNull<T>>` ten o mesmo tamaño que `* mut T`.
/// Non obstante, o punteiro aínda pode colgar se non está referenciado.
///
/// A diferenza de `*mut T`, `NonNull<T>` foi escollido para ser covariante sobre `T`.Isto fai posible usar `NonNull<T>` cando se constrúen tipos de covariantes, pero introduce o risco de insolencia se se usa nun tipo que non debería ser realmente covariante.
/// (A elección contraria tomouse para `*mut T` aínda que tecnicamente a insonoridade só podería ser causada por chamar a funcións inseguras.)
///
/// A covarianza é correcta para abstraccións máis seguras, como `Box`, `Rc`, `Arc`, `Vec` e `LinkedList`.Este é o caso porque proporcionan unha API pública que segue as regras XOR compartidas normais de Rust.
///
/// Se o seu tipo non pode ser covariante con seguridade, debe asegurarse de que contén algún campo adicional para proporcionar invarianza.Moitas veces este campo será un tipo [`PhantomData`] como `PhantomData<Cell<T>>` ou `PhantomData<&'a mut T>`.
///
/// Teña en conta que `NonNull<T>` ten unha instancia `From` para `&T`.Non obstante, isto non modifica o feito de que mutar a través dun (punteiro derivado dunha) referencia compartida é un comportamento indefinido a menos que a mutación ocorra dentro dun [`UnsafeCell<T>`].O mesmo sucede coa creación dunha referencia mutable a partir dunha referencia compartida.
///
/// Ao usar esta instancia `From` sen `UnsafeCell<T>`, é a súa responsabilidade asegurarse de que `as_mut` nunca se chama e que `as_ptr` nunca se usa para a mutación.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` os punteiros non son `Send` porque os datos aos que fan referencia poden estar aliados.
// Nota: esta aplicación non é necesaria, pero debería proporcionar mellores mensaxes de erro.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` os punteiros non son `Sync` porque os datos aos que fan referencia poden estar aliados.
// Nota: esta aplicación non é necesaria, pero debería proporcionar mellores mensaxes de erro.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Crea un novo `NonNull` colgante pero ben aliñado.
    ///
    /// Isto é útil para inicializar tipos que asignan preguiceiramente, como fai `Vec::new`.
    ///
    /// Teña en conta que o valor do punteiro pode representar potencialmente un punteiro válido a un `T`, o que significa que non se debe usar como valor centinela "not yet initialized".
    /// Os tipos que asignan preguiceiramente deben rastrexar a inicialización por outros medios.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SEGURIDADE: mem::align_of() devolve un uso distinto de cero que logo se lanza
        // a un * mut T.
        // Polo tanto, `ptr` non é nulo e respéctanse as condicións para chamar ao new_unchecked().
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Devolve unha referencia compartida ao valor.A diferenza do [`as_ref`], isto non require que se inicialice o valor.
    ///
    /// Para ver a contraparte mutable, vexa [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Ao chamar a este método, ten que asegurarse de que todo o seguinte é certo:
    ///
    /// * O punteiro debe estar correctamente aliñado.
    ///
    /// * Debe ser "dereferencable" no sentido definido en [the module documentation].
    ///
    /// * Debe facer cumprir as regras de aliasing de Rust, xa que a vida útil retornada `'a` é elixida arbitrariamente e non reflicte necesariamente a vida real dos datos.
    ///
    ///   En particular, durante a duración desta vida, a memoria á que apunta o punteiro non debe mutarse (excepto dentro de `UnsafeCell`).
    ///
    /// Isto aplícase aínda que o resultado deste método non se use.
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SEGURIDADE: o interlocutor debe garantir que `self` cumpre todos os requisitos
        // requisitos para unha referencia.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Devolve referencias únicas ao valor.A diferenza do [`as_mut`], isto non require que se inicialice o valor.
    ///
    /// Para a contraparte compartida, consulte [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Ao chamar a este método, ten que asegurarse de que todo o seguinte é certo:
    ///
    /// * O punteiro debe estar correctamente aliñado.
    ///
    /// * Debe ser "dereferencable" no sentido definido en [the module documentation].
    ///
    /// * Debe facer cumprir as regras de aliasing de Rust, xa que a vida útil retornada `'a` é elixida arbitrariamente e non reflicte necesariamente a vida real dos datos.
    ///
    ///   En particular, durante a duración desta vida, a memoria á que apunta o punteiro non debe acceder (lida ou escrita) a través de ningún outro punteiro.
    ///
    /// Isto aplícase aínda que o resultado deste método non se use.
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SEGURIDADE: o interlocutor debe garantir que `self` cumpre todos os requisitos
        // requisitos para unha referencia.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Crea un novo `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` debe ser non nulo.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SEGURIDADE: o interlocutor debe garantir que `ptr` non é nulo.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Crea un novo `NonNull` se `ptr` non é nulo.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SEGURIDADE: o punteiro xa está marcado e non é nulo
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Realiza a mesma funcionalidade que [`std::ptr::from_raw_parts`], excepto que se devolve un punteiro `NonNull`, en oposición a un punteiro `*const` en bruto.
    ///
    ///
    /// Consulte a documentación de [`std::ptr::from_raw_parts`] para máis detalles.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SEGURIDADE: o resultado de `ptr::from::raw_parts_mut` non é nulo porque `data_address` é.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Descompoña un punteiro (posiblemente ancho) en compoñentes de enderezos e metadatos.
    ///
    /// O punteiro pode reconstruírse posteriormente con [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Adquire o punteiro `*mut` subxacente.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Devolve unha referencia compartida ao valor.Se o valor pode non ser inicializado, no seu lugar debe usarse [`as_uninit_ref`].
    ///
    /// Para ver a contraparte mutable, vexa [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Ao chamar a este método, ten que asegurarse de que todo o seguinte é certo:
    ///
    /// * O punteiro debe estar correctamente aliñado.
    ///
    /// * Debe ser "dereferencable" no sentido definido en [the module documentation].
    ///
    /// * O punteiro debe apuntar a unha instancia inicializada de `T`.
    ///
    /// * Debe facer cumprir as regras de aliasing de Rust, xa que a vida útil retornada `'a` é elixida arbitrariamente e non reflicte necesariamente a vida real dos datos.
    ///
    ///   En particular, durante a duración desta vida, a memoria á que apunta o punteiro non debe mutarse (excepto dentro de `UnsafeCell`).
    ///
    /// Isto aplícase aínda que o resultado deste método non se use.
    /// (A parte sobre a inicialización aínda non está completamente decidida, pero ata que o faga, o único enfoque seguro é asegurarse de que se inicialicen.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SEGURIDADE: o interlocutor debe garantir que `self` cumpre todos os requisitos
        // requisitos para unha referencia.
        unsafe { &*self.as_ptr() }
    }

    /// Devolve unha referencia única ao valor.Se o valor pode non ser inicializado, no seu lugar debe usarse [`as_uninit_mut`].
    ///
    /// Para a contraparte compartida, consulte [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Ao chamar a este método, ten que asegurarse de que todo o seguinte é certo:
    ///
    /// * O punteiro debe estar correctamente aliñado.
    ///
    /// * Debe ser "dereferencable" no sentido definido en [the module documentation].
    ///
    /// * O punteiro debe apuntar a unha instancia inicializada de `T`.
    ///
    /// * Debe facer cumprir as regras de aliasing de Rust, xa que a vida útil retornada `'a` é elixida arbitrariamente e non reflicte necesariamente a vida real dos datos.
    ///
    ///   En particular, durante a duración desta vida, a memoria á que apunta o punteiro non debe acceder (lida ou escrita) a través de ningún outro punteiro.
    ///
    /// Isto aplícase aínda que o resultado deste método non se use.
    /// (A parte sobre a inicialización aínda non está completamente decidida, pero ata que o faga, o único enfoque seguro é asegurarse de que se inicialicen.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SEGURIDADE: o interlocutor debe garantir que `self` cumpre todos os requisitos
        // requisitos para unha referencia mutable.
        unsafe { &mut *self.as_ptr() }
    }

    /// Lánzase a un punteiro doutro tipo.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SEGURIDADE: `self` é un punteiro `NonNull` que necesariamente non é nulo
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Crea unha porción en bruto non nula a partir dun punteiro fino e unha lonxitude.
    ///
    /// O argumento `len` é o número de **elementos**, non o número de bytes.
    ///
    /// Esta función é segura, pero a desferenciación do valor devolto non é segura.
    /// Consulte a documentación de [`slice::from_raw_parts`] para os requisitos de seguridade do sector.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // cree un punteiro de corte cando comece cun punteiro ao primeiro elemento
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Teña en conta que este exemplo demostra artificialmente o uso deste método, pero `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SEGURIDADE: `data` é un punteiro `NonNull` que necesariamente non é nulo
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Devolve a lonxitude dunha porción en bruto non nula.
    ///
    /// O valor devolto é o número de **elementos**, non o número de bytes.
    ///
    /// Esta función é segura, incluso cando a porción en bruto non nula non se pode referenciar a unha porción porque o punteiro non ten un enderezo válido.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Devolve un punteiro que non é nulo ao buffer da porción.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SEGURIDADE: sabemos que `self` non é nulo.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Devolve un punteiro en bruto ao búfer da porción.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Devolve unha referencia compartida a unha porción de valores posiblemente non inicializados.A diferenza do [`as_ref`], isto non require que se inicialice o valor.
    ///
    /// Para ver a contraparte mutable, vexa [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Ao chamar a este método, ten que asegurarse de que todo o seguinte é certo:
    ///
    /// * O punteiro debe ser [valid] para lecturas para moitos bytes `ptr.len() * mem::size_of::<T>()` e debe estar correctamente aliñado.Isto significa en particular:
    ///
    ///     * Todo o intervalo de memoria desta porción debe estar contido nun único obxecto asignado.
    ///       As franxas nunca poden abarcar varios obxectos asignados.
    ///
    ///     * O punteiro debe estar aliñado incluso para franxas de lonxitude cero.
    ///     Unha das razóns para iso é que as optimizacións de deseño enum poden depender de que as referencias (incluídas as franxas de calquera lonxitude) estean aliñadas e non nulas para distinguilas doutros datos.
    ///
    ///     Podes obter un punteiro que se poida usar como `data` para franxas de lonxitude cero usando [`NonNull::dangling()`].
    ///
    /// * O tamaño total `ptr.len() * mem::size_of::<T>()` da porción non debe ser maior que `isize::MAX`.
    ///   Consulte a documentación de seguridade de [`pointer::offset`].
    ///
    /// * Debe facer cumprir as regras de aliasing de Rust, xa que a vida útil retornada `'a` é elixida arbitrariamente e non reflicte necesariamente a vida real dos datos.
    ///   En particular, durante a duración desta vida, a memoria á que apunta o punteiro non debe mutarse (excepto dentro de `UnsafeCell`).
    ///
    /// Isto aplícase aínda que o resultado deste método non se use.
    ///
    /// Vexa tamén [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Devolve unha referencia única a unha porción de valores posiblemente non inicializados.A diferenza do [`as_mut`], isto non require que se inicialice o valor.
    ///
    /// Para a contraparte compartida, consulte [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Ao chamar a este método, ten que asegurarse de que todo o seguinte é certo:
    ///
    /// * O punteiro debe ser [valid] para ler e escribir para `ptr.len() * mem::size_of::<T>()` moitos bytes e debe estar correctamente aliñado.Isto significa en particular:
    ///
    ///     * Todo o intervalo de memoria desta porción debe estar contido nun único obxecto asignado.
    ///       As franxas nunca poden abarcar varios obxectos asignados.
    ///
    ///     * O punteiro debe estar aliñado incluso para franxas de lonxitude cero.
    ///     Unha das razóns para iso é que as optimizacións de deseño enum poden depender de que as referencias (incluídas as franxas de calquera lonxitude) estean aliñadas e non nulas para distinguilas doutros datos.
    ///
    ///     Podes obter un punteiro que se poida usar como `data` para franxas de lonxitude cero usando [`NonNull::dangling()`].
    ///
    /// * O tamaño total `ptr.len() * mem::size_of::<T>()` da porción non debe ser maior que `isize::MAX`.
    ///   Consulte a documentación de seguridade de [`pointer::offset`].
    ///
    /// * Debe facer cumprir as regras de aliasing de Rust, xa que a vida útil retornada `'a` é elixida arbitrariamente e non reflicte necesariamente a vida real dos datos.
    ///   En particular, durante a duración desta vida, a memoria á que apunta o punteiro non debe acceder (lida ou escrita) a través de ningún outro punteiro.
    ///
    /// Isto aplícase aínda que o resultado deste método non se use.
    ///
    /// Vexa tamén [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Isto é seguro xa que `memory` é válido para lecturas e escrituras para moitos bytes de `memory.len()`.
    /// // Ten en conta que aquí non está permitido chamar ao `memory.as_mut()` xa que o contido pode non ser inicializado.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Devolve un punteiro en bruto a un elemento ou subslice, sen facer comprobación de límites.
    ///
    /// Chamar a este método cun índice fóra dos límites ou cando `self` non se pode referenciar é *[comportamento indefinido]* aínda que non se use o punteiro resultante.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SEGURIDADE: o interlocutor garante que `self` é desfase de referencia e `index` está dentro dos límites.
        // Como consecuencia, o punteiro resultante non pode ser NULO.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SEGURIDADE: Un punteiro único non pode ser nulo, polo que as condicións para
        // new_unchecked() son respectados.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SEGURIDADE: unha referencia mutable non pode ser nula.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SEGURIDADE: unha referencia non pode ser nula, polo que as condicións para
        // new_unchecked() son respectados.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}