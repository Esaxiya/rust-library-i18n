use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Un envoltorio ao redor dun `*mut T` bruto non nulo que indica que o posuidor deste envoltorio é o propietario do referente.
/// Útil para construír abstraccións como `Box<T>`, `Vec<T>`, `String` e `HashMap<K, V>`.
///
/// A diferenza de `*mut T`, `Unique<T>` compórtase como "as if" porque era unha instancia de `T`.
/// Implementa `Send`/`Sync` se `T` é `Send`/`Sync`.
/// Tamén implica o tipo de fortes garantías de aliasing que pode esperar unha instancia de `T`:
/// o referente do punteiro non se debería modificar sen un camiño único ao seu propietario Unique.
///
/// Se non está seguro de se é correcto usar `Unique` para os seus fins, considere o uso de `NonNull`, que ten unha semántica máis débil.
///
///
/// A diferenza de `*mut T`, o punteiro non debe ser sempre nulo, aínda que o punteiro nunca se derreferencia.
/// Isto é para que as enumeracións poidan usar este valor prohibido como discriminante: `Option<Unique<T>>` ten o mesmo tamaño que `Unique<T>`.
/// Non obstante, o punteiro aínda pode colgar se non está referenciado.
///
/// A diferenza de `*mut T`, `Unique<T>` é covariante sobre `T`.
/// Isto sempre debe ser correcto para calquera tipo que cumpra os requisitos de aliasing de Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: este marcador non ten consecuencias para a varianza, pero é necesario
    // para que Dropck comprenda que loxicamente posuímos un `T`.
    //
    // Para máis detalles, vexa:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` os punteiros son `Send` se `T` é `Send` porque os datos aos que fan referencia non teñen alias.
/// Teña en conta que este sistema de tipo non impón esta invariante de alias.a abstracción que usa o `Unique` debe facela valer.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` os punteiros son `Sync` se `T` é `Sync` porque os datos aos que fan referencia non teñen alias.
/// Teña en conta que este sistema de tipo non impón esta invariante de alias.a abstracción que usa o `Unique` debe facela valer.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Crea un novo `Unique` colgante pero ben aliñado.
    ///
    /// Isto é útil para inicializar tipos que asignan preguiceiramente, como fai `Vec::new`.
    ///
    /// Teña en conta que o valor do punteiro pode representar potencialmente un punteiro válido a un `T`, o que significa que non se debe usar como valor centinela "not yet initialized".
    /// Os tipos que asignan preguiceiramente deben rastrexar a inicialización por outros medios.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SEGURIDADE: mem::align_of() devolve un punteiro válido e non nulo.O
        // respéctanse as condicións para chamar ao new_unchecked().
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Crea un novo `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` debe ser non nulo.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SEGURIDADE: o interlocutor debe garantir que `ptr` non é nulo.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Crea un novo `Unique` se `ptr` non é nulo.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SEGURIDADE: o punteiro xa se comprobou e non é nulo.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Adquire o punteiro `*mut` subxacente.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dereferencia do contido.
    ///
    /// A vida resultante está limitada a si mesma polo que se comporta como "as if", realmente foi unha instancia de T que se está tomando prestada.
    /// Se se precisa unha vida máis longa de (unbound), use `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SEGURIDADE: o interlocutor debe garantir que `self` cumpre todos os requisitos
        // requisitos para unha referencia.
        unsafe { &*self.as_ptr() }
    }

    /// Dereferencia mutua do contido.
    ///
    /// A vida resultante está limitada a si mesma polo que se comporta como "as if", realmente foi unha instancia de T que se está tomando prestada.
    /// Se se precisa unha vida máis longa de (unbound), use `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SEGURIDADE: o interlocutor debe garantir que `self` cumpre todos os requisitos
        // requisitos para unha referencia mutable.
        unsafe { &mut *self.as_ptr() }
    }

    /// Lánzase a un punteiro doutro tipo.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SEGURIDADE: Unique::new_unchecked() crea un novo único e precisa
        // o punteiro indicado non será nulo.
        // Dado que estamos pasando un auto como punteiro, non pode ser nulo.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SEGURIDADE: unha referencia mutable non pode ser nula
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}