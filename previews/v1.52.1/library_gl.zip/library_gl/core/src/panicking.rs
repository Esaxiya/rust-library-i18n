//! Soporte de Panic para libcore
//!
//! A biblioteca principal non pode definir o pánico, pero si * declara o pánico.
//! Isto significa que as funcións dentro de libcore están autorizadas a panic, pero para ser útil un crate ascendente debe definir o pánico para que o use libcore.
//! A interface actual para entrar en pánico é:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Esta definición permite entrar en pánico con calquera mensaxe xeral, pero non permite fallar cun valor `Box<Any>`.
//! (`PanicInfo` só contén un `&(dyn Any + Send)`, para o que cubrimos un valor ficticio en `PanicInfo: : internal_constructor`.) A razón disto é que non se pode asignar libcore.
//!
//!
//! Este módulo contén algunhas outras funcións de pánico, pero estes son só os elementos necesarios para o compilador.Todos os panics están canalizados a través desta única función.
//! O símbolo real declárase a través do atributo `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// A implementación subxacente da macro `panic!` de libcore cando non se usa ningún formato.
#[cold]
// nunca en liña a menos que panic_immediate_abort para evitar o inchazo de código nos sitios de chamadas o máximo posible
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // necesarios por codegen para panic no overflow e outros terminadores MIR `Assert`
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Use Arguments::new_v1 en lugar de format_args! ("{}", Expr) para reducir potencialmente o gasto en tamaño.
    // O formato_args!a macro usa o Display trait de str para escribir expr, que chama Formatter::pad, que debe acomodar truncamento de cadeas e recheo (aínda que aquí non se usa ningún).
    //
    // Usar Arguments::new_v1 pode permitir que o compilador omita Formatter::pad do binario de saída, aforrando ata algúns kilobytes.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // necesario para panics avaliado constantemente
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // necesitado por codegen para panic no acceso OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// A implementación subxacente da macro `panic!` de libcore cando se usa o formato.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // NOTA Esta función nunca cruza o límite FFI;é unha chamada Rust-to-Rust que se resolve coa función `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SEGURIDADE: `panic_impl` defínese no código Rust seguro e, polo tanto, é seguro chamalo.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Función interna para macros `assert_eq!` e `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}