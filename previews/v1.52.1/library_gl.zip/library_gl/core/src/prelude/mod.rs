//! O libcore prelude
//!
//! Este módulo está pensado para usuarios de libcore que non ligan tamén a libstd.
//! Este módulo importase de xeito predeterminado cando se usa `#![no_std]` do mesmo xeito que o prelude da biblioteca estándar.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// A versión 2015 do núcleo prelude.
///
/// Vexa o [module-level documentation](self) para obter máis información.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// A versión 2018 do núcleo prelude.
///
/// Vexa o [module-level documentation](self) para obter máis información.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// A versión 2021 do núcleo prelude.
///
/// Vexa o [module-level documentation](self) para obter máis información.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Engade máis cousas.
}