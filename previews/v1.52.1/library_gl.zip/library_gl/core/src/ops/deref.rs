/// Utilízase para operacións de desreferenciación inmutables, como `*v`.
///
/// Ademais de usarse para operacións de dereferenciación explícitas co operador (unary) `*` en contextos inmutables, o compilador tamén usa implícitamente `Deref` en moitas circunstancias.
/// Este mecanismo chámase ['`Deref` coercion'][more].
/// En contextos mudables, úsase [`DerefMut`].
///
/// A implementación de `Deref` para punteiros intelixentes facilita o acceso aos datos que están detrás deles, razón pola que implementan `Deref`.
/// Por outra banda, as regras relativas a `Deref` e [`DerefMut`] foron deseñadas especificamente para acomodar punteiros intelixentes.
/// Debido a isto,**"Deref" só debería implementarse para punteiros intelixentes** para evitar confusións.
///
/// Por razóns similares,**este trait nunca debería fallar**.O fallo durante a desferenciación pode ser extremadamente confuso cando se invoca `Deref` de xeito implícito.
///
/// # Máis información sobre a coacción `Deref`
///
/// Se `T` implementa `Deref<Target = U>` e `x` é un valor do tipo `T`, entón:
///
/// * En contextos inmutables, `*x` (onde `T` non é nin unha referencia nin un punteiro en bruto) é equivalente a `* Deref::deref(&x)`.
/// * Os valores do tipo `&T` están coaccionados aos valores do tipo `&U`
/// * `T` implícitamente implementa todos os métodos (immutable) do tipo `U`.
///
/// Para obter máis detalles, visite [the chapter in *The Rust Programming Language*][book], así como as seccións de referencia en [the dereference operator][ref-deref-op], [method resolution] e [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Unha estrutura cun único campo ao que se pode acceder desferenciando a estrutura.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// O tipo resultante despois da desreferenciación.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Diferencia o valor.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Úsase para operacións de desferenciación mutables, como en `*v = 1;`.
///
/// Ademais de usarse para operacións de dereferenciación explícitas co operador (unary) `*` en contextos mutables, o compilador tamén usa implícitamente `DerefMut` en moitas circunstancias.
/// Este mecanismo chámase ['`Deref` coercion'][more].
/// En contextos inmutables, úsase [`Deref`].
///
/// A implementación de `DerefMut` para punteiros intelixentes fai que a mutación dos datos que hai detrás sexa conveniente, por iso implementan `DerefMut`.
/// Por outra banda, as regras relativas a [`Deref`] e `DerefMut` foron deseñadas especificamente para acomodar punteiros intelixentes.
/// Debido a isto,**"DerefMut" só debería implementarse para punteiros intelixentes** para evitar confusións.
///
/// Por razóns similares,**este trait nunca debería fallar**.O fallo durante a desferenciación pode ser extremadamente confuso cando se invoca `DerefMut` de xeito implícito.
///
/// # Máis información sobre a coacción `Deref`
///
/// Se `T` implementa `DerefMut<Target = U>` e `x` é un valor do tipo `T`, entón:
///
/// * En contextos mutables, `*x` (onde `T` non é nin unha referencia nin un punteiro en bruto) é equivalente a `* DerefMut::deref_mut(&mut x)`.
/// * Os valores do tipo `&mut T` están coaccionados aos valores do tipo `&mut U`
/// * `T` implícitamente implementa todos os métodos (mutable) do tipo `U`.
///
/// Para obter máis detalles, visite [the chapter in *The Rust Programming Language*][book], así como as seccións de referencia en [the dereference operator][ref-deref-op], [method resolution] e [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Unha estrutura cun único campo que se pode modificar desferenciando a estrutura.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Desferencia mutuamente o valor.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Indica que se pode usar unha estrutura como receptor de método, sen a característica `arbitrary_self_types`.
///
/// Isto é implementado por tipos de punteiros stdlib como `Box<T>`, `Rc<T>`, `&T` e `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}