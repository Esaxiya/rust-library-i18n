/// A versión do operador de chamada que leva un receptor inmutable.
///
/// As instancias de `Fn` pódense chamar repetidamente sen estado mutante.
///
/// *Non se debe confundir este trait (`Fn`) con [function pointers] (`fn`).*
///
/// `Fn` implántase automaticamente mediante peches que só toman referencias inmutables a variables capturadas ou non capturan nada de nada, así como (safe) [function pointers] (con algunhas advertencias, consulte a súa documentación para máis detalles).
///
/// Ademais, para calquera tipo `F` que implante `Fn`, `&F` tamén implementa `Fn`.
///
/// Dado que [`FnMut`] e [`FnOnce`] son supertratos de `Fn`, calquera instancia de `Fn` pode usarse como parámetro onde se espera un [`FnMut`] ou [`FnOnce`].
///
/// Use `Fn` como enlace cando desexe aceptar un parámetro de tipo funcional e necesite chamalo repetidamente e sen estado mutante (por exemplo, cando o chame simultaneamente).
/// Se non precisa esixencias tan estritas, use [`FnMut`] ou [`FnOnce`] como límites.
///
/// Vexa o [chapter on closures in *The Rust Programming Language*][book] para obter máis información sobre este tema.
///
/// Tamén hai que destacar a sintaxe especial para `Fn` traits (por exemplo
/// `Fn(usize, bool) -> usar`).Os interesados nos detalles técnicos disto poden consultar [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Chamando a un peche
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Usando un parámetro `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // para que regex poida confiar nese `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Realiza a operación de chamada.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// A versión do operador de chamada que leva un receptor mutable.
///
/// As instancias de `FnMut` pódense chamar repetidamente e poden mutar de estado.
///
/// `FnMut` impleméntase automaticamente mediante peches que toman referencias mutables a variables capturadas, así como todos os tipos que implementan [`Fn`], por exemplo, (safe) [function pointers] (xa que `FnMut` é un supertrato de [`Fn`]).
/// Ademais, para calquera tipo `F` que implante `FnMut`, `&mut F` tamén implementa `FnMut`.
///
/// Dado que [`FnOnce`] é un superestrato de `FnMut`, calquera instancia de `FnMut` pode usarse onde se espera un [`FnOnce`], e dado que [`Fn`] é un subtrito de `FnMut`, calquera instancia de [`Fn`] pode usarse onde se espera `FnMut`.
///
/// Use `FnMut` como enlace cando desexe aceptar un parámetro de tipo funcional e necesite chamalo repetidamente, mentres lle permite mutar o estado.
/// Se non desexa que o parámetro mute o estado, use [`Fn`] como límite;se non precisa chamalo repetidamente, use [`FnOnce`].
///
/// Vexa o [chapter on closures in *The Rust Programming Language*][book] para obter máis información sobre este tema.
///
/// Tamén hai que destacar a sintaxe especial para `Fn` traits (por exemplo
/// `Fn(usize, bool) -> usar`).Os interesados nos detalles técnicos disto poden consultar [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Chamando a un peche de captura mutua
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Usando un parámetro `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // para que regex poida confiar nese `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Realiza a operación de chamada.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// A versión do operador de chamada que recibe un receptor por valor.
///
/// Pódense chamar ás instancias de `FnOnce`, pero poden non ser chamables varias veces.Por iso, se o único que se sabe dun tipo é que implementa `FnOnce`, só se pode chamar unha vez.
///
/// `FnOnce` implántase automaticamente mediante peches que poden consumir variables capturadas, así como todos os tipos que implementan [`FnMut`], por exemplo, (safe) [function pointers] (xa que `FnOnce` é un superestrato de [`FnMut`]).
///
///
/// Dado que [`Fn`] e [`FnMut`] son subtraitos de `FnOnce`, pódese usar calquera instancia de [`Fn`] ou [`FnMut`] onde se espera un `FnOnce`.
///
/// Use `FnOnce` como enlace cando queira aceptar un parámetro de tipo funcional e só necesite chamalo unha vez.
/// Se precisa chamar ao parámetro repetidamente, use [`FnMut`] como enlace;se tamén o necesitas para non mutar o estado, usa [`Fn`].
///
/// Vexa o [chapter on closures in *The Rust Programming Language*][book] para obter máis información sobre este tema.
///
/// Tamén hai que destacar a sintaxe especial para `Fn` traits (por exemplo
/// `Fn(usize, bool) -> usar`).Os interesados nos detalles técnicos disto poden consultar [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Usando un parámetro `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` consume as súas variables capturadas, polo que non se pode executar máis dunha vez.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Se tenta invocar de novo `func()`, producirase un erro `use of moved value` para `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` xa non se pode invocar neste momento
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // para que regex poida confiar nese `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// O tipo devolto despois do operador de chamada.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Realiza a operación de chamada.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}