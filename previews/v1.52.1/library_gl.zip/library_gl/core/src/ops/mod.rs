//! Operadores sobrecargables.
//!
//! A implementación destes traits permítelle sobrecargar certos operadores.
//!
//! Algúns destes traits son importados polo prelude, polo que están dispoñibles en todos os programas Rust.Só se poden sobrecargar os operadores apoiados por traits.
//! Por exemplo, o operador de adición (`+`) pode ser sobrecargado a través do [`Add`] trait, pero dado que o operador de asignación (`=`) non ten trait de respaldo, non hai forma de sobrecargar a súa semántica.
//! Ademais, este módulo non proporciona ningún mecanismo para crear novos operadores.
//! Se se requiren sobrecargas sen trazos ou operadores personalizados, debería mirar cara ás macros ou os complementos do compilador para ampliar a sintaxe de Rust.
//!
//! As implementacións do operador traits non deben ser sorprendentes nos seus respectivos contextos, tendo en conta os seus significados habituais e [operator precedence].
//! Por exemplo, cando se implementa [`Mul`], a operación debería ter algunha semellanza coa multiplicación (e compartir as propiedades esperadas como a asociatividade).
//!
//! Teña en conta que os operadores `&&` e `||` cortocircuítan, é dicir, só avalían o seu segundo operando se contribúe ao resultado.Dado que este comportamento non é aplicable por traits, `&&` e `||` non son compatibles como operadores con sobrecarga.
//!
//! Moitos dos operadores toman os seus operandos por valor.En contextos non xenéricos que inclúen tipos incorporados, normalmente non é un problema.
//! Non obstante, o uso destes operadores en código xenérico require certa atención se hai que reutilizar os valores en lugar de deixar que os operadores os consuman.Unha opción é empregar ocasionalmente [`clone`].
//! Outra opción é confiar nos tipos implicados que proporcionan implementacións adicionais de operador para referencias.
//! Por exemplo, para un tipo `T` definido polo usuario que se supón que admite a adición, probablemente sexa unha boa idea que tanto `T` como `&T` implementen o traits [`Add<T>`][`Add`] e [`Add<&T>`][`Add`] para que se poida escribir código xenérico sen unha clonación innecesaria.
//!
//!
//! # Examples
//!
//! Este exemplo crea unha estrutura `Point` que implementa [`Add`] e [`Sub`] e, a continuación, demostra sumar e restar dous `Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Vexa a documentación de cada trait para obter un exemplo de implementación.
//!
//! [`Fn`], [`FnMut`] e [`FnOnce`] traits implementanse por tipos que se poden invocar como funcións.Teña en conta que [`Fn`] leva `&self`, [`FnMut`] leva `&mut self` e [`FnOnce`] leva `self`.
//! Correspóndense cos tres tipos de métodos que se poden invocar nunha instancia: chamada por referencia, chamada por referencia mutable e chamada por valor.
//! O uso máis común destes traits é actuar como límites para funcións de nivel superior que toman funcións ou peches como argumentos.
//!
//! Tomar un [`Fn`] como parámetro:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Tomar un [`FnMut`] como parámetro:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Tomar un [`FnOnce`] como parámetro:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` consume as súas variables capturadas, polo que non se pode executar máis dunha vez
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Se tenta invocar de novo `func()`, producirase un erro `use of moved value` para `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` xa non se pode invocar neste momento
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;