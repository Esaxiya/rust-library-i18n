/// Un trait para personalizar o comportamento do operador `?`.
///
/// Un tipo que implementa `Try` é aquel que ten un xeito canónico de velo en termos dunha dicotomía success/failure.
/// Este trait permite extraer eses valores de éxito ou fracaso dunha instancia existente e crear unha nova instancia a partir dun valor de éxito ou fracaso.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// O tipo deste valor cando se ve con éxito.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// O tipo deste valor cando se ve como fallou.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Aplica o operador "?".Un retorno de `Ok(t)` significa que a execución debería continuar normalmente e o resultado de `?` é o valor `t`.
    /// A devolución de `Err(e)` significa que a execución debería branch ao `catch` máis íntimo que o encerra ou volver da función.
    ///
    /// Se se devolve un resultado `Err(e)`, o valor `e` será "wrapped" no tipo de retorno do ámbito que inclúe (que debe implementar `Try`).
    ///
    /// En concreto, devólvese o valor `X::from_error(From::from(e))`, onde `X` é o tipo de devolución da función que inclúe.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Axuste un valor de erro para construír o resultado composto.
    /// Por exemplo, `Result::Err(x)` e `Result::from_error(x)` son equivalentes.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Enrole un valor OK para construír o resultado composto.
    /// Por exemplo, `Result::Ok(x)` e `Result::from_ok(x)` son equivalentes.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}