use crate::marker::Unsize;

/// Trait que indica que se trata dun punteiro ou dun envoltorio para un, onde se pode facer o tamaño no punto.
///
/// Consulte [DST coercion RFC][dst-coerce] e [the nomicon entry on coercion][nomicon-coerce] para obter máis detalles.
///
/// Para os tipos de punteiros integrados, os punteiros a `T` coaccionarán a punteiros a `U` se `T: Unsize<U>` ao converter dun punteiro fino a un punteiro gordo.
///
/// Para os tipos personalizados, a coacción aquí funciona coaccionando `Foo<T>` a `Foo<U>` sempre que exista un impl de `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Dita aplicación só se pode escribir se `Foo<T>` só ten un único campo de datos non fantasma que inclúe `T`.
/// Se o tipo dese campo é `Bar<T>`, debe existir unha implementación de `CoerceUnsized<Bar<U>> for Bar<T>`.
/// A coacción funcionará coaccionando o campo `Bar<T>` en `Bar<U>` e enchendo o resto dos campos de `Foo<T>` para crear un `Foo<U>`.
/// Isto efectivamente profundizará nun campo de punteiro e coaccionalo.
///
/// Xeralmente, para os punteiros intelixentes implementará `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, cun `?Sized` opcional enlazado no propio `T`.
/// Para tipos de envoltorios que incorporan directamente `T` como `Cell<T>` e `RefCell<T>`, pode implementar directamente `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Isto permitirá que funcionen coaccións de tipos como `Cell<Box<T>>`.
///
/// [`Unsize`][unsize] úsase para marcar tipos que poden ser coaccionados a DST se están detrás de punteiros.É implementado automaticamente polo compilador.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Utilízase para a seguridade de obxectos, para comprobar que se pode enviar o tipo de receptor dun método.
///
/// Un exemplo de implementación de trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}