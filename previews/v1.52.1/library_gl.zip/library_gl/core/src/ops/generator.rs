use crate::marker::Unpin;
use crate::pin::Pin;

/// O resultado dunha reanudación do xerador.
///
/// Este número devólvese a partir do método `Generator::resume` e indica os posibles valores de retorno dun xerador.
/// Actualmente isto corresponde a un punto de suspensión (`Yielded`) ou a un punto de finalización (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// O xerador suspendido cun valor.
    ///
    /// Este estado indica que un xerador foi suspendido e normalmente corresponde a unha instrución `yield`.
    /// O valor proporcionado nesta variante corresponde á expresión pasada a `yield` e permite aos xeradores proporcionar un valor cada vez que producen.
    ///
    ///
    Yielded(Y),

    /// O xerador completouse cun valor de retorno.
    ///
    /// Este estado indica que un xerador rematou a execución co valor proporcionado.
    /// Unha vez que un xerador devolveu `Complete`, considérase un erro de programador chamar de novo a `resume`.
    ///
    Complete(R),
}

/// O trait implementado por tipos de xeradores integrados.
///
/// Os xeradores, tamén chamados coroutinas, son actualmente unha característica de linguaxe experimental en Rust.
/// Os engadidos nos xeradores [RFC 2033] están destinados actualmente a proporcionar principalmente un bloque de construción para a sintaxe async/await, pero probablemente tamén se estendan a proporcionar unha definición ergonómica para os iteradores e outras primitivas.
///
///
/// A sintaxe e a semántica para os xeradores son inestables e requirirán unha RFC adicional para a estabilización.Non obstante, neste momento, a sintaxe é similar ao peche:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Pódese atopar máis documentación sobre xeradores no libro inestable.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// O tipo de valor que produce este xerador.
    ///
    /// Este tipo asociado corresponde á expresión `yield` e aos valores que se permiten devolver cada vez que cede un xerador.
    ///
    /// Por exemplo, un iterador como xerador probablemente tería este tipo como `T`, sendo o tipo iterado.
    ///
    type Yield;

    /// O tipo de valor que devolve este xerador.
    ///
    /// Isto corresponde ao tipo devolto dun xerador cunha instrución `return` ou implicitamente como a última expresión dun literal do xerador.
    /// Por exemplo, futures usaría isto como `Result<T, E>` xa que representa un future completado.
    ///
    ///
    type Return;

    /// Retoma a execución deste xerador.
    ///
    /// Esta función retomará a execución do xerador ou iniciará a execución se aínda non o fixo.
    /// Esta chamada volverá ao último punto de suspensión do xerador, retomando a execución a partir do último `yield`.
    /// O xerador seguirá executándose ata que cede ou volva, momento no que devolverá esta función.
    ///
    /// # Valor de devolución
    ///
    /// O número `GeneratorState` devolto desta función indica en que estado se atopa o xerador ao regresar.
    /// Se se devolve a variante `Yielded`, o xerador alcanzou un punto de suspensión e obtívose un valor.
    /// Os xeradores neste estado están dispoñibles para a súa continuación nun momento posterior.
    ///
    /// Se se devolve `Complete`, o xerador rematou completamente co valor proporcionado.Non é válido que o xerador se retome de novo.
    ///
    /// # Panics
    ///
    /// Esta función pode panic se se chama despois de que a variante `Complete` fose devolta con anterioridade.
    /// Mentres que os literales do xerador no idioma están garantidos a panic cando se retoma despois de `Complete`, isto non está garantido para todas as implementacións do `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}