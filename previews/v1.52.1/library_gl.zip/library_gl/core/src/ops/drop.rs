/// Código personalizado dentro do destructor.
///
/// Cando xa non se precise un valor, Rust executará un "destructor" nese valor.
/// A forma máis común de que un valor xa non é necesario é cando sae do alcance.É posible que os destrutores funcionen noutras circunstancias, pero centrarémonos no alcance dos exemplos aquí.
/// Para coñecer algúns deses outros casos, consulte a sección [the reference] sobre destrutores.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Este destructor consta de dous compoñentes:
/// - Unha chamada a `Drop::drop` por ese valor, se este `Drop` especial trait está implementado para o seu tipo.
/// - O "drop glue" xerado automaticamente que chama recursivamente aos destrutores de todos os campos deste valor.
///
/// Como Rust chama automaticamente aos destrutores de todos os campos contidos, non ten que implementar `Drop` na maioría dos casos.
/// Pero hai algúns casos nos que é útil, por exemplo para tipos que xestionan directamente un recurso.
/// Ese recurso pode ser memoria, pode ser un descriptor de ficheiros, pode ser un socket de rede.
/// Unha vez que non se vaia utilizar un valor dese tipo, debería "clean up" o seu recurso liberando a memoria ou pechando o ficheiro ou o socket.
/// Este é o traballo dun destructor e, polo tanto, o traballo de `Drop::drop`.
///
/// ## Examples
///
/// Para ver os destrutores en acción, botemos unha ollada ao seguinte programa:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust primeiro chamará a `Drop::drop` para `_x` e despois para `_x.one` e `_x.two`, o que significa que executando isto imprimirase
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Mesmo se eliminamos a implementación de `Drop` para `HasTwoDrop`, os destrutores dos seus campos aínda se chaman.
/// Isto resultaría en
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Non podes chamar ao `Drop::drop` ti mesmo
///
/// Debido a que `Drop::drop` se usa para limpar un valor, pode ser perigoso usar este valor despois de que se chame ao método.
/// Como `Drop::drop` non se fai propietario da súa entrada, Rust evita o mal uso ao non permitir que chame directamente a `Drop::drop`.
///
/// Noutras palabras, se tentase chamar explícitamente ao `Drop::drop` no exemplo anterior, obtería un erro do compilador.
///
/// Se desexa chamar explícitamente ao destructor dun valor, pódese usar [`mem::drop`].
///
/// [`mem::drop`]: drop
///
/// ## Solicitude de pedido
///
/// Cal das nosas dúas `HasDrop` cae primeiro?Para as estruturas, é a mesma orde que se declaran: primeiro `one` e logo `two`.
/// Se desexa probalo vostede mesmo, pode modificar `HasDrop` anterior para conter algúns datos, como un número enteiro, e despois usalo no `println!` dentro de `Drop`.
/// Este comportamento está garantido pola linguaxe.
///
/// A diferenza das estruturas, as variables locais caen en orde inversa:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Isto imprimirase
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Consulte [the reference] para ver as regras completas.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` e `Drop` son exclusivos
///
/// Non pode implementar [`Copy`] e `Drop` no mesmo tipo.Os tipos `Copy` son duplicados implícitamente polo compilador, o que fai moi difícil predicir cando e con que frecuencia se executarán os destrutores.
///
/// Polo tanto, estes tipos non poden ter destrutores.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Executa o destructor para este tipo.
    ///
    /// Este método chámase implícitamente cando o valor sae do alcance e non se pode chamar explícitamente (trátase dun erro do compilador [E0040]).
    /// Non obstante, a función [`mem::drop`] no prelude pode usarse para chamar á implementación `Drop` do argumento.
    ///
    /// Cando se chamou a este método, `self` aínda non foi deslocalizado.
    /// Iso só ocorre despois de que remate o método.
    /// Se este non fose o caso, `self` sería unha referencia colgante.
    ///
    /// # Panics
    ///
    /// Dado que un [`panic!`] chamará a `drop` mentres se desconecta, calquera [`panic!`] nunha implementación `drop` probablemente abortará.
    ///
    /// Teña en conta que, aínda que este panics, considérase que o valor é eliminado;
    /// non debe facer que volva chamar a `drop`.
    /// Isto normalmente é manipulado automaticamente polo compilador, pero cando se usa código non seguro, ás veces pode ocorrer involuntariamente, especialmente cando se usa [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}