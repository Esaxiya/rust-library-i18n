#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Contén definicións de estrutura para o deseño dos tipos incorporados do compilador.
//!
//! Pódense usar como obxectivos de transmutados en código inseguro para manipular directamente as representacións en bruto.
//!
//!
//! A súa definición sempre debe coincidir co ABI definido en `rustc_middle::ty::layout`.
//!

/// A representación dun obxecto trait como `&dyn SomeTrait`.
///
/// Esta estrutura ten o mesmo deseño que tipos como `&dyn SomeTrait` e `Box<dyn AnotherTrait>`.
///
/// `TraitObject` está garantido para que coincida cos deseños, pero non é o tipo de obxectos trait (por exemplo, os campos non son accesibles directamente nun `&dyn SomeTrait`) nin controla ese deseño (cambiar a definición non cambiará o deseño dun `&dyn SomeTrait`).
///
/// Só está deseñado para ser usado por códigos non seguros que precisan manipular os detalles de baixo nivel.
///
/// Non hai ningunha forma de referirse a todos os obxectos trait de xeito xenérico, polo que o único xeito de crear valores deste tipo é con funcións como [`std::mem::transmute`][transmute].
/// Do mesmo xeito, o único xeito de crear un verdadeiro obxecto trait a partir dun valor `TraitObject` é con `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Sintetizar un obxecto trait con tipos non coincidentes, aquel no que a mesa vt non se corresponde co tipo de valor ao que apunta o punteiro de datos, é moi probable que leve a un comportamento indefinido.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // un exemplo trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // deixe que o compilador faga un obxecto trait
/// let object: &dyn Foo = &value;
///
/// // mira a representación en bruto
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // o punteiro de datos é o enderezo de `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // constrúe un novo obxecto, apuntando a un `i32` diferente, tendo coidado de usar a táboa `i32` de `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // debería funcionar como se construísemos un obxecto trait a partir de `other_value` directamente
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}