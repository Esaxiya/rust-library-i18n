//! traits primitivos e tipos que representan propiedades básicas dos tipos.
//!
//! Os tipos Rust pódense clasificar de varias formas útiles segundo as súas propiedades intrínsecas.
//! Estas clasificacións represéntanse como traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Tipos que se poden transferir a través dos límites do fío.
///
/// Este trait implántase automaticamente cando o compilador determina que é apropiado.
///
/// Un exemplo dun tipo que non é "Enviar" é o punteiro de contar referencias [`rc::Rc`][`Rc`].
/// Se dous fíos intentan clonar [`Rc`] que apuntan ao mesmo valor contado por referencias, poderían tentar actualizar o reconto de referencia ao mesmo tempo, que é [undefined behavior][ub] porque [`Rc`] non usa operacións atómicas.
///
/// O seu curmán [`sync::Arc`][arc] usa operacións atómicas (incorrendo en gastos xerais) e, polo tanto, é `Send`.
///
/// Vexa [the Nomicon](../../nomicon/send-and-sync.html) para máis detalles.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Tipos cun tamaño constante coñecido no momento da compilación.
///
/// Todos os parámetros de tipo teñen un límite implícito de `Sized`.A sintaxe especial `?Sized` pode usarse para eliminar este límite se non é axeitado.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // estrutura FooUse(Foo<[i32]>);//erro: o tamaño non está implementado para [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// A única excepción é o tipo `Self` implícito dun trait.
/// Un trait non ten un límite `Sized` implícito xa que é incompatible con [obxecto trait] onde, por definición, o trait necesita traballar con todos os implementadores posibles e, polo tanto, podería ter calquera tamaño.
///
///
/// Aínda que Rust permitirá que vincule `Sized` a un trait, non poderá usalo para formar un obxecto trait máis tarde:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // imos y: &dyn Bar= &Impl;//erro: o trait `Bar` non se pode converter nun obxecto
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // por defecto, por exemplo, que require que `[T]: !Default` sexa avaliable
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Tipos que poden ser "unsized" a un tipo de tamaño dinámico.
///
/// Por exemplo, o tipo de matriz de tamaño `[i8; 2]` implementa `Unsize<[i8]>` e `Unsize<dyn fmt::Debug>`.
///
/// Todas as implementacións de `Unsize` son proporcionadas automaticamente polo compilador.
///
/// `Unsize` está implementado para:
///
/// - `[T; N]` é `Unsize<[T]>`
/// - `T` é `Unsize<dyn Trait>` cando `T: Trait`
/// - `Foo<..., T, ...>` é `Unsize<Foo<..., U, ...>>` se:
///   - `T: Unsize<U>`
///   - Foo é unha estrutura
///   - Só o último campo de `Foo` ten un tipo que inclúe `T`
///   - `T` non forma parte do tipo doutros campos
///   - `Bar<T>: Unsize<Bar<U>>`, se o último campo de `Foo` ten tipo `Bar<T>`
///
/// `Unsize` úsase xunto con [`ops::CoerceUnsized`] para permitir que os contedores "user-defined" como [`Rc`] conteñan tipos de tamaño dinámico.
/// Consulte [DST coercion RFC][RFC982] e [the nomicon entry on coercion][nomicon-coerce] para obter máis detalles.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// trait obrigatorio para as constantes empregadas nas coincidencias de patróns.
///
/// Calquera tipo que derive `PartialEq` implementa automaticamente este trait,*independentemente* de se os seus parámetros tipo implementan `Eq`.
///
/// Se un elemento `const` contén algún tipo que non implementa este trait, entón ese tipo (1.) non implementa `PartialEq` (o que significa que a constante non proporcionará ese método de comparación, que xeración de código supón que está dispoñible), ou (2.) implementa *o seu propio* versión de `PartialEq` (que supoñemos que non se axusta a unha comparación de igualdade estrutural).
///
///
/// En calquera dos dous escenarios anteriores, rexeitamos o uso de tal constante nunha coincidencia de patróns.
///
/// Vexa tamén [structural match RFC][RFC1445] e [issue 63438] que motivaron a migración dun deseño baseado en atributos a este trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// trait obrigatorio para as constantes empregadas nas coincidencias de patróns.
///
/// Calquera tipo que derive `Eq` implementa automaticamente este trait, * independentemente de que os seus parámetros de tipo implementen `Eq`.
///
/// Este é un truco para evitar unha limitación no noso sistema de tipos.
///
/// # Background
///
/// Queremos esixir que os tipos de consts empregados nas coincidencias de patróns teñan o atributo `#[derive(PartialEq, Eq)]`.
///
/// Nun mundo máis ideal, poderiamos comprobar ese requisito só comprobando que o tipo dado implanta tanto o `StructuralPartialEq` trait *como* o `Eq` trait.
/// Non obstante, podes ter ADT que *fagan*`derive(PartialEq, Eq)` e ser un caso que queremos que o compilador acepte e, con todo, o tipo da constante non pode implementar `Eq`.
///
/// É dicir, un caso coma este:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (O problema do código anterior é que `Wrap<fn(&())>` non implementa `PartialEq` nin `Eq`, porque `para <'a> fn(&'a _)` does not implement those traits.)
///
/// Polo tanto, non podemos confiar na comprobación inxenua de `StructuralPartialEq` e simple `Eq`.
///
/// Como solución para solucionar isto, usamos dous traits separados inxectados por cada un dos dous derivados (`#[derive(PartialEq)]` e `#[derive(Eq)]`) e comprobamos que ambos están presentes como parte da comprobación da coincidencia estrutural.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Tipos cuxos valores poden duplicarse simplemente copiando bits.
///
/// Por defecto, as combinacións de variables teñen "mover semántica".Noutras palabras:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` mudouse a `y`, polo que non se pode usar
///
/// // println! ("{: ?}", x);//erro: uso do valor movido
/// ```
///
/// Non obstante, se un tipo implementa `Copy`, ten "copia de semántica":
///
/// ```
/// // Podemos derivar unha implementación `Copy`.
/// // `Clone` tamén é necesario, xa que é un superestrato de `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` é unha copia de `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// É importante ter en conta que nestes dous exemplos, a única diferenza é se está autorizado a acceder a `x` despois da tarefa.
/// Baixo o capó, tanto unha copia coma un movemento poden producir copias de bits na memoria, aínda que ás veces se optimiza.
///
/// ## Como podo implementar `Copy`?
///
/// Hai dous xeitos de implementar `Copy` no seu tipo.O máis sinxelo é usar `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Tamén pode implementar `Copy` e `Clone` manualmente:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Hai unha pequena diferenza entre os dous: a estratexia `derive` tamén colocará un `Copy` ligado a parámetros de tipo, o que non sempre se desexa.
///
/// ## Cal é a diferenza entre `Copy` e `Clone`?
///
/// As copias ocorren de forma implícita, por exemplo como parte dunha tarefa `y = x`.O comportamento de `Copy` non é sobrecargable;sempre é unha simple copia pouco sabia.
///
/// A clonación é unha acción explícita, `x.clone()`.A implementación de [`Clone`] pode proporcionar calquera comportamento específico de tipo necesario para duplicar valores de forma segura.
/// Por exemplo, a implementación de [`Clone`] para [`String`] precisa copiar o buffer de cadea apuntada no heap.
/// Unha simple copia a bits dos valores [`String`] só copiaría o punteiro, o que levaría a un dobre libre na liña.
/// Por esta razón, [`String`] é [`Clone`] pero non `Copy`.
///
/// [`Clone`] é un supertrato de `Copy`, polo que todo o que sexa `Copy` tamén debe implementar [`Clone`].
/// Se un tipo é `Copy`, a súa implementación [`Clone`] só precisa devolver `*self` (ver o exemplo anterior).
///
/// ## Cando o meu tipo pode ser `Copy`?
///
/// Un tipo pode implementar `Copy` se todos os seus compoñentes implementan `Copy`.Por exemplo, esta estrutura pode ser `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Unha estrutura pode ser `Copy` e [`i32`] é `Copy`, polo tanto `Point` é elixible para ser `Copy`.
/// Pola contra, considere
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// A estrutura `PointList` non pode implementar `Copy`, porque [`Vec<T>`] non é `Copy`.Se tentamos derivar unha implementación `Copy`, obteremos un erro:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// As referencias compartidas (`&T`) tamén son `Copy`, polo que un tipo pode ser `Copy`, incluso cando contén referencias compartidas de tipos `T` que non son * `Copy`.
/// Considere a seguinte estrutura, que pode implementar `Copy`, porque só ten unha *referencia compartida* ao noso tipo "Copiar" tipo `PointList` desde arriba:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Cando *non* o meu tipo pode ser `Copy`?
///
/// Non se poden copiar algúns tipos de forma segura.Por exemplo, copiar `&mut T` crearía unha referencia mutable aliasada.
/// Copiar [`String`] duplicaría a responsabilidade de xestionar o búfer de [`String`], dando lugar a un dobre libre.
///
/// Xeralizando este último caso, calquera tipo que implemente [`Drop`] non pode ser `Copy`, porque está a xestionar algún recurso ademais dos seus propios bytes [`size_of::<T>`].
///
/// Se tenta implementar `Copy` nunha estrutura ou enum que conteña datos que non sexan "Copiar", obterá o erro [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Cando *debería* ser o meu tipo `Copy`?
///
/// En xeral, se o seu tipo _can_ implementa `Copy`, debería.
/// Non obstante, teña en conta que a implementación de `Copy` forma parte da API pública do seu tipo.
/// Se o tipo pode non ser "Copiar" no future, podería ser prudente omitir a implementación `Copy` agora para evitar un cambio de API.
///
/// ## Implementadores adicionais
///
/// Ademais do [implementors listed below][impls], os seguintes tipos tamén implementan `Copy`:
///
/// * Tipos de elementos de funcións (ou sexa, os distintos tipos definidos para cada función)
/// * Tipos de punteiros de funcións (por exemplo, `fn() -> i32`)
/// * Tipos de matriz, para todos os tamaños, se o tipo de elemento tamén implementa `Copy` (por exemplo, `[i32; 123456]`)
/// * Tipos de tuplas, se cada compoñente tamén implementa `Copy` (por exemplo, `()`, `(i32, bool)`)
/// * Tipos de peche, se non captan ningún valor do contorno ou se todos estes valores capturados implementan `Copy` eles mesmos.
///   Teña en conta que as variables capturadas por referencia compartida sempre implementan `Copy` (aínda que o referente non), mentres que as variables capturadas por referencia mutable nunca implementan `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Isto permite copiar un tipo que non implementa `Copy` debido a límites de vida insatisfeitos (copiar `A<'_>` cando só `A<'static>: Copy` e `A<'_>: Clone`).
// Temos este atributo aquí por agora só porque hai bastantes especializacións existentes en `Copy` que xa existen na biblioteca estándar e non hai ningunha forma de ter este comportamento con seguridade neste momento.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Deriva macro xerando un impl do trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Tipos para os que é seguro compartir referencias entre fíos.
///
/// Este trait implántase automaticamente cando o compilador determina que é apropiado.
///
/// A definición precisa é: un tipo `T` é [`Sync`] se e só se `&T` é [`Send`].
/// Noutras palabras, se non hai posibilidade de [undefined behavior][ub] (incluídas as carreiras de datos) ao pasar referencias `&T` entre fíos.
///
/// Como cabería esperar, os tipos primitivos como [`u8`] e [`f64`] son todos [`Sync`], e tamén os simples tipos agregados que os conteñen, como tuplas, estruturas e enumeracións.
/// Máis exemplos de tipos básicos [`Sync`] inclúen tipos "immutable" como `&T` e aqueles con mutabilidade herdada simple, como [`Box<T>`][box], [`Vec<T>`][vec] e a maioría dos outros tipos de colección.
///
/// (Os parámetros xenéricos deben ser [`Sync`] para que o seu contedor sexa [`Sincronizar]].)
///
/// Unha consecuencia un tanto sorprendente da definición é que `&mut T` é `Sync` (se `T` é `Sync`) aínda que parece que pode proporcionar unha mutación non sincronizada.
/// O truco é que unha referencia mutable detrás dunha referencia compartida (é dicir, `& &mut T`) convértese en de só lectura, coma se dun `& &T` se tratase.
/// Polo tanto, non hai risco dunha carreira de datos.
///
/// Os tipos que non son `Sync` son aqueles que teñen "interior mutability" de forma non segura, como [`Cell`][cell] e [`RefCell`][refcell].
/// Estes tipos permiten a mutación dos seus contidos incluso a través dunha referencia inmutable e compartida.
/// Por exemplo, o método `set` en [`Cell<T>`][cell] leva `&self`, polo que só require unha referencia compartida [`&Cell<T>`][cell].
/// O método non realiza ningunha sincronización, polo que [`Cell`][cell] non pode ser `Sync`.
///
/// Outro exemplo dun tipo que non é "Sync" é o punteiro de contar referencias [`Rc`][rc].
/// Dada calquera referencia [`&Rc<T>`][rc], pode clonar un novo [`Rc<T>`][rc], modificando os contos de referencia dun xeito non atómico.
///
/// Para os casos nos que se precisa unha mutabilidade interior segura de fíos, Rust proporciona [atomic data types], así como bloqueo explícito a través de [`sync::Mutex`][mutex] e [`sync::RwLock`][rwlock].
/// Estes tipos aseguran que calquera mutación non poida causar carreiras de datos, polo que os tipos son `Sync`.
/// Do mesmo xeito, [`sync::Arc`][arc] fornece un análogo seguro de fíos de [`Rc`][rc].
///
/// Calquera tipo con mutabilidade interior tamén debe empregar o envoltorio [`cell::UnsafeCell`][unsafecell] ao redor do value(s) que pode mutarse a través dunha referencia compartida.
/// Non facer isto é [undefined behavior][ub].
/// Por exemplo, [`transmute`][transmute]-ing de `&T` a `&mut T` non é válido.
///
/// Vexa [the Nomicon][nomicon-send-and-sync] para obter máis detalles sobre `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): unha vez que o soporte para engadir notas en `rustc_on_unimplemented` chega en versión beta, e ampliouse para comprobar se hai un peche en calquera lugar da cadea de requisitos, esténdeo como tal (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Tipo de tamaño cero usado para marcar cousas que posúen "act like" un `T`.
///
/// Engadir un campo `PhantomData<T>` ao seu tipo indica ao compilador que o seu tipo actúa coma se almacene un valor do tipo `T`, aínda que realmente non o faga.
/// Esta información úsase cando se calculan certas propiedades de seguridade.
///
/// Para unha explicación máis profunda de como usar `PhantomData<T>`, consulte [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Unha nota espantosa 👻👻👻
///
/// Aínda que ambos teñen nome asustado, `PhantomData` e "tipos fantasma" están relacionados, pero non idénticos.Un parámetro de tipo fantasma é simplemente un parámetro de tipo que nunca se usa.
/// En Rust, isto a miúdo fai que o compilador se queixa e a solución é engadir un uso de "dummy" a través de `PhantomData`.
///
/// # Examples
///
/// ## Parámetros de vida non utilizados
///
/// Quizais o caso de uso máis común para `PhantomData` sexa unha estrutura que ten un parámetro de vida non utilizado, normalmente como parte dalgún código non seguro.
/// Por exemplo, aquí hai unha estrutura `Slice` que ten dous punteiros do tipo `*const T`, presumiblemente apuntando a unha matriz nalgures:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// A intención é que os datos subxacentes só sexan válidos para `'a` de por vida, polo que `Slice` non debería sobrevivir a `'a`.
/// Non obstante, esta intención non se expresa no código, xa que non hai usos de toda a vida `'a` e, polo tanto, non está claro a que datos se aplica.
/// Podemos corrixilo dicíndolle ao compilador que actúe *coma se* a estrutura `Slice` contivese unha referencia `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Pola súa banda, isto tamén require a anotación `T: 'a`, o que indica que as referencias en `T` son válidas durante toda a vida `'a`.
///
/// Cando inicialice un `Slice`, simplemente proporcione o valor `PhantomData` para o campo `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Parámetros de tipo non utilizados
///
/// Ás veces acontece que ten parámetros de tipo non utilizados que indican a que tipo de datos é unha estrutura "tied", aínda que eses datos non se atopan na propia estrutura.
/// Aquí tes un exemplo onde isto xorde con [FFI].
/// A interface estranxeira usa asas do tipo `*mut ()` para referirse a valores Rust de diferentes tipos.
/// Seguimos o tipo Rust usando un parámetro tipo fantasma no struct `ExternalResource` que envolve un identificador.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Propiedade e cheque de caída
///
/// Engadir un campo do tipo `PhantomData<T>` indica que o seu tipo posúe datos do tipo `T`.Isto á súa vez implica que cando se cae o seu tipo, pode deixar caer unha ou máis instancias do tipo `T`.
/// Isto afecta á análise [drop check] do compilador Rust.
///
/// Se a súa estrutura non é propietaria dos datos do tipo `T`, é mellor usar un tipo de referencia, como `PhantomData<&'a T>` (ideally) ou `PhantomData<*const T>` (se non se aplica a vida útil), para non indicar a propiedade.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compilador interno trait usado para indicar o tipo de discriminantes enum.
///
/// Este trait implántase automaticamente para todos os tipos e non engade ningunha garantía ao [`mem::Discriminant`].
/// Transitar entre `DiscriminantKind::Discriminant` e `mem::Discriminant` é un **comportamento indefinido**.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// O tipo de discriminante, que debe satisfacer o trait bounds requirido por `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compilador interno trait usado para determinar se un tipo contén algún `UnsafeCell` internamente, pero non a través dunha indirecta.
///
/// Isto afecta, por exemplo, a que un `static` dese tipo se coloque na memoria estática de só lectura ou na memoria estática escribible.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Tipos que se poden mover con seguridade despois de fixalos.
///
/// Rust en si non ten nocións de tipos inmobles e considera que os movementos (por exemplo, mediante asignación ou [`mem::replace`]) sempre son seguros.
///
/// No seu lugar utilízase o tipo [`Pin`][Pin] para evitar movementos polo sistema de tipos.Os punteiros `P<T>` envoltos no envoltorio [`Pin<P<T>>`][Pin] non se poden sacar.
/// Consulte a documentación do [`pin` module] para obter máis información sobre como fixar.
///
/// A implementación de `Unpin` trait para `T` elimina as restricións de fixar o tipo, o que permite entón sacar `T` de [`Pin<P<T>>`][Pin] con funcións como [`mem::replace`].
///
///
/// `Unpin` non ten ningunha consecuencia para os datos non fixados.
/// En particular, [`mem::replace`] move os datos `!Unpin` felizmente (funciona para calquera `&mut T`, non só cando `T: Unpin`).
/// Non obstante, non podes usar [`mem::replace`] en datos envoltos nun [`Pin<P<T>>`][Pin] porque non podes obter o `&mut T` que necesitas para iso, e *iso* é o que fai que este sistema funcione.
///
/// Así, por exemplo, isto só se pode facer nos tipos que implementan `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Necesitamos unha referencia mutable para chamar ao `mem::replace`.
/// // Podemos obter esta referencia invocando (implicitly) a `Pin::deref_mut`, pero iso só é posible porque `String` implementa `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Este trait implántase automaticamente para case todos os tipos.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Un tipo de marcador que non implementa `Unpin`.
///
/// Se un tipo contén un `PhantomPinned`, non implementará `Unpin` por defecto.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementacións de `Copy` para tipos primitivos.
///
/// As implementacións que non se poden describir en Rust están implementadas en `traits::SelectionContext::copy_clone_conditions()` en `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// As referencias compartidas pódense copiar, pero as referencias mutables *non*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}