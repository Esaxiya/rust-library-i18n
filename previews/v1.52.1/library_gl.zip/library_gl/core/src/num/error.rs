//! Tipos de erro para a conversión a tipos integrais.

use crate::convert::Infallible;
use crate::fmt;

/// O tipo de erro devolveuse cando falla unha conversión de tipo integral comprobada.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Coincide en lugar de coaccionar para asegurarse de que o código como `From<Infallible> for TryFromIntError` anterior seguirá funcionando cando `Infallible` se converta nun alias de `!`.
        //
        //
        match never {}
    }
}

/// Un erro que se pode devolver ao analizar un número enteiro.
///
/// Este erro úsase como tipo de erro para as funcións `from_str_radix()` nos tipos enteiros primitivos, como [`i8::from_str_radix`].
///
/// # Causas potenciais
///
/// Entre outras causas, `ParseIntError` pódese lanzar debido ao espazo en branco principal ou final na cadea, por exemplo, cando se obtén da entrada estándar.
///
/// Usar o método [`str::trim()`] garante que non quede ningún espazo en branco antes de analizar.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum para almacenar os distintos tipos de erros que poden causar o fallo ao analizar un enteiro.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// O valor que se analiza está baleiro.
    ///
    /// Entre outras causas, esta variante construirase ao analizar unha cadea baleira.
    Empty,
    /// Contén un díxito non válido no seu contexto.
    ///
    /// Entre outras causas, esta variante construirase ao analizar unha cadea que conteña un carácter non ASCII.
    ///
    /// Esta variante tamén se constrúe cando un `+` ou `-` está mal colocado dentro dunha cadea por conta propia ou no medio dun número.
    ///
    ///
    InvalidDigit,
    /// O número enteiro é demasiado grande para almacenalo no tipo enteiro de destino.
    PosOverflow,
    /// O número enteiro é demasiado pequeno para almacenalo no tipo enteiro de destino.
    NegOverflow,
    /// O valor era cero
    ///
    /// Esta variante emitirase cando a cadea de análise teña un valor cero, o que sería ilegal para os tipos distintos de cero.
    ///
    Zero,
}

impl ParseIntError {
    /// Produce a causa detallada do fallo do análisis dun enteiro.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}