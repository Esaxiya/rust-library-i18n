//! Constantes específicas do tipo de coma flotante de dobre precisión `f64`.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! No submódulo `consts` fornécense números matemáticamente significativos.
//!
//! Para as constantes definidas directamente neste módulo (distintas das definidas no submódulo `consts`), o novo código debería empregar as constantes asociadas definidas directamente no tipo `f64`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// O raio ou base da representación interna de `f64`.
/// Use [`f64::RADIX`] no seu lugar.
///
/// # Examples
///
/// ```rust
/// // xeito obsoleto
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // xeito previsto
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// Número de díxitos significativos na base 2.
/// Use [`f64::MANTISSA_DIGITS`] no seu lugar.
///
/// # Examples
///
/// ```rust
/// // xeito obsoleto
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // xeito previsto
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// Número aproximado de díxitos significativos na base 10.
/// Use [`f64::DIGITS`] no seu lugar.
///
/// # Examples
///
/// ```rust
/// // xeito obsoleto
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // xeito previsto
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] valor para `f64`.
/// Use [`f64::EPSILON`] no seu lugar.
///
/// Esta é a diferenza entre `1.0` e o seguinte número representable máis grande.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // xeito obsoleto
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // xeito previsto
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// O valor `f64` finito máis pequeno.
/// Use [`f64::MIN`] no seu lugar.
///
/// # Examples
///
/// ```rust
/// // xeito obsoleto
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // xeito previsto
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// O menor valor normal `f64` positivo.
/// Use [`f64::MIN_POSITIVE`] no seu lugar.
///
/// # Examples
///
/// ```rust
/// // xeito obsoleto
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // xeito previsto
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// Valor `f64` finito máis grande.
/// Use [`f64::MAX`] no seu lugar.
///
/// # Examples
///
/// ```rust
/// // xeito obsoleto
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // xeito previsto
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// Un maior que a potencia normal mínima posible de 2 expoñentes.
/// Use [`f64::MIN_EXP`] no seu lugar.
///
/// # Examples
///
/// ```rust
/// // xeito obsoleto
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // xeito previsto
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// Potencia máxima posible de 2 expoñentes.
/// Use [`f64::MAX_EXP`] no seu lugar.
///
/// # Examples
///
/// ```rust
/// // xeito obsoleto
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // xeito previsto
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// Potencia normal mínima posible de 10 expoñentes.
/// Use [`f64::MIN_10_EXP`] no seu lugar.
///
/// # Examples
///
/// ```rust
/// // xeito obsoleto
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // xeito previsto
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// Potencia máxima posible de 10 expoñentes.
/// Use [`f64::MAX_10_EXP`] no seu lugar.
///
/// # Examples
///
/// ```rust
/// // xeito obsoleto
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // xeito previsto
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// Non é un número (NaN).
/// Use [`f64::NAN`] no seu lugar.
///
/// # Examples
///
/// ```rust
/// // xeito obsoleto
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // xeito previsto
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infinity (∞).
/// Use [`f64::INFINITY`] no seu lugar.
///
/// # Examples
///
/// ```rust
/// // xeito obsoleto
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // xeito previsto
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// Infinity negativo (−∞).
/// Use [`f64::NEG_INFINITY`] no seu lugar.
///
/// # Examples
///
/// ```rust
/// // xeito obsoleto
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // xeito previsto
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// Constantes matemáticas básicas.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: substitúe por constantes matemáticas de cmath.

    /// A constante (π) de Arquímedes
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// A constante de círculo completo (τ)
    ///
    /// Igual a 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// Número de Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// O raio ou base da representación interna de `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Número de díxitos significativos na base 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// Número aproximado de díxitos significativos na base 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] valor para `f64`.
    ///
    /// Esta é a diferenza entre `1.0` e o seguinte número representable máis grande.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// O valor `f64` finito máis pequeno.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// O menor valor normal `f64` positivo.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// Valor `f64` finito máis grande.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// Un maior que a potencia normal mínima posible de 2 expoñentes.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// Potencia máxima posible de 2 expoñentes.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// Potencia normal mínima posible de 10 expoñentes.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// Potencia máxima posible de 10 expoñentes.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// Non é un número (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// Infinity negativo (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// Devolve `true` se este valor é `NaN`.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` non está dispoñible publicamente en libcore debido a problemas de portabilidade, polo que esta implementación é para uso privado internamente.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// Devolve `true` se este valor é infinito positivo ou infinito negativo e `false` doutro xeito.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Devolve `true` se este número non é infinito nin `NaN`.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Non hai necesidade de manexar NaN por separado: se auto é NaN, a comparación non é certa, exactamente como se desexa.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Devolve `true` se o número é [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // Os valores entre `0` e `min` son subnormais.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Devolve `true` se o número non é cero, infinito, [subnormal] ou `NaN`.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // Os valores entre `0` e `min` son subnormais.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Devolve a categoría de coma flotante do número.
    /// Se só se vai probar unha propiedade, polo xeral é máis rápido usar o predicado específico.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Devolve `true` se `self` ten un signo positivo, incluído `+0.0`, `NaN` con bit de signo positivo e infinito positivo.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// Devolve `true` se `self` ten un signo negativo, incluído `-0.0`, `NaN` con bit de signo negativo e infinito negativo.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// Toma o (inverse) recíproco dun número, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// Converte os radianes en graos.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // Aquí a división está correctamente redondeada con respecto ao verdadeiro valor de 180/π.
        // (Isto difiere do f32, onde se debe empregar unha constante para garantir un resultado correctamente redondeado.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// Converte os graos en radiáns.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// Devolve o máximo dos dous números.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Se un dos argumentos é NaN, devólvese o outro argumento.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// Devolve o mínimo dos dous números.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Se un dos argumentos é NaN, devólvese o outro argumento.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// Redondea cara a cero e convértese en calquera tipo enteiro primitivo, supoñendo que o valor é finito e encaixa nese tipo.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// O valor debe:
    ///
    /// * Non sexa `NaN`
    /// * Non sexas infinito
    /// * Ser representable no tipo de retorno `Int`, despois de cortar a súa parte fraccionaria
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Transmutación bruta a `u64`.
    ///
    /// Actualmente é idéntico ao `transmute::<f64, u64>(self)` en todas as plataformas.
    ///
    /// Vexa `from_bits` para algunha discusión sobre a portabilidade desta operación (case non hai problemas).
    ///
    /// Teña en conta que esta función é distinta do lanzamento `as`, que intenta preservar o valor *numérico* e non o valor a bit.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() non é un casting!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // SEGURIDADE: `u64` é un tipo de datos sinxelo e antigo polo que sempre podemos transmutalo
        unsafe { mem::transmute(self) }
    }

    /// Transmutación en bruto desde `u64`.
    ///
    /// Actualmente é idéntico ao `transmute::<u64, f64>(v)` en todas as plataformas.
    /// Resulta que isto é increíblemente portátil, por dúas razóns:
    ///
    /// * Floats e Ints teñen a mesma finalidade en todas as plataformas compatibles.
    /// * IEEE-754 especifica moi precisamente o deseño de bits dos flotantes.
    ///
    /// Non obstante, hai unha advertencia: antes da versión 2008 do IEEE-754, non se especificaba realmente como interpretar o bit de sinalización NaN.
    /// A maioría das plataformas (especialmente x86 e ARM) escolleron a interpretación que finalmente se estandarizou en 2008, pero algunhas non (especialmente MIPS).
    /// Como resultado, todos os NaN de sinalización en MIPS son NaN silenciosos en x86 e viceversa.
    ///
    /// En vez de tratar de preservar a multiplataforma de sinalización, esta implementación favorece a conservación dos bits exactos.
    /// Isto significa que as cargas útiles codificadas en NaN conservaranse aínda que o resultado deste método se envíe pola rede desde unha máquina x86 a unha MIPS.
    ///
    ///
    /// Se os resultados deste método só son manipulados pola mesma arquitectura que os produciu, entón non hai ningún problema de portabilidade.
    ///
    /// Se a entrada non é NaN, non haberá problemas de portabilidade.
    ///
    /// Se non che importa a sinalización (moi probable), non hai preocupación de portabilidade.
    ///
    /// Teña en conta que esta función é distinta do lanzamento `as`, que intenta preservar o valor *numérico* e non o valor a bit.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // SEGURIDADE: `u64` é un tipo de datos sinxelo e antigo polo que sempre podemos transmutar del
        // Acontece que os problemas de seguridade con sNaN foron excesivos.Hurra!
        unsafe { mem::transmute(v) }
    }

    /// Devolve a representación de memoria deste número de punto flotante como unha matriz de bytes en orde de bytes (network) big-endian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// Devolve a representación de memoria deste número de punto flotante como unha matriz de bytes en orde de bytes pouco endianos.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// Devolve a representación de memoria deste número de punto flotante como unha matriz de bytes en orde de bytes nativos.
    ///
    /// A medida que se emprega o sistema nativo da plataforma de destino, o código portátil debería usar [`to_be_bytes`] ou [`to_le_bytes`], segundo corresponda.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// Devolve a representación de memoria deste número de punto flotante como unha matriz de bytes en orde de bytes nativos.
    ///
    ///
    /// [`to_ne_bytes`] debería preferirse antes que isto sempre que sexa posible.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // SEGURIDADE: `f64` é un tipo de datos sinxelo e antigo polo que sempre podemos transmutalo
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Crea un valor en coma flotante a partir da súa representación como unha matriz de bytes en big endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// Crea un valor en coma flotante a partir da súa representación como unha matriz de bytes en endian pouco.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// Crea un valor de punto flotante a partir da súa representación como matriz de bytes en endian nativo.
    ///
    /// A medida que se emprega o sistema nativo da plataforma de destino, é probable que o código portátil queira usar [`from_be_bytes`] ou [`from_le_bytes`], segundo corresponda.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// Devolve unha ordenación entre eu e outros valores.
    /// A diferenza da comparación parcial estándar entre números de punto flotante, esta comparación sempre produce unha orde de acordo co predicado totalOrder tal e como se define no estándar de punto flotante IEEE 754 (revisión de 2008).
    /// Os valores están ordenados na seguinte orde:
    /// - NaN tranquilo negativo
    /// - NaN de sinalización negativa
    /// - Infinito negativo
    /// - Números negativos
    /// - Números subnormais negativos
    /// - Cero negativo
    /// - Cero positivo
    /// - Números subnormais positivos
    /// - Números positivos
    /// - Infinito positivo
    /// - NaN de sinalización positiva
    /// - NaN tranquilo positivo
    ///
    /// Teña en conta que esta función non sempre coincide coas implementacións [`PartialOrd`] e [`PartialEq`] de `f64`.En particular, consideran que o cero negativo e positivo é igual, mentres que `total_cmp` non.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // En caso de negativos, xire todos os bits, excepto o signo, para lograr un deseño similar aos números enteiros do complemento de dous
        //
        // Por que funciona isto?Os flotadores IEEE 754 constan de tres campos:
        // Bit de sinal, expoñente e mantisa.O conxunto de campos de expoñente e mantisa no seu conxunto teñen a propiedade de que a súa orde a bits é igual á magnitude numérica onde se define a magnitude.
        // A magnitude normalmente non se define nos valores de NaN, pero o IEEE 754 totalOrder define os valores de NaN tamén para seguir a orde de bits.Isto leva á orde explicada no comentario do documento.
        // Non obstante, a representación da magnitude é a mesma para os números negativos e positivos; só o bit de signo é diferente.
        // Para comparar facilmente os flotadores como enteiros asinados, necesitamos dar a volta aos bits de expoñente e mantisa en caso de números negativos.
        // Convertemos efectivamente os números ao formulario "two's complement".
        //
        // Para facer o cambio, construímos unha máscara e XOR contra ela.
        // Calculamos sen máscaras unha máscara "all-ones except for the sign bit" a partir de valores con signo negativo: o signo desprazable á dereita estende o número enteiro, polo que "fill" a máscara con bits de signo e logo convertémolo a sen signo para empurrar un bit cero máis.
        //
        // En valores positivos, a máscara é todo ceros, polo que é un non-op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// Restrinxe un valor a un determinado intervalo a menos que sexa NaN.
    ///
    /// Devolve `max` se `self` é maior que `max` e `min` se `self` é inferior a `min`.
    /// Se non, devolve `self`.
    ///
    /// Teña en conta que esta función devolve NaN se o valor inicial tamén era NaN.
    ///
    /// # Panics
    ///
    /// Panics se `min > max`, `min` é NaN ou `max` é NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}