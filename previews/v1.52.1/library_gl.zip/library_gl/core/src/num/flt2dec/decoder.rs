//! Descodifica un valor de punto flotante en partes individuais e rangos de erro.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Valor finito non asinado descodificado, tal que:
///
/// - O valor orixinal é igual a `mant * 2^exp`.
///
/// - Calquera número de `(mant - minus)*2^exp` a `(mant + plus)* 2^exp` redondeará ao valor orixinal.
/// O rango inclúe só cando `inclusive` é `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// A mantisa escamada.
    pub mant: u64,
    /// O rango de erro máis baixo.
    pub minus: u64,
    /// O rango de erro superior.
    pub plus: u64,
    /// O expoñente compartido na base 2.
    pub exp: i16,
    /// Verdadeiro cando o rango de erro está incluído.
    ///
    /// En IEEE 754, isto é certo cando a mantisa orixinal era parella.
    pub inclusive: bool,
}

/// Valor sen asinar descodificado.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinitos, positivos ou negativos.
    Infinite,
    /// Cero, positivo ou negativo.
    Zero,
    /// Números finitos con campos máis descodificados.
    Finite(Decoded),
}

/// Un tipo de punto flotante que se pode "decodificar" d.
pub trait DecodableFloat: RawFloat + Copy {
    /// O valor normalizado mínimo positivo.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Devolve un signo (certo cando é negativo) e un valor `FullDecoded` dun número de punto flotante dado.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // veciños: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode sempre conserva o expoñente, polo que a mantisa escala para subnormais.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // veciños: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // onde maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // veciños: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}