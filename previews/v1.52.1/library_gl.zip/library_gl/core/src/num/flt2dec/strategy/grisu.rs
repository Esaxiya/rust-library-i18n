//! Adaptación Rust do algoritmo Grisu3 descrito en "Impresión rápida e precisa de números de punto flotante con números enteiros" [^ 1].
//! Emprega aproximadamente 1 KB de táboa precomputada e, á súa vez, é moi rápido para a maioría das entradas.
//!
//! [^1]: Florian Loitsch.2010. Impresión rápida de números en coma flotante e
//!   con precisión con números enteiros.SIGPLAN Non.45, 6 (xuño de 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// vexa os comentarios en `format_shortest_opt` para obter a razón.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Dado `x > 0`, devolve `(k, 10^k)` tal que `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// A implementación do modo máis curto para Grisu.
///
/// Devolve `None` cando devolvería unha representación inexacta doutro xeito.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // precisamos polo menos tres bits de precisión adicional

    // comeza cos valores normalizados co expoñente compartido
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // atopar calquera `cached = 10^minusk` tal que `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // xa que `plus` está normalizado, isto significa `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // dadas as nosas opcións de `ALPHA` e `GAMMA`, isto pon `plus * cached` en `[4, 2^32)`.
    //
    // obviamente é desexable maximizar `GAMMA - ALPHA`, de xeito que non necesitamos moitas potencias en caché de 10, pero hai algunhas consideracións:
    //
    //
    // 1. queremos manter `floor(plus * cached)` dentro de `u32` xa que precisa unha división custosa.
    //    (isto non é realmente evitable, o resto é necesario para a estimación da precisión.)
    // 2.
    // o resto de `floor(plus * cached)` multiplícase repetidamente por 10 e non debería desbordarse.
    //
    // o primeiro dá `64 + GAMMA <= 32`, mentres que o segundo dá `10 * 2^-ALPHA <= 2^64`;
    // -60 e -32 é o rango máximo con esta restrición, e V8 tamén os usa.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // escala fps.isto dá o erro máximo de 1 ulp (demostrado a partir do teorema 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-rango real de menos
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 cubo | 1 cubo || 1 cubo | 1 cubo || 1 cubo | 1 cubo |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // superior a `minus`, `v` e `plus` son aproximacións *cuantificadas*(erro <1 ulp).
    // como non sabemos que o erro é positivo ou negativo, empregamos dúas aproximacións espaciadas igualmente e temos o erro máximo de 2 ulpas.
    //
    // o "unsafe region" é un intervalo liberal que inicialmente xeramos.
    // o "safe region" é un intervalo conservador que só aceptamos.
    // comezamos coa repr correcta dentro da rexión non segura e intentamos atopar a reprodución máis próxima a `v` que tamén está dentro da rexión segura.
    // se non podemos, desistimos.
    //
    let plus1 = plus.f + 1;
    // deixe plus0 = plus.f, 1;//só para explicación deixe minus0 = minus.f + 1;//só para explicación
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // expoñente compartido

    // divide `plus1` en partes integrais e fraccionarias.
    // as partes integrantes están garantidas para que se axusten a u32, xa que a potencia na caché garante `plus < 2^32` e `plus.f` normalizado sempre é inferior a `2^64 - 2^4` debido á esixencia de precisión.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // calcula o `10^max_kappa` máis grande como máximo `plus1` (polo tanto `plus1 < 10^(max_kappa+1)`).
    // este é un límite superior de `kappa` a continuación.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teorema 6.2: se `k` é o maior número enteiro
    // `0 <= y mod 10^k <= y - x`,              entón `V = floor(y / 10^k) * 10^k` está en `[x, y]` e unha das representacións máis curtas (co número mínimo de díxitos significativos) nese rango.
    //
    //
    // atopar a lonxitude dos díxitos `kappa` entre `(minus1, plus1)` segundo o teorema 6.2.
    // Pódese adoptar o teorema 6.2 para excluír `x` requirindo no seu lugar `y mod 10^k < y - x`.
    // (por exemplo, `x` =32000, `y` =32777; `kappa` =2 xa que `y mod 10 ^ 3=777 <y, x=777`.) o algoritmo depende da fase de verificación posterior para excluír `y`.
    //
    let delta1 = plus1 - minus1;
    // imos delta1int=(delta1>> e) como usize;//só para explicación
    let delta1frac = delta1 & ((1 << e) - 1);

    // representar partes integrais, mentres comproba a precisión en cada paso.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // díxitos aínda sen renderizar
    loop {
        // sempre temos polo menos un díxito para renderizar, como invariantes `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (dedúcese que `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // divide `remainder` por `10^kappa`.ambos son escalados por `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; atopamos o `kappa` correcto.
            let ten_kappa = (ten_kappa as u64) << e; // escala 10 ^ kappa de volta ao expoñente compartido
            return round_and_weed(
                // SEGURIDADE: inicializamos esa memoria arriba.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // rompe o lazo cando representamos todos os díxitos integrais.
        // o número exacto de díxitos é `max_kappa + 1` como `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // restaurar invariantes
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // representar partes fraccionadas, mentres se comproba a precisión en cada paso.
    // esta vez contamos con multiplicacións repetidas, xa que a división perderá a precisión.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // o seguinte díxito debería ser significativo xa que o probamos antes de romper invariantes, onde `m = max_kappa + 1` (número de díxitos na parte integral):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // non se desbordará, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // divide `remainder` por `10^kappa`.
        // ambos son escalados por `2^e / 10^kappa`, polo que este último está implícito aquí.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // divisor implícito
            return round_and_weed(
                // SEGURIDADE: inicializamos esa memoria arriba.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // restaurar invariantes
        kappa -= 1;
        remainder = r;
    }

    // xeramos todos os díxitos significativos de `plus1`, pero non estou seguro de se é o mellor.
    // por exemplo, se `minus1` é 3,14153 ... e `plus1` é 3,14158 ..., hai 5 representacións máis curtas diferentes de 3.14154 a 3.14158 pero só temos a máis grande.
    // temos que diminuír sucesivamente o último díxito e comprobar se este é o mellor repr.
    // hai como máximo 9 candidatos (..1 a ..9), polo que isto é bastante rápido.(Fase "rounding")
    //
    // a función comproba se este "optimal" repr está realmente dentro dos rangos ulp e tamén é posible que o "second-to-optimal" repr poida ser óptimo debido ao erro de redondeo.
    // en calquera dos casos devolve `None`.
    // (Fase "weeding")
    //
    // todos os argumentos aquí están escalados polo valor común (pero implícito) `k`, de xeito que:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (e tamén, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (e tamén, `threshold > plus1v` de invariantes anteriores)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // producir dúas aproximacións a `v` (en realidade `plus1 - v`) dentro de ulps 1.5.
        // a representación resultante debería ser a representación máis próxima a ambas.
        //
        // aquí úsase `plus1 - v` xa que os cálculos fanse con respecto a `plus1` para evitar overflow/underflow (de aí os nomes aparentemente intercambiados).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 cub)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 cub)

        // diminúe o último díxito e detense na representación máis próxima a `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // traballamos cos díxitos aproximados `w(n)`, que inicialmente é igual a `plus1 - plus1 % 10^kappa`.despois de executar o corpo do lazo `n` veces, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // configuramos `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (así `resto= plus1w(0)`) para simplificar as comprobacións.
            // teña en conta que `plus1w(n)` sempre aumenta.
            //
            // temos tres condicións para finalizar.calquera deles fará que o bucle non poida continuar, pero temos polo menos unha representación válida que se sabe que é a máis próxima a `v + 1 ulp`.
            // denominarémolos como TC1 a TC3 por brevidade.
            //
            // TC1: `w(n) <= v + 1 ulp`, é dicir, esta é a última repr que pode ser a máis próxima.
            // isto equivale a `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // combinado con TC2 (que comproba se `w(n+1)` is valid), isto evita o posible desbordamento no cálculo de `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, é dicir, a seguinte reprodución definitivamente non redondeará a `v`.
            // isto equivale a `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // o lado esquerdo pode desbordarse, pero sabemos `threshold > plus1v`, polo que se TC1 é falso, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` e podemos probar con seguridade se `threshold - plus1w(n) < 10^kappa`.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, é dicir, a seguinte repr
            // nada máis preto do `v + 1 ulp` que o actual repr.
            // dado `z(n) = plus1v_up - plus1w(n)`, isto convértese en `abs(z(n)) <= abs(z(n+1))`.de novo asumindo que TC1 é falso, temos `z(n) > 0`.temos dous casos a considerar:
            //
            // - cando `z(n+1) >= 0`: TC3 pasa a ser `z(n) <= z(n+1)`.
            // como `plus1w(n)` está aumentando, `z(n)` debería ser decrecente e isto é claramente falso.
            // - cando `z(n+1) < 0`:
            //   - TC3a: a condición previa é `plus1v_up < plus1w(n) + 10^kappa`.supoñendo que TC2 é falso, `threshold >= plus1w(n) + 10^kappa` polo que non pode desbordarse.
            //   - TC3b: TC3 convértese en `z(n) <= -z(n+1)`, é dicir, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   o TC1 negado dá `plus1v_up > plus1w(n)`, polo que non pode desbordarse nin desbordarse cando se combina con TC3a.
            //
            // en consecuencia, deberiamos parar cando `TC1 || TC2 || (TC3a && TC3b)`.o seguinte é igual ao seu inverso, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // a reprodución máis curta non pode rematar con `0`
                plus1w += ten_kappa;
            }
        }

        // comproba se esta representación tamén é a representación máis próxima a `v - 1 ulp`.
        //
        // isto é simplemente igual ás condicións finais para `v + 1 ulp`, con todo `plus1v_up` substituído por `plus1v_down`.
        // a análise de desbordamento mantense igualmente.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // agora temos a representación máis próxima a `v` entre `plus1` e `minus1`.
        // Non obstante, isto é demasiado liberal, polo que rexeitamos calquera `w(n)` non entre `plus0` e `minus0`, é dicir, `plus1 - plus1w(n) <= minus0` ou `plus1 - plus1w(n) >= plus0`.
        // utilizamos os feitos que `threshold = plus1 - minus1` e `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// A implementación do modo máis curto para Grisu con Dragon fallback.
///
/// Isto debería usarse na maioría dos casos.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SEGURIDADE: o comprobador de préstamos non é o suficientemente intelixente como para permitirnos usar `buf`
    // no segundo branch, así que lavamos a vida aquí.
    // Pero só reutilizamos `buf` se `format_shortest_opt` devolveu `None` polo que está ben.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// A implementación do modo exacto e fixo para Grisu.
///
/// Devolve `None` cando devolvería unha representación inexacta doutro xeito.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // precisamos polo menos tres bits de precisión adicional
    assert!(!buf.is_empty());

    // normalizar e escalar `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // divide `v` en partes integrais e fraccionarias.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // tanto o antigo `v` como o novo `v` (escalado por `10^-k`) ten un erro de <1 ulp (teorema 5.1).
    // como non sabemos que o erro é positivo ou negativo, empregamos dúas aproximacións espaciadas igualmente e temos o erro máximo de 2 ulpas (igual ao caso máis curto).
    //
    //
    // o obxectivo é atopar a serie de díxitos exactamente redondeada que é común a `v - 1 ulp` e `v + 1 ulp`, de xeito que teñamos a máxima confianza.
    // se isto non é posible, non sabemos cal é a saída correcta para `v`, polo que renunciamos e retrocedemos.
    //
    // `err` defínese como `1 ulp * 2^e` aquí (igual ao ulp en `vfrac`), e escalarémolo sempre que `v` se modifique.
    //
    //
    //
    let mut err = 1;

    // calcula o `10^max_kappa` máis grande como máximo `v` (polo tanto `v < 10^(max_kappa+1)`).
    // este é un límite superior de `kappa` a continuación.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // se estamos a traballar coa limitación dos últimos díxitos, debemos acurtar o búfer antes da representación real para evitar o redondeo dobre.
    //
    // teña en conta que temos que agrandar de novo o búfer cando se redonde.
    let len = if exp <= limit {
        // oups, nin sequera podemos producir *un* díxito.
        // isto é posible cando, digamos, temos algo así como 9.5 e se redondea a 10.
        //
        // en principio podemos chamar inmediatamente a `possibly_round` cun buffer baleiro, pero escalar `max_ten_kappa << e` por 10 pode producir desbordamento.
        //
        // así estamos sendo desleixados aquí e ampliamos o intervalo de erros nun factor de 10.
        // isto aumentará a taxa de falsos negativos, pero só moi,*moi* lixeiramente;
        // só pode importar notablemente cando a mantisa supera os 60 bits.
        //
        // SEGURIDADE: `len=0`, polo que a obriga de inicializar esta memoria é trivial.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // render partes integrantes.
    // o erro é totalmente fraccionado, polo que non necesitamos comprobalo nesta parte.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // díxitos aínda sen renderizar
    loop {
        // sempre temos polo menos un díxito para render invariantes:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (dedúcese que `remainder = vint % 10^(kappa+1)`)
        //
        //

        // divide `remainder` por `10^kappa`.ambos son escalados por `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // o buffer está cheo?executa o pase de redondeo co resto.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SEGURIDADE: inicializamos `len` moitos bytes.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // rompe o lazo cando representamos todos os díxitos integrais.
        // o número exacto de díxitos é `max_kappa + 1` como `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // restaurar invariantes
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // render partes fraccionarias.
    //
    // en principio podemos continuar ata o último díxito dispoñible e comprobar a precisión.
    // desgraciadamente estamos a traballar cos enteiros de tamaño finito, polo que precisamos algún criterio para detectar o desbordamento.
    // V8 usa `remainder > err`, que se fai falso cando os primeiros díxitos significativos de `i` de `v - 1 ulp` e `v` difiren.
    // non obstante, isto rexeita demasiados datos válidos doutro xeito.
    //
    // xa que a fase posterior ten unha detección de desbordamento correcta, usamos un criterio máis axustado:
    // continuamos ata que `err` supera `10^kappa / 2`, de xeito que o intervalo entre `v - 1 ulp` e `v + 1 ulp` contén definitivamente dúas ou máis representacións redondeadas.
    //
    // isto é igual ás dúas primeiras comparacións de `possibly_round`, como referencia.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariantes, onde `m = max_kappa + 1` (número de díxitos na parte integral):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // non se desbordará, `2^e * 10 < 2^64`
        err *= 10; // non se desbordará, `err * 10 < 2^e * 5 < 2^64`

        // divide `remainder` por `10^kappa`.
        // ambos son escalados por `2^e / 10^kappa`, polo que este último está implícito aquí.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // o buffer está cheo?executa o pase de redondeo co resto.
        if i == len {
            // SEGURIDADE: inicializamos `len` moitos bytes.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // restaurar invariantes
        remainder = r;
    }

    // O cálculo adicional é inútil (o `possibly_round` definitivamente falla), así que renunciamos.
    return None;

    // xeramos todos os díxitos solicitados de `v`, que deben ser iguais aos díxitos correspondentes de `v - 1 ulp`.
    // agora comprobamos se hai unha representación única compartida por `v - 1 ulp` e `v + 1 ulp`;isto pode ser igual aos díxitos xerados ou á versión redondeada deses díxitos.
    //
    // se o intervalo contén varias representacións da mesma lonxitude, non podemos estar seguros e deberiamos devolver `None`.
    //
    // todos os argumentos aquí están escalados polo valor común (pero implícito) `k`, de xeito que:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SEGURIDADE: débense inicializar os primeiros bytes `len` de `buf`.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 cubo | 1 cubo |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (para a referencia, a liña de puntos indica o valor exacto para posibles representacións nun determinado número de díxitos.)
        //
        //
        // o erro é demasiado grande para que haxa polo menos tres representacións posibles entre `v - 1 ulp` e `v + 1 ulp`.
        // non podemos determinar cal é a correcta.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 cubo | 1 cubo |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // de feito, 1/2 ulp é suficiente para introducir dúas representacións posibles.
        // (lembre que necesitamos unha representación única tanto para `v - 1 ulp` como para "v + 1 ulp".) isto non se desbordará, xa que `ulp < ten_kappa` dende a primeira comprobación.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 cubo | 1 cubo |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // se `v + 1 ulp` está máis preto da representación redondeada (que xa está en `buf`), entón podemos regresar con seguridade.
        // teña en conta que `v - 1 ulp`*pode* ser inferior á representación actual, pero como `1 ulp < 10^kappa / 2`, esta condición é suficiente:
        // a distancia entre `v - 1 ulp` e a representación actual non pode exceder `10^kappa / 2`.
        //
        // a condición é igual a `remainder + ulp < 10^kappa / 2`.
        // xa que isto pode desbordarse facilmente, primeiro comproba se `remainder < 10^kappa / 2`.
        // xa comprobamos que `ulp < 10^kappa / 2`, polo que mentres `10^kappa` non rebordou ao cabo, a segunda verificación está ben.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SEGURIDADE: o noso interlocutor inicializou esa memoria.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------resto------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 cubo | 1 cubo |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // por outra banda, se `v - 1 ulp` está máis preto da representación redondeada, deberiamos redondear e volver.
        // pola mesma razón non necesitamos comprobar `v + 1 ulp`.
        //
        // a condición é igual a `remainder - ulp >= 10^kappa / 2`.
        // de novo comprobamos primeiro se `remainder > ulp` (teña en conta que este non é `remainder >= ulp`, xa que `10^kappa` nunca é cero).
        //
        // teña en conta tamén que `remainder - ulp <= 10^kappa`, polo que a segunda comprobación non reborda.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SEGURIDADE: o noso interlocutor debe ter inicializado esa memoria.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // só engade un díxito adicional cando se nos solicite a precisión fixa.
                // tamén necesitamos comprobar que, se o búfer orixinal estaba baleiro, o díxito adicional só se pode engadir cando `exp == limit` (caso edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SEGURIDADE: nós e o noso interlocutor inicializamos esa memoria.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // se non, estamos condenados (é dicir, algúns valores entre `v - 1 ulp` e `v + 1 ulp` redondean cara abaixo e outros redondean cara arriba) e renunciamos.
        //
        None
    }
}

/// A implementación do modo exacto e fixo para Grisu con Dragon fallback.
///
/// Isto debería usarse na maioría dos casos.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SEGURIDADE: o comprobador de préstamos non é o suficientemente intelixente como para permitirnos usar `buf`
    // no segundo branch, así que lavamos a vida aquí.
    // Pero só reutilizamos `buf` se `format_exact_opt` devolveu `None` polo que está ben.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}