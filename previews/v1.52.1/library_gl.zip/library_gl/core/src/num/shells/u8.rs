//! Constantes para o tipo enteiro sen asinar de 8 bits.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! O novo código debería empregar as constantes asociadas directamente no tipo primitivo.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }