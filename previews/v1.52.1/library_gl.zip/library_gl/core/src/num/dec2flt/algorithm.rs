//! Os distintos algoritmos do papel.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Número de bits significativos en Fp
const P: u32 = 64;

// Simplemente almacenamos a mellor aproximación para *todos* expoñentes, polo que se pode omitir a variable "h" e as condicións asociadas.
// Isto cambia o rendemento por un par de kilobytes de espazo.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Na maioría das arquitecturas, as operacións de punto flotante teñen un tamaño de bit explícito, polo tanto a precisión do cálculo determínase por operación.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// En x86, a FPU x87 úsase para operacións flotantes se as extensións SSE/SSE2 non están dispoñibles.
// O x87 FPU funciona con 80 bits de precisión de xeito predeterminado, o que significa que as operacións redondearanse a 80 bits facendo que se produza un redondeo dobre cando os valores se representen finalmente como
//
// 32/64 valores flotantes de bits.Para superalo, pódese configurar a palabra de control FPU para que os cálculos se realicen coa precisión desexada.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Unha estrutura usada para preservar o valor orixinal da palabra de control FPU, de xeito que se pode restaurar cando se deixa caer a estrutura.
    ///
    ///
    /// O x87 FPU é un rexistro de 16 bits cuxos campos son os seguintes:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// A documentación de todos os campos está dispoñible no Manual do programador de software IA-32 Architectures (volume 1).
    ///
    /// O único campo relevante para o seguinte código é PC, Control de precisión.
    /// Este campo determina a precisión das operacións realizadas pola FPU.
    /// Pode axustarse a:
    ///  - 0b00, precisión única, é dicir, 32 bits
    ///  - 0b10, dobre precisión, é dicir, 64 bits
    ///  - 0b11, dobre precisión estendida, é dicir, 80 bits (estado predeterminado) O valor 0b01 está reservado e non debe usarse.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SEGURIDADE: a instrución `fldcw` foi auditada para poder traballar correctamente
        // calquera `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Estamos a usar a sintaxe ATT para admitir LLVM 8 e LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Establece o campo de precisión da FPU en `T` e devolve un `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Calcule o valor do campo de control de precisión adecuado para `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bits
            8 => 0x0200, // 64 bits
            _ => 0x0300, // por defecto, 80 bits
        };

        // Obteña o valor orixinal da palabra de control para restaurala máis tarde, cando a estrutura `FPUControlWord` caia SEGURIDADE: a instrución `fnstcw` foi auditada para poder funcionar correctamente con calquera `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Estamos a usar a sintaxe ATT para admitir LLVM 8 e LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Estableza a palabra de control na precisión desexada.
        // Isto conséguese enmascarando a vella precisión (bits 8 e 9, 0x300) e substituíndoa pola bandeira de precisión calculada anteriormente.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// O camiño rápido de Bellerophon usando números enteiros e flotantes de tamaño máquina.
///
/// Isto extráese nunha función separada para que se poida intentar antes de construír un bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Comparamos o valor exacto con MAX_SIG preto do final, isto é só un rexeitamento rápido e barato (e tamén libera o resto do código de preocuparse polo desbordamento).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // O camiño rápido depende fundamentalmente de que a aritmética estea redondeada ao número correcto de bits sen redondeo intermedio.
    // En x86 (sen SSE ou SSE2) isto require que se cambie a precisión da pila x87 FPU para que redondee directamente a bit 64/32.
    // A función `set_precision` encárgase de establecer a precisión nas arquitecturas que requiren axustala cambiando o estado global (como a palabra de control do x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // O caso e <0 non se pode dobrar no outro branch.
    // As potencias negativas dan lugar a unha parte fraccionaria en binario que se repite, que son redondeadas, o que provoca erros reais (e ás veces bastante significativos!) No resultado final.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// O algoritmo Bellerophon é un código trivial xustificado por unha análise numérica non trivial.
///
/// Redondea "f" a un flotante con significado de 64 bits e multiplícao pola mellor aproximación de `10^e` (no mesmo formato de punto flotante).A miúdo isto é suficiente para obter o resultado correcto.
/// Non obstante, cando o resultado está preto da metade do camiño entre dous flotadores (ordinary) adxacentes, o erro de redondeo composto ao multiplicar dúas aproximacións significa que o resultado pode estar apagado por uns bits.
/// Cando isto ocorre, o algoritmo iterativo R arranxa as cousas.
///
/// O "close to halfway" ondulado á man faise máis preciso mediante a análise numérica no traballo.
/// En palabras de Clinger:
///
/// > Slop, expresado en unidades do bit menos significativo, é un límite inclusivo para o erro
/// > acumulado durante o cálculo en coma flotante da aproximación a f * 10 ^ e.(Slop é
/// > non é un límite para o verdadeiro erro, pero limita a diferenza entre a aproximación z e
/// > a mellor aproximación posible que emprega p bits de significando.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Os casos abs(e) <log5(2^N) están en fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // ¿A inclinación é o suficientemente grande como para marcar a diferenza ao redondear a n bits?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Un algoritmo iterativo que mellora unha aproximación en coma flotante de `f * 10^e`.
///
/// Cada iteración achega unha unidade no último lugar, o que, por suposto, tarda terriblemente en converxer se `z0` está incluso levemente apagado.
/// Afortunadamente, cando se usa como alternativa para Bellerophon, a aproximación inicial está desactivada como máximo por un ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Atopar enteiros positivos `x`, `y` tal que `x / y` sexa exactamente `(f *10^e) / (m* 2^k)`.
        // Isto non só evita tratar os signos de `e` e `k`, tamén eliminamos a potencia de dous comúns a `10^e` e `2^k` para facer os números máis pequenos.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Isto escríbese un pouco incómodo porque os nosos bignums non admiten números negativos, polo que empregamos a información de valor absoluto + signo.
        // A multiplicación con m_digits non pode desbordarse.
        // Se `x` ou `y` son o suficientemente grandes como para preocuparnos polo desbordamento, tamén son o suficientemente grandes como para que `make_ratio` reducise a fracción nun factor de 2 ^ 64 ou máis.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Non necesite máis x, garde un clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Aínda necesito y, fai unha copia.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Dados `x = f` e `y = m` onde `f` representan cifras decimais de entrada como de costume e `m` é o significado dunha aproximación en coma flotante, faga a relación `x / y` igual a `(f *10^e) / (m* 2^k)`, posiblemente reducida por unha potencia de dous.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, agás que reducimos a fracción por algunha potencia de dous.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Isto non pode desbordarse porque require `e` positivo e `k` negativo, o que só pode ocorrer para valores extremadamente próximos a 1, o que significa que `e` e `k` serán relativamente pequenos.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Tampouco isto pode desbordarse, ver arriba.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), reducíndose de novo cunha potencia común de dous.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Conceptualmente, o algoritmo M é o xeito máis sinxelo de converter un decimal a float.
///
/// Formamos unha proporción que é igual a `f * 10^e` e, a continuación, arroxando potencias de dous ata dar un significado flotante válido.
/// O expoñente binario `k` é o número de veces que multiplicamos o numerador ou o denominador por dous, é dicir, en todo momento `f *10^e` é igual a `(u / v)* 2^k`.
/// Cando descubrimos o significado, só precisamos redondear inspeccionando o resto da división, que se fai nas funcións de axuda máis abaixo.
///
///
/// Este algoritmo é super lento, incluso coa optimización descrita en `quick_start()`.
/// Non obstante, é o máis sinxelo dos algoritmos para adaptarse a resultados de desbordamento, desbordamento e subnormais.
/// Esta implementación faise cargo cando Bellerophon e Algorithm R están desbordados.
/// Detectar o desbordamento e o desbordamento é sinxelo: a relación aínda non é un significado dentro do rango, pero alcanzouse o expoñente minimum/maximum.
/// No caso de desbordamento, simplemente devolvemos o infinito.
///
/// Manexar o subflujo e as subnormais é máis complicado.
/// Un gran problema é que, co expoñente mínimo, a relación aínda pode ser demasiado grande para un significante.
/// Vexa underflow() para máis detalles.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME posible optimización: xeneraliza big_to_fp para que poidamos facer o equivalente a fp_to_float(big_to_fp(u)) aquí, só sen o dobre redondeo.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Temos que parar no máximo expoñente, se agardamos ata `k < T::MIN_EXP_INT`, entón estariamos apagados por un factor de dous.
            // Por desgraza, isto significa que temos que facer un caso especial con números normais co expoñente mínimo.
            // FIXME atopa unha formulación máis elegante, pero executa a proba `tiny-pow10` para asegurarte de que é realmente correcta.
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Salta a maioría das M iteracións do algoritmo comprobando a lonxitude do bit.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // A lonxitude de bits é unha estimación do logaritmo de base dous e log(u / v) = log(u), log(v).
    // A estimación está desactivada como máximo 1, pero sempre é unha infravaloración, polo que o erro en log(u) e log(v) ten o mesmo signo e cancélase (se ambos son grandes).
    // Polo tanto, o erro para log(u / v) tamén o é.
    // A proporción de destino é aquela onde u/v está nun significand dentro do rango.Así, a nosa condición de terminación é log2(u / v) sendo os bits significativos e plus/minus un.
    // Fixarse no segundo bit podería mellorar a estimación e evitar algunhas divisións máis.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Influencia ou subnormal.Déixeo á función principal.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Desbordamento.Déixeo á función principal.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // A proporción non é un significado dentro do rango co expoñente mínimo, polo que necesitamos redondear o exceso de bits e axustar o expoñente en consecuencia.
    // O valor real agora é así:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(representado por rem)
    //
    // Polo tanto, cando os bits redondeados son!= 0.5 ULP, deciden o redondeo por si mesmos.
    // Cando son iguais e o resto non é cero, o valor aínda debe ser redondeado cara arriba.
    // Só cando os bits redondeados son 1/2 e o resto é cero, temos unha situación igualada.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Ordinaria redonda ao igual, ofuscada por ter que redondear en función do resto dunha división.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}