//! Funcións de utilidade para bignums que non teñen demasiado sentido converterse en métodos.

// FIXME O nome deste módulo é un pouco lamentable, xa que outros módulos tamén importan `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Proba se truncar todos os bits menos significativos que `ones_place` introduce un erro relativo menor, igual ou maior que 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Se todos os bits restantes son cero, é= 0.5 ULP, se non> 0.5 Se non hai máis bits (half_bit==0), o seguinte tamén devolve igual.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Converte unha cadea ASCII que contén só díxitos decimais a un `u64`.
///
/// Non realiza comprobacións de desbordamento nin de caracteres inválidos, polo que se o interlocutor non ten coidado, o resultado é falso e pode panic (aínda que non será `unsafe`).
/// Ademais, as cadeas baleiras trátanse como cero.
/// Esta función existe porque
///
/// 1. usar `FromStr` en `&[u8]` require `from_utf8_unchecked`, que é malo, e
/// 2. xuntar os resultados de `integral.parse()` e `fractional.parse()` é máis complicado que toda esta función.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Converte unha cadea de díxitos ASCII nun bignum.
///
/// Do mesmo xeito que `from_str_unchecked`, esta función depende do analizador para eliminar sen cifras.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Desenvolve un bignum nun enteiro de 64 bits.Panics se o número é demasiado grande.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Extrae un rango de bits.

/// O índice 0 é o bit menos significativo e o rango está medio aberto como de costume.
/// Panics se se lle pide que extraia máis bits dos que caben no tipo de retorno.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}