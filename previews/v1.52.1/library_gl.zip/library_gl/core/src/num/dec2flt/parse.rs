//! Validación e descomposición dunha cadea decimal da forma:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Noutras palabras, sintaxe de punto flotante estándar, con dúas excepcións: sen signo e sen manexo de "inf" e "NaN".Estes son manexados pola función de controlador (super::dec2flt).
//!
//! Aínda que recoñecer entradas válidas é relativamente sinxelo, este módulo tamén ten que rexeitar as innumerables variacións inválidas, nunca panic, e realizar numerosas comprobacións nas que os outros módulos dependen e non panic (ou desbordamento) á súa vez.
//!
//! Para empeorar as cousas, todo o que ocorre nun só paso sobre a entrada.
//! Entón, teña coidado ao modificar calquera cousa e comprobe con outros módulos.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// As partes interesantes dunha cadea decimal.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// O expoñente decimal, con menos de 18 díxitos decimais.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Comproba se a cadea de entrada é un número de punto flotante válido e, se é así, localiza a parte integral, a parte fraccionada e o expoñente.
/// Non manexa sinais.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Sen díxitos antes do 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Precisamos polo menos un só díxito antes ou despois do punto.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Trastos de lixo tras unha parte fraccionada
            }
        }
        _ => Invalid, // Lixo final despois da cadea do primeiro díxito
    }
}

/// Talla os díxitos decimais ata o primeiro carácter que non conteña cifras.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Extracción de compoñentes e comprobación de erros.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Lixo ao final do expoñente
    }
    if number.is_empty() {
        return Invalid; // Exponente baleiro
    }
    // Neste momento, certamente temos unha cadea de díxitos válida.Pode ser demasiado longo para colocalo nun `i64`, pero se é tan enorme, a entrada é certamente nula ou infinita.
    // Dado que cada cero dos díxitos decimais só axusta o expoñente en +/-1, en exp=10 ^ 18 a entrada tería que ser de 17 exabytes (!) de ceros para chegar incluso remotamente a ser finita.
    //
    // Este non é exactamente un caso de uso que necesitamos atender.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}