macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// O menor valor que pode representar este tipo enteiro.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// O maior valor que pode representar este tipo enteiro.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// O tamaño deste tipo enteiro en bits.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Converte unha porción de cadea nunha base dada nun número enteiro.
        ///
        /// Espérase que a cadea sexa un signo `+` opcional seguido de díxitos.
        ///
        /// O espazo en branco líder e final representa un erro.
        /// Os díxitos son un subconxunto destes caracteres, dependendo de `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Esta función panics se `radix` non está no rango de 2 a 36.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Devolve o número de uns na representación binaria de `self`.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Devolve o número de ceros na representación binaria de `self`.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Devolve o número de ceros á fronte na representación binaria de `self`.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Devolve o número de ceros finais na representación binaria de `self`.
        ///
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Devolve o número de principais na representación binaria de `self`.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Devolve o número de finais na representación binaria de `self`.
        ///
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Move os bits á esquerda por unha cantidade especificada, `n`, axustando os bits truncados ao final do enteiro resultante.
        ///
        ///
        /// Ten en conta que esta non é a mesma operación que o operador de cambio `<<`.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Despraza os bits cara á dereita por unha cantidade especificada, `n`, axustando os bits truncados ao comezo do enteiro resultante.
        ///
        ///
        /// Ten en conta que esta non é a mesma operación que o operador de cambio `>>`.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Inverte a orde de bytes do enteiro.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// imos m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Inverte a orde de bits no número enteiro.
        /// O bit menos significativo convértese no bit máis significativo, o segundo bit menos significativo convértese no segundo bit máis significativo, etc.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// imos m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Converte un enteiro de endian grande a endianness do destino.
        ///
        /// En big endian este é un no-op.
        /// No endian pequeno intercambianse os bytes.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// se cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } máis {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Converte un enteiro de endian pequeno a endianness do destino.
        ///
        /// En endian pouco isto é un non-op.
        /// No endian grande intercambianse os bytes.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// se cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } máis {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Converte `self` en endian grande desde o endianness do destino.
        ///
        /// En big endian este é un no-op.
        /// No endian pequeno intercambianse os bytes.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// se cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } else { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // ou non ser?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Converte `self` en pequeno endian desde o endianness do destino.
        ///
        /// En endian pouco isto é un non-op.
        /// No endian grande intercambianse os bytes.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// se cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } else { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Comprobouse a suma enteira.
        /// Calcula `self + rhs`, devolve `None` se se produciu un desbordamento.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Adición enteira sen comprobar.Calcula `self + rhs`, supoñendo que non se pode producir un desbordamento.
        /// Isto resulta nun comportamento indefinido cando
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Subtracción enteira comprobada.
        /// Calcula `self - rhs`, devolve `None` se se produciu un desbordamento.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Restación enteira sen comprobar.Calcula `self - rhs`, supoñendo que non se pode producir un desbordamento.
        /// Isto resulta nun comportamento indefinido cando
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Multiplicación enteira comprobada.
        /// Calcula `self * rhs`, devolve `None` se se produciu un desbordamento.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Multiplicación de números enteiros sen comprobar.Calcula `self * rhs`, supoñendo que non se pode producir un desbordamento.
        /// Isto resulta nun comportamento indefinido cando
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Comprobouse a división enteira.
        /// Calcula `self / rhs`, devolve `None` se `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SEGURIDADE: div por cero comprobouse máis arriba e os tipos sen asinar non teñen outro
                // modos de fallo para a división
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Comprobada división euclidiana.
        /// Calcula `self.div_euclid(rhs)`, devolve `None` se `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Comprobouse o resto enteiro.
        /// Calcula `self % rhs`, devolve `None` se `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SEGURIDADE: div por cero comprobouse máis arriba e os tipos sen asinar non teñen outro
                // modos de fallo para a división
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Módulo euclidiano comprobado.
        /// Calcula `self.rem_euclid(rhs)`, devolve `None` se `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Negación comprobada.Calcula `-self`, devolve `None` a menos que `self==
        /// 0`.
        ///
        /// Teña en conta que a negación de calquera enteiro positivo desbordará.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Revisou a quenda á esquerda.
        /// Calcula `self << rhs`, devolve `None` se `rhs` é maior ou igual ao número de bits en `self`.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Comprobou quenda á dereita.
        /// Calcula `self >> rhs`, devolve `None` se `rhs` é maior ou igual ao número de bits en `self`.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Potenciación comprobada.
        /// Calcula `self.pow(exp)`, devolve `None` se se produciu un desbordamento.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // xa que exp!=0, finalmente o exp debe ser 1.
            // Trata o bit final do expoñente por separado, xa que non é necesario cadrar a base despois e pode provocar un desbordamento innecesario.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Adición enteira saturada.
        /// Calcula `self + rhs`, saturándose nos límites numéricos en lugar de desbordarse.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Resta de números enteiros saturados.
        /// Calcula `self - rhs`, saturándose nos límites numéricos en lugar de desbordarse.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Multiplicación de números enteiros saturados.
        /// Calcula `self * rhs`, saturándose nos límites numéricos en lugar de desbordarse.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Potenciación enteira saturada.
        /// Calcula `self.pow(exp)`, saturándose nos límites numéricos en lugar de desbordarse.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Engadido engadido (modular).
        /// Calcula `self + rhs`, envolvéndose no límite do tipo.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Envolvendo a resta (modular).
        /// Calcula `self - rhs`, envolvéndose no límite do tipo.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Envolvendo a multiplicación (modular).
        /// Calcula `self * rhs`, envolvéndose no límite do tipo.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// Ten en conta que este exemplo compártese entre tipos enteiros.
        /// O que explica por que se usa `u8` aquí.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Envoltura da división (modular).Computa `self / rhs`.
        /// A división axustada en tipos sen asinar é só unha división normal.
        /// Non hai forma de xestionar nunca.
        /// Esta función existe, de xeito que todas as operacións se contabilizan nas operacións de envoltura.
        ///
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Enrolando a división euclidiana.Computa `self.div_euclid(rhs)`.
        /// A división axustada en tipos sen asinar é só unha división normal.
        /// Non hai forma de xestionar nunca.
        /// Esta función existe, de xeito que todas as operacións se contabilizan nas operacións de envoltura.
        /// Xa que, para os enteiros positivos, todas as definicións comúns de división son iguais, isto é exactamente igual a `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Envolvendo o resto (modular).Computa `self % rhs`.
        /// O cálculo do resto envolvido en tipos sen asinar é só o cálculo normal do resto.
        ///
        /// Non hai forma de xestionar nunca.
        /// Esta función existe, de xeito que todas as operacións se contabilizan nas operacións de envoltura.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Envolvendo o módulo euclidiano.Computa `self.rem_euclid(rhs)`.
        /// O cálculo do módulo axustado en tipos sen asinar é só o cálculo normal do resto.
        /// Non hai forma de xestionar nunca.
        /// Esta función existe, de xeito que todas as operacións se contabilizan nas operacións de envoltura.
        /// Xa que, para os enteiros positivos, todas as definicións comúns de división son iguais, isto é exactamente igual a `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Envolvendo a negación (modular).
        /// Calcula `-self`, envolvéndose no límite do tipo.
        ///
        /// Dado que os tipos sen asinar non teñen equivalentes negativos, todas as aplicacións desta función axustaranse (excepto `-0`).
        /// Para valores inferiores ao máximo do tipo asinado correspondente, o resultado é o mesmo que emitir o valor asinado correspondente.
        ///
        /// Calquera valor maior equivale a `MAX + 1 - (val - MAX - 1)` onde `MAX` é o máximo do tipo asinado correspondente.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// Ten en conta que este exemplo compártese entre tipos enteiros.
        /// O que explica por que se usa `i8` aquí.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic sen desprazamento á esquerda;
        /// produce `self << mask(rhs)`, onde `mask` elimina os bits de alta orde de `rhs` que farían que o cambio exceda o ancho de bits do tipo.
        ///
        /// Teña en conta que isto non é * o mesmo que xirar á esquerda;o RHS dun desprazamento á esquerda está restrinxido ao rango do tipo, en lugar de que os bits desprazados fóra do LHS se devolvan ao outro extremo.
        /// Os tipos enteiros primitivos implementan unha función [`rotate_left`](Self::rotate_left), que pode ser o que desexa.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SEGURIDADE: o enmascaramento polo tamaño do bits asegura que non cambiamos
            // fóra dos límites
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic desprazamento de bits a dereita á dereita;
        /// produce `self >> mask(rhs)`, onde `mask` elimina os bits de alta orde de `rhs` que farían que o cambio exceda o ancho de bits do tipo.
        ///
        /// Teña en conta que isto non é * o mesmo que xirar á dereita;o RHS dun desprazamento á dereita está restrinxido ao rango do tipo, en lugar de que os bits desprazados fóra do LHS se devolvan ao outro extremo.
        /// Os tipos enteiros primitivos implementan todos unha función [`rotate_right`](Self::rotate_right), que pode ser o que quere.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SEGURIDADE: o enmascaramento polo tamaño do bits asegura que non cambiamos
            // fóra dos límites
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Expansión de (modular) envolvente.
        /// Calcula `self.pow(exp)`, envolvéndose no límite do tipo.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // xa que exp!=0, finalmente o exp debe ser 1.
            // Trata o bit final do expoñente por separado, xa que non é necesario cadrar a base despois e pode provocar un desbordamento innecesario.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Calcula `self` + `rhs`
        ///
        /// Devolve unha tupla da adición xunto cun booleano que indica se se produciría un desbordamento aritmético.
        /// Se se producise un desbordamento, devólvese o valor axustado.
        ///
        /// # Examples
        ///
        /// Uso básico
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Calcula `self`, `rhs`
        ///
        /// Devolve unha tupla da resta xunto cun booleano que indica se se produciría un desbordamento aritmético.
        /// Se se producise un desbordamento, devólvese o valor axustado.
        ///
        /// # Examples
        ///
        /// Uso básico
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Calcula a multiplicación de `self` e `rhs`.
        ///
        /// Devolve unha tupla da multiplicación xunto cun booleano que indica se se produciría un desbordamento aritmético.
        /// Se se producise un desbordamento, devólvese o valor axustado.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// Ten en conta que este exemplo compártese entre tipos enteiros.
        /// O que explica por que se usa `u32` aquí.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Calcula o divisor cando `self` está dividido por `rhs`.
        ///
        /// Devolve unha tupla do divisor xunto cun booleano que indica se se produciría un desbordamento aritmético.
        /// Teña en conta que para os enteiros sen asinar nunca se produce desbordamento, polo que o segundo valor sempre é `false`.
        ///
        /// # Panics
        ///
        /// Esta función será panic se `rhs` é 0.
        ///
        /// # Examples
        ///
        /// Uso básico
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Calcula o cociente da división euclidiana `self.div_euclid(rhs)`.
        ///
        /// Devolve unha tupla do divisor xunto cun booleano que indica se se produciría un desbordamento aritmético.
        /// Teña en conta que para os enteiros sen asinar nunca se produce desbordamento, polo que o segundo valor sempre é `false`.
        /// Xa que, para os enteiros positivos, todas as definicións comúns de división son iguais, isto é exactamente igual a `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Esta función será panic se `rhs` é 0.
        ///
        /// # Examples
        ///
        /// Uso básico
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Calcula o resto cando `self` está dividido por `rhs`.
        ///
        /// Devolve unha tupla do resto despois de dividila xunto cun booleano que indica se se produciría un desbordamento aritmético.
        /// Teña en conta que para os enteiros sen asinar nunca se produce desbordamento, polo que o segundo valor sempre é `false`.
        ///
        /// # Panics
        ///
        /// Esta función será panic se `rhs` é 0.
        ///
        /// # Examples
        ///
        /// Uso básico
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Calcula o resto `self.rem_euclid(rhs)` coma por división euclidiana.
        ///
        /// Devolve unha tupla do módulo despois de dividila xunto cun booleano que indica se se produciría un desbordamento aritmético.
        /// Teña en conta que para os enteiros sen asinar nunca se produce desbordamento, polo que o segundo valor sempre é `false`.
        /// Dado que, para os enteiros positivos, todas as definicións comúns de división son iguais, esta operación é exactamente igual a `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Esta función será panic se `rhs` é 0.
        ///
        /// # Examples
        ///
        /// Uso básico
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Négase a si mesmo de xeito desbordante.
        ///
        /// Devolve `!self + 1` mediante operacións de envoltura para devolver o valor que representa a negación deste valor sen asinar.
        /// Teña en conta que para os valores positivos sen asinar sempre se produce desbordamento, pero negar 0 non desborda.
        ///
        /// # Examples
        ///
        /// Uso básico
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Móvese á esquerda por bits `rhs`.
        ///
        /// Devolve unha tupla da versión desprazada de auto xunto cun booleano que indica se o valor de desprazamento foi maior ou igual ao número de bits.
        /// Se o valor de desprazamento é demasiado grande, entón o valor máscarase (N-1) onde N é o número de bits, e este valor úsase entón para realizar o desprazamento.
        ///
        /// # Examples
        ///
        /// Uso básico
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Cambia á dereita por bits `rhs`.
        ///
        /// Devolve unha tupla da versión desprazada de auto xunto cun booleano que indica se o valor de desprazamento foi maior ou igual ao número de bits.
        /// Se o valor de desprazamento é demasiado grande, entón o valor máscarase (N-1) onde N é o número de bits, e este valor úsase entón para realizar o desprazamento.
        ///
        /// # Examples
        ///
        /// Uso básico
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Elévase á potencia de `exp`, usando a exponenciación ao cadrado.
        ///
        /// Devolve unha tupla da potenciación xunto cun bool que indica se ocorreu un desbordamento.
        ///
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, verdadeiro));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Rascar espazo para almacenar os resultados de overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // xa que exp!=0, finalmente o exp debe ser 1.
            // Trata o bit final do expoñente por separado, xa que non é necesario cadrar a base despois e pode provocar un desbordamento innecesario.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Elévase á potencia de `exp`, usando a exponenciación ao cadrado.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // xa que exp!=0, finalmente o exp debe ser 1.
            // Trata o bit final do expoñente por separado, xa que non é necesario cadrar a base despois e pode provocar un desbordamento innecesario.
            //
            //
            acc * base
        }

        /// Realiza división euclidiana.
        ///
        /// Xa que, para os enteiros positivos, todas as definicións comúns de división son iguais, isto é exactamente igual a `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Esta función será panic se `rhs` é 0.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Calcula o mínimo resto de `self (mod rhs)`.
        ///
        /// Xa que, para os enteiros positivos, todas as definicións comúns de división son iguais, isto é exactamente igual a `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Esta función será panic se `rhs` é 0.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Devolve `true` se e só se `self == 2^k` para algúns `k`.
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Devolve un menos que a seguinte potencia de dous.
        // (Para 8u8 a seguinte potencia de dous é 8u8 e para 6u8 é 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Este método non pode desbordarse, xa que nos casos de desbordamento `next_power_of_two` acaba por devolver o valor máximo do tipo e pode devolver 0 por 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SEGURIDADE: Porque `p > 0`, non pode consistir completamente en ceros ao principio.
            // Iso significa que o cambio sempre está dentro dos límites e algúns procesadores (como intel pre-haswell) teñen intrínsecos ctlz máis eficientes cando o argumento non é cero.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Devolve a menor potencia de dúas maior ou igual a `self`.
        ///
        /// Cando o valor de retorno desborda (é dicir, `self > (1 << (N-1))` para o tipo `uN`), panics no modo de depuración e o valor de retorno axústase a 0 no modo de liberación (a única situación na que o método pode devolver 0).
        ///
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Devolve a menor potencia de dúas maior ou igual a `n`.
        /// Se a seguinte potencia de dous é maior que o valor máximo do tipo, devólvese `None`, se non, a potencia de dous envólvese en `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Devolve a menor potencia de dúas maior ou igual a `n`.
        /// Se a seguinte potencia de dous é maior que o valor máximo do tipo, o valor de retorno axústase a `0`.
        ///
        ///
        /// # Examples
        ///
        /// Uso básico:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Devolve a representación de memoria deste número enteiro como unha matriz de bytes en orde de bytes X-X de big-endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Devolve a representación de memoria deste número enteiro como unha matriz de bytes en orde de bytes pouco endiana.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Devolve a representación de memoria deste enteiro como unha matriz de bytes en orde de bytes nativos.
        ///
        /// A medida que se emprega o sistema nativo da plataforma de destino, o código portátil debería usar [`to_be_bytes`] ou [`to_le_bytes`], segundo corresponda.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, se cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } máis {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SEGURIDADE: son constante porque os números enteiros son tipos de datos antigos e simples para que poidamos sempre
        // transmúteos a matrices de bytes
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SEGURIDADE: os enteiros son tipos de datos antigos e simples polo que sempre podemos transmutalos a
            // matrices de bytes
            unsafe { mem::transmute(self) }
        }

        /// Devolve a representación de memoria deste enteiro como unha matriz de bytes en orde de bytes nativos.
        ///
        ///
        /// [`to_ne_bytes`] debería preferirse antes que isto sempre que sexa posible.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// let bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, se cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } máis {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SEGURIDADE: os enteiros son tipos de datos antigos e simples polo que sempre podemos transmutalos a
            // matrices de bytes
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Crea un valor enteiro endian nativo a partir da súa representación como matriz de bytes en endian grande.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// usa std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * entrada=descanso;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Crea un valor enteiro endian nativo a partir da súa representación como matriz de bytes en endian pequeno.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// usa std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * entrada=descanso;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Crear un valor enteiro nativo endiano a partir da súa representación de memoria como unha matriz de bytes en endianness nativo.
        ///
        /// A medida que se emprega o sistema nativo da plataforma de destino, é probable que o código portátil queira usar [`from_be_bytes`] ou [`from_le_bytes`], segundo corresponda.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } máis {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// usa std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * entrada=descanso;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SEGURIDADE: son constante porque os números enteiros son tipos de datos antigos e simples para que poidamos sempre
        // transmutalos
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SEGURIDADE: os números enteiros son tipos de datos simples e antigos polo que sempre podemos transmutalos
            unsafe { mem::transmute(bytes) }
        }

        /// O novo código debería preferilo usar
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Devolve o menor valor que pode representar este tipo enteiro.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// O novo código debería preferilo usar
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Devolve o maior valor que pode representar este tipo enteiro.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}