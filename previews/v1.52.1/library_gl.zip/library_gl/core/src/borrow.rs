//! Un módulo para traballar con datos prestados.

#![stable(feature = "rust1", since = "1.0.0")]

/// Un trait para o préstamo de datos.
///
/// En Rust, é común proporcionar representacións diferentes dun tipo para diferentes casos de uso.
/// Por exemplo, a localización de almacenamento e a xestión dun valor pódense escoller específicamente como apropiadas para un uso particular mediante tipos de punteiro como [`Box<T>`] ou [`Rc<T>`].
/// Máis alá destes envoltorios xenéricos que se poden usar con calquera tipo, algúns tipos ofrecen facetas opcionais que ofrecen funcionalidades potencialmente custosas.
/// Un exemplo para este tipo é [`String`] que engade a posibilidade de estender unha cadea ao [`str`] básico.
/// Isto require manter información adicional innecesaria para unha cadea simple e inmutable.
///
/// Estes tipos proporcionan acceso aos datos subxacentes mediante referencias ao tipo deses datos.Dise que están "prestados como" ese tipo.
/// Por exemplo, un [`Box<T>`] pódese tomar prestado como `T` mentres que un [`String`] pódese tomar prestado como `str`.
///
/// Os tipos expresan que se poden tomar prestados como algún tipo `T` implementando `Borrow<T>`, proporcionando unha referencia a un `T` no método [`borrow`] do trait.Un tipo é libre para pedir prestado como varios tipos diferentes.
/// Se desexa prestar mutualmente como o tipo-permitindo a modificación dos datos subxacentes, pode implementar [`BorrowMut<T>`].
///
/// Ademais, cando se fornecen implementacións para traits adicionais, cómpre considerar se deben comportarse idénticamente aos do tipo subxacente como consecuencia de actuar como representación dese tipo subxacente.
/// O código xenérico normalmente usa `Borrow<T>` cando se apoia no comportamento idéntico destas implementacións adicionais de trait.
/// É probable que estes traits aparezan como trait bounds adicionais.
///
/// En particular `Eq`, `Ord` e `Hash` deben ser equivalentes para os valores prestados e de propiedade: `x.borrow() == y.borrow()` debería dar o mesmo resultado que `x == y`.
///
/// Se o código xenérico só ten que funcionar para todos os tipos que poden proporcionar unha referencia ao tipo relacionado `T`, moitas veces é mellor usar [`AsRef<T>`] xa que máis tipos poden implementalo de forma segura.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Como recompilación de datos, [`HashMap<K, V>`] posúe claves e valores.Se os datos reais da clave están envoltos nun tipo de xestión de algún tipo, non obstante, aínda debería ser posible buscar un valor usando unha referencia aos datos da clave.
/// Por exemplo, se a clave é unha cadea, é probable que se almacene co mapa de hash como [`String`], mentres que debería ser posible buscar usando un [`&str`][`str`].
/// Así, `insert` necesita operar nun `String` mentres que `get` ten que ser capaz de usar un `&str`.
///
/// Lixeiramente simplificadas, as partes relevantes de `HashMap<K, V>` teñen este aspecto:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // campos omitidos
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Todo o mapa de hash é xenérico sobre unha clave tipo `K`.Debido a que estas claves almacénanse co mapa hash, este tipo ten que posuír os datos da clave.
/// Ao inserir un par clave-valor, o mapa recibe tal `K` e precisa atopar o balde de hash correcto e comprobar se a clave xa está presente en función dese `K`.Polo tanto, require `K: Hash + Eq`.
///
/// Non obstante, á hora de buscar un valor no mapa, ter que proporcionar unha referencia a un `K` xa que a clave para buscar requiriría sempre crear ese valor de propiedade.
/// Para as claves de cadea, isto significaría que hai que crear un valor `String` só para buscar casos nos que só hai un `str` dispoñible.
///
/// Pola contra, o método `get` é xenérico sobre o tipo de datos clave subxacente, chamado `Q` na sinatura do método anterior.Afirma que `K` toma prestado como `Q` requirindo ese `K: Borrow<Q>`.
/// Ao requirir adicionalmente `Q: Hash + Eq`, sinala o requisito de que `K` e `Q` teñan implementacións de `Hash` e `Eq` traits que produzan resultados idénticos.
///
/// A implementación de `get` depende en particular de implementacións idénticas de `Hash` ao determinar o depósito de hash da clave chamando a `Hash::hash` no valor `Q` aínda que inseriu a clave en función do valor de hash calculado a partir do valor `K`.
///
///
/// Como consecuencia, o mapa de hash rompe se un `K` que envolve un valor `Q` produce un hash diferente ao `Q`.Por exemplo, imaxina que tes un tipo que envolve unha cadea pero compara letras ASCII ignorando o seu caso:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Debido a que dous valores iguais precisan producir o mesmo valor hash, a implementación de `Hash` tamén debe ignorar as maiúsculas e minúsculas ASCII:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// ¿Pode `CaseInsensitiveString` implementar `Borrow<str>`?Certamente pode proporcionar unha referencia a unha porción de cadea a través da súa cadea de propiedade contida.
/// Pero debido a que a súa implementación `Hash` difire, compórtase de xeito diferente do `str` e, polo tanto, non debe implementar `Borrow<str>`.
/// Se quere permitir que outros accedan ao `str` subxacente, pode facelo a través de `AsRef<str>` que non leva ningún requisito adicional.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Préstamo inmutable dun valor de propiedade.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Un trait para o préstamo de datos mutualmente.
///
/// Como acompañante de [`Borrow<T>`], este trait permite que un tipo preste como tipo subxacente proporcionando unha referencia mutable.
/// Vexa [`Borrow<T>`] para obter máis información sobre o préstamo como outro tipo.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Préstase mutuamente a un valor de propiedade.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}