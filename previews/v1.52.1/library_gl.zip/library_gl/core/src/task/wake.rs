#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// Un `RawWaker` permite ao implementador dun executor de tarefas crear un [`Waker`] que proporcione un comportamento de espertar personalizado.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Consiste nun punteiro de datos e un [virtual function pointer table (vtable)][vtable] que personaliza o comportamento do `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Un punteiro de datos, que pode usarse para almacenar datos arbitrarios segundo o requira o executor.
    /// Isto podería ser por exemplo
    /// un punteiro borrado por tipo a un `Arc` asociado á tarefa.
    /// O valor deste campo pásase a todas as funcións que forman parte da táboa como primeiro parámetro.
    ///
    data: *const (),
    /// Táboa de punteiro de función virtual que personaliza o comportamento deste waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Crea un novo `RawWaker` a partir do punteiro `data` e `vtable` fornecidos.
    ///
    /// O punteiro `data` pode usarse para almacenar datos arbitrarios segundo o requira o executor.Isto podería ser por exemplo
    /// un punteiro borrado por tipo a un `Arc` asociado á tarefa.
    /// O valor deste punteiro pasarase a todas as funcións que forman parte do `vtable` como primeiro parámetro.
    ///
    /// O `vtable` personaliza o comportamento dun `Waker` que se crea a partir dun `RawWaker`.
    /// Para cada operación no `Waker`, chamarase á función asociada no `vtable` do `RawWaker` subxacente.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Unha táboa punteiro de función virtual (vtable) que especifica o comportamento dun [`RawWaker`].
///
/// O punteiro que se pasa a todas as funcións dentro do vtable é o punteiro `data` do obxecto [`RawWaker`] que se encerra.
///
/// As funcións dentro desta estrutura só se pretenden chamar ao punteiro `data` dun obxecto [`RawWaker`] correctamente construído desde a implementación [`RawWaker`].
/// Chamar a unha das funcións contidas usando calquera outro punteiro `data` causará un comportamento indefinido.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Esta función chamarase cando se clone o [`RawWaker`], por exemplo, cando se clone o [`Waker`] no que está almacenado o [`RawWaker`].
    ///
    /// A implementación desta función debe conservar todos os recursos necesarios para esta instancia adicional dun [`RawWaker`] e a tarefa asociada.
    /// Chamar ao `wake` no [`RawWaker`] resultante debería provocar a mesma tarefa que o [`RawWaker`] orixinal tería espertado.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Esta función chamarase cando se chama `wake` no [`Waker`].
    /// Debe espertar a tarefa asociada a este [`RawWaker`].
    ///
    /// A implementación desta función debe asegurarse de liberar os recursos asociados a esta instancia dun [`RawWaker`] e á tarefa asociada.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Esta función chamarase cando se chama `wake_by_ref` no [`Waker`].
    /// Debe espertar a tarefa asociada a este [`RawWaker`].
    ///
    /// Esta función é similar a `wake`, pero non debe consumir o punteiro de datos proporcionado.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Esta función chámase cando cae un [`RawWaker`].
    ///
    /// A implementación desta función debe asegurarse de liberar os recursos asociados a esta instancia dun [`RawWaker`] e á tarefa asociada.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Crea un novo `RawWakerVTable` a partir das funcións `clone`, `wake`, `wake_by_ref` e `drop` proporcionadas.
    ///
    /// # `clone`
    ///
    /// Esta función chamarase cando se clone o [`RawWaker`], por exemplo, cando se clone o [`Waker`] no que está almacenado o [`RawWaker`].
    ///
    /// A implementación desta función debe conservar todos os recursos necesarios para esta instancia adicional dun [`RawWaker`] e a tarefa asociada.
    /// Chamar ao `wake` no [`RawWaker`] resultante debería provocar a mesma tarefa que o [`RawWaker`] orixinal tería espertado.
    ///
    /// # `wake`
    ///
    /// Esta función chamarase cando se chama `wake` no [`Waker`].
    /// Debe espertar a tarefa asociada a este [`RawWaker`].
    ///
    /// A implementación desta función debe asegurarse de liberar os recursos asociados a esta instancia dun [`RawWaker`] e á tarefa asociada.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Esta función chamarase cando se chama `wake_by_ref` no [`Waker`].
    /// Debe espertar a tarefa asociada a este [`RawWaker`].
    ///
    /// Esta función é similar a `wake`, pero non debe consumir o punteiro de datos proporcionado.
    ///
    /// # `drop`
    ///
    /// Esta función chámase cando cae un [`RawWaker`].
    ///
    /// A implementación desta función debe asegurarse de liberar os recursos asociados a esta instancia dun [`RawWaker`] e á tarefa asociada.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// O `Context` dunha tarefa asíncrona.
///
/// Actualmente, `Context` só serve para proporcionar acceso a un `&Waker` que se pode usar para activar a tarefa actual.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Asegúrese de que future é a proba de cambios de varianza forzando a vida a ser invariante (as vidas de posición de argumento son contravariantes mentres que as de posición de retorno son covariantes).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Crea un novo `Context` a partir dun `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Devolve unha referencia ao `Waker` para a tarefa actual.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// Un `Waker` é un controlador para espertar unha tarefa avisando ao seu executor de que está listo para ser executado.
///
/// Este identificador encapsula unha instancia [`RawWaker`], que define o comportamento de espertar específico do executor.
///
///
/// Implementa [`Clone`], [`Send`] e [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Esperta a tarefa asociada a este `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // A chamada de espertar real é delegada a través dunha chamada de función virtual á implementación definida polo executor.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Non chame ao `drop`: o waker será consumido por `wake`.
        crate::mem::forget(self);

        // SEGURIDADE: isto é seguro porque `Waker::from_raw` é o único xeito
        // inicializar `wake` e `data` requirindo que o usuario recoñeza que se mantén o contrato de `RawWaker`.
        //
        unsafe { (wake)(data) };
    }

    /// Esperta a tarefa asociada a este `Waker` sen consumir o `Waker`.
    ///
    /// Isto é similar ao `wake`, pero pode ser lixeiramente menos eficiente no caso de que estea dispoñible un `Waker` de propiedade.
    /// Débese preferir este método que chamar ao `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // A chamada de espertar real é delegada a través dunha chamada de función virtual á implementación definida polo executor.
        //

        // SEGURIDADE: ver `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Devolve `true` se este `Waker` e outro `Waker` espertaron a mesma tarefa.
    ///
    /// Esta función funciona nun esforzo mellorado e pode resultar falsa incluso cando o `Waker` espertaría a mesma tarefa.
    /// Non obstante, se esta función devolve `true`, garantirase que o `Waker` despertará a mesma tarefa.
    ///
    /// Esta función úsase principalmente con fins de optimización.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Crea un novo `Waker` a partir de [`RawWaker`].
    ///
    /// O comportamento do `Waker` devolto non está definido se non se mantén o contrato definido na documentación de [`RawWaker`] e [`RawWakerVTable`].
    ///
    /// Polo tanto, este método non é seguro.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SEGURIDADE: isto é seguro porque `Waker::from_raw` é o único xeito
            // inicializar `clone` e `data` requirindo que o usuario recoñeza que se mantén o contrato de [`RawWaker`].
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SEGURIDADE: isto é seguro porque `Waker::from_raw` é o único xeito
        // inicializar `drop` e `data` requirindo que o usuario recoñeza que se mantén o contrato de `RawWaker`.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}