use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Unha interface para tratar con iteradores asíncronos.
///
/// Este é o fluxo principal trait.
/// Para obter máis información sobre o concepto de fluxos en xeral, consulte o [module-level documentation].
/// En particular, quizais queiras saber como [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// O tipo de elementos producidos polo fluxo.
    type Item;

    /// Tente extraer o seguinte valor deste fluxo, rexistrando a tarefa actual para o despertar se o valor aínda non está dispoñible e devolve `None` se o fluxo está esgotado.
    ///
    /// # Valor de devolución
    ///
    /// Hai varios valores de retorno posibles, cada un indicando un estado de fluxo distinto:
    ///
    /// - `Poll::Pending` significa que o seguinte valor deste fluxo aínda non está listo.As implementacións garantirán que a tarefa actual se notifique cando o seguinte valor estea listo.
    ///
    /// - `Poll::Ready(Some(val))` significa que o fluxo produciu con éxito un valor, `val`, e pode producir máis valores nas seguintes chamadas `poll_next`.
    ///
    /// - `Poll::Ready(None)` significa que o fluxo finalizou e que `poll_next` non se debería invocar de novo.
    ///
    /// # Panics
    ///
    /// Unha vez que o fluxo rematou (o `Ready(None)` from `poll_next`) devolto, chamar de novo ao seu método `poll_next` pode panic, bloquearse para sempre ou causar outro tipo de problemas; o `Stream` trait non impón requisitos sobre os efectos de tal chamada.
    ///
    /// Non obstante, como o método `poll_next` non está marcado como `unsafe`, aplícanse as regras habituais de Rust: as chamadas nunca deben causar un comportamento indefinido (corrupción de memoria, uso incorrecto das funcións `unsafe` ou similares), independentemente do estado do fluxo.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Devolve os límites da lonxitude restante do fluxo.
    ///
    /// En concreto, `size_hint()` devolve unha tupla onde o primeiro elemento é o límite inferior e o segundo elemento é o límite superior.
    ///
    /// A segunda metade da tupla que se devolve é unha [`Opción`]`<`[`usize`] `>>.
    /// Un [`None`] aquí significa que non hai límite superior coñecido ou que o límite superior é maior que [`usize`].
    ///
    /// # Notas de implementación
    ///
    /// Non se aplica que unha implementación de fluxo produza o número declarado de elementos.Un fluxo de buggy pode producir menos que o límite inferior ou máis que o límite superior dos elementos.
    ///
    /// `size_hint()` está pensado principalmente para usarse para optimizacións como a reserva de espazo para os elementos do fluxo, pero non debe confiarse, por exemplo, omitir as comprobacións de límites nun código non seguro.
    /// Unha implementación incorrecta de `size_hint()` non debería provocar violacións da seguridade da memoria.
    ///
    /// Dito isto, a implementación debería proporcionar unha estimación correcta, porque doutro xeito sería unha violación do protocolo de trait.
    ///
    /// A implementación predeterminada devolve `(0,` [`Ningún`]`)`o que é correcto para calquera fluxo.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}