//! Iteración asíncrona composable.
//!
//! Se futures son valores asíncronos, os fluxos son iteradores asíncronos.
//! Se te atopaches cunha colección asíncrona dalgún tipo e necesitabas realizar unha operación cos elementos da devandita colección, atoparás rapidamente 'streams'.
//! Os fluxos úsanse moito no código idiomático asincrónico Rust, polo que paga a pena familiarizarse con eles.
//!
//! Antes de explicar máis, falemos de como se estrutura este módulo:
//!
//! # Organization
//!
//! Este módulo está organizado en gran parte por tipo:
//!
//! * [Traits] son a parte principal: estes traits definen que tipo de fluxos existen e que podes facer con eles.Os métodos destes traits pagan a pena poñer un tempo de estudo extra.
//! * As funcións ofrecen algúns xeitos útiles para crear algúns fluxos básicos.
//! * As estruturas adoitan ser os tipos de retorno dos distintos métodos do traits deste módulo.Normalmente quererás ver o método que crea o `struct`, en lugar do `struct` en si.
//! Para máis detalles sobre o por que, vexa "[Implementing Stream](#Implementing-stream)".
//!
//! [Traits]: #traits
//!
//! Xa está!Digamos nos regatos.
//!
//! # Stream
//!
//! O corazón e a alma deste módulo é o [`Stream`] trait.O núcleo de [`Stream`] ten este aspecto:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! A diferenza de `Iterator`, `Stream` fai unha distinción entre o método [`poll_next`] que se usa ao implementar un `Stream` e un método (to-be-implemented) `next` que se usa cando se consume un fluxo.
//!
//! Os consumidores de `Stream` só precisan considerar `next`, que cando se chama devolve un future que produce `Option<Stream::Item>`.
//!
//! O future devolto por `next` producirá `Some(Item)` sempre que haxa elementos e, unha vez esgotados, producirá `None` para indicar que a iteración está rematada.
//! Se esperamos por algo asíncrono para resolver, o future agardará ata que o fluxo estea listo para ceder de novo.
//!
//! As emisións individuais poden optar por retomar a iteración, polo que chamar de novo a `next` pode producir ou non `Some(Item)` de novo nalgún momento.
//!
//! A definición completa de [`Stream`] inclúe tamén outros métodos, pero son métodos predeterminados, construídos sobre [`poll_next`], polo que os obtés de balde.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Implantación do fluxo
//!
//! Crear un fluxo propio implica dous pasos: crear un `struct` para manter o estado do fluxo e despois implementar [`Stream`] para ese `struct`.
//!
//! Imos facer un fluxo chamado `Counter` que conta de `1` a `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // En primeiro lugar, a estrutura:
//!
//! /// Un fluxo que conta dun a cinco
//! struct Counter {
//!     count: usize,
//! }
//!
//! // queremos que o noso reconto comece por un, así que engadimos un método new() para axudar.
//! // Isto non é estritamente necesario, pero é conveniente.
//! // Teña en conta que comezamos `count` a cero, veremos por que na implementación `poll_next()`'s a continuación.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Despois, implementamos `Stream` para o noso `Counter`:
//!
//! impl Stream for Counter {
//!     // estaremos contando con usize
//!     type Item = usize;
//!
//!     // poll_next() é o único método requirido
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Aumenta a nosa conta.É por iso que comezamos a cero.
//!         self.count += 1;
//!
//!         // Comproba se rematamos de contar ou non.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Os fluxos son *preguiceiros*.Isto significa que só crear un fluxo non é moi grande para _do_.Realmente non pasa nada ata que chamas ao `next`.
//! Ás veces isto é fonte de confusión cando se crea un fluxo exclusivamente polos seus efectos secundarios.
//! O compilador avisaranos sobre este tipo de comportamento:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;