//! Este módulo implementa o `Any` trait, que permite a escritura dinámica de calquera tipo `'static` a través da reflexión en tempo de execución.
//!
//! `Any` pode usarse para obter un `TypeId` e ten máis funcións cando se usa como obxecto trait.
//! Como `&dyn Any` (un obxecto trait prestado), ten os métodos `is` e `downcast_ref`, para probar se o valor contido é dun tipo determinado e obter unha referencia ao valor interno como un tipo.
//! Como `&mut dyn Any`, tamén existe o método `downcast_mut`, para obter unha referencia mutable ao valor interno.
//! `Box<dyn Any>` engade o método `downcast`, que intenta converter a un `Box<T>`.
//! Consulte a documentación [`Box`] para os detalles completos.
//!
//! Teña en conta que `&dyn Any` limítase a probar se un valor é dun tipo concreto especificado e non se pode usar para probar se un tipo implementa un trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Punteros intelixentes e `dyn Any`
//!
//! Un comportamento a ter en conta cando se usa `Any` como obxecto trait, especialmente con tipos como `Box<dyn Any>` ou `Arc<dyn Any>`, é que simplemente chamar a `.type_id()` no valor producirá o `TypeId` do *contedor*, non o obxecto trait subxacente.
//!
//! Isto pódese evitar convertendo o punteiro intelixente nun `&dyn Any`, que devolverá o `TypeId` do obxecto.
//! Por exemplo:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // É máis probable que queiras isto:
//! let actual_id = (&*boxed).type_id();
//! // ... que isto:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Considere unha situación na que queremos pechar sesión nun valor pasado a unha función.
//! Sabemos o valor no que estamos a traballar implementa a depuración, pero non sabemos o seu tipo concreto.Queremos dar un tratamento especial a certos tipos: neste caso imprimir a lonxitude dos valores da cadea antes do seu valor.
//! Non sabemos o tipo concreto do noso valor no momento da compilación, polo que debemos empregar a reflexión en tempo de execución.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Función de rexistro para calquera tipo que implante a depuración.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Tenta converter o noso valor nun `String`.
//!     // Se ten éxito, queremos emitir a lonxitude da cadea así como o seu valor.
//!     // Se non, é dun tipo diferente: só hai que imprimilo sen adornos.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Esta función quere pechar sesión no seu parámetro antes de traballar con ela.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... facer algún outro traballo
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Calquera trait
///////////////////////////////////////////////////////////////////////////////

/// Un trait para emular a escritura dinámica.
///
/// A maioría dos tipos implementan `Any`.Non obstante, calquera tipo que conteña unha referencia non "estática" non o fai.
/// Vexa o [module-level documentation][mod] para máis detalles.
///
/// [mod]: crate::any
// Este trait non é inseguro, aínda que confiamos nos detalles específicos da función `type_id` do seu único impl no código non seguro (por exemplo, `downcast`).Normalmente, iso sería un problema, pero debido a que o único impl de `Any` é unha implementación de manta, ningún outro código pode implementar `Any`.
//
// Poderiamos facer que este trait non sexa seguro-non causaría roturas, xa que controlamos todas as implementacións-, pero decidimos non facelo porque iso non é realmente necesario e pode confundir aos usuarios coa distinción de traits non seguro e métodos inseguros (é dicir, `type_id` aínda sería seguro de chamar, pero é probable que queiramos indicalo como tal na documentación).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Obtén o `TypeId` de `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Métodos de extensión para calquera obxecto trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Asegúrese de que o resultado de unir un fío pode ser impreso e, polo tanto, utilizado con `unwrap`.
// Finalmente, pode que xa non sexa necesario se o envío funciona con ascenso.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Devolve `true` se o tipo de caixa é o mesmo que `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Obtén `TypeId` do tipo con que se instancia esta función.
        let t = TypeId::of::<T>();

        // Obtén `TypeId` do tipo no obxecto trait (`self`).
        let concrete = self.type_id();

        // Compara os dous `TypeId` en igualdade.
        t == concrete
    }

    /// Devolve algunha referencia ao valor en caixa se é do tipo `T` ou `None` se non o é.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SEGURIDADE: só comprobamos se apuntamos ao tipo correcto e podemos confiar
            // comprobamos a seguridade da memoria porque implementamos Calquera para todos os tipos;non pode existir ningunha outra aplicación xa que entraría en conflito coa nosa aplicación.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Devolve algunha referencia mudable ao valor en caixa se é do tipo `T` ou `None` se non o é.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SEGURIDADE: só comprobamos se apuntamos ao tipo correcto e podemos confiar
            // comprobamos a seguridade da memoria porque implementamos Calquera para todos os tipos;non pode existir ningunha outra aplicación xa que entraría en conflito coa nosa aplicación.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Remite ao método definido no tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Remite ao método definido no tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Remite ao método definido no tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Remite ao método definido no tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Remite ao método definido no tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Remite ao método definido no tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID e os seus métodos
///////////////////////////////////////////////////////////////////////////////

/// Un `TypeId` representa un identificador único global para un tipo.
///
/// Cada `TypeId` é un obxecto opaco que non permite inspeccionar o que hai dentro, pero si permite operacións básicas como clonación, comparación, impresión e exhibición.
///
///
/// Un `TypeId` actualmente só está dispoñible para os tipos que se atribúen a `'static`, pero esta limitación pode eliminarse no future.
///
/// Mentres que `TypeId` implementa `Hash`, `PartialOrd` e `Ord`, cómpre ter en conta que os hash e a orde variarán entre as versións de Rust.
/// Coidado con confiar neles dentro do teu código.
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Devolve o `TypeId` do tipo con que se instancia esta función xenérica.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Devolve o nome dun tipo como unha porción de cadea.
///
/// # Note
///
/// Isto está pensado para uso diagnóstico.
/// Non se especifican o contido e o formato exactos da cadea devolta, ademais de ser unha descrición do mellor esforzo do tipo.
/// Por exemplo, entre as cadeas que `type_name::<Option<String>>()` pode devolver están `"Option<String>"` e `"std::option::Option<std::string::String>"`.
///
///
/// A cadea devolta non debe considerarse como un identificador único dun tipo xa que varios tipos poden asignarse ao mesmo nome de tipo.
/// Do mesmo xeito, non hai garantía de que todas as partes dun tipo aparezan na cadea devolta: por exemplo, os especificadores de vida non están incluídos actualmente.
/// Ademais, a saída pode cambiar entre versións do compilador.
///
/// A implementación actual usa a mesma infraestrutura que o diagnóstico do compilador e o debuginfo, pero isto non está garantido.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Devolve o nome do tipo de valor apuntado como unha porción de cadea.
/// Isto é o mesmo que `type_name::<T>()`, pero pódese usar cando o tipo de variable non está facilmente dispoñible.
///
/// # Note
///
/// Isto está pensado para uso diagnóstico.Non se especifican o contido e o formato exactos da cadea, máis alá de ser unha descrición do mellor esforzo do tipo.
/// Por exemplo, `type_name_of_val::<Option<String>>(None)` podería devolver `"Option<String>"` ou `"std::option::Option<std::string::String>"`, pero non `"foobar"`.
///
/// Ademais, a saída pode cambiar entre versións do compilador.
///
/// Esta función non resolve obxectos trait, o que significa que `type_name_of_val(&7u32 as &dyn Debug)` pode devolver `"dyn Debug"`, pero non `"u32"`.
///
/// O nome do tipo non debe considerarse un identificador único dun tipo;
/// varios tipos poden compartir o mesmo nome de tipo.
///
/// A implementación actual usa a mesma infraestrutura que o diagnóstico do compilador e o debuginfo, pero isto non está garantido.
///
/// # Examples
///
/// Imprime os tipos enteiros e flotantes predeterminados.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}