//! A cadea API Patrón.
//!
//! A API Patrón proporciona un mecanismo xenérico para usar diferentes tipos de patróns cando se busca a través dunha cadea.
//!
//! Para obter máis detalles, consulte traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] e [`DoubleEndedSearcher`].
//!
//! Aínda que esta API é inestable, exponse a través de API estables no tipo [`str`].
//!
//! # Examples
//!
//! [`Pattern`] é [implemented][pattern-impls] na API estable para [`&str`][`str`], [`char`], porcións de [`char`] e funcións e peches que implementan `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // patrón de caracteres
//! assert_eq!(s.find('n'), Some(2));
//! // porción de patrón de caracteres
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // patrón de peche
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Un patrón de corda.
///
/// Un `Pattern<'a>` expresa que o tipo de implementación pode usarse como patrón de cadea para buscar nun [`&'a str`][str].
///
/// Por exemplo, `'a'` e `"aa"` son patróns que coincidirían no índice `1` da cadea `"baaaab"`.
///
/// O propio trait actúa como un creador dun tipo [`Searcher`] asociado, que realiza o traballo real de buscar aparicións do patrón nunha cadea.
///
///
/// Dependendo do tipo de patrón, o comportamento de métodos como [`str::find`] e [`str::contains`] pode cambiar.
/// A táboa seguinte describe algúns deses comportamentos.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Buscador asociado deste patrón
    type Searcher: Searcher<'a>;

    /// Constrúe o buscador asociado a partir de `self` e `haystack` para buscar.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Comproba se o patrón coincide en calquera parte do palleiro
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Comproba se o patrón coincide na parte dianteira do palleiro
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Comproba se o patrón coincide na parte de atrás do palleiro
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Elimina o patrón da parte dianteira do palleiro, se coincide.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // SEGURIDADE: Sábese que `Searcher` devolve índices válidos.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Elimina o patrón da parte de atrás do palleiro, se coincide.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // SEGURIDADE: Sábese que `Searcher` devolve índices válidos.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Resultado da chamada a [`Searcher::next()`] ou [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Expresa que se atopou unha coincidencia do patrón en `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Expresa que `haystack[a..b]` foi rexeitado como posible coincidencia do patrón.
    ///
    /// Teña en conta que pode haber máis dun `Reject` entre dous `Match`es, non hai ningún requisito para que se combinen nun só.
    ///
    ///
    Reject(usize, usize),
    /// Expresa que se visitou cada byte do palleiro, rematando a iteración.
    ///
    Done,
}

/// Un buscador dun patrón de cadea.
///
/// Este trait proporciona métodos para buscar coincidencias non superpostas dun patrón a partir do (left) frontal dunha cadea.
///
/// Será implementado polos tipos `Searcher` asociados do [`Pattern`] trait.
///
/// O trait está marcado como inseguro porque os índices devoltos polos métodos [`next()`][Searcher::next] están obrigados a situarse en límites utf8 válidos no palleiro.
/// Isto permite aos consumidores deste trait cortar o palleiro sen comprobacións de tempo de execución adicionais.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter para buscar a cadea subxacente
    ///
    /// Sempre devolverá o mesmo [`&str`][str].
    fn haystack(&self) -> &'a str;

    /// Realiza o seguinte paso de busca a partir da parte frontal.
    ///
    /// - Devolve [`Match(a, b)`][SearchStep::Match] se `haystack[a..b]` coincide co patrón.
    /// - Devolve [`Reject(a, b)`][SearchStep::Reject] se `haystack[a..b]` non pode coincidir co patrón, nin sequera parcialmente.
    /// - Devolve [`Done`][SearchStep::Done] se se visitou cada byte do palleiro.
    ///
    /// O fluxo de valores [`Match`][SearchStep::Match] e [`Reject`][SearchStep::Reject] ata un [`Done`][SearchStep::Done] conterá rangos de índices adxacentes, non superpostos, que abarcan todo o palleiro e que se sitúan nos límites utf8.
    ///
    ///
    /// Un resultado [`Match`][SearchStep::Match] ten que conter todo o patrón coincidente, pero os resultados [`Reject`][SearchStep::Reject] poden dividirse en moitos fragmentos adxacentes arbitrarios.Ambos os rangos poden ter unha lonxitude cero.
    ///
    /// Como exemplo, o patrón `"aaa"` e o palleiro `"cbaaaaab"` poden producir o fluxo
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Atopa o seguinte resultado [`Match`][SearchStep::Match].Vexa [`next()`][Searcher::next].
    ///
    /// A diferenza do [`next()`][Searcher::next], non hai garantía de que os rangos devoltos deste e [`next_reject`][Searcher::next_reject] se superpoñan.
    /// Devolverá `(start_match, end_match)`, onde start_match é o índice de onde comeza a partida e end_match é o índice despois do final da partida.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Atopa o seguinte resultado [`Reject`][SearchStep::Reject].Vexa [`next()`][Searcher::next] e [`next_match()`][Searcher::next_match].
    ///
    /// A diferenza do [`next()`][Searcher::next], non hai garantía de que os rangos devoltos deste e [`next_match`][Searcher::next_match] se superpoñan.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Un buscador inverso dun patrón de cadea.
///
/// Este trait proporciona métodos para buscar coincidencias non superpostas dun patrón a partir do (right) traseiro dunha cadea.
///
/// Será implementado polos tipos [`Searcher`] asociados do [`Pattern`] trait se o patrón admite buscalo desde atrás.
///
///
/// Os rangos de índice devoltos por este trait non están obrigados a coincidir exactamente cos da busca directa ao revés.
///
/// Pola razón pola que este trait está marcado como non seguro, véxano como pai trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Realiza o seguinte paso de busca a partir de atrás.
    ///
    /// - Devolve [`Match(a, b)`][SearchStep::Match] se `haystack[a..b]` coincide co patrón.
    /// - Devolve [`Reject(a, b)`][SearchStep::Reject] se `haystack[a..b]` non pode coincidir co patrón, nin sequera parcialmente.
    /// - Devolve [`Done`][SearchStep::Done] se se visitou cada byte do palleiro
    ///
    /// O fluxo de valores [`Match`][SearchStep::Match] e [`Reject`][SearchStep::Reject] ata un [`Done`][SearchStep::Done] conterá rangos de índices adxacentes, non superpostos, que abarcan todo o palleiro e que se sitúan nos límites utf8.
    ///
    ///
    /// Un resultado [`Match`][SearchStep::Match] ten que conter todo o patrón coincidente, pero os resultados [`Reject`][SearchStep::Reject] poden dividirse en moitos fragmentos adxacentes arbitrarios.Ambos os rangos poden ter unha lonxitude cero.
    ///
    /// Como exemplo, o patrón `"aaa"` e o palleiro `"cbaaaaab"` poden producir o fluxo `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Atopa o seguinte resultado [`Match`][SearchStep::Match].
    /// Vexa [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Atopa o seguinte resultado [`Reject`][SearchStep::Reject].
    /// Vexa [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Un marcador trait para expresar que se pode usar un [`ReverseSearcher`] para unha implementación [`DoubleEndedIterator`].
///
/// Para iso, a aplicación de [`Searcher`] e [`ReverseSearcher`] debe cumprir estas condicións:
///
/// - Todos os resultados de `next()` deben ser idénticos aos resultados de `next_back()` en orde inversa.
/// - `next()` e `next_back()` teñen que comportarse como os dous extremos dun intervalo de valores, é dicir, non poden "walk past each other".
///
/// # Examples
///
/// `char::Searcher` é un `DoubleEndedSearcher` porque buscar un [`char`] só require mirar un de cada vez, que se comporta igual desde os dous extremos.
///
/// `(&str)::Searcher` non é un `DoubleEndedSearcher` porque o patrón `"aa"` no palleiro `"aaa"` coincide como `"[aa]a"` ou `"a[aa]"`, dependendo de que lado se busque.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl
/////////////////////////////////////////////////////////////////////////////

/// Tipo asociado para `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // invariante de seguridade: `finger`/`finger_back` debe ser un índice de bytes utf8 válido de `haystack` Este invariante pódese romper *dentro de* next_match e next_match_back, non obstante deben saír cos dedos nos límites dos puntos de código válidos.
    //
    //
    /// `finger` é o índice de bytes actual da busca directa.
    /// Imaxina que existe antes do byte no seu índice, é dicir
    /// `haystack[finger]` é o primeiro byte da porción que debemos inspeccionar durante a busca cara adiante
    ///
    finger: usize,
    /// `finger_back` é o índice de bytes actual da busca inversa.
    /// Imaxina que existe despois do byte no seu índice, é dicir
    /// palleiro [finger_back, 1] é o último byte da porción que debemos inspeccionar durante a busca directa (e, polo tanto, o primeiro byte que se inspecciona ao chamar ao next_back()).
    ///
    finger_back: usize,
    /// O personaxe que se busca
    needle: char,

    // invariante de seguridade: `utf8_size` debe ser inferior a 5
    /// O número de bytes `needle` ocupa cando está codificado en utf8.
    utf8_size: usize,
    /// Unha copia codificada utf8 do `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // SEGURIDADE: 1-4 garante a seguridade de `get_unchecked`
        // 1. `self.finger` e `self.finger_back` mantéñense nos límites unicode (isto é invariante)
        // 2. `self.finger >= 0` xa que comeza a 0 e só aumenta
        // 3. `self.finger < self.finger_back` porque se non, o char `iter` devolvería `SearchStep::Done`
        // 4.
        // `self.finger` chega antes do final do palleiro porque `self.finger_back` comeza ao final e só diminúe
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // engadir compensación de bytes do carácter actual sen recodificar como utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // obtén o palleiro despois do último personaxe atopado
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // o último byte da agulla codificada utf8 SEGURIDADE: temos un invariante que `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // O novo dedo é o índice do byte que atopamos, máis un, xa que fixemos o último byte do personaxe.
                //
                // Teña en conta que isto non sempre nos dá un dedo nun límite UTF8.
                // Se *non* atopamos o noso carácter, é posible que teñamos indexado ao último byte dun carácter de 3 ou 4 bytes.
                // Non podemos pasar ao seguinte byte inicial válido porque un personaxe como ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` fará que sempre atopemos o segundo byte ao buscar o terceiro.
                //
                //
                // Non obstante, está totalmente ben.
                // Aínda que temos o invariante de que self.finger está nun límite UTF8, este invariante non se fía neste método (fíase en CharSearcher::next()).
                //
                // Só saímos deste método cando chegamos ao final da cadea ou se atopamos algo.Cando atopemos algo, o `finger` establecerase nun límite UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // non atopei nada, saia
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // deixe que next_reject use a implementación predeterminada desde o Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // SEGURIDADE: vexa o comentario para next() anterior
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // restar a compensación de bytes do carácter actual sen recodificar como utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // obtén o palleiro ata o último personaxe buscado sen incluír
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // o último byte da agulla codificada utf8 SEGURIDADE: temos un invariante que `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // buscamos unha porción compensada por self.finger, engadimos self.finger para recuperar o índice orixinal
                //
                let index = self.finger + index;
                // memrchr devolverá o índice do byte que desexamos atopar.
                // No caso dun carácter ASCII, isto é realmente se queremos que o noso novo dedo sexa ("after" o carácter atopado no paradigma da iteración inversa).
                //
                // Para os caracteres multibyte necesitamos saltar polo número de bytes máis que ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // move o dedo cara antes do carácter atopado (é dicir, no seu índice inicial)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Aquí non podemos usar finger_back=index, tamaño + 1.
                // Se atopamos o último carácter dun carácter de tamaño diferente (ou o byte medio dun carácter diferente) necesitamos reducir o dedo cara atrás ata `index`.
                // Isto fai que `finger_back` teña o potencial de deixar de estar nun límite, pero está ben porque só saímos desta función nun límite ou cando se buscou completamente o palleiro.
                //
                //
                // A diferenza de next_match, este non ten o problema dos bytes repetidos en utf-8 porque estamos a buscar o último byte e só podemos atopar o último byte cando buscamos ao revés.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // non atopei nada, saia
                return None;
            }
        }
    }

    // deixe que next_reject_back use a implementación predeterminada desde o Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Busca caracteres iguais a un determinado [`char`].
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Implica un envoltorio MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Compare as lonxitudes do iterador de porción de bytes interno para atopar a lonxitude do carácter actual
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Compare as lonxitudes do iterador de porción de bytes interno para atopar a lonxitude do carácter actual
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl para&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Cambiar/Eliminar debido á ambigüidade no significado.

/// Tipo asociado para `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Busca caracteres iguais a calquera dos [`char`] da porción.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl para F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Tipo asociado para `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Busca [`char`] que coincida co predicado dado.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl para&&str
/////////////////////////////////////////////////////////////////////////////

/// Delegados no impl. `&str`
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl para &str
/////////////////////////////////////////////////////////////////////////////

/// Busca de subcadeas sen asignar.
///
/// Manexará o patrón `""` como devolución de coincidencias baleiras en cada límite de caracteres.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Comproba se o patrón coincide na parte dianteira do palleiro.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Elimina o patrón da parte dianteira do palleiro, se coincide.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // SEGURIDADE: acaba de verificarse que exista o prefixo.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Comproba se o patrón coincide na parte de atrás do palleiro.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Elimina o patrón da parte de atrás do palleiro, se coincide.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // SEGURIDADE: acaba de verificarse que existe o sufixo.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Buscador de subcadeas de dúas vías
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Tipo asociado para `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // a agulla baleira rexeita todos os caracteres e coincide con cada cadea baleira entre eles
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher produce índices *Match* válidos que se dividen nos límites dos caracteres sempre que fagan coincidencias correctas e que o palleiro e a agulla sexan válidos UTF-8 *Os rexeitamentos* do algoritmo poden caer en calquera índice, pero camiñámolos manualmente ata o seguinte límite de caracteres, para que sexan seguros para utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // ir ao límite do seguinte carácter
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // escriba casos `true` e `false` para animar ao compilador a especializar os dous casos por separado.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // ir ao límite do seguinte carácter
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // escribe `true` e `false`, como `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// O estado interno do algoritmo de busca de subcadeas de dobre sentido.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// índice de factorización crítica
    crit_pos: usize,
    /// índice de factorización crítica para a agulla invertida
    crit_pos_back: usize,
    period: usize,
    /// `byteset` é unha extensión (non forma parte do algoritmo bidireccional);
    /// é un "fingerprint" de 64 bits onde cada conxunto de bits `j` corresponde a un (byte e 63)==j presente na agulla.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// índice en agulla antes da cal xa coincidimos
    memory: usize,
    /// índice en agulla despois do cal xa coincidimos
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Unha explicación especialmente lexible do que está a suceder aquí pódese atopar no libro "Text Algorithms" de Crochemore e Rytter, cap 13.
        // Ver específicamente o código para "Algorithm CP" na p.
        // 323.
        //
        // O que está a suceder é que temos algunha factorización crítica (u, v) da agulla e queremos determinar se u é un sufixo de&v [.. punto].
        // Se é así, usamos "Algorithm CP1".
        // Se non, usamos "Algorithm CP2", que está optimizado para cando o período da agulla é grande.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // caso de período curto: o período é exacto calcula unha factorización crítica separada para a agulla invertida x=u 'v' onde | v '|<period(x).
            //
            // Isto é acelerado polo período que xa se coñece.
            // Teña en conta que un caso como x= "acba" pode ser tomado en conta exactamente cara adiante (crit_pos=1, período=3) mentres se ten en conta o período aproximado ao revés (crit_pos=2, período=2).
            // Usamos a factorización inversa dada pero mantemos o período exacto.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // caso de período longo: temos unha aproximación ao período real e non usamos a memorización.
            //
            //
            // Aproximar o período por límite inferior max(|u|, |v|) + 1.
            // A factorización crítica é eficiente para usar tanto para a busca directa como inversa.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Valor ficticio para indicar que o período é longo
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Unha das ideas principais de bidireccional é que factorizamos a agulla en dúas metades, (u, v) e comezamos a intentar atopar v no palleiro dixitalizando de esquerda a dereita.
    // Se v coincide, intentamos coincidir con u dixitalizando de dereita a esquerda.
    // Ata onde podemos saltar cando atopamos un desaxuste baséase en que (u, v) é unha factorización crítica para a agulla.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` usa `self.position` como cursor
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Comprobe que temos espazo para buscar na posición + agulla_ultima non pode desbordarse se supoñemos que as franxas están delimitadas polo rango de isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Saltar rapidamente por porcións grandes non relacionadas coa nosa subcadea
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Vexa se a parte dereita da agulla coincide
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Vexa se a parte esquerda da agulla coincide
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Atopamos unha coincidencia.
            let match_pos = self.position;

            // Note: engade self.period en vez de needle.len() para ter coincidencias superpostas
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // definido como needle.len(), self.period para coincidencias superpostas
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Sigue as ideas en `next()`.
    //
    // As definicións son simétricas, con period(x) = period(reverse(x)) e local_period(u, v) = local_period(reverse(v), reverse(u)), polo que se (u, v) é unha factorización crítica, tamén o é (reverse(v), reverse(u)).
    //
    //
    // Para o caso inverso calculamos unha factorización crítica x=u 'v' (campo `crit_pos_back`).Necesitamos | u |<period(x) para o caso directo e así | v '|<period(x) para o reverso.
    //
    // Para buscar ao revés polo palleiro, buscamos cara adiante a través dun palleiro invertido cunha agulla invertida, coincidindo primeiro con u 'e despois con v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` usa `self.end` como cursor, de xeito que `next()` e `next_back()` son independentes.
        //
        let old_end = self.end;
        'search: loop {
            // Comprobe que ao final temos espazo para buscar, needle.len() envolverase cando xa non haxa espazo, pero debido aos límites de lonxitude da porción, nunca pode envolverse ata a lonxitude do palleiro.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Saltar rapidamente por porcións grandes non relacionadas coa nosa subcadea
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Vexa se a parte esquerda da agulla coincide
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Vexa se a parte dereita da agulla coincide
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Atopamos unha coincidencia.
            let match_pos = self.end - needle.len();
            // Note: Sub self.period en lugar de needle.len() para ter coincidencias superpostas
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Calcula o sufixo máximo de `arr`.
    //
    // O sufixo máximo é unha posible factorización crítica (u, v) de `arr`.
    //
    // Devolve (`i`, `p`) onde `i` é o índice inicial de v e `p` é o período de v.
    //
    // `order_greater` determina se a orde léxica é `<` ou `>`.
    // As dúas ordes deben computarse: a orde co `i` máis grande dá unha factorización crítica.
    //
    //
    // En casos de período longo, o período resultante non é exacto (é demasiado curto).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Corresponde a i no xornal
        let mut right = 1; // Corresponde a j no xornal
        let mut offset = 0; // Corresponde a k no xornal, pero comezando por 0
        // para coincidir coa indexación baseada en 0.
        let mut period = 1; // Corresponde a p no xornal

        while let Some(&a) = arr.get(right + offset) {
            // `left` serán entrantes cando `right` estea.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // O sufixo é máis pequeno, o punto é o prefixo enteiro ata o de agora.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Avance mediante a repetición do período actual.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // O sufixo é máis grande, comeza de novo desde a situación actual.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Calcula o sufixo máximo do reverso de `arr`.
    //
    // O sufixo máximo é unha posible factorización crítica (u ', v') de `arr`.
    //
    // Devolve `i` onde `i` é o índice inicial de v ', desde atrás;
    // regresa inmediatamente cando se alcanza un período de `known_period`.
    //
    // `order_greater` determina se a orde léxica é `<` ou `>`.
    // As dúas ordes deben computarse: a orde co `i` máis grande dá unha factorización crítica.
    //
    //
    // En casos de período longo, o período resultante non é exacto (é demasiado curto).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Corresponde a i no xornal
        let mut right = 1; // Corresponde a j no xornal
        let mut offset = 0; // Corresponde a k no xornal, pero comezando por 0
        // para coincidir coa indexación baseada en 0.
        let mut period = 1; // Corresponde a p no xornal
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // O sufixo é máis pequeno, o punto é o prefixo enteiro ata o de agora.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Avance mediante a repetición do período actual.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // O sufixo é máis grande, comeza de novo desde a situación actual.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy permítelle ao algoritmo saltar non coincidencias o máis rápido posible ou traballar nun modo no que emite Rechazos relativamente rápido.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Saltar aos intervalos de coincidencia o máis rápido posible
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emitir Rexeita regularmente
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}