//! Formas de crear un `str` a partir de porción de bytes.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Converte unha porción de bytes nunha porción de cadea.
///
/// Unha porción de cadea ([`&str`]) está composta por bytes ([`u8`]) e unha porción de bytes ([`&[u8]`][byteslice]) está composta por bytes, polo que esta función convértese entre os dous.
/// Non todos os segmentos de bytes son segmentos de cadea válidos, con todo: [`&str`] require que sexa UTF-8 válido.
/// `from_utf8()` comproba que os bytes son válidos UTF-8 e logo realiza a conversión.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Se está seguro de que a porción de bytes é UTF-8 válida e non quere incorrer na sobrecarga da comprobación de validez, hai unha versión non segura desta función, [`from_utf8_unchecked`], que ten o mesmo comportamento pero omite a comprobación.
///
///
/// Se precisa un `String` en lugar dun `&str`, considere [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Debido a que se pode asignar un `[u8; N]` en pila e pode tomar un [`&[u8]`][byteslice], esta función é un xeito de ter unha cadea asignada a pila.Hai un exemplo disto na sección de exemplos a continuación.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Devolve `Err` se a porción non é UTF-8 cunha descrición de por que a porción proporcionada non é UTF-8.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::str;
///
/// // algúns bytes, nun vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Sabemos que estes bytes son válidos, polo que só tes que empregar `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Bytes incorrectos:
///
/// ```
/// use std::str;
///
/// // algúns bytes non válidos, nun vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Consulte os documentos de [`Utf8Error`] para obter máis detalles sobre os tipos de erros que se poden devolver.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // algúns bytes, nunha matriz asignada á pila
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Sabemos que estes bytes son válidos, polo que só tes que empregar `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SEGURIDADE: Simplemente executou a validación.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Converte unha porción de bytes mutable nunha porción de cadea mutable.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" como vector mutable
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Como sabemos que estes bytes son válidos, podemos usar `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Bytes incorrectos:
///
/// ```
/// use std::str;
///
/// // Algúns bytes non válidos nun vector mutable
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Consulte os documentos de [`Utf8Error`] para obter máis detalles sobre os tipos de erros que se poden devolver.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SEGURIDADE: Simplemente executou a validación.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Converte unha porción de bytes nunha porción de cadea sen comprobar que a cadea conteña UTF-8 válido.
///
/// Vexa a versión segura, [`from_utf8`], para obter máis información.
///
/// # Safety
///
/// Esta función non é segura porque non verifica que os bytes que se lle pasen sexan UTF-8 válidos.
/// Se se viola esta restrición, prodúcese un comportamento indefinido, xa que o resto de Rust asume que [`&str`] s son UTF-8 válidos.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::str;
///
/// // algúns bytes, nun vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SEGURIDADE: o interlocutor debe garantir que os bytes `v` son UTF-8 válidos.
    // Tamén depende de que `&str` e `&[u8]` teñan o mesmo deseño.
    unsafe { mem::transmute(v) }
}

/// Converte unha porción de bytes nunha porción de cadea sen comprobar que a cadea conteña UTF-8 válido;versión mutable.
///
///
/// Vexa a versión inmutable, [`from_utf8_unchecked()`] para máis información.
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SEGURIDADE: o interlocutor debe garantir que os bytes `v`
    // son UTF-8 válidos, polo tanto, o lanzamento a `*mut str` é seguro.
    // Ademais, a desreferencia do punteiro é segura porque ese punteiro provén dunha referencia que se garante que é válida para as escrituras.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}