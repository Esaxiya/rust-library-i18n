//! Implementacións Trait para `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Implementa a ordenación de cordas.
///
/// As cadeas están ordenadas [lexicographically](Ord#lexicographical-comparison) polos seus valores de bytes.
/// Isto ordena puntos de código Unicode en función das súas posicións nos gráficos de códigos.
/// Isto non é necesariamente o mesmo que a orde "alphabetical", que varía segundo o idioma e a configuración local.
/// A ordenación de cadeas segundo estándares culturalmente aceptados require datos específicos da rexión local que están fóra do alcance do tipo `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Implementa operacións de comparación en cadeas.
///
/// As cadeas compáranse [lexicographically](Ord#lexicographical-comparison) polos seus valores de bytes.
/// Isto compara os puntos de código Unicode en función das súas posicións nos gráficos de códigos.
/// Isto non é necesariamente o mesmo que a orde "alphabetical", que varía segundo o idioma e a configuración local.
/// A comparación de cadeas segundo os estándares culturalmente aceptados require datos específicos da rexión local que están fóra do alcance do tipo `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implementa cortes de subcadeas coa sintaxe `&self[..]` ou `&mut self[..]`.
///
/// Devolve unha porción de toda a cadea, é dicir, devolve `&self` ou `&mut self`.Equivalente a `&self [0 ..
/// len] `ou`&mut self [0 ..
/// len]`.
/// A diferenza doutras operacións de indexación, isto nunca pode panic.
///
/// Esta operación é *O*(1).
///
/// Antes de 1.20.0, estas operacións de indexación aínda estaban soportadas pola implementación directa de `Index` e `IndexMut`.
///
/// Equivalente a `&self[0 .. len]` ou `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implementa cortes de subcadeas coa sintaxe `&self[begin .. end]` ou `&mut self[begin .. end]`.
///
/// Devolve unha porción da cadea dada do rango de bytes [`begin`, `end`).
///
/// Esta operación é *O*(1).
///
/// Antes de 1.20.0, estas operacións de indexación aínda estaban soportadas pola implementación directa de `Index` e `IndexMut`.
///
/// # Panics
///
/// Panics se `begin` ou `end` non apunta ao desprazamento de bytes inicial dun carácter (como o define `is_char_boundary`), se `begin > end` ou `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // estes serán panic:
/// // o byte 2 está dentro de `ö`:
/// // &s [2 ..3];
///
/// // o byte 8 atópase dentro de `老`&s [1 ..
/// // 8];
///
/// // o byte 100 está fóra da cadea&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SEGURIDADE: acaba de comprobar que `start` e `end` están nun límite de caracteres,
            // e estamos a pasar unha referencia segura, polo que o valor de retorno tamén será un.
            // Tamén comprobamos os límites de caracteres, polo que é válido UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SEGURIDADE: acaba de comprobar que `start` e `end` están nun límite de caracteres.
            // Sabemos que o punteiro é único porque o conseguimos de `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SEGURIDADE: o interlocutor garante que `self` está nos límites de `slice`
        // que cumpre todas as condicións para `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SEGURIDADE: ver comentarios para `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary comproba que o índice está en [0, .len()] non pode reutilizar `get` como arriba, por problemas de NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SEGURIDADE: acaba de comprobar que `start` e `end` están nun límite de caracteres,
            // e estamos a pasar unha referencia segura, polo que o valor de retorno tamén será un.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Implementa cortes de subcadeas coa sintaxe `&self[.. end]` ou `&mut self[.. end]`.
///
/// Devolve unha porción da cadea dada do rango de bytes [`0`, `end`).
/// Equivalente a `&self[0 .. end]` ou `&mut self[0 .. end]`.
///
/// Esta operación é *O*(1).
///
/// Antes de 1.20.0, estas operacións de indexación aínda estaban soportadas pola implementación directa de `Index` e `IndexMut`.
///
/// # Panics
///
/// Panics se `end` non apunta ao desprazamento de bytes inicial dun carácter (como o define `is_char_boundary`) ou se `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SEGURIDADE: acaba de comprobar que `end` está nun límite de caracteres,
            // e estamos a pasar unha referencia segura, polo que o valor de retorno tamén será un.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SEGURIDADE: acaba de comprobar que `end` está nun límite de caracteres,
            // e estamos a pasar unha referencia segura, polo que o valor de retorno tamén será un.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SEGURIDADE: acaba de comprobar que `end` está nun límite de caracteres,
            // e estamos a pasar unha referencia segura, polo que o valor de retorno tamén será un.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implementa cortes de subcadeas coa sintaxe `&self[begin ..]` ou `&mut self[begin ..]`.
///
/// Devolve unha porción da cadea dada do rango de bytes [`begin`, `len`).Equivalente a `&auto [comezar ..
/// len] `ou`&mut self [comezar ..
/// len]`.
///
/// Esta operación é *O*(1).
///
/// Antes de 1.20.0, estas operacións de indexación aínda estaban soportadas pola implementación directa de `Index` e `IndexMut`.
///
/// # Panics
///
/// Panics se `begin` non apunta ao desprazamento de bytes inicial dun carácter (como o define `is_char_boundary`) ou se `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SEGURIDADE: acaba de comprobar que `start` está nun límite de caracteres,
            // e estamos a pasar unha referencia segura, polo que o valor de retorno tamén será un.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SEGURIDADE: acaba de comprobar que `start` está nun límite de caracteres,
            // e estamos a pasar unha referencia segura, polo que o valor de retorno tamén será un.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SEGURIDADE: o interlocutor garante que `self` está nos límites de `slice`
        // que cumpre todas as condicións para `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SEGURIDADE: idéntica a `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SEGURIDADE: acaba de comprobar que `start` está nun límite de caracteres,
            // e estamos a pasar unha referencia segura, polo que o valor de retorno tamén será un.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Implementa cortes de subcadeas coa sintaxe `&self[begin ..= end]` ou `&mut self[begin ..= end]`.
///
/// Devolve unha porción da cadea dada do rango de bytes [`begin`, `end`].Equivalente a `&self [begin .. end + 1]` ou `&mut self[begin .. end + 1]`, excepto se `end` ten o valor máximo para `usize`.
///
/// Esta operación é *O*(1).
///
/// # Panics
///
/// Panics se `begin` non apunta ao desprazamento de byte inicial dun carácter (como o define `is_char_boundary`), se `end` non apunta ao desprazamento de byte final dun carácter (`end + 1` é un offset de byte inicial ou igual a `len`), se `begin > end`, ou se `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implementa cortes de subcadeas coa sintaxe `&self[..= end]` ou `&mut self[..= end]`.
///
/// Devolve unha porción da cadea dada do rango de bytes [0, `end`].
/// Equivalente a `&self [0 .. end + 1]`, excepto se `end` ten o valor máximo para `usize`.
///
/// Esta operación é *O*(1).
///
/// # Panics
///
/// Panics se `end` non apunta ao desprazamento de byte final dun carácter (`end + 1` é un desprazamento de byte inicial definido por `is_char_boundary` ou igual a `len`) ou se `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Analice un valor dunha cadea
///
/// O método [`from_str`] de `FromStr` úsase a miúdo de xeito implícito, a través do método [`parse`] de [`str`].
/// Vexa a documentación de [`analizar`] para ver exemplos.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` non ten un parámetro de vida útil e, polo tanto, só pode analizar os tipos que non conteñan un parámetro de vida propia.
///
/// Noutras palabras, pode analizar un `i32` con `FromStr`, pero non un `&i32`.
/// Podes analizar unha estrutura que conteña un `i32`, pero non unha que conteña un `&i32`.
///
/// # Examples
///
/// Implementación básica de `FromStr` nun tipo de exemplo `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// O erro asociado que se pode devolver ao analizar.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analiza unha cadea `s` para devolver un valor deste tipo.
    ///
    /// Se o análise ten éxito, devolve o valor dentro de [`Ok`], se non, cando a cadea non está formatada devolve un erro específico para o interior de [`Err`].
    /// O tipo de erro é específico para a implementación do trait.
    ///
    /// # Examples
    ///
    /// Uso básico con [`i32`], un tipo que implementa `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Analice un `bool` desde unha cadea.
    ///
    /// Produce un `Result<bool, ParseBoolError>`, porque `s` pode ou non ser analizable.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Teña en conta que, en moitos casos, o método `.parse()` en `str` é máis adecuado.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}