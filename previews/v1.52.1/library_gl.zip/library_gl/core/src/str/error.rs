//! Define o tipo de erro utf8.

use crate::fmt;

/// Erros que poden ocorrer cando se intenta interpretar unha secuencia de [`u8`] como unha cadea.
///
/// Como tal, a familia de funcións e métodos `from_utf8` tanto para [`String`] como para [`&str`] fan uso deste erro, por exemplo.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Os métodos deste tipo de erro pódense utilizar para crear funcionalidades similares a `String::from_utf8_lossy` sen asignar memoria heap:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Devolve o índice da cadea indicada ata a que se verificou UTF-8 válido.
    ///
    /// É o índice máximo tal que `from_utf8(&input[..index])` devolvería `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::str;
    ///
    /// // algúns bytes non válidos, nun vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 devolve un Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // o segundo byte non é válido aquí
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Ofrece máis información sobre o fallo:
    ///
    /// * `None`: alcanzouse inesperadamente o final da entrada.
    ///   `self.valid_up_to()` é de 1 a 3 bytes desde o final da entrada.
    ///   Se se está descodificando incrementalmente un fluxo de bytes (como un ficheiro ou un socket de rede), este podería ser un `char` válido cuxa secuencia de bytes UTF-8 abrangue varios anacos.
    ///
    ///
    /// * `Some(len)`: atopouse un byte inesperado.
    ///   A lonxitude proporcionada é a da secuencia de bytes non válida que comeza no índice dado por `valid_up_to()`.
    ///   A descodificación debería retomarse despois desa secuencia (despois de inserir un [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) en caso de descodificación con perdas.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Fallou un erro ao analizar un `bool` usando [`from_str`]
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}