//! Funcións libres para crear `&[T]` e `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Forma unha porción a partir dun punteiro e unha lonxitude.
///
/// O argumento `len` é o número de **elementos**, non o número de bytes.
///
/// # Safety
///
/// O comportamento non está definido se se incumpre algunha das seguintes condicións:
///
/// * `data` debe ser [valid] para lecturas para moitos bytes `len * mem::size_of::<T>()` e debe estar aliñado correctamente.Isto significa en particular:
///
///     * Todo o intervalo de memoria desta porción debe estar contido nun único obxecto asignado.
///       As franxas nunca poden abarcar varios obxectos asignados.Vexa [below](#incorrect-usage) para ver un exemplo incorrecto non tendo en conta isto.
///     * `data` debe ser nulo e aliñado incluso para franxas de lonxitude cero.
///     Unha das razóns para iso é que as optimizacións de deseño enum poden depender de que as referencias (incluídas as franxas de calquera lonxitude) estean aliñadas e non nulas para distinguilas doutros datos.
///     Podes obter un punteiro que se poida usar como `data` para franxas de lonxitude cero usando [`NonNull::dangling()`].
///
/// * `data` debe apuntar a `len` valores consecutivos inicializados correctamente do tipo `T`.
///
/// * A memoria a que fai referencia a porción devolta non debe mutarse durante a duración da vida `'a`, excepto dentro dun `UnsafeCell`.
///
/// * O tamaño total `len * mem::size_of::<T>()` da porción non debe ser maior que `isize::MAX`.
///   Consulte a documentación de seguridade de [`pointer::offset`].
///
/// # Caveat
///
/// A vida útil da porción devolta dedúcese do seu uso.
/// Para evitar o uso indebido accidental, suxírese vincular a vida útil a calquera fonte de vida que sexa segura no contexto, como proporcionar unha función auxiliar que tome a vida útil dun valor de host para a porción, ou mediante anotación explícita.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifesta unha porción para un só elemento
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Uso incorrecto
///
/// A seguinte función `join_slices` é **desvalida** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // A afirmación anterior garante que `fst` e `snd` son contiguos, pero aínda poden estar incluídos dentro de _different allocated objects_, nese caso a creación desta porción é un comportamento indefinido.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` e `b` son diferentes obxectos asignados ...
///     let a = 42;
///     let b = 27;
///     // ... que, non obstante, pode aparecer contiguamente na memoria: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Realiza a mesma funcionalidade que [`from_raw_parts`], excepto que se devolve unha porción mutable.
///
/// # Safety
///
/// O comportamento non está definido se se incumpre algunha das seguintes condicións:
///
/// * `data` debe ser [valid] tanto para as lecturas como para as escrituras para moitos bytes `len * mem::size_of::<T>()` e debe estar correctamente aliñado.Isto significa en particular:
///
///     * Todo o intervalo de memoria desta porción debe estar contido nun único obxecto asignado.
///       As franxas nunca poden abarcar varios obxectos asignados.
///     * `data` debe ser nulo e aliñado incluso para franxas de lonxitude cero.
///     Unha das razóns para iso é que as optimizacións de deseño enum poden depender de que as referencias (incluídas as franxas de calquera lonxitude) estean aliñadas e non nulas para distinguilas doutros datos.
///
///     Podes obter un punteiro que se poida usar como `data` para franxas de lonxitude cero usando [`NonNull::dangling()`].
///
/// * `data` debe apuntar a `len` valores consecutivos inicializados correctamente do tipo `T`.
///
/// * Non se pode acceder á memoria a que fai referencia a porción devolta a través de ningún outro punteiro (non derivado do valor devolto) durante a duración da vida `'a`.
///   Os accesos de lectura e escritura están prohibidos.
///
/// * O tamaño total `len * mem::size_of::<T>()` da porción non debe ser maior que `isize::MAX`.
///   Consulte a documentación de seguridade de [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Converte unha referencia a T nunha porción de lonxitude 1 (sen copiar).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Converte unha referencia a T nunha porción de lonxitude 1 (sen copiar).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}