//! Operacións en ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Comproba se todos os bytes desta porción están dentro do rango ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Comproba que dúas franxas non coincidan con maiúsculas e minúsculas ASCII.
    ///
    /// Igual que `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, pero sen asignar e copiar temporais.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Converte esta porción no seu equivalente en maiúsculas ASCII no lugar.
    ///
    /// As letras ASCII de 'a' a 'z' están mapeadas de 'A' a 'Z', pero as letras non ASCII están inalteradas.
    ///
    /// Para devolver un novo valor en maiúsculas sen modificar o existente, use [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Converte esta porción no seu equivalente en minúsculas ASCII.
    ///
    /// As letras ASCII de 'A' a 'Z' están mapeadas de 'a' a 'z', pero as letras non ASCII están inalteradas.
    ///
    /// Para devolver un novo valor en minúscula sen modificar o existente, use [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Devolve `true` se algún byte da palabra `v` é nonascii (>=128).
/// Arrincado desde `../str/mod.rs`, que fai algo similar para a validación de utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Proba ASCII optimizada que usará operacións de uso por vez en vez de operacións de byte á vez (cando sexa posible).
///
/// O algoritmo que usamos aquí é bastante sinxelo.Se `s` é demasiado curto, comprobamos cada byte e rematamos con el.Se non:
///
/// - Lea a primeira palabra cunha carga non aliñada.
/// - Aliña o punteiro, le as palabras seguintes ata rematar con cargas aliñadas.
/// - Lea o último `usize` de `s` cunha carga non aliñada.
///
/// Se algunha destas cargas produce algo para o que `contains_nonascii` (above) devolve verdadeiro, entón sabemos que a resposta é falsa.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Se non gañaríamos nada da implementación palabra por vez, volvamos a un bucle escalar.
    //
    // Tamén o facemos para arquitecturas onde `size_of::<usize>()` non é suficiente para `usize`, porque é un estraño caso edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Sempre lemos a primeira palabra sen aliñar, o que significa que `align_offset` é
    // 0, volveriamos ler o mesmo valor para a lectura aliñada.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SEGURIDADE: verificamos `len < USIZE_SIZE` anterior.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Comprobámolo anteriormente, de xeito implícito.
    // Teña en conta que `offset_to_aligned` é `align_offset` ou `USIZE_SIZE`, ambos os dous están comprobados explicitamente anteriormente.
    //
    debug_assert!(offset_to_aligned <= len);

    // SEGURIDADE: word_ptr é o ptr usize (correctamente aliñado) que usamos para ler o
    // anaco medio da porción.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` é o índice de bytes de `word_ptr`, usado para comprobar o final do bucle.
    let mut byte_pos = offset_to_aligned;

    // Comprobación da paranoia sobre o aliñamento, xa que estamos a piques de facer unha chea de cargas non aliñadas.
    // Na práctica, isto debería ser imposible excluíndo un erro en `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Lea as palabras posteriores ata a última palabra aliñada, excluíndo a última palabra aliñada por si mesma que se fará na verificación de cola máis tarde, para asegurarse de que a cola sempre é un `usize` como máximo a branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Comprobar a cordura que a lectura está dentro dos límites
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // E que as nosas hipóteses sobre `byte_pos` manteñen.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SEGURIDADE: sabemos que `word_ptr` está correctamente aliñado (debido a
        // "align_offset"), e sabemos que temos suficientes bytes entre `word_ptr` e o final
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SEGURIDADE: Sabemos que `byte_pos <= len - USIZE_SIZE`, o que significa iso
        // despois deste `add`, `word_ptr` será como máximo un-de-final.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Comprobación de sanidade para asegurarse de que só queda un `usize`.
    // Isto debería estar garantido pola nosa condición de bucle.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SEGURIDADE: isto depende de `len >= USIZE_SIZE`, que comprobamos ao comezo.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}