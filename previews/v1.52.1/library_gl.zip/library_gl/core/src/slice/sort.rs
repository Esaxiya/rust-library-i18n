//! Clasificación por porcións
//!
//! Este módulo contén un algoritmo de ordenación baseado no quicksort de Orson Peters que derrota o patrón, publicado en: <https://github.com/orlp/pdqsort>
//!
//!
//! A ordenación inestable é compatible con libcore porque non asigna memoria, a diferenza da nosa implementación de ordenación estable.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Cando se deixa caer, copias de `src` a `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SEGURIDADE: Esta é unha clase auxiliar.
        //          Consulte o seu uso para ver a corrección.
        //          É dicir, hai que estar seguro de que `src` e `dst` non se superpoñen segundo o esixe `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Move o primeiro elemento cara á dereita ata que atopa un elemento maior ou igual.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SEGURIDADE: As operacións non seguras que se indican a continuación inclúen a indexación sen comprobación vinculada (`get_unchecked` e `get_unchecked_mut`)
    // e copiando memoria (`ptr::copy_nonoverlapping`).
    //
    // a.Indexación:
    //  1. Comprobamos o tamaño da matriz a>=2.
    //  2. Toda a indexación que faremos sempre está entre {0 <= index < len} como máximo.
    //
    // b.Copia de memoria
    //  1. Estamos a obter indicacións sobre referencias que se garante que son válidas.
    //  2. Non se poden solapar porque obtemos indicadores de índices de diferenza da porción.
    //     A saber, `i` e `i-1`.
    //  3. Se a porción está correctamente aliñada, os elementos están correctamente aliñados.
    //     É responsabilidade do interlocutor asegurarse de que a porción estea correctamente aliñada.
    //
    // Vexa os comentarios a continuación para máis detalles.
    unsafe {
        // Se os dous primeiros elementos están fóra de ordenación ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Lea o primeiro elemento nunha variable asignada a pila.
            // Se unha seguinte operación de comparación panics, `hole` caerá e escribirá automaticamente o elemento na porción.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Mova o elemento `i`-th un lugar á esquerda, desprazando así o burato cara á dereita.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` cae e copia `tmp` no burato restante de `v`.
        }
    }
}

/// Move o último elemento cara á esquerda ata que atopa un elemento máis pequeno ou igual.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SEGURIDADE: As operacións non seguras que se indican a continuación inclúen a indexación sen comprobación vinculada (`get_unchecked` e `get_unchecked_mut`)
    // e copiando memoria (`ptr::copy_nonoverlapping`).
    //
    // a.Indexación:
    //  1. Comprobamos o tamaño da matriz a>=2.
    //  2. Toda a indexación que faremos sempre está entre `0 <= index < len-1` como máximo.
    //
    // b.Copia de memoria
    //  1. Estamos a obter indicacións sobre referencias que se garante que son válidas.
    //  2. Non se poden solapar porque obtemos indicadores de índices de diferenza da porción.
    //     A saber, `i` e `i+1`.
    //  3. Se a porción está correctamente aliñada, os elementos están correctamente aliñados.
    //     É responsabilidade do interlocutor asegurarse de que a porción estea correctamente aliñada.
    //
    // Vexa os comentarios a continuación para máis detalles.
    unsafe {
        // Se os dous últimos elementos están fóra de ordenación ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Lea o último elemento nunha variable asignada a pila.
            // Se unha seguinte operación de comparación panics, `hole` caerá e escribirá automaticamente o elemento na porción.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Move o elemento `i`-th un lugar á dereita, desprazando así o burato cara á esquerda.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` cae e copia `tmp` no burato restante de `v`.
        }
    }
}

/// Ordena parcialmente unha porción cambiando varios elementos fóra de orde.
///
/// Devolve `true` se a porción se ordena ao final.Esta función é *O*(*n*) no peor dos casos.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Número máximo de pares adxacentes fóra de orde que se cambiarán.
    const MAX_STEPS: usize = 5;
    // Se a porción é máis curta que esta, non cambies ningún elemento.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SEGURIDADE: Xa fixemos explícitamente a comprobación vinculada con `i < len`.
        // Toda a nosa indexación posterior só está no rango `0 <= index < len`
        unsafe {
            // Atopar o seguinte par de elementos adxacentes fóra de orde.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Rematamos?
        if i == len {
            return true;
        }

        // Non mova elementos en matrices curtas, o que ten un custo de rendemento.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Intercambia o par de elementos atopado.Isto colócaos nunha orde correcta.
        v.swap(i - 1, i);

        // Move o elemento máis pequeno cara á esquerda.
        shift_tail(&mut v[..i], is_less);
        // Move o elemento maior cara á dereita.
        shift_head(&mut v[i..], is_less);
    }

    // Non conseguín clasificar a porción no número limitado de pasos.
    false
}

/// Ordena unha porción empregando ordenación por inserción, que é o peor dos casos *O*(*n*^ 2).
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Ordena `v` usando o heapsort, o que garante *O*(*n*\*log(* n*)) no peor dos casos.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Este montón binario respecta o invariante `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Fillos de `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Escolle o fillo maior.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Pare se o invariante mantense en `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Cambia `node` co fillo maior, mova un chanzo cara abaixo e continúa peneirando.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Constrúe o montón en tempo lineal.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Saia elementos máximos do montón.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Particiona `v` en elementos menores que `pivot`, seguidos de elementos maiores ou iguais a `pivot`.
///
///
/// Devolve o número de elementos inferiores a `pivot`.
///
/// O particionado realízase bloque por bloque co fin de minimizar o custo das operacións de ramificación.
/// Esta idea preséntase no xornal [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Número de elementos nun bloque típico.
    const BLOCK: usize = 128;

    // O algoritmo de partición repite os seguintes pasos ata completalo:
    //
    // 1. Trazar un bloque desde o lado esquerdo para identificar elementos maiores ou iguais ao pivote.
    // 2. Trazar un bloque dende o lado dereito para identificar elementos máis pequenos que o pivote.
    // 3. Intercambia os elementos identificados entre o lado esquerdo e o dereito.
    //
    // Gardamos as seguintes variables para un bloque de elementos:
    //
    // 1. `block` - Número de elementos do bloque.
    // 2. `start` - Comeza o punteiro na matriz `offsets`.
    // 3. `end` - Punteiro final na matriz `offsets`.
    // 4. `offsets, índices de elementos fóra de ordenación dentro do bloque.

    // O bloque actual no lado esquerdo (de `l` a `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // O bloque actual no lado dereito (desde `r.sub(block_r)` to `r`).
    // SEGURIDADE: A documentación para .add() menciona especificamente que `vec.as_ptr().add(vec.len())` sempre é seguro '
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Cando obteñamos VLA, intente crear unha matriz de lonxitude `min(v.len(), 2 * BLOCK) `
    // de dúas matrices de tamaño fixo de lonxitude `BLOCK`.Os VLA poden ser máis eficientes na caché.

    // Devolve o número de elementos entre os punteiros `l` (inclusive) e `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Rematamos de particionar bloque por bloque cando `l` e `r` se achegan moito.
        // Despois facemos un traballo de reparación para particionar os elementos restantes no medio.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Número de elementos restantes (aínda non se compara co pivote).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Axuste os tamaños de bloques para que o bloque esquerdo e dereito non se superpoñan, senón que queden perfectamente aliñados para cubrir todo o espazo restante.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Trazar elementos `block_l` desde o lado esquerdo.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SEGURIDADE: As seguintes operacións de seguridade implican o uso do `offset`.
                //         Segundo as condicións requiridas pola función, satisfacémolas porque:
                //         1. `offsets_l` está asignado en pila e, polo tanto, considérase obxecto asignado separado.
                //         2. A función `is_less` devolve un `bool`.
                //            Lanzar un `bool` nunca desbordará `isize`.
                //         3. Garantimos que `block_l` será `<= BLOCK`.
                //            Ademais, `end_l` configurouse inicialmente no punteiro de inicio de `offsets_` que foi declarado na pila.
                //            Así, sabemos que incluso no peor dos casos (todas as invocacións de `is_less` devolven falsas) só teremos como máximo un byte para pasar o final.
                //        Outra operación de seguridade aquí é a desferenciación de `elem`.
                //        Non obstante, `elem` foi inicialmente o punteiro de inicio á sección que sempre é válido.
                unsafe {
                    // Comparación sen ramas.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Trazar elementos `block_r` dende o lado dereito.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SEGURIDADE: As seguintes operacións de seguridade implican o uso do `offset`.
                //         Segundo as condicións requiridas pola función, satisfacémolas porque:
                //         1. `offsets_r` está asignado en pila e, polo tanto, considérase obxecto asignado separado.
                //         2. A función `is_less` devolve un `bool`.
                //            Lanzar un `bool` nunca desbordará `isize`.
                //         3. Garantimos que `block_r` será `<= BLOCK`.
                //            Ademais, `end_r` configurouse inicialmente no punteiro de inicio de `offsets_` que foi declarado na pila.
                //            Así, sabemos que incluso no peor dos casos (todas as invocacións de `is_less` devolven verdadeiro) só teremos como máximo 1 byte para pasar o final.
                //        Outra operación de seguridade aquí é a desferenciación de `elem`.
                //        Non obstante, `elem` foi inicialmente `1 *sizeof(T)` pasado o final e decrementámolo por `1* sizeof(T)` antes de acceder a el.
                //        Ademais, afirmouse que `block_r` era inferior a `BLOCK` e, polo tanto, `elem` apuntará ao comezo da porción.
                unsafe {
                    // Comparación sen ramas.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Número de elementos fóra de orde para intercambiar entre o lado esquerdo e o dereito.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // En vez de intercambiar un par á vez, é máis eficiente realizar unha permutación cíclica.
            // Isto non é estritamente equivalente ao intercambio, pero produce un resultado similar empregando menos operacións de memoria.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Movéronse todos os elementos fóra de orde do bloque esquerdo.Pasa ao seguinte bloque.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Movéronse todos os elementos fóra de orde do bloque dereito.Mover ao bloque anterior.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Agora só queda como máximo un bloque (xa sexa á esquerda ou á dereita) con elementos fóra de orden que hai que mover.
    // Estes elementos restantes poden simplemente desprazarse ao final dentro do seu bloque.
    //

    if start_l < end_l {
        // O bloque esquerdo permanece.
        // Move os seus restantes elementos fóra de ordenación á extrema dereita.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Queda o bloque dereito.
        // Move os seus restantes elementos fóra de ordenación á extrema esquerda.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Nada máis que facer, rematamos.
        width(v.as_mut_ptr(), l)
    }
}

/// Particiona `v` en elementos menores que `v[pivot]`, seguidos de elementos maiores ou iguais a `v[pivot]`.
///
///
/// Devolve unha tupla de:
///
/// 1. Número de elementos inferiores a `v[pivot]`.
/// 2. É certo se `v` xa estaba particionado.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Coloque o pivote ao comezo da porción.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Lea o pivote nunha variable asignada a pila para obter eficiencia.
        // Se se realiza unha seguinte operación de comparación panics, o pivote volverá a escribirse automaticamente na porción.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Atopa o primeiro par de elementos fóra de orde.
        let mut l = 0;
        let mut r = v.len();

        // SEGURIDADE: A inseguridade seguinte implica a indexación dunha matriz.
        // Para o primeiro: xa facemos os límites comprobando aquí con `l < r`.
        // Para o segundo: inicialmente temos `l == 0` e `r == v.len()` e comprobamos que `l < r` en cada operación de indexación.
        //                     A partir de aquí sabemos que `r` debe ser como mínimo `r == l`, o que demostrou ser válido desde o primeiro.
        unsafe {
            // Atopar o primeiro elemento maior ou igual que o pivote.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Atopa o último elemento máis pequeno que o pivote.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` sae do alcance e escribe o pivote (que é unha variable asignada á pila) de novo na porción onde estaba orixinalmente.
        // Este paso é fundamental para garantir a seguridade.
        //
    };

    // Coloque o pivote entre as dúas particións.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Particiona `v` en elementos iguais a `v[pivot]` seguidos de elementos maiores que `v[pivot]`.
///
/// Devolve o número de elementos igual ao pivote.
/// Suponse que `v` non contén elementos máis pequenos que o pivote.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Coloque o pivote ao comezo da porción.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Lea o pivote nunha variable asignada a pila para obter eficiencia.
    // Se se realiza unha seguinte operación de comparación panics, o pivote volverá a escribirse automaticamente na porción.
    // SEGURIDADE: o punteiro aquí é válido porque se obtén a partir dunha referencia a unha porción.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Agora particione a porción.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SEGURIDADE: A inseguridade seguinte implica a indexación dunha matriz.
        // Para o primeiro: xa facemos os límites comprobando aquí con `l < r`.
        // Para o segundo: inicialmente temos `l == 0` e `r == v.len()` e comprobamos que `l < r` en cada operación de indexación.
        //                     A partir de aquí sabemos que `r` debe ser como mínimo `r == l`, o que demostrou ser válido desde o primeiro.
        unsafe {
            // Atopa o primeiro elemento maior que o pivote.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Atopar o último elemento igual ao pivote.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Rematamos?
            if l >= r {
                break;
            }

            // Intercambia o par atopado de elementos fóra de orde.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Atopamos elementos `l` iguais ao pivote.Engade 1 para dar conta do propio pivote.
    l + 1

    // `_pivot_guard` sae do alcance e escribe o pivote (que é unha variable asignada á pila) de novo na porción onde estaba orixinalmente.
    // Este paso é fundamental para garantir a seguridade.
}

/// Dispersa algúns elementos ao redor nun intento de romper patróns que poden causar particións desequilibradas en corto.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Xerador de números aleatorios a partir do papel "Xorshift RNGs" de George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Toma números aleatorios módulo este número.
        // O número encaixa en `usize` porque `len` non é maior que `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Algúns candidatos pivote estarán preto deste índice.Imos aleatorizalos.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Xera un número aleatorio módulo `len`.
            // Non obstante, para evitar operacións custosas, primeiro tomamos un módulo cunha potencia de dous e despois diminuímos en `len` ata que se axuste ao rango `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` está garantido por ser inferior a `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Elixe un pivote en `v` e devolve o índice e `true` se é probable que a porción xa estea ordenada.
///
/// Os elementos en `v` poden reordenarse no proceso.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Lonxitude mínima para escoller o método de mediana de medianas.
    // As franxas máis curtas usan o método simple mediana de tres.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Número máximo de permutas que se poden realizar nesta función.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tres índices preto dos cales imos escoller un pivote.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Conta o número total de swaps que estamos a piques de realizar ao ordenar os índices.
    let mut swaps = 0;

    if len >= 8 {
        // Cambia índices para que `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Cambia índices para que `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Atopa a mediana de `v[a - 1], v[a], v[a + 1]` e almacena o índice en `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Busque medianas nos barrios de `a`, `b` e `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Atopa a mediana entre `a`, `b` e `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Realizouse o número máximo de permutas.
        // É probable que a porción sexa descendente ou maioritariamente descendente, polo que a inversión probablemente axude a ordenala máis rápido.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Ordena `v` recursivamente.
///
/// Se a porción tiña un predecesor na matriz orixinal, especifícase como `pred`.
///
/// `limit` é o número de particións desequilibradas permitidas antes de cambiar a `heapsort`.
/// Se é cero, esta función cambiará inmediatamente a un enorme.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // As franxas de ata esta lonxitude clasifícanse mediante ordenación por inserción.
    const MAX_INSERTION: usize = 20;

    // Certo se o último particionamento estivo razoablemente equilibrado.
    let mut was_balanced = true;
    // É certo se o último particionamento non mesturaba elementos (a porción xa estaba particionada).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // As franxas moi curtas clasifícanse mediante a clasificación por inserción.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Se se tomaron demasiadas malas eleccións de pivote, simplemente volve a pór en serio para garantir o peor caso de `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Se o último particionamento estaba desequilibrado, proba a romper patróns na porción barallando algúns elementos ao redor.
        // Con sorte escolleremos un pivote mellor esta vez.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Escolla un pivote e intente adiviñar se a porción xa está ordenada.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Se o último particionamento estivo decentemente equilibrado e non mesturou elementos e se a selección de pivote predice que a porción probablemente xa estea ordenada ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Proba a identificar varios elementos fóra de orde e cambialos a posicións correctas.
            // Se a porción acaba por ordenarse por completo, rematamos.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Se o pivote elixido é igual ao predecesor, entón é o elemento máis pequeno da porción.
        // Particione a porción en elementos iguais a e elementos maiores que o pivote.
        // Este caso adoita acertarse cando a porción contén moitos elementos duplicados.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Continúa ordenando elementos maiores que o pivote.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Particionar a porción.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Dividir a porción en `left`, `pivot` e `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Recurse no lado máis curto só para minimizar o número total de chamadas recursivas e consumir menos espazo na pila.
        // A continuación, continúa co lado máis longo (isto é similar á recursión da cola).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Ordena `v` usando o rápido cadro que derrota patróns, que é *O*(*n*\*log(* n*)) no peor dos casos.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // A ordenación non ten un comportamento significativo en tipos de tamaño cero.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Limita o número de particións desequilibradas a `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Para franxas de ata esta lonxitude probablemente sexa máis rápido simplemente ordenalos.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Elixe un pivote
        let (pivot, _) = choose_pivot(v, is_less);

        // Se o pivote elixido é igual ao predecesor, entón é o elemento máis pequeno da porción.
        // Particione a porción en elementos iguais a e elementos maiores que o pivote.
        // Este caso adoita acertarse cando a porción contén moitos elementos duplicados.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Se pasamos o noso índice, entón estamos ben.
                if mid > index {
                    return;
                }

                // Se non, continúa ordenando elementos maiores que o pivote.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Dividir a porción en `left`, `pivot` e `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Se mid==index, rematamos, xa que partition() garantiu que todos os elementos despois mid son maiores ou iguais a mid.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // A ordenación non ten un comportamento significativo en tipos de tamaño cero.Non fagas nada.
    } else if index == v.len() - 1 {
        // Atopa o elemento max e colócao na última posición da matriz.
        // Aquí somos libres de usar `unwrap()` porque sabemos que v non debe estar baleiro.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Atopa un elemento min e colócao na primeira posición da matriz.
        // Aquí somos libres de usar `unwrap()` porque sabemos que v non debe estar baleiro.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}