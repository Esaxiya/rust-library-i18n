// ignore-tidy-filelength

//! Manexo e manipulación de cortes.
//!
//! Para máis detalles, consulte [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Implementación pura rust memchr, extraída de rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Esta función é pública só porque non hai outro xeito de probar unidade.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Devolve o número de elementos da porción.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SEGURIDADE: son constante porque transmutamos o campo de lonxitude como usize (que debe ser)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SEGURIDADE: isto é seguro porque `&[T]` e `FatPtr<T>` teñen o mesmo deseño.
            // Só `std` pode facer esta garantía.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Substitúeo por `crate::ptr::metadata(self)` cando sexa estable.
            // A partir desta redacción isto provoca un erro "Const-stable functions can only call other const-stable functions".
            //

            // SEGURIDADE: acceder ao valor desde a unión `PtrRepr` é seguro dende * const T
            // e PtrComponents<T>teñen os mesmos deseños de memoria.
            // Só std pode facer esta garantía.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Devolve `true` se a porción ten unha lonxitude de 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Devolve o primeiro elemento da porción ou `None` se está baleiro.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Devolve un punteiro mudable ao primeiro elemento da porción ou `None` se está baleiro.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Devolve o primeiro e todo o resto dos elementos da porción ou `None` se está baleiro.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Devolve o primeiro e todo o resto dos elementos da porción ou `None` se está baleiro.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Devolve o último e todo o resto dos elementos da porción ou `None` se está baleiro.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Devolve o último e todo o resto dos elementos da porción ou `None` se está baleiro.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Devolve o último elemento da porción ou `None` se está baleiro.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Devolve un punteiro mudable ao último elemento da porción.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Devolve unha referencia a un elemento ou subslice dependendo do tipo de índice.
    ///
    /// - Se se lle dá unha posición, devolve unha referencia ao elemento nesa posición ou `None` se está fóra dos límites.
    ///
    /// - Se se lle dá un rango, devolve o subclase correspondente a ese rango ou `None` se está fóra dos límites.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Devolve unha referencia mudable a un elemento ou subslice dependendo do tipo de índice (ver [`get`]) ou `None` se o índice está fóra dos límites.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Devolve unha referencia a un elemento ou subslice, sen facer comprobación de límites.
    ///
    /// Para obter unha alternativa segura, consulte [`get`].
    ///
    /// # Safety
    ///
    /// Chamar a este método cun índice fóra dos límites é *[comportamento indefinido]* aínda que non se use a referencia resultante.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SEGURIDADE: o interlocutor debe cumprir a maioría dos requisitos de seguridade para `get_unchecked`;
        // a porción non se pode referenciar porque `self` é unha referencia segura.
        // O punteiro devolto é seguro porque as aplicacións de `SliceIndex` teñen que garantir que o é.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Devolve unha referencia mudable a un elemento ou subslice, sen facer comprobación de límites.
    ///
    /// Para obter unha alternativa segura, consulte [`get_mut`].
    ///
    /// # Safety
    ///
    /// Chamar a este método cun índice fóra dos límites é *[comportamento indefinido]* aínda que non se use a referencia resultante.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SEGURIDADE: o interlocutor debe cumprir os requisitos de seguridade para `get_unchecked_mut`;
        // a porción non se pode referenciar porque `self` é unha referencia segura.
        // O punteiro devolto é seguro porque as aplicacións de `SliceIndex` teñen que garantir que o é.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Devolve un punteiro en bruto ao búfer da porción.
    ///
    /// O interlocutor debe asegurarse de que a porción sobrevive ao punteiro que devolve esta función, ou ben acabará apuntando ao lixo.
    ///
    /// O interlocutor tamén debe asegurarse de que a memoria á que apunta o punteiro (non-transitively) nunca se escribe (excepto dentro dun `UnsafeCell`) usando este punteiro ou calquera outro derivado del.
    /// Se precisa mutar o contido da porción, use [`as_mut_ptr`].
    ///
    /// A modificación do contedor a que fai referencia esta porción pode provocar a reasignación do seu búfer, o que tamén faría que calquera indicador non fose válido.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Devolve un punteiro mutable non seguro ao búfer da porción.
    ///
    /// O interlocutor debe asegurarse de que a porción sobrevive ao punteiro que devolve esta función, ou ben acabará apuntando ao lixo.
    ///
    /// A modificación do contedor a que fai referencia esta porción pode provocar a reasignación do seu búfer, o que tamén faría que calquera indicador non fose válido.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Devolve os dous punteiros en bruto que abarcan a porción.
    ///
    /// O intervalo devolto está medio aberto, o que significa que o punteiro final apunta *un pasado* o último elemento da porción.
    /// Deste xeito, unha porción baleira represéntase por dous punteiros iguais e a diferenza entre os dous punteiros representa o tamaño da porción.
    ///
    /// Vexa [`as_ptr`] para avisos sobre o uso destes punteiros.O punteiro final require unha precaución adicional, xa que non apunta a un elemento válido na porción.
    ///
    /// Esta función é útil para interactuar con interfaces estrañas que usan dous punteiros para referirse a unha serie de elementos na memoria, como é común en C++ .
    ///
    ///
    /// Tamén pode ser útil comprobar se un punteiro a un elemento fai referencia a un elemento desta porción:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SEGURIDADE: o `add` aquí é seguro porque:
        //
        //   - Ambos os dous punteiros forman parte do mesmo obxecto, xa que o feito de apuntar directamente despois do obxecto tamén conta.
        //
        //   - O tamaño da porción nunca é superior a isize::MAX bytes, como se indica aquí:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Non hai ningún tipo de envoltura, xa que as franxas non pasan do extremo do espazo de enderezos.
        //
        // Consulte a documentación de pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Devolve os dous punteiros mutables non seguros que abarcan a porción.
    ///
    /// O intervalo devolto está medio aberto, o que significa que o punteiro final apunta *un pasado* o último elemento da porción.
    /// Deste xeito, unha porción baleira represéntase por dous punteiros iguais e a diferenza entre os dous punteiros representa o tamaño da porción.
    ///
    /// Vexa [`as_mut_ptr`] para avisos sobre o uso destes punteiros.
    /// O punteiro final require unha precaución adicional, xa que non apunta a un elemento válido na porción.
    ///
    /// Esta función é útil para interactuar con interfaces estrañas que usan dous punteiros para referirse a unha serie de elementos na memoria, como é común en C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SEGURIDADE: Vexa as_ptr_range() anterior para saber por que `add` aquí é seguro.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Cambia dous elementos na porción.
    ///
    /// # Arguments
    ///
    /// * a, O índice do primeiro elemento
    /// * b, o índice do segundo elemento
    ///
    /// # Panics
    ///
    /// Panics se `a` ou `b` están fóra dos límites.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Non se poden coller dous préstamos mutables dun vector, polo que emprega punteiros en bruto.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SEGURIDADE: `pa` e `pb` creáronse a partir de referencias e referencias seguras mutables
        // aos elementos da porción e, polo tanto, está garantido que son válidos e aliñados.
        // Teña en conta que o acceso aos elementos detrás de `a` e `b` está comprobado e fará que panic estea fóra dos límites.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Inverte a orde dos elementos da porción no lugar.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Para tipos moi pequenos, todas as lecturas individuais no camiño normal funcionan mal.
        // Podemos facelo mellor, dada a eficacia do load/store sen aliñar, cargando un anaco máis grande e revertendo un rexistro.
        //

        // Idealmente LLVM faría isto por nós, xa que sabe mellor que nós se as lecturas non aliñadas son eficientes (xa que iso cambia entre as diferentes versións de ARM, por exemplo) e cal sería o mellor tamaño do fragmento.
        // Por desgraza, a partir de LLVM 4.0 (2017-05) só desenrola o bucle, polo que debemos facelo nós mesmos.
        // (Hipótese: o reverso é problemático porque os lados poden aliñarse de xeito diferente, será cando a lonxitude é impar, polo que non hai forma de emitir pre e postludios para usar SIMD totalmente aliñado no medio.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Use o llvm.bswap intrínseco para reverter u8s nun usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SEGURIDADE: Aquí hai varias cousas que comprobar:
                //
                // - Teña en conta que `chunk` é 4 ou 8 debido á verificación cfg anterior.Entón `chunk - 1` é positivo.
                // - A indexación co índice `i` está ben, como garante a comprobación do bucle
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - A indexación co índice `ln - i - chunk = ln - (i + chunk)` está ben:
                //   - `i + chunk > 0` é trivialmente certo.
                //   - A comprobación de bucle garante:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, polo tanto, a resta non desborda.
                // - As chamadas `read_unaligned` e `write_unaligned` están ben:
                //   - `pa` apunta ao índice `i` onde `i < ln / 2 - (chunk - 1)` (ver arriba) e `pb` apunta ao índice `ln - i - chunk`, polo que ambos están polo menos `chunk` a moitos bytes de distancia do final de `self`.
                //
                //   - Calquera memoria inicializada é válida `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Use xirar por 16 para reverter u16 nun u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SEGURIDADE: pódese ler un u32 non aliñado desde `i` se `i + 1 < ln`
                // (e obviamente `i < ln`), porque cada elemento ten 2 bytes e estamos a ler 4.
                //
                // `i + chunk - 1 < ln / 2` # mentres condición
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Como é menor que a lonxitude dividida por 2, entón debe estar dentro dos límites.
                //
                // Isto tamén significa que sempre se respecta a condición `0 < i + chunk <= ln`, garantindo que o punteiro `pb` se poida usar con seguridade.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SEGURIDADE: `i` é inferior á metade da lonxitude da porción
            // acceder a `i` e `ln - i - 1` é seguro (`i` comeza a 0 e non irá máis alá de `ln / 2 - 1`).
            // Os punteiros resultantes `pa` e `pb` son, polo tanto, válidos e aliñados e pódense ler e escribir en.
            //
            //
            unsafe {
                // Intercambio non seguro para evitar os límites comprobar o intercambio seguro.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Devolve un iterador sobre a porción.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Devolve un iterador que permite modificar cada valor.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Devolve un iterador sobre todos os contiguos windows de lonxitude `size`.
    /// O windows superpón.
    /// Se a porción é máis curta que `size`, o iterador non devolve valores.
    ///
    /// # Panics
    ///
    /// Panics se `size` é 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Se a porción é máis curta que `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Devolve un iterador sobre elementos `chunk_size` da porción á vez, comezando polo comezo da porción.
    ///
    /// Os anacos son franxas e non se superpoñen.Se `chunk_size` non divide a lonxitude da porción, o último anaco non terá a lonxitude `chunk_size`.
    ///
    /// Vexa [`chunks_exact`] para ver unha variante deste iterador que devolve anacos de elementos `chunk_size` sempre exactamente, e [`rchunks`] para o mesmo iterador pero comezando ao final da porción.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` é 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Devolve un iterador sobre elementos `chunk_size` da porción á vez, comezando polo comezo da porción.
    ///
    /// Os anacos son franxas mutables e non se superpoñen.Se `chunk_size` non divide a lonxitude da porción, o último anaco non terá a lonxitude `chunk_size`.
    ///
    /// Vexa [`chunks_exact_mut`] para ver unha variante deste iterador que devolve anacos de elementos `chunk_size` sempre exactamente, e [`rchunks_mut`] para o mesmo iterador pero comezando ao final da porción.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` é 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Devolve un iterador sobre elementos `chunk_size` da porción á vez, comezando polo comezo da porción.
    ///
    /// Os anacos son franxas e non se superpoñen.
    /// Se `chunk_size` non divide a lonxitude da porción, omitiranse os últimos elementos ata `chunk_size-1` e poderanse recuperar da función `remainder` do iterador.
    ///
    ///
    /// Debido a que cada anaco ten exactamente elementos `chunk_size`, o compilador a miúdo pode optimizar o código resultante mellor que no caso de [`chunks`].
    ///
    /// Vexa [`chunks`] para ver unha variante deste iterador que tamén devolve o resto como un anaco máis pequeno e [`rchunks_exact`] para o mesmo iterador pero comezando ao final da porción.
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` é 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Devolve un iterador sobre elementos `chunk_size` da porción á vez, comezando polo comezo da porción.
    ///
    /// Os anacos son franxas mutables e non se superpoñen.
    /// Se `chunk_size` non divide a lonxitude da porción, omitiranse os últimos elementos ata `chunk_size-1` e poderanse recuperar da función `into_remainder` do iterador.
    ///
    ///
    /// Debido a que cada anaco ten exactamente elementos `chunk_size`, o compilador a miúdo pode optimizar o código resultante mellor que no caso de [`chunks_mut`].
    ///
    /// Vexa [`chunks_mut`] para ver unha variante deste iterador que tamén devolve o resto como un anaco máis pequeno e [`rchunks_exact_mut`] para o mesmo iterador pero comezando ao final da porción.
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` é 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Divide a porción nunha porción de matrices de elementos `N`, supoñendo que non queda resto.
    ///
    ///
    /// # Safety
    ///
    /// Isto só se pode chamar cando
    /// - A porción divídese exactamente en anacos de elemento "N" (tamén coñecido como `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SEGURIDADE: os anacos de 1 elemento nunca teñen resto
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SEGURIDADE: A lonxitude da porción (6) é múltiplo de 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Estes serían inútiles:
    /// // deixamos anacos: &[[_;5]]= slice.as_chunks_unchecked()//A lonxitude da porción non é múltiplo de 5 cantidades:&[[_;0]]= slice.as_chunks_unchecked()//Nunca se permiten anacos de lonxitude cero
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SEGURIDADE: a nosa condición previa é exactamente o que se precisa para chamar isto
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SEGURIDADE: lanzamos unha porción de elementos `new_len * N`
        // unha porción de `new_len` moitos anacos de elementos `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Divide a porción nunha porción de matrices de elementos `N`, comezando polo comezo da porción, e unha porción restante cunha lonxitude estritamente inferior a `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `N` é 0. Esta comprobación probablemente cambiarase a un erro de tempo de compilación antes de que este método se estabilice.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SEGURIDADE: Xa entramos en pánico por cero e aseguramos coa construción
        // que a lonxitude do subslice é múltiplo de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Divide a porción nunha porción de matrices de elementos `N`, comezando ao final da porción, e unha porción restante cunha lonxitude estritamente inferior a `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `N` é 0. Esta comprobación probablemente cambiarase a un erro de tempo de compilación antes de que este método se estabilice.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SEGURIDADE: Xa entramos en pánico por cero e aseguramos coa construción
        // que a lonxitude do subslice é múltiplo de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Devolve un iterador sobre elementos `N` da porción á vez, comezando polo comezo da porción.
    ///
    /// Os anacos son referencias de matriz e non se superpoñen.
    /// Se `N` non divide a lonxitude da porción, omitiranse os últimos elementos ata `N-1` e poderanse recuperar da función `remainder` do iterador.
    ///
    ///
    /// Este método é o equivalente xenérico constante de [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics se `N` é 0. Esta comprobación probablemente cambiarase a un erro de tempo de compilación antes de que este método se estabilice.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Divide a porción nunha porción de matrices de elementos `N`, supoñendo que non queda resto.
    ///
    ///
    /// # Safety
    ///
    /// Isto só se pode chamar cando
    /// - A porción divídese exactamente en anacos de elemento "N" (tamén coñecido como `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SEGURIDADE: os anacos de 1 elemento nunca teñen resto
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SEGURIDADE: A lonxitude da porción (6) é múltiplo de 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Estes serían inútiles:
    /// // deixamos anacos: &[[_;5]]= slice.as_chunks_unchecked_mut()//A lonxitude da porción non é múltiplo de 5 cantidades:&[[_;0]]= slice.as_chunks_unchecked_mut()//Nunca se permiten anacos de lonxitude cero
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SEGURIDADE: a nosa condición previa é exactamente o que se precisa para chamar isto
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SEGURIDADE: lanzamos unha porción de elementos `new_len * N`
        // unha porción de `new_len` moitos anacos de elementos `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Divide a porción nunha porción de matrices de elementos `N`, comezando polo comezo da porción, e unha porción restante cunha lonxitude estritamente inferior a `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `N` é 0. Esta comprobación probablemente cambiarase a un erro de tempo de compilación antes de que este método se estabilice.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SEGURIDADE: Xa entramos en pánico por cero e aseguramos coa construción
        // que a lonxitude do subslice é múltiplo de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Divide a porción nunha porción de matrices de elementos `N`, comezando ao final da porción, e unha porción restante cunha lonxitude estritamente inferior a `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `N` é 0. Esta comprobación probablemente cambiarase a un erro de tempo de compilación antes de que este método se estabilice.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SEGURIDADE: Xa entramos en pánico por cero e aseguramos coa construción
        // que a lonxitude do subslice é múltiplo de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Devolve un iterador sobre elementos `N` da porción á vez, comezando polo comezo da porción.
    ///
    /// Os anacos son referencias de matriz mutables e non se superpoñen.
    /// Se `N` non divide a lonxitude da porción, omitiranse os últimos elementos ata `N-1` e poderanse recuperar da función `into_remainder` do iterador.
    ///
    ///
    /// Este método é o equivalente xenérico constante de [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics se `N` é 0. Esta comprobación probablemente cambiarase a un erro de tempo de compilación antes de que este método se estabilice.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Devolve un iterador que se solapa con windows de elementos `N` dunha porción, comezando polo comezo da porción.
    ///
    ///
    /// Este é o equivalente xenérico constante de [`windows`].
    ///
    /// Se `N` é maior que o tamaño da porción, non devolverá ningún windows.
    ///
    /// # Panics
    ///
    /// Panics se `N` é 0.
    /// Esta comprobación probablemente cambiarase a un erro de tempo de compilación antes de que este método se estabilice.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Devolve un iterador sobre elementos `chunk_size` da porción á vez, comezando ao final da porción.
    ///
    /// Os anacos son franxas e non se superpoñen.Se `chunk_size` non divide a lonxitude da porción, o último anaco non terá a lonxitude `chunk_size`.
    ///
    /// Vexa [`rchunks_exact`] para ver unha variante deste iterador que devolve anacos de elementos sempre exactamente `chunk_size` e [`chunks`] para o mesmo iterador pero comezando ao comezo da porción.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` é 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Devolve un iterador sobre elementos `chunk_size` da porción á vez, comezando ao final da porción.
    ///
    /// Os anacos son franxas mutables e non se superpoñen.Se `chunk_size` non divide a lonxitude da porción, o último anaco non terá a lonxitude `chunk_size`.
    ///
    /// Vexa [`rchunks_exact_mut`] para ver unha variante deste iterador que devolve anacos de elementos sempre exactamente `chunk_size` e [`chunks_mut`] para o mesmo iterador pero comezando ao comezo da porción.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` é 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Devolve un iterador sobre elementos `chunk_size` da porción á vez, comezando ao final da porción.
    ///
    /// Os anacos son franxas e non se superpoñen.
    /// Se `chunk_size` non divide a lonxitude da porción, omitiranse os últimos elementos ata `chunk_size-1` e poderanse recuperar da función `remainder` do iterador.
    ///
    /// Debido a que cada anaco ten exactamente elementos `chunk_size`, o compilador a miúdo pode optimizar o código resultante mellor que no caso de [`chunks`].
    ///
    /// Vexa [`rchunks`] para ver unha variante deste iterador que tamén devolve o resto como un anaco máis pequeno e [`chunks_exact`] para o mesmo iterador pero comezando ao comezo da porción.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` é 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Devolve un iterador sobre elementos `chunk_size` da porción á vez, comezando ao final da porción.
    ///
    /// Os anacos son franxas mutables e non se superpoñen.
    /// Se `chunk_size` non divide a lonxitude da porción, omitiranse os últimos elementos ata `chunk_size-1` e poderanse recuperar da función `into_remainder` do iterador.
    ///
    /// Debido a que cada anaco ten exactamente elementos `chunk_size`, o compilador a miúdo pode optimizar o código resultante mellor que no caso de [`chunks_mut`].
    ///
    /// Vexa [`rchunks_mut`] para ver unha variante deste iterador que tamén devolve o resto como un anaco máis pequeno e [`chunks_exact_mut`] para o mesmo iterador pero comezando ao comezo da porción.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` é 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Devolve un iterador sobre a porción producindo carreiras de elementos que non se superpoñen usando o predicado para separalos.
    ///
    /// O predicado está chamado a dous elementos que seguen a si mesmos, significa que o predicado está chamado a `slice[0]` e `slice[1]`, despois a `slice[1]` e `slice[2]`, etc.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Este método pódese usar para extraer as subclases clasificadas:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Devolve un iterador sobre a porción producindo carreiras mutables non superpostas de elementos usando o predicado para separalos.
    ///
    /// O predicado está chamado a dous elementos que seguen a si mesmos, significa que o predicado está chamado a `slice[0]` e `slice[1]`, despois a `slice[1]` e `slice[2]`, etc.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Este método pódese usar para extraer as subclases clasificadas:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Divide unha porción en dúas nun índice.
    ///
    /// O primeiro conterá todos os índices de `[0, mid)` (excluíndo o propio índice `mid`) e o segundo conterá todos os índices de `[mid, len)` (excluíndo o propio índice `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics se `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SEGURIDADE: `[ptr; mid]` e `[mid; len]` están dentro de `self`, que
        // cumpre os requisitos de `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Divide unha porción mutable en dúas nun índice.
    ///
    /// O primeiro conterá todos os índices de `[0, mid)` (excluíndo o propio índice `mid`) e o segundo conterá todos os índices de `[mid, len)` (excluíndo o propio índice `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics se `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SEGURIDADE: `[ptr; mid]` e `[mid; len]` están dentro de `self`, que
        // cumpre os requisitos de `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Divide unha porción en dúas nun índice, sen verificar os límites.
    ///
    /// O primeiro conterá todos os índices de `[0, mid)` (excluíndo o propio índice `mid`) e o segundo conterá todos os índices de `[mid, len)` (excluíndo o propio índice `len`).
    ///
    ///
    /// Para obter unha alternativa segura, consulte [`split_at`].
    ///
    /// # Safety
    ///
    /// Chamar a este método cun índice fóra dos límites é *[comportamento indefinido]* aínda que non se use a referencia resultante.O interlocutor debe asegurarse de que `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SEGURIDADE: o interlocutor debe comprobar que `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Divide unha porción mutable en dúas nun índice, sen verificar os límites.
    ///
    /// O primeiro conterá todos os índices de `[0, mid)` (excluíndo o propio índice `mid`) e o segundo conterá todos os índices de `[mid, len)` (excluíndo o propio índice `len`).
    ///
    ///
    /// Para obter unha alternativa segura, consulte [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Chamar a este método cun índice fóra dos límites é *[comportamento indefinido]* aínda que non se use a referencia resultante.O interlocutor debe asegurarse de que `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SEGURIDADE: o interlocutor debe comprobar que `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` e `[mid; len]` non se superpoñen, polo que devolver unha referencia mutable está ben.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Devolve un iterador sobre subslices separadas por elementos que coinciden con `pred`.
    /// O elemento coincidente non está contido nas subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Se o primeiro elemento coincide, unha porción baleira será o primeiro elemento devolto polo iterador.
    /// Do mesmo xeito, se o último elemento da porción coincide, unha porción baleira será o último elemento devolto polo iterador:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Se dous elementos coincidentes están directamente adxacentes, unha porción baleira estará presente entre eles:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Devolve un iterador sobre subslices mutables separados por elementos que coinciden con `pred`.
    /// O elemento coincidente non está contido nas subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Devolve un iterador sobre subslices separadas por elementos que coinciden con `pred`.
    /// O elemento coincidente está contido ao final da subslice anterior como terminador.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Se o último elemento da porción coincide, ese elemento será considerado o rematador da porción anterior.
    ///
    /// Esa porción será o último elemento devolto polo iterador.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Devolve un iterador sobre subslices mutables separados por elementos que coinciden con `pred`.
    /// O elemento coincidente está contido na subslice anterior como terminador.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Devolve un iterador sobre subslices separadas por elementos que coinciden con `pred`, comezando ao final da porción e traballando cara atrás.
    /// O elemento coincidente non está contido nas subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Do mesmo xeito que con `split()`, se o primeiro ou último elemento coincide, unha porción baleira será o primeiro (ou último) elemento devolto polo iterador.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Devolve un iterador sobre subslices mutables separados por elementos que coinciden con `pred`, comezando ao final da porción e traballando cara atrás.
    /// O elemento coincidente non está contido nas subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Devolve un iterador sobre subslices separadas por elementos que coinciden con `pred`, limitada a devolver como máximo elementos `n`.
    /// O elemento coincidente non está contido nas subslices.
    ///
    /// O último elemento devolto, se o hai, conterá o resto da porción.
    ///
    /// # Examples
    ///
    /// Imprime a porción dividida unha vez por números divisibles por 3 (é dicir, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Devolve un iterador sobre subslices separadas por elementos que coinciden con `pred`, limitada a devolver como máximo elementos `n`.
    /// O elemento coincidente non está contido nas subslices.
    ///
    /// O último elemento devolto, se o hai, conterá o resto da porción.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Devolve un iterador sobre subslices separadas por elementos que coinciden con `pred` limitados a devolver como máximo elementos `n`.
    /// Isto comeza ao final da porción e funciona cara atrás.
    /// O elemento coincidente non está contido nas subslices.
    ///
    /// O último elemento devolto, se o hai, conterá o resto da porción.
    ///
    /// # Examples
    ///
    /// Imprime a porción dividida unha vez, comezando polo final, por números divisibles por 3 (é dicir, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Devolve un iterador sobre subslices separadas por elementos que coinciden con `pred` limitados a devolver como máximo elementos `n`.
    /// Isto comeza ao final da porción e funciona cara atrás.
    /// O elemento coincidente non está contido nas subslices.
    ///
    /// O último elemento devolto, se o hai, conterá o resto da porción.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Devolve `true` se a porción contén un elemento co valor indicado.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Se non tes un `&T`, senón só un `&U` tal que `T: Borrow<U>` (por exemplo
    /// `Cadea: emprestado<str>`), pode usar `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // porción de `String`
    /// assert!(v.iter().any(|e| e == "hello")); // busca con `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Devolve `true` se `needle` é un prefixo da porción.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Devolve sempre `true` se `needle` é unha porción baleira:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Devolve `true` se `needle` é un sufixo da porción.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Devolve sempre `true` se `needle` é unha porción baleira:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Devolve unha subslice co prefixo eliminado.
    ///
    /// Se a porción comeza con `prefix`, devolve a subslice despois do prefixo, envolta en `Some`.
    /// Se `prefix` está baleiro, simplemente devolve a porción orixinal.
    ///
    /// Se a porción non comeza con `prefix`, devolve `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Esta función necesitará reescribirse se e cando SlicePattern se volve máis sofisticado.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Devolve unha subslice co sufixo eliminado.
    ///
    /// Se a porción remata con `suffix`, devolve a subslice antes do sufixo, envolta en `Some`.
    /// Se `suffix` está baleiro, simplemente devolve a porción orixinal.
    ///
    /// Se a porción non remata con `suffix`, devolve `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Esta función necesitará reescribirse se e cando SlicePattern se volve máis sofisticado.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// O binario busca nesta porción ordenada un elemento determinado.
    ///
    /// Se se atopa o valor, devólvese [`Result::Ok`], que contén o índice do elemento coincidente.
    /// Se hai varias coincidencias, pódese devolver calquera das coincidencias.
    /// Se non se atopa o valor, devólvese [`Result::Err`], que contén o índice onde se podería inserir un elemento coincidente mantendo a orde ordenada.
    ///
    ///
    /// Vexa tamén [`binary_search_by`], [`binary_search_by_key`] e [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Busca unha serie de catro elementos.
    /// Atópase o primeiro, cunha posición determinada de xeito único;o segundo e o terceiro non se atopan;o cuarto podería igualar calquera posición en `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Se desexa inserir un elemento nun vector ordenado, mantendo a orde de clasificación:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// O binario busca esta porción ordenada cunha función de comparación.
    ///
    /// A función de comparación debe implementar unha orde consistente coa orde de clasificación da porción subxacente, devolvendo un código de orde que indica se o seu argumento é `Less`, `Equal` ou `Greater` o destino desexado.
    ///
    ///
    /// Se se atopa o valor, devólvese [`Result::Ok`], que contén o índice do elemento coincidente.Se hai varias coincidencias, pódese devolver calquera das coincidencias.
    /// Se non se atopa o valor, devólvese [`Result::Err`], que contén o índice onde se podería inserir un elemento coincidente mantendo a orde ordenada.
    ///
    /// Vexa tamén [`binary_search`], [`binary_search_by_key`] e [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Busca unha serie de catro elementos.Atópase o primeiro, cunha posición determinada de xeito único;o segundo e o terceiro non se atopan;o cuarto podería igualar calquera posición en `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SEGURIDADE: a chamada faise segura polos seguintes invariantes:
            // - `mid >= 0`
            // - `mid < size`: `mid` está limitado por `[left; right)` limitado.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // A razón pola que usamos o fluxo de control if/else no canto de coincidir é porque a coincidencia reordena as operacións de comparación, o que é perfecto.
            //
            // Este é x86 asm para u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// O binario busca esta porción ordenada cunha función de extracción de teclas.
    ///
    /// Supón que a porción está ordenada pola clave, por exemplo con [`sort_by_key`] usando a mesma función de extracción de teclas.
    ///
    /// Se se atopa o valor, devólvese [`Result::Ok`], que contén o índice do elemento coincidente.
    /// Se hai varias coincidencias, pódese devolver calquera das coincidencias.
    /// Se non se atopa o valor, devólvese [`Result::Err`], que contén o índice onde se podería inserir un elemento coincidente mantendo a orde ordenada.
    ///
    ///
    /// Vexa tamén [`binary_search`], [`binary_search_by`] e [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Busca unha serie de catro elementos nunha porción de pares ordenados polos seus segundos elementos.
    /// Atópase o primeiro, cunha posición determinada de xeito único;o segundo e o terceiro non se atopan;o cuarto podería igualar calquera posición en `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links está permitido xa que `slice::sort_by_key` está en crate `alloc` e, como tal, aínda non existe ao construír `core`.
    //
    // ligazóns a crate descendente: #74481.Dado que as primitivas só están documentadas en libstd (#73423), isto nunca leva a ligazóns rotas na práctica.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Ordena a porción, pero pode que non conserve a orde de elementos iguais.
    ///
    /// Este tipo é inestable (é dicir, pode reordenar elementos iguais), no lugar (é dicir, non se asigna) e *O*(*n*\*log(* n*)) no peor dos casos.
    ///
    /// # Implementación actual
    ///
    /// O algoritmo actual está baseado en [pattern-defeating quicksort][pdqsort] de Orson Peters, que combina o caso medio rápido de rápido cadro aleatorio co peor caso rápido de gran escala, ao tempo que se consegue un tempo lineal en franxas con certos patróns.
    /// Usa algunha aleatorización para evitar casos dexenerados, pero cun seed fixo para proporcionar sempre un comportamento determinista.
    ///
    /// Normalmente é máis rápido que a clasificación estable, excepto nalgúns casos especiais, por exemplo, cando a porción consiste en varias secuencias ordenadas concatenadas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Ordena a porción cunha función de comparación, pero pode que non conserve a orde de elementos iguais.
    ///
    /// Este tipo é inestable (é dicir, pode reordenar elementos iguais), no lugar (é dicir, non se asigna) e *O*(*n*\*log(* n*)) no peor dos casos.
    ///
    /// A función de comparación debe definir unha ordenación total para os elementos da porción.Se a orde non é total, a orde dos elementos non se especifica.Un pedido é un pedido total se o é (para todos os `a`, `b` e `c`):
    ///
    /// * total e antisimétrico: exactamente un de `a < b`, `a == b` ou `a > b` é certo e
    /// * transitiva, `a < b` e `b < c` implica `a < c`.O mesmo debe valerse tanto para `==` como para `>`.
    ///
    /// Por exemplo, aínda que [`f64`] non implementa [`Ord`] porque `NaN != NaN`, podemos usar `partial_cmp` como a nosa función de clasificación cando sabemos que a porción non contén un `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Implementación actual
    ///
    /// O algoritmo actual está baseado en [pattern-defeating quicksort][pdqsort] de Orson Peters, que combina o caso medio rápido de rápido cadro aleatorio co peor caso rápido de gran escala, ao tempo que se consegue un tempo lineal en franxas con certos patróns.
    /// Usa algunha aleatorización para evitar casos dexenerados, pero cun seed fixo para proporcionar sempre un comportamento determinista.
    ///
    /// Normalmente é máis rápido que a clasificación estable, excepto nalgúns casos especiais, por exemplo, cando a porción consiste en varias secuencias ordenadas concatenadas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // clasificación inversa
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Ordena a porción cunha función de extracción de teclas, pero pode que non conserve a orde de elementos iguais.
    ///
    /// Este tipo é inestable (é dicir, pode reordenar elementos iguais), no lugar (é dicir, non se asigna) e *O*(m\* * n *\* log(*n*)) no peor dos casos, onde a función clave é *O*(*m*).
    ///
    /// # Implementación actual
    ///
    /// O algoritmo actual está baseado en [pattern-defeating quicksort][pdqsort] de Orson Peters, que combina o caso medio rápido de rápido cadro aleatorio co peor caso rápido de gran escala, ao tempo que se consegue un tempo lineal en franxas con certos patróns.
    /// Usa algunha aleatorización para evitar casos dexenerados, pero cun seed fixo para proporcionar sempre un comportamento determinista.
    ///
    /// Debido á súa estratexia de chamada clave, é probable que [`sort_unstable_by_key`](#method.sort_unstable_by_key) sexa máis lento que [`sort_by_cached_key`](#method.sort_by_cached_key) nos casos en que a función clave sexa cara.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Reordene a porción de xeito que o elemento en `index` estea na súa posición ordenada final.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Reordene a porción cunha función de comparación de tal xeito que o elemento en `index` estea na súa posición ordenada final.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Reordene a porción cunha función de extracción de teclas de tal xeito que o elemento en `index` estea na súa posición final ordenada.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Reordene a porción de xeito que o elemento en `index` estea na súa posición ordenada final.
    ///
    /// Esta reordenación ten a propiedade adicional de que calquera valor na posición `i < index` será menor ou igual a calquera valor nunha posición `j > index`.
    /// Ademais, esta reordenación é inestable (é dicir
    /// calquera número de elementos iguais pode acabar na posición `index`), no lugar (é dicir
    /// non asigna), e *O*(*n*) no peor dos casos.
    /// Esta función tamén se coñece como "kth element" noutras bibliotecas.
    /// Devolve un triplete dos seguintes valores: todos os elementos inferiores ao do índice dado, o valor ao índice dado e todos os elementos maiores que o do índice dado.
    ///
    ///
    /// # Implementación actual
    ///
    /// O algoritmo actual está baseado na porción de selección rápida do mesmo algoritmo quicksort usado para [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics cando `index >= len()`, é dicir, sempre panics en rodajas baleiras.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Atopar a mediana
    /// v.select_nth_unstable(2);
    ///
    /// // Só temos a garantía de que a porción será unha das seguintes, en función da forma de ordenar o índice especificado.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Reordene a porción cunha función de comparación de tal xeito que o elemento en `index` estea na súa posición ordenada final.
    ///
    /// Esta reordenación ten a propiedade adicional de que calquera valor na posición `i < index` será menor ou igual a calquera valor nunha posición `j > index` usando a función comparador.
    /// Ademais, esta reordenación é inestable (é dicir, calquera número de elementos iguais pode acabar na posición `index`), no lugar (é dicir, non se asigna) e, no peor caso,*O*(*n*).
    /// Esta función tamén se coñece como "kth element" noutras bibliotecas.
    /// Devolve un triplete dos seguintes valores: todos os elementos inferiores ao do índice dado, o valor ao índice dado e todos os elementos maiores que o do índice dado, usando a función de comparación proporcionada.
    ///
    ///
    /// # Implementación actual
    ///
    /// O algoritmo actual está baseado na porción de selección rápida do mesmo algoritmo quicksort usado para [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics cando `index >= len()`, é dicir, sempre panics en rodajas baleiras.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Busque a mediana coma se a porción estivese ordenada en orde descendente.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Só temos a garantía de que a porción será unha das seguintes, en función da forma de ordenar o índice especificado.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Reordene a porción cunha función de extracción de teclas de tal xeito que o elemento en `index` estea na súa posición final ordenada.
    ///
    /// Esta reordenación ten a propiedade adicional de que calquera valor na posición `i < index` será menor ou igual a calquera valor nunha posición `j > index` usando a función de extracción de teclas.
    /// Ademais, esta reordenación é inestable (é dicir, calquera número de elementos iguais pode acabar na posición `index`), no lugar (é dicir, non se asigna) e, no peor caso,*O*(*n*).
    /// Esta función tamén se coñece como "kth element" noutras bibliotecas.
    /// Devolve un triplete dos seguintes valores: todos os elementos inferiores ao do índice dado, o valor ao índice dado e todos os elementos maiores que o do índice dado, usando a función de extracción de chave proporcionada.
    ///
    ///
    /// # Implementación actual
    ///
    /// O algoritmo actual está baseado na porción de selección rápida do mesmo algoritmo quicksort usado para [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics cando `index >= len()`, é dicir, sempre panics en rodajas baleiras.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Devolve a mediana coma se a matriz se ordenase segundo o valor absoluto.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Só temos a garantía de que a porción será unha das seguintes, en función da forma de ordenar o índice especificado.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Move todos os elementos repetidos consecutivos ao final da porción segundo a implementación [`PartialEq`] trait.
    ///
    ///
    /// Devolve dúas franxas.O primeiro non contén elementos repetidos consecutivos.
    /// O segundo contén todos os duplicados sen orde especificada.
    ///
    /// Se a porción está ordenada, a primeira porción devolta non contén duplicados.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Move todos os elementos consecutivos menos o primeiro ao final da porción que satisfai unha relación de igualdade dada.
    ///
    /// Devolve dúas franxas.O primeiro non contén elementos repetidos consecutivos.
    /// O segundo contén todos os duplicados sen orde especificada.
    ///
    /// A función `same_bucket` pasa referencias a dous elementos da porción e debe determinar se os elementos se comparan iguais.
    /// Os elementos pásanse en orde oposta á súa orde na porción, polo que se `same_bucket(a, b)` devolve `true`, `a` móvese ao final da porción.
    ///
    ///
    /// Se a porción está ordenada, a primeira porción devolta non contén duplicados.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Aínda que temos unha referencia mutable a `self`, non podemos facer cambios * arbitrarios.As chamadas `same_bucket` poderían panic, polo que debemos asegurarnos de que a porción estea nun estado válido en todo momento.
        //
        // O xeito en que manexamos isto é usando swaps;repetimos todos os elementos, intercambiando mentres avanzamos para que ao final os elementos que desexamos gardar estean na parte dianteira e os que desexamos rexeitar estean na parte traseira.
        // Despois podemos dividir a porción.
        // Esta operación aínda é `O(n)`.
        //
        // Exemplo: Comezamos neste estado, onde `r` representa "seguinte
        // ler "e `w` representa" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Comparando self[r] con auto [w-1], isto non é un duplicado, polo que intercambiamos self[r] e self[w] (sen efecto como r==w) e despois incrementamos tanto r como w, deixándonos con:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Comparando self[r] con auto [w-1], este valor é un duplicado, polo que incrementamos `r` pero deixamos sen cambios todo o demais:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Comparando self[r] con auto [w-1], isto non é un duplicado, así que permuta self[r] e self[w] e avanza r e w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Non é un duplicado, repite:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplicado, advance r. End de porción.Dividir en w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SEGURIDADE: a condición `while` garante `next_read` e `next_write`
        // son menos de `len`, polo tanto están dentro de `self`.
        // `prev_ptr_write` sinala un elemento antes de `ptr_write`, pero `next_write` comeza en 1, polo que `prev_ptr_write` nunca é inferior a 0 e está dentro da porción.
        // Isto cumpre os requisitos para desferenciar `ptr_read`, `prev_ptr_write` e `ptr_write` e para usar `ptr.add(next_read)`, `ptr.add(next_write - 1)` e `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` tamén se incrementa como máximo unha vez por bucle como máximo, o que significa que non se salta ningún elemento cando pode ser necesario intercambialo.
        //
        // `ptr_read` e `prev_ptr_write` nunca apuntan ao mesmo elemento.Isto é necesario para que `&mut *ptr_read`, `&mut* prev_ptr_write` sexa seguro.
        // A explicación é simplemente que `next_read >= next_write` sempre é certo, polo tanto `next_read > next_write - 1` tamén o é.
        //
        //
        //
        //
        //
        unsafe {
            // Evite as comprobacións de límites usando punteiros en bruto.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Move todos os elementos consecutivos menos o primeiro ao final da porción que se resolven á mesma clave.
    ///
    ///
    /// Devolve dúas franxas.O primeiro non contén elementos repetidos consecutivos.
    /// O segundo contén todos os duplicados sen orde especificada.
    ///
    /// Se a porción está ordenada, a primeira porción devolta non contén duplicados.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Xira a porción no lugar de tal xeito que os primeiros elementos `mid` da porción se moven ata o final mentres que os últimos elementos `self.len() - mid` se moven cara á fronte.
    /// Despois de chamar a `rotate_left`, o elemento anteriormente no índice `mid` converterase no primeiro elemento da porción.
    ///
    /// # Panics
    ///
    /// Esta función será panic se `mid` é maior que a lonxitude da porción.Teña en conta que `mid == self.len()` fai _not_ panic e é unha rotación sen operacións.
    ///
    /// # Complexity
    ///
    /// Toma lineal (en tempo `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Xirar unha subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SEGURIDADE: o rango `[p.add(mid) - mid, p.add(mid) + k)` é trivial
        // válido para ler e escribir, como esixe `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Xira a porción no lugar de tal xeito que os primeiros elementos `self.len() - k` da porción se moven ata o final mentres que os últimos elementos `k` se moven cara á fronte.
    /// Despois de chamar a `rotate_right`, o elemento anteriormente no índice `self.len() - k` converterase no primeiro elemento da porción.
    ///
    /// # Panics
    ///
    /// Esta función será panic se `k` é maior que a lonxitude da porción.Teña en conta que `k == self.len()` fai _not_ panic e é unha rotación sen operacións.
    ///
    /// # Complexity
    ///
    /// Toma lineal (en tempo `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Xirar unha subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SEGURIDADE: o rango `[p.add(mid) - mid, p.add(mid) + k)` é trivial
        // válido para ler e escribir, como esixe `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Enche `self` con elementos mediante a clonación de `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Enche `self` cos elementos devoltos chamando a un peche repetidamente.
    ///
    /// Este método usa un peche para crear novos valores.Se prefire [`Clone`] un valor determinado, use [`fill`].
    /// Se desexa usar o [`Default`] trait para xerar valores, pode pasar [`Default::default`] como argumento.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Copia os elementos de `src` a `self`.
    ///
    /// A lonxitude de `src` debe ser a mesma que `self`.
    ///
    /// Se `T` implementa `Copy`, pode ser máis eficiente usar [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Esta función será panic se as dúas franxas teñen lonxitudes diferentes.
    ///
    /// # Examples
    ///
    /// Clonación de dous elementos dunha porción a outra:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Debido a que as franxas teñen que ter a mesma lonxitude, cortamos a porción fonte de catro elementos a dous.
    /// // Será panic se non facemos isto.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust impón que só pode haber unha referencia mutable sen referencias inmutables a un dato particular nun alcance particular.
    /// Debido a isto, tentar empregar `clone_from_slice` nunha única porción producirá un fallo na compilación:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Para evitar isto, podemos usar [`split_at_mut`] para crear dúas sub-rebanadas distintas dunha rebanada:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Copia todos os elementos de `src` a `self`, usando un memcpy.
    ///
    /// A lonxitude de `src` debe ser a mesma que `self`.
    ///
    /// Se `T` non implementa `Copy`, use [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Esta función será panic se as dúas franxas teñen lonxitudes diferentes.
    ///
    /// # Examples
    ///
    /// Copiando dous elementos dunha porción noutra:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Debido a que as franxas teñen que ter a mesma lonxitude, cortamos a porción fonte de catro elementos a dous.
    /// // Será panic se non facemos isto.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust impón que só pode haber unha referencia mutable sen referencias inmutables a un dato particular nun alcance particular.
    /// Debido a isto, tentar empregar `copy_from_slice` nunha única porción producirá un fallo na compilación:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Para evitar isto, podemos usar [`split_at_mut`] para crear dúas sub-rebanadas distintas dunha rebanada:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // A ruta do código panic púxose nunha función fría para non inchar o sitio da chamada.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SEGURIDADE: `self` é válido para elementos `self.len()` por definición, e `src` foi
        // comprobou que ten a mesma lonxitude.
        // As franxas non se poden solapar porque as referencias mutables son exclusivas.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Copia elementos dunha parte da porción a outra parte de si mesma, usando un memmove.
    ///
    /// `src` é o rango dentro do `self` desde o que copiar.
    /// `dest` é o índice inicial do intervalo dentro de `self` para copiar, que terá a mesma lonxitude que `src`.
    /// Os dous rangos poden superpoñerse.
    /// Os extremos dos dous rangos deben ser inferiores ou iguais a `self.len()`.
    ///
    /// # Panics
    ///
    /// Esta función será panic se un intervalo supera o final da porción ou se o final de `src` é antes do comezo.
    ///
    ///
    /// # Examples
    ///
    /// Copiando catro bytes dentro dunha porción:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SEGURIDADE: comprobáronse todas as condicións para `ptr::copy` anteriormente,
        // como os de `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Intercambia todos os elementos en `self` cos de `other`.
    ///
    /// A lonxitude de `other` debe ser a mesma que `self`.
    ///
    /// # Panics
    ///
    /// Esta función será panic se as dúas franxas teñen lonxitudes diferentes.
    ///
    /// # Example
    ///
    /// Cambiando dous elementos entre franxas:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust fai valer que só pode haber unha referencia mutable a un dato particular nun ámbito determinado.
    ///
    /// Debido a isto, tentar empregar `swap_with_slice` nunha única porción producirá un fallo na compilación:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Para solucionar isto, podemos usar [`split_at_mut`] para crear dúas sub-franxas mutables distintas a partir dunha porción:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SEGURIDADE: `self` é válido para elementos `self.len()` por definición, e `src` foi
        // comprobou que ten a mesma lonxitude.
        // As franxas non se poden solapar porque as referencias mutables son exclusivas.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Función para calcular as lonxitudes do tramo medio e final para `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // O que imos facer con `rest` é descubrir que múltiplo de `U` podemos poñer nun número máis baixo de`T`.
        //
        // E cantos `T` necesitamos para cada "multiple".
        //
        // Considere por exemplo T=u8 U=u16.Despois podemos poñer 1 U en 2 Ts.Sinxelo.
        // Agora, considere por exemplo un caso onde size_of: :<T>=16, tamaño_de::<U>=24.</u>
        // Podemos colocar 2 Us no lugar de cada 3 Ts na porción `rest`.
        // Un pouco máis complicado.
        //
        // A fórmula para calcular isto é:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Ampliado e simplificado:
        //
        // Nós=tamaño_de: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=tamaño_de::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Por sorte, xa que todo isto é avaliado constantemente ... o rendemento aquí non importa.
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // algoritmo de stein iterativo Aínda deberiamos facer este `const fn` (e volver ao algoritmo recursivo se o facemos) porque confiar en llvm para constalar todo isto é ... ben, faino incómodo.
            //
            //

            // SEGURIDADE: compróbase que `a` e `b` son valores distintos de cero.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // elimina todos os factores de 2 de b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SEGURIDADE: compróbase que `b` non é cero.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Armados con este coñecemento, podemos atopar cantos `U`s podemos caber.
        let us_len = self.len() / ts * us;
        // E cantos `T` haberá na parte final.
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmuta a porción a unha porción doutro tipo, asegurando que se manteña o aliñamento dos tipos.
    ///
    /// Este método divide a porción en tres porcións distintas: prefixo, porción media aliñada correctamente dun novo tipo e por porción de sufixo.
    /// O método pode facer que a porción media sexa a maior lonxitude posible para un tipo e unha porción de entrada determinados, pero só o rendemento do seu algoritmo debe depender diso, non a súa corrección.
    ///
    /// É admisible que todos os datos de entrada se devolvan como prefixo ou porción de sufixo.
    ///
    /// Este método non ten ningún propósito cando o elemento de entrada `T` ou o elemento de saída `U` teñen un tamaño cero e devolverán a porción orixinal sen dividir nada.
    ///
    /// # Safety
    ///
    /// Este método é esencialmente un `transmute` con respecto aos elementos da porción media devolta, polo que tamén se aplican aquí todas as advertencias habituais relativas a `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Teña en conta que a maior parte desta función avaliarase constantemente,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // manexa especialmente as ZST, é dicir, non as manexes en absoluto.
            return (self, &[], &[]);
        }

        // En primeiro lugar, descubra en que momento dividimos entre a primeira e a segunda porción.
        // Fácil con ptr.align_offset.
        let ptr = self.as_ptr();
        // SEGURIDADE: consulte o método `align_to_mut` para o comentario detallado de seguridade.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SEGURIDADE: agora `rest` está definitivamente aliñado, polo que `from_raw_parts` a continuación está ben,
            // xa que o interlocutor garante que podemos transmutar `T` a `U` con seguridade.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmuta a porción a unha porción doutro tipo, asegurando que se manteña o aliñamento dos tipos.
    ///
    /// Este método divide a porción en tres porcións distintas: prefixo, porción media aliñada correctamente dun novo tipo e por porción de sufixo.
    /// O método pode facer que a porción media sexa a maior lonxitude posible para un tipo e unha porción de entrada determinados, pero só o rendemento do seu algoritmo debe depender diso, non a súa corrección.
    ///
    /// É admisible que todos os datos de entrada se devolvan como prefixo ou porción de sufixo.
    ///
    /// Este método non ten ningún propósito cando o elemento de entrada `T` ou o elemento de saída `U` teñen un tamaño cero e devolverán a porción orixinal sen dividir nada.
    ///
    /// # Safety
    ///
    /// Este método é esencialmente un `transmute` con respecto aos elementos da porción media devolta, polo que tamén se aplican aquí todas as advertencias habituais relativas a `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Teña en conta que a maior parte desta función avaliarase constantemente,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // manexa especialmente as ZST, é dicir, non as manexes en absoluto.
            return (self, &mut [], &mut []);
        }

        // En primeiro lugar, descubra en que momento dividimos entre a primeira e a segunda porción.
        // Fácil con ptr.align_offset.
        let ptr = self.as_ptr();
        // SEGURIDADE: Aquí estamos asegurando que usaremos punteiros aliñados para U para o
        // resto do método.Isto faise pasando un punteiro a&[T] cun aliñamento dirixido a U.
        // `crate::ptr::align_offset` chámase cun punteiro `ptr` correctamente aliñado e válido (vén dunha referencia a `self`) e cun tamaño que é unha potencia de dous (xa que provén do aliñamento para U), cumprindo as súas restricións de seguridade.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Non podemos volver usar `rest` despois disto, o que invalidaría o seu alias `mut_ptr`.SEGURIDADE: ver comentarios para `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Comproba se os elementos desta porción están ordenados.
    ///
    /// É dicir, para cada elemento `a` e o seu seguinte elemento `b`, `a <= b` debe manterse.Se a porción produce exactamente cero ou un elemento, devólvese `true`.
    ///
    /// Teña en conta que se `Self::Item` é só `PartialOrd`, pero non `Ord`, a definición anterior implica que esta función devolve `false` se dous elementos consecutivos non son comparables.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Comproba se os elementos desta porción se ordenan empregando a función de comparación dada.
    ///
    /// En vez de usar `PartialOrd::partial_cmp`, esta función usa a función `compare` dada para determinar a ordenación de dous elementos.
    /// Ademais disto, equivale a [`is_sorted`];consulte a súa documentación para obter máis información.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Comproba se os elementos desta porción se ordenan empregando a función de extracción de chave dada.
    ///
    /// En vez de comparar directamente os elementos da porción, esta función compara as teclas dos elementos, tal e como determina `f`.
    /// Ademais disto, equivale a [`is_sorted`];consulte a súa documentación para obter máis información.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Devolve o índice do punto de partición segundo o predicado dado (o índice do primeiro elemento da segunda partición).
    ///
    /// Suponse que a porción está particionada segundo o predicado dado.
    /// Isto significa que todos os elementos para os que o predicado devolve verdadeiro están ao comezo da porción e todos os elementos para os que o predicado devolve verdadeiro están ao final.
    ///
    /// Por exemplo, [7, 15, 3, 5, 4, 12, 6] é un particionado baixo o predicado x% 2!=0 (todos os números impares están ao comezo, todos pares ao final).
    ///
    /// Se esta porción non está particionada, o resultado devolto non se especifica e carece de sentido, xa que este método realiza unha especie de busca binaria.
    ///
    /// Vexa tamén [`binary_search`], [`binary_search_by`] e [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SEGURIDADE: cando `left < right`, `left <= mid < right`.
            // Polo tanto, `left` sempre aumenta e `right` sempre diminúe e selecciónase calquera deles.Nos dous casos `left <= right` está satisfeito.Polo tanto, se `left < right` nun paso, `left <= right` queda satisfeito no seguinte paso.
            //
            // Polo tanto, sempre que `left != right`, `0 <= left < right <= len` estea satisfeito e se este caso tamén se satisfaga `0 <= mid < len`.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Necesitamos cortalos explicitamente na mesma lonxitude
        // para facilitar ao optimizador a eliminación dos límites da verificación.
        // Pero como non se pode confiar nel tamén temos unha especialización explícita para T: Copiar.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Crea unha porción baleira.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Crea unha porción baleira mutable.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Patróns en franxas, actualmente só os usan `strip_prefix` e `strip_suffix`.
/// Nun punto future, esperamos xeneralizar `core::str::Pattern` (que no momento da escritura está limitado a `str`) a porcións, e entón este trait será substituído ou abolido.
///
pub trait SlicePattern {
    /// O tipo de elemento da porción na que se coincide.
    type Item;

    /// Actualmente, os consumidores de `SlicePattern` precisan unha porción.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}