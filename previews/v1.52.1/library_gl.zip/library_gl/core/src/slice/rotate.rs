// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Xira o rango `[mid-left, mid+right)` de xeito que o elemento en `mid` convértese no primeiro elemento.Equivalentemente, xira o rango `left` elementos cara á esquerda ou `right` elementos cara á dereita.
///
/// # Safety
///
/// O intervalo especificado debe ser válido para ler e escribir.
///
/// # Algorithm
///
/// O algoritmo 1 úsase para valores pequenos de `left + right` ou para `T` grandes.
/// Os elementos móvense ás súas posicións finais un a un comezando por `mid - left` e avanzando por pasos `right` módulo `left + right`, de xeito que só se precisa un temporal.
/// Finalmente, chegamos de novo ao `mid - left`.
/// Non obstante, se `gcd(left + right, right)` non é 1, os pasos anteriores ignoráronse os elementos.
/// Por exemplo:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Afortunadamente, o número de elementos saltados entre os elementos finalizados sempre é igual, polo que só podemos compensar a nosa posición inicial e facer máis roldas (o número total de roldas é o `gcd(left + right, right)` value).
///
/// O resultado final é que todos os elementos finalízanse unha vez e só unha vez.
///
/// O algoritmo 2 úsase se `left + right` é grande pero `min(left, right)` é o suficientemente pequeno como para caber nun buffer de pila.
/// Os elementos `min(left, right)` cópianse no búfer, `memmove` aplícase aos outros e os do búfer móvense de novo ao burato do lado oposto de onde se orixinaron.
///
/// Os algoritmos que se poden vectorizar superan ao anterior unha vez que `left + right` se fai o suficientemente grande.
/// O algoritmo 1 pódese vectorizar dividindo e realizando moitas roldas á vez, pero hai moi poucas roldas de media ata que `left + right` é enorme, e o peor caso dunha soa rolda sempre está aí.
/// En cambio, o algoritmo 3 utiliza o intercambio repetido de elementos `min(left, right)` ata que queda un problema de rotación menor.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// cando `left < right` o intercambio sucede pola esquerda.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. os seguintes algoritmos poden fallar se non se verifican estes casos
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritmo 1 Microbenchmarks indican que o rendemento medio para quendas aleatorias é mellor ata o `left + right == 32`, pero o peor dos casos rende ata os 16.
            // 24 foi elixido como punto medio.
            // Se o tamaño de `T` é maior que 4 `usize`s, este algoritmo tamén supera a outros algoritmos.
            //
            //
            let x = unsafe { mid.sub(left) };
            // comezo da primeira rolda
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` pódese atopar antes da man calculando `gcd(left + right, right)`, pero é máis rápido facer un bucle que calcula o mcd como efecto secundario e despois fai o resto do anaco
            //
            //
            let mut gcd = right;
            // os puntos de referencia revelan que é máis rápido cambiar temporalmente todo o tempo en vez de ler un temporal unha vez, copiar cara atrás e logo escribir ese temporal ao final.
            // Isto débese posiblemente ao feito de que intercambiar ou substituír temporais só usa unha dirección de memoria no bucle en lugar de ter que xestionar dous.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // no canto de incrementar `i` e despois comprobar se está fóra dos límites, comprobamos se `i` sairá dos límites no seguinte incremento.
                // Isto evita calquera envoltorio de punteiros ou `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // final da primeira rolda
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // este condicional debe estar aquí se `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // rematar o anaco con máis roldas
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` Non é un tipo de tamaño cero, polo que está ben dividilo polo seu tamaño.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritmo 2 O `[T; 0]` aquí garante que isto está aliñado adecuadamente para T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritmo 3 Hai un xeito alternativo de intercambio que consiste en atopar onde estaría o último intercambio deste algoritmo e intercambiar usando ese último anaco en vez de intercambiar anacos adxacentes como está a facer este algoritmo, pero deste xeito aínda é máis rápido.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritmo 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}