//! Tipos atómicos
//!
//! Os tipos atómicos proporcionan unha comunicación primitiva de memoria compartida entre fíos e son os elementos básicos doutros tipos simultáneos.
//!
//! Este módulo define versións atómicas dun número selecto de tipos primitivos, incluíndo [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], etc.
//! Os tipos atómicos presentan operacións que, cando se usan correctamente, sincronizan as actualizacións entre fíos.
//!
//! Cada método leva un [`Ordering`] que representa a forza da barreira de memoria para esa operación.Estas ordenacións son as mesmas que o [C++20 atomic orderings][1].Para obter máis información, consulte o [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! As variables atómicas son seguras de compartir entre fíos (implementan [`Sync`]) pero non proporcionan elas mesmas o mecanismo para compartir e seguen o [threading model](../../../std/thread/index.html#the-threading-model) de Rust.
//!
//! A forma máis común de compartir unha variable atómica é poñela nun [`Arc`][arc] (un punteiro compartido con referencia atómica).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Os tipos atómicos poden almacenarse en variables estáticas, inicializadas mediante inicializadores constantes como [`AtomicBool::new`].A estática atómica úsase a miúdo para a inicialización global preguiceira.
//!
//! # Portability
//!
//! Todos os tipos atómicos deste módulo teñen a garantía de ser [lock-free] se están dispoñibles.Isto significa que non adquiren internamente un mutex global.Non se garante que os tipos e as operacións atómicas estean libres de espera.
//! Isto significa que operacións como `fetch_or` poden implementarse cun bucle de comparación e intercambio.
//!
//! As operacións atómicas poden implementarse na capa de instrucións con atómicos de maior tamaño.Por exemplo, algunhas plataformas usan instrucións atómicas de 4 bytes para implementar `AtomicI8`.
//! Teña en conta que esta emulación non debe repercutir na corrección do código, é algo que debe ter en conta.
//!
//! É posible que os tipos atómicos deste módulo non estean dispoñibles en todas as plataformas.Non obstante, os tipos atómicos aquí están amplamente dispoñibles e xeralmente pódese confiar nos existentes.Algunhas excepcións notables son:
//!
//! * PowerPC e as plataformas MIPS con punteiros de 32 bits non teñen tipos `AtomicU64` ou `AtomicI64`.
//! * ARM plataformas como `armv5te` que non son para Linux só proporcionan operacións `load` e `store` e non admiten operacións de comparación e intercambio (CAS), como `swap`, `fetch_add`, etc.
//! Adicionalmente en Linux, estas operacións CAS implementanse a través de [operating system support], que pode ter unha penalización de rendemento.
//! * ARM os obxectivos con `thumbv6m` só proporcionan operacións `load` e `store` e non admiten operacións de comparación e intercambio (CAS), como `swap`, `fetch_add`, etc.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Teña en conta que pódense engadir plataformas future que tampouco teñen soporte para algunhas operacións atómicas.O código máximo portátil quererá ter coidado cos tipos atómicos que se usan.
//! `AtomicUsize` e `AtomicIsize` son xeralmente os máis portátiles, pero aínda así non están dispoñibles en todas partes.
//! Como referencia, a biblioteca `std` require atómicos de tamaño punteiro, aínda que `core` non.
//!
//! Actualmente necesitarás usar `#[cfg(target_arch)]` principalmente para compilar condicionalmente en código con atomics.Hai tamén un `#[cfg(target_has_atomic)]` inestable que se pode estabilizar no future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Un sinxelo bloqueo:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Agarde a que o outro fío solte o bloqueo
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Mantén unha conta global de fíos en directo:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Un tipo booleano que se pode compartir con seguridade entre fíos.
///
/// Este tipo ten a mesma representación en memoria que un [`bool`].
///
/// **Nota**: este tipo só está dispoñible en plataformas que admitan cargas atómicas e almacena `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Crea un `AtomicBool` inicializado a `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// O envío está implícitamente implementado para AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Un tipo de punteiro en bruto que se pode compartir con seguridade entre fíos.
///
/// Este tipo ten a mesma representación en memoria que un `*mut T`.
///
/// **Nota**: este tipo só está dispoñible en plataformas que admiten cargas atómicas e almacéns de punteiros.
/// O seu tamaño depende do tamaño do punteiro de destino.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Crea un `AtomicPtr<T>` nulo.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Ordenacións de memoria atómica
///
/// As ordes de memoria especifican a forma en que as operacións atómicas sincronizan a memoria.
/// No seu [`Ordering::Relaxed`] máis débil, só a memoria tocada directamente pola operación está sincronizada.
/// Por outra banda, un par de cargas de almacenamento de operacións [`Ordering::SeqCst`] sincroniza outra memoria á vez que preserva unha orde total de tales operacións en todos os fíos.
///
///
/// As ordes de memoria de Rust son [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Para obter máis información, consulte o [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Sen restricións de ordenación, só operacións atómicas.
    ///
    /// Corresponde a [`memory_order_relaxed`] en C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Cando se xuntan cunha tenda, todas as operacións anteriores ordenanse antes de cargar este valor con pedidos [`Acquire`] (ou superior).
    ///
    /// En particular, todas as escrituras anteriores son visibles para todos os fíos que realizan unha carga [`Acquire`] (ou máis forte) deste valor.
    ///
    /// Teña en conta que usar esta orde para unha operación que combina cargas e almacenamentos leva a unha operación de carga [`Relaxed`].
    ///
    /// Este pedido só é aplicable ás operacións que poden realizar unha tenda.
    ///
    /// Corresponde a [`memory_order_release`] en C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Cando se combina cunha carga, se o valor cargado foi escrito por unha operación de tenda con pedidos [`Release`] (ou máis fortes), entón todas as operacións posteriores ordenaranse despois dese almacén.
    /// En particular, todas as cargas posteriores verán os datos escritos antes da tenda.
    ///
    /// Teña en conta que usar esta orde para unha operación que combina cargas e almacenamentos leva a unha operación de almacén [`Relaxed`].
    ///
    /// Esta orde só é aplicable ás operacións que poden realizar unha carga.
    ///
    /// Corresponde a [`memory_order_acquire`] en C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Ten os efectos de [`Acquire`] e [`Release`] xuntos:
    /// Para cargas usa a orde [`Acquire`].Para as tendas usa o pedido [`Release`].
    ///
    /// Teña en conta que no caso de `compare_and_swap`, é posible que a operación non acabe realizando ningunha tenda e, polo tanto, só teña pedidos [`Acquire`].
    ///
    /// Non obstante, `AcqRel` nunca realizará accesos [`Relaxed`].
    ///
    /// Este pedido só é aplicable a operacións que combinan cargas e almacéns.
    ///
    /// Corresponde a [`memory_order_acq_rel`] en C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Como [Acquire`]/[`Release`]/[` AcqRel`](para operacións de carga, almacenamento e carga con almacenamento, respectivamente) coa garantía adicional de que todos os fíos ven todas as operacións consistentes secuencialmente na mesma orde .
    ///
    ///
    /// Corresponde a [`memory_order_seq_cst`] en C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// Un [`AtomicBool`] inicializado a `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Crea un novo `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Devolve unha referencia mudable ao [`bool`] subxacente.
    ///
    /// Isto é seguro porque a referencia mutable garante que ningún outro subproceso acceda simultaneamente aos datos atómicos.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SEGURIDADE: a referencia mutable garante a propiedade única.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Obtén acceso atómico a un `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SEGURIDADE: a referencia mutable garante a propiedade única e
        // o aliñamento de `bool` e `Self` é 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Consume o atómico e devolve o valor contido.
    ///
    /// Isto é seguro porque pasar `self` por valor garante que ningún outro subproceso acceda simultaneamente aos datos atómicos.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Carga un valor desde bool.
    ///
    /// `load` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.
    /// Os valores posibles son [`SeqCst`], [`Acquire`] e [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics se `order` é [`Release`] ou [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // SEGURIDADE: as carreiras de datos son impedidas polos intrínsecos atómicos e o raw
        // o punteiro pasado é válido porque o obtivemos dunha referencia.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Almacena un valor no bool.
    ///
    /// `store` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.
    /// Os valores posibles son [`SeqCst`], [`Release`] e [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics se `order` é [`Acquire`] ou [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // SEGURIDADE: as carreiras de datos son impedidas polos intrínsecos atómicos e o raw
        // o punteiro pasado é válido porque o obtivemos dunha referencia.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Almacena un valor no bool, devolvendo o valor anterior.
    ///
    /// `swap` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.Todos os modos de pedido son posibles.
    /// Teña en conta que o uso de [`Acquire`] fai que a tenda sexa parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a parte de carga [`Relaxed`].
    ///
    ///
    /// **Note:** Este método só está dispoñible en plataformas que admiten operacións atómicas en `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Almacena un valor no [`bool`] se o valor actual é o mesmo que o valor `current`.
    ///
    /// O valor de retorno sempre é o valor anterior.Se é igual a `current`, actualizouse o valor.
    ///
    /// `compare_and_swap` tamén leva un argumento [`Ordering`] que describe a orde da memoria desta operación.
    /// Teña en conta que, mesmo cando se usa [`AcqRel`], a operación pode fallar e, polo tanto, só debe realizar unha carga `Acquire`, pero non ter semántica `Release`.
    /// O uso de [`Acquire`] fai que a tenda sexa parte desta operación [`Relaxed`] se sucede e o uso de [`Release`] fai que a parte de carga [`Relaxed`].
    ///
    /// **Note:** Este método só está dispoñible en plataformas que admiten operacións atómicas en `u8`.
    ///
    /// # Migrando a `compare_exchange` e `compare_exchange_weak`
    ///
    /// `compare_and_swap` equivale a `compare_exchange` co seguinte mapeado para ordenacións de memoria:
    ///
    /// Orixinal |Éxito |Fracaso
    /// -------- | ------- | -------
    /// Relaxado |Relaxado |Relaxed Adquirir |Adquirir |Adquirir liberación |Lanzamento |AcqRel relaxadoAcqRel |Adquirir SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` déixase fallar espuriosamente incluso cando a comparación ten éxito, o que permite ao compilador xerar un mellor código de ensamblaxe cando a comparación e intercambio se usan nun bucle.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Almacena un valor no [`bool`] se o valor actual é o mesmo que o valor `current`.
    ///
    /// O valor de retorno é un resultado que indica se o novo valor foi escrito e contén o valor anterior.
    /// En caso de éxito, este valor está garantido para ser igual a `current`.
    ///
    /// `compare_exchange` leva dous argumentos [`Ordering`] para describir a orde de memoria desta operación.
    /// `success` describe a orde necesaria para a operación de lectura-modificación-escritura que ten lugar se a comparación con `current` ten éxito.
    /// `failure` describe a orde necesaria para a operación de carga que ten lugar cando falla a comparación.
    /// O uso de [`Acquire`] como orde correcta fai que a tenda forme parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a carga sexa [`Relaxed`].
    ///
    /// A orde de fallos só pode ser [`SeqCst`], [`Acquire`] ou [`Relaxed`] e debe ser equivalente ou menor que a orde de éxito.
    ///
    /// **Note:** Este método só está dispoñible en plataformas que admiten operacións atómicas en `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Almacena un valor no [`bool`] se o valor actual é o mesmo que o valor `current`.
    ///
    /// A diferenza do [`AtomicBool::compare_exchange`], esta función pode fallar espuriosamente incluso cando a comparación ten éxito, o que pode producir código máis eficiente nalgunhas plataformas.
    ///
    /// O valor de retorno é un resultado que indica se o novo valor foi escrito e contén o valor anterior.
    ///
    /// `compare_exchange_weak` leva dous argumentos [`Ordering`] para describir a orde de memoria desta operación.
    /// `success` describe a orde necesaria para a operación de lectura-modificación-escritura que ten lugar se a comparación con `current` ten éxito.
    /// `failure` describe a orde necesaria para a operación de carga que ten lugar cando falla a comparación.
    /// O uso de [`Acquire`] como orde correcta fai que a tenda forme parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a carga sexa [`Relaxed`].
    /// A orde de fallos só pode ser [`SeqCst`], [`Acquire`] ou [`Relaxed`] e debe ser equivalente ou menor que a orde de éxito.
    ///
    /// **Note:** Este método só está dispoñible en plataformas que admiten operacións atómicas en `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// "and" lóxico cun valor booleano.
    ///
    /// Realiza unha operación lóxica "and" sobre o valor actual e o argumento `val` e establece o novo valor no resultado.
    ///
    /// Devolve o valor anterior.
    ///
    /// `fetch_and` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.Todos os modos de pedido son posibles.
    /// Teña en conta que o uso de [`Acquire`] fai que a tenda sexa parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a parte de carga [`Relaxed`].
    ///
    ///
    /// **Note:** Este método só está dispoñible en plataformas que admiten operacións atómicas en `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// "nand" lóxico cun valor booleano.
    ///
    /// Realiza unha operación lóxica "nand" sobre o valor actual e o argumento `val` e establece o novo valor no resultado.
    ///
    /// Devolve o valor anterior.
    ///
    /// `fetch_nand` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.Todos os modos de pedido son posibles.
    /// Teña en conta que o uso de [`Acquire`] fai que a tenda sexa parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a parte de carga [`Relaxed`].
    ///
    ///
    /// **Note:** Este método só está dispoñible en plataformas que admiten operacións atómicas en `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Non podemos usar atomic_nand aquí porque pode producir un bool cun valor non válido.
        // Isto ocorre porque a operación atómica faise cun número enteiro de 8 bits internamente, o que configuraría os 7 bits superiores.
        //
        // Polo tanto, só empregamos fetch_xor ou swap.
        if val {
            // ! (x&true)== !x Debemos invertir o bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true Debemos establecer o bool en true.
            //
            self.swap(true, order)
        }
    }

    /// "or" lóxico cun valor booleano.
    ///
    /// Realiza unha operación lóxica "or" sobre o valor actual e o argumento `val` e establece o novo valor no resultado.
    ///
    /// Devolve o valor anterior.
    ///
    /// `fetch_or` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.Todos os modos de pedido son posibles.
    /// Teña en conta que o uso de [`Acquire`] fai que a tenda sexa parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a parte de carga [`Relaxed`].
    ///
    ///
    /// **Note:** Este método só está dispoñible en plataformas que admiten operacións atómicas en `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// "xor" lóxico cun valor booleano.
    ///
    /// Realiza unha operación lóxica "xor" sobre o valor actual e o argumento `val` e establece o novo valor no resultado.
    ///
    /// Devolve o valor anterior.
    ///
    /// `fetch_xor` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.Todos os modos de pedido son posibles.
    /// Teña en conta que o uso de [`Acquire`] fai que a tenda sexa parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a parte de carga [`Relaxed`].
    ///
    ///
    /// **Note:** Este método só está dispoñible en plataformas que admiten operacións atómicas en `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Devolve un punteiro mutable ao [`bool`] subxacente.
    ///
    /// Facer lecturas e escrituras non atómicas no número enteiro resultante pode ser unha carreira de datos.
    /// Este método é moi útil para FFI, onde a sinatura da función pode usar `*mut bool` en lugar de `&AtomicBool`.
    ///
    /// Devolver un punteiro `*mut` dunha referencia compartida a este atómico é seguro porque os tipos atómicos funcionan con mutabilidade interior.
    /// Todas as modificacións dun atómico cambian o valor a través dunha referencia compartida e poden facelo de forma segura sempre que usen operacións atómicas.
    /// Calquera uso do punteiro en bruto devolto require un bloque `unsafe` e aínda ten que manter a mesma restrición: as operacións nel deben ser atómicas.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Obtén o valor e aplícalle unha función que devolve un novo valor opcional.Devolve un `Result` de `Ok(previous_value)` se a función devolve `Some(_)`, se non `Err(previous_value)`.
    ///
    /// Note: Isto pode chamar á función varias veces se se cambiou o valor doutros fíos mentres tanto, sempre que a función devolva `Some(_)`, pero a función aplicarase só unha vez ao valor almacenado.
    ///
    ///
    /// `fetch_update` leva dous argumentos [`Ordering`] para describir a orde de memoria desta operación.
    /// O primeiro describe a orde requirida para cando finalmente a operación ten éxito mentres que a segunda describe a orde requirida para cargas.
    /// Corresponden ás ordes de éxito e fallo de [`AtomicBool::compare_exchange`] respectivamente.
    ///
    /// O uso de [`Acquire`] como orde de éxito fai que a tenda forme parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a carga final sexa exitosa [`Relaxed`].
    /// A orde de carga (failed) só pode ser [`SeqCst`], [`Acquire`] ou [`Relaxed`] e debe ser equivalente ou máis débil que a orde de éxito.
    ///
    /// **Note:** Este método só está dispoñible en plataformas que admiten operacións atómicas en `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Crea un novo `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Devolve unha referencia mudable ao punteiro subxacente.
    ///
    /// Isto é seguro porque a referencia mutable garante que ningún outro subproceso acceda simultaneamente aos datos atómicos.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Obtén acceso atómico a un punteiro.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - a referencia mutable garante a propiedade única.
        //  - o aliñamento de `*mut T` e `Self` é o mesmo en todas as plataformas compatibles con rust, como se verificou anteriormente.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Consume o atómico e devolve o valor contido.
    ///
    /// Isto é seguro porque pasar `self` por valor garante que ningún outro subproceso acceda simultaneamente aos datos atómicos.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Carga un valor desde o punteiro.
    ///
    /// `load` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.
    /// Os valores posibles son [`SeqCst`], [`Acquire`] e [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics se `order` é [`Release`] ou [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Almacena un valor no punteiro.
    ///
    /// `store` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.
    /// Os valores posibles son [`SeqCst`], [`Release`] e [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics se `order` é [`Acquire`] ou [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Almacena un valor no punteiro, devolvendo o valor anterior.
    ///
    /// `swap` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.Todos os modos de pedido son posibles.
    /// Teña en conta que o uso de [`Acquire`] fai que a tenda sexa parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a parte de carga [`Relaxed`].
    ///
    ///
    /// **Note:** Este método só está dispoñible en plataformas que admiten operacións atómicas en punteiros.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Almacena un valor no punteiro se o valor actual é o mesmo que o valor `current`.
    ///
    /// O valor de retorno sempre é o valor anterior.Se é igual a `current`, actualizouse o valor.
    ///
    /// `compare_and_swap` tamén leva un argumento [`Ordering`] que describe a orde da memoria desta operación.
    /// Teña en conta que, mesmo cando se usa [`AcqRel`], a operación pode fallar e, polo tanto, só debe realizar unha carga `Acquire`, pero non ter semántica `Release`.
    /// O uso de [`Acquire`] fai que a tenda sexa parte desta operación [`Relaxed`] se sucede e o uso de [`Release`] fai que a parte de carga [`Relaxed`].
    ///
    /// **Note:** Este método só está dispoñible en plataformas que admiten operacións atómicas en punteiros.
    ///
    /// # Migrando a `compare_exchange` e `compare_exchange_weak`
    ///
    /// `compare_and_swap` equivale a `compare_exchange` co seguinte mapeado para ordenacións de memoria:
    ///
    /// Orixinal |Éxito |Fracaso
    /// -------- | ------- | -------
    /// Relaxado |Relaxado |Relaxed Adquirir |Adquirir |Adquirir liberación |Lanzamento |AcqRel relaxadoAcqRel |Adquirir SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` déixase fallar espuriosamente incluso cando a comparación ten éxito, o que permite ao compilador xerar un mellor código de ensamblaxe cando a comparación e intercambio se usan nun bucle.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Almacena un valor no punteiro se o valor actual é o mesmo que o valor `current`.
    ///
    /// O valor de retorno é un resultado que indica se o novo valor foi escrito e contén o valor anterior.
    /// En caso de éxito, este valor está garantido para ser igual a `current`.
    ///
    /// `compare_exchange` leva dous argumentos [`Ordering`] para describir a orde de memoria desta operación.
    /// `success` describe a orde necesaria para a operación de lectura-modificación-escritura que ten lugar se a comparación con `current` ten éxito.
    /// `failure` describe a orde necesaria para a operación de carga que ten lugar cando falla a comparación.
    /// O uso de [`Acquire`] como orde correcta fai que a tenda forme parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a carga sexa [`Relaxed`].
    ///
    /// A orde de fallos só pode ser [`SeqCst`], [`Acquire`] ou [`Relaxed`] e debe ser equivalente ou menor que a orde de éxito.
    ///
    /// **Note:** Este método só está dispoñible en plataformas que admiten operacións atómicas en punteiros.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Almacena un valor no punteiro se o valor actual é o mesmo que o valor `current`.
    ///
    /// A diferenza do [`AtomicPtr::compare_exchange`], esta función pode fallar espuriosamente incluso cando a comparación ten éxito, o que pode producir código máis eficiente nalgunhas plataformas.
    ///
    /// O valor de retorno é un resultado que indica se o novo valor foi escrito e contén o valor anterior.
    ///
    /// `compare_exchange_weak` leva dous argumentos [`Ordering`] para describir a orde de memoria desta operación.
    /// `success` describe a orde necesaria para a operación de lectura-modificación-escritura que ten lugar se a comparación con `current` ten éxito.
    /// `failure` describe a orde necesaria para a operación de carga que ten lugar cando falla a comparación.
    /// O uso de [`Acquire`] como orde correcta fai que a tenda forme parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a carga sexa [`Relaxed`].
    /// A orde de fallos só pode ser [`SeqCst`], [`Acquire`] ou [`Relaxed`] e debe ser equivalente ou menor que a orde de éxito.
    ///
    /// **Note:** Este método só está dispoñible en plataformas que admiten operacións atómicas en punteiros.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SEGURIDADE: este intrínseco non é seguro porque opera nun punteiro en bruto
        // pero sabemos con certeza que o punteiro é válido (acabámolo de obter dun `UnsafeCell` que temos por referencia) e a propia operación atómica permítenos mutar de forma segura o contido do `UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Obtén o valor e aplícalle unha función que devolve un novo valor opcional.Devolve un `Result` de `Ok(previous_value)` se a función devolve `Some(_)`, se non `Err(previous_value)`.
    ///
    /// Note: Isto pode chamar á función varias veces se se cambiou o valor doutros fíos mentres tanto, sempre que a función devolva `Some(_)`, pero a función aplicarase só unha vez ao valor almacenado.
    ///
    ///
    /// `fetch_update` leva dous argumentos [`Ordering`] para describir a orde de memoria desta operación.
    /// O primeiro describe a orde requirida para cando finalmente a operación ten éxito mentres que a segunda describe a orde requirida para cargas.
    /// Corresponden ás ordes de éxito e fallo de [`AtomicPtr::compare_exchange`] respectivamente.
    ///
    /// O uso de [`Acquire`] como orde de éxito fai que a tenda forme parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a carga final sexa exitosa [`Relaxed`].
    /// A orde de carga (failed) só pode ser [`SeqCst`], [`Acquire`] ou [`Relaxed`] e debe ser equivalente ou máis débil que a orde de éxito.
    ///
    /// **Note:** Este método só está dispoñible en plataformas que admiten operacións atómicas en punteiros.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Converte un `bool` nun `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Esta macro acaba sen utilizarse nalgunhas arquitecturas.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Un tipo enteiro que se pode compartir con seguridade entre fíos.
        ///
        /// Este tipo ten a mesma representación en memoria que o tipo enteiro subxacente, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Para obter máis información sobre as diferenzas entre tipos atómicos e non atómicos, así como información sobre a portabilidade deste tipo, consulte o [module-level documentation].
        ///
        ///
        /// **Note:** Este tipo só está dispoñible en plataformas que soportan cargas atómicas e almacéns de [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Un enteiro atómico inicializado a `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // O envío está implícitamente implementado.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Crea un novo enteiro atómico.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Devolve unha referencia mudable ao enteiro subxacente.
            ///
            /// Isto é seguro porque a referencia mutable garante que ningún outro subproceso acceda simultaneamente aos datos atómicos.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// let mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// afirmar_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - a referencia mutable garante a propiedade única.
                //  - o aliñamento de `$int_type` e `Self` é o mesmo, como prometera $cfg_align e verificouse anteriormente.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Consume o atómico e devolve o valor contido.
            ///
            /// Isto é seguro porque pasar `self` por valor garante que ningún outro subproceso acceda simultaneamente aos datos atómicos.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Carga un valor do enteiro atómico.
            ///
            /// `load` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.
            /// Os valores posibles son [`SeqCst`], [`Acquire`] e [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics se `order` é [`Release`] ou [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Almacena un valor no enteiro atómico.
            ///
            /// `store` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.
            ///  Os valores posibles son [`SeqCst`], [`Release`] e [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics se `order` é [`Acquire`] ou [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Almacena un valor no enteiro atómico, devolvendo o valor anterior.
            ///
            /// `swap` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.Todos os modos de pedido son posibles.
            /// Teña en conta que o uso de [`Acquire`] fai que a tenda sexa parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a parte de carga [`Relaxed`].
            ///
            ///
            /// **Nota**: este método só está dispoñible en plataformas que admiten operacións atómicas activadas
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Almacena un valor no enteiro atómico se o valor actual é o mesmo que o valor `current`.
            ///
            /// O valor de retorno sempre é o valor anterior.Se é igual a `current`, actualizouse o valor.
            ///
            /// `compare_and_swap` tamén leva un argumento [`Ordering`] que describe a orde da memoria desta operación.
            /// Teña en conta que, mesmo cando se usa [`AcqRel`], a operación pode fallar e, polo tanto, só debe realizar unha carga `Acquire`, pero non ter semántica `Release`.
            ///
            /// O uso de [`Acquire`] fai que a tenda sexa parte desta operación [`Relaxed`] se sucede e o uso de [`Release`] fai que a parte de carga [`Relaxed`].
            ///
            /// **Nota**: este método só está dispoñible en plataformas que admiten operacións atómicas activadas
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Migrando a `compare_exchange` e `compare_exchange_weak`
            ///
            /// `compare_and_swap` equivale a `compare_exchange` co seguinte mapeado para ordenacións de memoria:
            ///
            /// Orixinal |Éxito |Fracaso
            /// -------- | ------- | -------
            /// Relaxado |Relaxado |Relaxed Adquirir |Adquirir |Adquirir liberación |Lanzamento |AcqRel relaxadoAcqRel |Adquirir SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` déixase fallar espuriosamente incluso cando a comparación ten éxito, o que permite ao compilador xerar un mellor código de ensamblaxe cando a comparación e intercambio se usan nun bucle.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Almacena un valor no enteiro atómico se o valor actual é o mesmo que o valor `current`.
            ///
            /// O valor de retorno é un resultado que indica se o novo valor foi escrito e contén o valor anterior.
            /// En caso de éxito, este valor está garantido para ser igual a `current`.
            ///
            /// `compare_exchange` leva dous argumentos [`Ordering`] para describir a orde de memoria desta operación.
            /// `success` describe a orde necesaria para a operación de lectura-modificación-escritura que ten lugar se a comparación con `current` ten éxito.
            /// `failure` describe a orde necesaria para a operación de carga que ten lugar cando falla a comparación.
            /// O uso de [`Acquire`] como orde correcta fai que a tenda forme parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a carga sexa [`Relaxed`].
            ///
            /// A orde de fallos só pode ser [`SeqCst`], [`Acquire`] ou [`Relaxed`] e debe ser equivalente ou menor que a orde de éxito.
            ///
            /// **Nota**: este método só está dispoñible en plataformas que admiten operacións atómicas activadas
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Almacena un valor no enteiro atómico se o valor actual é o mesmo que o valor `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// esta función pode fallar espuriosamente incluso cando a comparación ten éxito, o que pode producir código máis eficiente nalgunhas plataformas.
            /// O valor de retorno é un resultado que indica se o novo valor foi escrito e contén o valor anterior.
            ///
            /// `compare_exchange_weak` leva dous argumentos [`Ordering`] para describir a orde de memoria desta operación.
            /// `success` describe a orde necesaria para a operación de lectura-modificación-escritura que ten lugar se a comparación con `current` ten éxito.
            /// `failure` describe a orde necesaria para a operación de carga que ten lugar cando falla a comparación.
            /// O uso de [`Acquire`] como orde correcta fai que a tenda forme parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a carga sexa [`Relaxed`].
            ///
            /// A orde de fallos só pode ser [`SeqCst`], [`Acquire`] ou [`Relaxed`] e debe ser equivalente ou menor que a orde de éxito.
            ///
            /// **Nota**: este método só está dispoñible en plataformas que admiten operacións atómicas activadas
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// let mut old= val.load(Ordering::Relaxed);
            /// loop {let new=old * 2;
            ///     coincidencia val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Engádese ao valor actual, devolvendo o valor anterior.
            ///
            /// Esta operación envólvese ao desbordarse.
            ///
            /// `fetch_add` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.Todos os modos de pedido son posibles.
            /// Teña en conta que o uso de [`Acquire`] fai que a tenda sexa parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a parte de carga [`Relaxed`].
            ///
            ///
            /// **Nota**: este método só está dispoñible en plataformas que admiten operacións atómicas activadas
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Restas do valor actual, devolvendo o valor anterior.
            ///
            /// Esta operación envólvese ao desbordarse.
            ///
            /// `fetch_sub` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.Todos os modos de pedido son posibles.
            /// Teña en conta que o uso de [`Acquire`] fai que a tenda sexa parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a parte de carga [`Relaxed`].
            ///
            ///
            /// **Nota**: este método só está dispoñible en plataformas que admiten operacións atómicas activadas
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" co valor actual.
            ///
            /// Realiza unha operación bit0 bit "and" sobre o valor actual e o argumento `val` e establece o novo valor no resultado.
            ///
            /// Devolve o valor anterior.
            ///
            /// `fetch_and` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.Todos os modos de pedido son posibles.
            /// Teña en conta que o uso de [`Acquire`] fai que a tenda sexa parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a parte de carga [`Relaxed`].
            ///
            ///
            /// **Nota**: este método só está dispoñible en plataformas que admiten operacións atómicas activadas
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" co valor actual.
            ///
            /// Realiza unha operación bit0 bit "nand" sobre o valor actual e o argumento `val` e establece o novo valor no resultado.
            ///
            /// Devolve o valor anterior.
            ///
            /// `fetch_nand` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.Todos os modos de pedido son posibles.
            /// Teña en conta que o uso de [`Acquire`] fai que a tenda sexa parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a parte de carga [`Relaxed`].
            ///
            ///
            /// **Nota**: este método só está dispoñible en plataformas que admiten operacións atómicas activadas
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13 e 0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" co valor actual.
            ///
            /// Realiza unha operación bit0 bit "or" sobre o valor actual e o argumento `val` e establece o novo valor no resultado.
            ///
            /// Devolve o valor anterior.
            ///
            /// `fetch_or` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.Todos os modos de pedido son posibles.
            /// Teña en conta que o uso de [`Acquire`] fai que a tenda sexa parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a parte de carga [`Relaxed`].
            ///
            ///
            /// **Nota**: este método só está dispoñible en plataformas que admiten operacións atómicas activadas
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" co valor actual.
            ///
            /// Realiza unha operación bit0 bit "xor" sobre o valor actual e o argumento `val` e establece o novo valor no resultado.
            ///
            /// Devolve o valor anterior.
            ///
            /// `fetch_xor` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.Todos os modos de pedido son posibles.
            /// Teña en conta que o uso de [`Acquire`] fai que a tenda sexa parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a parte de carga [`Relaxed`].
            ///
            ///
            /// **Nota**: este método só está dispoñible en plataformas que admiten operacións atómicas activadas
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Obtén o valor e aplícalle unha función que devolve un novo valor opcional.Devolve un `Result` de `Ok(previous_value)` se a función devolve `Some(_)`, se non `Err(previous_value)`.
            ///
            /// Note: Isto pode chamar á función varias veces se se cambiou o valor doutros fíos mentres tanto, sempre que a función devolva `Some(_)`, pero a función aplicarase só unha vez ao valor almacenado.
            ///
            ///
            /// `fetch_update` leva dous argumentos [`Ordering`] para describir a orde de memoria desta operación.
            /// O primeiro describe a orde requirida para cando finalmente a operación ten éxito mentres que a segunda describe a orde requirida para cargas.Corresponden ás ordes de éxito e fracaso de
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// O uso de [`Acquire`] como orde de éxito fai que a tenda forme parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a carga final sexa exitosa [`Relaxed`].
            /// A orde de carga (failed) só pode ser [`SeqCst`], [`Acquire`] ou [`Relaxed`] e debe ser equivalente ou máis débil que a orde de éxito.
            ///
            /// **Nota**: este método só está dispoñible en plataformas que admiten operacións atómicas activadas
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Ordenando: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Ordenando: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Máximo co valor actual.
            ///
            /// Atopa o máximo do valor actual e do argumento `val` e establece o novo valor no resultado.
            ///
            /// Devolve o valor anterior.
            ///
            /// `fetch_max` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.Todos os modos de pedido son posibles.
            /// Teña en conta que o uso de [`Acquire`] fai que a tenda sexa parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a parte de carga [`Relaxed`].
            ///
            ///
            /// **Nota**: este método só está dispoñible en plataformas que admiten operacións atómicas activadas
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// deixar barra=42;
            /// imos max_foo=foo.fetch_max (barra, Ordering::SeqCst).max(bar);
            /// afirmar! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Mínimo co valor actual.
            ///
            /// Atopa o mínimo do valor actual e o argumento `val` e establece o novo valor no resultado.
            ///
            /// Devolve o valor anterior.
            ///
            /// `fetch_min` leva un argumento [`Ordering`] que describe a orde da memoria desta operación.Todos os modos de pedido son posibles.
            /// Teña en conta que o uso de [`Acquire`] fai que a tenda sexa parte desta operación [`Relaxed`] e o uso de [`Release`] fai que a parte de carga [`Relaxed`].
            ///
            ///
            /// **Nota**: este método só está dispoñible en plataformas que admiten operacións atómicas activadas
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// deixar barra=12;
            /// imos min_foo=foo.fetch_min (barra, Ordering::SeqCst).min(bar);
            /// afirmar_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEGURIDADE: as carreiras de datos son impedidas por intrínsecos atómicos.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Devolve un punteiro mutable ao enteiro subxacente.
            ///
            /// Facer lecturas e escrituras non atómicas no número enteiro resultante pode ser unha carreira de datos.
            /// Este método é moi útil para FFI, onde a sinatura de función pode usarse
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Devolver un punteiro `*mut` dunha referencia compartida a este atómico é seguro porque os tipos atómicos funcionan con mutabilidade interior.
            /// Todas as modificacións dun atómico cambian o valor a través dunha referencia compartida e poden facelo de forma segura sempre que usen operacións atómicas.
            /// Calquera uso do punteiro en bruto devolto require un bloque `unsafe` e aínda ten que manter a mesma restrición: as operacións nel deben ser atómicas.
            ///
            ///
            /// # Examples
            ///
            /// "" ignore (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SEGURIDADE: Seguro sempre que `my_atomic_op` sexa atómico.
            /// inseguro {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Devolve o valor anterior (como __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Devolve o valor anterior (como __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// devolve o valor máximo (comparación asinada)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// devolve o valor mínimo (comparación asinada)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// devolve o valor máximo (comparación sen asinar)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// devolve o valor mínimo (comparación sen asinar)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEGURIDADE: o interlocutor debe respectar o contrato de seguridade para `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Unha cerca atómica.
///
/// Dependendo da orde especificada, unha cerca impide que o compilador e a CPU reordenen certos tipos de operacións de memoria ao seu redor.
/// Isto crea relacións sincronizadas con elas e operacións atómicas ou valos noutros fíos.
///
/// Un valo 'A' que ten (polo menos) [`Release`] ordenando semántica, sincronízase cun valado 'B' con (polo menos) semántica [`Acquire`], se e só se existen operacións X e Y, ambas operando nalgún obxecto atómico 'M' tal que A se secuencia antes X, Y sincronízase antes de que B e Y observe o cambio a M.
/// Isto proporciona unha dependencia entre A e B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// As operacións atómicas con semántica [`Release`] ou [`Acquire`] tamén se poden sincronizar cunha cerca.
///
/// Un valo que ten orde [`SeqCst`], ademais de ter semántica [`Acquire`] e [`Release`], participa na orde do programa global das outras operacións e/ou valos [`SeqCst`].
///
/// Acepta pedidos [`Acquire`], [`Release`], [`AcqRel`] e [`SeqCst`].
///
/// # Panics
///
/// Panics se `order` é [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Unha primitiva exclusión mutua baseada no spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Agarde a que o valor antigo sexa `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Este valado sincronízase coa tenda en `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SEGURIDADE: usar unha cerca atómica é seguro.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Unha cerca de memoria do compilador.
///
/// `compiler_fence` non emite ningún código de máquina, pero restrinxe o tipo de memoria que se reordena ao compilador.En concreto, dependendo da semántica [`Ordering`] dada, pode que o compilador non poida mover lecturas ou escrituras antes ou despois da chamada ao outro lado da chamada a `compiler_fence`.Teña en conta que **non** impide que o *hardware* realice tal orde.
///
/// Isto non é un problema nun contexto de execución dun só fío, pero cando outros fíos poden modificar a memoria ao mesmo tempo, son necesarias primitivas de sincronización máis fortes como [`fence`].
///
/// A reordenación impedida polas diferentes semánticas de ordenación son:
///
///  - con [`SeqCst`], non se permite a reordenación de lecturas e escrituras neste punto.
///  - con [`Release`], as lecturas e escrituras anteriores non se poden mover despois das escrituras posteriores.
///  - con [`Acquire`], as lecturas e escrituras posteriores non se poden adiantar ás lecturas anteriores.
///  - con [`AcqRel`], aplícanse as dúas regras anteriores.
///
/// `compiler_fence` xeralmente só é útil para evitar que un fío corra *consigo mesmo*.É dicir, se un fío dado está executando un anaco de código, e entón é interrompido e comeza a executar código noutro lugar (aínda no mesmo fío e, conceptualmente, no mesmo núcleo).Nos programas tradicionais, isto só pode ocorrer cando se rexistra un controlador de sinal.
/// En códigos máis baixos, tales situacións tamén poden xurdir cando se manexan interrupcións, cando se implementan fíos verdes con preferencia, etc.
/// Anímase aos lectores curiosos a ler a discusión do núcleo Linux sobre [memory barriers].
///
/// # Panics
///
/// Panics se `order` é [`Relaxed`].
///
/// # Examples
///
/// Sen `compiler_fence`, o `assert_eq!` no seguinte código * non está garantido para ter éxito, a pesar de que todo sucede nun só fío.
/// Para ver por que, lembre que o compilador é libre de cambiar as tendas por `IMPORTANT_VARIABLE` e `IS_READ` xa que ambas son `Ordering::Relaxed`.Se o fai e o controlador de sinal invócase xusto despois de actualizar `IS_READY`, entón o controlador de sinal verá `IS_READY=1`, pero `IMPORTANT_VARIABLE=0`.
/// Usar un `compiler_fence` remedia esta situación.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // evitar que as escrituras anteriores se movan máis alá deste punto
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SEGURIDADE: usar unha cerca atómica é seguro.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Sinala ao procesador que está dentro dun ciclo de xiro ocupado ("bloqueo de xiro").
///
/// Esta función está obsoleta a favor de [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}