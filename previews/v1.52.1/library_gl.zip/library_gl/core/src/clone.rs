//! O `Clone` trait para tipos que non se poden "copiar implícitamente".
//!
//! En Rust, algúns tipos sinxelos son "implicitly copyable" e cando os asignas ou os pasas como argumentos, o receptor recibirá unha copia, deixando o valor orixinal no seu lugar.
//! Estes tipos non requiren asignación para copiar e non teñen finalizadores (é dicir, non conteñen caixas de propiedade nin implementan [`Drop`]), polo que o compilador os considera baratos e seguros de copiar.
//!
//! Para outros tipos, as copias deben facerse de xeito explícito, por convención, implementando o [`Clone`] trait e chamando ao método [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Exemplo de uso básico:
//!
//! ```
//! let s = String::new(); // O tipo de cadea implementa Clon
//! let copy = s.clone(); // para que poidamos clonalo
//! ```
//!
//! Para implementar facilmente o Clone trait, tamén pode usar `#[derive(Clone)]`.Exemplo:
//!
//! ```
//! #[derive(Clone)] // engadimos o clon trait a Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // e agora podemos clonalo!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Un trait común para a capacidade de duplicar explícitamente un obxecto.
///
/// Diferénciase de [`Copy`] porque [`Copy`] é implícito e moi barato, mentres que `Clone` é sempre explícito e pode ou non ser caro.
/// Para facer cumprir estas características, Rust non permite reimplementar [`Copy`], pero pode reimplementar `Clone` e executar código arbitrario.
///
/// Dado que `Clone` é máis xeral que [`Copy`], tamén podes facer que [`Copy`] sexa `Clone`.
///
/// ## Derivable
///
/// Este trait pode usarse con `#[derive]` se todos os campos son `Clone`.A implementación `derive`d de [`Clone`] chama a [`clone`] en cada campo.
///
/// [`clone`]: Clone::clone
///
/// Para unha estrutura xenérica, `#[derive]` implementa `Clone` condicionalmente engadindo `Clone` ligado a parámetros xenéricos.
///
/// ```
/// // `derive` implementa Clon para ler<T>cando T é Clon.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Como podo implementar `Clone`?
///
/// Os tipos que sexan [`Copy`] deberían ter unha implementación trivial de `Clone`.Máis formalmente:
/// se `T: Copy`, `x: T` e `y: &T`, entón `let x = y.clone();` equivale a `let x = *y;`.
/// As implementacións manuais deberían ter coidado de manter este invariante;con todo, o código non seguro non debe confiar nel para garantir a seguridade da memoria.
///
/// Un exemplo é unha estrutura xenérica que ten un punteiro de función.Neste caso, a implementación de `Clone` non se pode `derivar`d, pero pódese implementar como:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Implementadores adicionais
///
/// Ademais do [implementors listed below][impls], os seguintes tipos tamén implementan `Clone`:
///
/// * Tipos de elementos de funcións (ou sexa, os distintos tipos definidos para cada función)
/// * Tipos de punteiros de funcións (por exemplo, `fn() -> i32`)
/// * Tipos de matriz, para todos os tamaños, se o tipo de elemento tamén implementa `Clone` (por exemplo, `[i32; 123456]`)
/// * Tipos de tuplas, se cada compoñente tamén implementa `Clone` (por exemplo, `()`, `(i32, bool)`)
/// * Tipos de peche, se non captan ningún valor do contorno ou se todos estes valores capturados implementan `Clone` eles mesmos.
///   Teña en conta que as variables capturadas por referencia compartida sempre implementan `Clone` (aínda que o referente non), mentres que as variables capturadas por referencia mutable nunca implementan `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Devolve unha copia do valor.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implementa Clon
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Realiza a asignación de copias desde `source`.
    ///
    /// `a.clone_from(&b)` equivale á funcionalidade de `a = b.clone()`, pero pode anularse para reutilizar os recursos de `a` para evitar asignacións innecesarias.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Deriva macro xerando un impl do trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): estas estruturas son utilizadas exclusivamente por#[derive] para afirmar que cada compoñente dun tipo implementa Clonar ou Copiar.
//
//
// Estas estruturas nunca deben aparecer no código de usuario.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementacións de `Clone` para tipos primitivos.
///
/// As implementacións que non se poden describir en Rust están implementadas en `traits::SelectionContext::copy_clone_conditions()` en `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// As referencias compartidas pódense clonar, pero as referencias mutables *non poden*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// As referencias compartidas pódense clonar, pero as referencias mutables *non poden*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}