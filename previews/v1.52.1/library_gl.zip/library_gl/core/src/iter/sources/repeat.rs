use crate::iter::{FusedIterator, TrustedLen};

/// Crea un novo iterador que repite infinitamente un único elemento.
///
/// A función `repeat()` repite un único valor unha e outra vez.
///
/// Os iteradores infinitos como `repeat()` úsanse a miúdo con adaptadores como [`Iterator::take()`], para facelos finitos.
///
/// Se o tipo de elemento do iterador que precisa non implementa `Clone` ou se non quere manter o elemento repetido na memoria, pode usar a función [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::iter;
///
/// // o número catro 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // si, aínda catro
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Vai finito con [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // ese último exemplo foi demasiados catro.Só teñamos catro catro.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... e agora rematamos
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Un iterador que repite un elemento sen fin.
///
/// Este `struct` está creado pola función [`repeat()`].Vexa a súa documentación para máis información.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}