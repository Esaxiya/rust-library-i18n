use crate::fmt;

/// Crea un novo iterador onde cada iteración chama `F: FnMut() -> Option<T>` ao peche proporcionado.
///
/// Isto permite crear un iterador personalizado con calquera comportamento sen empregar a sintaxe máis detallada de crear un tipo dedicado e implementar o [`Iterator`] trait para el.
///
/// Teña en conta que o iterador `FromFn` non fai suposicións sobre o comportamento do peche e, polo tanto, de forma conservadora non implementa [`FusedIterator`] nin anula [`Iterator::size_hint()`] desde o seu `(0, None)` predeterminado.
///
///
/// O peche pode usar capturas e o seu contorno para rastrexar o estado a través das iteracións.Dependendo de como se utilice o iterador, é posible que iso precise unha especificación da palabra clave [`move`] no peche.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Imos volver a implementar o contador iterador de [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Aumenta a nosa conta.É por iso que comezamos a cero.
///     count += 1;
///
///     // Comproba se rematamos de contar ou non.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Un iterador onde cada iteración chama `F: FnMut() -> Option<T>` ao peche proporcionado.
///
/// Este `struct` está creado pola función [`iter::from_fn()`].
/// Vexa a súa documentación para máis información.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}