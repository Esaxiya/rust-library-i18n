use crate::iter::{FusedIterator, TrustedLen};

/// Crea un novo iterador que repite elementos do tipo `A` sen fin aplicando o peche proporcionado, o repetidor, `F: FnMut() -> A`.
///
/// A función `repeat_with()` chama ao repetidor unha e outra vez.
///
/// Os iteradores infinitos como `repeat_with()` úsanse a miúdo con adaptadores como [`Iterator::take()`], para facelos finitos.
///
/// Se o tipo de elemento do iterador que precisa implementa [`Clone`] e está ben manter o elemento fonte na memoria, debería empregar a función [`repeat()`].
///
///
/// Un iterador producido por `repeat_with()` non é un [`DoubleEndedIterator`].
/// Se precisa `repeat_with()` para devolver un [`DoubleEndedIterator`], abra un problema de GitHub explicando o seu caso de uso.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::iter;
///
/// // supoñamos que temos algún valor dun tipo que non é `Clone` ou que aínda non quere ter na memoria porque é caro:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // un valor particular para sempre:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Usando mutación e indo finito:
///
/// ```rust
/// use std::iter;
///
/// // Do cero ao terceiro poder de dous:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... e agora rematamos
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Un iterador que repite elementos do tipo `A` sen fin aplicando o peche `F: FnMut() -> A` fornecido.
///
///
/// Este `struct` está creado pola función [`repeat_with()`].
/// Vexa a súa documentación para máis información.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}