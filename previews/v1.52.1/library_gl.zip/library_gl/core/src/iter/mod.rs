//! Iteración externa composable.
//!
//! Se te atopaches cunha colección dalgún tipo e necesitabas realizar unha operación cos elementos da devandita colección, atoparás rapidamente 'iterators'.
//! Os iteradores úsanse moito no código idiomático Rust, polo que paga a pena familiarizarse con eles.
//!
//! Antes de explicar máis, falemos de como se estrutura este módulo:
//!
//! # Organization
//!
//! Este módulo está organizado en gran parte por tipo:
//!
//! * [Traits] son a parte principal: estes traits definen que tipo de iteradores existen e que podes facer con eles.Os métodos destes traits pagan a pena poñer un tempo de estudo extra.
//! * [Functions] fornecer algúns xeitos útiles para crear algúns iteradores básicos.
//! * [Structs] adoitan ser os tipos de retorno dos distintos métodos do traits deste módulo.Normalmente quererás ver o método que crea o `struct`, en lugar do `struct` en si.
//! Para máis detalles sobre o por que, consulte '[Implementing Iterator](#Implementing-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Xa está!Digamos nos iteradores.
//!
//! # Iterator
//!
//! O corazón e a alma deste módulo é o [`Iterator`] trait.O núcleo de [`Iterator`] ten este aspecto:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Un iterador ten un método, [`next`], que cando se chama, devolve unha [`Opción`]`<Item>`.
//! [`next`] devolverá [`Some(Item)`] sempre que haxa elementos e, unha vez esgotados, devolverá `None` para indicar que a iteración está rematada.
//! Os iteradores individuais poden optar por retomar a iteración e, así, chamar de novo a [`next`] pode ou non acabar por devolver [`Some(Item)`] nalgún momento (por exemplo, ver [`TryIter`]).
//!
//!
//! A definición completa de [`Iterator`] inclúe tamén outros métodos, pero son métodos predeterminados, construídos sobre [`next`], polo que os obtés de balde.
//!
//! Os iteradores tamén se poden compoñer e é común encadealos para facer formas máis complexas de procesamento.Vexa a sección [Adapters](#adapters) a continuación para obter máis detalles.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # As tres formas de iteración
//!
//! Hai tres métodos comúns que poden crear iteradores a partir dunha colección:
//!
//! * `iter()`, que itera sobre `&T`.
//! * `iter_mut()`, que itera sobre `&mut T`.
//! * `into_iter()`, que itera sobre `T`.
//!
//! Varias cousas na biblioteca estándar poden implementar unha ou máis das tres, se é o caso.
//!
//! # Implementando Iterator
//!
//! Crear un iterador propio implica dous pasos: crear un `struct` para manter o estado do iterador e despois implementar [`Iterator`] para ese `struct`.
//! É por iso que hai tantos `struct`s neste módulo: hai un para cada iterador e adaptador de iterador.
//!
//! Imos facer un iterador chamado `Counter` que conta de `1` a `5`:
//!
//! ```
//! // En primeiro lugar, a estrutura:
//!
//! /// Un iterador que conta dun a cinco
//! struct Counter {
//!     count: usize,
//! }
//!
//! // queremos que o noso reconto comece por un, así que engadimos un método new() para axudar.
//! // Isto non é estritamente necesario, pero é conveniente.
//! // Teña en conta que comezamos `count` a cero, veremos por que na implementación `next()`'s a continuación.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Despois, implementamos `Iterator` para o noso `Counter`:
//!
//! impl Iterator for Counter {
//!     // estaremos contando con usize
//!     type Item = usize;
//!
//!     // next() é o único método requirido
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Aumenta a nosa conta.É por iso que comezamos a cero.
//!         self.count += 1;
//!
//!         // Comproba se rematamos de contar ou non.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // E agora podemos usalo!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Chamar ao [`next`] deste xeito faise repetitivo.Rust ten unha construción que pode chamar a [`next`] no seu iterador, ata chegar a `None`.Repasemos o seguinte.
//!
//! Teña en conta tamén que `Iterator` proporciona unha implementación predeterminada de métodos como `nth` e `fold` que chaman internamente a `next`.
//! Non obstante, tamén é posible escribir unha implementación personalizada de métodos como `nth` e `fold` se un iterador pode computalos de xeito máis eficiente sen chamar a `next`.
//!
//! # `for` loops e `IntoIterator`
//!
//! A sintaxe do bucle `for` de Rust é realmente azucre para os iteradores.Aquí tes un exemplo básico de `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Isto imprimirá os números do un ao cinco, cada un na súa propia liña.Pero notarás algo aquí: nunca chamamos nada ao noso vector para producir un iterador.Que dá?
//!
//! Na biblioteca estándar hai un trait para converter algo nun iterador: [`IntoIterator`].
//! Este trait ten un método, [`into_iter`], que converte a cousa que implementa [`IntoIterator`] nun iterador.
//! Vexamos de novo ese bucle `for` e en que o converte o compilador:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust elimina os azucres en:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! En primeiro lugar, chamamos a `into_iter()` polo valor.Despois, coincidimos no iterador que volve, chamando ao [`next`] unha e outra vez ata que vemos un `None`.
//! Nese momento, `break` saímos do circuíto e rematamos a iteración.
//!
//! Aquí hai un pouco máis sutil: a biblioteca estándar contén unha interesante implementación de [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Noutras palabras, todos [`Iterator`] implementan [`IntoIterator`], só volvendo a si mesmos.Isto significa dúas cousas:
//!
//! 1. Se estás escribindo un [`Iterator`], podes usalo cun bucle `for`.
//! 2. Se estás creando unha colección, a implementación de [`IntoIterator`] permitirá que a túa colección se utilice co bucle `for`.
//!
//! # Iterando por referencia
//!
//! Dado que [`into_iter()`] toma `self` por valor, usar un bucle `for` para repetir unha colección consome esa colección.Moitas veces pode querer repetir unha colección sen consumila.
//! Moitas coleccións ofrecen métodos que proporcionan iteradores sobre referencias, convencionalmente chamados `iter()` e `iter_mut()` respectivamente:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` aínda é propiedade desta función.
//! ```
//!
//! Se unha colección tipo `C` proporciona `iter()`, normalmente tamén implementa `IntoIterator` para `&C`, cunha implementación que só chama `iter()`.
//! Do mesmo xeito, unha colección `C` que proporciona `iter_mut()` xeralmente implementa `IntoIterator` para `&mut C` delegando en `iter_mut()`.Isto permite unha taquigrafía conveniente:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // igual que `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // igual que `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Aínda que moitas coleccións ofrecen `iter()`, non todas ofrecen `iter_mut()`.
//! Por exemplo, mutando as claves dun [`HashSet<T>`] ou [`HashMap<K, V>`] podería colocar a colección nun estado inconsistente se cambian os hash de chaves, polo que estas coleccións só ofrecen `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! As funcións que levan un [`Iterator`] e devolven outro [`Iterator`] adoitan denominarse "adaptadores iteradores", xa que son unha forma do "adaptador
//! pattern'.
//!
//! Os adaptadores iteradores comúns inclúen [`map`], [`take`] e [`filter`].
//! Para máis información, consulte a súa documentación.
//!
//! Se un adaptador de iterador panics, o iterador estará nun estado non especificado (pero seguro para a memoria).
//! Este estado tampouco está garantido para manterse igual nas versións de Rust, polo que debes evitar confiar nos valores exactos devoltos por un iterador que entrou en pánico.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Os iteradores (e o iterador [adapters](#adapters)) son *preguiceiros*. Isto significa que só crear un iterador non é moi grande para _do_. En realidade non pasa nada ata que chamas ao [`next`].
//! Ás veces isto é fonte de confusión cando se crea un iterador exclusivamente polos seus efectos secundarios.
//! Por exemplo, o método [`map`] chama un peche a cada elemento que itera:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Isto non imprimirá ningún valor, xa que só creamos un iterador en lugar de usalo.O compilador avisaranos sobre este tipo de comportamento:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! O xeito idiomático de escribir un [`map`] para os seus efectos secundarios é empregar un bucle `for` ou chamar ao método [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Outro xeito común de avaliar un iterador é empregar o método [`collect`] para producir unha nova colección.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Os iteradores non teñen por que ser finitos.Como exemplo, un rango aberto é un iterador infinito:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! É común usar o adaptador de iterador [`take`] para converter un iterador infinito nun finito:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Isto imprimirá os números `0` a `4`, cada un na súa propia liña.
//!
//! Ten en conta que os métodos en iteradores infinitos, incluso aqueles para os que un resultado pode determinarse matemáticamente en tempo finito, poden non rematar.
//! En concreto, é probable que métodos como [`min`], que no caso xeral requiren percorrer todos os elementos do iterador, non volvan con éxito para ningún iterador infinito.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // ¡Non, non!Un bucle infinito!
//! // `ones.min()` provoca un bucle infinito, polo que non chegaremos a este punto.
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;