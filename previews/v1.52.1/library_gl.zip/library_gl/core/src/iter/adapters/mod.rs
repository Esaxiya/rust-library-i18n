use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Este trait proporciona acceso transitivo á fase de orixe nunha canalización de adaptador de interador nas condicións que
/// * a fonte do iterador `S` implementa `SourceIter<Source = S>`
/// * hai unha implementación delegadora deste trait para cada adaptador na canalización entre a fonte e o consumidor da canalización.
///
/// Cando a fonte é unha estrutura de iterador propietaria (normalmente chamada `IntoIter`), isto pode ser útil para especializar implementacións de [`FromIterator`] ou recuperar os elementos restantes despois de que un iterador se esgotase parcialmente.
///
///
/// Teña en conta que as implementacións non necesariamente teñen que proporcionar acceso á fonte máis interna dun gasoduto.Un adaptador intermedio con estado pode avaliar con ansia unha parte da canalización e expor o seu almacenamento interno como fonte.
///
/// O trait non é seguro porque os implementadores deben manter propiedades de seguridade adicionais.
/// Vexa [`as_inner`] para máis detalles.
///
/// # Examples
///
/// Recuperando unha fonte parcialmente consumida:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Unha etapa de orixe nunha canalización de iteradores.
    type Source: Iterator;

    /// Recuperar a fonte dunha canalización de iteradores.
    ///
    /// # Safety
    ///
    /// As implementacións de deben devolver a mesma referencia mutable durante a súa vida útil, a non ser que sexan substituídas por un interlocutor.
    /// Os interlocutores só poden substituír a referencia cando detiveron a iteración e deixaron caer a canalización do iterador despois de extraer a fonte.
    ///
    /// Isto significa que os adaptadores de iteradores poden confiar en que a fonte non cambia durante a iteración, pero non poden confiar nel nas súas implementacións Drop.
    ///
    /// A implementación deste método significa que os adaptadores renuncian ao acceso exclusivo privado á súa fonte e só poden confiar en garantías feitas en función dos tipos de receptores de métodos.
    /// A falta de acceso restrinxido tamén require que os adaptadores deban manter a API pública da fonte, mesmo cando teñen acceso ás súas funcións internas.
    ///
    /// Pola súa banda, os interlocutores deben esperar que a fonte estea en calquera estado que sexa coherente coa súa API pública, xa que os adaptadores situados entre ela e a fonte teñen o mesmo acceso.
    /// En particular, un adaptador pode ter consumido máis elementos dos estritamente necesarios.
    ///
    /// O obxectivo xeral destes requisitos é deixar que o consumidor utilice un gasoduto
    /// * todo o que queda na fonte despois de que a iteración detivese
    /// * a memoria que quedou inutilizada ao avanzar nun iterador consumidor
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Un adaptador de iterador que produce saída sempre que o iterador subxacente produce valores `Result::Ok`.
///
///
/// Se se produce un erro, o iterador detense e almacénase.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Procese o iterador dado como se producise un `T` en lugar dun `Result<T, _>`.
/// Calquera erro deterá o iterador interno e o resultado global será un erro.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}