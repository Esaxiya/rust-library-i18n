/// Conversión dun [`Iterator`].
///
/// Ao implementar `FromIterator` para un tipo, define como se creará a partir dun iterador.
/// Isto é común para os tipos que describen unha colección dalgún tipo.
///
/// [`FromIterator::from_iter()`] rara vez chámase explícitamente e úsase no método [`Iterator::collect()`].
///
/// Consulte a documentación de [`Iterator::collect()`]'s para obter máis exemplos.
///
/// Ver tamén: [`IntoIterator`].
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Usando [`Iterator::collect()`] para usar implícitamente `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Implementando `FromIterator` para o seu tipo:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Unha colección de mostras, iso é só un envoltorio sobre Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Imos darlle algúns métodos para que poidamos crear un e engadirlle cousas.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // e implementaremos FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Agora podemos facer un novo iterador ...
/// let iter = (0..5).into_iter();
///
/// // ... e faga unha MyCollection con ela
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // recolle obras tamén!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Crea un valor a partir dun iterador.
    ///
    /// Vexa o [module-level documentation] para obter máis información.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Conversión nun [`Iterator`].
///
/// Ao implementar `IntoIterator` para un tipo, define como se converterá nun iterador.
/// Isto é común para os tipos que describen unha colección dalgún tipo.
///
/// Un dos beneficios de implementar `IntoIterator` é que o teu tipo será [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Ver tamén: [`FromIterator`].
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Implementando `IntoIterator` para o seu tipo:
///
/// ```
/// // Unha colección de mostras, iso é só un envoltorio sobre Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Imos darlle algúns métodos para que poidamos crear un e engadirlle cousas.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // e implementaremos IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Agora podemos facer unha nova colección ...
/// let mut c = MyCollection::new();
///
/// // ... engádelle algunhas cousas ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... e logo convérteo nun iterador:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// É común usar `IntoIterator` como trait bound.Isto permite que o tipo de colección de entrada cambie, sempre e cando aínda sexa un iterador.
/// Pódense especificar límites adicionais restrinxindo
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// O tipo de elementos que se repiten.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// En que tipo de iterador estamos a converter isto?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Crea un iterador a partir dun valor.
    ///
    /// Vexa o [module-level documentation] para obter máis información.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Amplíe unha colección co contido dun iterador.
///
/// Os iteradores producen unha serie de valores e as coleccións tamén se poden considerar como unha serie de valores.
/// O `Extend` trait colma este espazo, permitíndolle ampliar unha colección incluíndo o contido dese iterador.
/// Ao ampliar unha colección cunha clave xa existente, actualízase esa entrada ou, no caso de coleccións que permitan varias entradas con claves iguais, insírese esa entrada.
///
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// // Podes ampliar unha cadea con algúns caracteres:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implementando `Extend`:
///
/// ```
/// // Unha colección de mostras, iso é só un envoltorio sobre Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Imos darlle algúns métodos para que poidamos crear un e engadirlle cousas.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // xa que MyCollection ten unha lista de i32, implementamos Extend para i32
/// impl Extend<i32> for MyCollection {
///
///     // Isto é un pouco máis sinxelo coa sinatura de tipo concreto: podemos chamar extensión a calquera cousa que poida converterse nun Iterador que nos dea i32s.
///     // Porque necesitamos i32 para colocar en MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // A implementación é moi sinxela: percorre o iterador e add() cada elemento para nós mesmos.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // ampliemos a nosa colección con tres números máis
/// c.extend(vec![1, 2, 3]);
///
/// // engadimos estes elementos ao final
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Amplía unha colección co contido dun iterador.
    ///
    /// Como este é o único método necesario para este trait, os documentos [trait-level] conteñen máis detalles.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // Podes ampliar unha cadea con algúns caracteres:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Amplía unha colección con exactamente un elemento.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Reserva capacidade nunha colección para o número dado de elementos adicionais.
    ///
    /// A implementación predeterminada non fai nada.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}