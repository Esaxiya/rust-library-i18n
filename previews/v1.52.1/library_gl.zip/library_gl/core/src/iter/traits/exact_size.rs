/// Un iterador que sabe a súa lonxitude exacta.
///
/// Moitos [`Iterator`] non saben cantas veces repetirán, pero algúns si.
/// Se un iterador sabe cantas veces pode repetir, pode ser útil proporcionar acceso a esa información.
/// Por exemplo, se queres repetir cara atrás, un bo comezo é saber onde está o final.
///
/// Ao implementar un `ExactSizeIterator`, tamén debe implementar [`Iterator`].
/// Ao facelo, a implementación de [`Iterator::size_hint`]*debe* devolver o tamaño exacto do iterador.
///
/// O método [`len`] ten unha implementación predeterminada, polo que normalmente non debería implementalo.
/// Non obstante, é posible que poida proporcionar unha implementación máis eficaz que a predeterminada, polo que ten sentido ter que substituíla neste caso.
///
///
/// Teña en conta que este trait é un trait seguro e, como tal,*non* e *non pode* garantir que a lonxitude devolta sexa correcta.
/// Isto significa que o código `unsafe`**non debe** confiar na corrección de [`Iterator::size_hint`].
/// O inestable e inseguro [`TrustedLen`](super::marker::TrustedLen) trait ofrece esta garantía adicional.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// // un rango finito sabe exactamente cantas veces iterará
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// No [module-level docs], implementamos un [`Iterator`], `Counter`.
/// Imos implementar `ExactSizeIterator` tamén para iso:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Podemos calcular facilmente o número restante de iteracións.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // E agora podemos usalo!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Devolve a lonxitude exacta do iterador.
    ///
    /// A implementación garante que o iterador devolva exactamente `len()` máis veces un valor [`Some(T)`], antes de devolver [`None`].
    ///
    /// Este método ten unha implementación predeterminada, polo que normalmente non debería implementalo directamente.
    /// Non obstante, se pode proporcionar unha implementación máis eficiente, pode facelo.
    /// Vexa os documentos [trait-level] para obter un exemplo.
    ///
    /// Esta función ten as mesmas garantías de seguridade que a función [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // un rango finito sabe exactamente cantas veces iterará
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Esta afirmación é demasiado defensiva, pero comproba o invariante
        // garantido polo trait.
        // Se este trait fose rust-interno, poderiamos usar debug_assert !;afirmar_eq!comprobará tamén todas as implementacións do usuario de Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Devolve `true` se o iterador está baleiro.
    ///
    /// Este método ten unha implementación predeterminada usando [`ExactSizeIterator::len()`], polo que non precisa implementalo vostede mesmo.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}