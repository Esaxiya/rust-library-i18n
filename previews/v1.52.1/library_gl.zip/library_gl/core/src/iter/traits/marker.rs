/// Un iterador que sempre produce `None` cando está esgotado.
///
/// Chamar despois a un iterador fusionado que devolveu `None` unha vez está garantido para devolver [`None`] de novo.
/// Este trait debería ser implementado por todos os iteradores que se comporten deste xeito porque permite optimizar [`Iterator::fuse()`].
///
///
/// Note: En xeral, non debería usar `FusedIterator` nos límites xenéricos se precisa un iterador fusionado.
/// Pola contra, só debes chamar ao [`Iterator::fuse()`] no iterador.
/// Se o iterador xa está fusionado, o envoltorio adicional [`Fuse`] será un non operativo sen penalización de rendemento.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Un iterador que informa dunha lonxitude precisa usando size_hint.
///
/// O iterador informa dunha suxestión de tamaño onde é exacta (o límite inferior é igual ao límite superior) ou o límite superior é [`None`].
///
/// O límite superior só debe ser [`None`] se a lonxitude real do iterador é maior que [`usize::MAX`].
/// Nese caso, o límite inferior debe ser [`usize::MAX`], o que resulta nun [`Iterator::size_hint()`] de `(usize::MAX, None)`.
///
/// O iterador debe producir exactamente o número de elementos dos que informou ou diverxen antes de chegar ao final.
///
/// # Safety
///
/// Este trait só debe implementarse cando se confirma o contrato.
/// Os consumidores deste trait deben inspeccionar o límite superior [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Un iterador que ao producir un elemento tomou polo menos un elemento do seu [`SourceIter`] subxacente.
///
/// Chamando a calquera método que avance o iterador, por exemplo
/// [`next()`] ou [`try_fold()`], garante que para cada paso se moveu polo menos un valor da fonte subxacente do iterador e que o resultado da cadea do iterador podería inserirse no seu lugar, supoñendo que as restricións estruturais da fonte permitan tal inserción.
///
/// Noutras palabras, este trait indica que se pode recoller un oleoduto iterador no seu lugar.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}