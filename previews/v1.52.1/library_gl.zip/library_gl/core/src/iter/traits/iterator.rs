// ignore-tidy-filelength Este ficheiro consiste case exclusivamente na definición de `Iterator`.
// Non podemos dividilo en varios ficheiros.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Unha interface para tratar con iteradores.
///
/// Este é o principal iterador trait.
/// Para obter máis información sobre o concepto de iteradores en xeral, consulte o [module-level documentation].
/// En particular, quizais queiras saber como [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// O tipo de elementos que se repiten.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Avanza o iterador e devolve o seguinte valor.
    ///
    /// Devolve [`None`] cando finaliza a iteración.
    /// As implementacións de iteradores individuais poden optar por retomar a iteración e, por tanto, chamar de novo a `next()` pode ou non acabar por devolver [`Some(Item)`] nalgún momento.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Unha chamada a next() devolve o seguinte valor ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... e logo Ningunha vez que remate.
    /// assert_eq!(None, iter.next());
    ///
    /// // É posible que máis chamadas devolvan `None` ou non.Aquí, sempre o farán.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Devolve os límites da lonxitude restante do iterador.
    ///
    /// En concreto, `size_hint()` devolve unha tupla onde o primeiro elemento é o límite inferior e o segundo elemento é o límite superior.
    ///
    /// A segunda metade da tupla que se devolve é unha [`Opción`]`<`[`usize`] `>>.
    /// Un [`None`] aquí significa que non hai límite superior coñecido ou que o límite superior é maior que [`usize`].
    ///
    /// # Notas de implementación
    ///
    /// Non se aplica que unha implementación iteradora produza o número declarado de elementos.Un iterador de buggy pode producir menos que o límite inferior ou máis que o límite superior dos elementos.
    ///
    /// `size_hint()` está pensado principalmente para usarse para optimizacións como a reserva de espazo para os elementos do iterador, pero non debe confiarse, por exemplo, omitir as comprobacións de límites nun código non seguro.
    /// Unha implementación incorrecta de `size_hint()` non debería provocar violacións da seguridade da memoria.
    ///
    /// Dito isto, a implementación debería proporcionar unha estimación correcta, porque doutro xeito sería unha violación do protocolo de trait.
    ///
    /// A implementación predeterminada devolve `(0,` [Ningún`]`)` o que é correcto para calquera iterador.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Un exemplo máis complexo:
    ///
    /// ```
    /// // Os números pares de cero a dez.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Poderiamos repetir de cero a dez veces.
    /// // Saber que son cinco exactamente non sería posible sen executar filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Engadimos cinco números máis con chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // agora os dous límites aumentan en cinco
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Devolver `None` para un límite superior:
    ///
    /// ```
    /// // un iterador infinito non ten límite superior e o límite inferior máximo posible
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Consume o iterador, contando o número de iteracións e devolvéndoo.
    ///
    /// Este método chamará [`next`] varias veces ata que se atope [`None`], devolvendo a cantidade de veces que viu [`Some`].
    /// Teña en conta que [`next`] ten que ser chamado polo menos unha vez aínda que o iterador non teña ningún elemento.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Comportamento de desbordamento
    ///
    /// O método non protexe contra desbordamentos, polo que contar elementos dun iterador con máis de [`usize::MAX`] produce un resultado incorrecto ou panics.
    ///
    /// Se as afirmacións de depuración están habilitadas, garántese un panic.
    ///
    /// # Panics
    ///
    /// Esta función pode ser panic se o iterador ten máis de elementos [`usize::MAX`].
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Consume o iterador, devolvendo o último elemento.
    ///
    /// Este método avaliará o iterador ata que devolva [`None`].
    /// Ao facelo, fai un seguimento do elemento actual.
    /// Despois de devolver [`None`], `last()` devolverá o último elemento que viu.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Avanza o iterador por elementos `n`.
    ///
    /// Este método saltará con entusiasmo os elementos `n` chamando a [`next`] ata `n` veces ata que se atope [`None`].
    ///
    /// `advance_by(n)` devolverá [`Ok(())`][Ok] se o iterador avanza con éxito por elementos `n`, ou [`Err(k)`][Err] se se atopa [`None`], onde `k` é o número de elementos que avanza o iterador antes de quedar sen elementos (é dicir,
    /// a lonxitude do iterador).
    /// Teña en conta que `k` sempre é inferior a `n`.
    ///
    /// Chamar ao `advance_by(0)` non consume ningún elemento e sempre devolve [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // só se omitiu `&4`
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Devolve o `n`th elemento do iterador.
    ///
    /// Como a maioría das operacións de indexación, o reconto comeza desde cero, polo que `nth(0)` devolve o primeiro valor, `nth(1)` o segundo, etc.
    ///
    /// Teña en conta que todos os elementos anteriores, así como o elemento devolto, serán consumidos desde o iterador.
    /// Isto significa que os elementos precedentes serán descartados e tamén que chamar `nth(0)` varias veces no mesmo iterador devolverá elementos diferentes.
    ///
    ///
    /// `nth()` devolverá [`None`] se `n` é maior ou igual á lonxitude do iterador.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Chamar ao `nth()` varias veces non rebobina o iterador:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Devolver `None` se hai menos de elementos `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Crea un iterador comezando no mesmo punto, pero pasando pola cantidade dada en cada iteración.
    ///
    /// Nota 1: sempre se devolverá o primeiro elemento do iterador, independentemente do paso dado.
    ///
    /// Nota 2: o tempo no que se tiran os elementos ignorados non está fixado.
    /// `StepBy` compórtase como a secuencia `next(), nth(step-1), nth(step-1),…`, pero tamén é libre de comportarse como a secuencia
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Cal é o camiño que se pode usar para algúns iteradores por razóns de rendemento.
    /// A segunda forma avanzará o iterador antes e pode consumir máis elementos.
    ///
    /// `advance_n_and_return_first` é o equivalente a:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// O método será panic se o paso dado é `0`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Toma dous iteradores e crea un novo iterador entre ambos en secuencia.
    ///
    /// `chain()` devolverá un novo iterador que primeiro iterará sobre os valores do primeiro iterador e despois sobre os valores do segundo iterador.
    ///
    /// Noutras palabras, vincula dous iteradores xuntos, nunha cadea.🔗
    ///
    /// [`once`] úsase normalmente para adaptar un único valor a unha cadea doutros tipos de iteración.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dado que o argumento para `chain()` usa [`IntoIterator`], podemos pasar calquera cousa que poida converterse nun [`Iterator`], non só nun [`Iterator`].
    /// Por exemplo, as franxas (`&[T]`) implementan [`IntoIterator`], polo que se poden pasar directamente a `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Se traballas coa API Windows, quizais queiras converter [`OsStr`] a `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// "Repita" dous iteradores nun único iterador de pares.
    ///
    /// `zip()` devolve un novo iterador que iterará sobre outros dous iteradores, devolvendo unha tupla onde o primeiro elemento provén do primeiro iterador e o segundo elemento provén do segundo iterador.
    ///
    ///
    /// Noutras palabras, comparte dous iteradores xuntos, nun só.
    ///
    /// Se calquera dos iteradores devolve [`None`], [`next`] do iterador comprimido devolverá [`None`].
    /// Se o primeiro iterador devolve [`None`], `zip` curtocircuitará e `next` non se chamará no segundo iterador.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dado que o argumento para `zip()` usa [`IntoIterator`], podemos pasar calquera cousa que poida converterse nun [`Iterator`], non só nun [`Iterator`].
    /// Por exemplo, as franxas (`&[T]`) implementan [`IntoIterator`], polo que se poden pasar directamente a `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` úsase a miúdo para comprimir un iterador infinito a outro finito.
    /// Isto funciona porque o iterador finito finalmente devolverá [`None`], rematando a cremalleira.Zipping con `(0..)` pode parecerse moito a [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Crea un novo iterador que coloca unha copia de `separator` entre elementos adxacentes do iterador orixinal.
    ///
    /// No caso de que `separator` non implemente [`Clone`] ou necesite ser calculado cada vez, use [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // O primeiro elemento de `a`.
    /// assert_eq!(a.next(), Some(&100)); // O separador.
    /// assert_eq!(a.next(), Some(&1));   // O seguinte elemento de `a`.
    /// assert_eq!(a.next(), Some(&100)); // O separador.
    /// assert_eq!(a.next(), Some(&2));   // O último elemento de `a`.
    /// assert_eq!(a.next(), None);       // O iterador está rematado.
    /// ```
    ///
    /// `intersperse` pode ser moi útil para unir elementos dun iterador usando un elemento común:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Crea un novo iterador que coloca un elemento xerado por `separator` entre elementos adxacentes do iterador orixinal.
    ///
    /// O peche chamarase exactamente unha vez que se coloca un elemento entre dous elementos adxacentes do iterador subxacente;
    /// especificamente, o peche non se chama se o iterador subxacente produce menos de dous elementos e despois de que se produce o último elemento.
    ///
    ///
    /// Se o elemento do iterador implementa [`Clone`], pode ser máis doado usar [`intersperse`].
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // O primeiro elemento de `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // O separador.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // O seguinte elemento de `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // O separador.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // O último elemento de `v`.
    /// assert_eq!(it.next(), None);               // O iterador está rematado.
    /// ```
    ///
    /// `intersperse_with` pódese usar en situacións nas que hai que calcular o separador:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // O peche mutuamente toma o seu contexto para xerar un elemento.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Fai un peche e crea un iterador que chama ese peche a cada elemento.
    ///
    /// `map()` transforma un iterador noutro, mediante o seu argumento:
    /// algo que implementa [`FnMut`].Produce un novo iterador que chama este peche a cada elemento do iterador orixinal.
    ///
    /// Se vostede é bo pensando en tipos, pode pensar en `map()` así:
    /// Se tes un iterador que che proporciona elementos dalgún tipo `A` e queres un iterador doutro tipo `B`, podes usar `map()`, pasando un peche que leva un `A` e devolve un `B`.
    ///
    ///
    /// `map()` é conceptualmente similar a un bucle [`for`].Non obstante, como `map()` é preguiceiro, úsase mellor cando xa está a traballar con outros iteradores.
    /// Se estás facendo algún tipo de bucle para obter un efecto secundario, considérase máis idiomático usar [`for`] que `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Se estás a facer algún tipo de efecto secundario, prefire [`for`] a `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // non fagas isto:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // nin sequera se executará, xa que é preguiceiro.Rust avisará sobre isto.
    ///
    /// // En lugar diso, use para:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Chama o peche de cada elemento dun iterador.
    ///
    /// Isto equivale a usar un bucle [`for`] no iterador, aínda que `break` e `continue` non son posibles desde un peche.
    /// Xeralmente é máis idiomático usar un bucle `for`, pero `for_each` pode ser máis lexible ao procesar elementos ao final de cadeas de iteradores máis longas.
    ///
    /// Nalgúns casos `for_each` tamén pode ser máis rápido que un bucle, porque empregará a iteración interna en adaptadores como `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Para un exemplo tan pequeno, un lazo `for` pode ser máis limpo, pero `for_each` pode ser preferible para manter un estilo funcional con iteradores máis longos:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Crea un iterador que usa un peche para determinar se se debe ceder un elemento.
    ///
    /// Dado un elemento, o peche debe devolver `true` ou `false`.O iterador devolto só producirá os elementos para os que o peche devolve verdadeiro.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Debido a que o peche pasado a `filter()` ten unha referencia e moitos iteradores iteran sobre as referencias, isto leva a unha situación posiblemente confusa, onde o tipo de peche é unha referencia dobre:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // necesito dous * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// É común usar a desestruturación no argumento para eliminar un:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // tanto&e *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ou ambos:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // dous &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// destas capas.
    ///
    /// Teña en conta que `iter.filter(f).next()` equivale a `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Crea un iterador que filtra e mapea.
    ///
    /// O iterador devolto só produce o "valor" para o que o peche subministrado devolve `Some(value)`.
    ///
    /// `filter_map` pódese usar para facer cadeas de [`filter`] e [`map`] máis concisas.
    /// O seguinte exemplo mostra como se pode acurtar un `map().filter().map()` a unha única chamada a `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Aquí tes o mesmo exemplo, pero con [`filter`] e [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Crea un iterador que proporciona o reconto de iteración actual e o seguinte valor.
    ///
    /// O iterador devolto produce pares `(i, val)`, onde `i` é o índice actual de iteración e `val` é o valor devolto polo iterador.
    ///
    ///
    /// `enumerate()` mantén a súa conta como [`usize`].
    /// Se desexa contar cun número enteiro diferente, a función [`zip`] proporciona unha funcionalidade similar.
    ///
    /// # Comportamento de desbordamento
    ///
    /// O método non protexe contra desbordamentos, polo que enumerar máis de elementos [`usize::MAX`] produce un resultado incorrecto ou panics.
    /// Se as afirmacións de depuración están habilitadas, garántese un panic.
    ///
    /// # Panics
    ///
    /// O iterador devolto pode panic se o índice que se devolvería desbordaría un [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Crea un iterador que pode usar [`peek`] para ver o seguinte elemento do iterador sen consumilo.
    ///
    /// Engade un método [`peek`] a un iterador.Consulte a súa documentación para obter máis información.
    ///
    /// Teña en conta que o iterador subxacente aínda está avanzado cando se chama [`peek`] por primeira vez: Para recuperar o seguinte elemento, [`next`] chámase ao iterador subxacente, de aí que se produzan efectos secundarios (é dicir,
    ///
    /// calquera outra cousa que non sexa a obtención do seguinte valor) do método [`next`].
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() déixanos ver no future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // podemos peek() varias veces, o iterador non avanzará
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // despois de que o iterador remate, peek() tamén
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Crea un iterador que [`saltar]] s elementos baseados nun predicado.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` toma un peche como argumento.Chamará este peche a cada elemento do iterador e ignorará os elementos ata que devolva `false`.
    ///
    /// Despois de devolver `false`, o traballo `skip_while()`'s rematou e cédense o resto dos elementos.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Debido a que o peche pasado a `skip_while()` ten unha referencia e moitos iteradores iteran sobre as referencias, isto leva a unha situación posiblemente confusa, onde o tipo do argumento de peche é unha dobre referencia:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // necesito dous * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Parar despois dun `false` inicial:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // aínda que isto sería falso, xa que xa recibimos un falso, skip_while() xa non se usa
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Crea un iterador que produce elementos baseados nun predicado.
    ///
    /// `take_while()` toma un peche como argumento.Chamará este peche a cada elemento do iterador e producirá elementos mentres devolve `true`.
    ///
    /// Despois de devolver `false`, finalizou o traballo `take_while()`'s e ignóranse o resto dos elementos.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Debido a que o peche pasado a `take_while()` ten unha referencia e moitos iteradores iteran sobre as referencias, isto leva a unha situación posiblemente confusa, onde o tipo de peche é unha referencia dobre:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // necesito dous * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Parar despois dun `false` inicial:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Temos máis elementos inferiores a cero, pero como xa recibimos un falso, take_while() xa non se usa
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Debido a que `take_while()` precisa mirar o valor para ver se se debe incluír ou non, os consumidores iteradores verán que se elimina:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// O `3` xa non está, porque se consumiu para ver se a iteración debería deterse, pero non se volveu colocar no iterador.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Crea un iterador que produce elementos baseados nun predicado e mapas.
    ///
    /// `map_while()` toma un peche como argumento.
    /// Chamará este peche a cada elemento do iterador e producirá elementos mentres devolve [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Aquí tes o mesmo exemplo, pero con [`take_while`] e [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Parar despois dun [`None`] inicial:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Temos máis elementos que poden caber en u32 (4, 5), pero `map_while` devolveu `None` para `-3` (xa que o `predicate` devolveu `None`) e `collect` detense no primeiro `None` atopado.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Debido a que `map_while()` precisa mirar o valor para ver se se debe incluír ou non, os consumidores iteradores verán que se elimina:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// O `-3` xa non está, porque se consumiu para ver se a iteración debería deterse, pero non se volveu colocar no iterador.
    ///
    /// Teña en conta que a diferenza de [`take_while`] este iterador **non** está fundido.
    /// Tampouco se especifica o que devolve este iterador despois de devolver o primeiro [`None`].
    /// Se precisa un iterador fundido, use [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Crea un iterador que salta os primeiros elementos `n`.
    ///
    /// Despois de consumilos, cédese o resto dos elementos.
    /// En lugar de substituír este método directamente, anule o método `nth`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Crea un iterador que produce os seus primeiros elementos `n`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` úsase a miúdo cun iterador infinito, para facelo finito:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Se hai menos de elementos `n` dispoñibles, `take` limitarase ao tamaño do iterador subxacente:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Un adaptador de iterador similar ao [`fold`] que mantén o estado interno e produce un novo iterador.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` leva dous argumentos: un valor inicial que sementa o estado interno e un peche con dous argumentos, sendo o primeiro unha referencia mutable ao estado interno e o segundo un elemento iterador.
    ///
    /// O peche pode asignarse ao estado interno para compartir o estado entre as iteracións.
    ///
    /// Na iteración, o peche aplicarase a cada elemento do iterador e o valor de devolución do peche, un [`Option`], prodúcese polo iterador.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // cada iteración, multiplicaremos o estado polo elemento
    ///     *state = *state * x;
    ///
    ///     // entón, produciremos a negación do estado
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Crea un iterador que funciona como o mapa, pero que aplana a estrutura aniñada.
    ///
    /// O adaptador [`map`] é moi útil, pero só cando o argumento de peche produce valores.
    /// Se produce un iterador, hai unha capa adicional de indirección.
    /// `flat_map()` eliminará esta capa adicional por si mesma.
    ///
    /// Podes pensar en `flat_map(f)` como o equivalente semántico de [`map`] ping e despois [`aplanar`] coma en `map(f).flatten()`.
    ///
    /// Outro xeito de pensar sobre `flat_map()`: o peche de [`map`] devolve un elemento por cada elemento e o peche de `flat_map()`'s devolve un iterador por cada elemento.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() devolve un iterador
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Crea un iterador que aplana a estrutura aniñada.
    ///
    /// Isto é útil cando tes un iterador de iteradores ou un iterador de cousas que se poden converter en iteradores e queres eliminar un nivel de indirección.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Mapeo e despois aplanamento:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() devolve un iterador
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Tamén pode reescribilo en termos de [`flat_map()`], o que é preferible neste caso xa que transmite a intención de xeito máis claro:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() devolve un iterador
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// O aplanamento só elimina un nivel de aniñamento á vez:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Aquí vemos que `flatten()` non realiza un aplanamento "deep".
    /// Pola contra, só se elimina un nivel de aniñamento.É dicir, se `flatten()` é unha matriz tridimensional, o resultado será bidimensional e non unidimensional.
    /// Para obter unha estrutura unidimensional, tes que volver a `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Crea un iterador que remata despois do primeiro [`None`].
    ///
    /// Despois de que un iterador devolva [`None`], as chamadas future poden producir ou non [`Some(T)`] de novo.
    /// `fuse()` adapta un iterador, garantindo que despois de dar un [`None`], sempre devolverá [`None`] para sempre.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// // un iterador que alterna entre Some e None
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // se é par, Some(i32), senón Ningún
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // podemos ver como o noso iterador vai e vén
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // con todo, unha vez que o fundimos ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // sempre devolverá `None` despois da primeira vez.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Fai algo con cada elemento dun iterador, pasando o valor.
    ///
    /// Cando usas iteradores, adoitas encadear varios deles.
    /// Mentres traballa neste código, pode querer comprobar o que está a suceder en varias partes do gasoduto.Para iso, insira unha chamada ao `inspect()`.
    ///
    /// É máis común que `inspect()` se use como ferramenta de depuración que no seu código final, pero as aplicacións poden resultarlle útil en determinadas situacións nas que hai que rexistrar erros antes de descartalos.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // esta secuencia iteradora é complexa.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // engadimos algunhas chamadas inspect() para investigar o que está a suceder
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Isto imprimirá:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Erros de rexistro antes de descartalos:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Isto imprimirá:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Presta un iterador en lugar de consumilo.
    ///
    /// Isto é útil para permitir a aplicación de adaptadores de iteradores mantendo a propiedade do iterador orixinal.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // se intentamos usalo de novo, non funcionará.
    /// // A seguinte liña indica "erro: uso do valor movido: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // imos tentalo de novo
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // no seu lugar, engadimos un .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // agora está moi ben:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Transforma un iterador nunha colección.
    ///
    /// `collect()` pode levar todo o que se poida repetir e convertelo nunha colección relevante.
    /// Este é un dos métodos máis potentes da biblioteca estándar, empregado nunha variedade de contextos.
    ///
    /// O patrón máis básico no que se usa `collect()` é converter unha colección noutra.
    /// Toma unha colección, chama a [`iter`], fai un monte de transformacións e despois `collect()` ao final.
    ///
    /// `collect()` tamén pode crear casos de tipos que non son coleccións típicas.
    /// Por exemplo, pódese construír un [`String`] a partir de [`char`] s e pódese recoller un iterador de elementos [`Result<T, E>`][`Result`] en `Result<Collection<T>, E>`.
    ///
    /// Vexa os exemplos a continuación para obter máis información.
    ///
    /// Debido a que `collect()` é tan xeral, pode causar problemas coa inferencia de tipo.
    /// Como tal, `collect()` é unha das poucas veces que verá a sintaxe cariñosamente coñecida como 'turbofish': `::<>`.
    /// Isto axuda ao algoritmo de inferencia a comprender específicamente en que colección estás intentando recompilar.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Teña en conta que necesitabamos o `: Vec<i32>` no lado esquerdo.Isto débese a que poderiamos recoller, por exemplo, un [`VecDeque<T>`]:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Usando o 'turbofish' no canto de anotar `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Como `collect()` só se preocupa polo que estás a recoller, aínda podes usar unha información de tipo parcial, `_`, co turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Usando `collect()` para facer un [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Se ten unha lista de [`Resultado<T, E>`][` Resultado]], pode usar `collect()` para ver se fallou algún deles:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // dános o primeiro erro
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // dános a lista de respostas
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Consume un iterador, creando dúas coleccións a partir del.
    ///
    /// O predicado pasado a `partition()` pode devolver `true` ou `false`.
    /// `partition()` devolve un par, todos os elementos polos que devolveu `true` e todos os elementos polos que devolveu `false`.
    ///
    ///
    /// Vexa tamén [`is_partitioned()`] e [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Reordena os elementos deste iterador *no lugar* segundo o predicado dado, de tal xeito que todos os que devolven `true` preceden a todos os que devolven `false`.
    ///
    /// Devolve o número de elementos `true` atopados.
    ///
    /// Non se mantén a orde relativa dos elementos particionados.
    ///
    /// Vexa tamén [`is_partitioned()`] e [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Partición no lugar entre pares e probabilidades
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: ¿debemos preocuparnos polo desbordamento do reconto?O único xeito de ter máis de
        // `usize::MAX` as referencias mutables están con ZST, que non son útiles para particionar ...

        // Estas funcións de peche "factory" existen para evitar a xenericidade en `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Atopa repetidamente o primeiro `false` e cámbiao co último `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Comproba se os elementos deste iterador están particionados segundo o predicado dado, de xeito que todos os que devolven `true` preceden a todos os que devolven `false`.
    ///
    ///
    /// Vexa tamén [`partition()`] e [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Ou todos os elementos proban `true` ou a primeira cláusula detense en `false` e comprobamos que despois non hai máis elementos `true`.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Un método iterador que aplica unha función sempre que volva con éxito, producindo un único valor final.
    ///
    /// `try_fold()` leva dous argumentos: un valor inicial e un peche con dous argumentos: un 'accumulator' e un elemento.
    /// O peche devolve con éxito, co valor que debería ter o acumulador para a seguinte iteración, ou devolve un fallo, cun valor de erro que se propaga de volta ao interlocutor (short-circuiting).
    ///
    ///
    /// O valor inicial é o valor que terá o acumulador na primeira chamada.Se a aplicación do peche tivo éxito contra todos os elementos do iterador, `try_fold()` devolve o acumulador final como éxito.
    ///
    /// O pregamento é útil sempre que tes unha colección de algo e queres producir un único valor a partir del.
    ///
    /// # Nota aos Implementadores
    ///
    /// Varios dos outros métodos (forward) teñen implementacións predeterminadas en termos deste, así que intente implementalo explícitamente se pode facer algo mellor que a implementación predeterminada do bucle `for`.
    ///
    /// En particular, intente ter esta chamada `try_fold()` nas partes internas das que está composto este iterador.
    /// Se son necesarias varias chamadas, o operador `?` pode ser conveniente para encadear o valor do acumulador, pero ten coidado con calquera invariante que deba confirmarse antes deses devolucións anticipadas.
    /// Este é un método `&mut self`, polo que hai que retomar a iteración despois de ter un erro aquí.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a suma comprobada de todos os elementos da matriz
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Esta suma desborda ao engadir o elemento 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Debido a que se cortocircuitou, os elementos restantes aínda están dispoñibles a través do iterador.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Un método de iterador que aplica unha función falible a cada elemento do iterador, deténdose no primeiro erro e devolvendo ese erro.
    ///
    ///
    /// Isto tamén se pode considerar como a forma falible de [`for_each()`] ou como a versión sen estado de [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Cortocircuitouse, polo que os elementos restantes aínda están no iterador:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Dobra todos os elementos nun acumulador aplicando unha operación, devolvendo o resultado final.
    ///
    /// `fold()` leva dous argumentos: un valor inicial e un peche con dous argumentos: un 'accumulator' e un elemento.
    /// O peche devolve o valor que o acumulador debería ter para a seguinte iteración.
    ///
    /// O valor inicial é o valor que terá o acumulador na primeira chamada.
    ///
    /// Despois de aplicar este peche a todos os elementos do iterador, `fold()` devolve o acumulador.
    ///
    /// Esta operación ás veces chámase 'reduce' ou 'inject'.
    ///
    /// O pregamento é útil sempre que tes unha colección de algo e queres producir un único valor a partir del.
    ///
    /// Note: `fold()`, e métodos similares que percorren todo o iterador, poden non finalizar en iteradores infinitos, incluso en traits para os que un resultado é determinable en tempo finito.
    ///
    /// Note: [`reduce()`] pode usarse para usar o primeiro elemento como valor inicial, se o tipo de acumulador e o tipo de elemento son os mesmos.
    ///
    /// # Nota aos Implementadores
    ///
    /// Varios dos outros métodos (forward) teñen implementacións predeterminadas en termos deste, así que intente implementalo explícitamente se pode facer algo mellor que a implementación predeterminada do bucle `for`.
    ///
    ///
    /// En particular, intente ter esta chamada `fold()` nas partes internas das que está composto este iterador.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a suma de todos os elementos da matriz
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Percorramos cada paso da iteración aquí:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// E así, o noso resultado final, `6`.
    ///
    /// É común que as persoas que non usaron moito os iteradores usen un bucle `for` cunha lista de cousas para acumular un resultado.Pódense converter en `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // para bucle:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // son os mesmos
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Reduce os elementos a un só aplicando repetidamente unha operación redutora.
    ///
    /// Se o iterador está baleiro, devolve [`None`];se non, devolve o resultado da redución.
    ///
    /// Para os iteradores con polo menos un elemento, isto é o mesmo que [`fold()`] co primeiro elemento do iterador como valor inicial, dobrando nel todos os elementos posteriores.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Atopar o valor máximo:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Proba se todos os elementos do iterador coinciden cun predicado.
    ///
    /// `all()` leva un peche que devolve `true` ou `false`.Aplica este peche a cada elemento do iterador e, se todos devolven `true`, tamén o fai `all()`.
    /// Se algún deles devolve `false`, devolve `false`.
    ///
    /// `all()` está en curtocircuíto;noutras palabras, deixará de procesarse en canto atope un `false`, dado que non importa o que pase, o resultado tamén será `false`.
    ///
    ///
    /// Un iterador baleiro devolve `true`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Parando no primeiro `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // aínda podemos usar `iter`, xa que hai máis elementos.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Proba se algún elemento do iterador coincide cun predicado.
    ///
    /// `any()` leva un peche que devolve `true` ou `false`.Aplica este peche a cada elemento do iterador e, se algún deles devolve `true`, tamén o fai `any()`.
    /// Se todos devolven `false`, devolve `false`.
    ///
    /// `any()` está en curtocircuíto;noutras palabras, deixará de procesarse en canto atope un `true`, dado que non importa o que pase, o resultado tamén será `true`.
    ///
    ///
    /// Un iterador baleiro devolve `false`.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Parando no primeiro `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // aínda podemos usar `iter`, xa que hai máis elementos.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Busca un elemento dun iterador que satisfaga un predicado.
    ///
    /// `find()` leva un peche que devolve `true` ou `false`.
    /// Aplica este peche a cada elemento do iterador e, se algún deles devolve `true`, entón `find()` devolve [`Some(element)`].
    /// Se todos devolven `false`, devolve [`None`].
    ///
    /// `find()` está en curtocircuíto;noutras palabras, deixará de procesarse en canto o peche devolva `true`.
    ///
    /// Debido a que `find()` toma unha referencia e moitos iteradores repiten sobre as referencias, isto leva a unha situación posiblemente confusa onde o argumento é unha dobre referencia.
    ///
    /// Podes ver este efecto nos exemplos de abaixo, con `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Parando no primeiro `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // aínda podemos usar `iter`, xa que hai máis elementos.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Teña en conta que `iter.find(f)` equivale a `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Aplica a función aos elementos do iterador e devolve o primeiro resultado que non é ningún.
    ///
    ///
    /// `iter.find_map(f)` equivale a `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Aplica a función aos elementos do iterador e devolve o primeiro resultado verdadeiro ou o primeiro erro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Busca un elemento nun iterador, devolvendo o seu índice.
    ///
    /// `position()` leva un peche que devolve `true` ou `false`.
    /// Aplica este peche a cada elemento do iterador e se un deles devolve `true`, entón `position()` devolve [`Some(index)`].
    /// Se todos eles devolven `false`, devolve [`None`].
    ///
    /// `position()` está en curtocircuíto;noutras palabras, deixará de procesarse en canto atope un `true`.
    ///
    /// # Comportamento de desbordamento
    ///
    /// O método non protexe contra desbordamentos, polo que se hai máis de [`usize::MAX`] elementos que non coinciden, produce un resultado incorrecto ou panics.
    ///
    /// Se as afirmacións de depuración están habilitadas, garántese un panic.
    ///
    /// # Panics
    ///
    /// Esta función pode ser panic se o iterador ten máis de elementos `usize::MAX` que non coinciden.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Parando no primeiro `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // aínda podemos usar `iter`, xa que hai máis elementos.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // O índice devolto depende do estado do iterador
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Busca un elemento nun iterador desde a dereita, devolvendo o seu índice.
    ///
    /// `rposition()` leva un peche que devolve `true` ou `false`.
    /// Aplica este peche a cada elemento do iterador, a partir do final, e se un deles devolve `true`, entón `rposition()` devolve [`Some(index)`].
    ///
    /// Se todos eles devolven `false`, devolve [`None`].
    ///
    /// `rposition()` está en curtocircuíto;noutras palabras, deixará de procesarse en canto atope un `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Parando no primeiro `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // aínda podemos usar `iter`, xa que hai máis elementos.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Non fai falta verificación de desbordamento aquí, porque `ExactSizeIterator` implica que o número de elementos encaixa nun `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Devolve o elemento máximo dun iterador.
    ///
    /// Se varios elementos son igualmente máximos, devólvese o último elemento.
    /// Se o iterador está baleiro, devólvese [`None`].
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Devolve o elemento mínimo dun iterador.
    ///
    /// Se varios elementos son igualmente mínimos, devólvese o primeiro elemento.
    /// Se o iterador está baleiro, devólvese [`None`].
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Devolve o elemento que dá o valor máximo da función especificada.
    ///
    ///
    /// Se varios elementos son igualmente máximos, devólvese o último elemento.
    /// Se o iterador está baleiro, devólvese [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Devolve o elemento que dá o valor máximo con respecto á función de comparación especificada.
    ///
    ///
    /// Se varios elementos son igualmente máximos, devólvese o último elemento.
    /// Se o iterador está baleiro, devólvese [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Devolve o elemento que dá o valor mínimo da función especificada.
    ///
    ///
    /// Se varios elementos son igualmente mínimos, devólvese o primeiro elemento.
    /// Se o iterador está baleiro, devólvese [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Devolve o elemento que dá o valor mínimo con respecto á función de comparación especificada.
    ///
    ///
    /// Se varios elementos son igualmente mínimos, devólvese o primeiro elemento.
    /// Se o iterador está baleiro, devólvese [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Inverte a dirección dun iterador.
    ///
    /// Normalmente, os iteradores iteran de esquerda a dereita.
    /// Despois de usar `rev()`, no seu lugar un iterador iterará de dereita a esquerda.
    ///
    /// Isto só é posible se o iterador ten un final, polo que `rev()` só funciona en [`DoubleEndedIterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Converte un iterador de pares nun par de contedores.
    ///
    /// `unzip()` consume todo un iterador de pares, producindo dúas coleccións: unha a partir dos elementos esquerdos dos pares e outra a partir dos elementos correctos.
    ///
    ///
    /// Esta función é, nalgún sentido, a oposta a [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Crea un iterador que copia todos os seus elementos.
    ///
    /// Isto é útil cando tes un iterador superior a `&T`, pero necesitas un iterador superior a `T`.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // copiado é o mesmo que .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Crea un iterador que [`clonar] ten todos os seus elementos.
    ///
    /// Isto é útil cando tes un iterador superior a `&T`, pero necesitas un iterador superior a `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // clonado é o mesmo que .map(|&x| x), para enteiros
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Repite un iterador sen fin.
    ///
    /// En vez de parar en [`None`], o iterador comezará de novo desde o principio.Despois de repetir de novo, comezará de novo ao comezo.E de novo.
    /// E de novo.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Resume os elementos dun iterador.
    ///
    /// Toma cada elemento, súmalos e devolve o resultado.
    ///
    /// Un iterador baleiro devolve o valor cero do tipo.
    ///
    /// # Panics
    ///
    /// Cando se chama a `sum()` e se devolve un tipo enteiro primitivo, este método será panic se o computador desborda e as afirmacións de depuración están activadas.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Repite todo o iterador, multiplicando todos os elementos
    ///
    /// Un iterador baleiro devolve o único valor do tipo.
    ///
    /// # Panics
    ///
    /// Cando se chama a `product()` e se devolve un tipo enteiro primitivo, o método será panic se o computador desborda e as afirmacións de depuración están activadas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compara os elementos deste [`Iterator`] cos doutro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compara os elementos deste [`Iterator`] cos doutro respecto á función de comparación especificada.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compara os elementos deste [`Iterator`] cos doutro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compara os elementos deste [`Iterator`] cos doutro respecto á función de comparación especificada.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Determina se os elementos deste [`Iterator`] son iguais aos doutro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Determina se os elementos deste [`Iterator`] son iguais aos doutro respecto á función de igualdade especificada.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Determina se os elementos deste [`Iterator`] son desiguais aos doutro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Determina se os elementos deste [`Iterator`] son [lexicographically](Ord#lexicographical-comparison) menos que os doutro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Determina se os elementos deste [`Iterator`] son [lexicographically](Ord#lexicographical-comparison) menos ou iguais aos doutro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Determina se os elementos deste [`Iterator`] son [lexicographically](Ord#lexicographical-comparison) maiores que os doutro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Determina se os elementos deste [`Iterator`] son [lexicographically](Ord#lexicographical-comparison) maiores ou iguais aos doutro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Comproba se os elementos deste iterador están ordenados.
    ///
    /// É dicir, para cada elemento `a` e o seu seguinte elemento `b`, `a <= b` debe manterse.Se o iterador produce exactamente cero ou un elemento, devólvese `true`.
    ///
    /// Teña en conta que se `Self::Item` é só `PartialOrd`, pero non `Ord`, a definición anterior implica que esta función devolve `false` se dous elementos consecutivos non son comparables.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Comproba se os elementos deste iterador están ordenados usando a función de comparador dada.
    ///
    /// En vez de usar `PartialOrd::partial_cmp`, esta función usa a función `compare` dada para determinar a ordenación de dous elementos.
    /// Ademais disto, equivale a [`is_sorted`];consulte a súa documentación para obter máis información.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Comproba se os elementos deste iterador están ordenados usando a función de extracción de chave dada.
    ///
    /// En vez de comparar directamente os elementos do iterador, esta función compara as claves dos elementos, como determina `f`.
    /// Ademais disto, equivale a [`is_sorted`];consulte a súa documentación para obter máis información.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Vexa [TrustedRandomAccess]
    // O nome inusual é evitar colisións de nomes na resolución do método. Vexa #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}