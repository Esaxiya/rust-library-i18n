//! Define o iterador de matrices do `IntoIter`.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Un iterador [array] por valor.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Esta é a matriz que estamos a repetir.
    ///
    /// Elementos con índice `i` onde `alive.start <= i < alive.end` aínda non se produciron e son entradas de matriz válidas.
    /// Xa se produciron elementos con índices `i < alive.start` ou `i >= alive.end` e xa non se debe acceder a eles.Eses elementos mortos poderían incluso estar nun estado completamente non inicializado.
    ///
    ///
    /// Polo tanto, os invariantes son:
    /// - `data[alive]` está vivo (é dicir, contén elementos válidos)
    /// - `data[..alive.start]` e `data[alive.end..]` están mortos (é dicir, os elementos xa estaban lidos e xa non se deben tocar!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Os elementos en `data` que aínda non se produciron.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Crea un novo iterador sobre o `array` dado.
    ///
    /// *Nota*: este método pode estar obsoleto en future, despois de [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // O tipo de `value` é un `i32` aquí, no canto de `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SEGURIDADE: o transmuto aquí é realmente seguro.Os documentos de `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` ten o mesmo tamaño e aliñamento
        // > como `T`.
        //
        // Os documentos incluso mostran un transmuto dunha matriz de `MaybeUninit<T>` a unha matriz de `T`.
        //
        //
        // Con iso, esta inicialización satisfai aos invariantes.

        // FIXME(LukasKalbertodt): realmente use `mem::transmute` aquí, unha vez que funciona con const xenéricos:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Ata entón, podemos usar `mem::transmute_copy` para crear unha copia bit a bit como un tipo diferente e logo esquecer `array` para que non se caia.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Devolve unha porción inmutable de todos os elementos que aínda non se produciron.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SEGURIDADE: Sabemos que todos os elementos dentro de `alive` están inicializados correctamente.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Devolve unha porción mutable de todos os elementos que aínda non se produciron.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SEGURIDADE: Sabemos que todos os elementos dentro de `alive` están inicializados correctamente.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Obtén o seguinte índice desde a fronte.
        //
        // Aumentar `alive.start` en 1 mantén o invariante respecto a `alive`.
        // Non obstante, debido a este cambio, por pouco tempo, a zona viva xa non é `data[alive]`, senón `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Le o elemento da matriz.
            // SEGURIDADE: `idx` é un índice da antiga rexión "alive" do
            // matriz.Ler este elemento significa que `data[idx]` considérase morto agora (é dicir, non o toques).
            // Como `idx` foi o comezo da zona viva, a zona viva agora é `data[alive]` de novo, restaurando todos os invariantes.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Obtén o seguinte índice de atrás.
        //
        // A diminución de `alive.end` en 1 mantén o invariante respecto a `alive`.
        // Non obstante, debido a este cambio, por pouco tempo, a zona viva xa non é `data[alive]`, senón `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Le o elemento da matriz.
            // SEGURIDADE: `idx` é un índice da antiga rexión "alive" do
            // matriz.Ler este elemento significa que `data[idx]` considérase morto agora (é dicir, non o toques).
            // Como `idx` era o final da zona viva, a zona viva agora é `data[alive]` de novo, restaurando todos os invariantes.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SEGURIDADE: isto é seguro: `as_mut_slice` devolve exactamente a sub-porción
        // de elementos que aínda non se moveron e que quedan por deixar caer.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Nunca se desbordará debido ao invariante `vivo.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// O iterador efectivamente informa da lonxitude correcta.
// O número de elementos "alive" (que aínda se producirá) é a lonxitude do rango `alive`.
// Este rango diminúe en lonxitude en `next` ou `next_back`.
// Sempre se decrementa en 1 neses métodos, pero só se devolve `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Teña en conta que non precisamos coincidir exactamente co mesmo rango vivo, polo que podemos clonar no offset 0 independentemente de onde estea `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Clonar todos os elementos vivos.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Escribe un clon na nova matriz e logo actualiza o seu rango vivo.
            // Se clonamos panics, eliminaremos correctamente os elementos anteriores.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Imprimir só os elementos que aínda non se produciron: xa non podemos acceder aos elementos cedidos.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}