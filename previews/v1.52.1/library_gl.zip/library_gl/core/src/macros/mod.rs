#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Expande a `$crate::panic::panic_2015` ou `$crate::panic::panic_2021` dependendo da edición do interlocutor.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Afirma que dúas expresións son iguais entre si (usando [`PartialEq`]).
///
/// En panic, esta macro imprimirá os valores das expresións coas súas representacións de depuración.
///
///
/// Do mesmo xeito que [`assert!`], esta macro ten un segundo formulario, onde se pode proporcionar unha mensaxe panic personalizada.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Os reinicios a continuación son intencionados.
                    // Sen eles, a ranura de pila para o préstamo inicialízase incluso antes de comparar os valores, o que leva a unha ralentización notable.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Os reinicios a continuación son intencionados.
                    // Sen eles, a ranura de pila para o préstamo inicialízase incluso antes de comparar os valores, o que leva a unha ralentización notable.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Afirma que dúas expresións non son iguais entre si (usando [`PartialEq`]).
///
/// En panic, esta macro imprimirá os valores das expresións coas súas representacións de depuración.
///
///
/// Do mesmo xeito que [`assert!`], esta macro ten un segundo formulario, onde se pode proporcionar unha mensaxe panic personalizada.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Os reinicios a continuación son intencionados.
                    // Sen eles, a ranura de pila para o préstamo inicialízase incluso antes de comparar os valores, o que leva a unha ralentización notable.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Os reinicios a continuación son intencionados.
                    // Sen eles, a ranura de pila para o préstamo inicialízase incluso antes de comparar os valores, o que leva a unha ralentización notable.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Afirma que unha expresión booleana é `true` no tempo de execución.
///
/// Isto invocará a macro [`panic!`] se a expresión proporcionada non se pode avaliar a `true` no tempo de execución.
///
/// Como [`assert!`], esta macro tamén ten unha segunda versión, onde se pode proporcionar unha mensaxe panic personalizada.
///
/// # Uses
///
/// A diferenza de [`assert!`], as instrucións `debug_assert!` só están habilitadas de xeito predeterminado en versións non optimizadas.
/// Unha compilación optimizada non executará instrucións `debug_assert!` a menos que `-C debug-assertions` se pase ao compilador.
/// Isto fai que `debug_assert!` sexa útil para comprobacións demasiado caras para estar presentes nunha versión de versión pero que poden ser útiles durante o desenvolvemento.
/// O resultado da expansión de `debug_assert!` sempre está comprobado.
///
/// Unha afirmación sen comprobar permite que un programa nun estado inconsistente siga funcionando, o que pode ter consecuencias inesperadas pero non introduce inseguridade sempre que isto só suceda no código seguro.
///
/// Non obstante, o custo de rendemento das afirmacións non é medible en xeral.
/// Así, só se recomenda a substitución de [`assert!`] por `debug_assert!` despois dun perfil completo e, o que é máis importante, só cun código seguro.
///
/// # Examples
///
/// ```
/// // a mensaxe panic para estas afirmacións é o valor en cadea da expresión dada.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // unha función moi sinxela
/// debug_assert!(some_expensive_computation());
///
/// // afirmar cunha mensaxe personalizada
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Afirma que dúas expresións son iguais entre si.
///
/// En panic, esta macro imprimirá os valores das expresións coas súas representacións de depuración.
///
/// A diferenza de [`assert_eq!`], as instrucións `debug_assert_eq!` só están habilitadas de xeito predeterminado en versións non optimizadas.
/// Unha compilación optimizada non executará instrucións `debug_assert_eq!` a menos que `-C debug-assertions` se pase ao compilador.
/// Isto fai que `debug_assert_eq!` sexa útil para comprobacións demasiado caras para estar presentes nunha versión de versión pero que poden ser útiles durante o desenvolvemento.
///
/// O resultado da expansión de `debug_assert_eq!` sempre está comprobado.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Afirma que dúas expresións non son iguais entre si.
///
/// En panic, esta macro imprimirá os valores das expresións coas súas representacións de depuración.
///
/// A diferenza de [`assert_ne!`], as instrucións `debug_assert_ne!` só están habilitadas de xeito predeterminado en versións non optimizadas.
/// Unha compilación optimizada non executará instrucións `debug_assert_ne!` a menos que `-C debug-assertions` se pase ao compilador.
/// Isto fai que `debug_assert_ne!` sexa útil para comprobacións demasiado caras para estar presentes nunha versión de versión pero que poden ser útiles durante o desenvolvemento.
///
/// O resultado da expansión de `debug_assert_ne!` sempre está comprobado.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Devolve se a expresión dada coincide con algún dos patróns dados.
///
/// Do mesmo xeito que nunha expresión `match`, o patrón pode seguirse opcionalmente por `if` e unha expresión de garda que ten acceso a nomes ligados polo patrón.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Desenvolve un resultado ou propaga o seu erro.
///
/// Engadiuse o operador `?` para substituír a `try!` e debería utilizarse no seu lugar.
/// Ademais, `try` é unha palabra reservada en Rust 2018, polo que se debes usalo, terás que usar o [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` coincide co [`Result`] dado.No caso da variante `Ok`, a expresión ten o valor do valor axustado.
///
/// No caso da variante `Err`, recupera o erro interno.`try!` realiza entón a conversión usando `From`.
/// Isto proporciona a conversión automática entre erros especializados e outros máis xerais.
/// O erro resultante devólvese inmediatamente.
///
/// Debido ao retorno anticipado, `try!` só se pode usar en funcións que devolven [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // O método preferido para devolver rapidamente os erros
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // O método anterior de devolución rápida de erros
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Isto equivale a:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Escribe datos formatados nun buffer.
///
/// Esta macro acepta un 'writer', unha cadea de formato e unha lista de argumentos.
/// Os argumentos formataranse segundo a cadea de formato especificada e o resultado pasarase ao escritor.
/// O escritor pode ter calquera valor cun método `write_fmt`;xeralmente isto provén dunha implementación do [`fmt::Write`] ou do [`io::Write`] trait.
/// A macro devolve o que devolva o método `write_fmt`;normalmente un [`fmt::Result`] ou un [`io::Result`].
///
/// Vexa [`std::fmt`] para obter máis información sobre a sintaxe da cadea de formato.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Un módulo pode importar `std::fmt::Write` e `std::io::Write` e chamar a `write!` en calquera dos obxectos que implementen, xa que os obxectos normalmente non implementan ambos.
///
/// Non obstante, o módulo debe importar o traits cualificado para que os seus nomes non entren en conflito:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // usa fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // usa io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Esta macro tamén se pode usar nas configuracións de `no_std`.
/// Nunha configuración `no_std` vostede é responsable dos detalles de implementación dos compoñentes.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Escribe datos formatados nun buffer, cunha nova liña engadida.
///
/// En todas as plataformas, a nova liña é o personaxe LINE FEED (`\n`/`U+000A`) só (non hai CARRIAGE RETURN (`\r`/`U+000D`) adicional.
///
/// Para obter máis información, consulte [`write!`].Para obter información sobre a sintaxe da cadea de formato, consulte [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Un módulo pode importar `std::fmt::Write` e `std::io::Write` e chamar a `write!` en calquera dos obxectos que implementen, xa que os obxectos normalmente non implementan ambos.
/// Non obstante, o módulo debe importar o traits cualificado para que os seus nomes non entren en conflito:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // usa fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // usa io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Indica un código inalcanzable.
///
/// Isto é útil sempre que o compilador non poida determinar que algún código non é accesible.Por exemplo:
///
/// * Combina os brazos coas condicións da garda.
/// * Bucles que finalizan dinámicamente.
/// * Iteradores que finalizan dinámicamente.
///
/// Se a determinación de que o código non é accesible resulta incorrecta, o programa finaliza inmediatamente cun [`panic!`].
///
/// A contraparte non segura desta macro é a función [`unreachable_unchecked`], que causará un comportamento indefinido se se alcanza o código.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Isto sempre será [`panic!`].
///
/// # Examples
///
/// Brazos de xogo:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // erro de compilación se se comenta
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // unha das implementacións máis pobres de x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Indica o código non implementado entrando en pánico cunha mensaxe de "not implemented".
///
/// Isto permite ao seu código comprobar o tipo, o que é útil se está a facer prototipos ou a implementar un trait que require varios métodos que non ten pensado empregar todos.
///
/// A diferenza entre `unimplemented!` e [`todo!`] é que, aínda que `todo!` transmite a intención de implementar a funcionalidade máis tarde e a mensaxe é "not yet implemented", `unimplemented!` non fai tales reclamacións.
/// A súa mensaxe é "not implemented".
/// Tamén algúns IDE marcarán `todo!` S.
///
/// # Panics
///
/// Isto sempre será [`panic!`] porque `unimplemented!` é só unha abreviatura de `panic!` cunha mensaxe fixa e específica.
///
/// Como `panic!`, esta macro ten un segundo formulario para amosar valores personalizados.
///
/// # Examples
///
/// Digamos que temos un trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Queremos implementar `Foo` para 'MyStruct', pero por algunha razón só ten sentido implementar a función `bar()`.
/// `baz()` e `qux()` aínda necesitará definirse na nosa implementación de `Foo`, pero podemos usar `unimplemented!` nas súas definicións para permitir a compilación do noso código.
///
/// Aínda queremos que o noso programa deixe de executarse se se alcanzan os métodos non implementados.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Non ten sentido `baz` a `MyStruct`, polo que aquí non temos ningunha lóxica.
/////
///         // Isto amosará "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Aquí temos algunha lóxica, podemos engadir unha mensaxe a non implementado.para mostrar a nosa omisión.
///         // Isto amosará: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Indica código inacabado.
///
/// Isto pode ser útil se estás a facer prototipos e só estás a buscar unha verificación tipográfica do teu código.
///
/// A diferenza entre [`unimplemented!`] e `todo!` é que, aínda que `todo!` transmite a intención de implementar a funcionalidade máis tarde e a mensaxe é "not yet implemented", `unimplemented!` non fai tales reclamacións.
/// A súa mensaxe é "not implemented".
/// Tamén algúns IDE marcarán `todo!` S.
///
/// # Panics
///
/// Isto sempre será [`panic!`].
///
/// # Examples
///
/// Aquí tes un exemplo dalgún código en curso.Temos un trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Queremos implementar `Foo` nun dos nosos tipos, pero tamén queremos traballar só en `bar()`.Para que o noso código compile, necesitamos implementar `baz()`, para que poidamos usar `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // a implementación vai aquí
///     }
///
///     fn baz(&self) {
///         // non nos preocupemos por implementar baz() por agora
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // nin sequera estamos a usar baz(), así que está ben.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definicións de macros integradas.
///
/// A maioría das propiedades macro (estabilidade, visibilidade, etc.) están tomadas do código fonte aquí, con excepción das funcións de expansión que transforman as entradas macro en saídas, esas funcións son proporcionadas polo compilador.
///
///
pub(crate) mod builtin {

    /// Fai que falla a compilación coa mensaxe de erro dada cando se atopa.
    ///
    /// Esta macro debería usarse cando un crate usa unha estratexia de compilación condicional para proporcionar mellores mensaxes de erro en condicións erróneas.
    ///
    /// É a forma de compilador de [`panic!`], pero emite un erro durante a *compilación* en vez de en *tempo de execución*.
    ///
    /// # Examples
    ///
    /// Dous exemplos son as macros e os entornos `#[cfg]`.
    ///
    /// Emite un erro mellor no compilador se se pasa a unha macro valores incorrectos.
    /// Sen o branch final, o compilador aínda emitiría un erro, pero a mensaxe do erro non mencionaría os dous valores válidos.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Emite un erro do compilador se unha das funcións non está dispoñible.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Constrúe parámetros para as outras macros de formato de cadea.
    ///
    /// Esta macro funciona tomando unha cadea de formato literal que contén `{}` para cada argumento adicional pasado.
    /// `format_args!` prepara os parámetros adicionais para garantir que a saída poida interpretarse como unha cadea e canoniza os argumentos nun só tipo.
    /// Calquera valor que implante o [`Display`] trait pódese pasar a `format_args!`, como calquera implementación de [`Debug`] pode pasar a un `{:?}` dentro da cadea de formato.
    ///
    ///
    /// Esta macro produce un valor do tipo [`fmt::Arguments`].Este valor pódese pasar ás macros de [`std::fmt`] para realizar unha redirección útil.
    /// Todas as demais macros de formato ([`formato!`], [`write!`], [`println!`], etc.) están proxiadas a través desta.
    /// `format_args!`, a diferenza das súas macros derivadas, evita as asignacións de montón.
    ///
    /// Podes usar o valor [`fmt::Arguments`] que devolve `format_args!` en contextos `Debug` e `Display` como se ve a continuación.
    /// O exemplo tamén mostra que `Debug` e `Display` forman o mesmo: a cadea de formato interpolada en `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Para obter máis información, consulte a documentación en [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Igual que `format_args`, pero ao final engade unha nova liña.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inspecciona unha variable de entorno ao tempo de compilación.
    ///
    /// Esta macro expandirase ao valor da variable de entorno nomeada ao tempo de compilación, producindo unha expresión de tipo `&'static str`.
    ///
    ///
    /// Se a variable de entorno non está definida, emitirase un erro de compilación.
    /// Para non emitir un erro de compilación, use a macro [`option_env!`] no seu lugar.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Podes personalizar a mensaxe de erro pasando unha cadea como segundo parámetro:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Se a variable de entorno `documentation` non está definida, obterá o seguinte erro:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Opcionalmente inspecciona unha variable de entorno ao tempo de compilación.
    ///
    /// Se a variable de ambiente nomeada está presente no momento da compilación, esta expandirase nunha expresión de tipo `Option<&'static str>` cuxo valor é `Some` do valor da variable de ambiente.
    /// Se a variable de entorno non está presente, esta expandirase a `None`.
    /// Vexa [`Option<T>`][Option] para obter máis información sobre este tipo.
    ///
    /// Nunca se emite un erro de tempo de compilación ao usar esta macro independentemente de que a variable de entorno estea presente ou non.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatena identificadores nun identificador.
    ///
    /// Esta macro toma calquera número de identificadores separados por comas e concaténtaos todos nun só, producindo unha expresión que é un novo identificador.
    /// Teña en conta que a hixiene fai que esta macro non poida capturar variables locais.
    /// Ademais, como regra xeral, as macros só se permiten en posición de elemento, instrución ou expresión.
    /// Isto significa que aínda que pode empregar esta macro para referirse a variables existentes, funcións ou módulos, etc., non pode definir unha nova con ela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (novo, divertido, nome) { }//non se pode usar deste xeito.
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatena literales nunha porción de cadea estática.
    ///
    /// Esta macro leva calquera número de literais separados por comas, dando unha expresión de tipo `&'static str` que representa todos os literais concatenados de esquerda a dereita.
    ///
    ///
    /// Os literales de número enteiro e de punto flotante están encordados para ser concatenados.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Expande ao número de liña no que foi invocado.
    ///
    /// Con [`column!`] e [`file!`], estas macros proporcionan información de depuración aos desenvolvedores sobre a situación dentro da fonte.
    ///
    /// A expresión expandida ten tipo `u32` e está baseada en 1, polo que a primeira liña de cada ficheiro avalía a 1, a segunda a 2, etc.
    /// Isto é coherente coas mensaxes de erro de compiladores comúns ou editores populares.
    /// A liña devolta non é necesariamente a liña da invocación `line!` en si, senón a primeira invocación de macro que leva á invocación da macro `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Expande ao número de columna ao que foi invocado.
    ///
    /// Con [`line!`] e [`file!`], estas macros proporcionan información de depuración para os desenvolvedores sobre a situación dentro da fonte.
    ///
    /// A expresión expandida ten tipo `u32` e está baseada en 1, polo que a primeira columna de cada liña avalía a 1, a segunda a 2, etc.
    /// Isto é coherente coas mensaxes de erro de compiladores comúns ou editores populares.
    /// A columna devolta non é necesariamente a liña da invocación `column!` en si, senón a primeira invocación de macro que leva á invocación da macro `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Amplíase ao nome do ficheiro no que foi invocado.
    ///
    /// Con [`line!`] e [`column!`], estas macros proporcionan información de depuración aos desenvolvedores sobre a situación dentro da fonte.
    ///
    /// A expresión expandida ten o tipo `&'static str` e o ficheiro devolto non é a invocación da macro `file!` en si, senón a primeira invocación de macro que leva á invocación da macro `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Estrutura os seus argumentos.
    ///
    /// Esta macro producirá unha expresión de tipo `&'static str` que é a encadeamento de todos os tokens pasados á macro.
    /// Non se establecen restricións na sintaxe da invocación macro.
    ///
    /// Teña en conta que os resultados ampliados da entrada tokens poden cambiar no future.Debería ter coidado se confía na saída.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Inclúe un ficheiro codificado UTF-8 como unha cadea.
    ///
    /// O ficheiro está situado en relación ao ficheiro actual (de xeito similar a como se atopan os módulos).
    /// A ruta proporcionada interprétase dunha forma específica de plataforma no momento da compilación.
    /// Así, por exemplo, unha invocación cun camiño Windows que conteña barras invertidas `\` non se compilaría correctamente en Unix.
    ///
    ///
    /// Esta macro producirá unha expresión de tipo `&'static str` que é o contido do ficheiro.
    ///
    /// # Examples
    ///
    /// Supoña que hai dous ficheiros no mesmo directorio co seguinte contido:
    ///
    /// Ficheiro 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Ficheiro 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Compilando 'main.rs' e executando o binario resultante imprimirase "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inclúe un ficheiro como referencia a unha matriz de bytes.
    ///
    /// O ficheiro está situado en relación ao ficheiro actual (de xeito similar a como se atopan os módulos).
    /// A ruta proporcionada interprétase dunha forma específica de plataforma no momento da compilación.
    /// Así, por exemplo, unha invocación cun camiño Windows que conteña barras invertidas `\` non se compilaría correctamente en Unix.
    ///
    ///
    /// Esta macro producirá unha expresión de tipo `&'static [u8; N]` que é o contido do ficheiro.
    ///
    /// # Examples
    ///
    /// Supoña que hai dous ficheiros no mesmo directorio co seguinte contido:
    ///
    /// Ficheiro 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Ficheiro 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Compilando 'main.rs' e executando o binario resultante imprimirase "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Amplíase a unha cadea que representa a ruta actual do módulo.
    ///
    /// A ruta actual do módulo pódese considerar como a xerarquía dos módulos que remontan ao crate root.
    /// O primeiro compoñente do camiño devolto é o nome do crate que se está a compilar actualmente.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Avalía combinacións booleanas de bandeiras de configuración no tempo de compilación.
    ///
    /// Ademais do atributo `#[cfg]`, esta macro fornécese para permitir a avaliación da expresión booleana das bandeiras de configuración.
    /// Con frecuencia isto leva a un código menos duplicado.
    ///
    /// A sintaxe dada a esta macro é a mesma sintaxe que o atributo [`cfg`].
    ///
    /// `cfg!`, a diferenza de `#[cfg]`, non elimina ningún código e só avalía como verdadeiro ou falso.
    /// Por exemplo, todos os bloques dunha expresión if/else deben ser válidos cando se usa `cfg!` para a condición, independentemente do que estea a avaliar `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Analiza un ficheiro como expresión ou elemento segundo o contexto.
    ///
    /// O ficheiro está situado en relación ao ficheiro actual (de xeito similar a como se atopan os módulos).A ruta proporcionada interprétase dunha forma específica de plataforma no momento da compilación.
    /// Así, por exemplo, unha invocación cun camiño Windows que conteña barras invertidas `\` non se compilaría correctamente en Unix.
    ///
    /// Usar esta macro adoita ser unha mala idea, porque se o ficheiro se analiza como unha expresión, colocarase no código circundante de forma hixiénica.
    /// Isto pode provocar que as variables ou funcións sexan diferentes do que esperaba o ficheiro se hai variables ou funcións que teñen o mesmo nome no ficheiro actual.
    ///
    ///
    /// # Examples
    ///
    /// Supoña que hai dous ficheiros no mesmo directorio co seguinte contido:
    ///
    /// Ficheiro 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Ficheiro 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Compilando 'main.rs' e executando o binario resultante imprimirase "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Afirma que unha expresión booleana é `true` no tempo de execución.
    ///
    /// Isto invocará a macro [`panic!`] se a expresión proporcionada non se pode avaliar a `true` no tempo de execución.
    ///
    /// # Uses
    ///
    /// As afirmacións sempre se comproban nas versións de depuración e liberación e non se poden desactivar.
    /// Consulte [`debug_assert!`] para ver as afirmacións que non están habilitadas nas versións de versión por defecto.
    ///
    /// O código non seguro pode confiar en `assert!` para aplicar invariantes en tempo de execución que, de violarse, poden provocar inseguridade.
    ///
    /// Outros casos de uso de `assert!` inclúen probar e aplicar os invariantes en tempo de execución en código seguro (cuxa violación non pode provocar seguridade).
    ///
    ///
    /// # Mensaxes personalizadas
    ///
    /// Esta macro ten un segundo formulario, onde se pode proporcionar unha mensaxe panic personalizada con ou sen argumentos para formatar.
    /// Vexa [`std::fmt`] para a sintaxe deste formulario.
    /// As expresións empregadas como argumentos de formato só se avaliarán se falla a afirmación.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // a mensaxe panic para estas afirmacións é o valor en cadea da expresión dada.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // unha función moi sinxela
    ///
    /// assert!(some_computation());
    ///
    /// // afirmar cunha mensaxe personalizada
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Montaxe en liña.
    ///
    /// Lea o [unstable book] para o seu uso.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Montaxe en liña ao estilo LLVM.
    ///
    /// Lea o [unstable book] para o seu uso.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Montaxe en liña a nivel de módulo.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// As impresións pasaron tokens á saída estándar.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Activa ou desactiva a funcionalidade de rastrexo empregada para depurar outras macros.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Macro de atributo empregada para aplicar macros derivadas.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Macro de atributo aplicada a unha función para convertela nunha proba unitaria.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Macro de atributo aplicada a unha función para convertela nunha proba de referencia.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Un detalle de implementación das macros `#[test]` e `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Macro de atributo aplicada a un estático para rexistralo como un asignador global.
    ///
    /// Vexa tamén [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Conserva o elemento ao que se aplica se a ruta pasada é accesible e elimínao doutro xeito.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Expande todos os atributos `#[cfg]` e `#[cfg_attr]` no fragmento de código ao que se aplica.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Non empregue detalles de implementación inestables do compilador `rustc`.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Non empregue detalles de implementación inestables do compilador `rustc`.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}