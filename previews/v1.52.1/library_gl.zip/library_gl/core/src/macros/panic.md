Panics o fío actual.

Isto permite que un programa remate inmediatamente e proporciónalle comentarios ao interlocutor do programa.
`panic!` debería empregarse cando un programa alcanza un estado irrecuperable.

Esta macro é o xeito perfecto de afirmar condicións no código de exemplo e nas probas.
`panic!` está intimamente ligado ao método `unwrap` de ambas as enumeracións [`Option`][ounwrap] e [`Result`][runwrap].
Ambas implementacións chaman a `panic!` cando están configuradas en variantes [`None`] ou [`Err`].

Cando se usa `panic!()` pode especificar unha carga útil de cadea, que se constrúe usando a sintaxe [`format!`].
Esa carga utilízase cando se inxecta o panic no fío Rust chamante, o que fai que o fío sexa completamente panic.

O comportamento do `std` hook predeterminado, é dicir
o código que se executa directamente despois de invocar o panic é imprimir a carga útil da mensaxe a `stderr` xunto coa información file/line/column da chamada `panic!()`.

Podes substituír o panic hook usando [`std::panic::set_hook()`].
No hook pódese acceder a un panic como un `&dyn Any + Send`, que contén un `&str` ou `String` para invocacións `panic!()` regulares.
Para panic cun valor doutro tipo, pódese usar [`panic_any`].

[`Result`] enum é a miúdo unha mellor solución para recuperarse de erros que usar a macro `panic!`.
Esta macro debería usarse para evitar continuar usando valores incorrectos, como de fontes externas.
[book] atopa información detallada sobre o manexo de erros.

Vexa tamén a macro [`compile_error!`] para obter erros durante a compilación.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Implementación actual

Se o fío principal panics rematará todos os teus fíos e rematará o teu programa co código `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





