//! API de asignación de memoria

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// O erro `AllocError` indica un fallo na asignación que pode deberse ao esgotamento dos recursos ou a algo incorrecto ao combinar os argumentos de entrada dados con este asignador.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (Necesitamos isto para a implementación descendente do erro trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Unha implementación de `Allocator` pode asignar, medrar, reducir e repartir bloques arbitrarios de datos descritos a través de [`Layout`][].
///
/// `Allocator` está deseñado para ser implementado en ZST, referencias ou punteiros intelixentes porque ter un asignador como `MyAlloc([u8; N])` non se pode mover sen actualizar os punteiros á memoria asignada.
///
/// A diferenza de [`GlobalAlloc`][], permítense asignacións de tamaño cero en `Allocator`.
/// Se un asignador subxacente non admite isto (como jemalloc) ou devolve un punteiro nulo (como `libc::malloc`), a implementación debe capturalo.
///
/// ### Memoria asignada actualmente
///
/// Algúns dos métodos requiren que un bloque de memoria estea *actualmente asignado* a través dun asignador.Isto significa que:
///
/// * [`allocate`], [`grow`] ou [`shrink`] devolvían previamente o enderezo inicial dese bloque de memoria e
///
/// * o bloque de memoria non se deslocalizou posteriormente, onde os bloques se deslocalizan directamente ao pasar a [`deallocate`] ou cambiaron ao pasar a [`grow`] ou [`shrink`] que devolve `Ok`.
///
/// Se `grow` ou `shrink` devolveron `Err`, o punteiro pasado seguirá sendo válido.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Axuste de memoria
///
/// Algúns dos métodos requiren que un deseño *se axuste* a un bloque de memoria.
/// O que significa para un deseño para "fit" un bloque de memoria significa (ou equivalentemente, para un bloque de memoria para "fit" un deseño) é que deben cumprir as seguintes condicións:
///
/// * O bloque debe asignarse co mesmo aliñamento que [`layout.align()`] e
///
/// * O [`layout.size()`] fornecido debe estar no rango `min ..= max`, onde:
///   - `min` é o tamaño do deseño usado máis recentemente para asignar o bloque e
///   - `max` é o último tamaño real devolto de [`allocate`], [`grow`] ou [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Os bloques de memoria devoltos desde un asignador deben apuntar cara a memoria válida e conservar a súa validez ata que a instancia e todos os seus clons caian
///
/// * a clonación ou o movemento do asignador non debe invalidar os bloques de memoria devoltos desde este asignador.Un asignador clonado debe comportarse como o mesmo asignador e
///
/// * calquera punteiro a un bloque de memoria que é [*currently allocated*] pode pasar a calquera outro método do asignador.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Tenta asignar un bloque de memoria.
    ///
    /// En caso de éxito, devolve un [`NonNull<[u8]>`][NonNull] que cumpre o tamaño e as garantías de aliñamento de `layout`.
    ///
    /// O bloque devolto pode ter un tamaño superior ao especificado por `layout.size()` e pode ou non ter inicializado o seu contido.
    ///
    /// # Errors
    ///
    /// A devolución de `Err` indica que a memoria está esgotada ou que `layout` non cumpre coas restricións de tamaño ou aliñamento do asignador.
    ///
    /// Anímase ás implementacións a devolver `Err` por esgotamento da memoria en lugar de entrar en pánico ou abortar, pero este non é un requisito estrito.
    /// (En concreto: é *legal* implementar este trait encima dunha biblioteca de asignación nativa subxacente que aborta ao esgotar a memoria.)
    ///
    /// Anímase aos clientes que desexen abortar o cálculo en resposta a un erro de asignación a chamar á función [`handle_alloc_error`], en lugar de invocar directamente `panic!` ou similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Comportase como `allocate`, pero tamén garante que a memoria devolta sexa inicializada cero.
    ///
    /// # Errors
    ///
    /// A devolución de `Err` indica que a memoria está esgotada ou que `layout` non cumpre coas restricións de tamaño ou aliñamento do asignador.
    ///
    /// Anímase ás implementacións a devolver `Err` por esgotamento da memoria en lugar de entrar en pánico ou abortar, pero este non é un requisito estrito.
    /// (En concreto: é *legal* implementar este trait encima dunha biblioteca de asignación nativa subxacente que aborta ao esgotar a memoria.)
    ///
    /// Anímase aos clientes que desexen abortar o cálculo en resposta a un erro de asignación a chamar á función [`handle_alloc_error`], en lugar de invocar directamente `panic!` ou similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SEGURIDADE: `alloc` devolve un bloque de memoria válido
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Distribúe a memoria á que fai referencia `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` debe denotar un bloque de memoria [*currently allocated*] a través deste asignador e
    /// * `layout` debe [*fit*] ese bloque de memoria.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Tenta ampliar o bloque de memoria.
    ///
    /// Devolve un novo [`NonNull<[u8]>`][NonNull] que contén un punteiro e o tamaño real da memoria asignada.O punteiro é adecuado para almacenar os datos descritos por `new_layout`.
    /// Para conseguilo, o asignador pode ampliar a asignación referenciada por `ptr` para axustala ao novo deseño.
    ///
    /// Se devolve `Ok`, a propiedade do bloque de memoria referenciado por `ptr` transferiuse a este asignador.
    /// É posible que a memoria se liberase ou non e debería considerarse inutilizable a menos que se volvese a transferir ao interlocutor mediante o valor de devolución deste método.
    ///
    /// Se este método devolve `Err`, a propiedade do bloque de memoria non se transferiu a este asignador e o contido do bloque de memoria non se alterará.
    ///
    /// # Safety
    ///
    /// * `ptr` debe denotar un bloque de memoria [*currently allocated*] a través deste asignador.
    /// * `old_layout` debe [*fit*] ese bloque de memoria (o argumento `new_layout` non ten por que encaixalo).
    /// * `new_layout.size()` debe ser maior ou igual a `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Devolve `Err` se o novo deseño non cumpre coas restricións de aliñamento ou tamaño do asignador do asignador, ou se falla crecer doutro xeito.
    ///
    /// Anímase ás implementacións a devolver `Err` por esgotamento da memoria en lugar de entrar en pánico ou abortar, pero este non é un requisito estrito.
    /// (En concreto: é *legal* implementar este trait encima dunha biblioteca de asignación nativa subxacente que aborta ao esgotar a memoria.)
    ///
    /// Anímase aos clientes que desexen abortar o cálculo en resposta a un erro de asignación a chamar á función [`handle_alloc_error`], en lugar de invocar directamente `panic!` ou similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SEGURIDADE: porque `new_layout.size()` debe ser maior ou igual a
        // `old_layout.size()`, tanto a antiga como a nova asignación de memoria son válidas para lecturas e escrituras para bytes `old_layout.size()`.
        // Ademais, debido a que a antiga asignación aínda non estaba repartida, non pode superpoñerse a `new_ptr`.
        // Así, a chamada a `copy_nonoverlapping` é segura.
        // O interlocutor debe confirmar o contrato de seguridade para `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Comportase como `grow`, pero tamén garante que os novos contidos se poñan a cero antes de devolvelos.
    ///
    /// O bloque de memoria conterá o seguinte contido despois dunha chamada exitosa a
    /// `grow_zeroed`:
    ///   * Os bytes `0..old_layout.size()` consérvanse da asignación orixinal.
    ///   * Os bytes `old_layout.size()..old_size` conservaranse ou cero, dependendo da implementación do asignador.
    ///   `old_size` refírese ao tamaño do bloque de memoria anterior á chamada `grow_zeroed`, que pode ser maior que o tamaño que se solicitou orixinalmente cando se asignou.
    ///   * Os bytes `old_size..new_size` cero.`new_size` refírese ao tamaño do bloque de memoria devolto pola chamada `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` debe denotar un bloque de memoria [*currently allocated*] a través deste asignador.
    /// * `old_layout` debe [*fit*] ese bloque de memoria (o argumento `new_layout` non ten por que encaixalo).
    /// * `new_layout.size()` debe ser maior ou igual a `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Devolve `Err` se o novo deseño non cumpre coas restricións de aliñamento ou tamaño do asignador do asignador, ou se falla crecer doutro xeito.
    ///
    /// Anímase ás implementacións a devolver `Err` por esgotamento da memoria en lugar de entrar en pánico ou abortar, pero este non é un requisito estrito.
    /// (En concreto: é *legal* implementar este trait encima dunha biblioteca de asignación nativa subxacente que aborta ao esgotar a memoria.)
    ///
    /// Anímase aos clientes que desexen abortar o cálculo en resposta a un erro de asignación a chamar á función [`handle_alloc_error`], en lugar de invocar directamente `panic!` ou similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SEGURIDADE: porque `new_layout.size()` debe ser maior ou igual a
        // `old_layout.size()`, tanto a antiga como a nova asignación de memoria son válidas para lecturas e escrituras para bytes `old_layout.size()`.
        // Ademais, debido a que a antiga asignación aínda non estaba repartida, non pode superpoñerse a `new_ptr`.
        // Así, a chamada a `copy_nonoverlapping` é segura.
        // O interlocutor debe confirmar o contrato de seguridade para `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Tenta reducir o bloque de memoria.
    ///
    /// Devolve un novo [`NonNull<[u8]>`][NonNull] que contén un punteiro e o tamaño real da memoria asignada.O punteiro é adecuado para almacenar os datos descritos por `new_layout`.
    /// Para conseguilo, o asignador pode reducir a asignación referenciada por `ptr` para axustala ao novo deseño.
    ///
    /// Se devolve `Ok`, a propiedade do bloque de memoria referenciado por `ptr` transferiuse a este asignador.
    /// É posible que a memoria se liberase ou non e debería considerarse inutilizable a menos que se volvese a transferir ao interlocutor mediante o valor de devolución deste método.
    ///
    /// Se este método devolve `Err`, a propiedade do bloque de memoria non se transferiu a este asignador e o contido do bloque de memoria non se alterará.
    ///
    /// # Safety
    ///
    /// * `ptr` debe denotar un bloque de memoria [*currently allocated*] a través deste asignador.
    /// * `old_layout` debe [*fit*] ese bloque de memoria (o argumento `new_layout` non ten por que encaixalo).
    /// * `new_layout.size()` debe ser menor ou igual a `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Devolve `Err` se o novo deseño non cumpre coas restricións de aliñamento ou tamaño do asignador do asignador ou se falla a contracción.
    ///
    /// Anímase ás implementacións a devolver `Err` por esgotamento da memoria en lugar de entrar en pánico ou abortar, pero este non é un requisito estrito.
    /// (En concreto: é *legal* implementar este trait encima dunha biblioteca de asignación nativa subxacente que aborta ao esgotar a memoria.)
    ///
    /// Anímase aos clientes que desexen abortar o cálculo en resposta a un erro de asignación a chamar á función [`handle_alloc_error`], en lugar de invocar directamente `panic!` ou similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SEGURIDADE: porque `new_layout.size()` debe ser inferior ou igual a
        // `old_layout.size()`, tanto a antiga como a nova asignación de memoria son válidas para lecturas e escrituras para bytes `new_layout.size()`.
        // Ademais, debido a que a antiga asignación aínda non estaba repartida, non pode superpoñerse a `new_ptr`.
        // Así, a chamada a `copy_nonoverlapping` é segura.
        // O interlocutor debe confirmar o contrato de seguridade para `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Crea un adaptador "by reference" para esta instancia de `Allocator`.
    ///
    /// O adaptador devolto tamén implementa `Allocator` e simplemente pedirá isto en préstamo.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SEGURIDADE: o contratante deberá confirmar o contrato de seguridade
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURIDADE: o contratante deberá confirmar o contrato de seguridade
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURIDADE: o contratante deberá confirmar o contrato de seguridade
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURIDADE: o contratante deberá confirmar o contrato de seguridade
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}