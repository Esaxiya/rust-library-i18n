use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Aínda que esta función se emprega nun só lugar e a súa implementación podería estar subliñada, os intentos anteriores de facelo fixeron rustc máis lento:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Deseño dun bloque de memoria.
///
/// Unha instancia de `Layout` describe un deseño particular de memoria.
/// Crea un `Layout` como entrada para entregar a un asignador.
///
/// Todos os deseños teñen un tamaño asociado e un aliñamento de potencia de dous.
///
/// (Teña en conta que os esquemas *non* son necesarios para ter un tamaño diferente de cero, aínda que `GlobalAlloc` require que todas as solicitudes de memoria sexan de tamaño diferente de cero.
/// Un interlocutor debe asegurarse de que se cumpren condicións coma esta, empregar asignadores específicos con requisitos máis soltos ou empregar a interface `Allocator` máis suave.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // tamaño do bloque de memoria solicitado, medido en bytes.
    size_: usize,

    // aliñamento do bloque de memoria solicitado, medido en bytes.
    // aseguramos que isto sempre é un poder de dous, porque as API como `posix_memalign` o requiren e é unha restrición razoable impoñer aos construtores de deseño.
    //
    //
    // (Non obstante, non requirimos de xeito análogo `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Constrúe un `Layout` a partir dun `size` e `align` dado, ou devolve `LayoutError` se non se cumpre algunha das seguintes condicións:
    ///
    /// * `align` non debe ser cero,
    ///
    /// * `align` debe ser unha potencia de dous,
    ///
    /// * `size`, cando se redondea ao múltiplo máis próximo de `align`, non debe desbordarse (é dicir, o valor redondeado debe ser menor ou igual a `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (a potencia de dous implica aliñar!=0.)

        // O tamaño redondeado é:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Sabemos desde arriba que aliñamos!=0.
        // Se engadir (aliñar, 1) non desborda, o redondeo cara arriba estará ben.
        //
        // Pola contra,&-masking con! (Align, 1) só restará bits de orde baixa.
        // Así, se se produce un desbordamento coa suma, a máscara&non pode restar o suficiente para desfacer ese desbordamento.
        //
        //
        // Arriba implica que a comprobación do desbordamento da suma é necesaria e suficiente.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SEGURIDADE: as condicións para `from_size_align_unchecked` foron
        // comprobado arriba.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Crea un deseño, ignorando todas as comprobacións.
    ///
    /// # Safety
    ///
    /// Esta función non é segura xa que non verifica as condicións previas de [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SEGURIDADE: o interlocutor debe asegurarse de que `align` sexa maior que cero.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// O tamaño mínimo en bytes para un bloque de memoria deste deseño.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// O aliñamento mínimo de bytes para un bloque de memoria deste deseño.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Constrúe un `Layout` adecuado para manter un valor do tipo `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SEGURIDADE: o aliñamento está garantido por Rust para ser unha potencia de dous e
        // o combo tamaño + aliñar está garantido para caber no noso espazo de enderezos.
        // Como resultado, use o constructor sen comprobar aquí para evitar inserir código que panics se non está optimizado o suficientemente ben.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produce un deseño que describe un rexistro que se podería empregar para asignar estrutura de respaldo para `T` (que podería ser un trait ou outro tipo sen tamaño como unha porción).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SEGURIDADE: vexa o fundamento en `new` para saber por que está a usar a variante non segura
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produce un deseño que describe un rexistro que se podería empregar para asignar estrutura de respaldo para `T` (que podería ser un trait ou outro tipo sen tamaño como unha porción).
    ///
    /// # Safety
    ///
    /// Esta función só se pode chamar con seguridade se se cumpren as seguintes condicións:
    ///
    /// - Se `T` é `Sized`, sempre se pode chamar con seguridade a esta función.
    /// - Se a cola sen tamaño de `T` é:
    ///     - un [slice], entón a lonxitude da cola da porción debe ser un número enteiro inicializado e o tamaño do *valor enteiro*(lonxitude da cola dinámica + prefixo de tamaño estático) debe caber en `isize`.
    ///     - un [trait object], entón a parte vtable do punteiro debe apuntar a unha vtable válida para o tipo `T` adquirida por unha coersión sen dimensionar e o tamaño do *valor enteiro*(lonxitude da cola dinámica + prefixo de tamaño estático) debe caber en `isize`.
    ///
    ///     - un (unstable) [extern type], entón esta función é sempre segura para chamar, pero pode que panic ou outra volta devolva o valor incorrecto, xa que non se coñece o deseño do tipo externo.
    ///     Este é o mesmo comportamento que [`Layout::for_value`] nunha referencia a unha cola de tipo externo.
    ///     - se non, non se pode conservar esta función.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SEGURIDADE: transmitimos os requisitos previos destas funcións ao interlocutor
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SEGURIDADE: vexa o fundamento en `new` para saber por que está a usar a variante non segura
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Crea un `NonNull` colgante, pero ben aliñado para este deseño.
    ///
    /// Teña en conta que o valor do punteiro pode representar potencialmente un punteiro válido, o que significa que non se debe empregar como valor centinela "not yet initialized".
    /// Os tipos que asignan preguiceiramente deben rastrexar a inicialización por outros medios.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SEGURIDADE: o aliñamento está garantido para ser diferente de cero
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Crea un deseño que describe o rexistro que pode ter un valor do mesmo deseño que `self`, pero que tamén está aliñado co aliñamento `align` (medido en bytes).
    ///
    ///
    /// Se `self` xa cumpre coa aliñación prescrita, devolve `self`.
    ///
    /// Teña en conta que este método non engade ningún recheo ao tamaño total, independentemente de que o deseño devolto teña un aliñamento diferente.
    /// Noutras palabras, se `K` ten o tamaño 16, `K.align_to(32)`*aínda* terá o tamaño 16.
    ///
    /// Devolve un erro se a combinación de `self.size()` e `align` dada viola as condicións listadas en [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Devolve a cantidade de recheo que debemos inserir despois de `self` para asegurarnos de que o seguinte enderezo satisfai `align` (medido en bytes).
    ///
    /// por exemplo, se `self.size()` é 9, entón `self.padding_needed_for(4)` devolve 3, porque ese é o número mínimo de bytes de recheo necesario para obter un enderezo de 4 aliñados (supoñendo que o bloque de memoria correspondente comeza nun enderezo de 4 aliñados).
    ///
    ///
    /// O valor devolto desta función non ten significado se `align` non é unha potencia de dous.
    ///
    /// Teña en conta que a utilidade do valor devolto require que `align` sexa menor ou igual ao aliñamento do enderezo inicial para todo o bloque de memoria asignado.Un xeito de satisfacer esta restrición é asegurando `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // O valor redondeado é:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // e despois devolvemos a diferenza de recheo: `len_rounded_up - len`.
        //
        // Usamos aritmética modular en todo:
        //
        // 1. o aliñamento está garantido> 0, polo que o aliñamento 1 sempre é válido.
        //
        // 2.
        // `len + align - 1` pode desbordarse como máximo por `align - 1`, polo que a máscara&con `!(align - 1)` asegurará que no caso de desbordamento, `len_rounded_up` será en si mesmo 0.
        //
        //    Así, o recheo devolto, cando se engade a `len`, produce 0, o que satisfai trivialmente o aliñamento `align`.
        //
        // (Por suposto, os intentos de asignar bloques de memoria cuxo tamaño e desbordamento de recheo do xeito anterior deberían facer que o asignador cometa un erro de todos os xeitos).
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Crea un deseño redondeando o tamaño deste deseño ata un múltiplo da aliñación do deseño.
    ///
    ///
    /// Isto equivale a engadir o resultado de `padding_needed_for` ao tamaño actual do deseño.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Isto non pode desbordarse.Citando o invariante do deseño:
        // > `size`, cando se redondea ao múltiplo máis próximo de `align`,
        // > non debe desbordarse (é dicir, o valor redondeado debe ser inferior a
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Crea un deseño que describe o rexistro de instancias `n` de `self`, cunha cantidade adecuada de recheo entre cada unha para garantir que cada instancia reciba o seu tamaño e aliñamento solicitados.
    /// En caso de éxito, devolve `(k, offs)` onde `k` é o deseño da matriz e `offs` é a distancia entre o inicio de cada elemento da matriz.
    ///
    /// En caso de desbordamento aritmético, devolve `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Isto non pode desbordarse.Citando o invariante do deseño:
        // > `size`, cando se redondea ao múltiplo máis próximo de `align`,
        // > non debe desbordarse (é dicir, o valor redondeado debe ser inferior a
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SEGURIDADE: xa se sabe que self.align é válido e o ten alloc_size
        // acolchado xa.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Crea un deseño que describe o rexistro de `self` seguido de `next`, incluíndo calquera recheo necesario para garantir que `next` estea correctamente aliñado, pero *sen recheo final*.
    ///
    /// Para coincidir co deseño de representación C `repr(C)`, debería chamar ao `pad_to_align` despois de ampliar o deseño con todos os campos.
    /// (Non hai ningunha forma de coincidir co deseño de representación Rust predeterminado `repr(Rust)`, as it is unspecified.)
    ///
    /// Teña en conta que o aliñamento do deseño resultante será o máximo dos de `self` e `next`, co fin de garantir o aliñamento de ambas as partes.
    ///
    /// Devolve `Ok((k, offset))`, onde `k` é o deseño do rexistro concatenado e `offset` é a situación relativa, en bytes, do inicio do `next` incrustado dentro do rexistro concatenado (supoñendo que o rexistro en si comeza no offset 0).
    ///
    ///
    /// En caso de desbordamento aritmético, devolve `LayoutError`.
    ///
    /// # Examples
    ///
    /// Para calcular o deseño dunha estrutura `#[repr(C)]` e as compensacións dos campos a partir dos deseños dos seus campos:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Lembre finalizar con `pad_to_align`.
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // proba que funciona
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Crea un deseño que describe o rexistro de instancias `n` de `self`, sen relleno entre cada instancia.
    ///
    /// Teña en conta que, a diferenza de `repeat`, `repeat_packed` non garante que as instancias repetidas de `self` estean correctamente aliñadas, aínda que unha instancia determinada de `self` estea correctamente aliñada.
    /// Noutras palabras, se o deseño devolto por `repeat_packed` se usa para asignar unha matriz, non se garante que todos os elementos da matriz estean aliñados correctamente.
    ///
    /// En caso de desbordamento aritmético, devolve `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Crea un deseño que describe o rexistro para `self` seguido de `next` sen recheo adicional entre os dous.
    /// Como non se inseriu ningún recheo, o aliñamento de `next` é irrelevante e non se incorpora *en absoluto* ao deseño resultante.
    ///
    ///
    /// En caso de desbordamento aritmético, devolve `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Crea un deseño que describe o rexistro dun `[T; n]`.
    ///
    /// En caso de desbordamento aritmético, devolve `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Os parámetros dados a `Layout::from_size_align` ou algún outro construtor `Layout` non cumpren as súas restricións documentadas.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (Necesitamos isto para a implementación descendente do erro trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}