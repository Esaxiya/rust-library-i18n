use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Un asignador de memoria que se pode rexistrar como predeterminado da biblioteca estándar a través do atributo `#[global_allocator]`.
///
/// Algúns dos métodos requiren que un bloque de memoria estea *actualmente asignado* a través dun asignador.Isto significa que:
///
/// * o enderezo inicial dese bloque de memoria foi devolto previamente por unha chamada anterior a un método de asignación como `alloc` e
///
/// * o bloque de memoria non se deslocalizou posteriormente, onde os bloques se deslocalizan xa se pasan a un método de deslocalización como `dealloc` ou se pasan a un método de reasignación que devolve un punteiro non nulo.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// O `GlobalAlloc` trait é un `unsafe` trait por varias razóns e os implementadores deben asegurarse de cumprir estes contratos:
///
/// * É un comportamento indefinido se os asignadores globais se desconectan.Esta restrición pode eliminarse no future, pero actualmente un panic de calquera destas funcións pode provocar seguridade na memoria.
///
/// * `Layout` as consultas e cálculos en xeral deben ser correctos.Os chamadores deste trait poden confiar nos contratos definidos en cada método e os implementadores deben asegurarse de que eses contratos sexan certos.
///
/// * Pode non confiar en que as asignacións estean a ocorrer, aínda que haxa asignacións de montón explícitas na fonte.
/// O optimizador pode detectar as asignacións non utilizadas que pode eliminar por completo ou moverse á pila e, polo tanto, nunca invocar o asignador.
/// O optimizador pode asumir ademais que a asignación é infalible, polo que o código que antes fallaba debido a fallos do asignador pode funcionar de súpeto porque o optimizador traballou en torno á necesidade dunha asignación.
/// Máis concretamente, o seguinte exemplo de código non é válido, independentemente de que o seu asignador personalizado permita contar cantas asignacións sucederon.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Teña en conta que as optimizacións mencionadas anteriormente non son a única que se pode aplicar.Xeralmente pode non confiar en que se produzan asignacións de pila se se poden eliminar sen cambiar o comportamento do programa.
///   Se as asignacións ocorren ou non non forma parte do comportamento do programa, aínda que podería ser detectado a través dun asignador que rastrexa as asignacións imprimíndose ou tendo efectos secundarios.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Asigne memoria como se describe no `layout` indicado.
    ///
    /// Devolve un punteiro á memoria recentemente asignada ou nulo para indicar un fallo na asignación.
    ///
    /// # Safety
    ///
    /// Esta función non é segura porque pode producirse un comportamento indefinido se o interlocutor non garante que o `layout` teña un tamaño diferente de cero.
    ///
    /// (Os subtraits de extensión poden proporcionar límites máis específicos no comportamento, por exemplo, garantir un enderezo de centinela ou un punteiro nulo en resposta a unha solicitude de asignación de tamaño cero.)
    ///
    /// O bloque de memoria asignado pode ou non ser inicializado.
    ///
    /// # Errors
    ///
    /// Devolver un punteiro nulo indica que a memoria está esgotada ou o `layout` non cumpre coas restricións de tamaño ou aliñamento deste asignador.
    ///
    /// Recoméndase ás implementacións que devolvan o valor nulo ao esgotar a memoria en lugar de abortar, pero este non é un requisito estrito.
    /// (En concreto: é *legal* implementar este trait encima dunha biblioteca de asignación nativa subxacente que aborta ao esgotar a memoria.)
    ///
    /// Anímase aos clientes que desexen abortar o cálculo en resposta a un erro de asignación a chamar á función [`handle_alloc_error`], en lugar de invocar directamente `panic!` ou similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Distribúe de novo o bloque de memoria no punteiro `ptr` dado co `layout` dado.
    ///
    /// # Safety
    ///
    /// Esta función non é segura porque pode producirse un comportamento indefinido se o interlocutor non garante todo o seguinte:
    ///
    ///
    /// * `ptr` debe denotar un bloque de memoria actualmente asignado a través deste asignador,
    ///
    /// * `layout` debe ser o mesmo deseño que se usou para asignar ese bloque de memoria.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Comportase como `alloc`, pero tamén garante que o contido se axuste a cero antes de devolvelo.
    ///
    /// # Safety
    ///
    /// Esta función non é segura polos mesmos motivos que o `alloc`.
    /// Non obstante, o bloque de memoria asignado está garantido para ser inicializado.
    ///
    /// # Errors
    ///
    /// Devolver un punteiro nulo indica que a memoria está esgotada ou que `layout` non cumpre coas restricións de tamaño ou aliñamento do asignador, igual que en `alloc`.
    ///
    /// Anímase aos clientes que desexen abortar o cálculo en resposta a un erro de asignación a chamar á función [`handle_alloc_error`], en lugar de invocar directamente `panic!` ou similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SEGURIDADE: o contratante de seguridade para `alloc` debe ser confirmado polo interlocutor.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SEGURIDADE: a asignación tivo éxito, a rexión desde `ptr`
            // de tamaño `size` está garantido para ser válido para escrituras.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Reduce ou fai medrar un bloque de memoria ata o `new_size` dado.
    /// O bloque descríbese co punteiro `ptr` e `layout` indicados.
    ///
    /// Se devolve un punteiro non nulo, a propiedade do bloque de memoria referenciado por `ptr` transferiuse a este asignador.
    /// É posible que a memoria se deslocalizase ou non e debería considerarse inutilizable (a non ser que, por suposto, volvese transferir ao interlocutor mediante o valor de devolución deste método).
    /// O novo bloque de memoria está asignado con `layout`, pero co `size` actualizado a `new_size`.
    /// Este novo deseño debería empregarse cando se deslocalice o novo bloque de memoria con `dealloc`.
    /// O rango `0..min(layout.size(), new_size) "do novo bloque de memoria está garantido para ter os mesmos valores que o bloque orixinal.
    ///
    /// Se este método devolve nulo, a propiedade do bloque de memoria non se transferiu a este asignador e o contido do bloque de memoria non se alterará.
    ///
    /// # Safety
    ///
    /// Esta función non é segura porque pode producirse un comportamento indefinido se o interlocutor non garante todo o seguinte:
    ///
    /// * `ptr` debe asignarse actualmente a través deste asignador,
    ///
    /// * `layout` debe ser o mesmo deseño que se usou para asignar ese bloque de memoria,
    ///
    /// * `new_size` debe ser maior que cero.
    ///
    /// * `new_size`, cando se redondea ao múltiplo máis próximo de `layout.align()`, non debe desbordarse (é dicir, o valor redondeado debe ser inferior a `usize::MAX`).
    ///
    /// (Os subtraits de extensión poden proporcionar límites máis específicos no comportamento, por exemplo, garantir un enderezo de centinela ou un punteiro nulo en resposta a unha solicitude de asignación de tamaño cero.)
    ///
    /// # Errors
    ///
    /// Devolve nulo se o novo deseño non cumpre coas restricións de tamaño e aliñamento do asignador ou se falla a reasignación.
    ///
    /// Recoméndase ás implementacións que devolvan o esgotamento da memoria en lugar de entrar en pánico ou abortar, pero este non é un requisito estrito.
    /// (En concreto: é *legal* implementar este trait encima dunha biblioteca de asignación nativa subxacente que aborta ao esgotar a memoria.)
    ///
    /// Anímase aos clientes que desexen abortar o cálculo en resposta a un erro de reasignación a chamar á función [`handle_alloc_error`], en lugar de invocar directamente `panic!` ou similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SEGURIDADE: o interlocutor debe asegurarse de que o `new_size` non reborda.
        // `layout.align()` vén dun `Layout` e, polo tanto, está garantido que é válido.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SEGURIDADE: o interlocutor debe asegurarse de que `new_layout` sexa maior que cero.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SEGURIDADE: o bloque asignado anteriormente non pode superpoñerse ao bloque recentemente asignado.
            // O interlocutor debe confirmar o contrato de seguridade para `dealloc`.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}