//! Implantación de Rust panics mediante proceso de interrupción
//!
//! En comparación coa implementación mediante desenrolo, este crate é * moito máis sinxelo.Dito isto, non é tan versátil, pero aquí vai.
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" a carga útil e a cota ao aborto correspondente na plataforma en cuestión.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // chama ao std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // En Windows, use o mecanismo __fastfail específico do procesador.En Windows 8 e posteriores, isto rematará o proceso inmediatamente sen executar ningún controlador de excepcións dentro do proceso.
            // Nas versións anteriores de Windows, esta secuencia de instrucións tratarase como unha violación de acceso, dando por finalizado o proceso pero sen ignorar necesariamente todos os controladores de excepcións.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: esta é a mesma implementación que no `abort_internal` de libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Isto ... é un pouco raro.O tl; dr;é que isto é necesario para ligar correctamente, a explicación máis longa está a continuación.
//
// Neste momento os binarios de libcore/libstd que enviamos compílanse todos con `-C panic=unwind`.Isto faise para garantir que os binarios sexan o máximo compatibles co maior número de situacións posibles.
// Non obstante, o compilador require un "personality function" para todas as funcións compiladas con `-C panic=unwind`.Esta función de personalidade está codificada co símbolo `rust_eh_personality` e está definida polo elemento lang `eh_personality`.
//
// So...
// por que non simplemente definir ese elemento lang aquí?Boa pregunta!A forma en que se ligan os tempos de execución de panic é un pouco sutil porque son "sort of" na tenda crate do compilador, pero só están realmente ligados se outro non está realmente ligado.
//
// Isto acaba significando que tanto este crate como o panic_unwind crate poden aparecer no almacén crate do compilador e, se ambos definen o elemento lang `eh_personality`, entón terá un erro.
//
// Para xestionar isto, o compilador só precisa que se defina o `eh_personality` se o tempo de execución panic no que está ligado é o tempo de execución de desenrolo, e doutro xeito non é necesario que se defina (con razón).
// Non obstante, neste caso, esta biblioteca só define este símbolo polo que hai polo menos algunha personalidade nalgures.
//
// Esencialmente, este símbolo acaba de definirse para conectarse a binarios libcore/libstd, pero nunca se debería chamar porque non enlazamos en ningún momento de execución.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // En x86_64-pc-windows-gnu usamos a nosa propia función de personalidade que precisa devolver `ExceptionContinueSearch` mentres estamos transmitindo todos os nosos cadros.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Do mesmo xeito que o anterior, isto corresponde ao elemento `eh_catch_typeinfo` lang que só se emprega en Emscripten actualmente.
    //
    // Dado que panics non xera excepcións e as excepcións foráneas son actualmente UB con -C panic=abortar (aínda que isto pode estar suxeito a cambios), as chamadas catch_unwind nunca usarán esta información de tipo.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Estes dous son chamados polos nosos obxectos de inicio en i686-pc-windows-gnu, pero non precisan facer nada polo que os corpos son nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}