#![feature(no_core)]
#![no_core]

// Vexa rustc-std-workspace-core para saber por que se precisa este crate.

// Cambie o nome do crate para evitar entrar en conflito co módulo alloc en liballoc.
extern crate alloc as foo;

pub use foo::*;