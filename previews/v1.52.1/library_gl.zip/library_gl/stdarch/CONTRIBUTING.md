# Contribuíndo a stdarch

O `stdarch` crate está máis que disposto a aceptar contribucións.Primeiro probablemente quererá consultar o repositorio e asegurarse de que as probas pasan por vostede:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Onde `<your-target-arch>` é o triplo de destino utilizado por `rustup`, por exemplo, `x86_x64-unknown-linux-gnu` (sen ningún `nightly-` anterior ou similar).
Lembre tamén que este repositorio require a canle nocturna de Rust.
As probas anteriores requiren, de feito, que rust nocturno sexa o predeterminado no seu sistema, para configurar o uso de `rustup default nightly` (e `rustup default stable` para volver).

Se algún dos pasos anteriores non funciona, [please let us know][new]!

A continuación podes axudar [find an issue][issues], seleccionamos algúns cos etiquetas [`help wanted`][help] e [`impl-period`][impl] que poderían axudar especialmente. 
Quizais estea máis interesado en [#40][vendor], implementando todos os intrínsecos do provedor en x86.Ese número ten algúns indicadores bos sobre onde comezar.

Se tes preguntas xerais, non dubides en [join us on gitter][gitter] e faino.Non dubide en facer ping a@BurntSushi ou@alexcrichton con preguntas.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Como escribir exemplos para intrínsecos de stdarch

Hai algunhas funcións que deben estar habilitadas para que o intrínseco dado funcione correctamente e o exemplo só debe ser executado por `cargo test --doc` cando a función sexa compatible coa CPU.

Como resultado, o `fn main` predeterminado que xera `rustdoc` non funcionará (na maioría dos casos).
Considere usar o seguinte como guía para garantir que o seu exemplo funciona como se esperaba.

```rust
/// # // Necesitamos cfg_target_feature para garantir que o exemplo só o sexa
/// # // executado por `cargo test --doc` cando a CPU admite a función
/// # #![feature(cfg_target_feature)]
/// # // Necesitamos un target_feature para que o intrínseco funcione
/// # #![feature(target_feature)]
/// #
/// # // rustdoc por defecto usa `extern crate stdarch`, pero necesitamos o
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // A verdadeira función principal
/// # fn main() {
/// #     // Execute isto só se admite `<target feature>`
/// #     se cfg_feature_enabled! ("<target feature>"){
/// #         // Crea unha función `worker` que só se executará se a función de destino
/// #         // é compatible e asegúrese de que `target_feature` estea habilitado para o seu traballador
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         fn worker() inseguro {
/// // Escribe aquí o teu exemplo.As funcións intrínsecas específicas funcionarán aquí.Vai salvaxe!
///
/// #         }
///
/// #         { worker(); } non seguro
/// #     }
/// # }
```

Se algunha das sintaxes anteriores non parece familiar, a sección [Documentation as tests] do [Rust Book] describe bastante ben a sintaxe `rustdoc`.
Como sempre, non dubides en [join us on gitter][gitter] e pregúntanos se atopas algún problema e grazas por axudar a mellorar a documentación de `stdarch`.

# Instrucións de proba alternativas

Xeralmente recoméndase que use `ci/run.sh` para realizar as probas.
Non obstante, pode que isto non funcione para vostede, por exemplo, se está en Windows.

Nese caso, pode volver a executar `cargo +nightly test` e `cargo +nightly test --release -p core_arch` para probar a xeración de código.
Teña en conta que estes requiren a instalación da cadea de ferramentas nocturna e que `rustc` coñeza o seu triplo de destino e a súa CPU.
En particular, ten que establecer a variable de entorno `TARGET` como faría para `ci/run.sh`.
Ademais, ten que configurar `RUSTCFLAGS` (precisa o `C`) para indicar as funcións de destino, por exemplo `RUSTCFLAGS="-C -target-features=+avx2"`.
Tamén podes configurar `-C -target-cpu=native` se estás desenvolvendo "just" coa túa CPU actual.

Teña en conta que cando usa estas instrucións alternativas, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], por exemplo
as probas de xeración de instrucións poden fallar porque o desmontador nomeounas doutro xeito, por exemplo
pode xerar instrucións `vaesenc` en lugar de `aesenc` a pesar de que se comportan igual.
Ademais, estas instrucións executan menos probas das que normalmente se farían, polo que non se estrañe de que cando finalmente solicite unha extracción pode aparecer algún erro para probas non cubertas aquí.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






