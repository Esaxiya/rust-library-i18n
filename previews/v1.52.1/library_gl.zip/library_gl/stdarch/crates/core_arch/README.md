`core::arch` - Intrínsecos específicos da arquitectura da biblioteca principal de Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

O módulo `core::arch` implementa intrínsecos dependentes da arquitectura (por exemplo, SIMD).

# Usage 

`core::arch` está dispoñible como parte de `libcore` e é reexportado por `libstd`.Prefire usalo a través de `core::arch` ou `std::arch` que a través deste crate.
As funcións inestables adoitan estar dispoñibles no Rust nocturno a través do `feature(stdsimd)`.

Usar `core::arch` a través deste crate require Rust nocturno e pode (e si) romper a miúdo.Os únicos casos nos que debería considerar o seu uso a través deste crate son:

* se precisa recompilar `core::arch` vostede mesmo, por exemplo, con características específicas activadas que non están habilitadas para `libcore`/`libstd`.
Note: se precisa recompilalo para un destino non estándar, prefire usar `xargo` e recompilar `libcore`/`libstd` segundo corresponda en lugar de usar este crate.
  
* usando algunhas funcións que quizais non estean dispoñibles, incluso detrás de funcións inestables de Rust.Tentamos que estes sexan mínimos.
Se precisas empregar algunhas destas funcións, abre un problema para que poidamos expoñelas no Rust nocturno e podelas empregar desde alí.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` distribúese principalmente baixo os termos da licenza MIT e da licenza Apache (versión 2.0), con porcións cubertas por varias licenzas tipo BSD.

Consulte LICENSE-APACHE e LICENSE-MIT para máis detalles.

# Contribution

A non ser que explique expresamente o contrario, calquera contribución enviada intencionadamente para incluílo en `core_arch`, tal e como se define na licenza Apache-2.0, terá unha licenza dobre como a anterior, sen termos ou condicións adicionais.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












