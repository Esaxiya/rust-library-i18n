use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Adoitaba dicir ás nosas anotacións `#[assert_instr]` que todos os intrínsecos simd están dispoñibles para probar o seu codegen, xa que algúns están pechados detrás dun `-Ctarget-feature=+unimplemented-simd128` adicional que non ten ningún equivalente en `#[target_feature]` neste momento.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}