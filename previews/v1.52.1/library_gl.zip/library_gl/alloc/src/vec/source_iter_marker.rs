use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Marcador de especialización para recoller un gasoduto iterador nun Vec mentres se reutiliza a asignación de orixe, é dicir
/// executando a canalización no seu lugar.
///
/// O pai SourceIter trait é necesario para que a función especializada acceda á asignación que se vai reutilizar.
/// Pero non é suficiente para que a especialización sexa válida.
/// Vexa límites adicionais no impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// O std-interno SourceIter/InPlaceIterable traits só son implementados por cadeas de adaptador <Adapter<Adapter<IntoIter>>> (todos son propiedade de core/std).
// Os límites adicionais nas implementacións de adaptadores (máis alá de `impl<I: Trait> Trait for Adapter<I>`) só dependen doutros traits xa marcados como especialización traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. o marcador non depende da vida útil dos tipos proporcionados polo usuario.Módulo o burato de copia, do que xa dependen outras especializacións.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Requisitos adicionais que non se poden expresar mediante trait bounds.En lugar diso, confiamos en const eval:
        // a) sen ZST, xa que non habería asignación para reutilizar e o aritmético do punteiro coincidiría con panic b) coincidiría co tamaño requirido polo contrato Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // alternativa a implementacións máis xenéricas
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // use try-fold desde
        // - vectorízase mellor para algúns adaptadores iteradores
        // - a diferenza da maioría dos métodos internos de iteración, só leva un auto &mut
        // - déixanos pasar o punteiro de escritura polas entrañas e recuperalo ao final
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // a iteración tivo éxito, non deixe caer a cabeza
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // comproba se o contrato SourceIter confirmouse: se non o fose, quizais nin sequera chegamos a este punto
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // comprobar Contrato InPlaceIterable.Isto só é posible se o iterador avanzou o punteiro de orixe.
        // Se usa acceso sen comprobar a través de TrustedRandomAccess, o punteiro de orixe permanecerá na súa posición inicial e non o podemos usar como referencia
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // solte os valores restantes na cola da fonte pero evite a caída da asignación en si unha vez que IntoIter sae do alcance se a caída panics entón tamén filtramos os elementos recollidos en dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // o contrato InPlaceIterable non se pode verificar con precisión aquí xa que try_fold ten unha referencia exclusiva ao punteiro de orixe o único que podemos facer é comprobar se aínda está no rango
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}