// Estableza a lonxitude do vec cando o valor `SetLenOnDrop` sae do alcance.
//
// A idea é: o campo de lonxitude en SetLenOnDrop é unha variable local que o optimizador verá non alias con ningunha tenda a través do punteiro de datos do Vec.
// Esta é unha solución para o problema de análise de alias #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}