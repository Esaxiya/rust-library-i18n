use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Un iterador que usa un peche para determinar se se debe eliminar un elemento.
///
/// Esta estrutura está creada por [`Vec::drain_filter`].
/// Vexa a súa documentación para máis información.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// O índice do elemento que será inspeccionado pola próxima chamada a `next`.
    pub(super) idx: usize,
    /// O número de elementos que se esgotaron ata agora (removed).
    pub(super) del: usize,
    /// A lonxitude orixinal de `vec` antes de escorrer.
    pub(super) old_len: usize,
    /// O predicado de proba do filtro.
    pub(super) pred: F,
    /// No predicado de proba do filtro produciuse unha bandeira que indica un panic.
    /// Isto utilízase como unha suxestión na implementación de caída para evitar o consumo do resto do `DrainFilter`.
    /// Calquera elemento non procesado volverá a ser cambiado no `vec`, pero o predicado do filtro non eliminará nin probará máis elementos.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Devolve unha referencia ao asignador subxacente.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Actualice o índice *despois de que se chame* o predicado.
                // Se o índice se actualiza previamente e o predicado panics, filtraríase o elemento deste índice.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Este é un estado bastante desordenado, e non hai realmente unha cousa obviamente correcta que facer.
                        // Non queremos seguir intentando executar `pred`, polo que só cambiamos todos os elementos sen procesar e dicímoslle ao vec que aínda existen.
                        //
                        // O retroceso é necesario para evitar unha dobre caída do último elemento drenado con éxito antes dun panic no predicado.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Tenta consumir os elementos restantes se o predicado do filtro aínda non entrou en pánico.
        // Cambiaremos de volta os elementos restantes, xa teñamos pánico ou se o consumo aquí é panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}