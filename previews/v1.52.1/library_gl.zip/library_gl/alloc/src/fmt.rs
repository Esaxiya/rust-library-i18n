//! Utilidades para formatar e imprimir `String`s.
//!
//! Este módulo contén o soporte de execución para a extensión de sintaxe [`format!`].
//! Esta macro está implementada no compilador para emitir chamadas a este módulo co fin de formatar argumentos en tempo de execución en cadeas.
//!
//! # Usage
//!
//! A macro [`format!`] está destinada a ser familiar para aqueles que proveñen das funcións X's C01X ou da función `str.format` de Python.
//!
//! Algúns exemplos da extensión [`format!`] son:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" con ceros ao principio
//! ```
//!
//! A partir destes, podes ver que o primeiro argumento é unha cadea de formato.O compilador esixe que isto sexa literal de cadea;non pode ser unha variable pasada (para realizar a comprobación da validez).
//! A continuación, o compilador analizará a cadea de formato e determinará se a lista de argumentos proporcionados é adecuada para pasar a esta cadea de formato.
//!
//! Para converter un único valor a unha cadea, use o método [`to_string`].Isto empregará o formato [`Display`] trait.
//!
//! ## Parámetros posicionais
//!
//! A cada argumento de formato permítese especificar o argumento de valor ao que fai referencia e, se se omite, suponse que é "the next argument".
//! Por exemplo, a cadea de formato `{} {} {}` tomaría tres parámetros e formataríanse na mesma orde que se indican.
//! Non obstante, a cadea de formato `{2} {1} {0}` formataría os argumentos en orde inversa.
//!
//! As cousas poden ser un pouco complicadas unha vez que comece a mesturar os dous tipos de especificadores de posición.O especificador "next argument" pode considerarse como un iterador sobre o argumento.
//! Cada vez que se ve un especificador "next argument", o iterador avanza.Isto leva a un comportamento coma este:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! O iterador interno sobre o argumento non se avanzou no momento en que se ve o primeiro `{}`, polo que imprime o primeiro argumento.Despois de chegar ao segundo `{}`, o iterador avanzou cara ao segundo argumento.
//! Esencialmente, os parámetros que nomean explícitamente o seu argumento non afectan aos parámetros que non nomean un argumento en termos de especificadores de posición.
//!
//! Requírese unha cadea de formato para usar todos os seus argumentos, se non, é un erro no tempo de compilación.Pode referirse ao mesmo argumento máis dunha vez na cadea de formato.
//!
//! ## Parámetros nomeados
//!
//! Rust en si non ten un equivalente similar a Python de parámetros nomeados a unha función, pero a macro [`format!`] é unha extensión de sintaxe que lle permite aproveitar parámetros nomeados.
//! Os parámetros nomeados están listados ao final da lista de argumentos e teñen a sintaxe:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Por exemplo, as seguintes expresións [`format!`] usan argumentos nomeados:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Non é válido poñer parámetros posicionais (os sen nomes) despois de argumentos que teñan nomes.Do mesmo xeito que cos parámetros posicionais, non é válido proporcionar parámetros nomeados que non sexan utilizados pola cadea de formato.
//!
//! # Parámetros de formato
//!
//! Cada argumento que se está formatando pode transformarse mediante unha serie de parámetros de formato (correspondentes a `format_spec` en [the syntax](#syntax)). Estes parámetros afectan á representación de cadeas do que se está formatando.
//!
//! ## Width
//!
//! ```
//! // Todos estes imprimen "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Este é un parámetro para o "minimum width" que debería tomar o formato.
//! Se a cadea do valor non enche tantos caracteres, o recheo especificado por fill/alignment empregarase para ocupar o espazo requirido (ver máis abaixo).
//!
//! O valor para o ancho tamén se pode proporcionar como [`usize`] na lista de parámetros engadindo un postfix `$`, o que indica que o segundo argumento é un [`usize`] que especifica o ancho.
//!
//! A referencia a un argumento coa sintaxe do dólar non afecta ao contador "next argument", polo que normalmente é unha boa idea referirse a argumentos por posición ou usar argumentos con nome.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! O carácter de recheo opcional e o aliñamento ofrécense normalmente xunto co parámetro [`width`](#width).Debe definirse antes do `width`, xusto despois do `:`.
//! Isto indica que se o valor que se está formatando é menor que `width`, imprimiranse algúns caracteres adicionais ao seu redor.
//! O recheo inclúe as seguintes variantes para diferentes aliñamentos:
//!
//! * `[fill]<` - o argumento está aliñado á esquerda en columnas `width`
//! * `[fill]^` - o argumento está aliñado ao centro en columnas `width`
//! * `[fill]>` - o argumento está aliñado á dereita en columnas `width`
//!
//! O [fill/alignment](#fillalignment) predeterminado para os números non é un espazo e aliñado á esquerda.O valor predeterminado para os formatos numéricos tamén é un carácter de espazo pero con aliñación á dereita.
//! Se se especifica o sinal `0` (ver máis abaixo) para os números, o carácter de recheo implícito é `0`.
//!
//! Teña en conta que é posible que algúns tipos non implementen o aliñamento.En particular, xeralmente non se implementa para o `Debug` trait.
//! Un bo xeito de asegurarse de que se aplica o recheo é formatear a entrada e, a continuación, empadronar esta cadea resultante para obter a saída:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Ola Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Estas son todas as bandeiras que alteran o comportamento do formateador.
//!
//! * `+` - Isto está pensado para tipos numéricos e indica que o signo sempre debe imprimirse.Os signos positivos nunca se imprimen por defecto e o signo negativo só se imprime por defecto para o `Signed` trait.
//! Esta marca indica que o signo correcto (`+` ou `-`) sempre debe imprimirse.
//! * `-` - Actualmente non se usa
//! * `#` - Esta marca indica que se debe empregar a forma de impresión "alternate".As formas alternativas son:
//!     * `#?` - imprime bastante o formato [`Debug`]
//!     * `#x` - precede ao argumento cun `0x`
//!     * `#X` - precede ao argumento cun `0x`
//!     * `#b` - precede ao argumento cun `0b`
//!     * `#o` - precede ao argumento cun `0o`
//! * `0` - Isto úsase para indicar para formatos enteiros que o recheo a `width` debe facerse cun carácter `0` e ser consciente de signos.
//! Un formato como `{:08}` produciría `00000001` para o enteiro `1`, mentres que o mesmo formato produciría `-0000001` para o enteiro `-1`.
//! Teña en conta que a versión negativa ten un cero menos que a versión positiva.
//!         Teña en conta que os ceros de relleno sempre se colocan despois do signo (se hai) e antes dos díxitos.Cando se usa xunto coa bandeira `#`, aplícase unha regra similar: os ceros de recheo insírense despois do prefixo pero antes dos díxitos.
//!         O prefixo inclúese no ancho total.
//!
//! ## Precision
//!
//! Para tipos non numéricos, pódese considerar un "maximum width".
//! Se a cadea resultante é maior que este ancho, entón truncarase ata moitos caracteres e ese valor truncado emítese con `fill`, `alignment` e `width` adecuados se se configuran eses parámetros.
//!
//! Para os tipos integrais, isto ignórase.
//!
//! Para os tipos de punto flotante, isto indica cantos díxitos despois do punto decimal deben imprimirse.
//!
//! Hai tres xeitos posibles de especificar o `precision` desexado:
//!
//! 1. Un número enteiro `.N`:
//!
//!    o número enteiro `N` é a precisión.
//!
//! 2. Un número enteiro ou un nome seguido do signo de dólar `.N$`:
//!
//!    use o formato *argumento*`N` (que debe ser un `usize`) como precisión.
//!
//! 3. Un asterisco `.*`:
//!
//!    `.*` significa que este `{...}` está asociado con entradas de formato *dous* en lugar dunha: a primeira entrada ten a precisión `usize` e a segunda mantén o valor para imprimir.
//!    Teña en conta que neste caso, se se usa a cadea de formato `{<arg>:<spec>.*}`, a parte `<arg>` refírese ao valor* para imprimir e o `precision` debe entrar na entrada anterior a `<arg>`.
//!
//! Por exemplo, as seguintes chamadas imprimen o mesmo `Hello x is 0.01000`:
//!
//! ```
//! // Ola {arg 0 ("x")} é {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Ola {arg 1 ("x")} é {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Ola {arg 0 ("x")} é {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Ola {next arg ("x")} é {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Ola {next arg ("x")} é {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Ola {next arg ("x")} é {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Mentres estes:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! imprima tres cousas significativamente diferentes:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Nalgunhas linguaxes de programación, o comportamento das funcións de formato de cadea depende da configuración local do sistema operativo.
//! As funcións de formato proporcionadas pola biblioteca estándar de Rust non teñen ningún concepto de configuración local e producirán os mesmos resultados en todos os sistemas independentemente da configuración do usuario.
//!
//! Por exemplo, o seguinte código sempre imprimirá `1.5` aínda que a configuración rexional do sistema use un separador decimal distinto dun punto.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Os caracteres literais `{` e `}` poden incluírse nunha cadea precedéndoos co mesmo carácter.Por exemplo, o carácter `{` escápase con `{{` e o carácter `}` escápase con `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Para resumir, aquí podes atopar a gramática completa das cadeas de formato.
//! A sintaxe da linguaxe de formato empregada está extraída doutras linguas, polo que non debería ser demasiado allea.Os argumentos están formatados cunha sintaxe similar a Python, o que significa que os argumentos están rodeados por `{}` en lugar do `%` como C.
//! A gramática real para a sintaxe de formato é:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Na gramática anterior, `text` pode non conter caracteres `'{'` ou `'}'`.
//!
//! # Formatando traits
//!
//! Ao solicitar que se formate un argumento cun tipo concreto, realmente solicita que un argumento se atribúa a un determinado trait.
//! Isto permite formatar varios tipos reais a través de `{:x}` (como [`i8`] e [`isize`]).O mapeo actual de tipos a traits é:
//!
//! * *nada* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] con números enteiros hexadecimais en minúscula
//! * `X?` ⇒ [`Debug`] con números enteiros hexadecimais en maiúscula
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! O que isto significa é que calquera tipo de argumento que implemente o [`fmt::Binary`][`Binary`] trait pode entón formatearse con `{:b}`.A biblioteca estándar fornece implementacións para estes traits para varios tipos primitivos.
//!
//! Se non se especifica ningún formato (como en `{}` ou `{:6}`), entón o formato trait usado é o [`Display`] trait.
//!
//! Ao implementar un formato trait para o seu propio tipo, terá que implementar un método de sinatura:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // o noso tipo personalizado
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! O seu tipo pasarase como referencia secundaria `self` e, a continuación, a función debería emitir saída ao fluxo `f.buf`.Depende de cada formato de implementación de trait cumprir correctamente os parámetros de formato solicitados.
//! Os valores destes parámetros serán listados nos campos da estrutura [`Formatter`].Para axudar a isto, a estrutura [`Formatter`] tamén ofrece algúns métodos de axuda.
//!
//! Ademais, o valor de devolución desta función é [`fmt::Result`], que é un alias tipo de [`Resultado]]` <(), `[` std: : fmt::Error`]`>`.
//! As implementacións de formato deben garantir que propagan erros desde o [`Formatter`] (por exemplo, cando se chama a [`write!`]).
//! Non obstante, nunca deben devolver erros de forma espuria.
//! É dicir, unha implementación de formato só pode e pode devolver un erro se o [`Formatter`] pasado devolve un erro.
//! Isto ocorre porque, ao contrario do que a sinatura de función podería suxerir, o formato de cadea é unha operación infalible.
//! Esta función só devolve un resultado porque a escritura no fluxo subxacente pode fallar e debe proporcionar un xeito de propagar o feito de que se produciu un erro na copia de seguridade da pila.
//!
//! Un exemplo de implementación do formato traits sería o seguinte:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // O valor `f` implementa o `Write` trait, que é o que escriben.a macro agarda.
//!         // Teña en conta que este formato ignora as distintas bandeiras proporcionadas para formatar as cadeas.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Diferentes traits permiten diferentes formas de saída dun tipo.
//! // O significado deste formato é imprimir a magnitude dun vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Respecta as bandeiras de formato empregando o método auxiliar `pad_integral` no obxecto Formatter.
//!         // Consulte a documentación do método para obter máis detalles e a función `pad` pode usarse para padear cordas.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Estes dous formatos de traits teñen propósitos distintos:
//!
//! - [`fmt::Display`][`Display`] as implementacións afirman que o tipo pode representarse fielmente como unha cadea UTF-8 en todo momento.**Non** se espera que todos os tipos implementen o [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] as implementacións deberían implementarse para **todos os** tipos públicos.
//!   A saída normalmente representará o estado interno o máis fielmente posible.
//!   O propósito do [`Debug`] trait é facilitar a depuración do código Rust.Na maioría dos casos, é suficiente e recomendable usar `#[derive(Debug)]`.
//!
//! Algúns exemplos da saída de ambos traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Macros relacionadas
//!
//! Hai unha serie de macros relacionadas na familia [`format!`].As que están actualmente implementadas son:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Esta e [`writeln!`] son dúas macros que se usan para emitir a cadea de formato a un fluxo especificado.Isto úsase para evitar asignacións intermedias de cadeas de formato e no seu lugar escribir directamente a saída.
//! Baixo o capó, esta función invoca realmente a función [`write_fmt`] definida no [`std::io::Write`] trait.
//! O exemplo de uso é:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Isto e [`println!`] emiten a súa saída a stdout.Do mesmo xeito que a macro [`write!`], o obxectivo destas macros é evitar asignacións intermedias ao imprimir a saída.O exemplo de uso é:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! As macros [`eprint!`] e [`eprintln!`] son idénticas a [`print!`] e [`println!`], respectivamente, excepto que emiten a súa saída a stderr.
//!
//! ### `format_args!`
//!
//! Esta é unha curiosa macro usada para pasar de forma segura un obxecto opaco que describe a cadea de formato.Este obxecto non require ningunha asignación de montón para crear e só fai referencia á información da pila.
//! Baixo o capó, todas as macros relacionadas están implementadas en termos disto.
//! En primeiro lugar, algúns exemplos de uso son:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! O resultado da macro [`format_args!`] é un valor do tipo [`fmt::Arguments`].
//! Esta estrutura pódese pasar ás funcións [`write`] e [`format`] dentro deste módulo para procesar a cadea de formato.
//! O obxectivo desta macro é evitar aínda máis as asignacións intermedias cando se trata de formatar cadeas.
//!
//! Por exemplo, unha biblioteca de rexistro podería usar a sintaxe de formato estándar, pero pasaría internamente por esta estrutura ata que se determinou a onde debería ir a saída.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// A función `format` toma unha estrutura [`Arguments`] e devolve a cadea formatada resultante.
///
///
/// A instancia [`Arguments`] pódese crear coa macro [`format_args!`].
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Ten en conta que pode ser preferible usar [`format!`].
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}