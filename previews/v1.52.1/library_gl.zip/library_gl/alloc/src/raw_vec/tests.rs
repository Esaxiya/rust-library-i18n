use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Escribir unha proba de integración entre asignadores de terceiros e `RawVec` é un pouco complicado porque a API `RawVec` non expón métodos de asignación falibles, polo que non podemos comprobar o que ocorre cando o asignador está esgotado (máis alá de detectar un panic).
    //
    //
    // Pola contra, isto só comproba que os métodos `RawVec` pasan polo menos pola API Allocator cando reserva almacenamento.
    //
    //
    //
    //
    //

    // Un tonto asignador que consume unha cantidade fixa de combustible antes de que os intentos de asignación comecen a fallar.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (provoca un reallocamento, empregando así 50 + 150=200 unidades de combustible)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // En primeiro lugar, `reserve` asigna como `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 supera o dobre de 7, polo que `reserve` debería funcionar como `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 é menos da metade de 12, polo que `reserve` debe medrar exponencialmente.
        // No momento de escribir esta proba, o factor de crecemento é 2, polo que a nova capacidade é 24, con todo, o factor de crecemento de 1.5 tamén está ben.
        //
        // De aí que `>= 18` en afirmación.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}