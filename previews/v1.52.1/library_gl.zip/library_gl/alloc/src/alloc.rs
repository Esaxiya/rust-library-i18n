//! API de asignación de memoria

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Estes son os símbolos máxicos para chamar ao asignador global.rustc xéraos para chamar ao `__rg_alloc` etc.
    // se hai un atributo `#[global_allocator]` (o código que expande ese atributo macro xera esas funcións) ou para chamar ás implementacións predeterminadas en libstd (`__rdl_alloc` etc.)
    //
    // en `library/std/src/alloc.rs`) doutro xeito.
    // O rustc fork de LLVM tamén usa casos especiais con estes nomes de funcións para poder optimizalos como `malloc`, `realloc` e `free`, respectivamente.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// O repartidor de memoria global.
///
/// Este tipo implementa o [`Allocator`] trait reenviando chamadas ao asignador rexistrado co atributo `#[global_allocator]` se hai algún ou o `std` crate é o predeterminado.
///
///
/// Note: mentres este tipo é inestable, pódese acceder á funcionalidade que ofrece a través do [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Asignar memoria co asignador global.
///
/// Esta función reenvía as chamadas ao método [`GlobalAlloc::alloc`] do asignador rexistrado co atributo `#[global_allocator]` se hai un ou o `std` crate é o predeterminado.
///
///
/// Espérase que esta función estea obsoleta a favor do método `alloc` do tipo [`Global`] cando este e o [`Allocator`] trait se volven estables.
///
/// # Safety
///
/// Vexa [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Distribúe a memoria co asignador global.
///
/// Esta función reenvía as chamadas ao método [`GlobalAlloc::dealloc`] do asignador rexistrado co atributo `#[global_allocator]` se hai un ou o `std` crate é o predeterminado.
///
///
/// Espérase que esta función estea obsoleta a favor do método `dealloc` do tipo [`Global`] cando este e o [`Allocator`] trait se volven estables.
///
/// # Safety
///
/// Vexa [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Reasignar memoria co asignador global.
///
/// Esta función reenvía as chamadas ao método [`GlobalAlloc::realloc`] do asignador rexistrado co atributo `#[global_allocator]` se hai un ou o `std` crate é o predeterminado.
///
///
/// Espérase que esta función estea obsoleta a favor do método `realloc` do tipo [`Global`] cando este e o [`Allocator`] trait se volven estables.
///
/// # Safety
///
/// Vexa [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Asignar memoria inicializada cero co asignador global.
///
/// Esta función reenvía as chamadas ao método [`GlobalAlloc::alloc_zeroed`] do asignador rexistrado co atributo `#[global_allocator]` se hai un ou o `std` crate é o predeterminado.
///
///
/// Espérase que esta función estea obsoleta a favor do método `alloc_zeroed` do tipo [`Global`] cando este e o [`Allocator`] trait se volven estables.
///
/// # Safety
///
/// Vexa [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // SEGURIDADE: o tamaño `layout` é diferente de cero,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // SEGURIDADE: Igual que `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // SEGURIDADE: `new_size` non é cero xa que `old_size` é maior ou igual a `new_size`
            // segundo requiren as condicións de seguridade.O interlocutor debe cumprir outras condicións
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` probablemente busque `new_size >= old_layout.size()` ou algo similar.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SEGURIDADE: porque `new_layout.size()` debe ser maior ou igual a `old_size`,
            // tanto a antiga como a nova asignación de memoria son válidas para lecturas e escrituras para bytes `old_size`.
            // Ademais, debido a que a antiga asignación aínda non estaba repartida, non pode superpoñerse a `new_ptr`.
            // Así, a chamada a `copy_nonoverlapping` é segura.
            // O interlocutor debe confirmar o contrato de seguridade para `dealloc`.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // SEGURIDADE: o tamaño `layout` é diferente de cero,
            // o interlocutor debe cumprir outras condicións
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURIDADE: todas as condicións deben ser cumpridas polo interlocutor
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURIDADE: todas as condicións deben ser cumpridas polo interlocutor
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // SEGURIDADE: as condicións deben ser cumpridas polo interlocutor
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // SEGURIDADE: `new_size` non é cero.O interlocutor debe cumprir outras condicións
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` probablemente busque `new_size <= old_layout.size()` ou algo similar.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SEGURIDADE: porque `new_size` debe ser menor ou igual a `old_layout.size()`,
            // tanto a antiga como a nova asignación de memoria son válidas para lecturas e escrituras para bytes `new_size`.
            // Ademais, debido a que a antiga asignación aínda non estaba repartida, non pode superpoñerse a `new_ptr`.
            // Así, a chamada a `copy_nonoverlapping` é segura.
            // O interlocutor debe confirmar o contrato de seguridade para `dealloc`.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// O asignador de punteiros únicos.
// Esta función non debe desconectarse.Se o fai, o codegen MIR fallará.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Esta sinatura ten que ser a mesma que `Box`, se non, sucederá un ICE.
// Cando se engade un parámetro adicional a `Box` (como `A: Allocator`), tamén hai que engadilo aquí.
// Por exemplo, se `Box` cambia a `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, tamén se debe cambiar esta función a `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Controlador de erros de asignación

extern "Rust" {
    // Este é o símbolo máxico para chamar ao controlador global de erros de asignación.
    // rustc xérao para chamar a `__rg_oom` se hai un `#[alloc_error_handler]` ou para chamar ás implementacións predeterminadas por debaixo de (`__rdl_oom`) doutro xeito.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Abortar o erro ou fallo na asignación de memoria.
///
/// Anímase aos chamadores de API de asignación de memoria que desexen abortar o cálculo en resposta a un erro de asignación a que chamen a esta función en lugar de invocar directamente `panic!` ou similar.
///
///
/// O comportamento predeterminado desta función é imprimir unha mensaxe cun erro estándar e abortar o proceso.
/// Pódese substituír por [`set_alloc_error_hook`] e [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Para a proba de asignación pódese usar `std::alloc::handle_alloc_error` directamente.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // chamado mediante `__rust_alloc_error_handler` xerado

    // se non hai `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // se hai un `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Especializa os clons na memoria non inicializada previamente asignada.
/// Usado por `Box::clone` e `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Ter asignado *primeiro* pode permitir ao optimizador crear o valor clonado no seu lugar, saltando o local e movéndose.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Sempre podemos copiar no lugar, sen implicar nunca un valor local.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}