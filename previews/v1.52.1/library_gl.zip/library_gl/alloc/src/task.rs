#![stable(feature = "wake_trait", since = "1.51.0")]
//! Tipos e Traits para traballar con tarefas asíncronas.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// A implementación de espertar unha tarefa nun executor.
///
/// Este trait pode usarse para crear un [`Waker`].
/// Un executor pode definir unha implementación deste trait e usalo para construír un Waker para pasar ás tarefas que se executan nese executor.
///
/// Este trait é unha alternativa ergonómica e segura para a memoria para construír un [`RawWaker`].
/// Admite o deseño común do executor no que os datos empregados para espertar unha tarefa se almacenan nun [`Arc`].
/// Algúns executores (especialmente os de sistemas embebidos) non poden usar esta API, razón pola cal existe [`RawWaker`] como alternativa para eses sistemas.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Unha función básica `block_on` que leva un future e o executa ata o final no fío actual.
///
/// **Note:** Este exemplo cambia a corrección por simplicidade.
/// Para evitar bloqueos, as implementacións de calidade de produción tamén terán que xestionar chamadas intermedias a `thread::unpark` así como invocacións anidadas.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Un waker que esperta o fío actual cando o chaman.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Executa un future ata o final no fío actual.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Fixa o future para que poida ser consultado.
///     let mut fut = Box::pin(fut);
///
///     // Crea un novo contexto para pasar ao future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Executa o future ata a súa conclusión.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Esperta esta tarefa.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Esperta esta tarefa sen consumir ao waker.
    ///
    /// Se un executor admite un xeito máis barato de espertar sen consumir o waker, debería anular este método.
    /// De xeito predeterminado, clona o [`Arc`] e chama a [`wake`] no clon.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SEGURIDADE: Isto é seguro porque raw_waker constrúe con seguridade
        // un RawWaker de Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Esta función privada para construír un RawWaker úsase en lugar de
// inserindo isto no impl `From<Arc<W>> for RawWaker`, para garantir que a seguridade de `From<Arc<W>> for Waker` non dependa do envío correcto de trait, en cambio ambos impls chaman esta función directa e explícitamente.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Incremente o reconto de referencia do arco para clonalo.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Esperta por valor, movendo o Arco na función Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Esperta por referencia, envolve o waker en ManuallyDrop para evitar deixalo caer
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Diminuír o número de referencia do arco ao soltar
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}