//! Unha cola de dobre extremo implementada cun buffer de anel cultivable.
//!
//! Esta cola ten insercións e retiradas amortizadas de *O*(1) de ambos os extremos do contedor.
//! Tamén ten indexación *O*(1) como un vector.
//! Non é necesario que os elementos contidos sexan copiables e a cola enviarase se o tipo contido é enviable.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // A maior potencia posible de dúas

/// Unha cola de dobre extremo implementada cun buffer de anel cultivable.
///
/// O uso deste tipo "default" como cola é usar [`push_back`] para engadir á cola e [`pop_front`] para eliminar da cola.
///
/// [`extend`] e [`append`] empuxe cara atrás deste xeito e a iteración sobre `VecDeque` vai de fronte a atrás.
///
/// Dado que `VecDeque` é un buffer de anel, os seus elementos non son necesariamente contiguos na memoria.
/// Se desexa acceder aos elementos como unha única porción, como para unha ordenación eficiente, pode usar [`make_contiguous`].
/// Xira o `VecDeque` para que os seus elementos non se envolvan e devolve unha porción mutable á secuencia de elementos agora contigua.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // a cola e a cabeza son indicadores do buffer.
    // A cola sempre apunta ao primeiro elemento que se podía ler, a cabeza sempre indica onde se deben escribir os datos.
    //
    // Se cola==a cabeza o búfer está baleiro.A lonxitude do amortecedor defínese como a distancia entre os dous.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Executa o destructor de todos os elementos da porción cando cae (normalmente ou durante o desenrolo).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // use drop para [T]
            ptr::drop_in_place(front);
        }
        // RawVec manexa a deslocalización
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Crea un `VecDeque<T>` baleiro.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Marxinalmente máis cómodo
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Marxinalmente máis cómodo
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Para os tipos de tamaño cero, sempre temos a máxima capacidade
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Converter ptr nunha porción
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Converte ptr nunha porción mut
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Move un elemento do búfer
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Escribe un elemento no buffer movéndoo.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Devolve `true` se o búfer está a plena capacidade.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Devolve o índice no búfer subxacente para un índice de elemento lóxico dado.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Devolve o índice no búfer subxacente para un índice de elemento lóxico dado + addend.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Devolve o índice no búfer subxacente para un índice de elemento lóxico dado, subhend.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Copia un bloque de memoria contiguo longo desde src a dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Copia un bloque de memoria contiguo longo desde src a dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Copia un bloque potencial de memoria de longa duración desde src a dest.
    /// (abs(dst - src) + len) non debe ser maior que cap() (Debe haber como máximo unha rexión solapada continua entre src e dest).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src non envolve, dst non envolve
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst antes de src, src non envolve, dst envolve
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src antes de dst, src non envolve, dst envolve
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst antes de src, src envolve, dst non envolve
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src antes de dst, src envolve, dst non envolve
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst antes de src, src envolve, dst envolve
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src antes de dst, src envolve, dst envolve
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Xira as seccións de cabeza e cola ao redor para controlar o feito de que acabamos de reasignar.
    /// Non é seguro porque confía na capacidade_de_vello.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Move a sección contigua máis curta do buffer de anel TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // A Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Crea un `VecDeque` baleiro.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Crea un `VecDeque` baleiro con espazo para polo menos elementos `capacity`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 xa que o amortecedor sempre deixa un espazo baleiro
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Ofrece unha referencia ao elemento no índice indicado.
    ///
    /// O elemento do índice 0 é a parte dianteira da cola.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Ofrece unha referencia mutable ao elemento no índice indicado.
    ///
    /// O elemento do índice 0 é a parte dianteira da cola.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Intercambia elementos nos índices `i` e `j`.
    ///
    /// `i` e `j` pode ser igual.
    ///
    /// O elemento do índice 0 é a parte dianteira da cola.
    ///
    /// # Panics
    ///
    /// Panics se calquera índice está fóra dos límites.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Devolve o número de elementos que o `VecDeque` pode manter sen reasignar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Reserva a capacidade mínima para que se insiren exactamente `additional` máis elementos no `VecDeque` indicado.
    /// Non fai nada se a capacidade xa é suficiente.
    ///
    /// Teña en conta que o asignador pode dar á colección máis espazo do que solicita.
    /// Polo tanto, non se pode confiar na capacidade para ser precisamente mínima.
    /// Preferir [`reserve`] se se esperan insercións future.
    ///
    /// # Panics
    ///
    /// Panics se a nova capacidade reborda `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Reserva capacidade para polo menos `additional` elementos máis para inserir no `VecDeque` indicado.
    /// A colección pode reservar máis espazo para evitar reasignacións frecuentes.
    ///
    /// # Panics
    ///
    /// Panics se a nova capacidade reborda `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Intenta reservar a capacidade mínima para que se insiren exactamente `additional` elementos máis no `VecDeque<T>` dado.
    ///
    /// Despois de chamar ao `try_reserve_exact`, a capacidade será maior ou igual que `self.len() + additional`.
    /// Non fai nada se a capacidade xa é suficiente.
    ///
    /// Teña en conta que o asignador pode dar á colección máis espazo do que solicita.
    /// Polo tanto, non se pode confiar na capacidade para ser precisamente mínima.
    /// Preferir `reserve` se se esperan insercións future.
    ///
    /// # Errors
    ///
    /// Se a capacidade reborda `usize` ou o asignador informa dun fallo, devolverase un erro.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Reserva previamente a memoria, saíndo se non podemos
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Agora sabemos que isto non pode OOM(Out-Of-Memory) no medio do noso complexo traballo
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // moi complicado
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Tenta reservar capacidade para polo menos `additional` elementos máis para inserir no `VecDeque<T>` dado.
    /// A colección pode reservar máis espazo para evitar reasignacións frecuentes.
    /// Despois de chamar ao `try_reserve`, a capacidade será maior ou igual que `self.len() + additional`.
    /// Non fai nada se a capacidade xa é suficiente.
    ///
    /// # Errors
    ///
    /// Se a capacidade reborda `usize` ou o asignador informa dun fallo, devolverase un erro.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Reserva previamente a memoria, saíndo se non podemos
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Agora sabemos que isto non pode OOM no medio do noso complexo traballo
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // moi complicado
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Reduce a capacidade do `VecDeque` na medida do posible.
    ///
    /// Descenderá o máis preto posible da lonxitude, pero o asignador aínda pode informar ao `VecDeque` de que hai espazo para algúns elementos máis.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Reduce a capacidade do `VecDeque` cun límite inferior.
    ///
    /// A capacidade seguirá sendo polo menos tan grande como a lonxitude e o valor subministrado.
    ///
    ///
    /// Se a capacidade actual é inferior ao límite inferior, este será un no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Non nos temos que preocupar por un desbordamento xa que nin `self.len()` nin `self.capacity()` poden ser `usize::MAX`.
        // +1 xa que o amortecedor sempre deixa un espazo baleiro.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Hai tres casos de interese:
            //   Todos os elementos están fóra dos límites desexados Os elementos son contiguos e a cabeza está fóra dos límites desexados Os elementos son descontinuos e a cola está fóra dos límites desexados
            //
            //
            // Noutros momentos, as posicións dos elementos non se ven afectadas.
            //
            // Indica que se deben mover elementos na cabeza.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Mover elementos fóra dos límites desexados (posicións despois de target_cap)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Acurta o `VecDeque`, mantendo os primeiros elementos `len` e deixando caer o resto.
    ///
    ///
    /// Se `len` é maior que a lonxitude actual do `VecDeque`, isto non terá efecto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Executa o destructor de todos os elementos da porción cando cae (normalmente ou durante o desenrolo).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Seguro porque:
        //
        // * Calquera porción que se pase a `drop_in_place` é válida;o segundo caso ten `len <= front.len()` e volver ao `len > self.len()` garante `begin <= back.len()` no primeiro caso
        //
        // * A cabeza do VecDeque móvese antes de chamar ao `drop_in_place`, polo que ningún valor cae dúas veces se `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Asegúrese de que a segunda metade caia incluso cando un destructor na primeira panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Devolve un iterador dianteiro.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Devolve un iterador dianteiro que devolve referencias mudables.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // SEGURIDADE: a invariante de seguridade interna `IterMut` establécese porque o
        // `ring` que creamos é unha porción dereferencible para toda a vida '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Devolve un par de franxas que conteñen, en orde, o contido do `VecDeque`.
    ///
    /// Se previamente se chamou a [`make_contiguous`], todos os elementos do `VecDeque` estarán na primeira sección e a segunda estará baleira.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Devolve un par de franxas que conteñen, en orde, o contido do `VecDeque`.
    ///
    /// Se previamente se chamou a [`make_contiguous`], todos os elementos do `VecDeque` estarán na primeira sección e a segunda estará baleira.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Devolve o número de elementos no `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Devolve `true` se o `VecDeque` está baleiro.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Crea un iterador que abrangue o rango especificado no `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics se o punto de partida é maior que o punto final ou se o punto final é maior que a lonxitude do vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Unha gama completa abarca todos os contidos
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // A referencia compartida que temos en &self mantense no '_ de Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Crea un iterador que abrangue o rango mutable especificado no `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics se o punto de partida é maior que o punto final ou se o punto final é maior que a lonxitude do vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Unha gama completa abarca todos os contidos
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // SEGURIDADE: a invariante de seguridade interna `IterMut` establécese porque o
        // `ring` que creamos é unha porción dereferencible para toda a vida '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Crea un iterador de drenaxe que elimina o rango especificado no `VecDeque` e produce os elementos eliminados.
    ///
    /// Nota 1: elimínase o rango de elementos aínda que o iterador non se consume ata o final.
    ///
    /// Nota 2: non se especifica cantos elementos se eliminan do deque, se o valor `Drain` non se deixa caer, pero o préstamo que ten caduca (por exemplo, debido a `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics se o punto de partida é maior que o punto final ou se o punto final é maior que a lonxitude do vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Unha gama completa limpa todo o contido
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Seguridade da memoria
        //
        // Cando se crea por primeira vez o Drain, o deque de orixe acórtase para asegurarse de que non hai elementos accesibles nin iniciados nin se o destructor do Drain nunca se executa.
        //
        //
        // Drain eliminará ptr::read os valores para eliminar.
        // Cando remate, os datos restantes copiaranse para cubrir o burato e os valores head/tail restauraranse correctamente.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Os elementos do deque están divididos en tres segmentos:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drenar_cola;h=drain_head
        //
        // Almacenamos drain_tail como self.head e drain_head e self.head como after_tail e after_head respectivamente no Drain.
        // Isto tamén trunca a matriz efectiva de tal xeito que, se se filtra o Drain, esquecemos os valores potencialmente desprazados despois do inicio do drain.
        //
        //
        //        T th H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" sobre os valores despois do inicio do drain ata despois de completar o drain e executar o destructor Drain.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // De xeito crucial, só creamos referencias compartidas de `self` aquí e lemos a partir del.
                // Non escribimos a `self` nin volvemos a solicitar unha referencia mutable.
                // De aí que o punteiro en bruto que creamos anteriormente, para `deque`, siga sendo válido.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Borra o `VecDeque`, eliminando todos os valores.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Devolve `true` se o `VecDeque` contén un elemento igual ao valor indicado.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Ofrece unha referencia ao elemento frontal ou `None` se o `VecDeque` está baleiro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Ofrece unha referencia mudable ao elemento frontal ou `None` se o `VecDeque` está baleiro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Ofrece unha referencia ao elemento traseiro ou `None` se o `VecDeque` está baleiro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Ofrece unha referencia mudable ao elemento traseiro ou `None` se o `VecDeque` está baleiro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Elimina o primeiro elemento e devólveo ou `None` se o `VecDeque` está baleiro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Elimina o último elemento do `VecDeque` e devólveo ou `None` se está baleiro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Prepende un elemento ao `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Engade un elemento na parte traseira do `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Debemos considerar `head == 0` como significado
        // que `self` é contiguo?
        self.tail <= self.head
    }

    /// Elimina un elemento de calquera lugar do `VecDeque` e devólveo, substituíndoo polo primeiro elemento.
    ///
    ///
    /// Isto non conserva a orde, pero é *O*(1).
    ///
    /// Devolve `None` se `index` está fóra dos límites.
    ///
    /// O elemento do índice 0 é a parte dianteira da cola.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Elimina un elemento de calquera lugar do `VecDeque` e devólveo, substituíndoo polo último elemento.
    ///
    ///
    /// Isto non conserva a orde, pero é *O*(1).
    ///
    /// Devolve `None` se `index` está fóra dos límites.
    ///
    /// O elemento do índice 0 é a parte dianteira da cola.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Insire un elemento en `index` dentro do `VecDeque`, desprazando todos os elementos con índices maiores ou iguais a `index` cara atrás.
    ///
    ///
    /// O elemento do índice 0 é a parte dianteira da cola.
    ///
    /// # Panics
    ///
    /// Panics se `index` é maior que a lonxitude de `VecDeque`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Move o menor número de elementos no buffer de anel e insira o obxecto indicado
        //
        // Como máximo len/2, moveranse 1 elementos. O(min(n, n-i))
        //
        // Hai tres casos principais:
        //  Os elementos son contiguos
        //      - caso especial cando a cola é 0 Os elementos son descontinuos e a inserción está na sección de cola Os elementos son descontiguos e a inserción está na sección de cabeza
        //
        //
        // Para cada un deles hai dous casos máis:
        //  A inserción está máis preto da cola A inserción está máis preto da cabeza
        //
        // Clave: H, self.head
        //      T, self.tail o, Elemento válido I, Elemento de inserción A, O elemento que debería estar despois do punto de inserción M, Indica que o elemento foi movido
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [A oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // contiguo, inserte máis preto da cola:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // contiguo, inserir máis preto da cola e a cola é 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Xa movemos a cola, polo que só copiamos elementos `index - 1`.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // contiguo, inserte máis preto da cabeza:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // descontinuo, inserto máis preto da cola, sección da cola:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // descontinuo, inserto máis preto da cabeza, sección da cola:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // copiar elementos ata a nova cabeza
                    self.copy(1, 0, self.head);

                    // copia o último elemento nun lugar baleiro na parte inferior do búfer
                    self.copy(0, self.cap() - 1, 1);

                    // move elementos de idx para rematar cara adiante sen incluír o elemento ^
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // descontinuo, a inserción está máis preto da cola, a sección da cabeza e está no índice cero no buffer interno:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // copiar elementos ata a nova cola
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // copia o último elemento nun lugar baleiro na parte inferior do búfer
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // descontinuo, inserto máis preto da cola, sección da cabeza:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // copiar elementos ata a nova cola
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // copia o último elemento nun lugar baleiro na parte inferior do búfer
                    self.copy(self.cap() - 1, 0, 1);

                    // mover elementos de idx-1 para rematar cara adiante sen incluír o elemento ^
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // descontinuo, inserto máis preto da cabeza, sección da cabeza:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // a cola pode que se cambiou polo que necesitamos volver calcular
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Elimina e devolve o elemento en `index` do `VecDeque`.
    /// O extremo máis próximo ao punto de eliminación moverase para facer espazo e todos os elementos afectados moveranse a novas posicións.
    ///
    /// Devolve `None` se `index` está fóra dos límites.
    ///
    /// O elemento do índice 0 é a parte dianteira da cola.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Hai tres casos principais:
        //  Os elementos son contiguos Os elementos son descontinuos e a eliminación está na sección de cola Os elementos son descontiguos e a eliminación está na sección de cabeza
        //
        //      - caso especial cando os elementos son técnicamente contiguos, pero self.head =0
        //
        // Para cada un deles hai dous casos máis:
        //  A inserción está máis preto da cola A inserción está máis preto da cabeza
        //
        // Clave: H, self.head
        //      T, self.tail o, Elemento válido x, Elemento marcado para a eliminación R, Indica o elemento que se está eliminando M, Indica que o elemento foi movido
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // contiguo, retírase máis preto da cola:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // contiguo, retírase máis preto da cabeza:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // descontinuo, retírase máis preto da cola, sección da cola:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // descontinuo, retírase máis preto da cabeza, sección da cabeza:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // descontinuo, retírase máis preto da cabeza, sección da cola:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // ou case descontinuo, elimina xunto á cabeza, a sección de cola:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // debuxa elementos na sección de cola
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Evita o desbordamento.
                    if self.head != 0 {
                        // copia o primeiro elemento nun lugar baleiro
                        self.copy(self.cap() - 1, 0, 1);

                        // move elementos da sección da cabeza cara atrás
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // descontinuo, retírase máis preto da cola, sección da cabeza:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // debuxa elementos ata idx
                    self.copy(1, 0, idx);

                    // copiar o último elemento nun lugar baleiro
                    self.copy(0, self.cap() - 1, 1);

                    // mover elementos da cola para rematar cara adiante, excluíndo o último
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Divide o `VecDeque` en dous no índice indicado.
    ///
    /// Devolve un `VecDeque` recentemente asignado.
    /// `self` contén elementos `[0, at)` e o `VecDeque` devolto contén elementos `[at, len)`.
    ///
    /// Teña en conta que a capacidade do `self` non cambia.
    ///
    /// O elemento do índice 0 é a parte dianteira da cola.
    ///
    /// # Panics
    ///
    /// Panics se `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` reside na primeira metade.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // só tes que levar toda a segunda metade.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` reside na segunda metade, ten que ter en conta os elementos que saltamos na primeira metade.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Limpeza onde están os extremos dos buffers
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Move todos os elementos de `other` a `self`, deixando `other` baleiro.
    ///
    /// # Panics
    ///
    /// Panics se o novo número de elementos en si desborda un `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // inxenuo impl
        self.extend(other.drain(..));
    }

    /// Conserva só os elementos especificados polo predicado.
    ///
    /// Noutras palabras, elimine todos os elementos `e` de xeito que `f(&e)` devolva falso.
    /// Este método funciona no seu lugar, visitando cada elemento exactamente unha vez na orde orixinal e preserva a orde dos elementos retidos.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// A orde exacta pode ser útil para rastrexar o estado externo, como un índice.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Isto pode panic ou abortar
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Dobre o tamaño do búfer.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Modifica o `VecDeque` no lugar para que `len()` sexa igual a `new_len`, xa sexa eliminando os elementos excedentes da parte traseira ou engadindo elementos xerados chamando `generator` á parte traseira.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Reorganiza o almacenamento interno deste deque polo que é unha porción contigua, que logo se devolve.
    ///
    /// Este método non se asigna e non modifica a orde dos elementos inseridos.Como devolve unha porción mutable, pódese usar para ordenar un deque.
    ///
    /// Unha vez que o almacenamento interno sexa contiguo, os métodos [`as_slices`] e [`as_mut_slices`] devolverán todo o contido do `VecDeque` nunha única porción.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Ordenación do contido dun deque.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // ordenando o deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // ordenándoo en orde inversa
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Obtendo acceso inmutable á porción contigua.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // agora podemos estar seguros de que `slice` contén todos os elementos do deque, aínda que temos acceso inmutable a `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // hai espazo libre suficiente para copiar a cola dunha soa vez, isto significa que primeiro movemos a cabeza cara atrás e despois copiamos a cola á posición correcta.
            //
            //
            // de: DEFGH .... ABC
            // a: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Actualmente non consideramos .... ABCDEFGH
            // para ser contiguo porque `head` sería `0` neste caso.
            // Aínda que probablemente queremos cambiar isto, non é trivial xa que algúns lugares esperan que `is_contiguous` signifique que só podemos cortar `buf[tail..head]`.
            //
            //

            // hai espazo libre suficiente para copiar a cabeza dunha soa vez, isto significa que primeiro movemos a cola cara adiante e despois copiamos a cabeza á posición correcta.
            //
            //
            // de: FGH .... ABCDE
            // a: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // libre é máis pequeno que a cabeza e a cola, isto significa que temos que lentamente "swap" a cola e a cabeza.
            //
            //
            // de: EFGHI ... ABCD ou HIJK.ABCDEFG
            // a: ABCDEFGHI ... ou ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // O problema xeral semella este GHIJKLM ... ABCDEF, antes de calquera intercambio ABCDEFM ... GHIJKL, despois de 1 paso de intercambios ABCDEFGHIJM ... KL, permuta ata que o edge esquerdo chegue á tenda temporal
                //                  - a continuación, reinicie o algoritmo cun novo almacén (smaller) Ás veces alcánzase o almacén temporal cando o edge correcto está ao final do búfer, isto significa que alcanzamos a orde correcta con menos intercambios.
                //
                // E.g
                // EF..ABCD ABCDEF .., despois de catro intercambios só rematamos
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Xira a cola de dobre final `mid` á esquerda.
    ///
    /// Equivalently,
    /// - Xira o elemento `mid` á primeira posición.
    /// - Descarga os primeiros elementos `mid` e empúxaos ata o final.
    /// - Xira os lugares `len() - mid` cara á dereita.
    ///
    /// # Panics
    ///
    /// Se `mid` é maior que `len()`.
    /// Teña en conta que `mid == len()` fai _not_ panic e é unha rotación sen operacións.
    ///
    /// # Complexity
    ///
    /// Leva `*O*(min(mid, len() - mid))` tempo e non ten espazo adicional.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Xira a cola de dobre extremo que coloca `k` cara á dereita.
    ///
    /// Equivalently,
    /// - Xira o primeiro elemento na posición `k`.
    /// - Descarga os últimos elementos `k` e empúxaos cara á fronte.
    /// - Xira os lugares `len() - k` cara á esquerda.
    ///
    /// # Panics
    ///
    /// Se `k` é maior que `len()`.
    /// Teña en conta que `k == len()` fai _not_ panic e é unha rotación sen operacións.
    ///
    /// # Complexity
    ///
    /// Leva `*O*(min(k, len() - k))` tempo e non ten espazo adicional.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // SEGURIDADE: os dous métodos seguintes requiren que a cantidade de rotación
    // ser inferior á metade da lonxitude do deque.
    //
    // `wrap_copy` require que `min(x, cap() - x) + copy_len <= cap()`, pero que `min` nunca supera a metade da capacidade, independentemente de x, polo que é bo chamar aquí porque estamos chamando con algo menos da metade da lonxitude, que nunca está por riba da metade da capacidade.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// O binario busca neste elemento `VecDeque` ordenado un determinado elemento.
    ///
    /// Se se atopa o valor, devólvese [`Result::Ok`], que contén o índice do elemento coincidente.
    /// Se hai varias coincidencias, pódese devolver calquera das coincidencias.
    /// Se non se atopa o valor, devólvese [`Result::Err`], que contén o índice onde se podería inserir un elemento coincidente mantendo a orde ordenada.
    ///
    ///
    /// # Examples
    ///
    /// Busca unha serie de catro elementos.
    /// Atópase o primeiro, cunha posición determinada de xeito único;o segundo e o terceiro non se atopan;o cuarto podería igualar calquera posición en `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Se desexa inserir un elemento nun `VecDeque` ordenado, mantendo a orde de clasificación:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// O binario busca este `VecDeque` ordenado cunha función de comparación.
    ///
    /// A función de comparación debería implementar unha orde consistente coa orde de clasificación do `VecDeque` subxacente, devolvendo un código de orde que indica se o seu argumento é `Less`, `Equal` ou `Greater` que o obxectivo desexado.
    ///
    ///
    /// Se se atopa o valor, devólvese [`Result::Ok`], que contén o índice do elemento coincidente.Se hai varias coincidencias, pódese devolver calquera das coincidencias.
    /// Se non se atopa o valor, devólvese [`Result::Err`], que contén o índice onde se podería inserir un elemento coincidente mantendo a orde ordenada.
    ///
    /// # Examples
    ///
    /// Busca unha serie de catro elementos.Atópase o primeiro, cunha posición determinada de xeito único;o segundo e o terceiro non se atopan;o cuarto podería igualar calquera posición en `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// O binario busca este `VecDeque` ordenado cunha función de extracción de teclas.
    ///
    /// Supón que o `VecDeque` está ordenado pola clave, por exemplo con [`make_contiguous().sort_by_key()`](#method.make_contiguous) usando a mesma función de extracción de teclas.
    ///
    ///
    /// Se se atopa o valor, devólvese [`Result::Ok`], que contén o índice do elemento coincidente.
    /// Se hai varias coincidencias, pódese devolver calquera das coincidencias.
    /// Se non se atopa o valor, devólvese [`Result::Err`], que contén o índice onde se podería inserir un elemento coincidente mantendo a orde ordenada.
    ///
    /// # Examples
    ///
    /// Busca unha serie de catro elementos nunha porción de pares ordenados polos seus segundos elementos.
    /// Atópase o primeiro, cunha posición determinada de xeito único;o segundo e o terceiro non se atopan;o cuarto podería igualar calquera posición en `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Modifica o `VecDeque` no lugar para que `len()` sexa igual a new_len, xa que elimina elementos excedentes da parte traseira ou engadindo clons de `value` á parte traseira.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Devolve o índice no búfer subxacente para un índice de elemento lóxico dado.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // o tamaño é sempre unha potencia de 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Calcula o número de elementos que quedan por ler no buffer
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // o tamaño é sempre unha potencia de 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Sempre divisible en tres seccións, por exemplo: auto: [a b c|d e f] outro: [0 1 2 3|4 5] dianteiro=3, medio=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Non é posible usar Hash::hash_slice en rodajas devoltas polo método as_slices xa que a súa lonxitude pode variar en deques idénticos.
        //
        //
        // Hasher só garante a equivalencia para o mesmo conxunto de chamadas aos seus métodos.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Consume o `VecDeque` nun iterador de fronte a atrás que produce elementos por valor.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Esta función debería ser o equivalente moral de:
        //
        //      para o elemento en iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Converte un [`Vec<T>`] nun [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Isto evita reasignar sempre que sexa posible, pero as condicións para iso son estritas e están suxeitas a cambios, polo que non se debe confiar a menos que o `Vec<T>` proceda de `From<VecDeque<T>>` e non se reasigne.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Non hai ningunha asignación real para que os ZST se preocupen pola capacidade, pero `VecDeque` non pode soportar tanta lonxitude como `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Necesitamos cambiar o tamaño se a capacidade non é unha potencia de dous, moi pequena ou non ten polo menos un espazo libre.
            // Facémolo mentres aínda está no `Vec` polo que os elementos caerán en panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Converte un [`VecDeque<T>`] nun [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Isto nunca necesita volver asignarse, pero ten que facer un movemento de datos *O*(*n*) se o búfer circular non está ao comezo da asignación.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Este é *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Este necesita reordenar datos.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}