use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Saca temporalmente outro equivalente inmutable do mesmo rango.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Atopa os distintos bordos das follas que delimitan un rango especificado nunha árbore.
    /// Devolve un par de tiradores diferentes na mesma árbore ou un par de opcións baleiras.
    ///
    /// # Safety
    ///
    /// A menos que `BorrowType` sexa `Immut`, non use os tiradores duplicados para visitar o mesmo KV dúas veces.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Equivalente a `(root1.first_leaf_edge(), root2.last_leaf_edge())` pero máis eficiente.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Atopa o par de bordos das follas que delimitan un rango específico nunha árbore.
    ///
    /// O resultado é significativo só se a árbore está ordenada por tecla, como é a árbore nun `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // SEGURIDADE: o noso tipo de préstamo é inmutable.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Atopa o par de bordos das follas que delimitan unha árbore enteira.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Divide unha referencia única nun par de bordos de follas que delimitan un intervalo especificado.
    /// O resultado son referencias non únicas que permiten a mutación (some), que deben usarse con coidado.
    ///
    /// O resultado é significativo só se a árbore está ordenada por tecla, como é a árbore nun `BTreeMap`.
    ///
    ///
    /// # Safety
    /// Non use os tiradores duplicados para visitar o mesmo KV dúas veces.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Divide unha referencia única nun par de bordos das follas que delimitan a gama completa da árbore.
    /// Os resultados son referencias non únicas que permiten a mutación (só de valores), polo que deben usarse con coidado.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Aquí duplicamos a raíz NodeRef: nunca visitaremos o mesmo KV dúas veces e nunca acabaremos con referencias de valores superpostas.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Divide unha referencia única nun par de bordos das follas que delimitan a gama completa da árbore.
    /// Os resultados son referencias non únicas que permiten unha mutación masivamente destrutiva, polo que deben empregarse co máximo coidado.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Aquí duplicamos a raíz NodeRef: nunca accederemos a ela dun xeito que se superpón ás referencias obtidas da raíz.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Dado un identificador de folla edge, devolve [`Result::Ok`] cun identificador ao KV veciño no lado dereito, que está no mesmo nodo de folla ou nun nodo ancestral.
    ///
    /// Se a folla edge é a última da árbore, devolve [`Result::Err`] co nodo raíz.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Dado un identificador de folla edge, devolve [`Result::Ok`] cun identificador ao KV veciño do lado esquerdo, que está no mesmo nodo de folla ou nun nodo ancestral.
    ///
    /// Se a folla edge é a primeira da árbore, devolve [`Result::Err`] co nodo raíz.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Dado un controlador edge interno, devolve [`Result::Ok`] cun controlador ao KV veciño no lado dereito, que está no mesmo nodo interno ou nun nodo ancestral.
    ///
    /// Se o edge interno é o último da árbore, devolve [`Result::Err`] co nodo raíz.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Dada unha folla edge cunha folla nunha árbore moribunda, devolve a seguinte folla edge no lado dereito e o par clave-valor polo medio, que se atopa no mesmo nodo de folla, nun nodo ancestral ou inexistente.
    ///
    ///
    /// Este método tamén reparte calquera node(s) que chegue ao final.
    /// Isto implica que se non hai máis par clave-valor, o resto da árbore estará repartido e xa non queda nada por devolver.
    ///
    /// # Safety
    /// O edge indicado non debe ser devolto previamente pola contraparte `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Dada unha folla edge cunha folla nunha árbore moribunda, devolve a seguinte folla edge no lado esquerdo e o par clave-valor polo medio, que se atopa no mesmo nodo de folla, nun nodo ancestral ou inexistente.
    ///
    ///
    /// Este método tamén reparte calquera node(s) que chegue ao final.
    /// Isto implica que se non hai máis par clave-valor, o resto da árbore estará repartido e xa non queda nada por devolver.
    ///
    /// # Safety
    /// O edge indicado non debe ser devolto previamente pola contraparte `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Distribúe un montón de nós desde a folla ata a raíz.
    /// Esta é a única forma de repartir o resto dunha árbore despois de que `deallocating_next` e `deallocating_next_back` mordesquenen os dous lados da árbore e alcanzasen o mesmo edge.
    /// Como só se pretende chamar cando se devolven todas as claves e valores, non se fai limpeza en ningunha das claves ou valores.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Move o controlador de folla edge á seguinte folla edge e devolve referencias á clave e ao valor intermedio.
    ///
    ///
    /// # Safety
    /// Debe haber outro KV na dirección percorrida.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Move o controlador de folla edge á folla edge anterior e devolve referencias á clave e ao valor intermedio.
    ///
    ///
    /// # Safety
    /// Debe haber outro KV na dirección percorrida.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Move o controlador de folla edge á seguinte folla edge e devolve referencias á clave e ao valor intermedio.
    ///
    ///
    /// # Safety
    /// Debe haber outro KV na dirección percorrida.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Facer isto último é máis rápido, segundo os puntos de referencia.
        kv.into_kv_valmut()
    }

    /// Move o controlador de folla edge á folla anterior e devolve referencias á clave e ao valor intermedio.
    ///
    ///
    /// # Safety
    /// Debe haber outro KV na dirección percorrida.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Facer isto último é máis rápido, segundo os puntos de referencia.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Move o controlador de folla edge á seguinte folla edge e devolve a clave e o valor intermedio, deslocalizando calquera nodo que deixe mentres deixa o edge correspondente no seu nodo pai colgando.
    ///
    /// # Safety
    /// - Debe haber outro KV na dirección percorrida.
    /// - O homólogo `next_back_unchecked` non devolveu ese KV en ningunha copia das asas que se usaban para atravesar a árbore.
    ///
    /// O único xeito seguro de continuar co controlador actualizado é comparalo, soltalo, chamar de novo a este método segundo as súas condicións de seguridade ou chamar ao homólogo `next_back_unchecked` segundo as súas condicións de seguridade.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Move o controlador de folla edge á folla edge anterior e devolve a clave e o valor intermedio, deslocalizando calquera nodo deixado mentres deixa a edge correspondente no seu nodo pai colgando.
    ///
    /// # Safety
    /// - Debe haber outro KV na dirección percorrida.
    /// - Esa folla edge non a devolveu previamente a contraparte `next_unchecked` en ningunha copia das asas que se empregaban para atravesar a árbore.
    ///
    /// O único xeito seguro de continuar co controlador actualizado é comparalo, soltalo, chamar de novo a este método segundo as súas condicións de seguridade ou chamar ao homólogo `next_unchecked` segundo as súas condicións de seguridade.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Devolve a folla edge máis á esquerda dentro ou debaixo dun nodo, noutras palabras, a edge que precisa primeiro para navegar cara adiante (ou a última cando navega cara atrás).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Devolve a folla edge situada máis á dereita dentro ou por debaixo dun nodo, noutras palabras, a edge que necesitas por última vez para navegar cara adiante (ou primeiro para navegar cara atrás).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Visita os nodos de folla e os KV internos por orde de teclas ascendentes e tamén visita os nodos internos no seu conxunto nunha primeira orde de profundidade, o que significa que os nodos internos preceden aos seus KV individuais e aos seus nodos fillos.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Calcula o número de elementos nunha (sub) árbore.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Devolve a folla edge máis próxima a un KV para a navegación cara a adiante.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Devolve a folla edge máis próxima a un KV para a navegación cara atrás.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}