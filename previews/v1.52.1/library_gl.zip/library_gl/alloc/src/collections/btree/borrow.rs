use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modela un reborrow dalgunha referencia única, cando sabe que o reborrow e todos os seus descendentes (é dicir, todos os punteiros e referencias derivados dela) xa non se usarán nalgún momento, despois do cal quere empregar a referencia única orixinal de novo .
///
///
/// O comprobador de préstamos normalmente manexa este apilamento de préstamos, pero algúns fluxos de control que conseguen este apilamento son demasiado complicados para que o compilador poida seguir.
/// Un `DormantMutRef` permítelle comprobar o seu préstamo, aínda que expresa a súa natureza empilhada e encapsula o código de punteiro bruto necesario para facelo sen un comportamento indefinido.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Captura un préstamo único e volve prestalo de inmediato.
    /// Para o compilador, a vida útil da nova referencia é a mesma que a vida orixinal da referencia, pero promise para usala durante un período máis curto.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SEGURIDADE: mantemos o préstamo en toda a a través de `_marker` e expoñemos
        // só esta referencia, polo que é única.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Volve ao préstamo único capturado inicialmente.
    ///
    /// # Safety
    ///
    /// O reembolso debe ter rematado, é dicir, a referencia devolta por `new` e todos os punteiros e referencias derivados dela, xa non se deben usar.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SEGURIDADE: as nosas propias condicións de seguridade implican que esta referencia volve ser única.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;