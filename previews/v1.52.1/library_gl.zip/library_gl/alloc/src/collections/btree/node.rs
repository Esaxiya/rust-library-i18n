// Este é un intento de implementación que segue o ideal
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Dado que Rust non ten tipos dependentes e unha recursión polimórfica, conformámonos con moita inseguridade.
//

// Un dos principais obxectivos deste módulo é evitar a complexidade tratando a árbore como un contedor xenérico (se ten unha forma estraña) e evita tratar coa maioría dos invariantes da árbore B.
//
// Polo tanto, a este módulo non lle importa se as entradas están ordenadas, que nodos poden estar incompletos ou incluso o que significa que non están completos.Non obstante, confiamos nalgúns invariantes:
//
// - As árbores deben ter un uniforme depth/height.Isto significa que cada camiño ata unha folla dun determinado nodo ten exactamente a mesma lonxitude.
// - Un nodo de lonxitude `n` ten claves `n`, valores `n` e arestas `n + 1`.
//   Isto implica que incluso un nodo baleiro ten polo menos un edge.
//   Para un nodo folla, "having an edge" só significa que podemos identificar unha posición no nodo, xa que os bordos das follas están baleiros e non precisan representación de datos.
// Nun nodo interno, un edge identifica unha posición e contén un punteiro a un nodo fillo.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// A representación subxacente de nodos de follas e parte da representación de nodos internos.
struct LeafNode<K, V> {
    /// Queremos ser covariantes en `K` e `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// O índice deste nodo na matriz `edges` do nodo pai.
    /// `*node.parent.edges[node.parent_idx]` debería ser o mesmo que `node`.
    /// Isto só se garante que se inicialice cando `parent` non é nulo.
    parent_idx: MaybeUninit<u16>,

    /// O número de claves e valores que almacena este nodo.
    len: u16,

    /// As matrices que almacenan os datos reais do nodo.
    /// Só se inicializan e son válidos os primeiros elementos `len` de cada matriz.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inicializa un novo `LeafNode` no lugar.
    unsafe fn init(this: *mut Self) {
        // Como política xeral, deixamos campos sen inicializar se poden ser, xa que isto debería ser un pouco máis rápido e máis doado de rastrexar en Valgrind.
        //
        unsafe {
            // parent_idx, claves e vals son MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Crea un novo `LeafNode` en caixa.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// A representación subxacente de nodos internos.Como ocorre con `LeafNode`s, estes deberían ocultarse detrás de`BoxedNode`s para evitar deixar caer claves e valores non iniciados.
/// Calquera punteiro a un `InternalNode` pódese lanzar directamente a un punteiro á porción `LeafNode` subxacente do nodo, permitindo que o código actúe xenericamente sobre os nodos folla e internos sen ter que comprobar sequera a cal dos dous apunta un punteiro.
///
/// Esta propiedade está habilitada mediante o uso de `repr(C)`.
///
#[repr(C)]
// gdb_providers.py usa este nome de tipo para a introspección.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// As indicacións para os fillos deste nodo.
    /// `len + 1` destas considéranse inicializadas e válidas, excepto que preto do final, mentres a árbore se mantén mediante préstamo tipo `Dying`, algúns destes punteiros están colgantes.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Crea un novo `InternalNode` en caixa.
    ///
    /// # Safety
    /// Unha invariante de nodos internos é que teñen polo menos un edge inicializado e válido.
    /// Esta función non configura tal edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Só precisamos inicializar os datos;os bordos son MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Un punteiro xestionado e non nulo a un nodo.Este é un punteiro de propiedade a `LeafNode<K, V>` ou un punteiro de propiedade a `InternalNode<K, V>`.
///
/// Non obstante, `BoxedNode` non contén información sobre cal dos dous tipos de nodos realmente contén e, parcialmente debido a esta falta de información, non é un tipo separado e non ten destructor.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// O nodo raíz dunha árbore propiedade.
///
/// Teña en conta que este non ten un destructor e debe limparse manualmente.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Devolve unha nova árbore de propiedade, co seu propio nodo raíz que inicialmente está baleiro.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` non debe ser cero.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Préstase mutualmente o nodo raíz propiedade.
    /// A diferenza de `reborrow_mut`, isto é seguro porque o valor de retorno non se pode usar para destruír a raíz e non pode haber outras referencias á árbore.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Pódese prestar un pouco o nodo raíz propiedade.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Transita de xeito irreversible a unha referencia que permite o percorrido e ofrece métodos destrutivos e pouco máis.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Engade un novo nodo interno cun único edge que apunta ao nodo raíz anterior, fai dese nodo novo o nodo raíz e devólveo.
    /// Isto aumenta a altura 1 e é o oposto a `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, agás que esquecemos que somos internos agora:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Elimina o nodo raíz interno, usando o seu primeiro fillo como novo nodo raíz.
    /// Como só se pretende chamar cando o nodo raíz só ten un fillo, non se fai limpeza en ningunha das claves, valores e outros fillos.
    ///
    /// Isto diminúe a altura en 1 e é o oposto a `push_internal_level`.
    ///
    /// Require acceso exclusivo ao obxecto `Root` pero non ao nodo raíz;
    /// non invalidará outros identificadores ou referencias ao nodo raíz.
    ///
    /// Panics se non hai nivel interno, é dicir, se o nodo raíz é unha folla.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SEGURIDADE: afirmamos ser internos.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SEGURIDADE: tomamos prestado exclusivamente `self` e o seu tipo de préstamo é exclusivo.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SEGURIDADE: o primeiro edge sempre se inicializa.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` sempre é covariante en `K` e `V`, incluso cando o `BorrowType` é `Mut`.
// Isto é técnicamente incorrecto, pero non pode producir ningunha seguridade debido ao uso interno de `NodeRef` porque seguimos completamente xenéricos sobre `K` e `V`.
//
// Non obstante, sempre que un tipo público envolve `NodeRef`, asegúrese de que ten a varianza correcta.
//
/// Unha referencia a un nodo.
///
/// Este tipo ten unha serie de parámetros que controlan o seu funcionamento:
/// - `BorrowType`: Un tipo ficticio que describe o tipo de préstamo e leva toda a vida.
///    - Cando este é `Immut<'a>`, o `NodeRef` actúa aproximadamente como `&'a Node`.
///    - Cando este é `ValMut<'a>`, o `NodeRef` actúa aproximadamente como `&'a Node` con respecto ás teclas e á estrutura da árbore, pero tamén permite que coexistan moitas referencias mudables a valores en toda a árbore.
///    - Cando este é `Mut<'a>`, o `NodeRef` actúa aproximadamente como `&'a mut Node`, aínda que os métodos de inserción permiten a coexistencia dun punteiro mutable a un valor.
///    - Cando se trata de `Owned`, o `NodeRef` actúa aproximadamente como `Box<Node>`, pero non ten un destructor e debe limparse manualmente.
///    - Cando este é `Dying`, o `NodeRef` aínda actúa aproximadamente como `Box<Node>`, pero ten métodos para destruír a árbore pouco a pouco e os métodos comúns, aínda que non están marcados como inseguros para chamar, poden invocar UB se se chama incorrectamente.
///
///   Dado que calquera `NodeRef` permite navegar pola árbore, `BorrowType` aplícase efectivamente a toda a árbore, non só ao nodo en si.
/// - `K` e `V`: son os tipos de claves e valores almacenados nos nodos.
/// - `Type`: Pode ser `Leaf`, `Internal` ou `LeafOrInternal`.
/// Cando este é `Leaf`, o `NodeRef` apunta a un nodo folla, cando é `Internal` o `NodeRef` apunta a un nodo interno e, cando este é `LeafOrInternal`, o `NodeRef` pode estar apuntando a calquera dos dous nodos.
///   `Type` chámase `NodeType` cando se usa fóra de `NodeRef`.
///
/// Tanto `BorrowType` como `NodeType` restrinxen os métodos que implementamos para explotar a seguridade do tipo estático.Hai limitacións na forma en que podemos aplicar estas restricións:
/// - Para cada parámetro tipo, só podemos definir un método xenéricamente ou para un tipo particular.
/// Por exemplo, non podemos definir un método como `into_kv` de xeito xenérico para todos os `BorrowType`, nin unha vez para todos os tipos que levan toda a vida, porque queremos que devolva referencias `&'a`.
///   Polo tanto, definímolo só para o tipo menos potente `Immut<'a>`.
/// - Non podemos obter a coerción implícita de digamos `Mut<'a>` a `Immut<'a>`.
///   Polo tanto, temos que chamar explícitamente a `reborrow` nun `NodeRef` máis potente para chegar a un método como `into_kv`.
///
/// Todos os métodos en `NodeRef` que devolven algún tipo de referencia, ben:
/// - Tome `self` por valor e devolva a vida útil que leva `BorrowType`.
///   Ás veces, para invocar tal método, necesitamos chamar ao `reborrow_mut`.
/// - Tome `self` como referencia e (implicitly) devolve a vida útil da referencia en lugar da vida útil que leva `BorrowType`.
/// Deste xeito, o comprobador de préstamos garante que o `NodeRef` permanecerá prestado sempre que se use a referencia devolta.
///   Os métodos que soportan a inserción dobran esta regra devolvendo un punteiro en bruto, é dicir, unha referencia sen vida.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// O número de niveis separados entre o nodo e o nivel de follas, unha constante do nodo que non pode ser descrita por completo por `Type` e que o propio nodo non almacena.
    /// Só necesitamos almacenar a altura do nodo raíz e derivar a altura de todos os outros nodos del.
    /// Debe ser cero se `Type` é `Leaf` e non é cero se `Type` é `Internal`.
    ///
    ///
    height: usize,
    /// O punteiro cara á folla ou ao nodo interno.
    /// A definición de `InternalNode` garante que o punteiro sexa válido de calquera xeito.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Descomprimir unha referencia de nodo que se empaquetou como `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Expón os datos dun nodo interno.
    ///
    /// Devolve un ptr en bruto para evitar invalidar outras referencias a este nodo.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SEGURIDADE: o tipo de nodo estático é `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Presta acceso exclusivo aos datos dun nodo interno.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Atopa a lonxitude do nodo.Este é o número de claves ou valores.
    /// O número de arestas é `len() + 1`.
    /// Teña en conta que, a pesar de ser seguro, chamar a esta función pode ter o efecto secundario de invalidar as referencias mudables que creou o código non seguro.
    ///
    pub fn len(&self) -> usize {
        // De xeito crucial, só accedemos ao campo `len` aquí.
        // Se BorrowType é marker::ValMut, pode haber referencias mudables pendentes a valores que non debemos invalidar.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Devolve o número de niveis separados entre o nodo e as follas.
    /// A altura cero significa que o nodo é unha folla.
    /// Se imaxinas árbores coa raíz na parte superior, o número di a que cota aparece o nodo.
    /// Se imaxinas árbores con follas na parte superior, o número di que altura se estende a árbore por riba do nó.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Elimina temporalmente outra referencia inmutable ao mesmo nodo.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Expón a porción de folla de calquera folla ou nodo interno.
    ///
    /// Devolve un ptr en bruto para evitar invalidar outras referencias a este nodo.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // O nodo debe ser válido para polo menos a parte LeafNode.
        // Esta non é unha referencia no tipo NodeRef porque non sabemos se debería ser única ou compartida.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Atopa o pai do nodo actual.
    /// Devolve `Ok(handle)` se o nodo actual ten realmente un pai, onde `handle` apunta ao edge do pai que apunta ao nodo actual.
    ///
    /// Devolve `Err(self)` se o nodo actual non ten pai, devolvendo o `NodeRef` orixinal.
    ///
    /// O nome do método supón que imaxes árbores co nodo raíz na parte superior.
    ///
    /// `edge.descend().ascend().unwrap()` e `node.ascend().unwrap().descend()` non deberían facer nada despois do éxito.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Necesitamos empregar punteiros en bruto para nodos porque, se BorrowType é marker::ValMut, pode haber referencias mutables pendentes a valores que non debemos invalidar.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Teña en conta que `self` debe ser non baleiro.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Teña en conta que `self` debe ser non baleiro.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Expón a porción de folla de calquera folla ou nodo interno nunha árbore inmutable.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SEGURIDADE: non pode haber referencias mutables nesta árbore prestadas como `Immut`.
        unsafe { &*ptr }
    }

    /// Prende unha vista das claves almacenadas no nodo.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Semellante a `ascend`, obtén unha referencia ao nodo pai dun nodo, pero tamén deslocala o nodo actual no proceso.
    /// Isto non é seguro porque o nodo actual aínda será accesible a pesar de estar deslocalizado.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Asegura ao compilador de forma segura a información estática de que este nodo é un `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Afirma ao compilador de forma segura a información estática de que este nodo é un `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Elimina temporalmente outra referencia mutable ao mesmo nodo.Coidado, xa que este método é moi perigoso, dobremente, xa que pode que non pareza perigoso de inmediato.
    ///
    /// Debido a que os punteiros mutables poden percorrer calquera lugar arredor da árbore, o punteiro devolto pode usarse facilmente para facer que o punteiro orixinal estea colgado, fóra dos límites ou non sexa válido segundo as regras de préstamo apilado.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) considere engadir outro parámetro de tipo a `NodeRef` que restrinxa o uso de métodos de navegación en punteiros de novo, evitando esta seguridade.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Préstase acceso exclusivo á porción de folla de calquera folla ou nodo interno.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SEGURIDADE: temos acceso exclusivo a todo o nodo.
        unsafe { &mut *ptr }
    }

    /// Ofrece acceso exclusivo á porción de folla de calquera folla ou nodo interno.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SEGURIDADE: temos acceso exclusivo a todo o nodo.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Préstase acceso exclusivo a un elemento da área de almacenamento de claves.
    ///
    /// # Safety
    /// `index` está dentro dos límites de 0..CAPACIDADE
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SEGURIDADE: o interlocutor non poderá chamar por si mesmo a outros métodos
        // ata que se elimine a referencia da porción clave, xa que temos acceso único durante a vida do préstamo.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Presta acceso exclusivo a un elemento ou porción da área de almacenamento de valores do nodo.
    ///
    /// # Safety
    /// `index` está dentro dos límites de 0..CAPACIDADE
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SEGURIDADE: o interlocutor non poderá chamar por si mesmo a outros métodos
        // ata que se elimine a referencia da porción de valor, xa que temos acceso único durante a vida do préstamo.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Préstase acceso exclusivo a un elemento ou porción da área de almacenamento do nodo para o contido edge.
    ///
    /// # Safety
    /// `index` está dentro dos límites de 0..CAPACIDADE + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SEGURIDADE: o interlocutor non poderá chamar por si mesmo a outros métodos
        // ata que se elimine a referencia da porción edge, xa que temos acceso único durante a vida do préstamo.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - O nodo ten máis de elementos inicializados `idx`.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Só creamos unha referencia ao único elemento que nos interesa, para evitar facer alias con referencias pendentes a outros elementos, en particular, os devoltos ao interlocutor en anteriores iteracións.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Debemos coaccionar aos indicadores de matriz sen tamaño debido ao problema Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Presta acceso exclusivo á lonxitude do nodo.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Establece a ligazón do nodo co seu pai edge, sen invalidar outras referencias ao nodo.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Borra a ligazón da raíz co seu pai edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Engade un par clave-valor ao final do nodo.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Cada elemento devolto por `range` é un índice edge válido para o nodo.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Engade un par clave-valor e un edge para ir á dereita dese par, ao final do nodo.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Comproba se un nodo é un nodo `Internal` ou un nodo `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Unha referencia a un par clave-valor específico ou edge dentro dun nodo.
/// O parámetro `Node` debe ser un `NodeRef`, mentres que o `Type` pode ser `KV` (que significa un identificador nun par clave-valor) ou `Edge` (que significa un identificador nun edge).
///
/// Teña en conta que incluso os nodos `Leaf` poden ter asas `Edge`.
/// En lugar de representar un punteiro a un nodo fillo, estes representan os espazos onde irían os punteiros infantís entre os pares clave-valor.
/// Por exemplo, nun nodo con lonxitude 2, habería 3 posibles localizacións edge, unha á esquerda do nodo, outra entre os dous pares e outra á dereita do nodo.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Non necesitamos a xeneralidade completa de `#[derive(Clone)]`, xa que a única vez que `Node` será "Clonable" é cando é unha referencia inmutable e, polo tanto, `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Recupera o nodo que contén o par edge ou par clave-valor ao que apunta este identificador.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Devolve a posición deste identificador no nodo.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Crea un novo identificador para un par clave-valor en `node`.
    /// Non é seguro porque o interlocutor debe asegurarse de que `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Pode ser unha implementación pública de PartialEq, pero só se usa neste módulo.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Saca temporalmente outro identificador inmutable no mesmo lugar.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Non podemos usar Handle::new_kv ou Handle::new_edge porque non sabemos o noso tipo
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Asegura ao compilador de forma segura a información estática de que o nodo do identificador é un `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Elimina temporalmente outro identificador mutable na mesma situación.
    /// Coidado, xa que este método é moi perigoso, dobremente, xa que pode que non pareza perigoso de inmediato.
    ///
    ///
    /// Para máis detalles, consulte `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Non podemos usar Handle::new_kv ou Handle::new_edge porque non sabemos o noso tipo
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Crea un novo identificador para un edge en `node`.
    /// Non é seguro porque o interlocutor debe asegurarse de que `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Dado un índice edge onde queremos inserir nun nodo cheo ata a capacidade, calcula un índice KV sensato dun punto dividido e onde realizar a inserción.
///
/// O obxectivo do punto de división é que a súa clave e valor acaban nun nodo pai;
/// as teclas, valores e bordos á esquerda do punto de división convértense no fillo esquerdo;
/// as teclas, valores e arestas á dereita do punto de división convértense no fillo adecuado.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // O número Rust #74834 trata de explicar estas regras simétricas.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Insire un novo par clave-valor entre os pares clave-valor á dereita e á esquerda deste edge.
    /// Este método supón que hai espazo suficiente no nodo para que se axuste o novo par.
    ///
    /// O punteiro devolto apunta ao valor inserido.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Insire un novo par clave-valor entre os pares clave-valor á dereita e á esquerda deste edge.
    /// Este método divide o nodo se non hai espazo suficiente.
    ///
    /// O punteiro devolto apunta ao valor inserido.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Corrixe o punteiro e o índice pai no nodo fillo ao que enlaza este edge.
    /// Isto é útil cando se cambiou a orde dos bordos,
    fn correct_parent_link(self) {
        // Crea un backpointer sen invalidar outras referencias ao nodo.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Insire un novo par clave-valor e un edge que irá á dereita dese novo par entre este edge e o par clave-valor á dereita deste edge.
    /// Este método supón que hai espazo suficiente no nodo para que se axuste o novo par.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Insire un novo par clave-valor e un edge que irá á dereita dese novo par entre este edge e o par clave-valor á dereita deste edge.
    /// Este método divide o nodo se non hai espazo suficiente.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Insire un novo par clave-valor entre os pares clave-valor á dereita e á esquerda deste edge.
    /// Este método divide o nodo se non hai espazo suficiente e tenta inserir a parte dividida no nodo pai de xeito recursivo, ata alcanzar a raíz.
    ///
    ///
    /// Se o resultado devolto é un `Fit`, o nodo do seu identificador pode ser o nodo de edge ou un devanceiro.
    /// Se o resultado devolto é un `Split`, o campo `left` será o nodo raíz.
    /// O punteiro devolto apunta ao valor inserido.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Atopa o nodo sinalado por este edge.
    ///
    /// O nome do método supón que imaxes árbores co nodo raíz na parte superior.
    ///
    /// `edge.descend().ascend().unwrap()` e `node.ascend().unwrap().descend()` non deberían facer nada despois do éxito.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Necesitamos empregar punteiros en bruto para nodos porque, se BorrowType é marker::ValMut, pode haber referencias mutables pendentes a valores que non debemos invalidar.
        // Non hai preocupación por acceder ao campo de altura porque se copia ese valor.
        // Teña en conta que, unha vez que se desferencia o punteiro do nodo, accedemos á matriz de bordos cunha referencia (Rust número #73987) e invalidamos calquera outra referencia ou dentro da matriz, se hai algunha.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Non podemos chamar a métodos de clave e valor separados, porque chamar ao segundo invalida a referencia devolta polo primeiro.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Substitúe a clave e o valor ao que se refire o identificador KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Axuda ás implementacións de `split` para un `NodeType` particular coidando os datos de follas.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Divide o nodo subxacente en tres partes:
    ///
    /// - O nodo truncase para só conter os pares clave-valor á esquerda deste identificador.
    /// - Extrae a clave e o valor que apunta este identificador.
    /// - Todos os pares clave-valor á dereita deste identificador colócanse nun nodo recentemente asignado.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Elimina o par clave-valor que apunta este identificador e devólveo, xunto co edge no que se colapsou o par clave-valor.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Divide o nodo subxacente en tres partes:
    ///
    /// - O nodo truncase para conter só os bordos e os pares clave-valor á esquerda deste identificador.
    /// - Extrae a clave e o valor que apunta este identificador.
    /// - Todos os bordos e os pares clave-valor á dereita deste identificador colócanse nun nodo recentemente asignado.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Representa unha sesión para avaliar e realizar unha operación de equilibrio en torno a un par clave-valor interno.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Elixe un contexto de equilibrio que implica o nodo cando é neno, polo tanto, entre o KV inmediatamente á esquerda ou á dereita no nodo pai.
    /// Devolve un `Err` se non hai pai.
    /// Panics se o pai está baleiro.
    ///
    /// Prefire o lado esquerdo, para ser óptimo se o nodo dado está dalgún xeito insuficiente, o que significa que só ten menos elementos que o seu irmán esquerdo e o seu irmán dereito, se existen.
    /// Nese caso, a fusión co irmán esquerdo é máis rápida, xa que só precisamos mover os N elementos do nodo, en vez de desprazalos á dereita e mover máis que N elementos diante.
    /// Roubar ao irmán esquerdo tamén é normalmente máis rápido, xa que só necesitamos desprazar os N elementos do nodo cara á dereita, en lugar de desprazar polo menos N dos elementos do irmán cara á esquerda.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Devolve se é posible a fusión, é dicir, se hai espazo suficiente nun nodo para combinar o KV central con ambos nodos fillos adxacentes.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Realiza unha combinación e permite que un peche decida que devolver.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SEGURIDADE: a altura dos nodos que se fusionan é inferior á altura
                // do nodo deste edge, polo tanto por riba de cero, polo que son internos.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Fusiona o par clave-valor do pai e os dous nodos fillos adxacentes no nodo fillo esquerdo e devolve o nodo pai reducido.
    ///
    ///
    /// Panics a menos que `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Fusiona o par clave-valor do pai e os dous nodos fillos adxacentes no nodo fillo esquerdo e devolve ese nodo fillo.
    ///
    ///
    /// Panics a menos que `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Combina o par clave-valor do pai e os dous nodos fillos adxacentes no nodo fillo esquerdo e devolve o identificador edge nese nodo fillo onde rematou o fillo seguido edge,
    ///
    ///
    /// Panics a menos que `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Elimina un par clave-valor do fillo esquerdo e colócao no almacenamento clave-valor do pai, mentres empurra o par vello clave-valor pai cara ao fillo dereito.
    ///
    /// Devolve un identificador ao edge no fillo dereito correspondente a onde rematou o edge orixinal especificado por `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Elimina un par clave-valor do fillo dereito e colócao no almacenamento de valor clave do pai, mentres empurra o par vello clave-valor pai ao fillo esquerdo.
    ///
    /// Devolve un identificador ao edge no fillo esquerdo especificado por `track_left_edge_idx`, que non se moveu.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Isto fai roubar de xeito similar ao `steal_left` pero rouba varios elementos á vez.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Asegúrese de que podemos roubar con seguridade.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Mover datos de follas.
            {
                // Deixa espazo aos elementos roubados no fillo adecuado.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Move elementos do fillo esquerdo ao dereito.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Move o par máis roubado á esquerda ao pai.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Move o par clave-valor dos pais ao fillo correcto.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Deixa espazo aos bordos roubados.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Roubar bordos.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// O clon simétrico de `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Asegúrese de que podemos roubar con seguridade.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Mover datos de follas.
            {
                // Move o par máis roubado á dereita ao pai.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Move o par clave-valor dos pais ao fillo esquerdo.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Move elementos do fillo dereito ao esquerdo.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Enche o espazo onde antes estaban os elementos roubados.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Roubar bordos.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Enche o oco onde antes estaban os bordos roubados.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Elimina calquera información estática que afirme que este nodo é un nodo `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Elimina calquera información estática que afirme que este nodo é un nodo `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Comproba se o nodo subxacente é un nodo `Internal` ou un nodo `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Move o sufixo despois de `self` dun nodo a outro.`right` debe estar baleiro.
    /// O primeiro edge de `right` permanece inalterado.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Resultado da inserción, cando un nodo necesitaba expandirse máis alá da súa capacidade.
pub struct SplitResult<'a, K, V, NodeType> {
    // Nodo alterado na árbore existente con elementos e bordos que pertencen á esquerda de `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Algunhas claves e valores separáronse, para inserir noutros lugares.
    pub kv: (K, V),
    // Nodo novo de propiedade, sen unir, con elementos e arestas que pertencen á dereita de `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Se as referencias de nodos deste tipo de préstamo permiten percorrer a outros nodos da árbore.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal non é necesario, ocorre usando o resultado de `borrow_mut`.
        // Ao desactivar o percorrido e crear só novas referencias ás raíces, sabemos que cada referencia do tipo `Owned` é a un nodo raíz.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Insire un valor nunha porción de elementos inicializados seguidos dun elemento non inicializado.
///
/// # Safety
/// A porción ten máis de `idx` elementos.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Elimina e devolve un valor dunha porción de todos os elementos inicializados, deixando atrás un elemento non inicializado final.
///
///
/// # Safety
/// A porción ten máis de `idx` elementos.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Move os elementos nunha porción de posicións `distance` cara á esquerda.
///
/// # Safety
/// A porción ten polo menos elementos `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Desplaza os elementos nunha porción de posición `distance` cara á dereita.
///
/// # Safety
/// A porción ten polo menos elementos `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Move todos os valores dunha porción de elementos inicializados a unha porción de elementos non inicializados, deixando atrás `src` como todos sen inicializar.
///
/// Funciona como `dst.copy_from_slice(src)` pero non require que `T` sexa `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;