use core::intrinsics;
use core::mem;
use core::ptr;

/// Isto substitúe o valor detrás da referencia única `v` chamando á función correspondente.
///
///
/// Se se produce un panic no peche do `change`, abortarase todo o proceso.
#[allow(dead_code)] // mantéñase como ilustración e para o uso de future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Isto substitúe o valor detrás da referencia única `v` chamando á función correspondente e devolve un resultado obtido no camiño.
///
///
/// Se se produce un panic no peche do `change`, abortarase todo o proceso.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}