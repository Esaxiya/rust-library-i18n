use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Engade todos os pares clave-valor da unión de dous iteradores ascendentes, incrementando unha variable `length` ao longo do camiño.Isto último facilita que o interlocutor evite unha fuga cando un manipulador de pingas entra en pánico.
    ///
    /// Se ambos iteradores producen a mesma clave, este método elimina o par do iterador esquerdo e engade o par do iterador dereito.
    ///
    /// Se queres que a árbore acabe nunha orde estritamente ascendente, como para un `BTreeMap`, ambos iteradores deberían producir claves en orde estritamente ascendente, cada unha delas superior a todas as teclas da árbore, incluídas as teclas que xa están na árbore ao entrar.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Preparámonos para combinar `left` e `right` nunha secuencia ordenada en tempo lineal.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Mentres tanto, construímos unha árbore a partir da secuencia ordenada en tempo lineal.
        self.bulk_push(iter, length)
    }

    /// Empuxa todos os pares clave-valor ata o final da árbore, incrementando unha variable `length` ao longo do camiño.
    /// Isto último facilita que o interlocutor evite unha fuga cando o iterador entra en pánico.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Repita todos os pares clave-valor, empurrándoos cara aos nodos do nivel correcto.
        for (key, value) in iter {
            // Tente empuxar o par clave-valor no nodo folla actual.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Non queda espazo, sube e empurra alí.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Atopou un nodo con espazo á esquerda, empurre aquí.
                                open_node = parent;
                                break;
                            } else {
                                // Sobe de novo.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Estamos na parte superior, creamos un novo nodo raíz e empurramos alí.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Empuxe o par clave-valor e o novo subarbre dereito.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Vai de novo á folla máis dereita.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Aumenta a lonxitude de cada iteración, para asegurarte de que o mapa elimina os elementos engadidos aínda que avance no iterador.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Un iterador para combinar dúas secuencias ordenadas nunha soa
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Se dúas claves son iguais, devolve o par clave-valor da fonte correcta.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}