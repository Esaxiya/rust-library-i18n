//! Rebanadas de cadeas Unicode.
//!
//! *[See also the `str` primitive type](str).*
//!
//! O tipo `&str` é un dos dous tipos de cordas principais, sendo o outro `String`.
//! A diferenza do seu homólogo `String`, o seu contido está prestado.
//!
//! # Uso básico
//!
//! Unha declaración básica de cadea de tipo `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Aquí declaramos unha cadea literal, tamén coñecida como unha porción de cadea.
//! Os literales de cadea teñen unha vida útil estática, o que significa que a cadea `hello_world` está garantida para a duración de todo o programa.
//!
//! Tamén podemos especificar de forma explícita a vida de `hello_world`:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Moitos dos usos deste módulo só se usan na configuración da proba.
// É máis limpo simplemente desactivar o aviso unused_imports que solucionalo.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` en `Concat<str>` non ten sentido aquí.
/// Este parámetro tipo de trait só existe para habilitar outro impl.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // os lazos con tamaños codificados son máis rápidos especializan os casos con pequenas lonxitudes de separador
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // alternativa de tamaño non cero arbitraria
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Implementación de unión optimizada que funciona tanto para Vec<T>(T: Copy) e vec interior de String Actualmente (2018-05-13) hai un erro con inferencia de tipo e especialización (ver número #36262) Por esta razón SliceConcat<T>non está especializado en T: Copy e SliceConcat<str>é o único usuario desta función.
// Déixase no seu lugar durante o tempo en que se soluciona.
//
// os límites para String-join son S: Borrow<str>e para Vec-join Borrow <[T]> [T] e str impl impl AsRef <[T]> para algúns T
// => s.borrow().as_ref() e sempre temos rodajas
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // a primeira porción é a única sen que o preceda un separador
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // calcula a lonxitude total exacta do Vec unido se o cálculo `len` desborda, panic quedariamos sen memoria de todos os xeitos e o resto da función require todo o Vec pre-asignado por seguridade
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // prepara un búfer non inicializado
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // copiar o separador e cortar sen límites as comprobacións xeran bucles con compensacións codificadas para pequenos separadores posibles melloras masivas (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Unha aplicación de préstamo estraña pode devolver diferentes franxas para o cálculo da lonxitude e a copia real.
        //
        // Asegúrese de que non lle expoñemos á chamada os bytes non inicializados.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Métodos para cortar cordas.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Converte un `Box<str>` nun `Box<[u8]>` sen copiar nin asignar.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Substitúe todas as coincidencias dun patrón por outra cadea.
    ///
    /// `replace` crea un novo [`String`] e copia nela os datos desta porción de cadea.
    /// Ao facelo, tenta atopar coincidencias dun patrón.
    /// Se atopa algún, substitúeos pola porción de cadea de substitución.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Cando o patrón non coincide:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Substitúe as primeiras N coincidencias dun patrón por outra cadea.
    ///
    /// `replacen` crea un novo [`String`] e copia nela os datos desta porción de cadea.
    /// Ao facelo, tenta atopar coincidencias dun patrón.
    /// Se atopa algún, substitúe-los pola porción de cadea de substitución como máximo `count` veces.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Cando o patrón non coincide:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Espero reducir os tempos de reasignación
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Devolve o equivalente en minúscula desta porción de cadea, como un novo [`String`].
    ///
    /// 'Lowercase' defínese segundo os termos da propiedade núcleo derivada Unicode `Lowercase`.
    ///
    /// Dado que algúns caracteres poden expandirse en varios caracteres cando cambian de maiúsculas e minúsculas, esta función devolve un [`String`] no canto de modificar o parámetro no lugar.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Un exemplo complicado, con sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // pero ao final dunha palabra, é ς, non σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Os idiomas sen maiúsculas non se cambian:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ mapea a σ, excepto ao final dunha palabra onde mapea a ς.
                // Este é o único mapeado (contextual) condicional pero independente da linguaxe en `SpecialCasing.txt`, polo que codifícao en vez de ter un mecanismo "condition" xenérico.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // para a definición de `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Devolve o equivalente en maiúscula desta porción de cadea, como un novo [`String`].
    ///
    /// 'Uppercase' defínese segundo os termos da propiedade núcleo derivada Unicode `Uppercase`.
    ///
    /// Dado que algúns caracteres poden expandirse en varios caracteres cando cambian de maiúsculas e minúsculas, esta función devolve un [`String`] no canto de modificar o parámetro no lugar.
    ///
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Non se cambian os guións sen maiúsculas:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Un personaxe pode converterse en múltiple:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Converte un [`Box<str>`] nun [`String`] sen copiar nin asignar.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Crea un novo [`String`] repetindo unha cadea `n` veces.
    ///
    /// # Panics
    ///
    /// Esta función será panic se a capacidade rebordaría.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// A panic despois do desbordamento:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Devolve unha copia desta cadea onde cada carácter está asignado ao seu equivalente en maiúsculas ASCII.
    ///
    ///
    /// As letras ASCII de 'a' a 'z' están mapeadas de 'A' a 'Z', pero as letras non ASCII están inalteradas.
    ///
    /// Para usar maiúsculas o valor no lugar, usa [`make_ascii_uppercase`].
    ///
    /// Para usar maiúsculas caracteres ASCII ademais de caracteres non ASCII, use [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() conserva o invariante UTF-8.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Devolve unha copia desta cadea onde cada carácter está asignado ao seu equivalente en minúscula ASCII.
    ///
    ///
    /// As letras ASCII de 'A' a 'Z' están mapeadas de 'a' a 'z', pero as letras non ASCII están inalteradas.
    ///
    /// Para minúsculas no seu lugar, use [`make_ascii_lowercase`].
    ///
    /// Para usar caracteres ASCII minúsculos ademais de caracteres non ASCII, use [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() conserva o invariante UTF-8.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Converte unha porción de bytes en caixa nunha porción de cadea sen comprobar que a cadea contén UTF-8 válido.
///
///
/// # Examples
///
/// Uso básico:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}