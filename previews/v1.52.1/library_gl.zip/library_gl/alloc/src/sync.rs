#![stable(feature = "rust1", since = "1.0.0")]

//! Punteros de conteo de referencias seguros de fíos.
//!
//! Consulte a documentación do [`Arc<T>`][Arc] para obter máis detalles.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Un límite mínimo na cantidade de referencias que se poden facer a un `Arc`.
///
/// Se superas este límite abortarás o teu programa (aínda que non necesariamente) con referencias _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer non admite valos de memoria.
// Para evitar informes falsos positivos na implementación de Arc/Weak, no seu lugar use cargas atómicas para a sincronización.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Un punteiro de conteo de referencias seguro de fíos.'Arc' significa "Atomically Reference Counted".
///
/// O tipo `Arc<T>` proporciona a propiedade compartida dun valor do tipo `T`, asignado no montón.A invocación de [`clone`][clone] en `Arc` produce unha nova instancia de `Arc`, que apunta á mesma asignación no heap que a fonte `Arc`, mentres aumenta o reconto de referencia.
/// Cando se destrúe o último punteiro `Arc` a unha asignación determinada, tamén se elimina o valor almacenado nesa asignación (a miúdo denominado "inner value").
///
/// As referencias compartidas en Rust non permiten a mutación por defecto e `Arc` non é unha excepción: normalmente non se pode obter unha referencia mutable a algo dentro dun `Arc`.Se precisa mutar a través dun `Arc`, use [`Mutex`][mutex], [`RwLock`][rwlock] ou un dos tipos [`Atomic`][atomic].
///
/// ## Seguridade do fío
///
/// A diferenza de [`Rc<T>`], `Arc<T>` usa operacións atómicas para o seu reconto de referencias.Isto significa que é apto para fíos.A desvantaxe é que as operacións atómicas son máis caras que os accesos de memoria comúns.Se non está a compartir as asignacións contadas con referencias entre fíos, considere usar [`Rc<T>`] para gastos xerais inferiores.
/// [`Rc<T>`] é un valor predeterminado seguro, porque o compilador detectará calquera intento de enviar un [`Rc<T>`] entre fíos.
/// Non obstante, unha biblioteca pode escoller `Arc<T>` para ofrecer aos consumidores de biblioteca máis flexibilidade.
///
/// `Arc<T>` implementará [`Send`] e [`Sync`] sempre que o `T` implemente [`Send`] e [`Sync`].
/// Por que non se pode poñer un tipo `T` que non sexa seguro de fíos nun `Arc<T>` para facelo seguro?Isto pode ser un pouco contra-intuitivo ao principio: á fin e ao cabo, non é certo o punto de seguridade do fío `Arc<T>`?A clave é esta: `Arc<T>` fai que sexa seguro de fíos de ter a propiedade múltiple dos mesmos datos, pero non engade seguridade de fíos aos seus datos.
///
/// Considere `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] non é [`Sync`], e se `Arc<T>` sempre foi [`Send`], `Arc <` [`RefCell<T>"]">`tamén o sería.
/// Pero entón teriamos un problema:
/// [`RefCell<T>`] non é seguro para fíos;realiza un seguimento do reconto de endebedamento mediante operacións non atómicas.
///
/// Ao final, isto significa que pode que teña que emparellar `Arc<T>` con algún tipo de [`std::sync`], normalmente [`Mutex<T>`][mutex].
///
/// ## Ciclos de ruptura con `Weak`
///
/// O método [`downgrade`][downgrade] pode usarse para crear un punteiro [`Weak`] que non sexa propietario.Un punteiro [`Weak`] pode [[actualizar]][actualizar] d a un `Arc`, pero devolverá [`None`] se o valor almacenado na asignación xa se eliminou.
/// Noutras palabras, os punteiros `Weak` non manteñen vivo o valor dentro da asignación;con todo,*si* manteñen viva a asignación (o almacén de apoio para o valor).
///
/// Nunca se repartirá un ciclo entre punteiros `Arc`.
/// Por esta razón, [`Weak`] úsase para romper ciclos.Por exemplo, unha árbore podería ter fortes punteiros `Arc` desde nodos pais ata fillos, e punteiros [`Weak`] de fillos de volta a pais.
///
/// # Referencias de clonación
///
/// A creación dunha nova referencia a partir dun punteiro contado con referencias existente faise mediante o `Clone` trait implementado para [`Arc<T>`][Arc] e [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // As dúas sintaxes seguintes son equivalentes.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b e foo son todos arcos que apuntan á mesma situación de memoria
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` desferencia automaticamente a `T` (a través do [`Deref`][deref] trait), polo que pode chamar aos métodos de `T` cun valor de tipo `Arc<T>`.Para evitar choques de nomes cos métodos de "T", os métodos de `Arc<T>` en si son funcións asociadas, chamadas usando [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>As implementacións de traits como `Clone` tamén se poden chamar mediante sintaxe totalmente cualificada.
/// Algunhas persoas prefiren usar sintaxe totalmente cualificada, mentres que outras prefiren usar sintaxe de método de chamada.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Sintaxe de método de chamada
/// let arc2 = arc.clone();
/// // Sintaxe totalmente cualificada
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] non fai a autoreferencia a `T`, porque o valor interno xa se eliminou.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Compartir algúns datos inmutables entre fíos:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Ten en conta que **non** executamos estas probas aquí.
// Os construtores de windows quedan moi descontentos se un fío é superior ao fío principal e despois sae ao mesmo tempo (algo bloqueado), polo que só evitamos isto ao non realizar estas probas.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Compartir un [`AtomicUsize`] mutable:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Vexa o [`rc` documentation][rc_examples] para obter máis exemplos de contas de referencias en xeral.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` é unha versión de [`Arc`] que ten unha referencia non propietaria á asignación xestionada.
/// Accédese á asignación chamando a [`upgrade`] no punteiro `Weak`, que devolve unha [`Opción`]`<`[`Arc`] `<T>>`.
///
/// Dado que unha referencia `Weak` non conta na propiedade, non impedirá que se elimine o valor almacenado na asignación e o propio `Weak` non ofrece garantías sobre o valor que aínda está presente.
///
/// Así, pode devolver [`None`] cando [`actualizar`] d.
/// Non obstante, teña en conta que unha referencia `Weak`*non* impide que a asignación en si (o almacén de respaldo) se reparte.
///
/// Un punteiro `Weak` é útil para manter unha referencia temporal á asignación xestionada por [`Arc`] sen evitar que se caia o seu valor interno.
/// Tamén se usa para evitar referencias circulares entre punteiros [`Arc`], xa que as mutuas referencias nunca permitirían deixar caer ningún dos dous [`Arc`].
/// Por exemplo, unha árbore podería ter fortes punteiros [`Arc`] desde nodos pais ata nenos, e punteiros `Weak` de nenos de volta aos seus pais.
///
/// O xeito típico de obter un punteiro `Weak` é chamar ao [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Este é un `NonNull` que permite optimizar o tamaño deste tipo en enumeracións, pero non é necesariamente un punteiro válido.
    //
    // `Weak::new` configura isto en `usize::MAX` para que non precise asignar espazo no montón.
    // Ese non é un valor que un punteiro real terá porque RcBox ten alineación polo menos 2.
    // Isto só é posible cando `T: Sized`;`T` sen tamaño nunca colga.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Isto é a proba de repr(C) a future contra posibles reordenamentos de campo, o que interferiría co [into|from]_raw() doutro xeito seguro de tipos internos transmutables.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // o valor usize::MAX actúa como un centinela para "locking" temporalmente a posibilidade de actualizar punteiros débiles ou degradar outros fortes;úsase para evitar carreiras en `make_mut` e `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Constrúe un novo `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Inicia o número de punteiros débiles como 1, que é o punteiro débil que teñen todos os punteiros fortes (kinda); consulta std/rc.rs para máis información.
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Constrúe un novo `Arc<T>` usando unha feble referencia a si mesmo.
    /// Se intenta actualizar a referencia débil antes de que devolva esta función, obterá un valor `None`.
    /// Non obstante, a referencia feble pode clonarse libremente e almacenarse para usala posteriormente.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Constrúe o interior no estado "uninitialized" cunha única referencia débil.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // É importante que non renunciamos á propiedade do punteiro débil ou se non, a memoria pode liberarse no momento en que `data_fn` volva.
        // Se realmente quixésemos pasar a propiedade, poderiamos crear un punteiro débil adicional para nós mesmos, pero isto daría lugar a actualizacións adicionais do reconto de referencias débiles que doutro xeito non serían necesarias.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Agora podemos inicializar correctamente o valor interno e converter a nosa feble referencia nunha forte referencia.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // A escritura anterior no campo de datos debe ser visible para calquera subproceso que observe un reconto forte diferente de cero.
            // Polo tanto, necesitamos polo menos unha orde "Release" para sincronizarnos co `compare_exchange_weak` en `Weak::upgrade`.
            //
            // "Acquire" non é necesario realizar pedidos.
            // Ao considerar os posibles comportamentos de `data_fn` só precisamos ver o que podería facer cunha referencia a un `Weak` non actualizable:
            //
            // - Pode *clonar* o `Weak`, aumentando o número de referencias débil.
            // - Pode caer eses clons, diminuíndo o débil reconto de referencia (pero nunca a cero).
            //
            // Estes efectos secundarios non nos afectan de ningún xeito e non hai outros efectos secundarios posibles só co código seguro.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // As referencias fortes deberían posuír colectivamente unha referencia feble compartida, polo que non execute o destructor da nosa vella referencia feble.
        //
        mem::forget(weak);
        strong
    }

    /// Constrúe un novo `Arc` con contido non inicializado.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicialización diferida:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Constrúe un novo `Arc` con contido non inicializado, coa memoria enchéndose de bytes `0`.
    ///
    ///
    /// Vexa [`MaybeUninit::zeroed`][zeroed] para ver exemplos de uso correcto e incorrecto deste método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Constrúe un novo `Pin<Arc<T>>`.
    /// Se `T` non implementa `Unpin`, `data` quedará fixado na memoria e non se poderá mover.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Constrúe un novo `Arc<T>`, devolvendo un erro se falla a asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Inicia o número de punteiros débiles como 1, que é o punteiro débil que teñen todos os punteiros fortes (kinda); consulta std/rc.rs para máis información.
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Constrúe un novo `Arc` con contido non inicializado, devolvendo un erro se falla a asignación.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inicialización diferida:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Constrúe un novo `Arc` con contido non inicializado, coa memoria enchéndose de bytes `0`, devolvendo un erro se falla a asignación.
    ///
    ///
    /// Vexa [`MaybeUninit::zeroed`][zeroed] para ver exemplos de uso correcto e incorrecto deste método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Devolve o valor interno, se o `Arc` ten exactamente unha referencia forte.
    ///
    /// Se non, devólvese un [`Err`] co mesmo `Arc` que se pasou.
    ///
    ///
    /// Isto terá éxito aínda que haxa referencias débiles pendentes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Fai un punteiro débil para limpar a referencia implícita forte-feble
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Constrúe unha nova porción contada atomicamente con referencias con contido non inicializado.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicialización diferida:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Constrúe unha nova porción atomicamente contada con referencias con contido non inicializado, coa memoria enchéndose de bytes `0`.
    ///
    ///
    /// Vexa [`MaybeUninit::zeroed`][zeroed] para ver exemplos de uso correcto e incorrecto deste método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Converte a `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Do mesmo xeito que co [`MaybeUninit::assume_init`], correspóndelle ao interlocutor garantir que o valor interno está realmente nun estado inicializado.
    ///
    /// Chamar a isto cando o contido aínda non está completamente inicializado provoca un comportamento indefinido inmediato.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicialización diferida:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Converte a `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Do mesmo xeito que co [`MaybeUninit::assume_init`], correspóndelle ao interlocutor garantir que o valor interno está realmente nun estado inicializado.
    ///
    /// Chamar a isto cando o contido aínda non está completamente inicializado provoca un comportamento indefinido inmediato.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicialización diferida:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Consume o `Arc`, devolvendo o punteiro axustado.
    ///
    /// Para evitar unha fuga de memoria, o punteiro debe converterse de novo a un `Arc` usando [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Ofrece un punteiro en bruto aos datos.
    ///
    /// Os recontos non se afectan de ningún xeito e o `Arc` non se consume.
    /// O punteiro é válido sempre que haxa contas fortes no `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SEGURIDADE: Isto non pode pasar por Deref::deref ou RcBoxPtr::inner porque
        // isto é necesario para manter a procedencia raw/mut tal que por exemplo
        // `get_mut` pode escribir a través do punteiro despois de recuperar o Rc a través de `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Constrúe un `Arc<T>` a partir dun punteiro en bruto.
    ///
    /// O punteiro en bruto debe ser devolto previamente por unha chamada a [`Arc<U>::into_raw`][into_raw] onde `U` debe ter o mesmo tamaño e aliñamento que `T`.
    /// Isto é trivialmente certo se `U` é `T`.
    /// Teña en conta que se `U` non é `T` pero ten o mesmo tamaño e aliñamento, isto é basicamente como transmutar referencias de diferentes tipos.
    /// Vexa [`mem::transmute`][transmute] para obter máis información sobre as restricións que se aplican neste caso.
    ///
    /// O usuario de `from_raw` ten que asegurarse de que un valor específico de `T` só se cae unha vez.
    ///
    /// Esta función non é segura porque un uso inadecuado pode causar seguridade na memoria, aínda que nunca se acceda ao `Arc<T>` devolto.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Converta de novo nun `Arc` para evitar fugas.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Outras chamadas a `Arc::from_raw(x_ptr)` non terían memoria.
    /// }
    ///
    /// // A memoria liberouse cando `x` saíu do alcance anterior, polo que `x_ptr` agora está colgando.
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Inverte o desprazamento para atopar o ArcInner orixinal.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Crea un novo punteiro [`Weak`] para esta asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Este Relaxed está ben porque estamos comprobando o valor no CAS a continuación.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // comproba se o contador feble é actualmente "locked";se é así, xira.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: este código ignora actualmente a posibilidade de desbordamento
            // en usize::MAX;en xeral, tanto Rc como Arc precisan axustarse para tratar o desbordamento.
            //

            // A diferenza de Clone(), necesitamos que sexa unha lectura de Adquisición para sincronizar coa escritura de `is_unique`, de xeito que os eventos anteriores a esa escritura ocorran antes desta lectura.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Asegúrese de que non creamos un débil colgante
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Obtén o número de punteiros [`Weak`] para esta asignación.
    ///
    /// # Safety
    ///
    /// Este método por si só é seguro, pero o seu uso correcto require un coidado adicional.
    /// Outro fío pode cambiar o reconto débil en calquera momento, incluíndo potencialmente entre chamar a este método e actuar sobre o resultado.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Esta afirmación é determinista porque non compartimos o `Arc` ou `Weak` entre fíos.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Se o reconto débil está bloqueado actualmente, o valor do reconto foi 0 xusto antes de tomar o bloqueo.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Obtén o número de punteiros (`Arc`) fortes para esta asignación.
    ///
    /// # Safety
    ///
    /// Este método por si só é seguro, pero o seu uso correcto require un coidado adicional.
    /// Outro fío pode cambiar o reconto forte en calquera momento, incluíndo potencialmente entre chamar a este método e actuar sobre o resultado.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Esta afirmación é determinista porque non compartimos o `Arc` entre fíos.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Incrementa o número forte de referencias no `Arc<T>` asociado co punteiro proporcionado.
    ///
    /// # Safety
    ///
    /// O punteiro debe obterse a través de `Arc::into_raw` e a instancia `Arc` asociada debe ser válida (é dicir
    /// o reconto forte debe ser polo menos 1) para a duración deste método.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Esta afirmación é determinista porque non compartimos o `Arc` entre fíos.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Conservar Arc, pero non toque o reconto envolvéndoo en ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Agora aumenta o reconto, pero tampouco solte o novo
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Diminúe o número de referencias fortes no `Arc<T>` asociado co punteiro proporcionado por un.
    ///
    /// # Safety
    ///
    /// O punteiro debe obterse a través de `Arc::into_raw` e a instancia `Arc` asociada debe ser válida (é dicir
    /// o reconto forte debe ser polo menos 1) cando se invoca este método.
    /// Este método pódese usar para liberar o `Arc` final e o almacenamento de copia de seguridade, pero **non se debería** chamar despois de que o `Arc` final sexa liberado.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Esas afirmacións son deterministas porque non compartimos o `Arc` entre fíos.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Esta inseguridade está ben porque mentres este arco está vivo, estamos garantidos de que o punteiro interno é válido.
        // Ademais, sabemos que a propia estrutura `ArcInner` é `Sync` porque os datos internos tamén son `Sync`, polo que estamos ben prestando un punteiro inmutable a estes contidos.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Parte non aliñada de `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Destruír os datos neste momento, aínda que quizais non liberemos a asignación de caixas en si mesma (aínda pode haber puntos débiles).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Deixar caer á feble ref que ten todas as referencias fortes
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Devolve `true` se os dous `Arc` apuntan á mesma asignación (nunha vea semellante a [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Asigna un `ArcInner<T>` con espazo suficiente para un valor interior posiblemente non dimensionado onde o valor teña o deseño proporcionado.
    ///
    /// A función `mem_to_arcinner` chámase co punteiro de datos e debe devolver un punteiro (potencialmente gordo) para o `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Calcula o deseño empregando o deseño do valor indicado.
        // Anteriormente, o deseño calculábase na expresión `&*(ptr as* const ArcInner<T>)`, pero isto creou unha referencia desalineada (ver #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Asigna un `ArcInner<T>` con espazo suficiente para un valor interno posiblemente sen tamaño onde o valor ten o deseño proporcionado, devolvendo un erro se falla a asignación.
    ///
    ///
    /// A función `mem_to_arcinner` chámase co punteiro de datos e debe devolver un punteiro (potencialmente gordo) para o `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Calcula o deseño empregando o deseño do valor indicado.
        // Anteriormente, o deseño calculábase na expresión `&*(ptr as* const ArcInner<T>)`, pero isto creou unha referencia desalineada (ver #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Inicialice o ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Asigna un `ArcInner<T>` con espazo suficiente para un valor interior non dimensionado.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Asigne o `ArcInner<T>` usando o valor indicado.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copia o valor como bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Libre a asignación sen deixar caer o seu contido
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Asigna un `ArcInner<[T]>` coa lonxitude indicada.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Copia os elementos da porción no arco recentemente asignado <\[T\]>
    ///
    /// Non é seguro porque o interlocutor debe asumir a propiedade ou vincular `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Constrúe un `Arc<[T]>` a partir dun iterador que se sabe dun certo tamaño.
    ///
    /// O comportamento non está definido se o tamaño é incorrecto.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic garda ao clonar elementos en T.
        // No caso dun panic, os elementos que se escribiron no novo ArcInner caerán e liberarase a memoria.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Punteiro ao primeiro elemento
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Todo claro.Esquece a garda para que non libere o novo ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Especialización trait usada para `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Fai un clon do punteiro `Arc`.
    ///
    /// Isto crea outro punteiro para a mesma asignación, aumentando o reconto de referencia forte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Usar unha ordenación relaxada está ben aquí, xa que o coñecemento da referencia orixinal impide que outros fíos borren erroneamente o obxecto.
        //
        // Como se explica no [Boost documentation][1], aumentar o contador de referencia sempre se pode facer con memory_order_relaxed: as novas referencias a un obxecto só se poden formar a partir dunha referencia existente e pasar unha referencia existente dun fío a outro xa debe proporcionar a sincronización necesaria.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Non obstante, debemos protexernos dos recontos masivos no caso de que alguén estea "mem: : forget`ing Arcs.
        // Se non facemos isto, o reconto pode desbordarse e os usuarios usarán de balde.
        // Saturamos racialmente ata `isize::MAX` supoñendo que non hai ~2 millóns de fíos que incrementen o reconto de referencia á vez.
        //
        // Este branch nunca se tomará en ningún programa realista.
        //
        // Abortamos porque tal programa é increíblemente dexenerado e non nos importa apoialo.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Fai unha referencia mutable no `Arc` dado.
    ///
    /// Se hai outros punteiros `Arc` ou [`Weak`] para a mesma asignación, entón `make_mut` creará unha nova asignación e invocará [`clone`][clone] sobre o valor interno para garantir a propiedade única.
    /// Isto tamén se coñece como clonación en escritura.
    ///
    /// Teña en conta que isto difiere do comportamento de [`Rc::make_mut`] que desvincula os punteiros `Weak` restantes.
    ///
    /// Vexa tamén [`get_mut`][get_mut], que fallará máis que clonar.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Non clonarei nada
    /// let mut other_data = Arc::clone(&data); // Non clonará datos internos
    /// *Arc::make_mut(&mut data) += 1;         // Clona datos internos
    /// *Arc::make_mut(&mut data) += 1;         // Non clonarei nada
    /// *Arc::make_mut(&mut other_data) *= 2;   // Non clonarei nada
    ///
    /// // Agora `data` e `other_data` apuntan a diferentes asignacións.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Teña en conta que temos unha referencia forte e unha referencia feble.
        // Así, liberar só a nosa forte referencia non provocará, por si só, a deslocalización da memoria.
        //
        // Use Acquire para asegurarse de que vexamos as escrituras en `weak` que ocorren antes de que as versións escriban (é dicir, diminúan) en `strong`.
        // Dado que temos un reconto débil, non hai ningunha posibilidade de que o propio ArcInner poida ser repartido.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Existe outro punteiro forte, polo que debemos clonalo.
            // Pre-asignar memoria para permitir escribir directamente o valor clonado.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // O relaxado abonda co anterior, porque isto é fundamentalmente unha optimización: sempre estamos a carreiras caendo puntos baixos.
            // No peor dos casos, acabamos asignando un novo Arco innecesariamente.
            //

            // Eliminamos a última referencia forte, pero quedan referencias febles adicionais.
            // Moveremos o contido a un novo arco e invalidaremos aos demais ref.
            //

            // Teña en conta que non é posible que a lectura de `weak` produza usize::MAX (é dicir, bloqueada), xa que a conta débil só pode ser bloqueada por un fío cunha referencia forte.
            //
            //

            // Materializa o noso propio punteiro débil implícito para que poida limpar o ArcInner segundo sexa necesario.
            //
            let _weak = Weak { ptr: this.ptr };

            // Só podo roubar os datos, só queda Débil
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Fomos a única referencia de calquera dos dous tipos;volve facer un forte número de ref.
            //
            this.inner().strong.store(1, Release);
        }

        // Do mesmo xeito que con `get_mut()`, a inseguridade está ben porque a nosa referencia foi única ao comezar ou converteuse nunha única ao clonar o contido.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Devolve unha referencia mutable no `Arc` indicado, se non hai outros punteiros `Arc` ou [`Weak`] para a mesma asignación.
    ///
    ///
    /// Devolve [`None`] doutro xeito, porque non é seguro mudar un valor compartido.
    ///
    /// Vexa tamén [`make_mut`][make_mut], que terá [`clone`][clone] o valor interno cando hai outros punteiros.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Esta inseguridade está ben porque temos a garantía de que o punteiro devolto é o *único* que sempre se devolverá a T.
            // A nosa conta de referencias está garantida neste momento e requirimos que o propio Arco sexa `mut`, polo que devolveremos a única referencia posible aos datos internos.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Devolve unha referencia mutable no `Arc` indicado, sen ningunha comprobación.
    ///
    /// Vexa tamén [`get_mut`], que é seguro e realiza as comprobacións adecuadas.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Calquera outro punteiro `Arc` ou [`Weak`] para a mesma asignación non debe ser anulado durante a duración do préstamo devolto.
    ///
    /// Isto é trivialmente o caso se non existen tales punteiros, por exemplo inmediatamente despois do `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Temos o coidado de *non* crear unha referencia que cubra os campos "count", xa que isto sería un alias con acceso simultáneo aos contos de referencia (por exemplo,
        // por `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Determine se esta é a referencia única (incluídos refs débiles) aos datos subxacentes.
    ///
    ///
    /// Teña en conta que isto require bloquear o número de ref.
    fn is_unique(&mut self) -> bool {
        // bloquea o reconto do punteiro débil se semellamos ser o único titular do punteiro débil.
        //
        // A etiqueta de compra aquí garante unha relación de acontecemento antes con calquera escritura en `strong` (en particular en `Weak::upgrade`) antes de diminuír o reconto de `weak` (a través de `Weak::drop`, que usa a versión).
        // Se nunca se eliminou a referencia feble actualizada, o CAS fallará, polo que non nos importa sincronizar.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Este ten que ser un `Acquire` para sincronizar co decremento do contador `strong` en `drop`, o único acceso que ocorre cando se está eliminando algunha, pero a última referencia.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // A versión de escritura aquí sincronízase cunha lectura en `downgrade`, evitando efectivamente que a lectura anterior de `strong` se produza despois da escritura.
            //
            //
            self.inner().weak.store(1, Release); // solta a pechadura
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Solta o `Arc`.
    ///
    /// Isto diminuirá o forte reconto de referencia.
    /// Se o reconto de referencias fortes chega a cero, as únicas outras referencias (se as hai) son [`Weak`], polo que `drop` o valor interno.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Non imprime nada
    /// drop(foo2);   // Imprime "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Debido a que `fetch_sub` xa é atómico, non necesitamos sincronizarnos con outros fíos a menos que vaiamos eliminar o obxecto.
        // Esta mesma lóxica aplícase ao seguinte `fetch_sub` para o reconto `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Esta cerca é necesaria para evitar o reordenamento do uso dos datos e a eliminación dos datos.
        // Debido a que está marcado como `Release`, a diminución do reconto de referencia sincronízase con este valo `Acquire`.
        // Isto significa que o uso dos datos ocorre antes de diminuír o reconto de referencia, o que ocorre antes desta cerca, que ocorre antes da eliminación dos datos.
        //
        // Como se explica no [Boost documentation][1],
        //
        // > É importante facer cumprir calquera posible acceso ao obxecto nun
        // > fío (a través dunha referencia existente) para *pasar antes de* eliminar
        // > o obxecto nun fío diferente.Isto conséguese cun "release"
        // > operación despois de soltar unha referencia (calquera acceso ao obxecto
        // > a través desta referencia obviamente debe ocorrer antes) e an
        // > "acquire" operación antes de eliminar o obxecto.
        //
        // En particular, aínda que o contido dun arco adoita ser inmutable, é posible que as escrituras interiores se fagan en algo así como un Mutex<T>.
        // Dado que un Mutex non se adquire cando se elimina, non podemos confiar na súa lóxica de sincronización para facer visibles as escrituras no fío A para un destrutor que se executa no fío B.
        //
        //
        // Ten en conta tamén que o valo Acquire aquí podería substituírse por unha carga Acquire, o que podería mellorar o rendemento en situacións moi disputadas.Vexa [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Intente abater o `Arc<dyn Any + Send + Sync>` a un tipo concreto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Constrúe un novo `Weak<T>` sen asignar memoria.
    /// Chamar a [`upgrade`] polo valor devolto sempre proporciona [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Tipo de axuda para permitir o acceso aos contos de referencia sen facer ningunha afirmación sobre o campo de datos.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Devolve un punteiro en bruto ao obxecto `T` ao que apunta este `Weak<T>`.
    ///
    /// O punteiro só é válido se hai algunhas referencias fortes.
    /// O punteiro pode estar colgado, sen aliñar ou incluso [`null`] doutro xeito.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Ambos apuntan ao mesmo obxecto
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // O forte aquí o mantén vivo, polo que aínda podemos acceder ao obxecto.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Pero xa non.
    /// // Podemos facer weak.as_ptr(), pero acceder ao punteiro levaría a un comportamento indefinido.
    /// // assert_eq! ("ola", inseguro {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Se o punteiro está colgado, devolvemos o centinela directamente.
            // Este non pode ser un enderezo de carga útil válido, xa que a carga útil está polo menos tan aliñada como ArcInner (usize).
            ptr as *const T
        } else {
            // SEGURIDADE: se is_dangling devolve falso, entón o punteiro non se pode referenciar.
            // A carga útil pode ser eliminada neste momento e temos que manter a procedencia, así que use a manipulación do punteiro en bruto.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Consume o `Weak<T>` e convérteo nun punteiro en bruto.
    ///
    /// Isto converte o punteiro débil nun punteiro en bruto, aínda que conserva a propiedade dunha referencia débil (o reconto débil non se modifica con esta operación).
    /// Pódese converter de novo no `Weak<T>` con [`from_raw`].
    ///
    /// As mesmas restricións para acceder ao destino do punteiro que con [`as_ptr`] aplícanse.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Converte un punteiro en bruto creado previamente por [`into_raw`] de novo en `Weak<T>`.
    ///
    /// Isto pódese usar para obter unha referencia segura (chamando máis tarde a [`upgrade`]) ou para localizar a conta débil caendo o `Weak<T>`.
    ///
    /// Toma a propiedade dunha referencia débil (coa excepción dos punteiros creados por [`new`], xa que estes non posúen nada; o método aínda funciona neles).
    ///
    /// # Safety
    ///
    /// O punteiro debe ter a súa orixe no [`into_raw`] e aínda debe posuír a súa feble referencia potencial.
    ///
    /// Permítese que o reconto forte sexa 0 no momento de chamar isto.
    /// Non obstante, isto faise propietario dunha referencia débil representada actualmente como un punteiro en bruto (a conta débil non se modifica con esta operación) e, polo tanto, debe combinarse cunha chamada previa a [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Diminúe o último reconto débil.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Vexa Weak::as_ptr para o contexto sobre como se deriva o punteiro de entrada.

        let ptr = if is_dangling(ptr as *mut T) {
            // Este é un débil colgante.
            ptr as *mut ArcInner<T>
        } else {
            // En caso contrario, temos a garantía de que o punteiro proviña dun débil incomprensible.
            // SEGURIDADE: data_offset é seguro de chamar, xa que ptr fai referencia a un T. real (potencialmente caído)
            let offset = unsafe { data_offset(ptr) };
            // Así, invertimos a compensación para obter todo o RcBox.
            // SEGURIDADE: o punteiro orixinouse a partir dun punto débil, polo que este desprazamento é seguro.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SEGURIDADE: agora recuperamos o punteiro feble orixinal, polo que podemos crear o feble.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Tenta actualizar o punteiro `Weak` a un [`Arc`], retrasando a caída do valor interno se ten éxito.
    ///
    ///
    /// Devolve [`None`] se desde entón se eliminou o valor interno.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Destruír todos os indicadores fortes.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Usamos un bucle CAS para incrementar o reconto forte no canto de fetch_add xa que esta función nunca debería levar o reconto de referencia de cero a un.
        //
        //
        let inner = self.inner()?;

        // Carga relaxada porque calquera escritura de 0 que podemos observar deixa o campo nun estado permanentemente cero (polo que unha lectura "stale" de 0 está ben) e calquera outro valor confírmase a través do CAS a continuación.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Vexa os comentarios en `Arc::clone` para saber por que facemos isto (para `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxed está ben para o caso do fracaso porque non temos expectativas sobre o novo estado.
            // A adquisición é necesaria para que o caso de éxito se sincronice con `Arc::new_cyclic`, cando o valor interno pode inicializarse despois de que xa se crearon referencias `Weak`.
            // Nese caso, esperamos observar o valor completamente inicializado.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // nulo comprobado arriba
                Err(old) => n = old,
            }
        }
    }

    /// Obtén o número de punteiros (`Arc`) fortes que apuntan a esta asignación.
    ///
    /// Se `self` se creou usando [`Weak::new`], devolverá 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Obtén unha aproximación do número de punteiros `Weak` que apuntan a esta asignación.
    ///
    /// Se `self` se creou usando [`Weak::new`] ou se non quedan punteiros fortes, devolverá 0.
    ///
    /// # Accuracy
    ///
    /// Debido aos detalles da implementación, o valor devolto pode estar desactivado por 1 en calquera dirección cando outros fíos manipulen calquera `Arc` ou`Debil` que apuntan á mesma asignación.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Dado que observamos que había polo menos un punteiro forte despois de ler o reconto débil, sabemos que a referencia débil implícita (presente sempre que hai referencias fortes viva) aínda estaba ao redor cando observamos o reconto débil e, polo tanto, podemos restalo con seguridade.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Devolve `None` cando o punteiro está colgado e non hai `ArcInner` asignado, (é dicir, cando este `Weak` foi creado por `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Temos coidado de *non* crear unha referencia que cubra o campo "data", xa que o campo pode mutarse simultaneamente (por exemplo, se se baixa o último `Arc`, o campo de datos caerá no seu lugar).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Devolve `true` se os dous `Débiles` apuntan á mesma asignación (similar a [`ptr::eq`]), ou se ambos non apuntan a ningunha asignación (porque foron creados con `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Dado que isto compara os punteiros, significa que `Weak::new()` será igual, aínda que non apunten a ningunha asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Comparando `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Fai un clon do punteiro `Weak` que apunta á mesma asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Vexa os comentarios en Arc::clone() para saber por que está relaxado.
        // Isto pode usar fetch_add (ignorando o bloqueo) porque o reconto débil só está bloqueado onde non hai *outros* punteiros débiles.
        //
        // (Polo tanto, non podemos executar este código nese caso).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Vexa os comentarios en Arc::clone() para saber por que facemos isto (para mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Constrúe un novo `Weak<T>`, sen asignar memoria.
    /// Chamar a [`upgrade`] polo valor devolto sempre proporciona [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Solta o punteiro `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Non imprime nada
    /// drop(foo);        // Imprime "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Se descubrimos que fomos o último punteiro débil, entón é hora de deslocalizar completamente os datos.Vexa a discusión en Arc::drop() sobre as ordes da memoria
        //
        // Non é necesario comprobar o estado bloqueado aquí, porque o reconto débil só se pode bloquear se precisamente houbo un ref feble, o que significa que a caída só pode executarse ON na ref feble restante, que só pode ocorrer despois de liberar o bloqueo.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Estamos facendo esta especialización aquí, e non como unha optimización máis xeral en `&T`, porque doutro xeito engadiría un custo a todas as comprobacións de igualdade dos ref.
/// Supoñemos que `Arc`s úsanse para almacenar valores grandes, que son lentos para clonarse, pero tamén pesados para comprobar a igualdade, o que fai que este custo se pague máis facilmente.
///
/// Tamén é máis probable que teña dous clons `Arc`, que apuntan ao mesmo valor, que dous `&T`.
///
/// Só podemos facelo cando `T: Eq` como `PartialEq` pode ser deliberadamente irreflexivo.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Igualdade para dous `Arc`s.
    ///
    /// Dous `Arc`s son iguais se os seus valores internos son iguais, aínda que estean almacenados nunha asignación diferente.
    ///
    /// Se `T` tamén implementa `Eq` (o que implica reflexividade de igualdade), dous `Arc`s que apuntan á mesma asignación son sempre iguais.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Desigualdade para dous `Arc`s.
    ///
    /// Dous `Arc` son desiguais se os seus valores internos son desiguais.
    ///
    /// Se `T` tamén implementa `Eq` (o que implica reflexividade de igualdade), dous `Arc`s que apuntan ao mesmo valor nunca serán desiguais.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Comparación parcial para dous `Arc`s.
    ///
    /// Os dous compáranse chamando ao `partial_cmp()` polos seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Comparación inferior a dous `Arc`s.
    ///
    /// Os dous compáranse chamando ao `<` polos seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Comparación "inferior ou igual a" para dous "Arc".
    ///
    /// Os dous compáranse chamando ao `<=` polos seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Comparación superior a dúas de `Arc`.
    ///
    /// Os dous compáranse chamando ao `>` polos seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Comparación "maior ou igual a" para dous `Arc`.
    ///
    /// Os dous compáranse chamando ao `>=` polos seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Comparación para dous `Arc`s.
    ///
    /// Os dous compáranse chamando ao `cmp()` polos seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Crea un novo `Arc<T>`, co valor `Default` para `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Asigne unha porción contada por referencias e énchea clonando elementos de `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Asigne un `str` contado con referencias e copia nel `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Asigne un `str` contado con referencias e copia nel `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Move un obxecto en caixa a unha nova asignación contada por referencias.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Asigna unha porción contada por referencias e move nela os elementos de `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Permite ao Vec liberar a súa memoria, pero non destruír o seu contido
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Colle cada elemento do `Iterator` e recólleo nun `Arc<[T]>`.
    ///
    /// # Características de rendemento
    ///
    /// ## O caso xeral
    ///
    /// No caso xeral, a recollida en `Arc<[T]>` faise primeiro recolléndoa nun `Vec<T>`.É dicir, ao escribir o seguinte:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// isto compórtase coma se escribísemos:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Aquí faise o primeiro conxunto de asignacións.
    ///     .into(); // Aquí ocorre unha segunda asignación para `Arc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Isto asignarase cantas veces sexa necesario para construír o `Vec<T>` e despois asignarase unha vez para converter o `Vec<T>` no `Arc<[T]>`.
    ///
    ///
    /// ## Iteradores de lonxitude coñecida
    ///
    /// Cando o `Iterator` implemente `TrustedLen` e teña un tamaño exacto, farase unha única asignación para o `Arc<[T]>`.Por exemplo:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Aquí só ocorre unha única asignación.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Especialización trait empregada para recoller en `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Este é o caso dun iterador `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SEGURIDADE: debemos asegurarnos de que o iterador ten unha lonxitude exacta e temos.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Volve á implementación normal.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Obtén a compensación nun `ArcInner` pola carga útil detrás dun punteiro.
///
/// # Safety
///
/// O punteiro debe apuntar a (e ter metadatos válidos para) unha instancia válida previamente de T, pero permítese soltar a T.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Aliña o valor sen tamaño ao final do ArcInner.
    // Debido a que RcBox é repr(C), sempre será o último campo da memoria.
    // SEGURIDADE: xa que os únicos tipos non dimensionados posibles son franxas, obxectos trait,
    // e tipos externos, o requisito de seguridade de entrada é actualmente suficiente para satisfacer os requisitos de align_of_val_raw;este é un detalle de implementación da linguaxe que non se pode confiar fóra de std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}