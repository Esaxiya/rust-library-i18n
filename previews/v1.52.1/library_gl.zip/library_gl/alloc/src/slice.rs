//! Unha vista de tamaño dinámico nunha secuencia contigua, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! As franxas son unha vista nun bloque de memoria representado como un punteiro e unha lonxitude.
//!
//! ```
//! // cortar un Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // coaccionar unha matriz nunha porción
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! As porcións son mutables ou compartidas.
//! O tipo de porción compartida é `&[T]`, mentres que o tipo de porción mutable é `&mut [T]`, onde `T` representa o tipo de elemento.
//! Por exemplo, pode mutar o bloque de memoria ao que apunta unha porción mutable:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Aquí tes algunhas das cousas que contén este módulo:
//!
//! ## Structs
//!
//! Hai varias estruturas que son útiles para cortes, como [`Iter`], que representa a iteración sobre unha porción.
//!
//! ## Implementacións de Trait
//!
//! Hai varias implementacións de traits común para slices.Algúns exemplos inclúen:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], para cortes cuxo tipo de elemento son [`Eq`] ou [`Ord`].
//! * [`Hash`] - para franxas cuxo tipo de elemento é [`Hash`].
//!
//! ## Iteration
//!
//! As franxas implementan `IntoIterator`.O iterador proporciona referencias aos elementos da porción.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! A porción mutable proporciona referencias mutables aos elementos:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Este iterador proporciona referencias mudables aos elementos da porción, polo que mentres o tipo de elemento da porción é `i32`, o tipo de elemento do iterador é `&mut i32`.
//!
//!
//! * [`.iter`] e [`.iter_mut`] son os métodos explícitos para devolver os iteradores predeterminados.
//! * Outros métodos que devolven os iteradores son [`.split`], [`.splitn`], [`.chunks`], [`.windows`] e moito máis.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Moitos dos usos deste módulo só se usan na configuración da proba.
// É máis limpo simplemente desactivar o aviso unused_imports que solucionalo.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Métodos básicos de extensión de porción
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) necesario para a implementación da macro `vec!` durante a proba NB, consulte o módulo `hack` neste ficheiro para obter máis detalles.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) necesario para a implementación de `Vec::clone` durante a proba NB, consulte o módulo `hack` neste ficheiro para máis detalles.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Con cfg(test) `impl [T]` non está dispoñible, estas tres funcións son métodos que están en `impl [T]` pero non en `core::slice::SliceExt`, necesitamos subministrar estas funcións para a proba `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Non lle deberiamos engadir atributo en liña xa que se usa principalmente na macro `vec!` e provoca unha regresión perfecta.
    // Vexa #71204 para obter resultados de discusión e perfección.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // os elementos marcáronse inicializados no bucle seguinte
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) é necesario para que LLVM elimine os controis de límites e ten mellor código de rexistro que zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // o vec foi asignado e inicializado anteriormente a polo menos esta lonxitude.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // asignado arriba coa capacidade de `s` e inicialízase a `s.len()` en ptr::copy_to_non_overlapping a continuación.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Ordena a porción.
    ///
    /// Este tipo é estable (é dicir, non reordena elementos iguais) e *O*(*n*\*log(* n*)) no peor dos casos.
    ///
    /// Cando é aplicable, prefírese a clasificación inestable porque xeralmente é máis rápida que a clasificación estable e non asigna memoria auxiliar.
    /// Vexa [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Implementación actual
    ///
    /// O algoritmo actual é un tipo de combinación iterativo e adaptativo inspirado en [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Está deseñado para ser moi rápido nos casos en que a porción está case ordenada ou consiste en dúas ou máis secuencias ordenadas concatenadas unha tras outra.
    ///
    ///
    /// Ademais, asigna almacenamento temporal á metade do tamaño de `self`, pero para cortes curtos úsase no seu lugar unha clasificación de inserción non asignadora.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Ordena a porción cunha función de comparación.
    ///
    /// Este tipo é estable (é dicir, non reordena elementos iguais) e *O*(*n*\*log(* n*)) no peor dos casos.
    ///
    /// A función de comparación debe definir unha ordenación total para os elementos da porción.Se a orde non é total, a orde dos elementos non se especifica.
    /// Un pedido é un pedido total se o é (para todos os `a`, `b` e `c`):
    ///
    /// * total e antisimétrico: exactamente un de `a < b`, `a == b` ou `a > b` é certo e
    /// * transitiva, `a < b` e `b < c` implica `a < c`.O mesmo debe valerse tanto para `==` como para `>`.
    ///
    /// Por exemplo, aínda que [`f64`] non implementa [`Ord`] porque `NaN != NaN`, podemos usar `partial_cmp` como a nosa función de clasificación cando sabemos que a porción non contén un `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Cando é aplicable, prefírese a clasificación inestable porque xeralmente é máis rápida que a clasificación estable e non asigna memoria auxiliar.
    /// Vexa [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Implementación actual
    ///
    /// O algoritmo actual é un tipo de combinación iterativo e adaptativo inspirado en [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Está deseñado para ser moi rápido nos casos en que a porción está case ordenada ou consiste en dúas ou máis secuencias ordenadas concatenadas unha tras outra.
    ///
    /// Ademais, asigna almacenamento temporal á metade do tamaño de `self`, pero para cortes curtos úsase no seu lugar unha clasificación de inserción non asignadora.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // clasificación inversa
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Ordena a porción cunha función de extracción de teclas.
    ///
    /// Este tipo é estable (é dicir, non reordena elementos iguais) e *O*(*m*\* * n *\* log(*n*)) no peor dos casos, onde a función clave é *O*(*m*).
    ///
    /// Para funcións de teclas caras (por exemplo
    /// funcións que non son simples accesos a propiedades ou operacións básicas), é probable que [`sort_by_cached_key`](slice::sort_by_cached_key) sexa significativamente máis rápido, xa que non recomputa as teclas do elemento.
    ///
    ///
    /// Cando é aplicable, prefírese a clasificación inestable porque xeralmente é máis rápida que a clasificación estable e non asigna memoria auxiliar.
    /// Vexa [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Implementación actual
    ///
    /// O algoritmo actual é un tipo de combinación iterativo e adaptativo inspirado en [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Está deseñado para ser moi rápido nos casos en que a porción está case ordenada ou consiste en dúas ou máis secuencias ordenadas concatenadas unha tras outra.
    ///
    /// Ademais, asigna almacenamento temporal á metade do tamaño de `self`, pero para cortes curtos úsase no seu lugar unha clasificación de inserción non asignadora.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Ordena a porción cunha función de extracción de teclas.
    ///
    /// Durante a clasificación, a función clave só se chama unha vez por elemento.
    ///
    /// Este tipo é estable (é dicir, non reordena elementos iguais) e *O*(*m*\* * n *+* n *\* log(*n*)) no peor dos casos, onde a función clave é *O*(*m*) .
    ///
    /// Para funcións de teclas simples (por exemplo, funcións que son accesos a propiedades ou operacións básicas), é probable que [`sort_by_key`](slice::sort_by_key) sexa máis rápido.
    ///
    /// # Implementación actual
    ///
    /// O algoritmo actual está baseado en [pattern-defeating quicksort][pdqsort] de Orson Peters, que combina o caso medio rápido de rápido cadro aleatorio co peor caso rápido de gran escala, ao tempo que se consegue un tempo lineal en franxas con certos patróns.
    /// Usa algunha aleatorización para evitar casos dexenerados, pero cun seed fixo para proporcionar sempre un comportamento determinista.
    ///
    /// No peor dos casos, o algoritmo asigna almacenamento temporal nun `Vec<(K, usize)>` da lonxitude da porción.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Macro auxiliar para indexar o noso vector polo menor tipo posible, para reducir a asignación.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Os elementos de `indices` son únicos, xa que están indexados, polo que calquera tipo será estable con respecto á porción orixinal.
                // Usamos `sort_unstable` aquí porque require menos asignación de memoria.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Copia `self` nun novo `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Aquí, `s` e `x` pódense modificar de forma independente.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Copia `self` nun novo `Vec` cun asignador.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Aquí, `s` e `x` pódense modificar de forma independente.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB: consulte o módulo `hack` neste ficheiro para obter máis detalles.
        hack::to_vec(self, alloc)
    }

    /// Converte `self` nun vector sen clons nin asignación.
    ///
    /// O vector resultante pódese converter de novo nunha caixa a través de `Vec<T>Método `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` xa non se pode usar porque se converteu en `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB: consulte o módulo `hack` neste ficheiro para obter máis detalles.
        hack::into_vec(self)
    }

    /// Crea un vector repetindo unha porción `n` veces.
    ///
    /// # Panics
    ///
    /// Esta función será panic se a capacidade rebordaría.
    ///
    /// # Examples
    ///
    /// Uso básico:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// A panic despois do desbordamento:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Se `n` é maior que cero, pódese dividir como `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` é o número representado polo bit '1' máis á esquerda de `n` e `rem` é a parte restante de `n`.
        //
        //

        // Usando `Vec` para acceder a `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` a repetición faise dobrando os tempos "expn" de `buf`.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Se `m > 0`, quedarán bits ata o '1' máis á esquerda.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` ten unha capacidade de `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) a repetición faise copiando as primeiras repeticións `rem` do propio `buf`.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Isto non se solapa desde `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` é igual a `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Aplana unha porción de `T` nun único valor `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Aplana unha porción de `T` nun único valor `Self::Output`, colocando un separador entre cada un.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Aplana unha porción de `T` nun único valor `Self::Output`, colocando un separador entre cada un.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Devolve un vector que contén unha copia desta porción onde cada byte está mapeado ao seu equivalente en maiúsculas ASCII.
    ///
    ///
    /// As letras ASCII de 'a' a 'z' están mapeadas de 'A' a 'Z', pero as letras non ASCII están inalteradas.
    ///
    /// Para usar maiúsculas o valor no lugar, usa [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Devolve un vector que contén unha copia desta porción onde cada byte está mapeado ao seu equivalente en minúscula ASCII.
    ///
    ///
    /// As letras ASCII de 'A' a 'Z' están mapeadas de 'a' a 'z', pero as letras non ASCII están inalteradas.
    ///
    /// Para minúsculas no seu lugar, use [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Extensión traits para segmentos sobre tipos específicos de datos
////////////////////////////////////////////////////////////////////////////////

/// Axudante trait para [`[T]: : concat`](slice::concat).
///
/// Note: o parámetro tipo `Item` non se usa neste trait, pero permite que os impls sexan máis xenéricos.
/// Sen el, obtemos este erro:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Isto débese a que podería existir tipos `V` con múltiples implos `Borrow<[_]>`, de tal xeito que se aplicarían varios tipos `T`:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// O tipo resultante despois da concatenación
    type Output;

    /// Implementación de [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Axudante trait para [`[T]: : xuntar`](porción::xuntar)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// O tipo resultante despois da concatenación
    type Output;

    /// Implementación de [`[T]: : join`](slice::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Implementacións estándar de trait para slices
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // solte calquera cousa no destino que non se sobreescriba
        target.truncate(self.len());

        // target.len <= self.len debido ao truncado anterior, polo que as porcións aquí sempre están dentro dos límites.
        //
        let (init, tail) = self.split_at(target.len());

        // reutiliza os valores contidos allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Insire `v[0]` na secuencia `v[1..]` pre-ordenada para que `v[..]` enteiro se ordene.
///
/// Esta é a subrutina integral do tipo de inserción.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Aquí hai tres xeitos de implementar a inserción:
            //
            // 1. Intercambia elementos adxacentes ata que o primeiro chegue ao seu destino final.
            //    Non obstante, deste xeito copiamos os datos máis do necesario.
            //    Se os elementos son estruturas grandes (custa copiar), este método será lento.
            //
            // 2. Iterar ata que se atope o lugar axeitado para o primeiro elemento.
            // A continuación, move os elementos que o suceden para deixar espazo e finalmente colócao no burato restante.
            // Este é un bo método.
            //
            // 3. Copia o primeiro elemento nunha variable temporal.Iterar ata que se atope o lugar axeitado.
            // A medida que avanzamos, copie todos os elementos atravesados na rañura que o precede.
            // Finalmente, copia os datos da variable temporal no burato restante.
            // Este método é moi bo.
            // Os puntos de referencia demostraron un rendemento lixeiramente mellor que co segundo método.
            //
            // Todos os métodos foron comparados e o terceiro mostrou os mellores resultados.Entón eliximos aquel.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // O estado intermedio do proceso de inserción é sempre rastrexado por `hole`, que ten dous propósitos:
            // 1. Protexe a integridade de `v` de panics en `is_less`.
            // 2. Enche o burato restante en `v` ao final.
            //
            // Seguridade Panic:
            //
            // Se `is_less` panics nalgún momento do proceso, `hole` caerá e encherá o burato de `v` con `tmp`, garantindo así que `v` aínda ten todos os obxectos que tiña inicialmente exactamente unha vez.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` cae e copia `tmp` no burato restante de `v`.
        }
    }

    // Cando se deixa caer, copias de `src` a `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Combina as tiradas `v[..mid]` e `v[mid..]` non decrecentes usando `buf` como almacenamento temporal e almacena o resultado en `v[..]`.
///
/// # Safety
///
/// As dúas franxas non deben estar baleiras e `mid` debe estar dentro dos límites.
/// O búfer `buf` debe ser o suficientemente longo como para manter unha copia da porción máis curta.
/// Ademais, `T` non debe ser de tamaño cero.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // O proceso de combinación copia primeiro a execución máis curta en `buf`.
    // Despois rastrexa a execución recentemente copiada e a execución máis longa cara adiante (ou cara atrás), comparando os seus seguintes elementos non consumidos e copiando o menor (ou maior) en `v`.
    //
    // En canto se consome a curta duración, o proceso está feito.Se se consome primeiro o tempo máis longo, entón debemos copiar o que queda do tempo máis curto no burato restante en `v`.
    //
    // O estado intermedio do proceso sempre é seguido por `hole`, que ten dous propósitos:
    // 1. Protexe a integridade de `v` de panics en `is_less`.
    // 2. Enche o burato restante en `v` se primeiro se consume máis tempo.
    //
    // Seguridade Panic:
    //
    // Se `is_less` panics nalgún momento do proceso, `hole` caerá e encherá o burato en `v` co intervalo non consumido en `buf`, garantindo así que `v` aínda ten todos os obxectos que tiña inicialmente exactamente unha vez.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // A carreira á esquerda é máis curta.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Inicialmente, estas indicacións apuntan aos inicios das súas matrices.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Consume o lado menor.
            // Se é igual, prefire a esquerda para manter a estabilidade.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // A carreira correcta é máis curta.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Inicialmente, estes indicadores apuntan máis alá dos extremos das súas matrices.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Consume o lado maior.
            // Se é igual, prefire a carreira correcta para manter a estabilidade.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Finalmente, `hole` cae.
    // Se o percorrido máis curto non se consumiu por completo, o que queda del copiarase agora no burato de `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Cando se deixa caer, copia o intervalo `start..end` en `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` Non é un tipo de tamaño cero, polo que está ben dividilo polo seu tamaño.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Este tipo de combinación toma algunhas (pero non todas) ideas de TimSort, que se describe detalladamente [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// O algoritmo identifica subsecuencias estritamente descendentes e non descendentes, que se denominan carreiras naturais.Hai unha pila de execucións pendentes aínda por fusionar.
/// Cada nova carreira atopada empúxase á pila e logo algúns pares de carreiras adxacentes combínanse ata que estes dous invariantes están satisfeitos:
///
/// 1. por cada `i` en `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. por cada `i` en `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Os invariantes aseguran que o tempo total de execución é *O*(*n*\*log(* n*)) no peor dos casos.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // As franxas de ata esta lonxitude clasifícanse mediante ordenación por inserción.
    const MAX_INSERTION: usize = 20;
    // As carreiras moi curtas esténdense usando a clasificación de inserción para abarcar polo menos estes moitos elementos.
    const MIN_RUN: usize = 10;

    // A ordenación non ten un comportamento significativo en tipos de tamaño cero.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // As matrices curtas clasifícanse no lugar mediante a clasificación por inserción para evitar asignacións.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Asigne un búfer para empregalo como memoria de cero.Mantemos a lonxitude 0 para que poidamos gardar nel copias pouco profundas do contido de `v` sen arriscar a que os médicos funcionen con copias se `is_less` panics.
    //
    // Ao combinar dúas carreiras ordenadas, este búfer contén unha copia da carreira máis curta, que sempre terá unha lonxitude como máximo `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Para identificar as corridas naturais en `v`, percorrémola cara atrás.
    // Pode parecer unha decisión estraña, pero considere o feito de que as fusións van máis a miúdo na dirección oposta (forwards).
    // Segundo os puntos de referencia, a fusión cara adiante é lixeiramente máis rápida que a fusión cara atrás.
    // Para concluír, identificar carreiras atravesando cara atrás mellora o rendemento.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Atopa a seguinte carreira natural e invístea se é estrictamente descendente.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Insira algúns elementos máis na carreira se é demasiado curto.
        // A clasificación por inserción é máis rápida que a de combinación en secuencias curtas, polo que isto mellora significativamente o rendemento.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Empuxe esta carreira na pila.
        runs.push(Run { start, len: end - start });
        end = start;

        // Combina algúns pares de carreiras adxacentes para satisfacer aos invariantes.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Finalmente, exactamente unha carreira debe permanecer na pila.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Examina a pila de carreiras e identifica o seguinte par de carreiras a combinar.
    // Máis concretamente, se se devolve `Some(r)`, isto significa que `runs[r]` e `runs[r + 1]` deben fusionarse a continuación.
    // Se o algoritmo debería continuar construíndo unha nova execución, devólvese `None`.
    //
    // TimSort é famoso polas súas implementacións de buggy, como se describe aquí:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // A esencia da historia é: debemos facer cumprir os invariantes nas catro primeiras carreiras da pila.
    // Forzalos só entre os tres primeiros non é suficiente para garantir que os invariantes aínda manteñan durante *todas* as carreiras na pila.
    //
    // Esta función comproba correctamente os invariantes das catro primeiras carreiras.
    // Ademais, se a execución superior comeza no índice 0, sempre esixirá unha operación de combinación ata que a pila estea completamente colapsada, para completar a ordenación.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}