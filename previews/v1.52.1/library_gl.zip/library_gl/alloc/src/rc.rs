//! Punteiros de conteo de referencias dun só fío.'Rc' significa 'Referencia
//! Counted'.
//!
//! O tipo [`Rc<T>`][`Rc`] proporciona a propiedade compartida dun valor do tipo `T`, asignado no montón.
//! Invocar [`clone`][clone] en [`Rc`] produce un novo punteiro para a mesma asignación no montón.
//! Cando se destrúe o último punteiro [`Rc`] a unha asignación determinada, tamén se elimina o valor almacenado nesa asignación (a miúdo denominado "inner value").
//!
//! As referencias compartidas en Rust non permiten a mutación por defecto e [`Rc`] non é unha excepción: normalmente non se pode obter unha referencia mutable a algo dentro dun [`Rc`].
//! Se precisa mutabilidade, coloque un [`Cell`] ou [`RefCell`] dentro do [`Rc`];ver [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] usa o reconto de referencias non atómicas.
//! Isto significa que a sobrecarga é moi baixa, pero non se pode enviar un [`Rc`] entre fíos e, en consecuencia, [`Rc`] non implementa [`Send`][send].
//! Como resultado, o compilador Rust comprobará *no momento da compilación* que non está a enviar [`Rc`] s entre fíos.
//! Se precisa un reconto de referencias atómicas multi-fío, use [`sync::Arc`][arc].
//!
//! O método [`downgrade`][downgrade] pode usarse para crear un punteiro [`Weak`] que non sexa propietario.
//! Un punteiro [`Weak`] pode [[actualizar]][actualizar] d a un [`Rc`], pero devolverá [`None`] se o valor almacenado na asignación xa se eliminou.
//! Noutras palabras, os punteiros `Weak` non manteñen vivo o valor dentro da asignación;con todo,*si* manteñen viva a asignación (o almacén de apoio para o valor interno).
//!
//! Nunca se repartirá un ciclo entre punteiros [`Rc`].
//! Por esta razón, [`Weak`] úsase para romper ciclos.
//! Por exemplo, unha árbore podería ter fortes punteiros [`Rc`] desde nodos pais ata nenos, e punteiros [`Weak`] de nenos de volta aos seus pais.
//!
//! `Rc<T>` desferencia automaticamente a `T` (a través do [`Deref`] trait), polo que pode chamar aos métodos de `T` cun valor de tipo [`Rc<T>`][`Rc`].
//! Para evitar choques de nomes cos métodos de `T`, os métodos de [`Rc<T>`][`Rc`] en si son funcións asociadas, chamadas usando [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>As implementacións de traits como `Clone` tamén se poden chamar usando sintaxe totalmente cualificada.
//! Algunhas persoas prefiren usar sintaxe totalmente cualificada, mentres que outras prefiren usar sintaxe de método de chamada.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Sintaxe de método de chamada
//! let rc2 = rc.clone();
//! // Sintaxe totalmente cualificada
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] non fai a autoreferencia a `T`, porque o valor interno xa se eliminou.
//!
//! # Referencias de clonación
//!
//! A creación dunha nova referencia á mesma asignación que un punteiro de contas de referencia existente faise mediante o `Clone` trait implementado para [`Rc<T>`][`Rc`] e [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // As dúas sintaxes seguintes son equivalentes.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // aeb apuntan á mesma situación de memoria que foo.
//! ```
//!
//! A sintaxe `Rc::clone(&from)` é a máis idiomática porque transmite de xeito máis explícito o significado do código.
//! No exemplo anterior, esta sintaxe facilita ver que este código está a crear unha nova referencia en lugar de copiar todo o contido de foo.
//!
//! # Examples
//!
//! Considere un escenario onde un conxunto de "gadgets" son propiedade dun determinado `Owner`.
//! Queremos que o noso gadget apunte ao seu `Owner`.Non podemos facelo cunha propiedade única, porque é posible que máis dun gadget pertenza ao mesmo `Owner`.
//! [`Rc`] permítenos compartir un `Owner` entre varios `Gadget` e facer que o `Owner` permaneza asignado sempre que os puntos `Gadget` nel.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... outros campos
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... outros campos
//! }
//!
//! fn main() {
//!     // Crea un `Owner` contado por referencias.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Crea `Gadget` pertencente a `gadget_owner`.
//!     // A clonación do `Rc<Owner>` ofrécenos un novo punteiro á mesma asignación `Owner`, incrementando o reconto de referencia no proceso.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Desbote a nosa variable local `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // A pesar de caer `gadget_owner`, aínda podemos imprimir o nome do `Owner` do `Gadget`.
//!     // Isto débese a que só caemos un único `Rc<Owner>`, non o `Owner` ao que apunta.
//!     // Mentres haxa outros `Rc<Owner>` apuntando á mesma asignación `Owner`, seguirá activo.
//!     // A proxección de campo `gadget1.owner.name` funciona porque `Rc<Owner>` desferencia automaticamente a `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Ao final da función, `gadget1` e `gadget2` destrúense, e con elas as últimas referencias contadas ao noso `Owner`.
//!     // Gadget Man agora tamén é destruído.
//!     //
//! }
//! ```
//!
//! Se os nosos requisitos cambian e tamén necesitamos ser capaces de atravesar de `Owner` a `Gadget`, teremos problemas.
//! Un punteiro [`Rc`] de `Owner` a `Gadget` introduce un ciclo.
//! Isto significa que o seu número de referencias nunca pode chegar a 0 e a asignación nunca será destruída:
//! unha fuga de memoria.Para evitar isto, podemos usar punteiros [`Weak`].
//!
//! Rust fai que sexa un pouco difícil producir este bucle en primeiro lugar.Para terminar con dous valores que apuntan un ao outro, un deles debe ser mutable.
//! Isto é difícil porque [`Rc`] impón a seguridade da memoria só dando referencias compartidas ao valor que envolve e estas non permiten a mutación directa.
//! Necesitamos envolver a parte do valor que desexamos mutar nun [`RefCell`], que proporciona *mutabilidade interior*: un método para lograr a mutabilidade a través dunha referencia compartida.
//! [`RefCell`] aplica as regras de endebedamento de Rust no tempo de execución.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... outros campos
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... outros campos
//! }
//!
//! fn main() {
//!     // Crea un `Owner` contado por referencias.
//!     // Teña en conta que colocamos o vector do "Propietario" de "Gadget" dentro dun `RefCell` para que poidamos mutalo a través dunha referencia compartida.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Crea `Gadget` pertencente a `gadget_owner`, como antes.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Engade o gadget ao seu `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` o préstamo dinámico remata aquí.
//!     }
//!
//!     // Repita os nosos gadgets, imprimindo os seus detalles.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` é un `Weak<Gadget>`.
//!         // Dado que os punteiros `Weak` non poden garantir que a asignación aínda existe, necesitamos chamar ao `upgrade`, que devolve un `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Neste caso, sabemos que a asignación aínda existe, polo que simplemente `unwrap` o `Option`.
//!         // Nun programa máis complicado, é posible que precise un manexo de erros elegante para un resultado `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Ao final da función, `gadget_owner`, `gadget1` e `gadget2` destrúense.
//!     // Agora non hai indicadores (`Rc`) fortes para os gadgets, polo que son destruídos.
//!     // Isto pon a cero o número de referencias en Gadget Man, polo que tamén é destruído.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Isto é a proba de repr(C) a future contra posibles reordenamentos de campo, o que interferiría co [into|from]_raw() doutro xeito seguro de tipos internos transmutables.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Un punteiro de conteo de referencias dun só fío.'Rc' significa 'Referencia
/// Counted'.
///
/// Vexa o [module-level documentation](./index.html) para máis detalles.
///
/// Os métodos inherentes a `Rc` son funcións asociadas, o que significa que ten que chamalos como, por exemplo, [`Rc::get_mut(&mut value)`][get_mut] en lugar de `value.get_mut()`.
/// Isto evita conflitos con métodos do tipo interno `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Esta inseguridade está ben porque mentres este Rc está vivo, garantímonos que o punteiro interno é válido.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Constrúe un novo `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Hai un punteiro débil implícito propiedade de todos os punteiros fortes, o que garante que o destructor débil nunca libera a asignación mentres o destrutor forte está en execución, aínda que o punteiro débil estea almacenado dentro do forte.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Constrúe un novo `Rc<T>` usando unha feble referencia a si mesmo.
    /// Se intenta actualizar a referencia débil antes de que devolva esta función, obterá un valor `None`.
    ///
    /// Non obstante, a referencia feble pode clonarse libremente e almacenarse para usala posteriormente.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... máis campos
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Constrúe o interior no estado "uninitialized" cunha única referencia débil.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // É importante que non renunciamos á propiedade do punteiro débil ou se non, a memoria pode liberarse no momento en que `data_fn` volva.
        // Se realmente quixésemos pasar a propiedade, poderiamos crear un punteiro débil adicional para nós mesmos, pero isto daría lugar a actualizacións adicionais do reconto de referencias débiles que doutro xeito non serían necesarias.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // As referencias fortes deberían posuír colectivamente unha referencia feble compartida, polo que non execute o destructor da nosa vella referencia feble.
        //
        mem::forget(weak);
        strong
    }

    /// Constrúe un novo `Rc` con contido non inicializado.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicialización diferida:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Constrúe un novo `Rc` con contido non inicializado, coa memoria enchéndose de bytes `0`.
    ///
    ///
    /// Vexa [`MaybeUninit::zeroed`][zeroed] para ver exemplos de uso correcto e incorrecto deste método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Constrúe un novo `Rc<T>`, devolvendo un erro se falla a asignación
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Hai un punteiro débil implícito propiedade de todos os punteiros fortes, o que garante que o destructor débil nunca libera a asignación mentres o destrutor forte está en execución, aínda que o punteiro débil estea almacenado dentro do forte.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Constrúe un novo `Rc` con contido non inicializado, devolvendo un erro se falla a asignación
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inicialización diferida:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Constrúe un novo `Rc` con contido non inicializado, coa memoria enchéndose de bytes `0`, devolvendo un erro se falla a asignación
    ///
    ///
    /// Vexa [`MaybeUninit::zeroed`][zeroed] para ver exemplos de uso correcto e incorrecto deste método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Constrúe un novo `Pin<Rc<T>>`.
    /// Se `T` non implementa `Unpin`, `value` quedará fixado na memoria e non se poderá mover.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Devolve o valor interno, se o `Rc` ten exactamente unha referencia forte.
    ///
    /// Se non, devólvese un [`Err`] co mesmo `Rc` que se pasou.
    ///
    ///
    /// Isto terá éxito aínda que haxa referencias débiles pendentes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // copia o obxecto contido

                // Indique a Weaks que non se poden promover decrementando o reconto forte e, a continuación, elimine o punteiro "strong weak" implícito mentres tamén manexa a lóxica de caída só elaborando un Weak falso.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Constrúe unha nova porción contada con referencias con contido non inicializado.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicialización diferida:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Constrúe unha nova porción contada con referencias con contido non inicializado, coa memoria enchéndose de bytes `0`.
    ///
    ///
    /// Vexa [`MaybeUninit::zeroed`][zeroed] para ver exemplos de uso correcto e incorrecto deste método.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Converte a `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Do mesmo xeito que co [`MaybeUninit::assume_init`], correspóndelle ao interlocutor garantir que o valor interno está realmente nun estado inicializado.
    ///
    /// Chamar a isto cando o contido aínda non está completamente inicializado provoca un comportamento indefinido inmediato.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicialización diferida:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Converte a `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Do mesmo xeito que co [`MaybeUninit::assume_init`], correspóndelle ao interlocutor garantir que o valor interno está realmente nun estado inicializado.
    ///
    /// Chamar a isto cando o contido aínda non está completamente inicializado provoca un comportamento indefinido inmediato.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicialización diferida:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Consume o `Rc`, devolvendo o punteiro axustado.
    ///
    /// Para evitar unha fuga de memoria, o punteiro debe converterse de novo a un `Rc` usando [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Ofrece un punteiro en bruto aos datos.
    ///
    /// Os recontos non se afectan de ningún xeito e o `Rc` non se consume.
    /// O punteiro é válido mentres haxa fortes contas no `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SEGURIDADE: Isto non pode pasar por Deref::deref ou Rc::inner porque
        // isto é necesario para manter a procedencia raw/mut tal que por exemplo
        // `get_mut` pode escribir a través do punteiro despois de recuperar o Rc a través de `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Constrúe un `Rc<T>` a partir dun punteiro en bruto.
    ///
    /// O punteiro en bruto debe ser devolto previamente por unha chamada a [`Rc<U>::into_raw`][into_raw] onde `U` debe ter o mesmo tamaño e aliñamento que `T`.
    /// Isto é trivialmente certo se `U` é `T`.
    /// Teña en conta que se `U` non é `T` pero ten o mesmo tamaño e aliñamento, isto é basicamente como transmutar referencias de diferentes tipos.
    /// Vexa [`mem::transmute`][transmute] para obter máis información sobre as restricións que se aplican neste caso.
    ///
    /// O usuario de `from_raw` ten que asegurarse de que un valor específico de `T` só se cae unha vez.
    ///
    /// Esta función non é segura porque un uso inadecuado pode causar seguridade na memoria, aínda que nunca se acceda ao `Rc<T>` devolto.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Converta de novo nun `Rc` para evitar fugas.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Outras chamadas a `Rc::from_raw(x_ptr)` non terían memoria.
    /// }
    ///
    /// // A memoria liberouse cando `x` saíu do alcance anterior, polo que `x_ptr` agora está colgando.
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Inverte o desprazamento para atopar o RcBox orixinal.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Crea un novo punteiro [`Weak`] para esta asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Asegúrese de que non creamos un débil colgante
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Obtén o número de punteiros [`Weak`] para esta asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Obtén o número de punteiros (`Rc`) fortes para esta asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Devolve `true` se non hai outros punteiros `Rc` ou [`Weak`] para esta asignación.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Devolve unha referencia mutable no `Rc` indicado, se non hai outros punteiros `Rc` ou [`Weak`] para a mesma asignación.
    ///
    ///
    /// Devolve [`None`] doutro xeito, porque non é seguro mudar un valor compartido.
    ///
    /// Vexa tamén [`make_mut`][make_mut], que terá [`clone`][clone] o valor interno cando hai outros punteiros.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Devolve unha referencia mutable no `Rc` indicado, sen ningunha comprobación.
    ///
    /// Vexa tamén [`get_mut`], que é seguro e realiza as comprobacións adecuadas.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Calquera outro punteiro `Rc` ou [`Weak`] para a mesma asignación non debe ser anulado durante a duración do préstamo devolto.
    ///
    /// Isto é trivialmente o caso se non existen tales punteiros, por exemplo inmediatamente despois do `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Temos o coidado de *non* crear unha referencia que cubra os campos "count", xa que isto entraría en conflito cos accesos aos contos de referencia (por exemplo,
        // por `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Devolve `true` se os dous `Rc` apuntan á mesma asignación (nunha liña similar a [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Fai unha referencia mutable no `Rc` dado.
    ///
    /// Se hai outros punteiros `Rc` para a mesma asignación, entón `make_mut` x02X o valor interno dunha nova asignación para garantir a propiedade única.
    /// Isto tamén se coñece como clonación en escritura.
    ///
    /// Se non hai outros punteiros `Rc` para esta asignación, entón os punteiros [`Weak`] para esta asignación desvincularanse.
    ///
    /// Vexa tamén [`get_mut`], que fallará máis que clonar.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Non clonarei nada
    /// let mut other_data = Rc::clone(&data);    // Non clonará datos internos
    /// *Rc::make_mut(&mut data) += 1;        // Clona datos internos
    /// *Rc::make_mut(&mut data) += 1;        // Non clonarei nada
    /// *Rc::make_mut(&mut other_data) *= 2;  // Non clonarei nada
    ///
    /// // Agora `data` e `other_data` apuntan a diferentes asignacións.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] os punteiros desvincularanse:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Debo clonar os datos, hai outros Rcs.
            // Pre-asignar memoria para permitir escribir directamente o valor clonado.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Só podo roubar os datos, só queda Débil
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Elimina o ref implícito forte-débil (non fai falta crear un falso débil aquí; sabemos que outros febles poden limparnos)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Esta inseguridade está ben porque temos a garantía de que o punteiro devolto é o *único* que sempre se devolverá a T.
        // O noso reconto de referencias está garantido a 1 neste momento e requirimos que o propio `Rc<T>` sexa `mut`, polo que devolveremos a única referencia posible á asignación.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Intente abater o `Rc<dyn Any>` a un tipo concreto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Asigna un `RcBox<T>` con espazo suficiente para un valor interior posiblemente non dimensionado onde o valor teña o deseño proporcionado.
    ///
    /// A función `mem_to_rcbox` chámase co punteiro de datos e debe devolver un punteiro (potencialmente gordo) para o `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Calcula o deseño empregando o deseño do valor indicado.
        // Anteriormente, o deseño calculábase na expresión `&*(ptr as* const RcBox<T>)`, pero isto creou unha referencia desalineada (ver #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Asigna un `RcBox<T>` con espazo suficiente para un valor interno posiblemente sen tamaño onde o valor ten o deseño proporcionado, devolvendo un erro se falla a asignación.
    ///
    ///
    /// A función `mem_to_rcbox` chámase co punteiro de datos e debe devolver un punteiro (potencialmente gordo) para o `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Calcula o deseño empregando o deseño do valor indicado.
        // Anteriormente, o deseño calculábase na expresión `&*(ptr as* const RcBox<T>)`, pero isto creou unha referencia desalineada (ver #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Asignar o deseño.
        let ptr = allocate(layout)?;

        // Inicialice o RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Asigna un `RcBox<T>` con espazo suficiente para un valor interior non dimensionado
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Asigne o `RcBox<T>` usando o valor indicado.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copia o valor como bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Libre a asignación sen deixar caer o seu contido
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Asigna un `RcBox<[T]>` coa lonxitude indicada.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Copia elementos da porción no Rc <\[T\]> recentemente asignado
    ///
    /// Non é seguro porque o interlocutor debe asumir a propiedade ou vincular `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Constrúe un `Rc<[T]>` a partir dun iterador que se sabe dun certo tamaño.
    ///
    /// O comportamento non está definido se o tamaño é incorrecto.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic garda ao clonar elementos en T.
        // No caso dun panic, os elementos que se escribiron no novo RcBox caeranse e liberarase a memoria.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Punteiro ao primeiro elemento
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Todo claro.Esqueza a garda para que non libere o novo RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Especialización trait usada para `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Solta o `Rc`.
    ///
    /// Isto diminuirá o forte reconto de referencia.
    /// Se o reconto de referencias fortes chega a cero, as únicas outras referencias (se as hai) son [`Weak`], polo que `drop` o valor interno.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Non imprime nada
    /// drop(foo2);   // Imprime "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // destruír o obxecto contido
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // elimina o punteiro "strong weak" implícito agora que destruímos o contido.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Fai un clon do punteiro `Rc`.
    ///
    /// Isto crea outro punteiro para a mesma asignación, aumentando o reconto de referencia forte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Crea un novo `Rc<T>`, co valor `Default` para `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Corte para permitir especializarse en `Eq` aínda que `Eq` ten un método.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Estamos facendo esta especialización aquí, e non como unha optimización máis xeral en `&T`, porque doutro xeito engadiría un custo a todas as comprobacións de igualdade dos ref.
/// Supoñemos que os `Rc` úsanse para almacenar valores grandes, que son lentos para clonarse, pero tamén pesados para comprobar a igualdade, o que fai que este custo se pague máis facilmente.
///
/// Tamén é máis probable que teña dous clons `Rc`, que apuntan ao mesmo valor, que dous `&T`.
///
/// Só podemos facelo cando `T: Eq` como `PartialEq` pode ser deliberadamente irreflexivo.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Igualdade para dous `Rc`s.
    ///
    /// Dous `Rc` son iguais se os seus valores internos son iguais, aínda que estean almacenados nunha asignación diferente.
    ///
    /// Se `T` tamén implementa `Eq` (o que implica reflexividade de igualdade), dous `Rc` que apuntan á mesma asignación son sempre iguais.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Desigualdade para dous `Rc`s.
    ///
    /// Dous `Rc` son desiguais se os seus valores internos son desiguais.
    ///
    /// Se `T` tamén implementa `Eq` (o que implica reflexividade de igualdade), dous `Rc` que apuntan á mesma asignación nunca serán desiguais.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Comparación parcial para dous `Rc`s.
    ///
    /// Os dous compáranse chamando ao `partial_cmp()` polos seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Comparación inferior a dous "Rc".
    ///
    /// Os dous compáranse chamando ao `<` polos seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Comparación "inferior ou igual a" para dous "Rc".
    ///
    /// Os dous compáranse chamando ao `<=` polos seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Comparación superior a dúas "Rc".
    ///
    /// Os dous compáranse chamando ao `>` polos seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Comparación "maior ou igual a" para dous "Rc".
    ///
    /// Os dous compáranse chamando ao `>=` polos seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Comparación para dous `Rc`s.
    ///
    /// Os dous compáranse chamando ao `cmp()` polos seus valores internos.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Asigne unha porción contada por referencias e énchea clonando elementos de `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Asigne unha porción de cadea contada por referencias e copia nela `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Asigne unha porción de cadea contada por referencias e copia nela `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Move un obxecto en caixa a unha nova asignación de contas de referencias.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Asigna unha porción contada por referencias e move nela os elementos de `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Permite ao Vec liberar a súa memoria, pero non destruír o seu contido
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Colle cada elemento do `Iterator` e recólleo nun `Rc<[T]>`.
    ///
    /// # Características de rendemento
    ///
    /// ## O caso xeral
    ///
    /// No caso xeral, a recollida en `Rc<[T]>` faise primeiro recolléndoa nun `Vec<T>`.É dicir, ao escribir o seguinte:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// isto compórtase coma se escribísemos:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Aquí faise o primeiro conxunto de asignacións.
    ///     .into(); // Aquí ocorre unha segunda asignación para `Rc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Isto asignarase cantas veces sexa necesario para construír o `Vec<T>` e despois asignarase unha vez para converter o `Vec<T>` no `Rc<[T]>`.
    ///
    ///
    /// ## Iteradores de lonxitude coñecida
    ///
    /// Cando o `Iterator` implemente `TrustedLen` e teña un tamaño exacto, farase unha única asignación para o `Rc<[T]>`.Por exemplo:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Aquí só ocorre unha única asignación.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Especialización trait empregada para recoller en `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Este é o caso dun iterador `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SEGURIDADE: debemos asegurarnos de que o iterador ten unha lonxitude exacta e temos.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Volve á implementación normal.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` é unha versión de [`Rc`] que ten unha referencia non propietaria á asignación xestionada.Accédese á asignación chamando a [`upgrade`] no punteiro `Weak`, que devolve unha [`Opción`]`<`[`Rc`] `<T>>`.
///
/// Dado que unha referencia `Weak` non conta na propiedade, non impedirá que se elimine o valor almacenado na asignación e o propio `Weak` non ofrece garantías sobre o valor que aínda está presente.
/// Así, pode devolver [`None`] cando [`actualizar`] d.
/// Non obstante, teña en conta que unha referencia `Weak`*non* impide que a asignación en si (o almacén de respaldo) se reparte.
///
/// Un punteiro `Weak` é útil para manter unha referencia temporal á asignación xestionada por [`Rc`] sen evitar que se caia o seu valor interno.
/// Tamén se usa para evitar referencias circulares entre punteiros [`Rc`], xa que as mutuas referencias nunca permitirían deixar caer ningún dos dous [`Rc`].
/// Por exemplo, unha árbore podería ter fortes punteiros [`Rc`] desde nodos pais ata nenos, e punteiros `Weak` de nenos de volta aos seus pais.
///
/// O xeito típico de obter un punteiro `Weak` é chamar ao [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Este é un `NonNull` que permite optimizar o tamaño deste tipo en enumeracións, pero non é necesariamente un punteiro válido.
    //
    // `Weak::new` configura isto en `usize::MAX` para que non precise asignar espazo no montón.
    // Ese non é un valor que un punteiro real terá porque RcBox ten alineación polo menos 2.
    // Isto só é posible cando `T: Sized`;`T` sen tamaño nunca colga.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Constrúe un novo `Weak<T>` sen asignar memoria.
    /// Chamar a [`upgrade`] polo valor devolto sempre proporciona [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Tipo de axuda para permitir o acceso aos contos de referencia sen facer ningunha afirmación sobre o campo de datos.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Devolve un punteiro en bruto ao obxecto `T` ao que apunta este `Weak<T>`.
    ///
    /// O punteiro só é válido se hai algunhas referencias fortes.
    /// O punteiro pode estar colgado, sen aliñar ou incluso [`null`] doutro xeito.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Ambos apuntan ao mesmo obxecto
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // O forte aquí o mantén vivo, polo que aínda podemos acceder ao obxecto.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Pero xa non.
    /// // Podemos facer weak.as_ptr(), pero acceder ao punteiro levaría a un comportamento indefinido.
    /// // assert_eq! ("ola", inseguro {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Se o punteiro está colgado, devolvemos o centinela directamente.
            // Non pode ser un enderezo de carga útil válido, xa que a carga útil está polo menos tan aliñada como RcBox (usize).
            ptr as *const T
        } else {
            // SEGURIDADE: se is_dangling devolve falso, entón o punteiro non se pode referenciar.
            // A carga útil pode ser eliminada neste momento e temos que manter a procedencia, así que use a manipulación do punteiro en bruto.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Consume o `Weak<T>` e convérteo nun punteiro en bruto.
    ///
    /// Isto converte o punteiro débil nun punteiro en bruto, aínda que conserva a propiedade dunha referencia débil (o reconto débil non se modifica con esta operación).
    /// Pódese converter de novo no `Weak<T>` con [`from_raw`].
    ///
    /// As mesmas restricións para acceder ao destino do punteiro que con [`as_ptr`] aplícanse.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Converte un punteiro en bruto creado previamente por [`into_raw`] de novo en `Weak<T>`.
    ///
    /// Isto pódese usar para obter unha referencia segura (chamando máis tarde a [`upgrade`]) ou para localizar a conta débil caendo o `Weak<T>`.
    ///
    /// Toma a propiedade dunha referencia débil (coa excepción dos punteiros creados por [`new`], xa que estes non posúen nada; o método aínda funciona neles).
    ///
    /// # Safety
    ///
    /// O punteiro debe ter a súa orixe no [`into_raw`] e aínda debe posuír a súa feble referencia potencial.
    ///
    /// Permítese que o reconto forte sexa 0 no momento de chamar isto.
    /// Non obstante, isto faise propietario dunha referencia débil representada actualmente como un punteiro en bruto (a conta débil non se modifica con esta operación) e, polo tanto, debe combinarse cunha chamada previa a [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Diminúe o último reconto débil.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Vexa Weak::as_ptr para o contexto sobre como se deriva o punteiro de entrada.

        let ptr = if is_dangling(ptr as *mut T) {
            // Este é un débil colgante.
            ptr as *mut RcBox<T>
        } else {
            // En caso contrario, temos a garantía de que o punteiro proviña dun débil incomprensible.
            // SEGURIDADE: data_offset é seguro de chamar, xa que ptr fai referencia a un T. real (potencialmente caído)
            let offset = unsafe { data_offset(ptr) };
            // Así, invertimos a compensación para obter todo o RcBox.
            // SEGURIDADE: o punteiro orixinouse a partir dun punto débil, polo que este desprazamento é seguro.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SEGURIDADE: agora recuperamos o punteiro feble orixinal, polo que podemos crear o feble.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Tenta actualizar o punteiro `Weak` a un [`Rc`], retrasando a caída do valor interno se ten éxito.
    ///
    ///
    /// Devolve [`None`] se desde entón se eliminou o valor interno.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Destruír todos os indicadores fortes.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Obtén o número de punteiros (`Rc`) fortes que apuntan a esta asignación.
    ///
    /// Se `self` se creou usando [`Weak::new`], devolverá 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Obtén o número de punteiros `Weak` que apuntan a esta asignación.
    ///
    /// Se non quedan indicadores fortes, devolverá cero.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // restar o ptr débil implícito
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Devolve `None` cando o punteiro está colgado e non hai `RcBox` asignado, (é dicir, cando este `Weak` foi creado por `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Temos coidado de *non* crear unha referencia que cubra o campo "data", xa que o campo pode mutarse simultaneamente (por exemplo, se se baixa o último `Rc`, o campo de datos caerá no seu lugar).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Devolve `true` se os dous `Débiles` apuntan á mesma asignación (similar a [`ptr::eq`]), ou se ambos non apuntan a ningunha asignación (porque foron creados con `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Dado que isto compara os punteiros, significa que `Weak::new()` será igual, aínda que non apunten a ningunha asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Comparando `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Solta o punteiro `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Non imprime nada
    /// drop(foo);        // Imprime "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // o reconto débil comeza a 1 e só irá a cero se desapareceron todos os punteiros fortes.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Fai un clon do punteiro `Weak` que apunta á mesma asignación.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Constrúe un novo `Weak<T>`, asignando memoria para `T` sen inicializalo.
    /// Chamar a [`upgrade`] polo valor devolto sempre proporciona [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Comprobamos_aquí para tratar con mem::forget con seguridade.En particular
// se mem::forget Rcs (ou Weaks), o reconto pode desbordarse e entón pode liberar a asignación mentres existan Rcs (ou Weaks) pendentes.
//
// Abortamos porque este é un escenario tan dexenerado que non nos importa o que suceda; ningún programa real debería experimentalo.
//
// Isto debería ter unha sobrecarga despreciable xa que en realidade non é preciso clonalo en Rust grazas á propiedade e movemento-semántica.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Queremos abortar por desbordamento en lugar de deixar caer o valor.
        // O reconto de referencia nunca será cero cando se chama isto;
        // non obstante, inserimos aquí un aborto para suxerir LLVM nunha optimización que por outra banda se perdeu.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Queremos abortar por desbordamento en lugar de deixar caer o valor.
        // O reconto de referencia nunca será cero cando se chama isto;
        // non obstante, inserimos aquí un aborto para suxerir LLVM nunha optimización que por outra banda se perdeu.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Obtén a compensación nun `RcBox` pola carga útil detrás dun punteiro.
///
/// # Safety
///
/// O punteiro debe apuntar a (e ter metadatos válidos para) unha instancia válida previamente de T, pero permítese soltar a T.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Aliña o valor sen tamaño ao final do RcBox.
    // Debido a que RcBox é repr(C), sempre será o último campo da memoria.
    // SEGURIDADE: xa que os únicos tipos non dimensionados posibles son franxas, obxectos trait,
    // e tipos externos, o requisito de seguridade de entrada é actualmente suficiente para satisfacer os requisitos de align_of_val_raw;este é un detalle de implementación da linguaxe que non se pode confiar fóra de std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}