//! O alloc Prelude
//!
//! O propósito deste módulo é aliviar as importacións de elementos de uso común do `alloc` crate engadindo unha importación de globos á parte superior dos módulos:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;