//! מבט בגודל דינמי לרצף רציף, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! פרוסות הן מבט לגוש זיכרון המיוצג כמצביע ואורך.
//!
//! ```
//! // חותך Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // כפיית מערך לפרוסה
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! פרוסות ניתנות לשינוי או משותפות.
//! סוג הפרוסה המשותפת הוא `&[T]`, בעוד שסוג הפרוסה המשתנה הוא `&mut [T]`, כאשר `T` מייצג את סוג האלמנט.
//! לדוגמה, אתה יכול לשנות את גוש הזיכרון שפרוסה ניתנת לשינוי מצביעה עליו:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! להלן כמה דברים שמודול זה מכיל:
//!
//! ## Structs
//!
//! ישנן מספר סטרוקטורות שימושיות לפרוסות, כגון [`Iter`], המייצג איטרציה על פני פרוסה.
//!
//! ## יישומי Trait
//!
//! ישנם מספר יישומים של traits נפוצים עבור פרוסות.כמה דוגמאות כוללות:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], לפרוסות שסוג האלמנט שלהן הוא [`Eq`] או [`Ord`].
//! * [`Hash`] - לפרוסות שסוג האלמנט שלהן הוא [`Hash`].
//!
//! ## Iteration
//!
//! הפרוסות מיישמות את `IntoIterator`.האיטרטור מניב התייחסויות לרכיבי הפרוסה.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! הנתח המשתנה מניב הפניות משתנות לאלמנטים:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! איטרטור זה מניב הפניות ניתנות לשינוי לאלמנטים של הפרוסה, ולכן בעוד שסוג האלמנט של הנתח הוא `i32`, סוג האלמנט של האיטרטור הוא `&mut i32`.
//!
//!
//! * [`.iter`] ו-[`.iter_mut`] הן השיטות המפורשות להחזרת איטרטורי ברירת המחדל.
//! * שיטות נוספות שמחזירות איטרטורים הן [`.split`], [`.splitn`], [`.chunks`], [`.windows`] ועוד.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// רבים מהשימושים במודול זה משמשים רק בתצורת הבדיקה.
// זה נקי יותר פשוט לכבות את האזהרה שאינה בשימוש_יבוא מאשר לתקן אותם.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// שיטות בסיסיות להארכת פרוסות
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) הדרוש ליישום מאקרו `vec!` במהלך בדיקת NB, עיין במודול `hack` בקובץ זה לפרטים נוספים.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) הדרוש ליישום `Vec::clone` במהלך בדיקת NB, עיין במודול `hack` בקובץ זה לפרטים נוספים.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): עם cfg(test) `impl [T]` אינו זמין, שלוש הפונקציות הללו הן למעשה שיטות שנמצאות ב-`impl [T]` אך לא ב-`core::slice::SliceExt`, עלינו לספק פונקציות אלה לצורך בדיקת `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // אנחנו לא צריכים להוסיף לזה תכונה מוטבעת מכיוון שזה משמש במאקרו `vec!` בעיקר וגורם לנסיגה מושלמת.
    // ראה #71204 לדיון ותוצאות מושלמות.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // פריטים סומנו באותיות גדולות בלולאה למטה
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) הוא הכרחי עבור LLVM להסיר בדיקות גבולות ויש לו קודגן טוב יותר מאשר zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // ה-vec הוקצה ואותחל לאורכו לפחות.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // שהוקצה לעיל עם קיבולת של `s`, ואתחל ל-`s.len()` ב-ptr::copy_to_non_overlapping למטה.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// ממיין את הנתח.
    ///
    /// מין זה יציב (כלומר, אינו מסדר מחדש אלמנטים שווים) ו-*O*(*n*\*log(* n*)) במקרה הגרוע ביותר.
    ///
    /// במידת הצורך, עדיף מיון לא יציב מכיוון שהוא בדרך כלל מהיר יותר ממיון יציב והוא אינו מקצה זיכרון עזר.
    /// ראה [`sort_unstable`](slice::sort_unstable).
    ///
    /// # יישום שוטף
    ///
    /// האלגוריתם הנוכחי הוא סוג מיזוג אדפטיבי, איטרטיבי, בהשראת [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// היא נועדה להיות מהירה מאוד במקרים בהם הנתח כמעט ממוין, או מורכב משני רצפים ממוינים או יותר המורכבים זה אחר זה.
    ///
    ///
    /// כמו כן, הוא מקצה אחסון זמני בגודל של `self`, אך עבור פרוסות קצרות משתמשים במקום סוג הכנסה שאינו מקצה.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// ממיין את הנתח עם פונקציית השוואה.
    ///
    /// מין זה יציב (כלומר, אינו מסדר מחדש אלמנטים שווים) ו-*O*(*n*\*log(* n*)) במקרה הגרוע ביותר.
    ///
    /// על פונקציית ההשוואה להגדיר סדר כולל עבור האלמנטים בפרוסה.אם ההזמנה אינה מוחלטת, סדר האלמנטים אינו מוגדר.
    /// הזמנה היא הזמנה כוללת אם היא (לכל `a`, `b` ו-`c`):
    ///
    /// * כולל ואנטי-סימטרי: בדיוק אחד מ-`a < b`, `a == b` או `a > b` נכון, וגם
    /// * מעבר, `a < b` ו-`b < c` מרמז על `a < c`.אותו הדבר חייב להחזיק גם ב-`==` וגם ב-`>`.
    ///
    /// לדוגמא, בעוד ש-[`f64`] אינו מיישם את [`Ord`] מכיוון ש-`NaN != NaN`, אנו יכולים להשתמש ב-`partial_cmp` כפונקציית המיון שלנו כשאנו יודעים שהפרוסה אינה מכילה `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// במידת הצורך, עדיף מיון לא יציב מכיוון שהוא בדרך כלל מהיר יותר ממיון יציב והוא אינו מקצה זיכרון עזר.
    /// ראה [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # יישום שוטף
    ///
    /// האלגוריתם הנוכחי הוא סוג מיזוג אדפטיבי, איטרטיבי, בהשראת [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// היא נועדה להיות מהירה מאוד במקרים בהם הנתח כמעט ממוין, או מורכב משני רצפים ממוינים או יותר המורכבים זה אחר זה.
    ///
    /// כמו כן, הוא מקצה אחסון זמני בגודל של `self`, אך עבור פרוסות קצרות משתמשים במקום סוג הכנסה שאינו מקצה.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // מיון הפוך
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// ממיין את הנתח עם פונקציית חילוץ מפתח.
    ///
    /// מיון זה יציב (כלומר, אינו מסדר מחדש אלמנטים שווים) ו-*O*(*m*\* * n *\* log(*n*)) במקרה הגרוע ביותר, כאשר פונקציית המפתח היא *O*(*m*).
    ///
    /// עבור פונקציות מפתח יקרות (למשל
    /// פונקציות שאינן גישה נכסית פשוטה או פעולות בסיסיות), סביר להניח ש-[`sort_by_cached_key`](slice::sort_by_cached_key) יהיה מהיר יותר באופן משמעותי, מכיוון שהוא אינו מחשב מחדש את מקשי האלמנטים.
    ///
    ///
    /// במידת הצורך, עדיף מיון לא יציב מכיוון שהוא בדרך כלל מהיר יותר ממיון יציב והוא אינו מקצה זיכרון עזר.
    /// ראה [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # יישום שוטף
    ///
    /// האלגוריתם הנוכחי הוא סוג מיזוג אדפטיבי, איטרטיבי, בהשראת [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// היא נועדה להיות מהירה מאוד במקרים בהם הנתח כמעט ממוין, או מורכב משני רצפים ממוינים או יותר המורכבים זה אחר זה.
    ///
    /// כמו כן, הוא מקצה אחסון זמני בגודל של `self`, אך עבור פרוסות קצרות משתמשים במקום סוג הכנסה שאינו מקצה.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// ממיין את הנתח עם פונקציית חילוץ מפתח.
    ///
    /// במהלך המיון, פונקציית המפתח נקראת רק פעם אחת לכל אלמנט.
    ///
    /// מיון זה יציב (כלומר, אינו מסדר מחדש אלמנטים שווים) ו-*O*(*m*\* * n *+* n *\* log(*n*)) במקרה הגרוע ביותר, כאשר פונקציית המפתח היא *O*(*m*) .
    ///
    /// עבור פונקציות מפתח פשוטות (למשל פונקציות שהן גישה למאפיינים או פעולות בסיסיות), סביר להניח ש-[`sort_by_key`](slice::sort_by_key) יהיה מהיר יותר.
    ///
    /// # יישום שוטף
    ///
    /// האלגוריתם הנוכחי מבוסס על [pattern-defeating quicksort][pdqsort] של אורסון פיטרס, המשלב את המקרה הממוצע המהיר של סיבית אקראית אקראית עם המקרה הגרוע ביותר של ערימה גדולה, תוך השגת זמן ליניארי על פרוסות עם תבניות מסוימות.
    /// הוא משתמש באקראיות מסוימת כדי למנוע מקרים מנווונים, אך עם seed קבוע כדי לספק תמיד התנהגות דטרמיניסטית.
    ///
    /// במקרה הגרוע ביותר, האלגוריתם מקצה אחסון זמני ב-`Vec<(K, usize)>` לאורך הפרוסה.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // מאקרו עוזר לאינדקס ה-vector שלנו לפי הסוג הקטן ביותר האפשרי, כדי להפחית את ההקצאה.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // האלמנטים של `indices` הם ייחודיים, שכן הם באינדקס, כך שכל סוג יהיה יציב ביחס לפרוסה המקורית.
                // אנו משתמשים ב-`sort_unstable` כאן מכיוון שהוא דורש פחות הקצאת זיכרון.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// מעתיק את `self` ל-`Vec` חדש.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // כאן, ניתן לשנות באופן עצמאי את `s` ו-`x`.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// מעתיק את `self` ל-`Vec` חדש עם מקצה.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // כאן, ניתן לשנות באופן עצמאי את `s` ו-`x`.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // הערה, עיין במודול `hack` בקובץ זה לקבלת פרטים נוספים.
        hack::to_vec(self, alloc)
    }

    /// ממיר את `self` ל-vector ללא שיבוטים או הקצאה.
    ///
    /// ניתן להמיר את ה-vector שנוצר חזרה לקופסה באמצעות `Vec<T>שיטת `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` לא ניתן להשתמש יותר מכיוון שהוא הוסב ל-`x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // הערה, עיין במודול `hack` בקובץ זה לקבלת פרטים נוספים.
        hack::into_vec(self)
    }

    /// יוצר vector על ידי חזרה על פרוסה `n` פעמים.
    ///
    /// # Panics
    ///
    /// פונקציה זו תהיה panic אם הקיבולת תעלה על גדותיה.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic עם הצפה:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // אם `n` גדול מאפס, ניתן לפצל אותו כ-`n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` הוא המספר המיוצג על ידי סיבית ה-'1' השמאלית ביותר של `n`, ו-`rem` הוא החלק הנותר של `n`.
        //
        //

        // באמצעות `Vec` לגישה ל-`set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` החזרה נעשית על ידי הכפלת `buf` `expn` פעמים.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // אם `m > 0`, יש ביטים שנותרו עד '1' השמאלי ביותר.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` בעל קיבולת של `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) החזרה נעשית על ידי העתקת חזרות `rem` ראשונות מ-`buf` עצמו.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // זה לא חופף מאז `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` שווה ל-`buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// משטח פרוסה של `T` לערך יחיד `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// משטח פרוסה של `T` לערך יחיד `Self::Output`, ומניח מפריד נתון בין כל אחד מהם.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// משטח פרוסה של `T` לערך יחיד `Self::Output`, ומניח מפריד נתון בין כל אחד מהם.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// מחזיר vector המכיל עותק של פרוסה זו כאשר כל בייט ממופה לשווה המקביל שלה ל-ASCII.
    ///
    ///
    /// אותיות ASCII 'a' ל-'z' ממופות ל-'A' ל-'Z', אך אותיות שאינן ASCII אינן משתנות.
    ///
    /// כדי להשתמש באותיות רישיות באותיות גדולות, השתמש ב-[`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// מחזירה vector המכיל עותק של פרוסה זו כאשר כל בייט ממופה לשווה המקביל שלה ל-ASCII.
    ///
    ///
    /// אותיות ASCII 'A' ל-'Z' ממופות ל-'a' ל-'z', אך אותיות שאינן ASCII אינן משתנות.
    ///
    /// כדי להקטין את הערך במקום, השתמש ב-[`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// הרחבה traits לפרוסות על סוגים ספציפיים של נתונים
////////////////////////////////////////////////////////////////////////////////

/// עוזר trait עבור [`[T]: : concat`](פרוסה::concat).
///
/// Note: לא נעשה שימוש בפרמטר מסוג `Item` ב-trait זה, אך הוא מאפשר ל-impls להיות כללי יותר.
/// בלעדיה, אנו מקבלים את השגיאה הזו:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// הסיבה לכך היא שיכולים להתקיים סוגי `V` עם מספר יישומי `Borrow<[_]>`, כך שחלים על מספר `T`:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// הסוג המתקבל לאחר שרשור
    type Output;

    /// יישום של [`[T]: : concat`](פרוסה::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// עוזר trait עבור [`[T]: : להצטרף '](פרוסה::הצטרף)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// הסוג המתקבל לאחר שרשור
    type Output;

    /// יישום של [`[T]: : להצטרף '](פרוסה::הצטרפות)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// יישומי trait סטנדרטיים לפרוסות
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // שחרר כל מטרה שלא תוחלף
        target.truncate(self.len());

        // target.len <= self.len בגלל הקטיעה שלמעלה, כך שהפרוסות כאן תמיד בגבול.
        //
        let (init, tail) = self.split_at(target.len());

        // השתמש מחדש בערכים הכלולים allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// מכניס את `v[0]` לרצף הממוין מראש `v[1..]` כך שכל ה-`v[..]` יהפוך למיון.
///
/// זהו תת-דרך אינטגרלית של מיון הכנסה.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // ישנן שלוש דרכים ליישם את ההכנסה כאן:
            //
            // 1. החלף אלמנטים סמוכים עד שהראשון יגיע ליעדו הסופי.
            //    עם זאת, בדרך זו אנו מעתיקים נתונים מעבר לדרוש.
            //    אם אלמנטים הם מבנים גדולים (יקר להעתקה), שיטה זו תהיה איטית.
            //
            // 2. בוטל עד שנמצא המקום הנכון לאלמנט הראשון.
            // ואז העבירו את האלמנטים שיצליחו בכך כדי לפנות לו מקום ולבסוף הניחו אותו בחור שנותר.
            // זו שיטה טובה.
            //
            // 3. העתק את האלמנט הראשון למשתנה זמני.בוטל עד שנמצא המקום הנכון לכך.
            // ככל שאנו הולכים, העתק כל אלמנט שעבר דרך החריץ שקדם לו.
            // לבסוף, העתק נתונים מהמשתנה הזמני לחור שנותר.
            // שיטה זו טובה מאוד.
            // מדדי המידה הראו ביצועים מעט טובים יותר מאשר בשיטה השנייה.
            //
            // כל השיטות היו ממושכות, והשלישית הראתה את התוצאות הטובות ביותר.אז בחרנו בזה.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // תמיד נמצא מעקב אחר מצב הביניים של תהליך ההכנסה על ידי `hole`, המשרת שתי מטרות:
            // 1. מגן על תקינות ה-`v` מפני panics ב-`is_less`.
            // 2. ממלא בסוף את החור שנותר ב-`v`.
            //
            // Panic בטיחות:
            //
            // אם `is_less` panics בנקודה כלשהי במהלך התהליך, `hole` יירד וימלא את החור ב-`v` עם `tmp`, ובכך יבטיח כי `v` עדיין מחזיק כל אובייקט שהחזיק בתחילה בדיוק פעם אחת.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` יורד וכך מעתיק את `tmp` לחור שנותר ב-`v`.
        }
    }

    // כאשר הוא נשמט, העתקים מ-`src` ל-`dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// ממזג את הריצות `v[..mid]` ו-`v[mid..]` ללא ירידה תוך שימוש ב-`buf` כאחסון זמני ומאחסן את התוצאה ב-`v[..]`.
///
/// # Safety
///
/// שתי הפרוסות חייבות להיות לא ריקות ו-`mid` חייב להיות בגבול.
/// מאגר `buf` חייב להיות ארוך מספיק כדי להחזיק עותק של הנתח הקצר יותר.
/// כמו כן, `T` לא יכול להיות סוג בגודל אפס.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // תהליך המיזוג מעתיק לראשונה את הריצה הקצרה יותר ל-`buf`.
    // לאחר מכן הוא עוקב אחר הריצה שהועתקה לאחרונה והריצה ארוכה יותר קדימה (או אחורה), תוך השוואת האלמנטים הלא-צרכניים הבאים שלהם והעתקת הקטן (או הגדול יותר) ל-`v`.
    //
    // ברגע שהריצה הקצרה יותר נצרכת במלואה, התהליך מתבצע.אם הריצה הארוכה יותר נצרכת תחילה, עלינו להעתיק את כל מה שנותר מהריצה הקצרה יותר אל החור שנותר ב-`v`.
    //
    // תמיד מתבצע מעקב אחר מצב הביניים של התהליך על ידי `hole`, המשרת שתי מטרות:
    // 1. מגן על תקינות ה-`v` מפני panics ב-`is_less`.
    // 2. ממלא את החור שנותר ב-`v` אם הריצה הארוכה יותר נצרכת תחילה.
    //
    // Panic בטיחות:
    //
    // אם `is_less` panics בנקודה כלשהי במהלך התהליך, `hole` יירד וימלא את החור ב-`v` בטווח הלא נצרך ב-`buf`, ובכך יבטיח כי `v` עדיין מחזיק כל אובייקט שהחזיק בתחילה בדיוק פעם אחת.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // הריצה השמאלית קצרה יותר.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // בתחילה, מצביעים אלה מצביעים על ראשית מערכיהם.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // צרכו את הצד הפחות.
            // אם שווים, העדיפו את הריצה השמאלית כדי לשמור על יציבות.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // הריצה הנכונה קצרה יותר.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // בתחילה, מצביעים אלה מצביעים על קצות מערכיהם.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // צרכו את הצד הגדול יותר.
            // אם שווים, העדיפו את הריצה הנכונה כדי לשמור על יציבות.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // לבסוף, `hole` יורד.
    // אם הריצה הקצרה יותר לא נצרכה במלואה, כל מה שנשאר ממנה יועתק כעת לחור ב-`v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // כאשר הוא נשמט, מעתיק את הטווח `start..end` ל-`dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` אינו סוג בגודל אפס, אז זה בסדר לחלק לפי הגודל שלו.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// מיון מיזוג זה לווה כמה (אך לא את כל) הרעיונות מ-TimSort, המתואר בפירוט [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// האלגוריתם מזהה המשכים יורדים בהחלט ולא יורדים, הנקראים ריצות טבעיות.יש ערימה של ריצות ממתינות שעדיין לא מוזגו.
/// כל ריצה שנמצאה לאחרונה נדחקת אל הערימה ואז מזוגים כמה זוגות של ריצות סמוכות עד לשביעות רצון של שני הפושעים האלה:
///
/// 1. לכל `i` ב-`1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. לכל `i` ב-`2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// הפונדקים מבטיחים כי זמן הריצה הכולל הוא *O*(*n*\*log(* n*)) במקרה הגרוע ביותר.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // פרוסות עד אורך זה ממוינות באמצעות מיון הכנסה.
    const MAX_INSERTION: usize = 20;
    // ריצות קצרות מאוד מורחבות באמצעות מיון הכנסה כדי להקיף לפחות את האלמנטים הרבים האלה.
    const MIN_RUN: usize = 10;

    // למיון אין התנהגות משמעותית בסוגים בגודל אפס.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // מערכים קצרים ממוינים במקום באמצעות מיון הכנסה כדי למנוע הקצאות.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // הקצה מאגר לשימוש כזיכרון שריטות.אנו שומרים על האורך 0 כדי שנוכל לשמור בו עותקים רדודים של תוכן ה-`v` מבלי להסתכן בכך שהרופאים יפעלו על עותקים אם `is_less` panics.
    //
    // בעת מיזוג שתי ריצות ממוינות, מאגר זה מחזיק עותק של הריצה הקצרה יותר, שתמיד אורך מקסימום `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // על מנת לזהות ריצות טבעיות ב-`v`, אנו חוצים אותה לאחור.
    // זה אולי נראה כמו החלטה מוזרה, אך שקול את העובדה שהתמזגות לעיתים קרובות יותר הולכות בכיוון ההפוך (forwards).
    // על פי אמות מידה, מיזוג קדימה מהיר מעט יותר ממיזוג לאחור.
    // לסיום, זיהוי ריצות על ידי מעבר לאחור משפר את הביצועים.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // מצא את הריצה הטבעית הבאה והפוך אותה אם היא יורדת לחלוטין.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // הכנס עוד כמה אלמנטים לריצה אם זה קצר מדי.
        // מיון ההכנסה מהיר יותר ממיזוג מיזוגים ברצפים קצרים, ולכן זה משפר משמעותית את הביצועים.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // דחף את הריצה הזו אל הערימה.
        runs.push(Run { start, len: end - start });
        end = start;

        // למזג כמה זוגות של ריצות סמוכות כדי לספק את הפושעים.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // לבסוף, בדיוק ריצה אחת חייבת להישאר בערימה.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // בוחן את ערימת הריצות ומזהה את זוג הריצות הבא להתמזג.
    // באופן ספציפי יותר, אם `Some(r)` מוחזר, המשמעות היא שיש למזג את `runs[r]` ו-`runs[r + 1]`.
    // אם האלגוריתם אמור להמשיך לבנות ריצה חדשה במקום זאת, `None` מוחזר.
    //
    // TimSort ידוע לשמצה ביישומי הכרכרה שלה, כמתואר כאן:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // תמצית הסיפור היא: עלינו לאכוף את הפושעים בארבע הריצות הראשונות על הערימה.
    // אכיפתם רק על שלוש הראשונות אינה מספיקה בכדי להבטיח כי הפושעים עדיין יחזיקו במשך *כל* הריצות בערימה.
    //
    // פונקציה זו בודקת כראוי את המשתתפים בארבע הריצות הראשונות.
    // בנוסף, אם הריצה העליונה מתחילה באינדקס 0, היא תמיד תדרוש פעולת מיזוג עד שהמחסנית תתמוטט במלואה, על מנת להשלים את המיון.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}