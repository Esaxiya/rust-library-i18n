#![stable(feature = "wake_trait", since = "1.51.0")]
//! סוגים ו-Traits לעבודה עם משימות אסינכרוניות.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// יישום הערת משימה על ביצוע.
///
/// ניתן להשתמש ב-trait ליצירת [`Waker`].
/// מנהל יכול להגדיר יישום של trait זה, ולהשתמש בזה כדי לבנות Waker שיעביר למשימות שמבוצעות על אותו מבצע.
///
/// trait הוא חלופה חסכונית בזיכרון וארגונומית לבניית [`RawWaker`].
/// הוא תומך בתכנון המוצא הנפוץ שבו הנתונים המשמשים להעיר משימה מאוחסנים ב-[`Arc`].
/// כמה מבצעים (במיוחד אלה עבור מערכות משובצות) אינם יכולים להשתמש ב-API זה, ולכן [`RawWaker`] קיים כחלופה למערכות אלה.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// פונקציית `block_on` בסיסית שלוקחת future ומפעילה אותה עד לסיומה בשרשור הנוכחי.
///
/// **Note:** דוגמה זו סוחרת נכונות לפשטות.
/// על מנת למנוע פסקולים, יישומים בדרגת ייצור יצטרכו גם לטפל בשיחות ביניים ל-`thread::unpark`, כמו גם בהזמנות מקוננות.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// מתעורר שמעיר את החוט הנוכחי כשמתקשרים אליו.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// הפעל future לסיום בשרשור הנוכחי.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // הצמיד את ה-future כך שניתן יהיה לסקור אותו.
///     let mut fut = Box::pin(fut);
///
///     // צור הקשר חדש שיועבר ל-future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // הפעל את future לסיום.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// העירו את המשימה הזו.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// העיר את המשימה הזו מבלי לצרוך את הווייקר.
    ///
    /// אם מנהל תומך תומך בדרך זולה יותר להעיר מבלי לצרוך את הוויקר, עליו לבטל שיטה זו.
    /// כברירת מחדל, הוא משכפל את ה-[`Arc`] וקורא ל-[`wake`] על השיבוט.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // בטיחות: זה בטוח כי raw_waker בונה בבטחה
        // RawWaker מארק<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: פונקציה פרטית זו לבניית RawWaker משמשת במקום
// הטמעת זה ב-`From<Arc<W>> for RawWaker` impl, בכדי להבטיח כי בטיחות ה-`From<Arc<W>> for Waker` אינה תלויה במשלוח הנכון של trait, במקום זאת שני ה-impls קוראים לפונקציה זו באופן ישיר ומפורש.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // הגדל את ספירת ההתייחסות של הקשת כדי לשכפל אותה.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // התעוררו לפי ערך והעבירו את הקשת לפונקציה Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // התעוררו על ידי התייחסות, עטפו את הווייק במניפול דרופ כדי להפיל אותו
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // דחה את ספירת ההתייחסות של הקשת בירידה
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}