#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// תוכן הזיכרון החדש אינו מאוחד.
    Uninitialized,
    /// זיכרון חדש מובטח להיות מאופס.
    Zeroed,
}

/// כלי ברמה נמוכה להקצאה ארגונומית יותר, הקצאה מחדש והקצאת מאגר זיכרון בערימה מבלי לדאוג לכל מקרי הפינה המעורבים.
///
/// סוג זה מצוין לבניית מבני נתונים משלך כמו Vec ו-VecDeque.
/// באופן מיוחד:
///
/// * מייצר `Unique::dangling()` על סוגים אפסיים.
/// * מייצר `Unique::dangling()` בהקצאות באורך אפס.
/// * נמנע משחרור `Unique::dangling()`.
/// * תופס את כל הצפיפות בחישובי הקיבולת (מקדם אותם ל-"capacity overflow" panics).
/// * שומר מפני מערכות של 32 סיביות המקצות יותר מ-isize::MAX בתים.
/// * שומר מפני הצפת אורךך.
/// * מתקשר ל-`handle_alloc_error` לצורך הקצאות שגויות.
/// * מכיל `ptr::Unique` ובכך מעניק למשתמש את כל היתרונות הנלווים.
/// * משתמש בעודף שהוחזר מהמקצה כדי להשתמש בקיבולת הזמינה הגדולה ביותר.
///
/// סוג זה אינו בודק את הזיכרון שהוא מנהל בכל מקרה.כשמפילים אותו *הוא* ישחרר את זיכרונו, אבל הוא *לא* ינסה להפיל את תוכנו.
/// על המשתמש של `RawVec` להתמודד עם הדברים בפועל *המאוחסנים* בתוך `RawVec`.
///
/// שים לב שעודף סוגים בגודל אפס תמיד אינסופי, ולכן `capacity()` מחזיר תמיד `usize::MAX`.
/// פירוש הדבר שעליך להיזהר כשמעליפים עגול מסוג זה עם `Box<[T]>`, מכיוון ש-`capacity()` לא יניב את האורך.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): זה קיים מכיוון ש-`#[unstable]` `const fn`s לא צריך להתאים ל-`min_const_fn` ולכן גם אי אפשר לקרוא להם ב-min_const_fn`s.
    ///
    /// אם תשנה את `RawVec<T>::new` או תלות, אנא הקפד לא להציג שום דבר שיפר באמת את `min_const_fn`.
    ///
    /// NOTE: אנו יכולים להימנע מפריצה זו ולבדוק התאמה עם תכונה כלשהי של `#[rustc_force_min_const_fn]` הדורשת התאמה עם `min_const_fn` אך אינה בהכרח מאפשרת לקרוא לה בקוד `stable(...) const fn`/קוד משתמש שאינו מאפשר `foo` כאשר `#[rustc_const_unstable(feature = "foo", issue = "01234")]` קיים.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// יוצר את ה-`RawVec` הגדול ביותר האפשרי (בערמת המערכת) ללא הקצאה.
    /// אם ל-`T` יש גודל חיובי, זה עושה `RawVec` עם קיבולת `0`.
    /// אם `T` הוא בגודל אפס, אז הוא יוצר `RawVec` עם קיבולת `usize::MAX`.
    /// שימושי ליישום הקצאה מושהית.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// יוצר `RawVec` (בערמת המערכת) עם בדיוק דרישות הקיבולת והיישור עבור `[T; capacity]`.
    /// זה שווה ערך להתקשרות ל-`RawVec::new` כאשר `capacity` הוא `0` או ש-`T` הוא בגודל אפס.
    /// שים לב שאם `T` הוא בגודל אפס זה אומר שאתה *לא* תקבל `RawVec` עם הקיבולת המבוקשת.
    ///
    /// # Panics
    ///
    /// Panics אם הקיבולת המבוקשת עולה על `isize::MAX` בתים.
    ///
    /// # Aborts
    ///
    /// מפסיק ב-OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// כמו `with_capacity`, אך מבטיח שהמאגר אפס.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// מחדש `RawVec` ממצביע ויכולת.
    ///
    /// # Safety
    ///
    /// יש להקצות את ה-`ptr` (בערמת המערכת) ועם ה-`capacity` הנתון.
    /// ה-`capacity` לא יכול לחרוג מ-`isize::MAX` עבור סוגים גדולים.(רק דאגה במערכות 32 סיביות).
    /// ZST vectors יכול להיות בעל קיבולת של עד `usize::MAX`.
    /// אם ה-`ptr` וה-`capacity` מגיעים מ-`RawVec`, זה מובטח.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Vecs זעירים הם מטומטמים.לדלג ל:
    // - 8 אם גודל האלמנט הוא 1, משום שמקצה ערימה כלשהו עשוי לעגל בקשה של פחות מ-8 בתים ל-8 בתים לפחות.
    //
    // - 4 אם האלמנטים בגודל בינוני (<=1 KiB).
    // - אחרת, כדי להימנע מבזבוז מקום רב יותר ל-Vecs קצרים מאוד.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// כמו `new`, אך פרמטר על בחירת המקצה עבור ה-`RawVec` שהוחזר.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` פירושו "unallocated".סוגים בגודל אפס מתעלמים.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// כמו `with_capacity`, אך פרמטר על בחירת המקצה עבור ה-`RawVec` שהוחזר.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// כמו `with_capacity_zeroed`, אך פרמטר על בחירת המקצה עבור ה-`RawVec` שהוחזר.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// ממיר `Box<[T]>` ל-`RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// ממיר את כל המאגר ל-`Box<[MaybeUninit<T>]>` עם ה-`len` שצוין.
    ///
    /// שים לב כי פעולה זו תחדש כהלכה את כל שינויים `cap` שייתכן שבוצעו.(ראה תיאור סוג לפרטים.)
    ///
    /// # Safety
    ///
    /// * `len` חייב להיות גדול או שווה ליכולת המבוקשת לאחרונה, ו
    /// * `len` חייב להיות קטן או שווה ל-`self.capacity()`.
    ///
    /// שים לב, הקיבולת המבוקשת ו-`self.capacity()` עשויים להיות שונים, מכיוון שמקצה יכול להקצות ולהחזיר חסימת זיכרון גדולה יותר מהמתבקש.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // בדוק שפיות מחצית מדרישת הבטיחות (איננו יכולים לבדוק את החצי השני).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // אנו נמנעים מ-`unwrap_or_else` כאן מכיוון שהוא מנפח את כמות ה-LLVM IR שנוצרת.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// מחדש `RawVec` ממצביע, קיבולת ומקצה.
    ///
    /// # Safety
    ///
    /// יש להקצות את ה-`ptr` (דרך המקצה `alloc` הנתון) ועם ה-`capacity` הנתון.
    /// ה-`capacity` לא יכול לחרוג מ-`isize::MAX` עבור סוגים גדולים.
    /// (רק דאגה במערכות 32 סיביות).
    /// ZST vectors יכול להיות בעל קיבולת של עד `usize::MAX`.
    /// אם ה-`ptr` וה-`capacity` מגיעים מ-`RawVec` שנוצר באמצעות `alloc`, זה מובטח.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// מקבל מצביע גולמי לתחילת ההקצאה.
    /// שים לב שזה `Unique::dangling()` אם `capacity == 0` או `T` הוא בגודל אפס.
    /// במקרה הקודם, עליכם להיזהר.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// מקבל את יכולת ההקצאה.
    ///
    /// זה תמיד יהיה `usize::MAX` אם `T` הוא בגודל אפס.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// מחזירה התייחסות משותפת למקצה המגבה `RawVec` זה.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // יש לנו נתח זיכרון שהוקצה, כך שנוכל לעקוף את בדיקות זמן הריצה כדי לקבל את הפריסה הנוכחית שלנו.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// מבטיח כי המאגר מכיל לפחות מספיק מקום להכיל רכיבי `len + additional`.
    /// אם עדיין אין לו מספיק קיבולת, יקצה מחדש מספיק מקום בתוספת שטח רפוי נוח כדי לקבל התנהגות *O*(1) מופחתת.
    ///
    /// יגביל התנהגות זו אם היא תגרום לעצמה ללא צורך ל-panic.
    ///
    /// אם `len` חורג מ-`self.capacity()`, הדבר עשוי להיכשל בהקצאת השטח המבוקש.
    /// זה לא ממש לא בטוח, אבל הקוד הלא בטוח * שאתה כותב שמסתמך על התנהגות פונקציה זו עלול להישבר.
    ///
    /// זה אידיאלי ליישום פעולת דחיפה בכמות גדולה כמו `extend`.
    ///
    /// # Panics
    ///
    /// Panics אם הקיבולת החדשה עולה על `isize::MAX` בתים.
    ///
    /// # Aborts
    ///
    /// מפסיק ב-OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // מילואים היו מפילים או נבהלים אם ה-len חרג מ-`isize::MAX`, כך שניתן לעשות זאת ללא ביטול כעת.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// זהה ל-`reserve`, אך חוזר על שגיאות במקום להיבהל או להפיל.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// מבטיח כי המאגר מכיל לפחות מספיק מקום להכיל רכיבי `len + additional`.
    /// אם זה עדיין לא, יעשה מחדש את כמות הזיכרון המינימלית האפשרית הנחוצה.
    /// באופן כללי זה יהיה בדיוק כמות הזיכרון הנחוצה, אך באופן עקרוני המקצה רשאי להחזיר יותר ממה שביקשנו.
    ///
    ///
    /// אם `len` חורג מ-`self.capacity()`, הדבר עשוי להיכשל בהקצאת השטח המבוקש.
    /// זה לא ממש לא בטוח, אבל הקוד הלא בטוח * שאתה כותב שמסתמך על התנהגות פונקציה זו עלול להישבר.
    ///
    /// # Panics
    ///
    /// Panics אם הקיבולת החדשה עולה על `isize::MAX` בתים.
    ///
    /// # Aborts
    ///
    /// מפסיק ב-OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// זהה ל-`reserve_exact`, אך חוזר על שגיאות במקום להיבהל או להפיל.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// מכווץ את ההקצאה עד לסכום שצוין.
    /// אם הסכום הנתון הוא 0, למעשה מתמקם לחלוטין.
    ///
    /// # Panics
    ///
    /// Panics אם הסכום הנתון *גדול* מהקיבולת הנוכחית.
    ///
    /// # Aborts
    ///
    /// מפסיק ב-OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// חוזר אם המאגר צריך לגדול כדי למלא את הקיבולת הנוספת הנדרשת.
    /// משמש בעיקר לאיפוס שיחות מילואים אפשריות מבלי להטמיע `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // בדרך כלל מיישרים שיטה זו פעמים רבות.אז אנחנו רוצים שהוא יהיה קטן ככל האפשר, וישפר את זמני ההידור.
    // אך אנו רוצים שגם כמה שיותר מתכולתו יהיו ניתנים לחישוב סטטי ככל האפשר, כדי שהקוד שנוצר יפעל מהר יותר.
    // לכן, שיטה זו נכתבת בקפידה כך שכל הקוד שתלוי ב-`T` נמצא בתוכו, בעוד כמה שיותר מהקוד שאינו תלוי ב-`T` נמצא בפונקציות שאינן גנריות מעל `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // זה מובטח על ידי ההקשרים הקוראים.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // מכיוון שאנו מחזירים קיבולת של `usize::MAX` כאשר `elem_size` הוא
            // 0, להגיע לכאן אומר בהכרח שה-`RawVec` מלא מדי.
            return Err(CapacityOverflow);
        }

        // לצערנו שום דבר שאנחנו באמת יכולים לעשות בקשר לבדיקות האלה.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // זה מבטיח צמיחה אקספוננציאלית.
        // ההכפלה לא יכולה לעלות על גדותיה מכיוון ש-`cap <= isize::MAX` וסוג ה-`cap` הוא `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` אינו גנרי מעל `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // האילוצים בשיטה זו הם זהים לאלו שב-`grow_amortized`, אך בדרך כלל שיטה זו מופעלת בתדירות נמוכה יותר ולכן היא פחות קריטית.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // מכיוון שאנו מחזירים קיבולת של `usize::MAX` כאשר גודל הסוג הוא
            // 0, להגיע לכאן אומר בהכרח שה-`RawVec` מלא מדי.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` אינו גנרי מעל `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// פונקציה זו נמצאת מחוץ ל-`RawVec` כדי למזער זמני הידור.ראה את ההערה לעיל `RawVec::grow_amortized` לפרטים.
// (הפרמטר `A` אינו משמעותי מכיוון שמספר סוגי ה-`A` שנראים בפועל קטן בהרבה ממספר סוגי ה-`T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // בדוק אם קיימת השגיאה כאן כדי למזער את גודל ה-`RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // המקצה בודק שוויון יישור
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// משחרר את הזיכרון שבבעלות ה-`RawVec`*מבלי* לנסות להוריד את תוכנו.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// פונקציה מרכזית לטיפול בשגיאות מילואים.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// עלינו להבטיח את הדברים הבאים:
// * אנו אף פעם לא מקצים אובייקטים בגודל `> isize::MAX` בתים.
// * אנחנו לא מציפים את `usize::MAX` ובעצם מקצים מעט מדי.
//
// ב-64 סיביות עלינו רק לבדוק אם קיימת הצפה מכיוון שניסיון להקצות בתים `> isize::MAX` בוודאי ייכשל.
// על 32 סיביות ו-16 סיביות עלינו להוסיף שומר נוסף לשם כך אנו פועלים על פלטפורמה שיכולה להשתמש בכל 4 ג'יגה בייט במרחב המשתמשים, למשל, PAE או x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// פונקציה מרכזית אחת האחראית על הצפת יכולת הדיווח.
// זה יבטיח שייצור הקוד הקשור ל-panics יהיה מינימלי מכיוון שיש רק מיקום אחד אשר panics ולא חבורה לאורך כל המודול.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}