//! ממשקי API להקצאת זיכרון

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // אלה הם סמלי הקסם לקרוא למקצה הגלובלי.rustc מייצר אותם להתקשר ל-`__rg_alloc` וכו '.
    // אם יש תכונה `#[global_allocator]` (הקוד המרחיב את המאקרו של התכונה מייצר פונקציות אלה), או להתקשר ליישומי ברירת המחדל ב-libstd (`__rdl_alloc` וכו ').
    //
    // ב-`library/std/src/alloc.rs`) אחרת.
    // rustc fork של LLVM גם מקרים מיוחדים שמות פונקציות אלה כדי להיות אופטימיזציה כמו `malloc`, `realloc` ו-`free` בהתאמה.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// מקצה הזיכרון הגלובלי.
///
/// סוג זה מיישם את [`Allocator`] trait על ידי העברת שיחות להקצאה הרשומה במאפיין `#[global_allocator]` אם קיימת כזו, או ברירת המחדל של `std` crate.
///
///
/// Note: בעוד שסוג זה אינו יציב, ניתן לגשת לפונקציונליות שהוא מספק באמצעות ה-[free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// הקצה זיכרון עם המקצה הגלובלי.
///
/// פונקציה זו מעבירה שיחות לשיטת [`GlobalAlloc::alloc`] של ההקצאה הרשומה בתכונה `#[global_allocator]` אם קיימת כזו, או ברירת המחדל של `std` crate.
///
///
/// פונקציה זו צפויה להיות מנוטרלת לטובת שיטת `alloc` מסוג [`Global`] כאשר היא וה-[`Allocator`] trait נעשים יציבים.
///
/// # Safety
///
/// ראה [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// הקצה זיכרון עם המקצה הגלובלי.
///
/// פונקציה זו מעבירה שיחות לשיטת [`GlobalAlloc::dealloc`] של ההקצאה הרשומה בתכונה `#[global_allocator]` אם קיימת כזו, או ברירת המחדל של `std` crate.
///
///
/// פונקציה זו צפויה להיות מנוטרלת לטובת שיטת `dealloc` מסוג [`Global`] כאשר היא וה-[`Allocator`] trait נעשים יציבים.
///
/// # Safety
///
/// ראה [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// הקצה מחדש זיכרון עם המקצה הגלובלי.
///
/// פונקציה זו מעבירה שיחות לשיטת [`GlobalAlloc::realloc`] של ההקצאה הרשומה בתכונה `#[global_allocator]` אם קיימת כזו, או ברירת המחדל של `std` crate.
///
///
/// פונקציה זו צפויה להיות מנוטרלת לטובת שיטת `realloc` מסוג [`Global`] כאשר היא וה-[`Allocator`] trait נעשים יציבים.
///
/// # Safety
///
/// ראה [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// הקצה זיכרון מאותחל לאפס עם המקצה הגלובלי.
///
/// פונקציה זו מעבירה שיחות לשיטת [`GlobalAlloc::alloc_zeroed`] של ההקצאה הרשומה בתכונה `#[global_allocator]` אם קיימת כזו, או ברירת המחדל של `std` crate.
///
///
/// פונקציה זו צפויה להיות מנוטרלת לטובת שיטת `alloc_zeroed` מסוג [`Global`] כאשר היא וה-[`Allocator`] trait נעשים יציבים.
///
/// # Safety
///
/// ראה [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // בטיחות: `layout` אינו בגודל אפס,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // בטיחות: זהה ל-`Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // בטיחות: `new_size` אינו אפס שכן `old_size` גדול או שווה ל-`new_size`
            // כנדרש בתנאי הבטיחות.על המתקשר לעמוד בתנאים אחרים
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` כנראה בודק `new_size >= old_layout.size()` או משהו דומה.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // בטיחות: מכיוון ש-`new_layout.size()` חייב להיות גדול או שווה ל-`old_size`,
            // הקצאת הזיכרון הישנה והחדשה תקפה לקריאה וכתיבה עבור בתים `old_size`.
            // כמו כן, מכיוון שההקצאה הישנה טרם הוקצה, היא אינה יכולה לחפוף את `new_ptr`.
            // לפיכך, השיחה ל-`copy_nonoverlapping` בטוחה.
            // חוזה הבטיחות ל-`dealloc` חייב להתקיים על ידי המתקשר.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // בטיחות: `layout` אינו בגודל אפס,
            // התנאים האחרים חייבים להתקיים על ידי המתקשר
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // בטיחות: על המתקשר לשמור על כל התנאים
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // בטיחות: על המתקשר לשמור על כל התנאים
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // בטיחות: על המתקשר לעמוד בתנאים
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // בטיחות: `new_size` אינו אפס.על המתקשר לעמוד בתנאים אחרים
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` כנראה בודק `new_size <= old_layout.size()` או משהו דומה.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // בטיחות: מכיוון ש-`new_size` חייב להיות קטן או שווה ל-`old_layout.size()`,
            // הקצאת הזיכרון הישנה והחדשה תקפה לקריאה וכתיבה עבור בתים `new_size`.
            // כמו כן, מכיוון שההקצאה הישנה טרם הוקצה, היא אינה יכולה לחפוף את `new_ptr`.
            // לפיכך, השיחה ל-`copy_nonoverlapping` בטוחה.
            // חוזה הבטיחות ל-`dealloc` חייב להתקיים על ידי המתקשר.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// הקצאת המצביעים הייחודיים.
// אסור לפונקציה זו להירגע.אם כן, קידוד MIR ייכשל.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// חתימה זו צריכה להיות זהה ל-`Box`, אחרת יקרה ICE.
// כאשר נוסף פרמטר נוסף ל-`Box` (כמו `A: Allocator`), יש להוסיף זאת גם כאן.
// לדוגמא אם `Box` שונה ל-`struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, יש לשנות פונקציה זו גם ל-`fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # מטפל בשגיאות הקצאה

extern "Rust" {
    // זהו סמל הקסם לקרוא למטפל בשגיאות הקצאה גלובלית.
    // rustc מייצר אותו להתקשר ל-`__rg_oom` אם יש `#[alloc_error_handler]`, או להתקשר ליישומי ברירת המחדל מתחת ל-(`__rdl_oom`) אחרת.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// בוטל בשגיאת הקצאת זיכרון או כשל.
///
/// מתקשרים לממשקי API להקצאת זיכרון המעוניינים להפסיק חישוב בתגובה לשגיאת הקצאה, מוזמנים להתקשר לפונקציה זו, במקום להפעיל ישירות `panic!` או דומה.
///
///
/// התנהגות ברירת המחדל של פונקציה זו היא להדפיס הודעה לשגיאה רגילה ולהפסיק את התהליך.
/// ניתן להחליף אותו ב-[`set_alloc_error_hook`] ו-[`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// למבחן הקצאה ניתן להשתמש ישירות ב-`std::alloc::handle_alloc_error`.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // נקרא באמצעות `__rust_alloc_error_handler` שנוצר

    // אם אין `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // אם יש `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// התמחו שיבוטים בזיכרון שלא הוקצה מראש.
/// משמש על ידי `Box::clone` ו-`Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // הקצאת *ראשונה* עשויה לאפשר למיטוב ליצור את הערך המשובט במקום, לדלג על המקומי ולעבור.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // אנחנו תמיד יכולים להעתיק במקום, בלי לערב ערך מקומי.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}