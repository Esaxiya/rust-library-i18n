use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // כתיבת מבחן אינטגרציה בין מקצים של צד שלישי ל-`RawVec` היא מעט מסובכת מכיוון שממשק ה-API של `RawVec` אינו חושף שיטות הקצאה שגויות, ולכן איננו יכולים לבדוק מה קורה כאשר המוקצה מוצה (מעבר לזיהוי panic).
    //
    //
    // במקום זאת, זה רק בודק ששיטות `RawVec` עוברות לפחות דרך ה-API של Allocator כאשר הוא שומר אחסון.
    //
    //
    //
    //
    //

    // מקצה מטומטם הצורך כמות קבועה של דלק לפני שניסיונות ההקצאה מתחילים להיכשל.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (גורם לריאלוק מחדש, ובכך להשתמש ב-50 + 150=200 יחידות דלק)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // ראשית, `reserve` מקצה כמו `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 הוא יותר מכפול מ-7, לכן `reserve` צריך לעבוד כמו `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 הוא פחות ממחצית 12, ולכן `reserve` חייב לצמוח באופן אקספוננציאלי.
        // בזמן הכתיבה גורם הגידול למבחן זה הוא 2, ולכן קיבולת חדשה היא 24, אולם גורם גדילה של 1.5 גם כן בסדר.
        //
        // מכאן `>= 18` בטענה.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}