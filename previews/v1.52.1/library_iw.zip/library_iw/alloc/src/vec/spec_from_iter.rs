use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// התמחות trait המשמשת ל-Vec::from_iter
///
/// ## גרף המשלחת:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // מקרה נפוץ הוא העברת vector לפונקציה שנאספת מיד מחדש ל-vector.
        // אנו יכולים לקצר את זה אם ה-IntoIter כלל לא התקדם.
        // כאשר הוא מתקדם אנו יכולים גם לעשות שימוש חוזר בזיכרון ולהעביר את הנתונים לחזית.
        // אך אנו עושים זאת רק כאשר ל-Vec שנוצר לא תהיה יותר יכולת שאינה בשימוש מאשר ליצור אותו באמצעות היישום הכללי FromIterator.
        //
        // מגבלה זו אינה הכרחית בהחלט מכיוון שהתנהגות ההקצאה של Vec אינה מוגדרת בכוונה.
        // אבל זו בחירה שמרנית.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // חייב להאציל ל-spec_extend() מכיוון ש-extend() עצמו מאציל ל-spec_from עבור Vecs ריקים
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// זה משתמש ב-`iterator.as_slice().to_vec()` מכיוון ש-spec_extend חייב לנקוט בצעדים נוספים כדי לחשוב על הקיבולת הסופית + האורך וכך לעשות יותר עבודה.
// `to_vec()` מקצה ישירות את הסכום הנכון וממלא אותו בדיוק.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): עם cfg(test), שיטת `[T]::to_vec` הטבועה, הנדרשת להגדרת שיטה זו, אינה זמינה.
    // במקום זאת השתמש בפונקציה `slice::to_vec` אשר זמינה רק עם cfg(test) NB ראה את מודול slice::hack ב-slice.rs למידע נוסף
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}