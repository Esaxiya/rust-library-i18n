use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// התמחות נוספת trait עבור Vec::from_iter הכרחית לתעדוף ידני של התמחויות חופפות ראה [`SpecFromIter`](super::SpecFromIter) לפרטים.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // הסר את האיטרציה הראשונה, מכיוון ש-vector הולך להיות מורחב על איטרציה זו בכל מקרה כאשר ה-iterable אינו ריק, אך הלולאה ב-extend_desugared() לא תראה ש-vector יהיה מלא בכמה חזרות הלולאה הבאות.
        //
        // אז אנו מקבלים ניבוי טוב יותר של branch.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // חייב להאציל ל-spec_extend() מכיוון ש-extend() עצמו מאציל ל-spec_from עבור Vecs ריקים
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // חייב להאציל ל-spec_extend() מכיוון ש-extend() עצמו מאציל ל-spec_from עבור Vecs ריקים
        //
        vector.spec_extend(iterator);
        vector
    }
}