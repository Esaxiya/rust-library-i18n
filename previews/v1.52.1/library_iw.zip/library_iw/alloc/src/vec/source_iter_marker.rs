use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// סמן התמחות לאיסוף צינור איטרור ל-Vec תוך שימוש חוזר בהקצאת המקור, כלומר
/// ביצוע הצינור במקום.
///
/// ה-SourceIter האב trait נחוץ לפונקציה המתמחה לגשת להקצאה שעתידה לעשות בה שימוש חוזר.
/// אך לא די בכך שהתמחות תהיה תקפה.
/// ראה גבולות נוספים במידע.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// ה-std הפנימי של SourceIter/InPlaceIterable traits מיושם רק על ידי רשתות מתאם <Adapter<Adapter<IntoIter>>> (כולם בבעלות core/std).
// גבולות נוספים ביישומי המתאם (מעבר ל-`impl<I: Trait> Trait for Adapter<I>`) תלויים רק ב-traits אחרים שכבר סומנו כהתמחות traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. הסמן אינו תלוי בחיי החיים של הסוגים המסופקים על ידי המשתמש.מודולו את חור ההעתקה, שכמה וכמה התמחויות אחרות כבר תלויים בו.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // דרישות נוספות שלא ניתן לבטא באמצעות trait bounds.במקום זאת אנו מסתמכים על הערכה קבועה:
        // א) ללא ZSTs מכיוון שלא תהיה הקצאה לשימוש חוזר וחשבון המצביע היה panic ב) גודל התאמה כנדרש בחוזה Alloc ג) יישור התאמות כנדרש בחוזה Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // נסיגה ליישומים כלליים יותר
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // השתמש בניסיון לקפל מאז
        // - זה יותר וקטורי עבור מתאמי איטרטור מסוימים
        // - בניגוד לרוב שיטות האיטרציה הפנימיות, זה לוקח רק עצמי &mut
        // - זה מאפשר לנו להשחיל את מצביע הכתיבה בתוך הקרביים שלו ולקבל אותו בחזרה בסופו של דבר
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // איטרציה הצליחה, אל תפיל את הראש
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // בדוק אם חוזה SourceIter נשמר אזהרה: אם לא, ייתכן אפילו שלא נגיע לנקודה זו
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // בדוק חוזה InPlaceIterable.זה אפשרי רק אם האיטרטור בכלל קידם את מצביע המקור.
        // אם הוא משתמש בגישה לא מסומנת באמצעות TrustedRandomAccess, מצביע המקור יישאר במצבו ההתחלתי ולא נוכל להשתמש בו כהפניה
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // שחרר את כל הערכים הנותרים בזנב המקור אך מנע ירידה של ההקצאה עצמה ברגע ש-IntoIter יוצא מהתחום אם הטיפה panics אז אנו מדליפים גם את כל האלמנטים שנאספו ל-dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // לא ניתן לאמת את החוזה InPlaceIterable בדיוק כאן מכיוון של-try_fold יש התייחסות בלעדית למצביע המקור כל מה שאנחנו יכולים לעשות זה לבדוק אם הוא עדיין בטווח
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}