use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// איטרטור המשתמש בסגירה כדי לקבוע אם יש להסיר אלמנט.
///
/// מבנה זה נוצר על ידי [`Vec::drain_filter`].
/// עיין בתיעוד שלו לקבלת מידע נוסף.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// אינדקס הפריט שייבדק בשיחה הבאה ל-`next`.
    pub(super) idx: usize,
    /// מספר הפריטים שנקז (removed) עד כה.
    pub(super) del: usize,
    /// האורך המקורי של `vec` לפני ניקוז.
    pub(super) old_len: usize,
    /// פרדיקט מבחן המסנן.
    pub(super) pred: F,
    /// בדגל המציין panic התרחש בפרדיקט בדיקת המסנן.
    /// זה משמש רמז ליישום טיפה למניעת צריכת שארית ה-`DrainFilter`.
    /// פריטים לא מעובדים יוחלפו אחורה ב-`vec`, אך פריטים נוספים לא יושמטו או ייבדקו על ידי פרדיקט המסנן.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// מחזירה הפניה למקצה הבסיסי.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // עדכן את האינדקס * לאחר שקוראים לפרדיקט.
                // אם האינדקס עודכן לפני כן והפרדיקט panics, האלמנט באינדקס זה יודלף.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // זוהי מדינה די מבולגנת, ואין באמת דבר נכון לעשות.
                        // אנחנו לא רוצים להמשיך לנסות לבצע את `pred`, אז אנחנו פשוט מעבירים אחורה את כל האלמנטים הלא מעובדים ואומרים ל-vec שהם עדיין קיימים.
                        //
                        // המעבר האחורי נדרש כדי למנוע ירידה כפולה של הפריט האחרון שנקז בהצלחה לפני panic בפרדיקט.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // נסה לצרוך את כל האלמנטים הנותרים אם פרדיקט המסנן עדיין לא נבהל.
        // נשנה אחורה את כל האלמנטים הנותרים בין אם כבר נכנסנו לפאניקה ובין אם הצריכה כאן panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}