use core::intrinsics;
use core::mem;
use core::ptr;

/// זה מחליף את הערך שמאחורי ההפניה הייחודית של `v` על ידי קריאה לפונקציה הרלוונטית.
///
///
/// אם מתרחש panic בסגירת `change`, התהליך כולו יופסק.
#[allow(dead_code)] // שמור להמחשה ולשימוש ב-future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// זה מחליף את הערך שמאחורי ההפניה הייחודית של `v` על ידי קריאה לפונקציה הרלוונטית ומחזיר תוצאה שהושגה בדרך.
///
///
/// אם מתרחש panic בסגירת `change`, התהליך כולו יופסק.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}