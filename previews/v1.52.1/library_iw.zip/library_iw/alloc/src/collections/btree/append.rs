use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// מוסיף את כל זוגות ערכי המפתח מהאיחוד של שני איטרטורים עולים, תוך הגדלת משתנה `length` בדרך.האחרון מקל על המתקשר להימנע מדליפה כאשר מטפל טיפה נכנס לפאניקה.
    ///
    /// אם שני האיטרטים מייצרים את אותו מפתח, שיטה זו מורידה את הצמד מהאיטרטור השמאלי ומוסיפה את הצמד מהאיטרטור הימני.
    ///
    /// אם אתה רוצה שהעץ יסתדר בסדר עולה בקפידה, כמו ב-`BTreeMap`, שני האיטרטורים צריכים לייצר מפתחות בסדר עולה, כל אחד גדול יותר מכל המקשים בעץ, כולל כל המפתחות שכבר נמצאים בעץ עם הכניסה.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // אנו מתכוננים למזג `left` ו-`right` לרצף ממוין בזמן ליניארי.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // בינתיים אנו בונים עץ מהרצף הממוין בזמן ליניארי.
        self.bulk_push(iter, length)
    }

    /// דוחף את כל זוגות ערך המפתח לקצה העץ, ומגדיל משתנה `length` לאורך הדרך.
    /// האחרון מקל על המתקשר להימנע מדליפה כאשר האיטרטור נכנס לפאניקה.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // חזר בין כל זוגות ערכי המפתח, ודחף אותם לצמתים ברמה הנכונה.
        for (key, value) in iter {
            // נסה לדחוף את צמד ערכי המפתח לצומת העלים הנוכחי.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // לא נשאר מקום, עלו ודחפו לשם.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // מצאתי צומת שנותר מקום, לחץ כאן.
                                open_node = parent;
                                break;
                            } else {
                                // לעלות שוב.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // אנחנו בראש, יוצרים צומת שורש חדש ודוחפים לשם.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // לחץ על צמד ערכי המפתח ועץ המשנה הימני החדש.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // רד שוב לעלה הימני ביותר.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // הגדל את אורך כל איטרציה, כדי לוודא שהמפה מפילה את האלמנטים המצורפים גם אם התקדמות האיטרציה נבהלת.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// איטרטור למיזוג שני רצפים ממוינים לאחד
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// אם שני מקשים שווים, מחזיר את צמד ערכי המפתח מהמקור הנכון.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}