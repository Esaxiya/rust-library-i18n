// זהו ניסיון ליישום בעקבות האידיאל
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// מכיוון של-Rust אין למעשה סוגים תלויים ורקורסיה פולימורפית, אנו מסתפקים בהמון חוסר בטיחות.
//

// מטרה עיקרית של מודול זה היא למנוע מורכבות על ידי התייחסות לעץ כאל מיכל גנרי (אם מעוצב בצורה מוזרה) והימנעות מהתמודדות עם מרבית משתתפי B-Tree.
//
// ככזה, למודול זה לא אכפת אם הערכים ממוינים, אילו צמתים יכולים להיות מלאים או אפילו מה המשמעות של פחות.עם זאת, אנו מסתמכים על כמה זרים:
//
// - על העצים להיות depth/height אחיד.המשמעות היא שלכל נתיב עד עלה מצומת נתון יש אותו אורך בדיוק.
// - צומת באורך `n` כולל מקשי `n`, ערכי `n` וקצוות `n + 1`.
//   זה מרמז שגם לצומת ריק יש לפחות edge אחד.
//   עבור צומת עלים, "having an edge" אומר רק שאנחנו יכולים לזהות מיקום בצומת, מכיוון שקצוות העלים ריקים ואינם זקוקים לייצוג נתונים.
// בצומת פנימי, edge מזהה מיקום ומכיל מצביע לצומת ילד.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// הייצוג הבסיסי של צמתים עלים וחלק מהייצוג של צמתים פנימיים.
struct LeafNode<K, V> {
    /// אנחנו רוצים להיות משתנים ב-`K` ו-`V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// אינדקס הצומת הזה למערך `edges` של הצומת האב.
    /// `*node.parent.edges[node.parent_idx]` צריך להיות אותו הדבר כמו `node`.
    /// זה מובטח כי יאותחל רק כאשר `parent` אינו ריק.
    parent_idx: MaybeUninit<u16>,

    /// מספר המקשים והערכים שצומת זה מאחסן.
    len: u16,

    /// המערכים המאחסנים את הנתונים בפועל של הצומת.
    /// רק רכיבי `len` הראשונים של כל מערך מאותחלים ותקפים.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// מאתחל `LeafNode` חדש במקום.
    unsafe fn init(this: *mut Self) {
        // כמדיניות כללית, אנו משאירים שדות לא מאוחדים אם הם יכולים להיות, מכיוון שזה צריך להיות מעט מהיר יותר וקל יותר לעקוב אחריו ב Valgrind.
        //
        unsafe {
            // parent_idx, מפתחות ו-vals הם כולם אולי יוניניט
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// יוצר `LeafNode` ממוסגר חדש.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// הייצוג הבסיסי של צמתים פנימיים.כמו ב-'LeafNode', אלה צריכים להיות מוסתרים מאחורי 'BoxedNode' כדי למנוע צניחת מפתחות וערכים שאינם מאוחדים.
/// ניתן להטיל כל מצביע ל-`InternalNode` ישירות למצביע לחלק ה-`LeafNode` הבסיסי של הצומת, מה שמאפשר לקוד לפעול על צמתים עלים ופנימיים באופן כללי מבלי לבדוק אפילו על איזה מהשניים מצביע מצביע.
///
/// מאפיין זה מופעל על ידי שימוש ב-`repr(C)`.
///
#[repr(C)]
// gdb_providers.py משתמש בשם סוג זה לצורך התבוננות פנימית.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// המצביעים לילדי הצומת הזה.
    /// `len + 1` מאלה נחשבים לאותליזציה ותקפים, למעט שבקרוב לסוף, בעוד שהעץ מוחזק באמצעות סוג השאלה `Dying`, חלק מהמצביעים האלה משתלשלים.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// יוצר `InternalNode` ממוסגר חדש.
    ///
    /// # Safety
    /// משתנה של צמתים פנימיים הוא שיש להם לפחות edge מאותחל ותקף.
    /// פונקציה זו אינה מגדירה edge כזה.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // עלינו לאתחל רק את הנתונים;הקצוות הם אולי יוניניט.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// מצביע מנוהל שאינו אפס לצומת.זהו או מצביע בבעלות ל-`LeafNode<K, V>` או מצביע בבעלות ל-`InternalNode<K, V>`.
///
/// עם זאת, `BoxedNode` אינו מכיל מידע לגבי איזה משני סוגי הצמתים הוא מכיל בפועל, ובחלקו בגלל היעדר מידע זה אינו סוג נפרד ואין לו הורס.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// צומת השורש של עץ בבעלות.
///
/// שים לב שאין לזה הורס, ויש לנקות אותו ידנית.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// מחזיר עץ בבעלות חדשה, עם צומת שורש משלה שהוא ריק בתחילה.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` לא יכול להיות אפס.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// לווה באופן מוטרלי את צומת השורש שבבעלות.
    /// בניגוד ל-`reborrow_mut`, זה בטוח מכיוון שלא ניתן להשתמש בערך ההחזרה כדי להשמיד את השורש, ולא יכולות להיות הפניות אחרות לעץ.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// בהשוואה קלה משתנה את צומת השורש שבבעלות.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// עובר באופן בלתי הפיך להתייחסות המאפשרת מעבר ומציעה שיטות הרסניות ומעט אחר.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// מוסיף צומת פנימי חדש עם edge יחיד שמפנה לצומת השורש הקודם, הפוך את הצומת החדש הזה לצומת השורש והחזיר אותו.
    /// זה מגדיל את הגובה ב-1 והוא ההפך מ-`pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, אלא שרק שכחנו שאנחנו פנימיים עכשיו:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// מסיר את צומת השורש הפנימי, ומשתמש בילדו הראשון כצומת השורש החדש.
    /// מכיוון שהוא נועד להתקשר רק כאשר לצומת השורש יש ילד אחד בלבד, לא נעשה ניקוי על אף אחד מהמפתחות, הערכים וילדים אחרים.
    ///
    /// זה מקטין את הגובה ב-1 והוא ההפך מ-`push_internal_level`.
    ///
    /// דורש גישה בלעדית לאובייקט `Root` אך לא לצומת הבסיס;
    /// זה לא יפסל ידיות אחרות או הפניות לצומת הבסיס.
    ///
    /// Panics אם אין רמה פנימית, כלומר אם צומת השורש הוא עלה.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // בטיחות: טענו כי אנו פנימיים.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // בטיחות: השאלנו את `self` באופן בלעדי וסוג ההשאלה שלו הוא בלעדי.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // בטיחות: ה-edge הראשון מאותחל תמיד.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` תמיד משתנה ב-`K` וב-`V`, גם כאשר `BorrowType` הוא `Mut`.
// זה לא נכון מבחינה טכנית, אך לא יכול לגרום לחוסר בטיחות כלשהו בגלל שימוש פנימי ב-`NodeRef` מכיוון שאנו נשארים גנריים לחלוטין על פני `K` ו-`V`.
//
// עם זאת, בכל פעם שסוג ציבורי עוטף את `NodeRef`, וודא שיש לו את השונות הנכונה.
//
/// התייחסות לצומת.
///
/// לסוג זה מספר פרמטרים השולטים כיצד הוא פועל:
/// - `BorrowType`: סוג דמה שמתאר את סוג ההשאלה ונושא חיים שלמים.
///    - כאשר זהו `Immut<'a>`, ה-`NodeRef` מתנהג בערך כמו `&'a Node`.
///    - כאשר מדובר ב-`ValMut<'a>`, ה-`NodeRef` מתנהג בערך כמו `&'a Node` ביחס למפתחות ולמבנה העץ, אך מאפשר גם קיום של הפניות משתנות רבות לערכים ברחבי העץ.
///    - כאשר מדובר ב-`Mut<'a>`, ה-`NodeRef` פועל בערך כמו `&'a mut Node`, אם כי שיטות הוספה מאפשרות למצביע משתנה לערך להתקיים יחד.
///    - כאשר מדובר ב-`Owned`, ה-`NodeRef` מתנהג בערך כמו `Box<Node>`, אך אין לו הורס, ויש לנקות אותו ידנית.
///    - כאשר מדובר ב-`Dying`, ה-`NodeRef` עדיין מתנהג בערך כמו `Box<Node>`, אך יש לו שיטות להשמיד את העץ טיפין טיפין, ושיטות רגילות, אמנם אינן מסומנות כלא בטוחות להתקשרות, אך יכולות להפעיל UB אם קוראים להן באופן שגוי.
///
///   מכיוון שכל `NodeRef` מאפשר ניווט בעץ, `BorrowType` חל למעשה על העץ כולו, ולא רק על הצומת עצמו.
/// - `K` ו-`V`: אלו סוגי המקשים והערכים המאוחסנים בצמתים.
/// - `Type`: זה יכול להיות `Leaf`, `Internal` או `LeafOrInternal`.
/// כאשר זהו `Leaf`, ה-`NodeRef` מצביע על צומת עלים, כאשר זהו `Internal` ה-`NodeRef` מצביע על צומת פנימי, וכאשר זהו `LeafOrInternal` ה-`NodeRef` יכול להצביע על כל סוג הצומת.
///   `Type` נקרא `NodeType` כאשר משתמשים בו מחוץ ל-`NodeRef`.
///
/// הן `BorrowType` והן `NodeType` מגבילים את השיטות שאנו מיישמים, כדי לנצל את בטיחות הסוג הסטטי.יש מגבלות באופן שבו אנו יכולים להחיל מגבלות כאלה:
/// - עבור כל פרמטר מסוג, אנו יכולים להגדיר שיטה רק באופן כללי או עבור סוג מסוים אחד.
/// לדוגמא, איננו יכולים להגדיר שיטה כמו `into_kv` באופן כללי עבור כל `BorrowType`, או פעם אחת לכל הסוגים הנושאים חיים שלמים, מכיוון שאנו רוצים שהיא תחזיר הפניות ל-`&'a`.
///   לכן, אנו מגדירים זאת רק עבור הסוג הפחות חזק ביותר `Immut<'a>`.
/// - אנחנו לא יכולים להשיג כפייה מרומזת מ-`Mut<'a>` ל-`Immut<'a>`.
///   לכן עלינו להתקשר במפורש ל-`reborrow` על `NodeRef` חזק יותר בכדי להגיע לשיטה כמו `into_kv`.
///
/// כל השיטות ב-`NodeRef` שמחזירות הפניה כלשהי, או:
/// - קח את `self` לפי ערך והחזיר את חיי החיים של `BorrowType`.
///   לפעמים, כדי להפעיל שיטה כזו, עלינו להתקשר ל-`reborrow_mut`.
/// - קח את התייחסות ל-`self`, ו-(implicitly) תחזיר את חיי ההפניה, במקום אורך החיים של `BorrowType`.
/// באופן זה, בודק ההלוואות מבטיח שה-`NodeRef` יישאר מושאל כל עוד נעשה שימוש בהפניה המוחזרת.
///   השיטות התומכות בהכנסה מכופפות את הכלל הזה על ידי החזרת מצביע גולמי, כלומר הפניה ללא כל חיים.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// מספר הרמות שהצומת ורמת העלים הם זה מזה, קבוע של הצומת שלא ניתן לתאר לחלוטין על ידי `Type`, והצומת עצמו אינו מאוחסן.
    /// עלינו לאחסן רק את גובה צומת השורש ולהפיק ממנו את גובהו של כל צומת אחר.
    /// חייב להיות אפס אם `Type` הוא `Leaf` ולא אפס אם `Type` הוא `Internal`.
    ///
    ///
    height: usize,
    /// המצביע לעלה או לצומת הפנימי.
    /// ההגדרה של `InternalNode` מבטיחה שהמצביע תקף בכל מקרה.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// פרוק הפניה לצומת שנארזה כ-`NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// חושף את הנתונים של צומת פנימי.
    ///
    /// מחזירה ptr גולמי כדי להימנע מביטול הפניות אחרות לצומת זה.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // בטיחות: סוג הצומת הסטטי הוא `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// לווה גישה בלעדית לנתונים של צומת פנימי.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// מוצא את אורך הצומת.זהו מספר המקשים או הערכים.
    /// מספר הקצוות הוא `len() + 1`.
    /// שים לב שלמרות היותה בטוחה, קריאה לפונקציה זו יכולה לגרום לתופעת לוואי של ביטול הפניות משתנות שיצר קוד לא בטוח.
    ///
    pub fn len(&self) -> usize {
        // באופן מכריע, אנו ניגשים רק לשדה `len` כאן.
        // אם BorrowType הוא marker::ValMut, יתכנו הפניות משתנות מובהקות לערכים שאסור לנו לבטל.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// מחזיר את מספר הרמות שהצומת והעלים נמצאים זה מזה.
    /// גובה אפס פירושו שהצומת הוא עלה עצמו.
    /// אם אתה מדמיין עצים עם השורש למעלה, המספר אומר באיזו גובה הצומת מופיע.
    /// אם אתה מדמיין עצים עם עלים מעל, המספר אומר כמה גבוה העץ משתרע מעל הצומת.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// מוציא באופן זמני התייחסות אחרת, שאינה ניתנת לשינוי, לאותו צומת.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// חושף את חלק העלה של כל עלה או צומת פנימי.
    ///
    /// מחזירה ptr גולמי כדי להימנע מביטול הפניות אחרות לצומת זה.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // הצומת חייב להיות תקף לפחות לחלק LeafNode.
        // זו אינה הפניה מסוג NodeRef מכיוון שאיננו יודעים אם היא צריכה להיות ייחודית או משותפת.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// מוצא את האב של הצומת הנוכחי.
    /// מחזירה את `Ok(handle)` אם לצומת הנוכחי אכן יש הורה, כאשר `handle` מצביע על edge של ההורה שמצביע על הצומת הנוכחי.
    ///
    /// מחזירה את `Err(self)` אם לצומת הנוכחי אין אב, ומחזיר את ה-`NodeRef` המקורי.
    ///
    /// שם השיטה מניח שתמונות עצים עם צומת השורש למעלה.
    ///
    /// `edge.descend().ascend().unwrap()` ו-`node.ascend().unwrap().descend()` שניהם, עם ההצלחה, לא צריכים לעשות כלום.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // עלינו להשתמש במצביעים גולמיים לצמתים מכיוון שאם BorrowType הוא marker::ValMut, ייתכן שיש התייחסויות משתנות יוצאות מן הכלל לערכים שאסור לנו לפסול.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// שים לב ש-`self` חייב להיות לא נקי.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// שים לב ש-`self` חייב להיות לא נקי.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// חושף את חלק העלה של כל עלה או צומת פנימי בעץ בלתי משתנה.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // בטיחות: לא יכולות להיות הפניות משתנות לעץ זה שהושאל כ-`Immut`.
        unsafe { &*ptr }
    }

    /// לווה מבט למפתחות המאוחסנים בצומת.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// בדומה ל-`ascend`, מקבל התייחסות לצומת האב של הצומת, אך גם מתמקם את הצומת הנוכחי בתהליך.
    /// זה לא בטוח מכיוון שהצומת הנוכחי עדיין יהיה נגיש למרות היותו מוקצה.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// מבטיח ללא בטחון למהדר את המידע הסטטי כי הצומת הזה הוא `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// מבטיח באופן מהימן למהדר את המידע הסטטי כי צומת זה הוא `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// מוציא זמנית התייחסות אחרת וניתנת לשינוי לאותו צומת.היזהר מכיוון ששיטה זו מסוכנת מאוד, כפליים מכיוון שהיא עשויה שלא להיראות מסוכנת באופן מיידי.
    ///
    /// מכיוון שמצביעים ניתנים לשינוי יכולים לשוטט בכל מקום סביב העץ, בעזרת המצביע המוחזר ניתן להשתמש בקלות בכדי לגרום למצביע המקורי להשתלשל, מחוץ לתחום, או להיות לא חוקי תחת כללי הלוואה שנערמו.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) שקול להוסיף עוד פרמטר מסוג `NodeRef` המגביל את השימוש בשיטות ניווט על מצביעים שנבנו מחדש, ומונע חוסר בטיחות זה.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// לווה גישה בלעדית לחלק העלה של כל עלה או צומת פנימי.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // בטיחות: יש לנו גישה בלעדית לכל הצומת.
        unsafe { &mut *ptr }
    }

    /// מציע גישה בלעדית לחלק העלים של כל עלה או צומת פנימי.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // בטיחות: יש לנו גישה בלעדית לכל הצומת.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// לווה גישה בלעדית לאלמנט באזור אחסון המפתח.
    ///
    /// # Safety
    /// `index` נמצא בגבולות של 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // בטיחות: המתקשר לא יוכל לקרוא בשיטות נוספות בעצמו
        // עד שההתייחסות לפרוסת המפתח נשמטת, מכיוון שיש לנו גישה ייחודית לכל אורך ההשאלה.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// לווה גישה בלעדית לאלמנט או פרוסה מאזור אחסון הערכים של הצומת.
    ///
    /// # Safety
    /// `index` נמצא בגבולות של 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // בטיחות: המתקשר לא יוכל לקרוא בשיטות נוספות בעצמו
        // עד שההפניה לפרוסת הערך תישמט, מכיוון שיש לנו גישה ייחודית למשך כל זמן ההלוואה.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// לווה גישה בלעדית לאלמנט או פרוסה מאזור האחסון של הצומת לתוכן edge.
    ///
    /// # Safety
    /// `index` נמצא בתחומים של 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // בטיחות: המתקשר לא יוכל לקרוא בשיטות נוספות בעצמו
        // עד שההתייחסות לפרוסת edge תושמט, מכיוון שיש לנו גישה ייחודית לכל אורך ההשאלה.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - בצומת יש יותר מאלמנטים מאותחללים של `idx`.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // אנו יוצרים רק התייחסות לאלמנט האחד בו אנו מעוניינים, כדי להימנע מכינוי עם התייחסויות מצטיינות לאלמנטים אחרים, בפרט לאלה שהוחזרו למתקשר באיטרציות קודמות.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // עלינו לכפות על מצביעי מערך לא גדולים בגלל גיליון Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// לווה גישה בלעדית לאורך הצומת.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// מגדיר את הקישור של הצומת להורה edge, מבלי לבטל את הפניות האחרות לצומת.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// מנקה את קישור השורש להורה edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// מוסיף צמד ערכי מפתח לסוף הצומת.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// כל פריט המוחזר על ידי `range` הוא אינדקס edge חוקי עבור הצומת.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// מוסיף זוג ערך מפתח, ו-edge כדי לעבור מימין לזוג זה, לקצה הצומת.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// בודק אם צומת הוא צומת `Internal` או צומת `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// התייחסות לצמד ערכי מפתח ספציפי או edge בתוך צומת.
/// הפרמטר `Node` חייב להיות `NodeRef`, בעוד ש-`Type` יכול להיות `KV` (מסמן ידית על צמד ערכי מפתח) או `Edge` (מציין ידית על edge).
///
/// שים לב שגם לצמתים של `Leaf` יכולים להיות ידיות `Edge`.
/// במקום לייצג מצביע לצומת ילד, אלה מייצגים את הרווחים בהם ילכו מצביעי ילדים בין צמדי ערכי המפתח.
/// לדוגמא, בצומת עם אורך 2 יהיו 3 מיקומי edge אפשריים, אחד משמאל לצומת, אחד בין שני הזוגות ואחד בצד ימין של הצומת.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// איננו זקוקים לכלליות המלאה של `#[derive(Clone)]`, שכן הפעם היחידה ש-`Node` תהיה 'שיבוטית' היא כאשר מדובר בהתייחסות בלתי ניתנת לשינוי ולכן `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// מאחזר את הצומת המכיל את edge או את צמד ערכי המפתח שאליו מציינת הידית.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// מחזירה את המיקום של הידית הזו בצומת.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// יוצר ידית חדשה לזוג ערכי מפתח ב-`node`.
    /// לא בטוח מפני שהמתקשר צריך לוודא ש-`idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// יכול להיות יישום ציבורי של PartialEq, אך משמש רק במודול זה.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// מוציא זמנית ידית אחרת ובלתי ניתנת לשינוי באותו מקום.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // איננו יכולים להשתמש ב-Handle::new_kv או Handle::new_edge מכיוון שאנו לא יודעים את סוגנו
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// מבטיח ללא בטחון למהדר את המידע הסטטי כי צומת הידית הוא `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// מוציא זמנית ידית אחרת וניתנת לשינוי באותו מיקום.
    /// היזהר מכיוון ששיטה זו מסוכנת מאוד, כפליים מכיוון שהיא עשויה שלא להיראות מסוכנת באופן מיידי.
    ///
    ///
    /// לפרטים, ראה `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // איננו יכולים להשתמש ב-Handle::new_kv או Handle::new_edge מכיוון שאנו לא יודעים את סוגנו
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// יוצר ידית חדשה ל-edge ב-`node`.
    /// לא בטוח מפני שהמתקשר צריך לוודא ש-`idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// בהינתן אינדקס edge שבו אנו רוצים להכניס לצומת מלא עד אפס מקום, מחשב אינדקס KV הגיוני של נקודת פיצול ואיפה לבצע את ההכנסה.
///
/// מטרת נקודת הפיצול היא שהמפתח והערך שלה יסתיימו בצומת אב;
/// המקשים, הערכים והקצוות שמשמאל לנקודת הפיצול הופכים לילד שמאל;
/// המקשים, הערכים והקצוות מימין לנקודת הפיצול הופכים לילד הנכון.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // גיליון Rust #74834 מנסה להסביר את הכללים הסימטריים הללו.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// מכניס צמד ערכי מפתח חדש בין זוגות ערך המפתח מימין ומשמאל ל edge זה.
    /// שיטה זו מניחה שיש מספיק מקום בצומת כדי שהזוג החדש יתאים.
    ///
    /// המצביע שהוחזר מצביע על הערך שהוכנס.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// מכניס צמד ערכי מפתח חדש בין זוגות ערך המפתח מימין ומשמאל ל edge זה.
    /// שיטה זו מחלקת את הצומת אם אין מספיק מקום.
    ///
    /// המצביע שהוחזר מצביע על הערך שהוכנס.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// מתקן את מצביע האב ואת האינדקס בצומת הילד שאליו edge מקשר.
    /// זה שימושי כאשר סידור הקצוות השתנה,
    fn correct_parent_link(self) {
        // צור נקודת אחורי מבלי לפסול הפניות אחרות לצומת.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// מכניס צמד ערכי מפתח חדש ו-edge שיעברו מימין לאותו זוג חדש בין edge זה לבין זוג ערך המפתח מימין ל-edge זה.
    /// שיטה זו מניחה שיש מספיק מקום בצומת כדי שהזוג החדש יתאים.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// מכניס צמד ערכי מפתח חדש ו-edge שיעברו מימין לאותו זוג חדש בין edge זה לבין זוג ערך המפתח מימין ל-edge זה.
    /// שיטה זו מחלקת את הצומת אם אין מספיק מקום.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// מכניס צמד ערכי מפתח חדש בין זוגות ערך המפתח מימין ומשמאל ל edge זה.
    /// שיטה זו מחלקת את הצומת אם אין מספיק מקום, ומנסה להכניס את החלק המנותק לצומת האב באופן רקורסיבי, עד להשגת השורש.
    ///
    ///
    /// אם התוצאה שהוחזרה היא `Fit`, הצומת של הידית שלה יכול להיות הצומת של edge זה או אב קדמון.
    /// אם התוצאה שהוחזרה היא `Split`, השדה `left` יהיה צומת השורש.
    /// המצביע שהוחזר מצביע על הערך שהוכנס.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// מוצא את הצומת אליו הצביע edge.
    ///
    /// שם השיטה מניח שתמונות עצים עם צומת השורש למעלה.
    ///
    /// `edge.descend().ascend().unwrap()` ו-`node.ascend().unwrap().descend()` שניהם, עם ההצלחה, לא צריכים לעשות כלום.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // עלינו להשתמש במצביעים גולמיים לצמתים מכיוון שאם BorrowType הוא marker::ValMut, ייתכן שיש התייחסויות משתנות יוצאות מן הכלל לערכים שאסור לנו לפסול.
        // אין דאגה לגשת לשדה הגובה מכיוון שערך זה מועתק.
        // היזהר, ברגע שמפנים את הצומת הצומת, אנו ניגשים למערך הקצוות עם הפניה (Rust גליון #73987) ואנו מבטלים כל הפניות אחרות למערך או בתוךו, אם יהיו בסביבה.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // איננו יכולים לקרוא לשיטות מפתח וערך נפרדות, מכיוון שקריאה לשניה מבטלת את הפניה שהוחזרה על ידי הראשונה.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// החלף את המפתח והערך שאליו מתייחסת ידית KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// מסייע ליישומים של `split` עבור `NodeType` מסוים, על ידי טיפול בנתוני העלים.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// מפצל את הצומת הבסיסי לשלושה חלקים:
    ///
    /// - הצומת נחתך כדי להכיל רק את צמדי ערך המפתח משמאל לידית זו.
    /// - המפתח והערך עליו מצביעים ידית זו מופקים.
    /// - כל זוגות ערך המפתח מימין לידית זו מוכנסים לצומת שהוקצה לאחרונה.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// מסיר את צמד ערכי המפתח אליו ידית ידית זו מצביע ומחזיר אותו, יחד עם ה-edge אליו צמד ערכי המפתח קרס.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// מפצל את הצומת הבסיסי לשלושה חלקים:
    ///
    /// - הצומת נחתך כדי להכיל רק את הקצוות וזוגות ערך מפתח משמאל לידית זו.
    /// - המפתח והערך עליו מצביעים ידית זו מופקים.
    /// - כל הקצוות וזוגות ערכי המפתח מימין לידית זו מוכנסים לצומת שהוקצה לאחרונה.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// מייצג מושב להערכה וביצוע פעולת איזון סביב צמד מפתח-מפתח פנימי.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// בוחר הקשר איזון הכרוך בצומת כילד, ובכך בין ה-KV מייד שמאלה או ימינה בצומת האב.
    /// מחזירה `Err` אם אין הורה.
    /// Panics אם ההורה ריק.
    ///
    /// מעדיף את הצד השמאלי, להיות אופטימלי אם הצומת הנתון יהיה איכשהו מלא, כלומר רק שיש לו פחות אלמנטים מאחיו השמאלי ומהאח הימני שלו, אם הם קיימים.
    /// במקרה כזה, המיזוג עם האח השמאלי הוא מהיר יותר, מכיוון שעלינו להזיז רק את אלמנטים ה-N של הצומת, במקום להזיז אותם ימינה ולהעביר יותר מ-N אלמנטים מלפנים.
    /// גניבה מהאח השמאלי היא בדרך כלל מהירה יותר, מכיוון שעלינו רק להעביר את אלמנטים ה-N של הצומת ימינה, במקום להזיז לפחות N מאלמנטים של האח לשמאל.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// מחזיר אם מיזוג אפשרי, כלומר האם יש מספיק מקום בצומת כדי לשלב את ה-KV המרכזי עם שני צמתי הילד הסמוכים.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// מבצע מיזוג ומאפשר לסגירה להחליט מה להחזיר.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // בטיחות: גובה הצמתים הממוזגים נמצא מתחת לגובה
                // של הצומת של edge זה, ולכן מעל לאפס, ולכן הם פנימיים.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// ממזג את צמד ערכי המפתח של ההורה ושני צמתי הילד הסמוכים לצומת הילד השמאלי ומחזיר את צומת ההורה המצומק.
    ///
    ///
    /// Panics אלא אם כן אנחנו `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// משלב את צמד ערכי המפתח של ההורה ושני צמתי הילד הסמוכים לצומת הילד השמאלי ומחזיר את צומת הילד.
    ///
    ///
    /// Panics אלא אם כן אנחנו `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// ממזג את צמד ערכי המפתח של ההורה ושני צמתי הילד הסמוכים לצומת הילד השמאלי ומחזיר את ידית ה-edge באותו צומת הילד בו נקלע הילד edge שנמצא במעקב,
    ///
    ///
    /// Panics אלא אם כן אנחנו `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// מסיר צמד ערכי מפתח מהילד השמאלי ומציב אותו באחסון ערך המפתח של ההורה, תוך דחיפת צמד ערכי המפתח של ההורה הישן לילד הימני.
    ///
    /// מחזיר ידית ל-edge בילד הימני המתאים למקום בו edge המקורי שצוין על ידי `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// מסיר צמד ערכי מפתח מהילד הימני ומציב אותו באחסון ערך המפתח של ההורה, תוך דחיפת צמד ערכי המפתח של ההורה הישן אל הילד השמאלי.
    ///
    /// מחזיר ידית ל-edge בילד השמאלי שצוין על ידי `track_left_edge_idx`, שלא זז.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// זה אכן גונב בדומה ל-`steal_left` אך גונב מספר אלמנטים בבת אחת.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // ודא שאנחנו עלולים לגנוב בבטחה.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // העבר נתוני עלים.
            {
                // פנו מקום לגורמים גנובים בילד הנכון.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // העבר אלמנטים מהילד השמאלי לילד הימני.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // העבירו את הזוג הגנוב השמאלי ביותר להורה.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // העבר את צמד ערכי המפתח של ההורה לילד הנכון.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // לפנות מקום לקצוות גנובים.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // לגנוב קצוות.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// השיבוט הסימטרי של `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // ודא שאנחנו עלולים לגנוב בבטחה.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // העבר נתוני עלים.
            {
                // העבר את הזוג הכי נגנב נכון להורה.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // העבר את צמד ערכי המפתח של ההורה לילד השמאלי.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // העבר אלמנטים מהילד הימני לשמאלי.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // מלא את הפער במקום בו היו בעבר אלמנטים גנובים.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // לגנוב קצוות.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // מלא את הפער במקום בו היו בעבר קצוות גנובים.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// מסיר כל מידע סטטי הטוען כי צומת זה הוא צומת `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// מסיר כל מידע סטטי הטוען כי צומת זה הוא צומת `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// בודק אם הצומת הבסיסי הוא צומת `Internal` או צומת `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// העבר את הסיומת אחרי `self` מצומת אחד לאחר.`right` חייב להיות ריק.
    /// ה-edge הראשון של `right` נותר ללא שינוי.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// תוצאה של הכנסה, כאשר הצומת צריך להתרחב מעבר ליכולתו.
pub struct SplitResult<'a, K, V, NodeType> {
    // צומת שונה בעץ קיים עם אלמנטים וקצוות השייכים לשמאל ל-`kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // חלק מהמפתח והערך מתפצלים כדי להכניס למקום אחר.
    pub kv: (K, V),
    // צומת בבעלות, לא צמודה, חדשה עם אלמנטים וקצוות השייכים לימין `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // בין אם הפניות לצומת מסוג השאלה זה מאפשרות מעבר לצמתים אחרים בעץ.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // אין צורך במעבר, זה קורה באמצעות התוצאה של `borrow_mut`.
        // על ידי השבתת מעבר, ויצירת רק הפניות חדשות לשורשים, אנו יודעים שכל התייחסות מסוג `Owned` היא לצומת שורש.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// מכניס ערך לפרוסת אלמנטים מאותחל ואחריו אלמנט אחד שאינו מאושר.
///
/// # Safety
/// הנתח כולל יותר מאלמנטים של `idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// מסיר ומחזיר ערך מפרוסה של כל האלמנטים האתחוליים, ומשאיר אחריו אלמנט אחד שלא נגרר נגרר.
///
///
/// # Safety
/// הנתח כולל יותר מאלמנטים של `idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// מעביר את האלמנטים במיקום `distance` פרוסה שמאלה.
///
/// # Safety
/// הנתח כולל לפחות אלמנטים `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// מעביר את האלמנטים במיקום `distance` פרוסה ימינה.
///
/// # Safety
/// הנתח כולל לפחות אלמנטים `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// מעביר את כל הערכים מפרוסת אלמנטים מאותחלים לפרוסת אלמנטים לא מאומתים, ומשאירה מאחור את `src` ככולם שאינם מאוחדים.
///
/// עובד כמו `dst.copy_from_slice(src)` אך אינו דורש ש-`T` יהיה `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;