use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// מוציא זמנית מקבילה אחרת ובלתי ניתנת לשינוי של אותו טווח.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// מוצא את קצוות העלים המובהקים התוחמים טווח מוגדר בעץ.
    /// מחזיר זוג ידיות שונות לאותו עץ או זוג אפשרויות ריקות.
    ///
    /// # Safety
    ///
    /// אלא אם כן `BorrowType` הוא `Immut`, אל תשתמש בידיות הכפולות כדי לבקר באותו KV פעמיים.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// שווה ערך ל-`(root1.first_leaf_edge(), root2.last_leaf_edge())` אך יעיל יותר.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// מוצא את זוג קצוות העלים התוחמים טווח מסוים בעץ.
    ///
    /// התוצאה משמעותית רק אם העץ מסודר לפי מפתח, כמו העץ ב-`BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // בטיחות: סוג ההשאלה שלנו אינו משתנה.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// מוצא את זוג קצוות העלים התוחמים עץ שלם.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// פיצול ייחוס ייחודי לצמד קצוות עלים התוחם טווח מוגדר.
    /// התוצאה היא הפניות לא ייחודיות המאפשרות מוטציה של (some), בה יש להשתמש בזהירות.
    ///
    /// התוצאה משמעותית רק אם העץ מסודר לפי מפתח, כמו העץ ב-`BTreeMap`.
    ///
    ///
    /// # Safety
    /// אל תשתמש בידיות הכפולות כדי לבקר באותו KV פעמיים.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// מחלק התייחסות ייחודית לזוג קצוות עלים התוחמים את כל טווח העץ.
    /// התוצאות הן הפניות לא ייחודיות המאפשרות מוטציה (של ערכים בלבד), לכן יש להשתמש בזהירות.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // אנו משכפלים כאן את שורש NodeRef-לעולם לא נבקר באותה KV פעמיים, ולעולם לא נקבל הפניות ערכיות חופפות.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// מחלק התייחסות ייחודית לזוג קצוות עלים התוחמים את כל טווח העץ.
    /// התוצאות הן התייחסויות לא ייחודיות המאפשרות מוטציה הרסנית מאסיבית, ולכן יש להשתמש בהן בזהירות מירבית.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // אנו משכפלים את שורש NodeRef כאן-לעולם לא ניגש אליו באופן חופף הפניות המתקבלות מהשורש.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// בהינתן ידית edge, מחזירה את [`Result::Ok`] עם ידית ל-KV השכן בצד ימין, שנמצא באותו צומת עלים או בצומת קדמון.
    ///
    /// אם העלה edge הוא האחרון בעץ, מחזיר את [`Result::Err`] עם צומת השורש.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// בהינתן ידית edge עלה, מחזירה את [`Result::Ok`] עם ידית ל-KV השכן בצד שמאל, שנמצא באותו צומת עלים או בצומת קדמון.
    ///
    /// אם העלה edge הוא הראשון בעץ, מחזיר את [`Result::Err`] עם צומת השורש.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// בהינתן ידית edge פנימית, מחזירה את [`Result::Ok`] עם ידית ל-KV השכן בצד ימין, שנמצא באותו צומת פנימי או בצומת קדמון.
    ///
    /// אם ה-edge הפנימי הוא האחרון בעץ, מחזיר את [`Result::Err`] עם צומת השורש.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// בהינתן ידית edge של עלה לעץ גוסס, מחזירה את העלה הבא edge בצד ימין, ואת צמד ערכי המפתח שביניהם, שנמצא באותו צומת עלה, בצומת קדמון או שאינו קיים.
    ///
    ///
    /// שיטה זו גם מתמקדת בכל node(s) שהיא מגיעה לסוף.
    /// זה מרמז שאם לא קיים צמד ערכי מפתח נוסף, יתרת העץ כולה הוקצה ולא נותר מה להחזיר.
    ///
    /// # Safety
    /// ייתכן ש-edge הנתון לא הוחזר בעבר על ידי עמיתו `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// בהינתן ידית edge עלה לתוך עץ גוסס, מחזיר את העלה הבא edge בצד שמאל, ואת צמד ערכי המפתח שביניהם, שנמצא באותו צומת עלה, בצומת קדמון או שאינו קיים.
    ///
    ///
    /// שיטה זו גם מתמקדת בכל node(s) שהיא מגיעה לסוף.
    /// זה מרמז שאם לא קיים צמד ערכי מפתח נוסף, יתרת העץ כולה הוקצה ולא נותר מה להחזיר.
    ///
    /// # Safety
    /// ייתכן ש-edge הנתון לא הוחזר בעבר על ידי עמיתו `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// מחלק ערימה של צמתים מהעלה ועד השורש.
    /// זוהי הדרך היחידה להתמודד עם שארית עץ לאחר ש-`deallocating_next` ו-`deallocating_next_back` נשנושו משני צידי העץ ופגעו באותו edge.
    /// מכיוון שהוא נועד להתקשר רק כאשר כל המפתחות והערכים הוחזרו, לא נעשה ניקוי על אף אחד מהמפתחות או הערכים.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// מעביר את ידית edge העלה לדף edge הבא ומחזיר הפניות למפתח ולערך שביניהם.
    ///
    ///
    /// # Safety
    /// חייב להיות KV נוסף בכיוון שנסע.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// מעביר את ידית העלה edge לעלה edge הקודם ומחזיר הפניות למפתח ולערך שביניהם.
    ///
    ///
    /// # Safety
    /// חייב להיות KV נוסף בכיוון שנסע.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// מעביר את ידית edge העלה לדף edge הבא ומחזיר הפניות למפתח ולערך שביניהם.
    ///
    ///
    /// # Safety
    /// חייב להיות KV נוסף בכיוון שנסע.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // ביצוע אחרון זה מהיר יותר, על פי אמות מידה.
        kv.into_kv_valmut()
    }

    /// מעביר את עלה edge לעלה הקודם ומחזיר הפניות למפתח ולערך שביניהם.
    ///
    ///
    /// # Safety
    /// חייב להיות KV נוסף בכיוון שנסע.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // ביצוע אחרון זה מהיר יותר, על פי אמות מידה.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// מעביר את ידית edge העלה לדף edge הבא ומחזיר את המפתח והערך שביניהם, תוך כדי מיקום כל צומת שנשאר מאחור תוך השארת edge המתאים בצומת האב שלו משתלשל.
    ///
    /// # Safety
    /// - חייב להיות KV נוסף בכיוון שנסע.
    /// - אותו KV לא הוחזר בעבר על ידי עמיתו `next_back_unchecked` על שום עותק של הידיות ששימשו לחציית העץ.
    ///
    /// הדרך הבטוחה היחידה להמשיך בידית המעודכנת היא להשוות אותה, להפיל אותה, להתקשר שוב לשיטה זו בכפוף לתנאי הבטיחות שלה, או להתקשר לעמית `next_back_unchecked` בכפוף לתנאי הבטיחות שלה.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// מעביר את ידית edge העלה לדף edge הקודם ומחזיר את המפתח והערך שביניהם, וממקם כל צומת שנשאר מאחור תוך השארת ה-edge בצומת האב שלו משתלשל.
    ///
    /// # Safety
    /// - חייב להיות KV נוסף בכיוון שנסע.
    /// - עלה זה edge לא הוחזר בעבר על ידי עמיתו `next_unchecked` על כל עותק של הידיות ששימשו לחציית העץ.
    ///
    /// הדרך הבטוחה היחידה להמשיך בידית המעודכנת היא להשוות אותה, להפיל אותה, להתקשר שוב לשיטה זו בכפוף לתנאי הבטיחות שלה, או להתקשר לעמית `next_unchecked` בכפוף לתנאי הבטיחות שלה.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// מחזיר את העלה edge השמאלי ביותר בצומת או מתחת לו, במילים אחרות, ה-edge הדרוש לך קודם בעת ניווט קדימה (או אחרון כשניווט אחורה).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// מחזיר את העלה edge הימני ביותר בצומת או מתחת לו, במילים אחרות, ה-edge שאתה צריך אחרון בעת ניווט קדימה (או ראשון כשניווט אחורה).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// מבקר בצמתים של עלים וב-KV פנימי לפי סדר מפתחות עולה, וכן מבקר בצמתים פנימיים בכללותם בסדר ראשון מעמיק, כלומר צמתים פנימיים קודמים ל-KV האישי שלהם ולצמתים שלהם.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// מחשבת את מספר האלמנטים בעץ (משנה).
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// מחזיר את העלה edge הקרוב ביותר ל-KV לניווט קדימה.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// מחזיר את העלה edge הקרוב ביותר ל-KV לניווט לאחור.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}