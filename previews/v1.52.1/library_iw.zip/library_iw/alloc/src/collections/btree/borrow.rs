use core::marker::PhantomData;
use core::ptr::NonNull;

/// מדגמן מחדש של התייחסות ייחודית כלשהי, כשאתה יודע שברבוב וכל צאצאיו (כלומר, כל המצביעים וההפניות הנגזרות ממנו) לא ישמשו יותר בשלב מסוים, ולאחר מכן תרצה להשתמש שוב בהתייחסות הייחודית המקורית. .
///
///
/// בודק ההלוואות מטפל בדרך כלל בערימת הלוואות זו עבורך, אך כמה תזרימי בקרה שמשיגים את הערימה הזו מסובכים מכדי שהמהדר יכול לעקוב אחריו.
/// `DormantMutRef` מאפשר לך לבדוק את ההלוואות בעצמך, תוך ביטוי של אופיו המוערם, ומעטפת את קוד המצביע הגולמי הדרוש לשם כך ללא התנהגות לא מוגדרת.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// תפוס הלוואה ייחודית, ומיד אותה מחדש.
    /// עבור המהדר, אורך החיים של ההפניה החדשה זהה לחיי ההפניה המקורית, אך אתה promise להשתמש בו לתקופה קצרה יותר.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // בטיחות: אנו מחזיקים את ההלוואות לאורך כל ה-`_marker` ואנחנו חושפים
        // רק התייחסות זו, ולכן היא ייחודית.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// חזור להלוואות הייחודיות שנלכדו בתחילה.
    ///
    /// # Safety
    ///
    /// בוודאי הסתיים המהדורה מחדש, כלומר, אסור להשתמש יותר בהפניה שהוחזרה על ידי `new` וכל המצביעים וההפניות הנגזרים ממנה.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // בטיחות: תנאי הבטיחות שלנו מרמזים שהתייחסות זו שוב ייחודית.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;