//! מצביעי ספירת הפניות עם הברגה אחת.'Rc' מייצג 'הפניה'
//! Counted'.
//!
//! הסוג [`Rc<T>`][`Rc`] מספק בעלות משותפת על ערך מסוג `T`, המוקצה בערימה.
//! הפעלת [`clone`][clone] ב-[`Rc`] מייצרת מצביע חדש לאותה הקצאה בערימה.
//! כאשר מצביע ה-[`Rc`] האחרון להקצאה נתונה נהרס, הערך השמור באותה הקצאה (המכונה לעתים קרובות "inner value") יורד גם הוא.
//!
//! הפניות משותפות ב-Rust אינן מאפשרות מוטציה כברירת מחדל, ו-[`Rc`] אינו יוצא מן הכלל: בדרך כלל אינך יכול לקבל התייחסות ניתנת לשינוי למשהו בתוך [`Rc`].
//! אם אתה זקוק למשתנות, הכנס [`Cell`] או [`RefCell`] בתוך ה-[`Rc`];ראה [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] משתמש בספירת ייחוס שאינה אטומית.
//! משמעות הדבר היא כי התקורה נמוכה מאוד, אך לא ניתן לשלוח [`Rc`] בין השרשור, וכתוצאה מכך [`Rc`] אינו מיישם את [`Send`][send].
//! כתוצאה מכך, מהדר Rust יבדוק *בזמן הידור* כי אינך שולח [`Rc`] בין האשכולות.
//! אם אתה זקוק לספירת הפניות אטומית מרובת הברגה, השתמש ב-[`sync::Arc`][arc].
//!
//! ניתן להשתמש בשיטת [`downgrade`][downgrade] ליצירת מצביע [`Weak`] שאינו בבעלות.
//! מצביע [`Weak`] יכול להיות ["שדרוג"][שדרוג] d ל-[`Rc`], אך זה יחזיר את [`None`] אם הערך המאוחסן בהקצאה כבר הושמט.
//! במילים אחרות, מצביעי `Weak` אינם שומרים על הערך בתוך ההקצאה בחיים;עם זאת, הם * שומרים על קיום ההקצאה (חנות הגיבוי לערך הפנימי).
//!
//! מחזור בין מצביעי [`Rc`] לעולם לא יוקצה.
//! מסיבה זו, [`Weak`] משמש לשבירת מחזורים.
//! לדוגמא, לעץ יכולות להיות מצביעי [`Rc`] חזקים מצומת הורים לילדים, ומצבי [`Weak`] מילדים חזרה להוריהם.
//!
//! `Rc<T>` בהפניות אוטומטיות ל-`T` (דרך ה-[`Deref`] trait), כך שתוכל להתקשר לשיטות 'T' בערך מסוג [`Rc<T>`][`Rc`].
//! כדי למנוע עימותים בשמות עם שיטות 'T', השיטות של [`Rc<T>`][`Rc`] עצמו הן פונקציות המשויכות, הנקראות באמצעות [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `RC<T>יישומי traits כמו `Clone` עשויים להיקרא גם באמצעות תחביר מלא.
//! יש אנשים שמעדיפים להשתמש בתחביר מוסמך לחלוטין, בעוד שאחרים מעדיפים להשתמש בתחביר שיחת-שיחה.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // תחביר שיחת שיטה
//! let rc2 = rc.clone();
//! // תחביר מוסמך לחלוטין
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] אינו מפנה אוטומטית ל-`T`, מכיוון שהערך הפנימי כבר ירד.
//!
//! # שיבוט הפניות
//!
//! יצירת הפניה חדשה לאותה הקצאה כמו מצביע נספר הפניה קיים נעשית באמצעות `Clone` trait המיושם עבור [`Rc<T>`][`Rc`] ו-[`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // שני התחבירים להלן שווים.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a ו-b שניהם מצביעים על אותו מיקום זיכרון כמו foo.
//! ```
//!
//! התחביר `Rc::clone(&from)` הוא האידיומטי ביותר מכיוון שהוא מעביר בצורה מפורשת יותר את משמעות הקוד.
//! בדוגמה לעיל, תחביר זה מקל על ראיית קוד זה שיוצר התייחסות חדשה במקום העתקת כל התוכן של foo.
//!
//! # Examples
//!
//! שקול תרחיש שבו סט של 'גאדג'טים' נמצא בבעלות `Owner` נתון.
//! אנו רוצים ש"הגאדג'ט"שלנו יצביע על ה-`Owner` שלהם.איננו יכולים לעשות זאת בבעלות ייחודית, מכיוון שיותר מגאדג'ט אחד עשוי להשתייך לאותו `Owner`.
//! [`Rc`] מאפשר לנו לחלוק `Owner` בין מספר גאדג'טים, ולהשאיר את ה-`Owner` מוקצה כל עוד נקודות `Gadget` בו.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... שדות אחרים
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... שדות אחרים
//! }
//!
//! fn main() {
//!     // צור `Owner` עם ספירת הפניות.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // צור 'גאדג'טים' השייכים ל-`gadget_owner`.
//!     // שיבוט ה-`Rc<Owner>` נותן לנו מצביע חדש לאותה הקצאת `Owner`, שמגדיל את ספירת ההתייחסות בתהליך.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // השלך את המשתנה המקומי `gadget_owner` שלנו.
//!     drop(gadget_owner);
//!
//!     // למרות הצניחה של `gadget_owner`, אנו עדיין מסוגלים להדפיס את שם ה-`Owner` של 'גאדג'ט'.
//!     // הסיבה לכך היא שהורדנו רק `Rc<Owner>` יחיד, ולא ה-`Owner` שהוא מצביע עליו.
//!     // כל עוד יש `Rc<Owner>` אחר שמצביע על אותה הקצאת `Owner`, הוא יישאר פעיל.
//!     // הקרנת השדה `gadget1.owner.name` עובדת מכיוון ש-`Rc<Owner>` מפנה אוטומטית ל-`Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // בסוף הפונקציה `gadget1` ו-`gadget2` נהרסים, ואיתם הפניות האחרונות שנספרו ל-`Owner` שלנו.
//!     // איש הגאדג'ט נהרס כעת גם כן.
//!     //
//! }
//! ```
//!
//! אם הדרישות שלנו ישתנו, ונצטרך גם להיות מסוגלים לעבור מ-`Owner` ל-`Gadget`, אנו נתקל בבעיות.
//! מצביע [`Rc`] מ-`Owner` ל-`Gadget` מציג מחזור.
//! פירוש הדבר שספירות הייחוס שלהם לעולם לא יכולות להגיע ל-0, וההקצאה לעולם לא תיהרס:
//! דליפת זיכרון.על מנת לעקוף זאת, נוכל להשתמש במצבי [`Weak`].
//!
//! Rust למעשה מקשה במקצת על הפקת הלולאה הזו מלכתחילה.כדי לסיים שני ערכים המצביעים זה על זה, אחד מהם צריך להיות משתנה.
//! זה קשה מכיוון ש-[`Rc`] אוכף את בטיחות הזיכרון בכך שהוא נותן רק הפניות משותפות לערך שהוא עוטף, ואלו אינן מאפשרות מוטציה ישירה.
//! עלינו לעטוף את חלק הערך אותו אנו רוצים לשנות ב-[`RefCell`], המספק *מוטציה פנימית*: שיטה להשגת מוטציה באמצעות התייחסות משותפת.
//! [`RefCell`] אוכף את כללי ההלוואות של Rust בזמן הריצה.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... שדות אחרים
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... שדות אחרים
//! }
//!
//! fn main() {
//!     // צור `Owner` עם ספירת הפניות.
//!     // שים לב שהכנסנו את ה-vector של 'הבעלים' של 'גאדג'ט' בתוך `RefCell` כדי שנוכל לשנות אותו באמצעות הפניה משותפת.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // צור 'גאדג'טים' השייכים ל-`gadget_owner`, כמו בעבר.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // הוסף את הגאדג'טים ל-`Owner` שלהם.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` הלוואה דינמית מסתיימת כאן.
//!     }
//!
//!     // חזר על הגאדג'טים שלנו והדפס את פרטיהם.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` הוא `Weak<Gadget>`.
//!         // מכיוון שמצבי `Weak` אינם יכולים להבטיח שההקצאה עדיין קיימת, עלינו להתקשר ל-`upgrade`, שמחזיר `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // במקרה זה אנו יודעים שההקצאה עדיין קיימת, לכן פשוט `unwrap` ה-`Option`.
//!         // בתוכנית מסובכת יותר, ייתכן שתזדקק לטיפול בשגיאות חינניות לתוצאה של `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // בסוף הפונקציה, `gadget_owner`, `gadget1` ו-`gadget2` נהרסים.
//!     // אין כעת מצביעי (`Rc`) חזקים לגאדג'טים, ולכן הם נהרסים.
//!     // זה מאפס את ספירת ההתייחסות לגאדג'ט מן, כך שהוא נהרס גם כן.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// זהו הוכחה repr(C) ל-future כנגד סידור שדות אפשרי, אשר יפריע ל-[into|from]_raw() בטוח אחרת מסוגים פנימיים הניתנים להחלפה.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// מצביע ספירת הפניות עם הברגה אחת.'Rc' מייצג 'הפניה'
/// Counted'.
///
/// לפרטים נוספים, עיין ב-[module-level documentation](./index.html).
///
/// השיטות האינהרנטיות של `Rc` הן פונקציות משויכות, מה שאומר שאתה צריך לקרוא להן כמו למשל, [`Rc::get_mut(&mut value)`][get_mut] במקום `value.get_mut()`.
/// זה מונע התנגשויות עם שיטות מהסוג הפנימי `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // חוסר בטיחות זה בסדר מכיוון שבעוד ש-Rc זה חי מובטח לנו שהמצביע הפנימי תקף.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// בונה `Rc<T>` חדש.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // יש מצביע חלש מרומז בבעלות כל המצביעים החזקים, מה שמבטיח שההרס החלש לעולם לא ישחרר את ההקצאה בזמן שההרס החזק פועל, גם אם המצביע החלש מאוחסן בתוך החזק.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// בונה `Rc<T>` חדש תוך שימוש בהתייחסות חלשה לעצמו.
    /// ניסיון לשדרג את הפניה החלשה לפני שחזרה פונקציה זו יביא לערך `None`.
    ///
    /// עם זאת, ניתן לשכפל את ההתייחסות החלשה באופן חופשי ולאחסן לשימוש במועד מאוחר יותר.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... שדות נוספים
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // בנה את החלק הפנימי במצב "uninitialized" עם התייחסות חלשה אחת.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // חשוב שלא נוותר על הבעלות על המצביע החלש, אחרת הזיכרון עלול להשתחרר עד ש-`data_fn` יחזור.
        // אם באמת היינו רוצים להעביר בעלות, נוכל ליצור לעצמנו מצביע חלש נוסף, אך הדבר יביא לעדכונים נוספים לספירת ההתייחסות החלשה שאולי לא יהיה צורך אחרת.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // אסמכתאות חזקות צריכות להיות בעלות יחוס חלש משותף, לכן אל תפעיל את ההורס להתייחסות חלשה ישנה שלנו.
        //
        mem::forget(weak);
        strong
    }

    /// בונה `Rc` חדש עם תוכן שאינו מאושר.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // אתחול נדחה:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// בונה `Rc` חדש עם תוכן לא מאוזן, כאשר הזיכרון מתמלא בתים `0`.
    ///
    ///
    /// ראה [`MaybeUninit::zeroed`][zeroed] לקבלת דוגמאות לשימוש נכון ושגוי בשיטה זו.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// בונה `Rc<T>` חדש, ומחזיר שגיאה אם ההקצאה נכשלת
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // יש מצביע חלש מרומז בבעלות כל המצביעים החזקים, מה שמבטיח שההרס החלש לעולם לא ישחרר את ההקצאה בזמן שההרס החזק פועל, גם אם המצביע החלש מאוחסן בתוך החזק.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// בונה `Rc` חדש עם תוכן לא מאוזן, ומחזיר שגיאה אם ההקצאה נכשלת
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // אתחול נדחה:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// בונה `Rc` חדש עם תוכן לא מאוזן, כאשר הזיכרון מתמלא בתים `0`, ומחזיר שגיאה אם ההקצאה נכשלת
    ///
    ///
    /// ראה [`MaybeUninit::zeroed`][zeroed] לקבלת דוגמאות לשימוש נכון ושגוי בשיטה זו.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// בונה `Pin<Rc<T>>` חדש.
    /// אם `T` לא מיישם את `Unpin`, אז `value` יוצמד לזיכרון ולא ניתן יהיה להזיז אותו.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// מחזיר את הערך הפנימי, אם ל-`Rc` יש התייחסות חזקה אחת בדיוק.
    ///
    /// אחרת, [`Err`] מוחזר עם אותו `Rc` שהועבר אליו.
    ///
    ///
    /// זה יצליח גם אם יש התייחסויות חלשות יוצאות מן הכלל.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // העתק את האובייקט הכלול

                // ציין בפני Weaks כי לא ניתן לקדם אותן על ידי הקטנת הספירה החזקה, ואז הסר את מצביע ה-"strong weak" המשתמע תוך כדי טיפול ב לוגיקת טיפה רק על ידי יצירת חלש מזויף.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// בונה פרוסה חדשה עם ספירת הפניות עם תוכן שאינו מאושר.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // אתחול נדחה:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// בונה פרוסה חדשה עם ספירת הפניות עם תוכן לא מאוזן, כשהזיכרון מתמלא בתים `0`.
    ///
    ///
    /// ראה [`MaybeUninit::zeroed`][zeroed] לקבלת דוגמאות לשימוש נכון ושגוי בשיטה זו.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// ממיר ל-`Rc<T>`.
    ///
    /// # Safety
    ///
    /// כמו ב-[`MaybeUninit::assume_init`], על המתקשר להבטיח שהערך הפנימי באמת נמצא במצב מאותחל.
    ///
    /// קריאה לכך כאשר התוכן עדיין לא מאותחל לחלוטין גורמת להתנהגות בלתי מוגדרת מיידית.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // אתחול נדחה:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// ממיר ל-`Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// כמו ב-[`MaybeUninit::assume_init`], על המתקשר להבטיח שהערך הפנימי באמת נמצא במצב מאותחל.
    ///
    /// קריאה לכך כאשר התוכן עדיין לא מאותחל לחלוטין גורמת להתנהגות בלתי מוגדרת מיידית.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // אתחול נדחה:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// צורכת את ה-`Rc` ומחזירה את המצביע העטוף.
    ///
    /// כדי למנוע דליפת זיכרון יש להמיר את המצביע בחזרה ל-`Rc` באמצעות [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// מספק מצביע גולמי לנתונים.
    ///
    /// הספירות לא מושפעות בשום צורה וה-`Rc` אינו נצרך.
    /// המצביע תקף כל עוד יש ספירות חזקות ב-`Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // בטיחות: זה לא יכול לעבור Deref::deref או Rc::inner בגלל
        // זה נדרש כדי לשמור על מקור raw/mut כך למשל
        // `get_mut` יכול לכתוב דרך המצביע לאחר התאוששות ה-Rc באמצעות `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// בונה `Rc<T>` ממצביע גולמי.
    ///
    /// המצביע הגולמי בוודאי הוחזר בעבר על ידי שיחה ל-[`Rc<U>::into_raw`][into_raw] כאשר `U` חייב להיות באותו הגודל והיישור כמו ל-`T`.
    /// זה נכון באופן טריוויאלי אם `U` הוא `T`.
    /// שים לב שאם `U` אינו `T` אך יש לו אותו גודל והתאמה, זה בעצם כמו להעביר הפניות מסוגים שונים.
    /// ראה [`mem::transmute`][transmute] למידע נוסף על המגבלות החלות במקרה זה.
    ///
    /// המשתמש ב-`from_raw` צריך לוודא שערך ספציפי של `T` נשמט רק פעם אחת.
    ///
    /// פונקציה זו אינה בטוחה מכיוון ששימוש לא נכון עלול להוביל לחוסר בטיחות בזיכרון, גם אם לעולם אין גישה ל-`Rc<T>` שהוחזר.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // המרה חזרה ל-`Rc` כדי למנוע נזילה.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // שיחות נוספות ל-`Rc::from_raw(x_ptr)` יהיו חסינות בזיכרון.
    /// }
    ///
    /// // הזיכרון שוחרר כאשר `x` יצא מחוץ לתחום מעל, כך ש-`x_ptr` משתלשל כעת!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // הפוך את הקיזוז כדי למצוא את ה-RcBox המקורי.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// יוצר מצביע [`Weak`] חדש להקצאה זו.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // ודא שלא ניצור חלש משתלשל
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// מקבל את מספר מצביעי [`Weak`] להקצאה זו.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// מקבל מספר מצביעי (`Rc`) חזקים להקצאה זו.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// מחזירה את `true` אם אין מצביעי `Rc` או [`Weak`] אחרים להקצאה זו.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// מחזירה הפניה משתנה ל-`Rc` הנתון, אם אין מצביעי `Rc` או [`Weak`] אחרים לאותה הקצאה.
    ///
    ///
    /// מחזירה [`None`] אחרת, מכיוון שלא בטוח לשנות את הערך המשותף.
    ///
    /// ראה גם [`make_mut`][make_mut], שיהיה [`clone`][clone] לערך הפנימי כשיש מצביעים אחרים.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// מחזירה הפניה משתנה ל-`Rc` הנתון, ללא כל בדיקה.
    ///
    /// ראה גם [`get_mut`], שהוא בטוח ועושה בדיקות מתאימות.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// אסור להפנות כל מצביע `Rc` או [`Weak`] לאותה הקצאה למשך ההשאלה שהוחזרה.
    ///
    /// זה המקרה של מה בכך אם אין מצביעים כאלה, למשל מיד לאחר `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // אנו מקפידים *לא* ליצור סימוכין המכסים את שדות ה-"count", מכיוון שזה מתנגש עם הגישות לספירות הייחוס (למשל
        // על ידי `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// מחזירה `true` אם שני ה-Rc מצביעים על אותה הקצאה (בווריד הדומה ל-[`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// עושה הפניה משתנה ל-`Rc` הנתון.
    ///
    /// אם יש מצביעי `Rc` אחרים לאותה הקצאה, אז `make_mut` יקבע את הערך הפנימי להקצאה חדשה כדי להבטיח בעלות ייחודית.
    /// זה מכונה גם שיבוט על כתיבה.
    ///
    /// אם אין מצביעי `Rc` אחרים להקצאה זו, אזי מצביעי [`Weak`] להקצאה זו ינותקו.
    ///
    /// ראה גם [`get_mut`], שייכשל במקום שיבוט.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // לא ישכפל שום דבר
    /// let mut other_data = Rc::clone(&data);    // לא ישכפל נתונים פנימיים
    /// *Rc::make_mut(&mut data) += 1;        // משכפל נתונים פנימיים
    /// *Rc::make_mut(&mut data) += 1;        // לא ישכפל שום דבר
    /// *Rc::make_mut(&mut other_data) *= 2;  // לא ישכפל שום דבר
    ///
    /// // כעת `data` ו-`other_data` מצביעים על הקצאות שונות.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] המצביעים ינותקו:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // חייבים לשכפל את הנתונים, יש Rcs אחרים.
            // הקצה זיכרון מראש כדי לאפשר כתיבת הערך המשובט ישירות.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // יכול פשוט לגנוב את הנתונים, כל שנותר הוא חלשות
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // הסר שופט משתמע חזק-חלש (אין צורך ליצור כאן חלש מזויף-אנו יודעים שחלשות אחרות יכולות לנקות עבורנו)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // חוסר בטיחות זה בסדר מכיוון שמובטח לנו שהמצביע שהוחזר הוא המצביע *היחיד* שיוחזר אי פעם לט '.
        // מספר הפניות שלנו מובטח שיהיה 1 בנקודה זו, ואנחנו דרשנו שה-`Rc<T>` עצמו יהיה `mut`, ולכן אנו מחזירים את ההתייחסות האפשרית היחידה להקצאה.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// ניסיון להוריד את ה-`Rc<dyn Any>` לסוג קונקרטי.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// הקצאת `RcBox<T>` עם מספיק מקום לערך פנימי שאולי לא מוגדל כאשר הערך מספק את הפריסה.
    ///
    /// הפונקציה `mem_to_rcbox` נקראת באמצעות מצביע הנתונים ועליה להחזיר מצביע (שעלול להיות שמן) עבור ה-`RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // חשב את הפריסה באמצעות פריסת הערך הנתונה.
        // בעבר, הפריסה חושבה על הביטוי `&*(ptr as* const RcBox<T>)`, אך הדבר יצר הפניה שלא מיושרה (ראה #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// מקצה `RcBox<T>` עם מספיק מקום לערך פנימי שאולי לא מוגדל בו הערך מספק הפריסה, ומחזיר שגיאה אם ההקצאה נכשלת.
    ///
    ///
    /// הפונקציה `mem_to_rcbox` נקראת באמצעות מצביע הנתונים ועליה להחזיר מצביע (שעלול להיות שמן) עבור ה-`RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // חשב את הפריסה באמצעות פריסת הערך הנתונה.
        // בעבר, הפריסה חושבה על הביטוי `&*(ptr as* const RcBox<T>)`, אך הדבר יצר הפניה שלא מיושרה (ראה #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // הקצה לפריסה.
        let ptr = allocate(layout)?;

        // אתחל את ה-RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// הקצאת `RcBox<T>` עם מספיק מקום לערך פנימי לא גדול
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // הקצה ל-`RcBox<T>` באמצעות הערך הנתון.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // העתק ערך כבתים
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // שחררו את ההקצאה מבלי להפיל את תוכנה
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// מקצה `RcBox<[T]>` באורך הנתון.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// העתק אלמנטים מהפרוסה ל-Rc <\[T\]> שהוקצה לאחרונה
    ///
    /// לא בטוח מפני שהמתקשר צריך לקחת בעלות או לאגד את `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// בונה `Rc<[T]>` מאיטרטור הידוע כגודל מסוים.
    ///
    /// ההתנהגות אינה מוגדרת במידה והגודל לא נכון.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // שומר Panic בזמן שיבוט אלמנטים T.
        // במקרה של panic, אלמנטים שנכתבו לתוך ה-RcBox החדש יושמטו ואז הזיכרון ישוחרר.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // מצביע לאלמנט ראשון
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // הכל ברור.תשכחו מהשומר כדי שלא ישחרר את ה-RcBox החדש.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// התמחות trait המשמשת ל-`From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// מוריד את ה-`Rc`.
    ///
    /// זה יקטין את ספירת ההתייחסות החזקה.
    /// אם ספירת הייחוס החזקה מגיעה לאפס אזי ההפניות היחידות האחרות (אם קיימות) הן [`Weak`], לכן אנו `drop` הערך הפנימי.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // לא מדפיס שום דבר
    /// drop(foo2);   // מדפיס "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // להשמיד את האובייקט הכלול
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // הסר את מצביע "strong weak" הגלום כעת לאחר שהרסנו את התוכן.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// עושה שיבוט של מצביע ה-`Rc`.
    ///
    /// זה יוצר מצביע נוסף לאותה הקצאה, ומגדיל את ספירת ההתייחסות החזקה.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// יוצר `Rc<T>` חדש, עם ערך `Default` עבור `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// פריצה כדי לאפשר התמחות ב-`Eq` למרות של-`Eq` יש שיטה.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// אנו מבצעים את ההתמחות הזו כאן ולא כביצוע אופטימיזציה כללית יותר ב-`&T`, מכיוון שאחרת זה יוסיף עלות לכל בדיקת השוויון של שופטים.
/// אנו מניחים ש-Rc משמשים לאחסון ערכים גדולים, שהם איטי לשיבוט, אך גם כבדים לבדיקת שוויון, מה שגורם לעלות זו להשתלם ביתר קלות.
///
/// כמו כן, סביר יותר שיהיו שני שיבוטים של `Rc`, המצביעים על אותו ערך, מאשר שני `&T`.
///
/// אנו יכולים לעשות זאת רק כאשר `T: Eq` כ-`PartialEq` עשוי להיות לא רפלקסיבי בכוונה.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// שוויון לשני RC.
    ///
    /// שני RCs שווים אם הערכים הפנימיים שלהם שווים, גם אם הם מאוחסנים בהקצאה שונה.
    ///
    /// אם `T` מיישם גם את `Eq` (המרמז על רפלקסיביות של שוויון), שני 'RC' שמצביעים על אותה הקצאה תמיד שווים.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// אי-שוויון לשני RC.
    ///
    /// שני RCs אינם שווים אם הערכים הפנימיים שלהם אינם שווים.
    ///
    /// אם `T` מיישם גם את `Eq` (מרמז על רפלקסיביות של שוויון), שני Rcs המצביעים על אותה הקצאה לעולם אינם שווים.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// השוואה חלקית לשני `Rc`s.
    ///
    /// השניים מושווים באמצעות קריאה ל-`partial_cmp()` על הערכים הפנימיים שלהם.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// השוואה פחותה משני שני Rc.
    ///
    /// השניים מושווים באמצעות קריאה ל-`<` על הערכים הפנימיים שלהם.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'פחות או שווה' להשוואה לשני 'Rc'.
    ///
    /// השניים מושווים באמצעות קריאה ל-`<=` על הערכים הפנימיים שלהם.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// השוואה גדולה יותר משני שני Rc.
    ///
    /// השניים מושווים באמצעות קריאה ל-`>` על הערכים הפנימיים שלהם.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// השוואה 'גדולה או שווה יותר לשני' Rc.
    ///
    /// השניים מושווים באמצעות קריאה ל-`>=` על הערכים הפנימיים שלהם.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// השוואה בין שני RCs.
    ///
    /// השניים מושווים באמצעות קריאה ל-`cmp()` על הערכים הפנימיים שלהם.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// הקצה פרוסה שסופרה הפניה ומלא אותה על ידי שיבוט פריטי 'v'.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// הקצה פרוסת מחרוזת שנספרה והעתק לתוכה את `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// הקצה פרוסת מחרוזת שנספרה והעתק לתוכה את `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// העבר אובייקט מוסגר להקצאה חדשה, ספירת הפניה.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// הקצה פרוסה שנספרה והעבור לתוכה פריטי 'v'.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // אפשר ל-Vec לשחרר את זיכרונו, אך לא להרוס את תוכנו
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// לוקח כל אלמנט ב-`Iterator` ואוסף אותו ל-`Rc<[T]>`.
    ///
    /// # מאפייני ביצועים
    ///
    /// ## המקרה הכללי
    ///
    /// במקרה הכללי, איסוף ל-`Rc<[T]>` נעשה על ידי איסוף ראשון ל-`Vec<T>`.כלומר, בעת כתיבת הדברים הבאים:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// זה מתנהג כאילו כתבנו:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // סט ההקצאות הראשון קורה כאן.
    ///     .into(); // הקצאה שנייה ל-`Rc<[T]>` מתרחשת כאן.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// זה יוקצה פעמים רבות ככל שיידרש לבניית ה-`Vec<T>` ואז יוקצה פעם אחת להפיכת ה-`Vec<T>` ל-`Rc<[T]>`.
    ///
    ///
    /// ## מחטאים באורך ידוע
    ///
    /// כאשר ה-`Iterator` שלך מיישם את `TrustedLen` והוא בגודל מדויק, תתבצע הקצאה אחת ל-`Rc<[T]>`.לדוגמה:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // רק הקצאה אחת מתרחשת כאן.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// התמחות trait המשמשת לאיסוף ל-`Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // זה המקרה של איטרטור `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // בטיחות: עלינו להבטיח שאיטרטור יהיה באורך מדויק ויש לנו.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // חזור ליישום רגיל.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` היא גרסה של [`Rc`] המחזיקה התייחסות שאינה בבעלות להקצאה המנוהלת.ההקצאה ניגשת על ידי קריאה ל-[`upgrade`] על מצביע ה-`Weak`, המחזיר את ["Option"] "<" ["Rc"] "<T>>`.
///
/// מכיוון שהפניה ל-`Weak` אינה נחשבת לבעלות, היא לא תמנע את ירידת הערך המאוחסן בהקצאה, ו-`Weak` עצמו אינו מתחייב לגבי הערך שעדיין קיים.
/// לפיכך הוא עשוי להחזיר את [`None`] כאשר ["שדרג"] ד.
/// שים לב, עם זאת, הפניה ל-`Weak` * מונעת את הקצאת הקצאה עצמה (חנות הגיבוי).
///
/// מצביע `Weak` שימושי לשמירה על התייחסות זמנית להקצאה המנוהלת על ידי [`Rc`] מבלי למנוע את ירידת הערך הפנימי שלה.
/// הוא משמש גם למניעת הפניות מעגליות בין מצביעי [`Rc`], מכיוון שהפניות בעלות הדדית לעולם לא יאפשרו לשחרר אף אחד מה-[`Rc`].
/// לדוגמא, לעץ יכולות להיות מצביעי [`Rc`] חזקים מצומת הורים לילדים, ומצבי `Weak` מילדים חזרה להוריהם.
///
/// הדרך האופיינית להשיג מצביע `Weak` היא להתקשר ל-[`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // זהו `NonNull` המאפשר אופטימיזציה של גודל סוג זה באנומות, אך הוא אינו בהכרח מצביע תקף.
    //
    // `Weak::new` מגדיר את זה ל-`usize::MAX` כך שלא יהיה צורך להקצות מקום בערימה.
    // זה לא ערך שלמצביע אמיתי יהיה אי פעם מכיוון של-RcBox יש יישור לפחות 2.
    // זה אפשרי רק כאשר `T: Sized`;`T` לא גדול לעולם לא משתלשל.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// בונה `Weak<T>` חדש, מבלי להקצות זיכרון כלשהו.
    /// קריאה ל-[`upgrade`] על ערך ההחזרה נותנת תמיד את [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// סוג עוזר המאפשר גישה לספירות הפניה מבלי להעלות טענות לגבי שדה הנתונים.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// מחזיר מצביע גולמי לאובייקט `T` אליו הצביע `Weak<T>`.
    ///
    /// המצביע תקף רק אם יש כמה הפניות חזקות.
    /// המצביע עשוי להיות תלוי, לא מיושר או אפילו [`null`] אחרת.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // שניהם מצביעים על אותו אובייקט
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // החזק כאן מחזיק אותו בחיים, כך שאנחנו עדיין יכולים לגשת לאובייקט.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // אבל לא עוד.
    /// // אנחנו יכולים לעשות weak.as_ptr(), אך גישה למצביע תוביל להתנהגות לא מוגדרת.
    /// // assert_eq! ("שלום", לא בטוח {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // אם המצביע משתלשל, אנו מחזירים את הזקיף ישירות.
            // זו לא יכולה להיות כתובת מטען חוקית, מכיוון שהמטען מיושר לפחות כמו RcBox (usize).
            ptr as *const T
        } else {
            // בטיחות: אם is_dangling מחזיר שקר, אז המצביע ניתן להפניה.
            // העומס עשוי להישמט בשלב זה, ועלינו לשמור על מקור, לכן השתמש במניפולציה של מצביעים גולמיים.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// צורכת את ה-`Weak<T>` והופכת אותו למצביע גולמי.
    ///
    /// זה ממיר את המצביע החלש למצביע גולמי, תוך שמירה על הבעלות על התייחסות חלשה אחת (הספירה החלשה לא משתנה על ידי פעולה זו).
    /// ניתן להחזיר אותו ל-`Weak<T>` עם [`from_raw`].
    ///
    /// אותן מגבלות לגבי הגישה ליעד של המצביע כמו ב-[`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// ממיר מצביע גולמי שנוצר בעבר על ידי [`into_raw`] בחזרה ל-`Weak<T>`.
    ///
    /// זה יכול לשמש בכדי לקבל בבטחה התייחסות חזקה (על ידי התקשרות ל-[`upgrade`] מאוחר יותר) או כדי להתמקם בספירה החלשה על ידי הפלת ה-`Weak<T>`.
    ///
    /// זה לוקח בעלות על התייחסות חלשה אחת (למעט מצביעים שנוצרו על ידי [`new`], מכיוון שאלה לא מחזיקים בשום דבר; השיטה עדיין עובדת עליהם).
    ///
    /// # Safety
    ///
    /// המצביע בוודאי מקורו ב-[`into_raw`] ועליו להחזיק בהתייחסות החלשה הפוטנציאלית שלו.
    ///
    /// מותר שהספירה החזקה תהיה 0 בזמן הקריאה לכך.
    /// עם זאת, זה לוקח בעלות על התייחסות חלשה אחת המיוצגת כרגע כמצביע גולמי (הספירה החלשה לא משתנה על ידי פעולה זו) ולכן יש להתאים אותה עם שיחה קודמת ל-[`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // דחה את הספירה החלשה האחרונה.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ראה Weak::as_ptr לקבלת הקשר כיצד נגזר מצביע הקלט.

        let ptr = if is_dangling(ptr as *mut T) {
            // זהו חלש משתלשל.
            ptr as *mut RcBox<T>
        } else {
            // אחרת, מובטח לנו שהמצביע הגיע מחולשה לא משתלשלת.
            // בטיחות: data_offset בטוח להתקשר אליו, מכיוון ש-ptr מתייחס לט 'אמיתי (שעלול להישמט).
            let offset = unsafe { data_offset(ptr) };
            // לפיכך, אנו הופכים את הקיזוז כדי לקבל את כל ה-RcBox.
            // בטיחות: מקור המצביע הוא חלש, ולכן הקיזוז הזה בטוח.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // בטיחות: כעת התאוששנו המצביע החלש המקורי, כך שנוכל ליצור את החלש.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// מנסה לשדרג את מצביע ה-`Weak` ל-[`Rc`], לעכב את צניחת הערך הפנימי אם יצליח.
    ///
    ///
    /// מחזירה את [`None`] אם הערך הפנימי ירד מאז.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // השמד את כל המצביעים החזקים.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// מקבל מספר מצביעי (`Rc`) חזקים המצביעים על הקצאה זו.
    ///
    /// אם `self` נוצר באמצעות [`Weak::new`], זה יחזיר 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// מקבל את מספר מצביעי `Weak` המצביעים על הקצאה זו.
    ///
    /// אם לא יישארו מצביעים חזקים, זה יחזיר אפס.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // גרע את ה-ptr החלש הגלום
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// מחזירה את `None` כאשר המצביע משתלשל ואין `RcBox` שהוקצה, (כלומר כאשר `Weak` זה נוצר על ידי `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // אנו מקפידים *לא* ליצור הפניה המכסה את שדה "data", מכיוון שהשדה עשוי להיות מוטציה במקביל (למשל, אם ה-`Rc` האחרון יושמט, שדה הנתונים יושמט במקום).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// מחזירה `true` אם שני ה'חלשים 'מצביעים על אותה הקצאה (בדומה ל-[`ptr::eq`]), או אם שניהם אינם מצביעים על הקצאה כלשהי (מכיוון שהם נוצרו עם `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// מכיוון שזה משווה בין מצביעים זה אומר ש-`Weak::new()` ישווה זה לזה, למרות שהם לא מצביעים על הקצאה כלשהי.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// השוואת `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// מפיל את מצביע ה-`Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // לא מדפיס שום דבר
    /// drop(foo);        // מדפיס "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // הספירה החלשה מתחילה ב-1, ותעלה לאפס רק אם כל המצביעים החזקים נעלמו.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// עושה שיבוט של מצביע ה-`Weak` המצביע על אותה הקצאה.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// בונה `Weak<T>` חדש, ומקצה זיכרון ל-`T` מבלי לאתחל אותו.
    /// קריאה ל-[`upgrade`] על ערך ההחזרה נותנת תמיד את [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: בדקנו_הוסף כאן כדי להתמודד עם mem::forget בבטחה.באופן מיוחד
// אם אתה mem::forget Rcs (או Weaks), ספירת היישומים יכולה לעלות על גדותיהם, ואז אתה יכול לפנות את ההקצאה בעוד Rcs (או Weaks) מצטיינים.
//
// אנו מפילים מכיוון שמדובר בתרחיש מנוון כל כך שלא אכפת לנו ממה שקורה-אף תוכנית אמיתית לעולם לא צריכה לחוות זאת.
//
// זה צריך להיות תקורה זניחה מכיוון שאתה לא באמת צריך לשכפל אותם הרבה ב-Rust הודות לבעלות ולסמנטיקה של מהלך.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // אנו רוצים להפיל על הצפה במקום להפיל את הערך.
        // ספירת הייחוס לעולם לא תהיה אפס כשזה נקרא;
        // עם זאת, אנו מכניסים כאן הפלה כדי לרמוז על LLVM על אופטימיזציה שהוחמצה אחרת.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // אנו רוצים להפיל על הצפה במקום להפיל את הערך.
        // ספירת הייחוס לעולם לא תהיה אפס כשזה נקרא;
        // עם זאת, אנו מכניסים כאן הפלה כדי לרמוז על LLVM על אופטימיזציה שהוחמצה אחרת.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// קבל את הקיזוז בתוך `RcBox` עבור המטען שמאחורי מצביע.
///
/// # Safety
///
/// על המצביע להצביע על (ויש לו מטא-נתונים תקפים עבור) מופע חוקי קודם של T, אך מותר להוריד את ה-T.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // יישר את הערך הלא ממדים לסוף ה-RcBox.
    // מכיוון ש-RcBox הוא repr(C), זה תמיד יהיה השדה האחרון בזיכרון.
    // בטיחות: מכיוון שהסוגים היחידים שאינם גדולים הם פרוסות, אובייקטים trait,
    // וסוגים חיצוניים, דרישת הבטיחות של הקלט מספיקה כרגע כדי לספק את הדרישות של align_of_val_raw;זהו פרט יישום של השפה שלא ניתן להסתמך עליה מחוץ ל-std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}