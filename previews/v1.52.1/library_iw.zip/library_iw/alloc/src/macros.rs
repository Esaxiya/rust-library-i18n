/// יוצר [`Vec`] המכיל את הארגומנטים.
///
/// `vec!` מאפשר להגדיר את ה-Vec עם תחביר זהה לביטויי מערך.
/// ישנן שתי צורות של מאקרו זה:
///
/// - צור [`Vec`] המכיל רשימת אלמנטים נתונה:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - צור [`Vec`] מאלמנט וגודל נתון:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// שים לב שבניגוד לביטויי מערך תחביר זה תומך בכל האלמנטים המיישמים את [`Clone`] ומספר האלמנטים לא צריך להיות קבוע.
///
/// פעולה זו תשתמש ב-`clone` כדי לשכפל ביטוי, ולכן צריך להיזהר להשתמש בזה עם סוגים בעלי יישום `Clone` לא תקני.
/// לדוגמא, `vec![Rc::new(1);5] `תיצור vector של חמש אזכורים לאותו ערך שלם מוסגר, ולא חמש אזכורים המפנים למספרים שלמים באופן עצמאי.
///
///
/// כמו כן, שים לב ש-`vec![expr; 0]` מותר ומייצר vector ריק.
/// זה עדיין יעריך את `expr`, עם זאת, ויוריד מיד את הערך המתקבל, אז שימו לב לתופעות הלוואי.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): עם cfg(test), שיטת `[T]::into_vec` הטבועה, הנדרשת להגדרת מאקרו זו, אינה זמינה.
// במקום זאת השתמש בפונקציה `slice::into_vec` אשר זמינה רק עם cfg(test) NB ראה את מודול slice::hack ב-slice.rs למידע נוסף
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// יוצר `String` באמצעות אינטרפולציה של ביטויי זמן ריצה.
///
/// הטיעון הראשון ש-`format!` מקבל הוא מחרוזת פורמט.זה חייב להיות מילולי מחרוזת.העוצמה של מחרוזת העיצוב נמצאת ב-"{}" הכלול.
///
/// פרמטרים נוספים המועברים ל-`format!` מחליפים את '{} בתוך מחרוזת העיצוב בסדר שניתן אלא אם משתמשים בפרמטרים עם שם או מיקום;ראה [`std::fmt`] למידע נוסף.
///
///
/// שימוש נפוץ ב-`format!` הוא שרשור ואינטרפולציה של מיתרים.
/// באותה מוסכמה משתמשים במקרו [`print!`] ו-[`write!`], בהתאם ליעד המיועד למחרוזת.
///
/// כדי להמיר ערך יחיד למחרוזת, השתמש בשיטת [`to_string`].זה ישתמש בעיצוב [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics אם יישום trait בעיצוב מחזיר שגיאה.
/// זה מצביע על יישום שגוי מכיוון ש-`fmt::Write for String` לעולם לא מחזיר שגיאה בעצמה.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// כפה על צומת AST לביטוי כדי לשפר את האבחון במיקום התבנית.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}