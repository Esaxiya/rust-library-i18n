#![stable(feature = "rust1", since = "1.0.0")]

//! מצביעי ספירת הפניות בטוחים בחוטים.
//!
//! לפרטים נוספים, עיין בתיעוד של [`Arc<T>`][Arc].

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// מגבלה רכה על כמות הפניות שניתן לבצע ל-`Arc`.
///
/// מעבר למגבלה זו יבטל את התוכנית שלך (אם כי לא בהכרח) בהפניות _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer אינו תומך בגדרות זיכרון.
// כדי למנוע דיווחים חיוביים כוזבים ביישום Arc/Weak השתמש במקום זאת בעומסים אטומיים לסינכרון.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// מצביע ספירת הפניות בטיחות חוטים.'Arc' מייצג 'Atomically Reference Counted'.
///
/// הסוג `Arc<T>` מספק בעלות משותפת על ערך מסוג `T`, המוקצה בערימה.הפעלת [`clone`][clone] ב-`Arc` מייצרת מופע `Arc` חדש, המצביע על אותה הקצאה בערמה כמו המקור `Arc`, תוך הגדלת ספירת התייחסות.
/// כאשר מצביע ה-`Arc` האחרון להקצאה נתונה נהרס, הערך השמור באותה הקצאה (המכונה לעתים קרובות "inner value") יורד גם הוא.
///
/// הפניות משותפות ב-Rust אינן מאפשרות מוטציה כברירת מחדל, ו-`Arc` אינו יוצא מן הכלל: בדרך כלל אינך יכול לקבל התייחסות ניתנת לשינוי למשהו בתוך `Arc`.אם אתה צריך להשתנות באמצעות `Arc`, השתמש ב-[`Mutex`][mutex], [`RwLock`][rwlock] או באחד מסוגי [`Atomic`][atomic].
///
/// ## בטיחות חוטים
///
/// שלא כמו [`Rc<T>`], `Arc<T>` משתמש בפעולות אטומיות לצורך ספירת הפניות שלו.פירוש הדבר שהוא בטוח בחוטים.החיסרון הוא שפעולות אטומיות יקרות יותר מגישות זיכרון רגילות.אם אינך משתף הקצאות שנספרו בין הפתילים, שקול להשתמש ב-[`Rc<T>`] לצורך תקורה נמוכה יותר.
/// [`Rc<T>`] הוא ברירת מחדל בטוח, מכיוון שהמהדר יתפוס כל ניסיון לשלוח [`Rc<T>`] בין השרשור.
/// עם זאת, ספרייה עשויה לבחור ב-`Arc<T>` על מנת לתת לצרכני הספרייה גמישות רבה יותר.
///
/// `Arc<T>` יישם את [`Send`] ו-[`Sync`] כל עוד ה-`T` יישם את [`Send`] ו-[`Sync`].
/// מדוע אינך יכול להכניס סוג `T` שאינו בטוח לברגה ב-`Arc<T>` כדי להפוך אותו לבטוח הברגה?זה יכול להיות מעט אינטואיטיבי בהתחלה: אחרי הכל, לא העיקר של בטיחות חוט `Arc<T>`?המפתח הוא זה: `Arc<T>` הופך אותו לבטוח הברגה בעל בעלות מרובה על אותם נתונים, אך הוא אינו מוסיף בטיחות שרשור לנתוניו.
///
/// שקול `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] אינו [`Sync`], ואם `Arc<T>` תמיד היה [`Send`], 'Arc <`[` RefCell<T>`]`> `יהיה גם כן.
/// אבל אז תהיה לנו בעיה:
/// [`RefCell<T>`] אינו בטוח בחוטים;זה עוקב אחר ספירת ההלוואות באמצעות פעולות שאינן אטומיות.
///
/// בסופו של דבר, פירוש הדבר כי ייתכן שיהיה עליך להתאים את `Arc<T>` לסוג [`std::sync`] כלשהו, בדרך כלל [`Mutex<T>`][mutex].
///
/// ## שבירת מחזורים עם `Weak`
///
/// ניתן להשתמש בשיטת [`downgrade`][downgrade] ליצירת מצביע [`Weak`] שאינו בבעלות.מצביע [`Weak`] יכול להיות ["שדרוג"][שדרוג] ל-`Arc`, אך זה יחזיר את [`None`] אם הערך המאוחסן בהקצאה כבר הושמט.
/// במילים אחרות, מצביעי `Weak` אינם שומרים על הערך בתוך ההקצאה בחיים;עם זאת, הם *עושים* לשמור על ההקצאה (חנות הגיבוי לערך) בחיים.
///
/// מחזור בין מצביעי `Arc` לעולם לא יוקצה.
/// מסיבה זו, [`Weak`] משמש לשבירת מחזורים.לדוגמא, לעץ יכולות להיות מצביעי `Arc` חזקים מצומת הורים לילדים, ומצבי [`Weak`] מילדים חזרה להוריהם.
///
/// # שיבוט הפניות
///
/// יצירת הפניה חדשה מצביע קיים של ספירת הפניות מתבצעת באמצעות ה-`Clone` trait המיושם עבור [`Arc<T>`][Arc] ו-[`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // שני התחבירים להלן שווים.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b ו-foo הם כל קשתות המצביעות על אותו מיקום זיכרון
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` מפנה אוטומטית ל `T` (דרך [`Deref`][deref] trait), כך שתוכל להתקשר לשיטות 'T' בערך מסוג `Arc<T>`.כדי למנוע עימותים בשמות עם שיטות 'T', השיטות של `Arc<T>` עצמו הן פונקציות משויכות, הנקראות באמצעות [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `קשת<T>יישומי traits כמו `Clone` עשויים להיקרא גם באמצעות תחביר מלא.
/// יש אנשים שמעדיפים להשתמש בתחביר מוסמך לחלוטין, בעוד שאחרים מעדיפים להשתמש בתחביר שיחת-שיחה.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // תחביר שיחת שיטה
/// let arc2 = arc.clone();
/// // תחביר מוסמך לחלוטין
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] אינו מפנה אוטומטית ל-`T`, מכיוון שהערך הפנימי כבר ירד.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// שיתוף נתונים בלתי ניתנים לשינוי בין האשכולות:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// שים לב שאנחנו **לא** מריצים את הבדיקות האלה כאן.
// בוני windows נהיים מאוד אומללים אם חוט עובר את החוט הראשי ואז יוצא בו זמנית (משהו סתום) אז אנחנו פשוט נמנעים מכך על ידי כך שלא נבצע את הבדיקות הללו.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// שיתוף [`AtomicUsize`] משתנה:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// עיין ב-[`rc` documentation][rc_examples] לקבלת דוגמאות נוספות לספירת הפניות באופן כללי.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` היא גרסה של [`Arc`] המחזיקה התייחסות שאינה בבעלות להקצאה המנוהלת.
/// ההקצאה ניגשת על ידי קריאה ל-[`upgrade`] על מצביע `Weak`, המחזיר את ["אפשרות"] <"[" קשת "]"<T>> `.
///
/// מכיוון שהפניה ל-`Weak` אינה נחשבת לבעלות, היא לא תמנע את ירידת הערך המאוחסן בהקצאה, ו-`Weak` עצמו אינו מתחייב לגבי הערך שעדיין קיים.
///
/// לפיכך הוא עשוי להחזיר את [`None`] כאשר ["שדרג"] ד.
/// שים לב, עם זאת, הפניה ל-`Weak` * מונעת את הקצאת הקצאה עצמה (חנות הגיבוי).
///
/// מצביע `Weak` שימושי לשמירה על התייחסות זמנית להקצאה המנוהלת על ידי [`Arc`] מבלי למנוע את ירידת הערך הפנימי שלה.
/// הוא משמש גם למניעת הפניות מעגליות בין מצביעי [`Arc`], מכיוון שהפניות בעלות הדדית לעולם לא יאפשרו לשחרר אף אחד מה-[`Arc`].
/// לדוגמא, לעץ יכולות להיות מצביעי [`Arc`] חזקים מצומת הורים לילדים, ומצבי `Weak` מילדים חזרה להוריהם.
///
/// הדרך האופיינית להשיג מצביע `Weak` היא להתקשר ל-[`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // זהו `NonNull` המאפשר אופטימיזציה של גודל סוג זה באנומות, אך הוא אינו בהכרח מצביע תקף.
    //
    // `Weak::new` מגדיר את זה ל-`usize::MAX` כך שלא יהיה צורך להקצות מקום בערימה.
    // זה לא ערך שלמצביע אמיתי יהיה אי פעם מכיוון של-RcBox יש יישור לפחות 2.
    // זה אפשרי רק כאשר `T: Sized`;`T` לא גדול לעולם לא משתלשל.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// זהו הוכחה repr(C) ל-future כנגד סידור שדות אפשרי, אשר יפריע ל-[into|from]_raw() בטוח אחרת מסוגים פנימיים הניתנים להחלפה.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // הערך usize::MAX משמש כזקף עבור "locking" באופן זמני את היכולת לשדרג מצביעים חלשים או לשדרג לאחור חזקים;זה משמש כדי להימנע מירוצים ב-`make_mut` וב-`get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// בונה `Arc<T>` חדש.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // התחל את ספירת המצביע החלשה כ-1 שהיא המצביע החלש שמוחזק על ידי כל המצביעים החזקים (kinda), ראה std/rc.rs למידע נוסף
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// בונה `Arc<T>` חדש תוך שימוש בהתייחסות חלשה לעצמו.
    /// ניסיון לשדרג את הפניה החלשה לפני שחזרה פונקציה זו יביא לערך `None`.
    /// עם זאת, ניתן לשכפל את ההתייחסות החלשה באופן חופשי ולאחסן לשימוש במועד מאוחר יותר.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // בנה את החלק הפנימי במצב "uninitialized" עם התייחסות חלשה אחת.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // חשוב שלא נוותר על הבעלות על המצביע החלש, אחרת הזיכרון עלול להשתחרר עד ש-`data_fn` יחזור.
        // אם באמת היינו רוצים להעביר בעלות, נוכל ליצור לעצמנו מצביע חלש נוסף, אך הדבר יביא לעדכונים נוספים לספירת ההתייחסות החלשה שאולי לא יהיה צורך אחרת.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // כעת אנו יכולים לאתחל כראוי את הערך הפנימי ולהפוך את ההתייחסות החלשה שלנו להתייחסות חזקה.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // הכתיבה הנ"ל לשדה הנתונים חייבת להיות גלויה לכל שרשורים אשר צופים בספירה חזקה שאינה אפסית.
            // לכן אנו זקוקים להזמנת "Release" לפחות על מנת להסתנכרן עם `compare_exchange_weak` ב-`Weak::upgrade`.
            //
            // "Acquire" אין צורך בהזמנה.
            // כאשר בוחנים את ההתנהגויות האפשריות של `data_fn` עלינו רק לבדוק מה הוא יכול לעשות בהתייחס ל-`Weak` שאינו ניתן לשדרוג:
            //
            // - זה יכול *לשכפל* את `Weak`, ולהגדיל את ספירת ההתייחסות החלשה.
            // - זה יכול להוריד את השיבוטים האלה, ולהפחית את ספירת הייחוס החלשה (אך לעולם לא לאפס).
            //
            // תופעות לוואי אלו אינן משפיעות עלינו בשום צורה, ואין תופעות לוואי אחרות אפשריות בקוד בטוח בלבד.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // אסמכתאות חזקות צריכות להיות בעלות יחוס חלש משותף, לכן אל תפעיל את ההורס להתייחסות חלשה ישנה שלנו.
        //
        mem::forget(weak);
        strong
    }

    /// בונה `Arc` חדש עם תוכן שאינו מאושר.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // אתחול נדחה:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// בונה `Arc` חדש עם תוכן לא מאוזן, כאשר הזיכרון מתמלא בתים `0`.
    ///
    ///
    /// ראה [`MaybeUninit::zeroed`][zeroed] לקבלת דוגמאות לשימוש נכון ושגוי בשיטה זו.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// בונה `Pin<Arc<T>>` חדש.
    /// אם `T` לא מיישם את `Unpin`, אז `data` יוצמד לזיכרון ולא ניתן יהיה להזיז אותו.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// בונה `Arc<T>` חדש, ומחזיר שגיאה אם ההקצאה נכשלת.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // התחל את ספירת המצביע החלשה כ-1 שהיא המצביע החלש שמוחזק על ידי כל המצביעים החזקים (kinda), ראה std/rc.rs למידע נוסף
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// בונה `Arc` חדש עם תוכן שאינו מאושר, ומחזיר שגיאה אם ההקצאה נכשלת.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // אתחול נדחה:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// בונה `Arc` חדש עם תוכן לא מאוזן, כאשר הזיכרון מתמלא בתים `0`, ומחזיר שגיאה אם ההקצאה נכשלת.
    ///
    ///
    /// ראה [`MaybeUninit::zeroed`][zeroed] לקבלת דוגמאות לשימוש נכון ושגוי בשיטה זו.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// מחזיר את הערך הפנימי, אם ל-`Arc` יש התייחסות חזקה אחת בדיוק.
    ///
    /// אחרת, [`Err`] מוחזר עם אותו `Arc` שהועבר אליו.
    ///
    ///
    /// זה יצליח גם אם יש התייחסויות חלשות יוצאות מן הכלל.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // הכין מצביע חלש כדי לנקות את ההתייחסות המרומזת חזקה-חלשה
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// בונה פרוסה חדשה שסופרה הפניה אטומית עם תוכן שאינו מאושר.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // אתחול נדחה:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// בונה פרוסה חדשה עם ספירת הפניות אטומית עם תוכן לא ממוגן, כשהזיכרון מתמלא בתים `0`.
    ///
    ///
    /// ראה [`MaybeUninit::zeroed`][zeroed] לקבלת דוגמאות לשימוש נכון ושגוי בשיטה זו.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// ממיר ל-`Arc<T>`.
    ///
    /// # Safety
    ///
    /// כמו ב-[`MaybeUninit::assume_init`], על המתקשר להבטיח שהערך הפנימי באמת נמצא במצב מאותחל.
    ///
    /// קריאה לכך כאשר התוכן עדיין לא מאותחל לחלוטין גורמת להתנהגות בלתי מוגדרת מיידית.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // אתחול נדחה:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// ממיר ל-`Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// כמו ב-[`MaybeUninit::assume_init`], על המתקשר להבטיח שהערך הפנימי באמת נמצא במצב מאותחל.
    ///
    /// קריאה לכך כאשר התוכן עדיין לא מאותחל לחלוטין גורמת להתנהגות בלתי מוגדרת מיידית.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // אתחול נדחה:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// צורכת את ה-`Arc` ומחזירה את המצביע העטוף.
    ///
    /// כדי למנוע דליפת זיכרון יש להמיר את המצביע בחזרה ל-`Arc` באמצעות [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// מספק מצביע גולמי לנתונים.
    ///
    /// הספירות לא מושפעות בשום צורה וה-`Arc` אינו נצרך.
    /// המצביע תקף כל עוד יש ספירות חזקות ב-`Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // בטיחות: זה לא יכול לעבור Deref::deref או RcBoxPtr::inner בגלל
        // זה נדרש כדי לשמור על מקור raw/mut כך למשל
        // `get_mut` יכול לכתוב דרך המצביע לאחר התאוששות ה-Rc באמצעות `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// בונה `Arc<T>` ממצביע גולמי.
    ///
    /// המצביע הגולמי בוודאי הוחזר בעבר על ידי שיחה ל-[`Arc<U>::into_raw`][into_raw] כאשר `U` חייב להיות באותו הגודל והיישור כמו ל-`T`.
    /// זה נכון באופן טריוויאלי אם `U` הוא `T`.
    /// שים לב שאם `U` אינו `T` אך יש לו אותו גודל והתאמה, זה בעצם כמו להעביר הפניות מסוגים שונים.
    /// ראה [`mem::transmute`][transmute] למידע נוסף על המגבלות החלות במקרה זה.
    ///
    /// המשתמש ב-`from_raw` צריך לוודא שערך ספציפי של `T` נשמט רק פעם אחת.
    ///
    /// פונקציה זו אינה בטוחה מכיוון ששימוש לא נכון עלול להוביל לחוסר בטיחות בזיכרון, גם אם לעולם אין גישה ל-`Arc<T>` שהוחזר.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // המרה חזרה ל-`Arc` כדי למנוע נזילה.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // שיחות נוספות ל-`Arc::from_raw(x_ptr)` יהיו חסינות בזיכרון.
    /// }
    ///
    /// // הזיכרון שוחרר כאשר `x` יצא מחוץ לתחום מעל, כך ש-`x_ptr` משתלשל כעת!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // הפוך את הקיזוז כדי למצוא את ArcInner המקורי.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// יוצר מצביע [`Weak`] חדש להקצאה זו.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // זה רגוע הוא בסדר מכיוון שאנחנו בודקים את הערך ב-CAS להלן.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // בדוק אם הדלפק החלש כרגע "locked";אם כן, ספין.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: קוד זה מתעלם כרגע מהאפשרות של הצפה
            // לתוך usize::MAX;באופן כללי יש להתאים גם את ה-Rc וגם את Arc כדי להתמודד עם הצפה.
            //

            // שלא כמו ב-Clone(), עלינו שזו תהיה קריאת רכישה כדי לסנכרן עם הכתיבה שמגיעה מ-`is_unique`, כך שהאירועים שקדמו לכתיבה זו יתרחשו לפני קריאה זו.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // ודא שלא ניצור חלש משתלשל
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// מקבל את מספר מצביעי [`Weak`] להקצאה זו.
    ///
    /// # Safety
    ///
    /// שיטה זו כשלעצמה בטוחה, אך השימוש בה נכון מצריך טיפול נוסף.
    /// חוט אחר יכול לשנות את הספירה החלשה בכל עת, כולל פוטנציאל בין קריאה לשיטה זו לבין פעולה על פי התוצאה.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // קביעה זו היא דטרמיניסטית מכיוון שלא שיתפנו את ה-`Arc` או `Weak` בין השרשור.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // אם הספירה החלשה כרגע נעולה, ערך הספירה היה 0 רגע לפני שלוקחים את הנעילה.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// מקבל מספר מצביעי (`Arc`) חזקים להקצאה זו.
    ///
    /// # Safety
    ///
    /// שיטה זו כשלעצמה בטוחה, אך השימוש בה נכון מצריך טיפול נוסף.
    /// חוט אחר יכול לשנות את הספירה החזקה בכל עת, כולל פוטנציאל בין קריאה לשיטה זו לבין פעולה על פי התוצאה.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // קביעה זו היא דטרמיניסטית מכיוון שלא שיתפנו את ה-`Arc` בין האשכולות.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// מגדיל את ספירת ההתייחסות החזקה ב-`Arc<T>` המשויכת למצביע המסופק אחד.
    ///
    /// # Safety
    ///
    /// המצביע חייב להיות מושג דרך `Arc::into_raw`, ומופע ה-`Arc` המשויך חייב להיות תקף (כלומר
    /// הספירה החזקה חייבת להיות לפחות 1) למשך שיטה זו.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // קביעה זו היא דטרמיניסטית מכיוון שלא שיתפנו את ה-`Arc` בין האשכולות.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // שמור על Arc, אך אל תיגע בספירת החידושים על ידי גלישה ב-ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // עכשיו הגדל את ספירת העדכונים, אך אל תפיל גם את ספירת העדכונים החדשה
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// מקטין את ספירת ההתייחסות החזקה ב-`Arc<T>` המשויכת למצביע המסופק אחד.
    ///
    /// # Safety
    ///
    /// המצביע חייב להיות מושג דרך `Arc::into_raw`, ומופע ה-`Arc` המשויך חייב להיות תקף (כלומר
    /// הספירה החזקה חייבת להיות לפחות 1) בעת הפעלת שיטה זו.
    /// ניתן להשתמש בשיטה זו לשחרור אחסון ה-`Arc` והגיבוי הסופי, אך **אסור להתקשר** לאחר שחרור ה-`Arc` הסופי.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // קביעות אלה הן דטרמיניסטיות מכיוון שלא חלקנו את ה-`Arc` בין השרשור.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // חוסר הביטחון הזה הוא בסדר מכיוון שבזמן שקשת זו חיה מובטח לנו שהמצביע הפנימי תקף.
        // יתר על כן, אנו יודעים שמבנה ה-`ArcInner` עצמו הוא `Sync` מכיוון שהנתונים הפנימיים הם גם `Sync`, לכן אנו בסדר השאלת מצביע בלתי משתנה לתכנים אלה.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // חלק לא מוטבע של `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // השמד את הנתונים בשלב זה, למרות שאולי לא נשחרר את הקצאת התיבה עצמה (יתכן שעדיין יש מצביעים חלשים שמסתובבים).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // זרוק את השופט החלש המוחזק על ידי כל הפניות החזקות
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// מחזירה `true` אם שני הקשתות מצביעות על אותה הקצאה (בווריד הדומה ל-[`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// הקצאת `ArcInner<T>` עם מספיק מקום לערך פנימי שאולי לא מוגדל כאשר הערך מספק את הפריסה.
    ///
    /// הפונקציה `mem_to_arcinner` נקראת באמצעות מצביע הנתונים ועליה להחזיר מצביע (שעלול להיות שמן) עבור ה-`ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // חשב את הפריסה באמצעות פריסת הערך הנתונה.
        // בעבר, הפריסה חושבה על הביטוי `&*(ptr as* const ArcInner<T>)`, אך הדבר יצר הפניה שלא מיושרה (ראה #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// מקצה `ArcInner<T>` עם מספיק מקום לערך פנימי שאולי לא מוגדל בו הערך מספק הפריסה, ומחזיר שגיאה אם ההקצאה נכשלת.
    ///
    ///
    /// הפונקציה `mem_to_arcinner` נקראת באמצעות מצביע הנתונים ועליה להחזיר מצביע (שעלול להיות שמן) עבור ה-`ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // חשב את הפריסה באמצעות פריסת הערך הנתונה.
        // בעבר, הפריסה חושבה על הביטוי `&*(ptr as* const ArcInner<T>)`, אך הדבר יצר הפניה שלא מיושרה (ראה #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // אתחל את ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// הקצאת `ArcInner<T>` עם מספיק מקום לערך פנימי לא גדול.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // הקצה ל-`ArcInner<T>` באמצעות הערך הנתון.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // העתק ערך כבתים
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // שחררו את ההקצאה מבלי להפיל את תוכנה
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// מקצה `ArcInner<[T]>` באורך הנתון.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// העתק אלמנטים מפרוסה לקשת <\[T\]> שהוקצתה לאחרונה
    ///
    /// לא בטוח מפני שהמתקשר צריך לקחת בעלות או לאגד את `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// בונה `Arc<[T]>` מאיטרטור הידוע כגודל מסוים.
    ///
    /// ההתנהגות אינה מוגדרת במידה והגודל לא נכון.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // שומר Panic בזמן שיבוט אלמנטים T.
        // במקרה של panic, אלמנטים שנכתבו לתוך ArcInner החדש יושמטו ואז הזיכרון ישוחרר.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // מצביע לאלמנט ראשון
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // הכל ברור.תשכחו מהשומר כדי שלא ישחרר את ArcInner החדשה.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// התמחות trait המשמשת ל-`From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// עושה שיבוט של מצביע ה-`Arc`.
    ///
    /// זה יוצר מצביע נוסף לאותה הקצאה, ומגדיל את ספירת ההתייחסות החזקה.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // שימוש בסדר רגוע הוא בסדר כאן, מכיוון שידע על ההתייחסות המקורית מונע משרשורים אחרים למחוק את האובייקט בטעות.
        //
        // כפי שהוסבר ב-[Boost documentation][1], הגדלת מונה ההפניה יכולה להיעשות תמיד באמצעות memory_order_relaxed: הפניות חדשות לאובייקט יכולות להיווצר רק מתוך התייחסות קיימת, והעברת הפניה קיימת משרשור אחד למשנהו חייבת כבר לספק כל סנכרון נדרש.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // עם זאת עלינו להישמר מפני ספירות חוזרות מאסיביות למקרה שמישהו יזכר את הקשתות.
        // אם לא נעשה זאת הספירה יכולה לעלות על גדותיהם והמשתמשים ישתמשו בחינם.
        // אנו רוויים עד `isize::MAX` מתוך הנחה שאין ~2 מיליארד שרשורים שמגדילים את ספירת ההתייחסות בבת אחת.
        //
        // branch זה לעולם לא ייקח בשום תוכנית מציאותית.
        //
        // אנו מבטלים כי תוכנית כזו מנוונת להפליא, ולא אכפת לנו לתמוך בה.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// עושה הפניה משתנה ל-`Arc` הנתון.
    ///
    /// אם יש מצביעי `Arc` או [`Weak`] אחרים לאותה הקצאה, אז `make_mut` ייצור הקצאה חדשה ויקרין את [`clone`][clone] על הערך הפנימי כדי להבטיח בעלות ייחודית.
    /// זה מכונה גם שיבוט על כתיבה.
    ///
    /// שים לב שהדבר שונה מההתנהגות של [`Rc::make_mut`] המנתק את כל מצביעי `Weak` הנותרים.
    ///
    /// ראה גם [`get_mut`][get_mut], שייכשל במקום שיבוט.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // לא ישכפל שום דבר
    /// let mut other_data = Arc::clone(&data); // לא ישכפל נתונים פנימיים
    /// *Arc::make_mut(&mut data) += 1;         // משכפל נתונים פנימיים
    /// *Arc::make_mut(&mut data) += 1;         // לא ישכפל שום דבר
    /// *Arc::make_mut(&mut other_data) *= 2;   // לא ישכפל שום דבר
    ///
    /// // כעת `data` ו-`other_data` מצביעים על הקצאות שונות.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // שים לב שאנחנו מחזיקים גם התייחסות חזקה וגם התייחסות חלשה.
        // לפיכך, שחרור ההתייחסות החזקה שלנו בלבד לא, כשלעצמו, יגרום למיקום של הזיכרון.
        //
        // השתמש ב-Acquire כדי לוודא שנראה כתיבות ל-`weak` שקורות לפני שחרור כותב (כלומר, ירידות) ל-`strong`.
        // מכיוון שאנו מחזיקים בספירה חלשה, אין שום סיכוי שה ArcInner עצמו יוכל להיות מוקצה.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // מצביע חזק נוסף קיים, ולכן עלינו לשכפל.
            // הקצה זיכרון מראש כדי לאפשר כתיבת הערך המשובט ישירות.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // רגוע מספיק באמור לעיל מכיוון שזו ביסודו אופטימיזציה: אנחנו תמיד דוהרים עם מצביעים חלשים שנשמטים.
            // במקרה הגרוע ביותר, בסופו של דבר הקצנו קשת חדשה ללא צורך.
            //

            // הסרנו את השופט החזק האחרון, אך נותרו שופטים חלשים נוספים.
            // נעביר את התוכן לקשת חדשה ונבטל את שאר השופטים החלשים.
            //

            // שים לב שלא ייתכן שקריאת `weak` תניב usize::MAX (כלומר נעולה), מכיוון שהספירה החלשה ניתנת לנעילה רק על ידי חוט עם התייחסות חזקה.
            //
            //

            // התממשו את המצביע החלש המרומז שלנו, כך שהוא יוכל לנקות את ArcInner לפי הצורך.
            //
            let _weak = Weak { ptr: this.ptr };

            // יכול פשוט לגנוב את הנתונים, כל שנותר הוא חלשות
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // היינו הייחוס היחיד מכל סוג שהוא;להקפיץ את ספירת השופטים החזקה.
            //
            this.inner().strong.store(1, Release);
        }

        // כמו ב-`get_mut()`, אי הבטיחות היא בסדר מכיוון שההתייחסות שלנו הייתה ייחודית מלכתחילה, או שהפכה להיות אחת לאחר שיבוט התוכן.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// מחזירה הפניה משתנה ל-`Arc` הנתון, אם אין מצביעי `Arc` או [`Weak`] אחרים לאותה הקצאה.
    ///
    ///
    /// מחזירה [`None`] אחרת, מכיוון שלא בטוח לשנות את הערך המשותף.
    ///
    /// ראה גם [`make_mut`][make_mut], שיהיה [`clone`][clone] לערך הפנימי כשיש מצביעים אחרים.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // חוסר בטיחות זה בסדר מכיוון שמובטח לנו שהמצביע שהוחזר הוא המצביע *היחיד* שיוחזר אי פעם לט '.
            // מספר הפניות שלנו מובטח שיהיה 1 בנקודה זו, ואנחנו דרשנו שהקשת עצמה תהיה `mut`, ולכן אנו מחזירים את ההתייחסות האפשרית היחידה לנתונים הפנימיים.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// מחזירה הפניה משתנה ל-`Arc` הנתון, ללא כל בדיקה.
    ///
    /// ראה גם [`get_mut`], שהוא בטוח ועושה בדיקות מתאימות.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// אסור להפנות כל מצביע `Arc` או [`Weak`] לאותה הקצאה למשך ההשאלה שהוחזרה.
    ///
    /// זה המקרה של מה בכך אם אין מצביעים כאלה, למשל מיד לאחר `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // אנו מקפידים *לא* ליצור הפניה המכסה את שדות ה-"count", מכיוון שזה יהיה כינוי עם גישה במקביל לספירות הייחוס (למשל
        // על ידי `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// קבע אם זו ההתייחסות הייחודית (כולל התייחסויות חלשות) לנתונים הבסיסיים.
    ///
    ///
    /// שים לב שהדבר מחייב נעילה של ספירת השופטים החלשה.
    fn is_unique(&mut self) -> bool {
        // נעל את ספירת המצביעים החלשה אם נראה שאנחנו המחזיקים במצביע החלש היחיד.
        //
        // תווית הרכישה כאן מבטיחה קשר שקורה לפני כל כתיבה ל-`strong` (בפרט ב-`Weak::upgrade`) לפני ירידות בספירת `weak` (באמצעות `Weak::drop`, המשתמשת בשחרור).
        // אם השופט החלש המשודרג מעולם לא ירד, ה-CAS כאן ייכשל ולכן לא אכפת לנו לסנכרן.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // זה צריך להיות `Acquire` כדי לסנכרן עם הפחתת מונה `strong` ב-`drop`-הגישה היחידה שקורה כאשר כל אחד מלבד ההפניה האחרונים מוחלש.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // כתיבת השחרור כאן מסונכרנת עם קריאה ב-`downgrade`, ובכך מונעת מהקריאה של `strong` לעיל לאחר הכתיבה.
            //
            //
            self.inner().weak.store(1, Release); // שחרר את המנעול
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// מוריד את ה-`Arc`.
    ///
    /// זה יקטין את ספירת ההתייחסות החזקה.
    /// אם ספירת הייחוס החזקה מגיעה לאפס אזי ההפניות היחידות האחרות (אם קיימות) הן [`Weak`], לכן אנו `drop` הערך הפנימי.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // לא מדפיס שום דבר
    /// drop(foo2);   // מדפיס "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // מכיוון ש-`fetch_sub` כבר אטומי, איננו צריכים לסנכרן עם שרשורים אחרים אלא אם כן אנו הולכים למחוק את האובייקט.
        // אותו היגיון חל על `fetch_sub` להלן לספירת `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // גדר זו נחוצה על מנת למנוע סדר מחדש של השימוש בנתונים ומחיקת הנתונים.
        // מכיוון שהוא מסומן `Release`, הירידה בספירת הייחוס מסונכרנת עם גדר `Acquire` זו.
        // המשמעות היא שהשימוש בנתונים מתרחש לפני הפחתת ספירת ההתייחסות, שקורה לפני גדר זו, מה שקורה לפני מחיקת הנתונים.
        //
        // כפי שהוסבר ב-[Boost documentation][1],
        //
        // > חשוב לאכוף כל גישה אפשרית לאובייקט באחד
        // > שרשור (דרך הפניה קיימת) כדי *לקרות לפני* מחיקה
        // > האובייקט בשרשור אחר.זה מושג על ידי "release"
        // > פעולה לאחר הפלת הפניה (כל גישה לאובייקט
        // > דרך התייחסות זו כמובן חייב לקרות לפני כן), ו-
        // > "acquire" פעולה לפני מחיקת האובייקט.
        //
        // בפרט, בעוד שתוכן של קשת בדרך כלל אינו ניתן לשינוי, אפשר לקבל כתבות פנים למשהו כמו Mutex<T>.
        // מכיוון ש-Mutex אינו נרכש כאשר הוא נמחק, איננו יכולים להסתמך על לוגיקת הסנכרון שלו כדי להפוך את הכיתוב בשרשור A לגלוי להרס הפועל בחוט B.
        //
        //
        // שים לב גם כי ניתן להחליף את גדר ה-Acquire כאן כנראה בעומס Acquire, מה שיכול לשפר את הביצועים במצבים מתמודדים מאוד.ראה [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// ניסיון להוריד את ה-`Arc<dyn Any + Send + Sync>` לסוג קונקרטי.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// בונה `Weak<T>` חדש, מבלי להקצות זיכרון כלשהו.
    /// קריאה ל-[`upgrade`] על ערך ההחזרה נותנת תמיד את [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// סוג עוזר המאפשר גישה לספירות הפניה מבלי להעלות טענות לגבי שדה הנתונים.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// מחזיר מצביע גולמי לאובייקט `T` אליו הצביע `Weak<T>`.
    ///
    /// המצביע תקף רק אם יש כמה הפניות חזקות.
    /// המצביע עשוי להיות תלוי, לא מיושר או אפילו [`null`] אחרת.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // שניהם מצביעים על אותו אובייקט
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // החזק כאן מחזיק אותו בחיים, כך שאנחנו עדיין יכולים לגשת לאובייקט.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // אבל לא עוד.
    /// // אנחנו יכולים לעשות weak.as_ptr(), אך גישה למצביע תוביל להתנהגות לא מוגדרת.
    /// // assert_eq! ("שלום", לא בטוח {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // אם המצביע משתלשל, אנו מחזירים את הזקיף ישירות.
            // זו לא יכולה להיות כתובת מטען חוקית, מכיוון שהמטען מיושר לפחות כמו ArcInner (usize).
            ptr as *const T
        } else {
            // בטיחות: אם is_dangling מחזיר שקר, אז המצביע ניתן להפניה.
            // העומס עשוי להישמט בשלב זה, ועלינו לשמור על מקור, לכן השתמש במניפולציה של מצביעים גולמיים.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// צורכת את ה-`Weak<T>` והופכת אותו למצביע גולמי.
    ///
    /// זה ממיר את המצביע החלש למצביע גולמי, תוך שמירה על הבעלות על התייחסות חלשה אחת (הספירה החלשה לא משתנה על ידי פעולה זו).
    /// ניתן להחזיר אותו ל-`Weak<T>` עם [`from_raw`].
    ///
    /// אותן מגבלות לגבי הגישה ליעד של המצביע כמו ב-[`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// ממיר מצביע גולמי שנוצר בעבר על ידי [`into_raw`] בחזרה ל-`Weak<T>`.
    ///
    /// זה יכול לשמש בכדי לקבל בבטחה התייחסות חזקה (על ידי התקשרות ל-[`upgrade`] מאוחר יותר) או כדי להתמקם בספירה החלשה על ידי הפלת ה-`Weak<T>`.
    ///
    /// זה לוקח בעלות על התייחסות חלשה אחת (למעט מצביעים שנוצרו על ידי [`new`], מכיוון שאלה לא מחזיקים בשום דבר; השיטה עדיין עובדת עליהם).
    ///
    /// # Safety
    ///
    /// המצביע בוודאי מקורו ב-[`into_raw`] ועליו להחזיק בהתייחסות החלשה הפוטנציאלית שלו.
    ///
    /// מותר שהספירה החזקה תהיה 0 בזמן הקריאה לכך.
    /// עם זאת, זה לוקח בעלות על התייחסות חלשה אחת המיוצגת כרגע כמצביע גולמי (הספירה החלשה לא משתנה על ידי פעולה זו) ולכן יש להתאים אותה עם שיחה קודמת ל-[`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // דחה את הספירה החלשה האחרונה.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ראה Weak::as_ptr לקבלת הקשר כיצד נגזר מצביע הקלט.

        let ptr = if is_dangling(ptr as *mut T) {
            // זהו חלש משתלשל.
            ptr as *mut ArcInner<T>
        } else {
            // אחרת, מובטח לנו שהמצביע הגיע מחולשה לא משתלשלת.
            // בטיחות: data_offset בטוח להתקשר אליו, מכיוון ש-ptr מתייחס לט 'אמיתי (שעלול להישמט).
            let offset = unsafe { data_offset(ptr) };
            // לפיכך, אנו הופכים את הקיזוז כדי לקבל את כל ה-RcBox.
            // בטיחות: מקור המצביע הוא חלש, ולכן הקיזוז הזה בטוח.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // בטיחות: כעת התאוששנו המצביע החלש המקורי, כך שנוכל ליצור את החלש.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// מנסה לשדרג את מצביע ה-`Weak` ל-[`Arc`], לעכב את צניחת הערך הפנימי אם יצליח.
    ///
    ///
    /// מחזירה את [`None`] אם הערך הפנימי ירד מאז.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // השמד את כל המצביעים החזקים.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // אנו משתמשים בלולאת CAS כדי להגדיל את הספירה החזקה במקום fetch_add מכיוון שפונקציה זו לעולם לא צריכה לקחת את ספירת ההתייחסות מאפס לאחת.
        //
        //
        let inner = self.inner()?;

        // עומס רגוע מכיוון שכל כתיבה של 0 שנוכל לצפות בה משאירה את השדה במצב אפס קבוע (כך שקריאה של "stale" של 0 היא בסדר), וכל ערך אחר אושר באמצעות ה-CAS שלמטה.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // ראה הערות ב-`Arc::clone` מדוע אנו עושים זאת (עבור `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // רגוע הוא בסדר במקרה של הכישלון כיוון שאין לנו שום ציפיות למדינה החדשה.
            // רכישה נחוצה כדי שמקרה ההצלחה יסתנכרן עם `Arc::new_cyclic`, כאשר ניתן לאתחל את הערך הפנימי לאחר שכבר נוצרו הפניות `Weak`.
            // במקרה כזה, אנו מצפים להתבונן בערך המאתחל לחלוטין.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // אפס מסומן לעיל
                Err(old) => n = old,
            }
        }
    }

    /// מקבל מספר מצביעי (`Arc`) חזקים המצביעים על הקצאה זו.
    ///
    /// אם `self` נוצר באמצעות [`Weak::new`], זה יחזיר 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// מקבל הערכה למספר מצביעי `Weak` המצביעים על הקצאה זו.
    ///
    /// אם `self` נוצר באמצעות [`Weak::new`], או אם אין מצביעים חזקים שנותרו, זה יחזיר 0.
    ///
    /// # Accuracy
    ///
    /// בשל פרטי היישום, הערך המוחזר יכול להיות מושבת ב-1 לשני הכיוונים כאשר חוטים אחרים מבצעים מניפולציה על כל 'קשת' או 'חלשה' המצביעים על אותה הקצאה.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // מכיוון שצפינו שיש לפחות מצביע חזק אחד לאחר קריאת הספירה החלשה, אנו יודעים שההתייחסות החלשה הגלומה (קיימת בכל התייחסות חזקה כלשהי בחיים) הייתה עדיין בסביבה כאשר צפינו בספירה החלשה, ולכן אנו יכולים להפחית אותה בבטחה.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// מחזירה את `None` כאשר המצביע משתלשל ואין `ArcInner` שהוקצה, (כלומר כאשר `Weak` זה נוצר על ידי `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // אנו מקפידים *לא* ליצור התייחסות המכסה את שדה "data", מכיוון שהשדה עשוי להיות מוטציה במקביל (למשל, אם ה-`Arc` האחרון יושמט, שדה הנתונים יושמט במקום).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// מחזירה `true` אם שני ה'חלשים 'מצביעים על אותה הקצאה (בדומה ל-[`ptr::eq`]), או אם שניהם אינם מצביעים על הקצאה כלשהי (מכיוון שהם נוצרו עם `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// מכיוון שזה משווה בין מצביעים זה אומר ש-`Weak::new()` ישווה זה לזה, למרות שהם לא מצביעים על הקצאה כלשהי.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// השוואת `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// עושה שיבוט של מצביע ה-`Weak` המצביע על אותה הקצאה.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // ראה הערות ב-Arc::clone() מדוע זה רגוע.
        // זה יכול להשתמש ב-fetch_add (התעלמות מהנעילה) מכיוון שהספירה החלשה נעולה רק במקום בו אין *מצביעים חלשים אחרים*.
        //
        // (כך שאיננו יכולים להפעיל את הקוד הזה במקרה זה).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // ראה הערות ב-Arc::clone() מדוע אנו עושים זאת (עבור mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// בונה `Weak<T>` חדש, ללא הקצאת זיכרון.
    /// קריאה ל-[`upgrade`] על ערך ההחזרה נותנת תמיד את [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// מפיל את מצביע ה-`Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // לא מדפיס שום דבר
    /// drop(foo);        // מדפיס "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // אם נגלה שהיינו המצביע החלש האחרון, אז הגיע הזמן לאתר את הנתונים לחלוטין.ראה את הדיון ב-Arc::drop() אודות סדרי הזיכרון
        //
        // אין צורך לבדוק את המצב הנעול כאן, מכיוון שניתן לנעול את הספירה החלשה רק אם היה בדיוק שופט חלש אחד, כלומר ירידה יכולה להפעיל רק לאחר מכן את אותו נציג חלש שנותר, מה שיכול לקרות רק לאחר שחרור הנעילה.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// אנו מבצעים את ההתמחות הזו כאן ולא כביצוע אופטימיזציה כללית יותר ב-`&T`, מכיוון שאחרת זה יוסיף עלות לכל בדיקת השוויון של שופטים.
/// אנו מניחים ש'קשתות 'משמשות לאחסון ערכים גדולים, איטיים לשיבוט, אך גם כבדים לבדיקת שוויון, מה שגורם לעלות זו להשתלם ביתר קלות.
///
/// כמו כן, סביר יותר שיהיו שני שיבוטים `Arc`, המצביעים על אותו ערך, מאשר שני `&T`.
///
/// אנו יכולים לעשות זאת רק כאשר `T: Eq` כ-`PartialEq` עשוי להיות לא רפלקסיבי בכוונה.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// שוויון לשני 'קשתות'.
    ///
    /// שני 'קשתות' שוות אם הערכים הפנימיים שלהם שווים, גם אם הם מאוחסנים בהקצאה שונה.
    ///
    /// אם `T` מיישם גם את `Eq` (מרמז על רפלקסיביות של שוויון), שני 'קשתות' המצביעות על אותה הקצאה תמיד שוות.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// אי-שוויון בשני `קשתות '.
    ///
    /// שני 'קשתות' אינן שוות אם הערכים הפנימיים שלהם אינם שווים.
    ///
    /// אם `T` מיישם גם את `Eq` (מרמז על רפלקסיביות של שוויון), שני 'קשתות' שמצביעות על אותו ערך אינן שוות.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// השוואה חלקית לשני `קשתות '.
    ///
    /// השניים מושווים באמצעות קריאה ל-`partial_cmp()` על הערכים הפנימיים שלהם.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// פחות מהשוואה לשני Arc's.
    ///
    /// השניים מושווים באמצעות קריאה ל-`<` על הערכים הפנימיים שלהם.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'פחות או שווה' להשוואה לשני 'קשתות'.
    ///
    /// השניים מושווים באמצעות קריאה ל-`<=` על הערכים הפנימיים שלהם.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// השוואה גדולה יותר משני שני קשתות.
    ///
    /// השניים מושווים באמצעות קריאה ל-`>` על הערכים הפנימיים שלהם.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// השוואה 'גדולה או שווה יותר לשני' קשתות.
    ///
    /// השניים מושווים באמצעות קריאה ל-`>=` על הערכים הפנימיים שלהם.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// השוואה לשני `Arc`s.
    ///
    /// השניים מושווים באמצעות קריאה ל-`cmp()` על הערכים הפנימיים שלהם.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// יוצר `Arc<T>` חדש, עם ערך `Default` עבור `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// הקצה פרוסה שסופרה הפניה ומלא אותה על ידי שיבוט פריטי 'v'.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// הקצה `str` שנספר בהתייחסו והעתק לתוכו את `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// הקצה `str` שנספר בהתייחסו והעתק לתוכו את `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// העבר אובייקט מוסגר להקצאה חדשה ומספרת הפניה.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// הקצה פרוסה שנספרה והעבור לתוכה פריטי 'v'.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // אפשר ל-Vec לשחרר את זיכרונו, אך לא להרוס את תוכנו
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// לוקח כל אלמנט ב-`Iterator` ואוסף אותו ל-`Arc<[T]>`.
    ///
    /// # מאפייני ביצועים
    ///
    /// ## המקרה הכללי
    ///
    /// במקרה הכללי, איסוף ל-`Arc<[T]>` נעשה על ידי איסוף ראשון ל-`Vec<T>`.כלומר, בעת כתיבת הדברים הבאים:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// זה מתנהג כאילו כתבנו:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // סט ההקצאות הראשון קורה כאן.
    ///     .into(); // הקצאה שנייה ל-`Arc<[T]>` מתרחשת כאן.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// זה יוקצה פעמים רבות ככל שיידרש לבניית ה-`Vec<T>` ואז יוקצה פעם אחת להפיכת ה-`Vec<T>` ל-`Arc<[T]>`.
    ///
    ///
    /// ## מחטאים באורך ידוע
    ///
    /// כאשר ה-`Iterator` שלך מיישם את `TrustedLen` והוא בגודל מדויק, תתבצע הקצאה אחת ל-`Arc<[T]>`.לדוגמה:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // רק הקצאה אחת מתרחשת כאן.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// התמחות trait המשמשת לאיסוף ל-`Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // זה המקרה של איטרטור `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // בטיחות: עלינו להבטיח שאיטרטור יהיה באורך מדויק ויש לנו.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // חזור ליישום רגיל.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// קבל את הקיזוז בתוך `ArcInner` עבור המטען שמאחורי מצביע.
///
/// # Safety
///
/// על המצביע להצביע על (ויש לו מטא-נתונים תקפים עבור) מופע חוקי קודם של T, אך מותר להוריד את ה-T.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // יישר את הערך הלא ממדים לסוף ArcInner.
    // מכיוון ש-RcBox הוא repr(C), זה תמיד יהיה השדה האחרון בזיכרון.
    // בטיחות: מכיוון שהסוגים היחידים שאינם גדולים הם פרוסות, אובייקטים trait,
    // וסוגים חיצוניים, דרישת הבטיחות של הקלט מספיקה כרגע כדי לספק את הדרישות של align_of_val_raw;זהו פרט יישום של השפה שלא ניתן להסתמך עליה מחוץ ל-std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}