//! יישום Rust panics באמצעות הפסקת תהליך
//!
//! בהשוואה ליישום באמצעות פריקה, crate זה הרבה יותר פשוט!עם זאת, זה לא ממש תכליתי, אבל הנה הולך!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" את המטען והשימוש להפסקת הרלוונטיות בפלטפורמה המדוברת.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // התקשר ל-std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // ב-Windows השתמש במנגנון __fastfail הספציפי למעבד.ב-Windows 8 ואילך, פעולה זו תסיים את התהליך באופן מיידי מבלי להפעיל מטפלים חריגים בתהליך.
            // בגירסאות קודמות של Windows, רצף זה של הוראות יטופל כהפרת גישה, תוך סיום התהליך אך מבלי לעקוף בהכרח את כל מטפלי החריגים.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: זהו אותו יישום כמו ב-`abort_internal` של libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// זה ... זה קצת מוזר.ה-tl; dr;זה שנדרש לקישור נכון, ההסבר הארוך יותר להלן.
//
// כרגע הבינאריות של libcore/libstd שאנו שולחים כולן נערכות עם `-C panic=unwind`.זה נעשה כדי להבטיח שהבינאריות תואמות באופן מקסימלי לכמה שיותר מצבים.
// אולם המהדר דורש "personality function" עבור כל הפונקציות שמורכבות עם `-C panic=unwind`.פונקציית אישיות זו מקודדת לסמל `rust_eh_personality` ומוגדרת על ידי פריט ה-`eh_personality` lang.
//
// So...
// מדוע לא פשוט להגדיר את פריט הלנג כאן?שאלה טובה!האופן שבו מקושרים זמן זמני panic הוא עדין מעט בכך שהם "sort of" בחנות crate של המהדר, אך רק מקושרים אם אחר אינו מקושר בפועל.
//
// בסופו של דבר המשמעות היא שגם crate וגם ה-panic_unwind crate יכולים להופיע בחנות crate של המהדר, ואם שניהם מגדירים את פריט `eh_personality` lang אז זה יפגע בשגיאה.
//
// כדי להתמודד עם זה, המהדר דורש שהגדרת `eh_personality` מוגדרת רק אם זמן הריצה panic שמקושר אליו הוא זמן הריצה המונע, ואחרת זה לא נדרש להגדרה (בצדק).
// אולם במקרה זה, הספרייה הזו מגדירה סמל זה כך שיש איפשהו לפחות אישיות כלשהי.
//
// בעיקרו של דבר, סמל זה מוגדר רק כדי לחבר את הבינאריות של libcore/libstd, אך לעולם אסור לקרוא לו מכיוון שאיננו מקשרים כלל בזמן ריצה מתפתל.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // ב-x86_64-pc-windows-gnu אנו משתמשים בפונקציית האישיות שלנו שצריכה להחזיר את `ExceptionContinueSearch` כאשר אנו מעבירים את כל המסגרות שלנו.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // בדומה לעיל, זה תואם לפריט `eh_catch_typeinfo` lang המשמש רק ב-Emscripten כרגע.
    //
    // מכיוון ש-panics לא מייצרים חריגים ויוצאים מן הכלל חריגים זרים כרגע UB עם -C panic=בוטל (אם כי זה עשוי להיות כפוף לשינוי), כל שיחות catch_unwind לעולם לא ישתמשו בסוג זה.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // שני אלה נקראים על ידי אובייקטי ההפעלה שלנו ב-i686-pc-windows-gnu, אך הם לא צריכים לעשות שום דבר ולכן הגופים הם טיפשים.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}