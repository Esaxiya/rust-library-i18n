use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // מירי איטית מדי
fn exact_sanity_test() {
    // בסופו של דבר מבחן זה מריץ את מה שאני יכול להניח רק שהוא מקרה פינתי כלשהו של פונקציית הספרייה `exp2`, המוגדרת בכל זמן ריצה C שבו אנו משתמשים.
    // ב-VS 2013 לפונקציה זו כנראה היה באג מכיוון שבדיקה זו נכשלת כאשר היא מקושרת, אך עם VS 2015 הבאג נראה קבוע שכן הבדיקה פועלת בסדר גמור.
    //
    // נראה כי הבאג הוא הבדל בערך ההחזר של `exp2(-1057)`, כאשר ב-VS 2013 הוא מחזיר כפול עם תבנית הסיביות 0x2 וב-VS 2015 הוא מחזיר את 0x20000.
    //
    //
    // לעת עתה פשוט התעלם מבדיקה זו לחלוטין ב-MSVC מכיוון שהיא נבדקת בכל מקום אחר ואנחנו לא מעוניינים במיוחד לבדוק את יישום ה-exp2 של כל פלטפורמה.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}