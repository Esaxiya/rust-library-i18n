use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // זה לא שטח פנים יציב, אבל עוזר לשמור על `?` זול ביניהם, גם אם LLVM לא תמיד יכול לנצל אותו כרגע.
    //
    // (למרבה הצער התוצאה והאופציה אינן עקביות, כך ש-ControlFlow לא יכול להתאים לשניהם).

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}