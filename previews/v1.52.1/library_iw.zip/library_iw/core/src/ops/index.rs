/// משמש לאינדקס פעולות (`container[index]`) בהקשרים בלתי ניתנים לשינוי.
///
/// `container[index]` הוא למעשה סוכר תחבירי ל-`*container.index(index)`, אך רק כאשר משתמשים בו כערך בלתי משתנה.
/// אם מבקשים ערך משתנה, משתמשים במקום זאת ב-[`IndexMut`].
/// זה מאפשר דברים נחמדים כגון `let value = v[index]` אם סוג ה-`value` מיישם את [`Copy`].
///
/// # Examples
///
/// הדוגמה הבאה מיישמת את `Index` על מיכל `NucleotideCount` לקריאה בלבד, ומאפשר לאחזר ספירות בודדות באמצעות תחביר אינדקס.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// הסוג שהוחזר לאחר הוספה לאינדקס.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// מבצע את פעולת האינדקס (`container[index]`).
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// משמש לאינדקס פעולות (`container[index]`) בהקשרים משתנים.
///
/// `container[index]` הוא למעשה סוכר תחבירי ל-`*container.index_mut(index)`, אך רק כאשר משתמשים בו כערך משתנה.
/// אם מבקשים ערך בלתי משתנה, במקום זאת נעשה שימוש ב-[`Index`] trait.
/// זה מאפשר דברים נחמדים כמו `v[index] = value`.
///
/// # Examples
///
/// יישום פשוט מאוד של מבנה `Balance` בעל שני צדדים, כאשר כל אחד מהם יכול להתווסף באופן משתנה וללא שינוי.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // במקרה זה, `balance[Side::Right]` הוא סוכר עבור `*balance.index(Side::Right)`, מכיוון שאנחנו רק* קוראים * `balance[Side::Right]`, ולא כותבים אותו.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // עם זאת, במקרה זה `balance[Side::Left]` הוא סוכר עבור `*balance.index_mut(Side::Left)`, מכיוון שאנחנו כותבים `balance[Side::Left]`.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// מבצע פעולת (`container[index]`) המופעלת לאינדקס.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}