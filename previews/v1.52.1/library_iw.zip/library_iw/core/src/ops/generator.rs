use crate::marker::Unpin;
use crate::pin::Pin;

/// תוצאה של חידוש גנרטור.
///
/// אנום זה מוחזר משיטת `Generator::resume` ומציין את ערכי ההחזרה האפשריים של גנרטור.
/// נכון לעכשיו זה מתאים לנקודת השעיה (`Yielded`) או לנקודת סיום (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// הגנרטור הושעה עם ערך.
    ///
    /// מצב זה מציין כי גנרטור הושעה, ומתאים בדרך כלל להצהרת `yield`.
    /// הערך המסופק בגרסה זו תואם את הביטוי המועבר ל-`yield` ומאפשר לגנרטורים לספק ערך בכל פעם שהם מניבים.
    ///
    ///
    Yielded(Y),

    /// הגנרטור הושלם עם ערך החזר.
    ///
    /// מצב זה מציין שגנרטור סיים את הביצוע עם הערך המסופק.
    /// לאחר שהגנרטור החזיר את `Complete` זה נחשב לשגיאת מתכנת להתקשר שוב ל-`resume`.
    ///
    Complete(R),
}

/// ה-trait מיושם על ידי סוגי גנרטורים מובנים.
///
/// גנרטורים, המכונים בדרך כלל קורוטינים, הם כיום תכונת שפה ניסיונית ב-Rust.
/// גנרטורים של [RFC 2033] שנוספו כרגע מיועדים לספק בעיקר אבן בניין לתחביר async/await, אך ככל הנראה יתרחבו גם למתן הגדרה ארגונומית לאיטרטורים ופרימיטיביים אחרים.
///
///
/// התחביר והסמנטיקה לגנרטורים אינם יציבים ודורשים RFC נוסף לייצוב.אולם בשלב זה התחביר דומה לסגירה:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// תיעוד נוסף של גנרטורים ניתן למצוא בספר הלא יציב.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// סוג הערך שמניב הגנרטור.
    ///
    /// סוג משויך זה תואם את הביטוי `yield` ואת הערכים שמותר להחזיר בכל פעם שמניב גנרטור.
    ///
    /// לדוגמא איטרטור-כמחולל סביר להניח שיהיה לו סוג זה כ-`T`, הסוג שעוברים איטרציה.
    ///
    type Yield;

    /// סוג הערך שהמחולל מחזיר.
    ///
    /// זה תואם את הסוג שהוחזר מגנרטור עם משפט `return` או באופן משתמע כביטוי האחרון של מילולית גנרטור.
    /// לדוגמא futures ישתמש בזה כ-`Result<T, E>` מכיוון שהוא מייצג future.
    ///
    ///
    type Return;

    /// ממשיך לבצע את ביצוע הגנרטור הזה.
    ///
    /// פונקציה זו תחדש את ביצוע הגנרטור או תחיל את ביצועו אם טרם עשה זאת.
    /// שיחה זו תחזור לנקודת ההשעיה האחרונה של הגנרטור, ותתחדש לביצוע מה-`yield` האחרונה.
    /// הגנרטור ימשיך לבצע עד שהוא יניב או יחזור, ובנקודה זו פונקציה זו תחזור.
    ///
    /// # ערך החזרה
    ///
    /// ה-`GeneratorState` האנומר המוחזר מפונקציה זו מציין באיזה מצב נמצא הגנרטור עם חזרתו.
    /// אם מחזירים את גרסת ה-`Yielded` אז הגנרטור הגיע לנקודת השעיה והוחלף ערך.
    /// גנרטורים במצב זה זמינים לחידוש בשלב מאוחר יותר.
    ///
    /// אם `Complete` מוחזר אז הגנרטור סיים לחלוטין עם הערך שסופק.אין זה חוקי לחדש את הגנרטור.
    ///
    /// # Panics
    ///
    /// פונקציה זו עשויה panic אם היא נקראת לאחר שהוחזרה גרסת `Complete` בעבר.
    /// בעוד שמילולי הגנרטור בשפה מובטחים ל-panic בחידושם לאחר `Complete`, זה לא מובטח לכל היישומים של ה-`Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}