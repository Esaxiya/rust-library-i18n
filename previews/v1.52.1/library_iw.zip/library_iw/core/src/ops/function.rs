/// הגרסה של מפעיל השיחה שלוקח מקלט בלתי משתנה.
///
/// ניתן לקרוא למופעים של `Fn` שוב ושוב ללא שינוי במצב.
///
/// *אין להתבלבל בין trait (`Fn`) לבין [function pointers] (`fn`).*
///
/// `Fn` מיושם באופן אוטומטי על ידי סגירות שלוקחות רק הפניות בלתי משתנות למשתנים שנתפסו או שאינן לוכדות שום דבר, כמו גם (safe) [function pointers] (עם כמה אזהרות, עיין בתיעוד שלהם לפרטים נוספים).
///
/// בנוסף, עבור כל סוג `F` שמיישם את `Fn`, `&F` מיישם גם את `Fn`.
///
/// מכיוון שגם [`FnMut`] וגם [`FnOnce`] הם מסלולי על של `Fn`, ניתן להשתמש בכל מופע של `Fn` כפרמטר שבו צפוי [`FnMut`] או [`FnOnce`].
///
/// השתמש ב-`Fn` כגבול כאשר ברצונך לקבל פרמטר מסוג דמוי פונקציה וצריך להתקשר אליו שוב ושוב וללא מצב מוטציה (למשל, בעת קריאה אליו במקביל).
/// אם אינך זקוק לדרישות כה קפדניות, השתמש בגבול [`FnMut`] או [`FnOnce`].
///
/// עיין ב-[chapter on closures in *The Rust Programming Language*][book] לקבלת מידע נוסף בנושא זה.
///
/// יש לציין גם את התחביר המיוחד עבור `Fn` traits (למשל
/// `Fn(usize, bool) -> השתמש בגודל ').מי שמעוניין בפרטים הטכניים של זה יכול להתייחס ל-[the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## קורא לסגירה
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## באמצעות פרמטר `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // כך ש-regex יכול לסמוך על ה-`&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// מבצע את פעולת השיחה.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// הגרסה של מפעיל השיחה שלוקח מקלט משתנה.
///
/// ניתן לקרוא למופעים של `FnMut` שוב ושוב ועשויים להשתנות במצב.
///
/// `FnMut` מיושם אוטומטית על ידי סגירות שלוקחות הפניות משתנות למשתנים שנתפסו, כמו גם כל הסוגים המיישמים את [`Fn`], למשל, (safe) [function pointers] (מכיוון ש-`FnMut` הוא משטח-על של [`Fn`]).
/// בנוסף, עבור כל סוג `F` שמיישם את `FnMut`, `&mut F` מיישם גם את `FnMut`.
///
/// מכיוון ש-[`FnOnce`] הוא תחום-על של `FnMut`, ניתן להשתמש בכל מופע של `FnMut` במקום בו צפוי [`FnOnce`], ומכיוון ש-[`Fn`] הוא תת-קטע של `FnMut`, ניתן להשתמש בכל מופע של [`Fn`] במקום בו צפוי `FnMut`.
///
/// השתמש ב-`FnMut` כגבול כאשר ברצונך לקבל פרמטר מסוג דמוי פונקציה וצריך להתקשר אליו שוב ושוב, תוך מתן אפשרות לשנות את המצב.
/// אם אינך רוצה שהפרמטר ישתנה מצב, השתמש ב-[`Fn`] כגבול;אם אינך צריך להתקשר אליו שוב ושוב, השתמש ב-[`FnOnce`].
///
/// עיין ב-[chapter on closures in *The Rust Programming Language*][book] לקבלת מידע נוסף בנושא זה.
///
/// יש לציין גם את התחביר המיוחד עבור `Fn` traits (למשל
/// `Fn(usize, bool) -> השתמש בגודל ').מי שמעוניין בפרטים הטכניים של זה יכול להתייחס ל-[the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## קורא לסגר לוכד באופן משתנה
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## באמצעות פרמטר `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // כך ש-regex יכול לסמוך על ה-`&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// מבצע את פעולת השיחה.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// הגרסה של מפעיל השיחה שלוקח מקלט ערך.
///
/// ניתן להתקשר למופעים של `FnOnce`, אך ייתכן שלא ניתן יהיה להתקשר אליהם מספר פעמים.מסיבה זו, אם הדבר היחיד הידוע בסוג הוא שהוא מיישם את `FnOnce`, ניתן להתקשר אליו רק פעם אחת.
///
/// `FnOnce` מיושם אוטומטית על ידי סגירות העשויות לצרוך משתנים שנתפסו, כמו גם כל הסוגים המיישמים את [`FnMut`], למשל, (safe) [function pointers] (מכיוון ש-`FnOnce` הוא משטח-על של [`FnMut`]).
///
///
/// מכיוון שגם [`Fn`] וגם [`FnMut`] הם תת-תכנות של `FnOnce`, ניתן להשתמש בכל מופע של [`Fn`] או [`FnMut`] במקום בו צפוי `FnOnce`.
///
/// השתמש ב-`FnOnce` כגבול כאשר ברצונך לקבל פרמטר מסוג דמוי פונקציה וצריך להתקשר אליו רק פעם אחת.
/// אם אתה צריך להתקשר לפרמטר שוב ושוב, השתמש ב-[`FnMut`] כגבול;אם אתה גם צריך את זה כדי לא לשנות את המצב, השתמש ב-[`Fn`].
///
/// עיין ב-[chapter on closures in *The Rust Programming Language*][book] לקבלת מידע נוסף בנושא זה.
///
/// יש לציין גם את התחביר המיוחד עבור `Fn` traits (למשל
/// `Fn(usize, bool) -> השתמש בגודל ').מי שמעוניין בפרטים הטכניים של זה יכול להתייחס ל-[the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## באמצעות פרמטר `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` צורכת את המשתנים שנתפסו, כך שאי אפשר להריץ אותה יותר מפעם אחת.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // ניסיון להפעיל את `func()` שוב יזרוק שגיאת `use of moved value` עבור `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` לא ניתן להפעיל עוד בשלב זה
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // כך ש-regex יכול לסמוך על ה-`&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// נעשה שימוש בסוג המוחזר לאחר מפעיל השיחה.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// מבצע את פעולת השיחה.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}