//! מפעילים הניתנים לעומס יתר.
//!
//! יישום traits אלה מאפשר לך להעמיס על מפעילים מסוימים.
//!
//! חלק מה-traits מיובאים על ידי prelude, כך שהם זמינים בכל תוכנית Rust.ניתן להעמיס רק על מפעילים המגובים על ידי traits.
//! לדוגמא, ניתן להעמיס על מפעיל התוספת (`+`) דרך ה-[`Add`] trait, אך מכיוון שלמפעיל ההקצאה (`=`) אין גיבוי trait, אין שום דרך להעמיס על הסמנטיקה שלו.
//! בנוסף, מודול זה אינו מספק כל מנגנון ליצירת אופרטורים חדשים.
//! אם נדרשים עומס יתר ללא תכונות או אופרטורים מותאמים אישית, עליך להסתכל על פקודות מאקרו או תוספי מהדר כדי להרחיב את התחביר של Rust.
//!
//! יישומים של מפעיל traits צריכים להיות לא מפתיעים בהקשרים שלהם, תוך התחשבות במשמעויות הרגילות שלהם וב-[operator precedence].
//! לדוגמא, כאשר מיישמים את [`Mul`], על הפעולה להיות דומה לכפל (ולשתף מאפיינים צפויים כמו אסוציאטיביות).
//!
//! שים לב שמפעילי `&&` ו-`||` מקצרים, כלומר, הם מעריכים רק את האופראנד השני שלהם אם זה תורם לתוצאה.מכיוון שהתנהגות זו אינה ניתנת לאכיפה על ידי traits, `&&` ו-`||` אינם נתמכים כמפעילים הניתנים לעומס יתר.
//!
//! רבים מהמפעילים מעריכים את הפעולות שלהם לפי ערך.בהקשרים לא גנריים הכוללים סוגים מובנים זו בדרך כלל לא בעיה.
//! עם זאת, שימוש באופרטורים אלה בקוד גנרי, דורש התייחסות מסוימת אם יש לעשות שימוש חוזר בערכים לעומת מתן אפשרות למפעילים לצרוך אותם.אפשרות אחת היא להשתמש מדי פעם ב-[`clone`].
//! אפשרות נוספת היא להסתמך על הסוגים הכרוכים במתן יישומי מפעיל נוספים לצורך הפניות.
//! לדוגמא, עבור סוג `T` המוגדר על ידי המשתמש אשר אמור לתמוך בהוספה, כנראה שזה רעיון טוב שיהיו גם `T` וגם `&T` ליישם את traits [`Add<T>`][`Add`] ו-[`Add<&T>`][`Add`] כך שניתן יהיה לכתוב קוד גנרי ללא שיבוט מיותר.
//!
//!
//! # Examples
//!
//! דוגמה זו יוצרת מבנה `Point` המיישם את [`Add`] ו-[`Sub`], ולאחר מכן מדגים הוספה וחיסור של שתי נקודות.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! עיין בתיעוד עבור כל trait לקבלת דוגמה ליישום.
//!
//! ה-[`Fn`], [`FnMut`] וה-[`FnOnce`] traits מיושמים על ידי סוגים שניתן להפעיל כמו פונקציות.שים לב ש-[`Fn`] לוקח `&self`, [`FnMut`] לוקח `&mut self` ו-[`FnOnce`] לוקח `self`.
//! אלה תואמים לשלושת סוגי השיטות שניתן להפעיל בהן מופע: קריאה לפי התייחסות, התייחסות לפי שינוי שינוי והתקשרות לפי ערך.
//! השימוש הנפוץ ביותר ב-traits הוא לפעול כגבול לפונקציות ברמה גבוהה יותר שלוקחות פונקציות או סגירות כטיעונים.
//!
//! נטילת [`Fn`] כפרמטר:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! נטילת [`FnMut`] כפרמטר:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! נטילת [`FnOnce`] כפרמטר:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` צורכת את המשתנים שנתפסו, כך שאי אפשר להריץ אותה יותר מפעם אחת
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // ניסיון להפעיל את `func()` שוב יזרוק שגיאת `use of moved value` עבור `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` לא ניתן להפעיל עוד בשלב זה
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;