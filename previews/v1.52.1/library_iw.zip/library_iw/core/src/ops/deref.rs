/// משמש לביצוע פעולות הפיכה בלתי ניתנות לשינוי, כמו `*v`.
///
/// בנוסף לשימוש ב-(unary) `*` בניתוחי התייחסות מפורשים בהקשרים בלתי ניתנים לשינוי, `Deref` משמש גם באופן מרומז על ידי המהדר בנסיבות רבות.
/// מנגנון זה נקרא ['`Deref` coercion'][more].
/// בהקשרים משתנים, נעשה שימוש ב-[`DerefMut`].
///
/// יישום `Deref` עבור מצביעים חכמים הופך את הגישה לנתונים שמאחוריהם לנוחה, ולכן הם מיישמים את `Deref`.
/// מצד שני, הכללים לגבי `Deref` ו-[`DerefMut`] תוכננו במיוחד כדי להכיל מצביעים חכמים.
/// מסיבה זו, יש ליישם את 'Deref' רק עבור מצביעים חכמים ** כדי למנוע בלבול.
///
/// מסיבות דומות,**trait זה לעולם לא צריך להיכשל**.כישלון במהלך דיפרנס יכול להיות מבלבל ביותר כאשר `Deref` מופעל באופן מרומז.
///
/// # עוד על כפייה `Deref`
///
/// אם `T` מיישם את `Deref<Target = U>`, ו-`x` הוא ערך מסוג `T`, אז:
///
/// * בהקשרים בלתי ניתנים לשינוי, `*x` (כאשר `T` אינו התייחסות ולא מצביע גולמי) שווה ערך ל-`* Deref::deref(&x)`.
/// * ערכים מסוג `&T` מכופפים לערכים מסוג `&U`
/// * `T` מיישם באופן מרומז את כל שיטות ה-(immutable) מהסוג `U`.
///
/// לפרטים נוספים בקרו ב-[the chapter in *The Rust Programming Language*][book] וכן בסעיפי ההתייחסות ב-[the dereference operator][ref-deref-op], [method resolution] ו-[type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// מבנה בעל שדה יחיד הנגיש באמצעות העברת מבנה.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// הסוג המתקבל לאחר התייחסות נוספת.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// מפנה את הערך.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// משמש לביצוע פעולות הניתנות לשינויים ניתנים לשינוי, כמו ב-`*v = 1;`.
///
/// בנוסף לשימוש בפעולות התייחסות מפורשות עם מפעיל (unary) `*` בהקשרים משתנים, `DerefMut` משמש גם באופן מרומז על ידי המהדר בנסיבות רבות.
/// מנגנון זה נקרא ['`Deref` coercion'][more].
/// בהקשרים בלתי ניתנים לשינוי, נעשה שימוש ב-[`Deref`].
///
/// יישום `DerefMut` עבור מצביעים חכמים הופך את המוטציה של הנתונים מאחוריהם לנוחה ולכן הם מיישמים את `DerefMut`.
/// מצד שני, הכללים לגבי [`Deref`] ו-`DerefMut` תוכננו במיוחד כדי להכיל מצביעים חכמים.
/// מסיבה זו, יש ליישם את 'DerefMut' רק עבור מצביעים חכמים ** כדי למנוע בלבול.
///
/// מסיבות דומות,**trait זה לעולם לא צריך להיכשל**.כישלון במהלך דיפרנס יכול להיות מבלבל ביותר כאשר `DerefMut` מופעל באופן מרומז.
///
/// # עוד על כפייה `Deref`
///
/// אם `T` מיישם את `DerefMut<Target = U>`, ו-`x` הוא ערך מסוג `T`, אז:
///
/// * בהקשרים משתנים, `*x` (כאשר `T` אינו התייחסות ולא מצביע גולמי) שווה ערך ל-`* DerefMut::deref_mut(&mut x)`.
/// * ערכים מסוג `&mut T` מכופפים לערכים מסוג `&mut U`
/// * `T` מיישם באופן מרומז את כל שיטות ה-(mutable) מהסוג `U`.
///
/// לפרטים נוספים בקרו ב-[the chapter in *The Rust Programming Language*][book] וכן בסעיפי ההתייחסות ב-[the dereference operator][ref-deref-op], [method resolution] ו-[type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// מבנה עם שדה יחיד הניתן לשינוי על ידי שינוי ההפניה של המבנה.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// ניתן להפנות את הערך באופן הדדי.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// מציין ש-struct יכול לשמש כמקלט שיטה, ללא תכונת `arbitrary_self_types`.
///
/// זה מיושם על ידי סוגי מצביעים מסוג stdlib כמו `Box<T>`, `Rc<T>`, `&T` ו-`Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}