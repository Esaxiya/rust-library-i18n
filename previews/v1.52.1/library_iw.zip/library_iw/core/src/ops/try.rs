/// trait להתאמה אישית של התנהגות מפעיל ה-`?`.
///
/// סוג המיישם את `Try` הוא כזה שיש לו דרך קנונית לראות אותו במונחים של דיכוטומיה success/failure.
/// trait זה מאפשר גם לחלץ את ערכי ההצלחה או הכישלון ממופע קיים וגם יצירת מופע חדש מערך הצלחה או כישלון.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// סוג הערך הזה כאשר הוא נתפס כמוצלח.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// סוג הערך הזה כאשר הוא נתפס ככושל.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// חל על מפעיל "?".החזר של `Ok(t)` פירושו שהביצוע צריך להמשיך כרגיל, והתוצאה של `?` היא הערך `t`.
    /// החזר של `Err(e)` פירושו שהביצוע צריך להיות branch אל הפנימי הסוגר ביותר `catch`, או לחזור מהפונקציה.
    ///
    /// אם תוחזר תוצאת `Err(e)`, הערך `e` יהיה "wrapped" בסוג ההחזרה של ההיקף הסוגר (שעליו ליישם בעצמו את `Try`).
    ///
    /// באופן ספציפי, מוחזר הערך `X::from_error(From::from(e))`, כאשר `X` הוא סוג ההחזרה של הפונקציה הסוגרת.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// עטוף ערך שגיאה לבניית התוצאה המורכבת.
    /// לדוגמא, `Result::Err(x)` ו-`Result::from_error(x)` שוות ערך.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// עטוף ערך OK לבניית התוצאה המורכבת.
    /// לדוגמא, `Result::Ok(x)` ו-`Result::from_ok(x)` שוות ערך.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}