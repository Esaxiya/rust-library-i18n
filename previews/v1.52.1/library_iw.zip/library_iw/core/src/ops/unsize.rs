use crate::marker::Unsize;

/// Trait המציין כי זהו מצביע או עטיפה עבור אחד, כאשר ניתן לבצע שינוי גודל על הצבע.
///
/// לפרטים נוספים, עיין ב-[DST coercion RFC][dst-coerce] ו-[the nomicon entry on coercion][nomicon-coerce].
///
/// עבור סוגי מצביעים מובנים, מצביעים ל-`T` יכריחו מצביעים ל-`U` אם `T: Unsize<U>` על ידי המרה ממצביע דק למצביע שמן.
///
/// עבור סוגים מותאמים אישית, הכפייה כאן עובדת על ידי אילוץ `Foo<T>` ל-`Foo<U>` בתנאי שקיים impl של `CoerceUnsized<Foo<U>> for Foo<T>`.
/// ניתן לכתוב רמז כזה רק אם ל-`Foo<T>` יש רק שדה יחיד שאינו פנטומטי ומערב `T`.
/// אם סוג השדה הוא `Bar<T>`, יישום של `CoerceUnsized<Bar<U>> for Bar<T>` חייב להתקיים.
/// הכפייה תעבוד על ידי כפיית שדה `Bar<T>` ל-`Bar<U>` ומילוי שאר השדות מ-`Foo<T>` ליצירת `Foo<U>`.
/// זה יהיה למעשה לקדוח לשדה מצביע ולכפות על כך.
///
/// באופן כללי, עבור מצביעים חכמים תיישם את `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, עם `?Sized` אופציונלי המוטל על `T` עצמו.
/// לסוגי עטיפה המוטבעים ישירות `T` כמו `Cell<T>` ו-`RefCell<T>`, אתה יכול ליישם ישירות את `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// זה יאפשר לכפיות מסוגים כמו `Cell<Box<T>>` לעבוד.
///
/// [`Unsize`][unsize] משמש לסימון סוגים שניתן לכפות על שיחות DST אם מאחורי מצביעים.הוא מיושם אוטומטית על ידי המהדר.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *קונסט T->* קונסט U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// זה משמש לבטיחות אובייקטים, כדי לבדוק שאפשר לשלוח את סוג המקלט של השיטה.
///
/// דוגמה ליישום ה-trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *קונסט T->* קונסט U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}