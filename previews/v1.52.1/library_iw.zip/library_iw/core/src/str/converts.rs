//! דרכים ליצור `str` מפרוסת בתים.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// ממיר פרוסת בתים לפרוסת מחרוזת.
///
/// פרוסת מחרוזת ([`&str`]) עשויה בתים ([`u8`]), ופרוסת בתים ([`&[u8]`][byteslice]) עשויה בתים, ולכן פונקציה זו ממירה בין השניים.
/// לא כל פרוסות הבייט הן פרוסות מחרוזת תקפות, עם זאת: [`&str`] מחייב שהיא תקפה UTF-8.
/// `from_utf8()` בודק כדי להבטיח שהבתים תקפים ל-UTF-8, ואז מבצע את ההמרה.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// אם אתה בטוח שפרוסת הבייט תקפה ל-UTF-8, ואינך מעוניין להכניס את התקורה לבדיקת התוקף, קיימת גרסה לא בטוחה של פונקציה זו, [`from_utf8_unchecked`], שמתנהגת באותה התנהגות אך מדלגת על הסימון.
///
///
/// אם אתה צריך `String` במקום `&str`, שקול [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// מכיוון שאתה יכול להקצות מחסנית `[u8; N]`, ואתה יכול לקחת [`&[u8]`][byteslice] ממנה, פונקציה זו היא אחת הדרכים לקבל מחרוזת המוקצית מחסנית.יש דוגמה לכך בסעיף הדוגמאות להלן.
///
/// [byteslice]: slice
///
/// # Errors
///
/// מחזירה את `Err` אם הנתח אינו UTF-8 עם תיאור מדוע הנתח שסופק אינו UTF-8.
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// use std::str;
///
/// // כמה בתים, ב-vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // אנו יודעים שבתים אלה תקפים, אז פשוט השתמש ב-`unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// בתים שגויים:
///
/// ```
/// use std::str;
///
/// // כמה בתים לא חוקיים, ב-vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// עיין במסמכי [`Utf8Error`] לקבלת פרטים נוספים על סוגי השגיאות שניתן להחזיר.
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // כמה בתים, במערך שהוקצה לערימה
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // אנו יודעים שבתים אלה תקפים, אז פשוט השתמש ב-`unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // בטיחות: פשוט הריץ אימות.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// ממיר פרוסת בתים ניתנת לשינוי לפרוסת מחרוזת משתנה.
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" כ-vector משתנה
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // כידוע בתים אלה תקפים, אנו יכולים להשתמש ב-`unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// בתים שגויים:
///
/// ```
/// use std::str;
///
/// // כמה בתים לא חוקיים ב-vector המשתנה
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// עיין במסמכי [`Utf8Error`] לקבלת פרטים נוספים על סוגי השגיאות שניתן להחזיר.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // בטיחות: פשוט הריץ אימות.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// ממיר פרוסת בתים לפרוסת מחרוזת מבלי לבדוק שהמחרוזת מכילה UTF-8 תקף.
///
/// ראה את הגרסה הבטוחה, [`from_utf8`], לקבלת מידע נוסף.
///
/// # Safety
///
/// פונקציה זו אינה בטוחה מכיוון שהיא אינה בודקת כי הבייטים המועברים אליה תקפים ל-UTF-8.
/// אם מגבלה זו מופרת, התנהגות לא מוגדרת גורמת, שכן שאר ה-Rust מניחים ש [&str`] תקפים UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// use std::str;
///
/// // כמה בתים, ב-vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // בטיחות: על המתקשר להבטיח כי הבתים `v` תקפים ל-UTF-8.
    // מסתמך גם על כך ש-`&str` ו-`&[u8]` בעלי אותה פריסה.
    unsafe { mem::transmute(v) }
}

/// ממיר פרוסת בתים לפרוסת מחרוזת מבלי לבדוק שהמחרוזת מכילה UTF-8 תקף;גרסה משתנה.
///
///
/// ראה את הגרסה הבלתי ניתנת לשינוי, [`from_utf8_unchecked()`] למידע נוסף.
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // בטיחות: על המתקשר להבטיח כי הבתים `v`
    // הם UTF-8 תקפים, ולכן הצוות ל-`*mut str` בטוח.
    // כמו כן, התייחסות המצביע בטוחה מכיוון שמצביע זה מגיע מהפניה אשר מובטחת שתוקפה לכתיבה.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}