//! יישומי Trait עבור `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// מיישם הזמנת מיתרים.
///
/// מחרוזות מסודרות [lexicographically](Ord#lexicographical-comparison) לפי ערכי הבייט שלהן.
/// זה מזמין נקודות קוד של Unicode בהתבסס על מיקומם בתרשימי הקוד.
/// זה לא בהכרח זהה להזמנת "alphabetical", המשתנה לפי השפה והמקום.
/// מיון מחרוזות על פי סטנדרטים מקובלים תרבותית דורש נתונים ספציפיים למקום שנמצאים מחוץ לסוג ה-`str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// מיישם פעולות השוואה על מיתרים.
///
/// מחרוזות מושוות ל-[lexicographically](Ord#lexicographical-comparison) לפי ערכי הבייט שלהם.
/// זה משווה נקודות קוד של Unicode בהתבסס על מיקומן בתרשימי הקוד.
/// זה לא בהכרח זהה להזמנת "alphabetical", המשתנה לפי השפה והמקום.
/// השוואת מחרוזות על פי סטנדרטים מקובלים תרבותית מחייבת נתונים ספציפיים למקום שנמצאים מחוץ לסוג ה-`str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// מיישמת חיתוך מיתרים בעזרת תחביר `&self[..]` או `&mut self[..]`.
///
/// מחזירה פרוסה של כל המחרוזת, כלומר מחזירה `&self` או `&mut self`.שווה ערך ל '&עצמי [0 ..
/// len] `או`&mut self [0 ..
/// len]`.
/// שלא כמו פעולות אינדקס אחרות, זה לעולם לא יכול להיות panic.
///
/// פעולה זו היא *O*(1).
///
/// לפני 1.20.0, פעולות אינדקס אלה עדיין נתמכו על ידי יישום ישיר של `Index` ו-`IndexMut`.
///
/// שווה ערך ל-`&self[0 .. len]` או `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// מיישמת חיתוך מיתרים בעזרת תחביר `&self[begin .. end]` או `&mut self[begin .. end]`.
///
/// מחזיר פרוסה של המחרוזת הנתונה מטווח הבתים [`התחל ', `end`).
///
/// פעולה זו היא *O*(1).
///
/// לפני 1.20.0, פעולות אינדקס אלה עדיין נתמכו על ידי יישום ישיר של `Index` ו-`IndexMut`.
///
/// # Panics
///
/// Panics אם `begin` או `end` לא מצביעים על קיזוז בתים ההתחלתי של תו (כהגדרתו `is_char_boundary`), אם `begin > end`, או אם `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // אלה יהיו panic:
/// // בית 2 נמצא בתוך `ö`:
/// // &s [2 ..3];
///
/// // בית 8 נמצא בתוך `老`&s [1 ..
/// // 8];
///
/// // בתים 100 נמצא מחוץ למחרוזת ו [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // בטיחות: רק בדק ש-`start` ו-`end` נמצאים בגבול החרבן,
            // ואנחנו מעבירים התייחסות בטוחה, כך שגם ערך ההחזר יהיה אחד.
            // בדקנו גם גבולות שכר, אז זה תקף ל-UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // בטיחות: רק בדק ש-`start` ו-`end` נמצאים בגבול החרבן.
            // אנו יודעים שהמצביע הוא ייחודי מכיוון שקיבלנו אותו מ-`slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // בטיחות: המתקשר מבטיח ש-`self` נמצא בתחומי `slice`
        // שעומד בכל התנאים ל-`add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // בטיחות: ראה הערות ל-`get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary בודק שהמדד נמצא ב-[0, .len()] לא יכול לעשות שימוש חוזר ב-`get` כנ"ל, בגלל בעיות NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // בטיחות: רק בדק ש-`start` ו-`end` נמצאים בגבול החרבן,
            // ואנחנו מעבירים התייחסות בטוחה, כך שגם ערך ההחזר יהיה אחד.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// מיישמת חיתוך מיתרים בעזרת תחביר `&self[.. end]` או `&mut self[.. end]`.
///
/// מחזיר פרוסה של המחרוזת הנתונה מטווח הבתים [`0 ', `end`).
/// שווה ערך ל-`&self[0 .. end]` או `&mut self[0 .. end]`.
///
/// פעולה זו היא *O*(1).
///
/// לפני 1.20.0, פעולות אינדקס אלה עדיין נתמכו על ידי יישום ישיר של `Index` ו-`IndexMut`.
///
/// # Panics
///
/// Panics אם `end` אינו מצביע על קיזוז בתים התחלתי של תו (כהגדרתו `is_char_boundary`), או אם `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // בטיחות: רק בדק שה-`end` נמצא בגבול החרבן,
            // ואנחנו מעבירים התייחסות בטוחה, כך שגם ערך ההחזר יהיה אחד.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // בטיחות: רק בדק שה-`end` נמצא בגבול החרבן,
            // ואנחנו מעבירים התייחסות בטוחה, כך שגם ערך ההחזר יהיה אחד.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // בטיחות: רק בדק שה-`end` נמצא בגבול החרבן,
            // ואנחנו מעבירים התייחסות בטוחה, כך שגם ערך ההחזר יהיה אחד.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// מיישמת חיתוך מיתרים בעזרת תחביר `&self[begin ..]` או `&mut self[begin ..]`.
///
/// מחזיר פרוסה של המחרוזת הנתונה מטווח הבתים [`התחל ', `len`).שווה ערך ל'&עצמי [מתחילים ..
/// len] `או`&mut self [התחל ..
/// len]`.
///
/// פעולה זו היא *O*(1).
///
/// לפני 1.20.0, פעולות אינדקס אלה עדיין נתמכו על ידי יישום ישיר של `Index` ו-`IndexMut`.
///
/// # Panics
///
/// Panics אם `begin` אינו מצביע על קיזוז בתים התחלתי של תו (כהגדרתו `is_char_boundary`), או אם `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // בטיחות: רק בדק שה-`start` נמצא בגבול החרבן,
            // ואנחנו מעבירים התייחסות בטוחה, כך שגם ערך ההחזר יהיה אחד.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // בטיחות: רק בדק שה-`start` נמצא בגבול החרבן,
            // ואנחנו מעבירים התייחסות בטוחה, כך שגם ערך ההחזר יהיה אחד.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // בטיחות: המתקשר מבטיח ש-`self` נמצא בתחומי `slice`
        // שעומד בכל התנאים ל-`add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // בטיחות: זהה ל-`get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // בטיחות: רק בדק שה-`start` נמצא בגבול החרבן,
            // ואנחנו מעבירים התייחסות בטוחה, כך שגם ערך ההחזר יהיה אחד.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// מיישמת חיתוך מיתרים בעזרת תחביר `&self[begin ..= end]` או `&mut self[begin ..= end]`.
///
/// מחזיר פרוסה של המחרוזת הנתונה מטווח הבתים [`begin`, `end`].שווה ערך ל-`&self [begin .. end + 1]` או `&mut self[begin .. end + 1]`, למעט אם ל-`end` יש את הערך המקסימלי עבור `usize`.
///
/// פעולה זו היא *O*(1).
///
/// # Panics
///
/// Panics אם `begin` אינו מצביע על קיזוז בתים ההתחלה של תו (כהגדרתו `is_char_boundary`), אם `end` אינו מצביע על קיזוז בתים הסופי של תו (`end + 1` הוא קיזוז של בתים התחלה או שווה ל-`len`), אם `begin > end`, או אם `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// מיישמת חיתוך מיתרים בעזרת תחביר `&self[..= end]` או `&mut self[..= end]`.
///
/// מחזיר פרוסה של המחרוזת הנתונה מטווח הבתים [0, `end`].
/// שווה ערך ל-`&self [0 .. end + 1]`, למעט אם ל-`end` יש את הערך המקסימלי עבור `usize`.
///
/// פעולה זו היא *O*(1).
///
/// # Panics
///
/// Panics אם `end` אינו מצביע על קיזוז בתים הסוף של תו (`end + 1` הוא קיזוז בתים התחלתי כהגדרתו `is_char_boundary`, או שווה ל-`len`), או אם `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// מנתח ערך ממחרוזת
///
/// לעתים קרובות משתמשים בשיטת [`from_str`] של `FromStr` באופן מרומז, באמצעות שיטת [`parse`] של [`str`].
/// ראה תיעוד של ["ניתוח"] לדוגמאות.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` אין פרמטר לכל החיים, ולכן אתה יכול רק לנתח סוגים שאינם מכילים פרמטר לכל החיים בעצמם.
///
/// במילים אחרות, אתה יכול לנתח `i32` עם `FromStr`, אבל לא `&i32`.
/// אתה יכול לנתח מבנה שמכיל `i32`, אך לא כזה שמכיל `&i32`.
///
/// # Examples
///
/// יישום בסיסי של `FromStr` על סוג `Point` לדוגמא:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// השגיאה המשויכת שניתנת להחזרה מניתוח.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// מנתח מחרוזת `s` להחזרת ערך מסוג זה.
    ///
    /// אם הניתוח מצליח, החזר את הערך בתוך [`Ok`], אחרת כאשר המחרוזת אינה מעוצבת, החזיר שגיאה ספציפית לפנים [`Err`].
    /// סוג השגיאה הוא ספציפי ליישום ה-trait.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי עם [`i32`], סוג המיישם את `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// נתח `bool` ממחרוזת.
    ///
    /// מניב `Result<bool, ParseBoolError>` מכיוון ש-`s` יכול להיות ניתנת לניתוח או לא.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// שים לב, במקרים רבים, שיטת `.parse()` ב-`str` נכונה יותר.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}