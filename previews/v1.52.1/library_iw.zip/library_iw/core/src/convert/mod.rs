//! Traits להמרות בין סוגים.
//!
//! ה-traits במודול זה מספק דרך להמיר מסוג אחד לסוג אחר.
//! כל trait משרת מטרה אחרת:
//!
//! - יישם את [`AsRef`] trait להמרות הפניה להפניה זולות
//! - יישם את [`AsMut`] trait להמרות זולות לניתנות לשינוי
//! - יישם את [`From`] trait לצריכת המרות ערך-ערך
//! - יישם את [`Into`] trait לצריכת המרות ערך-ערך לסוגים מחוץ ל-crate הנוכחי.
//! - [`TryFrom`] ו-[`TryInto`] traits מתנהגים כמו [`From`] ו-[`Into`], אך יש ליישם כאשר ההמרה עלולה להיכשל.
//!
//! traits במודול זה משמשים לעיתים קרובות כ-trait bounds עבור פונקציות כלליות כך שתומכים בארגומנטים מסוגים רבים.עיין בתיעוד של כל trait לדוגמאות.
//!
//! ככותב ספרייה, אתה תמיד מעדיף להטמיע את [`From<T>`][`From`] או [`TryFrom<T>`][`TryFrom`] במקום [`Into<U>`][`Into`] או [`TryInto<U>`][`TryInto`], שכן [`From`] ו-[`TryFrom`] מספקים גמישות רבה יותר ומציעים מימושים [`Into`] או [`TryInto`] שווה ערך בחינם, הודות ליישום שמיכה בספריה הסטנדרטית.
//! בעת מיקוד לגרסה לפני Rust 1.41, ייתכן שיהיה צורך ליישם [`Into`] או [`TryInto`] ישירות בעת המרה לסוג שמחוץ ל-crate הנוכחי.
//!
//! # יישומים גנריים
//!
//! - [`AsRef`] ו [`AsMut`] אוטומטי-הסחות אם הסוג הפנימי הוא הפניה
//! - [`From`]`<U>עבור T` מרמז על [`Into`]`</u><T><U>עבור U`</u>
//! - [`TryFrom`]`<U>עבור T` מרמז על [`TryInto`]`</u><T><U>עבור U`</u>
//! - [`From`] ו-[`Into`] הם רפלקסיביים, כלומר כל הסוגים יכולים `into` עצמם ו-`from` עצמם
//!
//! ראה כל trait לקבלת דוגמאות לשימוש.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// פונקציית הזהות.
///
/// חשוב לשים לב לשני דברים לגבי פונקציה זו:
///
/// - זה לא תמיד שווה ערך לסגירה כמו `|x| x`, מכיוון שהסגירה עשויה להכריח את `x` לסוג אחר.
///
/// - זה מעביר את קלט `x` שהועבר לפונקציה.
///
/// אמנם זה אולי נראה מוזר שיש פונקציה שרק מחזירה את הקלט, אך ישנם שימושים מעניינים.
///
///
/// # Examples
///
/// שימוש ב-`identity` כדי לעשות דבר ברצף של פונקציות אחרות ומעניינות:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // בואו נעמיד פנים שהוספת אחת מהן היא פונקציה מעניינת.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// שימוש ב-`identity` כמארז בסיס "do nothing" בתנאי:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // עשו דברים מעניינים יותר ...
///
/// let _results = do_stuff(42);
/// ```
///
/// שימוש ב-`identity` כדי לשמור על גרסאות ה-`Some` של איטרטור של `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// משמש לבצע המרה זולה להפניה.
///
/// trait זה דומה ל-[`AsMut`] המשמש להמרה בין הפניות משתנות.
/// אם אתה צריך לבצע המרה יקרה עדיף ליישם [`From`] עם סוג `&T` או לכתוב פונקציה מותאמת אישית.
///
/// `AsRef` בעל אותה חתימה כמו [`Borrow`], אך [`Borrow`] שונה בכמה היבטים:
///
/// - שלא כמו `AsRef`, ל-[`Borrow`] יש שמיכת שמיכה לכל `T`, והיא יכולה לשמש לקבלת הפניה או ערך.
/// - [`Borrow`] דורש גם ש-[`Hash`], [`Eq`] ו-[`Ord`] עבור שווי מושאל שווים לאלה של הערך שבבעלות.
/// מסיבה זו, אם ברצונך לשאול רק שדה יחיד של מבנה אתה יכול ליישם את `AsRef`, אך לא את [`Borrow`].
///
/// **Note: אסור ש-trait זה ייכשל **.אם ההמרה עלולה להיכשל, השתמש בשיטה ייעודית המחזירה [`Option<T>`] או [`Result<T, E>`].
///
/// # יישומים גנריים
///
/// - `AsRef` הפניות אוטומטיות אם הסוג הפנימי הוא הפניה או הפניה משתנה (למשל: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// באמצעות trait bounds אנו יכולים לקבל טיעונים מסוגים שונים כל עוד ניתן להמיר אותם לסוג שצוין `T`.
///
/// לדוגמא: על ידי יצירת פונקציה כללית שלוקחת `AsRef<str>` אנו מבטאים כי אנו רוצים לקבל את כל ההפניות שניתן להמיר ל-[`&str`] כארגומנט.
/// מכיוון שגם [`String`] וגם [`&str`] מיישמים את `AsRef<str>` אנו יכולים לקבל את שניהם כטיעון קלט.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// מבצע את ההמרה.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// משמש לביצוע המרת הפניה זולה לשינוי-משתנה.
///
/// trait זה דומה ל-[`AsRef`] אך משמש להמרה בין הפניות משתנות.
/// אם אתה צריך לבצע המרה יקרה עדיף ליישם [`From`] עם סוג `&mut T` או לכתוב פונקציה מותאמת אישית.
///
/// **Note: אסור ש-trait זה ייכשל **.אם ההמרה עלולה להיכשל, השתמש בשיטה ייעודית המחזירה [`Option<T>`] או [`Result<T, E>`].
///
/// # יישומים גנריים
///
/// - `AsMut` הפניות אוטומטיות אם הסוג הפנימי הוא הפניה משתנה (למשל: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// באמצעות `AsMut` כ-trait bound עבור פונקציה כללית אנו יכולים לקבל את כל ההפניות הניתנות לשינוי הניתנות להמרה לסוג `&mut T`.
/// מכיוון ש-[`Box<T>`] מיישם את `AsMut<T>` נוכל לכתוב פונקציה `add_one` שלוקחת את כל הארגומנטים שניתן להמיר ל-`&mut u64`.
/// מכיוון ש-[`Box<T>`] מיישם את `AsMut<T>`, ה-`add_one` מקבל גם ארגומנטים מסוג `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// מבצע את ההמרה.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// המרה בין ערך לערך הצורכת את ערך הקלט.ההפך מ-[`From`].
///
/// יש להימנע מיישום [`Into`] וליישם במקום זאת את [`From`].
/// יישום [`From`] מספק ליישום אוטומטי יישום של [`Into`] הודות ליישום השמיכה בספרייה הסטנדרטית.
///
/// העדיף להשתמש ב-[`Into`] על פני [`From`] בעת ציון trait bounds בפונקציה כללית כדי להבטיח כי ניתן להשתמש גם בסוגים המיישמים [`Into`] בלבד.
///
/// **Note: אסור ש-trait זה ייכשל **.אם ההמרה עלולה להיכשל, השתמש ב-[`TryInto`].
///
/// # יישומים גנריים
///
/// - [`מאת`]`<T>עבור U` מרמז על `Into<U> for T`
/// - [`Into`] הוא רפלקסיבי, מה שאומר ש-`Into<T> for T` מיושם
///
/// # יישום [`Into`] להמרות לסוגים חיצוניים בגרסאות ישנות של Rust
///
/// לפני Rust 1.41, אם סוג היעד לא היה חלק מ-crate הנוכחי, לא תוכל ליישם את [`From`] ישירות.
/// לדוגמה, קח את הקוד הזה:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// זה לא ייכשל בגירסאות ישנות יותר של השפה מכיוון שכללי היתומים של Rust היו קפדניים יותר.
/// כדי לעקוף זאת, תוכל ליישם את [`Into`] ישירות:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// חשוב להבין ש-[`Into`] אינו מספק יישום [`From`] (כמו ש-[`From`] עושה עם [`Into`]).
/// לכן, כדאי תמיד לנסות ליישם את [`From`] ואז לחזור ל-[`Into`] אם לא ניתן ליישם את [`From`].
///
/// # Examples
///
/// [`String`] מיישם [`לתוך`]`<`[`Vec`] `<` [`u8`]`>>":
///
/// על מנת להביע כי אנו רוצים שפונקציה גנרית תיקח את כל הארגומנטים שניתן להמיר לסוג מוגדר `T`, נוכל להשתמש ב-trait bound של ["Into"] "<T>`.
///
/// לדוגמא: הפונקציה `is_hello` לוקחת את כל הארגומנטים שניתן להמיר ל [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// מבצע את ההמרה.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// משמש לביצוע המרות ערך-ערך תוך צריכת ערך הקלט.זה ההדדי של [`Into`].
///
/// תמיד צריך להעדיף יישום `From` על פני [`Into`] מכיוון שיישום `From` מספק באופן אוטומטי ליישום של [`Into`] הודות ליישום השמיכה בספרייה הסטנדרטית.
///
///
/// יישם את [`Into`] רק כאשר אתה ממקד לגרסה לפני Rust 1.41 וממיר לסוג שמחוץ ל-crate הנוכחי.
/// `From` לא הצליח לבצע המרות מסוג זה בגרסאות קודמות בגלל כללי היתומים של Rust.
/// לפרטים נוספים, ראה [`Into`].
///
/// העדיף להשתמש ב-[`Into`] על פני השימוש ב-`From` בעת ציון trait bounds בפונקציה כללית.
/// בדרך זו, ניתן להשתמש גם בסוגים המיישמים ישירות את [`Into`] כטיעונים.
///
/// ה-`From` מאוד שימושי בעת ביצוע טיפול בשגיאות.בעת בניית פונקציה המסוגלת להיכשל, סוג ההחזרה יהיה בדרך כלל בצורה `Result<T, E>`.
/// ה-`From` trait מפשט את הטיפול בשגיאות בכך שהוא מאפשר לפונקציה להחזיר סוג שגיאה יחיד המקיף סוגי שגיאות מרובים.עיין בסעיף "Examples" וב-[the book][book] לפרטים נוספים.
///
/// **Note: אסור ש-trait זה ייכשל **.אם ההמרה עלולה להיכשל, השתמש ב-[`TryFrom`].
///
/// # יישומים גנריים
///
/// - `From<T> for U` מרמז [`לתוך`]`<U>עבור T`</u>
/// - `From` הוא רפלקסיבי, מה שאומר ש-`From<T> for T` מיושם
///
/// # Examples
///
/// [`String`] מיישם את `From<&str>`:
///
/// המרה מפורשת מ-`&str` למחרוזת נעשית באופן הבא:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// בעת ביצוע טיפול בשגיאות לעתים קרובות שימושי להטמיע את `From` לסוג השגיאה שלך.
/// על ידי המרת סוגי שגיאות בסיסיות לסוג השגיאה המותאם אישית שלנו שמקיף את סוג השגיאה הבסיסי, אנו יכולים להחזיר סוג שגיאה יחיד מבלי לאבד מידע על הסיבה הבסיסית.
/// מפעיל ה-'?' ממיר באופן אוטומטי את סוג השגיאה הבסיסי לסוג השגיאה המותאם אישית שלנו על ידי קריאה ל-`Into<CliError>::into` המסופק באופן אוטומטי בעת הטמעת `From`.
/// לאחר מכן המהדר מגלה באיזה יישום של `Into` יש להשתמש.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// מבצע את ההמרה.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// ניסיון המרה שצורך `self`, שעשוי להיות יקר או לא.
///
/// על כותבי הספריות בדרך כלל לא ליישם ישירות את trait הזה, אלא להעדיף ליישם את [`TryFrom`] trait, המציע גמישות רבה יותר ומספק יישום `TryInto` שווה ערך בחינם, הודות ליישום שמיכה בספרייה הסטנדרטית.
/// למידע נוסף על כך, עיין בתיעוד ל-[`Into`].
///
/// # יישום `TryInto`
///
/// זה סובל מאותן מגבלות ונימוקים כמו יישום [`Into`], ראה שם לפרטים.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// הסוג שהוחזר במקרה של שגיאת המרה.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// מבצע את ההמרה.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// המרות מסוג פשוט ובטוח שעלולות להיכשל בצורה מבוקרת בנסיבות מסוימות.זה ההדדי של [`TryInto`].
///
/// זה שימושי כאשר אתה מבצע המרת סוג שעשויה להצליח באופן טריוויאלי, אך ייתכן שתזדקק לטיפול מיוחד.
/// לדוגמא, אין דרך להמיר [`i64`] ל-[`i32`] באמצעות ה-[`From`] trait, מכיוון ש-[`i64`] עשוי להכיל ערך ש-[`i32`] אינו יכול לייצג ולכן ההמרה תאבד נתונים.
///
/// ניתן לטפל בכך על ידי קטיעת ה-[`i64`] ל-[`i32`] (למעשה מתן הערך ["i64"] מודולו [`i32::MAX`]) או פשוט על ידי החזרת [`i32::MAX`], או על ידי שיטה אחרת.
/// ה-[`From`] trait מיועד להמרות מושלמות, ולכן ה-`TryFrom` trait מודיע למתכנת מתי המרת סוג עלולה להשתבש ומאפשר להם להחליט כיצד לטפל בזה.
///
/// # יישומים גנריים
///
/// - `TryFrom<T> for U` מרמז על [`TryInto`] <U>עבור T`</u>
/// - [`try_from`] הוא רפלקסיבי, מה שאומר ש-`TryFrom<T> for T` מיושם ולא יכול להיכשל-סוג ה-`Error` המשויך להתקשרות ל-`T::try_from()` בערך מסוג `T` הוא [`Infallible`].
/// כאשר סוג [`!`] מיוצב [`Infallible`] ו-[`!`] יהיו שווים.
///
/// `TryFrom<T>` ניתן ליישם באופן הבא:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// כמתואר, [`i32`] מיישם את 'TryFrom <`[` i64`]>>:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // קוטם בשקט את `big_number`, דורש איתור וטיפול בחיתוך לאחר מעשה.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // מחזירה שגיאה מכיוון ש-`big_number` גדול מכדי להתאים ל-`i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // מחזירה `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// הסוג שהוחזר במקרה של שגיאת המרה.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// מבצע את ההמרה.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// כללים כללים
////////////////////////////////////////////////////////////////////////////////

// כשמעליות מעל&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// כמעליות מעל &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): החלף את המכשירים הנ"ל עבור&/&mut באחת הכללית הבאה:
// // כמעליות מעל דרף
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? גודל> AsRef <U>עבור D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut מרים מעל &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): החלף את ה-impl לעיל ל-&mut עם הכללי הבא:
// // AsMut מרים מעל DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>for D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// מתוך מרמז אל תוך
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// מ (וכך לתוך) רפלקסיבי
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **הערת יציבות:** יישום זה עדיין לא קיים, אבל אנחנו "reserving space" להוסיף אותו ב-future.
/// לפרטים ראה [rust-lang/rust#64715][#64715].
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): לעשות תיקון עקרוני במקום.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom מרמז על TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// המרות בלתי-שוות שוות סמנטית להמרות שנפלות עם סוג שגיאה לא מיושב.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// תמציות בטון
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// סוג הטעות ללא טעויות
////////////////////////////////////////////////////////////////////////////////

/// סוג השגיאה לשגיאות שלעולם לא יכולות לקרות.
///
/// מכיוון שלאלום זה אין גרסה, ערך מסוג זה לעולם לא יכול להתקיים בפועל.
/// זה יכול להיות שימושי עבור ממשקי API כלליים המשתמשים ב-[`Result`] ולפרמטרים את סוג השגיאה, כדי לציין שהתוצאה היא תמיד [`Ok`].
///
/// לדוגמא, ל-[`TryFrom`] trait (המרה המחזירה [`Result`]) יש הטמעת שמיכה לכל הסוגים שבהם קיימת הטמעה [`Into`] הפוכה.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # תאימות Future
///
/// לאנומן זה תפקיד זהה ל-[the `!`“never”type][never], שאינו יציב בגרסה זו של Rust.
/// כאשר `!` מתייצב, אנו מתכננים להפוך את `Infallible` לכינוי מסוג זה:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... ובסופו של דבר פוחת `Infallible`.
///
/// עם זאת יש מקרה אחד שבו ניתן להשתמש בתחביר `!` לפני שהתייצבות `!` כסוג מן המניין: במצב של סוג ההחזרה של פונקציה.
/// באופן ספציפי, ניתן ליישם שני סוגים שונים של מצביעי פונקציה:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// עם `Infallible` להיות enum, קוד זה תקף.
/// עם זאת, כאשר `Infallible` יהפוך לכינוי עבור never type, שני ה-`impl`s יתחילו לחפוף ולכן כללי הקוהרנטיות של trait בשפה יתבטלו.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}