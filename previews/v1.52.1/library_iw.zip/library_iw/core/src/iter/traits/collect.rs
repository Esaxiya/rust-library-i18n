/// המרה מ-[`Iterator`].
///
/// על ידי יישום `FromIterator` עבור סוג, אתה מגדיר כיצד הוא ייווצר מאיטרטור.
/// זה נפוץ לסוגים המתארים אוסף כלשהו.
///
/// [`FromIterator::from_iter()`] נקרא לעיתים רחוקות במפורש, ובמקום זה נעשה שימוש בשיטת [`Iterator::collect()`].
///
/// ראה תיעוד [`Iterator::collect()`]'s לקבלת דוגמאות נוספות.
///
/// ראה גם: [`IntoIterator`].
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// שימוש ב-[`Iterator::collect()`] לשימוש מרומז ב-`FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// יישום `FromIterator` לסוג שלך:
///
/// ```
/// use std::iter::FromIterator;
///
/// // אוסף דוגמאות, זה רק עטיפה מעל Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // בואו ניתן לו כמה שיטות כדי שנוכל ליצור אחת ולהוסיף לה דברים.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // וניישם את FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // עכשיו נוכל ליצור איטרטור חדש ...
/// let iter = (0..5).into_iter();
///
/// // ... ולעשות מזה מייקולקשן
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // אוספים גם עבודות!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// יוצר ערך מאיטרטור.
    ///
    /// ראה [module-level documentation] לקבלת מידע נוסף.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// המרה ל-[`Iterator`].
///
/// על ידי יישום `IntoIterator` לסוג, אתה מגדיר כיצד הוא יומר לאיטרציה.
/// זה נפוץ לסוגים המתארים אוסף כלשהו.
///
/// יתרון אחד ביישום `IntoIterator` הוא שהסוג שלך יהיה [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// ראה גם: [`FromIterator`].
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// יישום `IntoIterator` לסוג שלך:
///
/// ```
/// // אוסף דוגמאות, זה רק עטיפה מעל Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // בואו ניתן לו כמה שיטות כדי שנוכל ליצור אחת ולהוסיף לה דברים.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // וניישם את IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // עכשיו נוכל ליצור אוסף חדש ...
/// let mut c = MyCollection::new();
///
/// // ... להוסיף לזה כמה דברים ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ואז להפוך אותו למטפל:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// נהוג להשתמש ב-`IntoIterator` כ-trait bound.זה מאפשר לשנות את סוג אוסף הקלט, כל עוד הוא עדיין איטרטור.
/// ניתן להגדיר גבולות נוספים על ידי הגבלת
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// סוג האלמנטים שעושים איטרציה.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// לאיזה סוג איטרטור אנו הופכים את זה?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// יוצר איטרטור מערך.
    ///
    /// ראה [module-level documentation] לקבלת מידע נוסף.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// הרחב אוסף עם תוכן איטרטור.
///
/// מחמירים מייצרים סדרת ערכים, ואפשר לחשוב על אוספים גם כסדרת ערכים.
/// ה-`Extend` trait מגשר על פער זה, ומאפשר לך להרחיב אוסף על ידי הכללת התוכן של אותו איטרטור.
/// בעת הרחבת אוסף עם מפתח קיים כבר, ערך זה מתעדכן, או במקרה של אוספים המאפשרים כניסות מרובות עם מקשים שווים, ערך זה מוכנס.
///
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// // אתה יכול להאריך מחרוזת עם כמה תווים:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// יישום `Extend`:
///
/// ```
/// // אוסף דוגמאות, זה רק עטיפה מעל Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // בואו ניתן לו כמה שיטות כדי שנוכל ליצור אחת ולהוסיף לה דברים.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // מכיוון של-MyCollection יש רשימת i32, אנו מיישמים את Extend עבור i32
/// impl Extend<i32> for MyCollection {
///
///     // זה קצת יותר פשוט עם חתימת הבטון: אנו יכולים לקרוא להאריך את כל מה שניתן להפוך לאינטרטור שמעניק לנו i32s.
///     // כי אנחנו צריכים i32 להכניס את MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // היישום הוא מאוד פשוט: לעבור דרך האיטרטור ו-add() כל אלמנט לעצמנו.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // בואו נרחיב את האוסף שלנו בשלושה מספרים נוספים
/// c.extend(vec![1, 2, 3]);
///
/// // הוספנו את האלמנטים האלה בסוף
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// מרחיב אוסף עם תוכן של איטרטור.
    ///
    /// מכיוון שזו השיטה הנדרשת היחידה עבור trait זה, מסמכי [trait-level] מכילים פרטים נוספים.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// // אתה יכול להאריך מחרוזת עם כמה תווים:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// מרחיב אוסף עם אלמנט אחד בדיוק.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// שומר קיבולת באוסף למספר הנתון של אלמנטים נוספים.
    ///
    /// יישום ברירת המחדל אינו עושה דבר.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}