// ignore-tidy-filelength קובץ זה מורכב כמעט אך ורק מההגדרה של `Iterator`.
// אנחנו לא יכולים לפצל את זה למספר קבצים.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// ממשק להתמודדות עם איטרטורים.
///
/// זהו האיטרטור הראשי trait.
/// לקבלת מידע נוסף על מושג האיטרטורים בדרך כלל, עיין ב-[module-level documentation].
/// בפרט, ייתכן שתרצה לדעת כיצד [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// סוג האלמנטים שעושים איטרציה.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// מקדם את האיטרטור ומחזיר את הערך הבא.
    ///
    /// מחזירה את [`None`] לאחר סיום האיטרציה.
    /// יישומי איטרטור בודדים עשויים לבחור לחדש את האיטרציה, ולכן קריאה ל-`next()` שוב עשויה להתחיל להחזיר [`Some(Item)`] שוב או לא, בשלב מסוים.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // קריאה ל-next() מחזירה את הערך הבא ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ואז אף אחד לאחר שזה נגמר.
    /// assert_eq!(None, iter.next());
    ///
    /// // שיחות נוספות עשויות להחזיר `None` או לא.הנה, הם תמיד יעשו זאת.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// מחזיר את הגבולות לאורך האיטר שנותר.
    ///
    /// באופן ספציפי, `size_hint()` מחזיר כפולת כאשר האלמנט הראשון הוא הגבול התחתון, והאלמנט השני הוא הגבול העליון.
    ///
    /// המחצית השנייה של הטולפ המוחזר היא [`אפשרות`] <<[[גודל גודל]]>>.
    /// [`None`] כאן פירושו שאף אין גבולות עליונים ידועים, או שהגבול העליון גדול מ-[`usize`].
    ///
    /// # הערות יישום
    ///
    /// לא נאכף כי יישום איטרטור מניב את מספר האלמנטים המוצהר.איטרטור באגי עשוי להניב פחות מהגבול התחתון או יותר מהגבול העליון של האלמנטים.
    ///
    /// `size_hint()` מיועד בעיקר לשימוש אופטימיזציות כגון שמירת מקום לאלמנטים של האיטרטור, אך אסור לסמוך עליו למשל, להשמיט בדיקות גבולות בקוד לא בטוח.
    /// יישום שגוי של `size_hint()` לא אמור להוביל להפרות בטיחות זיכרון.
    ///
    /// עם זאת, היישום אמור לספק הערכה נכונה, מכיוון שאחרת זו תהיה הפרה של פרוטוקול ה-trait.
    ///
    /// הטמעת ברירת המחדל מחזירה את '(0, `[' ללא ']') 'הנכון לכל איטרטור.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// דוגמה מורכבת יותר:
    ///
    /// ```
    /// // המספרים הזוגיים מאפס לעשר.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // אנו עשויים לחזור מאפס לעשר פעמים.
    /// // הידיעה שזה בדיוק חמש לא תתאפשר ללא ביצוע filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // בואו נוסיף חמישה מספרים נוספים עם chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // כעת שני הגבולות מוגדלים בחמישה
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// החזרת `None` לגבול עליון:
    ///
    /// ```
    /// // לאיטרטור אינסופי אין גבול עליון וגבול תחתון מקסימאלי אפשרי
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// צורכת את האיטרטור, סופרת את מספר האיטרציות ומחזירה אותו.
    ///
    /// שיטה זו תתקשר שוב ושוב ל-[`next`] עד להיתקל ב-[`None`], ותחזיר את מספר הפעמים שראתה את [`Some`].
    /// שים לב כי יש להתקשר ל-[`next`] לפחות פעם אחת גם אם לאיטורציה אין אלמנטים.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # התנהגות הצפה
    ///
    /// השיטה אינה שומרת מפני הצפות, לכן ספירת אלמנטים של איטרטור עם יותר מ-[`usize::MAX`] אלמנטים מניבה תוצאה שגויה או panics.
    ///
    /// אם טענות ניפוי באגים מופעלות, מובטח panic.
    ///
    /// # Panics
    ///
    /// פונקציה זו עשויה להיות panic אם לאיטרטור יש יותר מאלמנטים של [`usize::MAX`].
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// צורכת את האיטרטור ומחזירה את האלמנט האחרון.
    ///
    /// שיטה זו תעריך את האיטרטור עד להחזרת [`None`].
    /// תוך כדי כך, הוא עוקב אחר האלמנט הנוכחי.
    /// לאחר החזרת [`None`], `last()` יחזיר את האלמנט האחרון שראה.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// מקדם את האיטרטור על ידי אלמנטים `n`.
    ///
    /// שיטה זו תדלג בשקיקה על אלמנטים `n` על ידי קריאה ל-[`next`] עד `n` פעמים עד להיתקל ב-[`None`].
    ///
    /// `advance_by(n)` יחזיר את [`Ok(())`][Ok] אם האיטרטור יתקדם בהצלחה על ידי אלמנטים `n`, או [`Err(k)`][Err] אם נתקלת ב-[`None`], כאשר `k` הוא מספר האלמנטים שאיתור מתקדם לפני שנגמר להם האלמנטים (כלומר
    /// אורך החזרה).
    /// שים לב ש-`k` הוא תמיד פחות מ-`n`.
    ///
    /// קריאה ל-`advance_by(0)` אינה צורכת שום אלמנט ומחזירה תמיד את [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // רק `&4` הוחלף
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// מחזיר את האלמנט 'n' של האיטרטור.
    ///
    /// כמו רוב פעולות הוספה לאינדקס, הספירה מתחילה מאפס, ולכן `nth(0)` מחזיר את הערך הראשון, `nth(1)` השני וכו '.
    ///
    /// שים לב שכל האלמנטים הקודמים, כמו גם האלמנט שהוחזר, ייצרכו מאיטרציה.
    /// המשמעות היא שהאלמנטים הקודמים יימחקו, וכי קריאה ל-`nth(0)` מספר פעמים באותו איטרטור תחזיר אלמנטים שונים.
    ///
    ///
    /// `nth()` יחזיר את [`None`] אם `n` גדול או שווה לאורך האיטרציה.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// התקשרות למספר פעמים ל-`nth()` לא מחזירה לאחור את האיטרטור:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// החזרת `None` אם ישנם פחות מאלמנטים `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// יוצר איטרטר שמתחיל באותה נקודה, אך עובר לפי הסכום הנתון בכל איטרציה.
    ///
    /// הערה 1: האלמנט הראשון של האיטרטור יוחזר תמיד, ללא קשר לשלב שניתן.
    ///
    /// הערה 2: הזמן בו מושכים אלמנטים מתעלמים אינו קבוע.
    /// `StepBy` מתנהג כמו הרצף `next(), nth(step-1), nth(step-1),…`, אבל הוא גם חופשי להתנהג כמו הרצף
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// הדרך שבה נעשה שימוש עשויה להשתנות עבור חלק מאיטרטים מסיבות ביצוע.
    /// הדרך השנייה תקדם את האיטרציה מוקדם יותר ועלולה לצרוך פריטים נוספים.
    ///
    /// `advance_n_and_return_first` שווה ערך ל:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// השיטה תהיה panic אם השלב הנתון הוא `0`.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// לוקח שני איטרטורים ויוצר איטרטור חדש על פני שניהם ברצף.
    ///
    /// `chain()` יחזיר איטרטור חדש שיחזור תחילה על פני ערכים מהאיטרטור הראשון ואז על ערכים מהאיטרטור השני.
    ///
    /// במילים אחרות, זה מקשר בין שני איטרטורים יחד, בשרשרת.🔗
    ///
    /// [`once`] משמש בדרך כלל להתאמת ערך יחיד לשרשרת של סוגים אחרים של איטרציה.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// מכיוון שהוויכוח ל-`chain()` משתמש ב-[`IntoIterator`], אנו יכולים להעביר כל דבר שניתן להמיר ל-[`Iterator`], ולא רק ל-[`Iterator`] עצמו.
    /// לדוגמה, פרוסות (`&[T]`) מיישמות את [`IntoIterator`], וכך ניתן להעביר אותן ישירות ל-`chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// אם אתה עובד עם Windows API, ייתכן שתרצה להמיר [`OsStr`] ל-`Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'רוכס' שני איטרטורים לאיטרטור זוגי יחיד.
    ///
    /// `zip()` מחזיר איטרטור חדש שיחזור על פני שני איטרטורים אחרים, ויחזיר צמרת איפה שהאלמנט הראשון מגיע מהאיטרטור הראשון, והאלמנט השני מגיע מהאיטרטור השני.
    ///
    ///
    /// במילים אחרות, הוא רוכס שני איטרטורים יחד, לאחד.
    ///
    /// אם איטרטור מחזיר את [`None`], [`next`] מאיטרטור הרוכסן יחזיר את [`None`].
    /// אם האיטרטור הראשון יחזיר את [`None`], ה-`zip` יקצר וקצר ל-`next` באיטרציה השנייה.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// מכיוון שהוויכוח ל-`zip()` משתמש ב-[`IntoIterator`], אנו יכולים להעביר כל דבר שניתן להמיר ל-[`Iterator`], ולא רק ל-[`Iterator`] עצמו.
    /// לדוגמה, פרוסות (`&[T]`) מיישמות את [`IntoIterator`], וכך ניתן להעביר אותן ישירות ל-`zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` משמש לעתים קרובות כדי לרכוס איטרטר אינסופי לאחד סופי.
    /// זה עובד מכיוון שהאיטרטור הסופי יחזיר בסופו של דבר את [`None`] ויסיים את הרוכסן.רוכסן עם `(0..)` יכול להיראות הרבה כמו [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// יוצר איטרטור חדש שממקם עותק של `separator` בין פריטים סמוכים של האיטרטור המקורי.
    ///
    /// במקרה ש-`separator` אינו מיישם את [`Clone`] או שיש צורך לחשב אותו בכל פעם, השתמש ב-[`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // האלמנט הראשון מ-`a`.
    /// assert_eq!(a.next(), Some(&100)); // המפריד.
    /// assert_eq!(a.next(), Some(&1));   // האלמנט הבא מ-`a`.
    /// assert_eq!(a.next(), Some(&100)); // המפריד.
    /// assert_eq!(a.next(), Some(&2));   // האלמנט האחרון מ-`a`.
    /// assert_eq!(a.next(), None);       // האיטרטור הסתיים.
    /// ```
    ///
    /// `intersperse` יכול להיות מאוד שימושי להצטרף לפריטים של איטרטר באמצעות אלמנט משותף:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// יוצר איטרטור חדש אשר ממקם פריט שנוצר על ידי `separator` בין פריטים סמוכים של האיטרטור המקורי.
    ///
    /// הסגירה תיקרא בדיוק פעם אחת בכל פעם שהפריט מוצב בין שני פריטים סמוכים מהאיטרטור הבסיסי;
    /// באופן ספציפי, הסגירה אינה נקראת אם האיטרטור הבסיסי מניב פחות משני פריטים ולאחר שהפריט האחרון הושג.
    ///
    ///
    /// אם פריט האיטרטור מיישם את [`Clone`], ייתכן שיהיה קל יותר להשתמש ב-[`intersperse`].
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // האלמנט הראשון מ-`v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // המפריד.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // האלמנט הבא מ-`v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // המפריד.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // האלמנט האחרון מ-`v`.
    /// assert_eq!(it.next(), None);               // האיטרטור הסתיים.
    /// ```
    ///
    /// `intersperse_with` ניתן להשתמש במצבים בהם צריך לחשב את המפריד:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // הסגירה שואלת באופן מוטבע את ההקשר שלה ליצירת פריט.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// לוקח סגירה ויוצר איטרטור שקורא לסגירה זו על כל אלמנט.
    ///
    /// `map()` הופך איטרטור אחד למשנהו, באמצעות טיעונו:
    /// משהו שמיישם את [`FnMut`].הוא מייצר איטרטור חדש המכנה סגירה זו על כל אלמנט של האיטרטור המקורי.
    ///
    /// אם אתה טוב לחשוב בסוגים, אתה יכול לחשוב על `map()` ככה:
    /// אם יש לך איטרטור שנותן לך אלמנטים מסוג `A` כלשהו, ואתה רוצה איטרטור מסוג `B` מסוג אחר, אתה יכול להשתמש ב-`map()`, ולהעביר סגירה שלוקחת `A` ומחזירה `B`.
    ///
    ///
    /// `map()` דומה רעיונית לולאת [`for`].עם זאת, מכיוון ש-`map()` עצלן, מומלץ להשתמש בו כאשר אתה כבר עובד עם איטרטורים אחרים.
    /// אם אתה מבצע לולאה כלשהי לתופעת לוואי, זה נחשב לאידיומטי יותר להשתמש ב-[`for`] מאשר ב-`map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// אם אתה עושה איזושהי תופעת לוואי, העדיף את [`for`] על `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // אל תעשה את זה:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // זה אפילו לא יבוצע, כיוון שהוא עצלן.Rust יזהיר אותך על כך.
    ///
    /// // במקום זאת, השתמש ב:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// קורא לסגירה על כל אלמנט של איטרטר.
    ///
    /// זה שווה ערך לשימוש בלולאה [`for`] באיטרטר, אם כי `break` ו-`continue` אינם אפשריים מסגירה.
    /// בדרך כלל יותר אידיומטי להשתמש בלולאת `for`, אך `for_each` עשוי להיות קריא יותר בעת עיבוד פריטים בסוף רשתות איטרור ארוכות יותר.
    ///
    /// במקרים מסוימים `for_each` עשוי להיות גם מהיר יותר מלולאה, מכיוון שהוא ישתמש באיטרציה פנימית במתאמים כמו `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// לדוגמא קטנה כל כך, לולאת `for` עשויה להיות נקייה יותר, אך `for_each` עשוי להיות עדיף בכדי לשמור על סגנון פונקציונלי עם איטרטורים ארוכים יותר:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// יוצר איטרטור המשתמש בסגירה כדי לקבוע אם צריך להניב אלמנט.
    ///
    /// בהינתן אלמנט על הסגירה להחזיר את `true` או `false`.האיטרטור המוחזר יניב רק את האלמנטים שעבורם הסגירה מחזירה נכון.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// מכיוון שהסגירה שעברה ל-`filter()` לוקחת התייחסות, ואיטרטים רבים מתלבטים על פני הפניות, זה מוביל למצב מבלבל אולי, שבו סוג הסגירה הוא התייחסות כפולה:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // צריך שני * ים!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// במקום זאת מקובל להשתמש בהשמדה על הטיעון כדי לפסול אחד:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // שניהם וגם *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// או שניהם:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // שני &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// משכבות אלה.
    ///
    /// שים לב ש-`iter.filter(f).next()` שווה ערך ל-`iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// יוצר איטרטור שמסנן וגם ממפה.
    ///
    /// האיטרטור המוחזר מניב רק את הערכים שעבורם הסגירה שסופקה מחזירה את `Some(value)`.
    ///
    /// `filter_map` ניתן להשתמש בהם כדי להפוך שרשראות של [`filter`] ו-[`map`] לתמציתיות יותר.
    /// הדוגמה שלהלן מראה כיצד ניתן לקצר `map().filter().map()` לשיחה אחת ל-`filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// הנה אותה דוגמה, אך עם [`filter`] ו-[`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// יוצר איטרטור המספק את ספירת האיטרציה הנוכחית וכן את הערך הבא.
    ///
    /// האיטרטור המוחזר מניב זוגות `(i, val)`, כאשר `i` הוא המדד הנוכחי של האיטרציה ו-`val` הוא הערך שהוחזר על ידי האיטרטור.
    ///
    ///
    /// `enumerate()` שומר על ספירתו כ-[`usize`].
    /// אם ברצונך לספור לפי מספר שלם בגודל שונה, הפונקציה [`zip`] מספקת פונקציונליות דומה.
    ///
    /// # התנהגות הצפה
    ///
    /// השיטה אינה שומרת מפני הצפות, ולכן ספירת יותר מאלמנטים של [`usize::MAX`] מפיקה את התוצאה הלא נכונה או את panics.
    /// אם טענות ניפוי באגים מופעלות, מובטח panic.
    ///
    /// # Panics
    ///
    /// האיטרטור שהוחזר עשוי להיות panic אם האינדקס שיש להחזיר יציף [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// יוצר איטרטור שיכול להשתמש ב-[`peek`] כדי להסתכל על האלמנט הבא של האיטראטור מבלי לצרוך אותו.
    ///
    /// מוסיף שיטת [`peek`] לאיטרציה.עיין בתיעוד שלו למידע נוסף.
    ///
    /// שים לב שהאיטרטור הבסיסי עדיין מתקדם כאשר נקרא [`peek`] בפעם הראשונה: על מנת לאחזר את האלמנט הבא, [`next`] נקרא לאיטרטור הבסיסי, ומכאן כל תופעות לוואי (כלומר
    ///
    /// כל דבר אחר מלבד להביא את הערך הבא) של שיטת [`next`] יתרחש.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() מאפשר לנו לראות את future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // אנחנו יכולים peek() מספר פעמים, האיטרטור לא יתקדם
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // לאחר סיום האיטרציה, כך גם peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// יוצר איטרטור ש [`דלג`] על אלמנטים בהתבסס על פרדיקט.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` לוקח סגירה כוויכוח.זה יקרא סגירה זו על כל אלמנט של האיטרטור, ויתעלם מאלמנטים עד שיחזיר `false`.
    ///
    /// לאחר החזרת `false`, עבודת `skip_while()`'s הסתיימה ושאר האלמנטים ניתנים.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// מכיוון שהסגירה שעברה ל-`skip_while()` מתייחסת להתייחסות, ואיטרטורים רבים מתלבטים על פני התייחסויות, זה מוביל למצב מבלבל אולי, שבו סוג טיעון הסגירה הוא התייחסות כפולה:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // צריך שני * ים!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// עצירה לאחר `false` ראשוני:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // אמנם זה היה שקר, מכיוון שכבר קיבלנו שקר, לא נעשה יותר שימוש ב-skip_while()
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// יוצר איטרטור שמניב אלמנטים על בסיס פרדיקט.
    ///
    /// `take_while()` לוקח סגירה כוויכוח.זה יקרא סגירה זו על כל אלמנט של האיטרטור, ויניב אלמנטים בזמן שהוא מחזיר `true`.
    ///
    /// לאחר החזרת `false`, עבודת `take_while()`'s הסתיימה, ושאר האלמנטים מתעלמים.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// מכיוון שהסגירה שעברה ל-`take_while()` לוקחת התייחסות, ואיטרטים רבים מתלבטים על פני הפניות, זה מוביל למצב מבלבל אולי, שבו סוג הסגירה הוא התייחסות כפולה:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // צריך שני * ים!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// עצירה לאחר `false` ראשוני:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // יש לנו יותר אלמנטים שהם פחות מאפס, אבל מכיוון שכבר קיבלנו שקר, take_while() לא משמש יותר
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// מכיוון ש-`take_while()` צריך לבחון את הערך על מנת לראות אם יש לכלול אותו או לא, איטרציות צריכות יראו שהוא מוסר:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// ה-`3` כבר לא שם, מכיוון שהוא נצרך על מנת לראות אם האיטרציה צריכה להיפסק, אך לא הושבה חזרה לאיטרציה.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// יוצר איטרטור שמניב אלמנטים על בסיס פרדיקט ומפות.
    ///
    /// `map_while()` לוקח סגירה כוויכוח.
    /// זה יקרא סגירה זו על כל אלמנט של האיטרטור, ויניב אלמנטים בזמן שהוא מחזיר [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// הנה אותה דוגמה, אך עם [`take_while`] ו-[`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// עצירה לאחר [`None`] ראשוני:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // יש לנו אלמנטים נוספים שיכולים להתאים ל-u32 (4, 5), אך `map_while` החזיר את `None` עבור `-3` (כאשר ה-`predicate` החזיר את `None`) ו-`collect` נעצר ב-`None` הראשון שנתקל בו.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// מכיוון ש-`map_while()` צריך לבחון את הערך על מנת לראות אם יש לכלול אותו או לא, איטרציות צריכות יראו שהוא מוסר:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// ה-`-3` כבר לא שם, מכיוון שהוא נצרך על מנת לראות אם האיטרציה צריכה להיפסק, אך לא הושבה חזרה לאיטרציה.
    ///
    /// שים לב שבניגוד ל-[`take_while`] איטרטור זה אינו ** ממוזג.
    /// כמו כן, לא צויין מה מחזיר איטרטור זה לאחר החזרת ה-[`None`] הראשון.
    /// אם אתה זקוק לאיטרציה התמזגה, השתמש ב-[`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// יוצר איטרטור שמדלג על רכיבי `n` הראשונים.
    ///
    /// לאחר שהם נצרכו, שאר האלמנטים ניתנים.
    /// במקום לבטל שיטה זו ישירות, במקום לבטל את שיטת `nth`.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// יוצר איטרטור שמניב את רכיבי ה-`n` הראשונים שלו.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` משמש לעתים קרובות עם איטרטר אינסופי, כדי להפוך אותו לסופי:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// אם פחות מ-`n` רכיבים זמינים, `take` יגביל את עצמו לגודל האיטרטור הבסיסי:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// מתאם איטרציה הדומה ל-[`fold`] המחזיק במצב פנימי ומייצר איטרטור חדש.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` לוקח שני טיעונים: ערך התחלתי הזורע את המצב הפנימי, וסגירה עם שני טיעונים, הראשון הוא התייחסות משתנה למצב הפנימי והשני אלמנט איטרציה.
    ///
    /// הסגירה יכולה להקצות למצב הפנימי לחלוק מצב בין איטרציות.
    ///
    /// על איטרציה, הסגר יוחל על כל אלמנט של האיטרטור ואת ערך ההחזר מהסגירה, [`Option`], יניב על ידי האיטרטור.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // בכל איטרציה נכפיל את המדינה באלמנט
    ///     *state = *state * x;
    ///
    ///     // ואז נביא את שלילת המדינה
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// יוצר איטרטור שעובד כמו מפה, אך משטח מבנה מקונן.
    ///
    /// מתאם ה-[`map`] שימושי מאוד, אך רק כאשר טיעון הסגירה מייצר ערכים.
    /// אם זה מייצר איטרטור במקום, יש שכבה נוספת של כיוון.
    /// `flat_map()` יסיר שכבה נוספת זו בכוחות עצמה.
    ///
    /// אתה יכול לחשוב על `flat_map(f)` כמו המקבילה הסמנטית של [`מפה`] פינג, ואז ["לשטח"] כמו ב-`map(f).flatten()`.
    ///
    /// דרך נוספת לחשוב על `flat_map()`: סגירת [`מפה`] מחזירה פריט אחד לכל אלמנט, וסגירת `flat_map()`'s מחזירה איטרטור לכל אלמנט.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() מחזיר איטרטור
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// יוצר איטרטור המשטח את המבנה המקונן.
    ///
    /// זה שימושי כאשר יש לך איטרטור של איטרטורים או איטרטור של דברים שניתן להפוך לאיטרטורים ואתה רוצה להסיר רמה אחת של כיוון.
    ///
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// מיפוי ואז רידוד:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() מחזיר איטרטור
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// אתה יכול גם לכתוב את זה מחדש במונחים של [`flat_map()`], וזה עדיף במקרה זה מכיוון שהוא מעביר כוונה בצורה ברורה יותר:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() מחזיר איטרטור
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// רידוד מסיר רק בכל פעם רמה אחת של קינון:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// כאן אנו רואים כי `flatten()` אינו מבצע שיטוח "deep".
    /// במקום זאת, רק רמת קינון אחת מוסרת.כלומר, אם אתה `flatten()` מערך תלת מימדי, התוצאה תהיה דו ממדית ולא חד מימדית.
    /// כדי לקבל מבנה חד ממדי, עליך לבצע `flatten()` שוב.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// יוצר איטרטור שמסתיים אחרי ה-[`None`] הראשון.
    ///
    /// לאחר איטרטור מחזיר את [`None`], שיחות future עשויות להניב [`Some(T)`] שוב או לא.
    /// `fuse()` מתאימה איטרטור ומבטיחה שאחרי מתן [`None`], הוא תמיד יחזיר את [`None`] לנצח.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// // איטרטור שמתחלף בין חלק ללא
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // אם זה אפילו, Some(i32), אחרת אף אחד
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // אנו יכולים לראות את האיטרטור שלנו הולך קדימה ואחורה
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // אולם ברגע שנמזג אותו ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // זה תמיד יחזיר את `None` לאחר הפעם הראשונה.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// עושה משהו עם כל אלמנט של איטרטר, ומעביר את הערך הלאה.
    ///
    /// בעת שימוש באיטוררים, לרוב תשלב כמה מהם יחד.
    /// בזמן שאתה עובד על קוד כזה, כדאי לך לבדוק מה קורה בחלקים שונים בצינור.לשם כך, הכנס שיחה ל-`inspect()`.
    ///
    /// זה נפוץ יותר כי `inspect()` משמש ככלי ניפוי באגים מאשר בקוד הסופי שלך, אך יישומים עשויים למצוא את זה שימושי במצבים מסוימים כאשר יש צורך לבצע רישום שגיאות לפני השלכתם.
    ///
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // רצף איטרציה זה מורכב.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // בואו נוסיף כמה שיחות inspect() כדי לבדוק מה קורה
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// זה יודפס:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// שגיאות רישום לפני השלכתם:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// זה יודפס:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// לווה איטרטור במקום לצרוך אותו.
    ///
    /// זה שימושי כדי לאפשר החלת מתאמי איטרור תוך שמירה על הבעלות על האיטרטור המקורי.
    ///
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // אם ננסה להשתמש באיטר שוב, זה לא יעבוד.
    /// // השורה הבאה נותנת "שגיאה: שימוש בערך שהועבר: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // בוא ננסה את זה שוב
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // במקום זאת, אנו מוסיפים .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // עכשיו זה בסדר גמור:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// הופך איטרטור לאוסף.
    ///
    /// `collect()` יכול לקחת כל דבר שניתן לצרוב ולהפוך אותו לאוסף רלוונטי.
    /// זו אחת השיטות החזקות יותר בספרייה הסטנדרטית, המשמשת במגוון הקשרים.
    ///
    /// התבנית הבסיסית ביותר בה משתמשים ב-`collect()` היא להפוך אוסף אחד לאחר.
    /// אתה לוקח אוסף, מתקשר אליו ל-[`iter`], מבצע חבורה של טרנספורמציות ואז `collect()` בסוף.
    ///
    /// `collect()` יכול גם ליצור מופעים מסוגים שאינם אוספים אופייניים.
    /// לדוגמא, ניתן לבנות [`String`] מ [`char`], וניתן לאסוף איטרטור של פריטי [`Result<T, E>`][`Result`] ל-`Result<Collection<T>, E>`.
    ///
    /// ראה את הדוגמאות להלן לקבלת מידע נוסף.
    ///
    /// מכיוון ש-`collect()` כל כך כללי, הוא עלול לגרום לבעיות בהסקת סוג.
    /// ככזה, `collect()` הוא אחת הפעמים הבודדות שתראה את התחביר המכונה בחיבה 'turbofish': `::<>`.
    /// זה עוזר לאלגוריתם ההסקות להבין באופן ספציפי לאיזה אוסף אתה מנסה לאסוף.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// שים לב שהיינו זקוקים ל-`: Vec<i32>` בצד שמאל.הסיבה לכך היא שנוכל לאסוף, למשל, [`VecDeque<T>`] במקום זאת:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// שימוש ב-'turbofish' במקום להוסיף הערות ל-`doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// מכיוון של-`collect()` אכפת רק ממה שאתה אוסף, אתה עדיין יכול להשתמש ברמז חלקי, `_`, עם הטורפופיש:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// שימוש ב-`collect()` ליצירת [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// אם יש לך רשימה של [`תוצאה<T, E>`][`תוצאה`] s, אתה יכול להשתמש ב-`collect()` כדי לראות אם אחד מהם נכשל:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // נותן לנו את השגיאה הראשונה
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // נותן לנו את רשימת התשובות
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// צורכת איטרטור ויוצרת ממנו שני אוספים.
    ///
    /// הפרדיקט המועבר ל-`partition()` יכול להחזיר את `true`, או `false`.
    /// `partition()` מחזיר זוג, שכל האלמנטים שעבורם הוא החזיר את `true`, וכל האלמנטים שעבורם הוא החזיר את `false`.
    ///
    ///
    /// ראה גם [`is_partitioned()`] ו-[`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// סדר מחדש את האלמנטים של איטרטור זה *במקום* על פי הקביעה הנתונה, כך שכל אלה שמחזירים `true` מקדימים את כל אלה שמחזירים `false`.
    ///
    /// מחזירה את מספר רכיבי `true` שנמצאו.
    ///
    /// הסדר היחסי של פריטים המחולקים אינו נשמר.
    ///
    /// ראה גם [`is_partitioned()`] ו-[`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // החלוקה במקום בין ערבים לסיכויים
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: האם עלינו לדאוג שהספירה תעלה על גדותיה?הדרך היחידה לקבל יותר מ
        // `usize::MAX` הפניות משתנות הן עם ZSTs, שאינם שימושיים למחיצה ...

        // פונקציות "factory" סגורות אלה קיימות כדי למנוע כלליות ב-`Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // מצא שוב ושוב את ה-`false` והחלף אותו עם ה-`true` האחרון.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// בודק אם האלמנטים של איטרטור זה מחולקים על פי הקביעה הנתונה, כך שכל אלה שמחזירים `true` קודמים לכל אלה שמחזירים `false`.
    ///
    ///
    /// ראה גם [`partition()`] ו-[`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // או שכל הפריטים בודקים את `true`, או שהסעיף הראשון נעצר ב-`false` ואנחנו בודקים שאין עוד פריטי `true` אחרי זה.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// שיטת איטרטור החלת פונקציה כל עוד היא חוזרת בהצלחה ומייצרת ערך סופי יחיד.
    ///
    /// `try_fold()` לוקח שני ארגומנטים: ערך התחלתי, וסגירה עם שני ארגומנטים: 'accumulator' ואלמנט.
    /// הסגירה חוזרת בהצלחה, עם הערך שצריך להיות לצבר לאיטרציה הבאה, או שהיא מחזירה כישלון, עם ערך שגיאה המופץ בחזרה למתקשר מיד (short-circuiting).
    ///
    ///
    /// הערך ההתחלתי הוא הערך שיהיה לצבר בשיחה הראשונה.אם יישום הסגירה הצליח כנגד כל אלמנט של האיטרטור, `try_fold()` מחזיר את המצבר הסופי כהצלחה.
    ///
    /// קיפול שימושי בכל פעם שיש לך אוסף של משהו ורוצה לייצר ממנו ערך יחיד.
    ///
    /// # הערה למיישמים
    ///
    /// לכמה משיטות (forward) אחרות יש יישומי ברירת מחדל מבחינת זו, לכן נסה ליישם זאת במפורש אם הוא יכול לעשות משהו טוב יותר מאשר יישום לולאת ברירת המחדל של `for`.
    ///
    /// בפרט, נסה להתקשר לשיחה זו `try_fold()` על החלקים הפנימיים מהם מורכב האיטרטור הזה.
    /// אם יש צורך בשיחות מרובות, מפעיל ה-`?` עשוי להיות נוח לשרשר את ערך הצבר, אך היזהר מכל הזרמים שיש צורך לשמור עליהם לפני אותם חזרות מוקדמות.
    /// זוהי שיטת `&mut self`, כך שהאיטרציה חייבת להיות חוזרת לאחר פגיעה בשגיאה כאן.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // הסכום המסומן של כל מרכיבי המערך
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // סכום זה עולה על גדותיו כאשר מוסיפים את האלמנט 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // מכיוון שהוא קצר במעגל, האלמנטים הנותרים עדיין זמינים דרך האיטרטור.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// שיטת איטרטור המפעילה פונקציה נופלת על כל פריט באיטרטור, ועוצרת בשגיאה הראשונה ומחזירה שגיאה זו.
    ///
    ///
    /// ניתן לחשוב על כך גם כצורה הניתנת לטעות של [`for_each()`] או כגרסה חסרת המדינה של [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // זה היה קצר חשמלי, כך שהפריטים הנותרים עדיין נמצאים באיטרציה:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// מקפל כל אלמנט לצבר על ידי הפעלת פעולה, והחזרת התוצאה הסופית.
    ///
    /// `fold()` לוקח שני ארגומנטים: ערך התחלתי, וסגירה עם שני ארגומנטים: 'accumulator' ואלמנט.
    /// הסגירה מחזירה את הערך שצריך להיות לצבר לאיטרציה הבאה.
    ///
    /// הערך ההתחלתי הוא הערך שיהיה לצבר בשיחה הראשונה.
    ///
    /// לאחר החלת סגירה זו על כל אלמנט של האיטרטור, `fold()` מחזיר את המצבר.
    ///
    /// פעולה זו נקראת לפעמים 'reduce' או 'inject'.
    ///
    /// קיפול שימושי בכל פעם שיש לך אוסף של משהו ורוצה לייצר ממנו ערך יחיד.
    ///
    /// Note: `fold()`, ושיטות דומות החוצות את כל האיטרטור, עשויות שלא להסתיים עבור איטרטורים אינסופיים, אפילו לא ב-traits שתוצאה ניתנת לקביעה בזמן סופי.
    ///
    /// Note: ניתן להשתמש ב-[`reduce()`] כדי להשתמש באלמנט הראשון כערך ההתחלתי, אם סוג המצבר וסוג הפריט זהים.
    ///
    /// # הערה למיישמים
    ///
    /// לכמה משיטות (forward) אחרות יש יישומי ברירת מחדל מבחינת זו, לכן נסה ליישם זאת במפורש אם הוא יכול לעשות משהו טוב יותר מאשר יישום לולאת ברירת המחדל של `for`.
    ///
    ///
    /// בפרט, נסה להתקשר לשיחה זו `fold()` על החלקים הפנימיים מהם מורכב האיטרטור הזה.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // סכום כל מרכיבי המערך
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// בואו נעבור על כל שלב של איטרציה כאן:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// וכך, התוצאה הסופית שלנו, `6`.
    ///
    /// זה נפוץ אצל אנשים שלא השתמשו הרבה באיטוררים להשתמש בלולאת `for` עם רשימה של דברים לבניית תוצאה.ניתן להפוך אותם ל-`fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // לולאה:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // הם אותו הדבר
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// מצמצם את האלמנטים לאחד, על ידי הפעלת פעולת צמצום שוב ושוב.
    ///
    /// אם האיטרטור ריק, מחזיר את [`None`];אחרת, מחזיר את תוצאת ההפחתה.
    ///
    /// עבור איטרטורים עם לפחות אלמנט אחד, זהה ל-[`fold()`] כאשר האלמנט הראשון של האיטרטור הוא הערך ההתחלתי, ומקפל לתוכו כל אלמנט עוקב.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// מצא את הערך המרבי:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// בודק אם כל רכיב באיטרטור תואם פרדיקט.
    ///
    /// `all()` לוקח סגירה שמחזירה את `true` או `false`.הוא מחיל סגירה זו על כל אלמנט של האיטרטור, ואם כולם מחזירים את `true`, כך גם `all()`.
    /// אם מישהו מהם מחזיר את `false`, הוא מחזיר את `false`.
    ///
    /// `all()` הוא קצר חשמלי;במילים אחרות, הוא יפסיק את העיבוד ברגע שהוא ימצא `false`, בהתחשב בכך שלא משנה מה יקרה עוד, התוצאה תהיה גם `false`.
    ///
    ///
    /// איטרטור ריק מחזיר את `true`.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// עוצר ב-`false` הראשון:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // אנחנו עדיין יכולים להשתמש ב-`iter` מכיוון שיש יותר אלמנטים.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// בודק אם אלמנט כלשהו באיטרטור תואם פרדיקט.
    ///
    /// `any()` לוקח סגירה שמחזירה את `true` או `false`.הוא מחיל סגירה זו על כל אלמנט של האיטרטור, ואם מישהו מהם מחזיר את `true`, כך גם `any()`.
    /// אם כולם מחזירים את `false`, הוא מחזיר את `false`.
    ///
    /// `any()` הוא קצר חשמלי;במילים אחרות, הוא יפסיק את העיבוד ברגע שהוא ימצא `true`, בהתחשב בכך שלא משנה מה יקרה עוד, התוצאה תהיה גם `true`.
    ///
    ///
    /// איטרטור ריק מחזיר את `false`.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// עוצר ב-`true` הראשון:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // אנחנו עדיין יכולים להשתמש ב-`iter` מכיוון שיש יותר אלמנטים.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// מחפש אלמנט של איטרטור העונה על פרדיקט.
    ///
    /// `find()` לוקח סגירה שמחזירה את `true` או `false`.
    /// הוא מחיל סגירה זו על כל אלמנט של האיטרטור, ואם מישהו מהם מחזיר את `true`, אז `find()` מחזיר את [`Some(element)`].
    /// אם כולם מחזירים את `false`, הוא מחזיר את [`None`].
    ///
    /// `find()` הוא קצר חשמלי;במילים אחרות, הוא יפסיק את העיבוד ברגע שהסגירה תחזור ל-`true`.
    ///
    /// מכיוון ש-`find()` לוקח התייחסות, ואיטרטים רבים חוזרים על פני הפניות, זה מוביל למצב מבלבל אולי שבו הטיעון הוא התייחסות כפולה.
    ///
    /// אתה יכול לראות את האפקט הזה בדוגמאות שלהלן, עם `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// עוצר ב-`true` הראשון:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // אנחנו עדיין יכולים להשתמש ב-`iter` מכיוון שיש יותר אלמנטים.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// שים לב ש-`iter.find(f)` שווה ערך ל-`iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// החל פונקציה על אלמנטים של iterator ומחזיר את התוצאה הראשונה שאיננה אף אחד.
    ///
    ///
    /// `iter.find_map(f)` שווה ערך ל-`iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// החל פונקציה על רכיבי iterator ומחזיר את התוצאה האמיתית הראשונה או את השגיאה הראשונה.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// מחפש אלמנט באיטרטור ומחזיר את האינדקס שלו.
    ///
    /// `position()` לוקח סגירה שמחזירה את `true` או `false`.
    /// הוא מחיל סגירה זו על כל אלמנט של האיטרטור, ואם אחד מהם מחזיר את `true`, אז `position()` מחזיר את [`Some(index)`].
    /// אם כולם מחזירים את `false`, הוא מחזיר את [`None`].
    ///
    /// `position()` הוא קצר חשמלי;במילים אחרות, הוא יפסיק את העיבוד ברגע שהוא ימצא `true`.
    ///
    /// # התנהגות הצפה
    ///
    /// השיטה אינה שומרת מפני הצפות, כך שאם ישנם יותר מ-[`usize::MAX`] אלמנטים שאינם תואמים, היא מפיקה את התוצאה הלא נכונה או את panics.
    ///
    /// אם טענות ניפוי באגים מופעלות, מובטח panic.
    ///
    /// # Panics
    ///
    /// פונקציה זו עשויה panic אם לאיטרטור יש יותר מ-`usize::MAX` אלמנטים שאינם תואמים.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// עוצר ב-`true` הראשון:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // אנחנו עדיין יכולים להשתמש ב-`iter` מכיוון שיש יותר אלמנטים.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // האינדקס שהוחזר תלוי במצב החזרה
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// מחפש רכיב באיטרטור מימין ומחזיר את האינדקס שלו.
    ///
    /// `rposition()` לוקח סגירה שמחזירה את `true` או `false`.
    /// הוא מחיל סגירה זו על כל אלמנט של האיטרטור, החל מהסוף, ואם אחד מהם מחזיר את `true`, אז `rposition()` מחזיר את [`Some(index)`].
    ///
    /// אם כולם מחזירים את `false`, הוא מחזיר את [`None`].
    ///
    /// `rposition()` הוא קצר חשמלי;במילים אחרות, הוא יפסיק את העיבוד ברגע שהוא ימצא `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// עוצר ב-`true` הראשון:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // אנחנו עדיין יכולים להשתמש ב-`iter` מכיוון שיש יותר אלמנטים.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // אין צורך בבדיקת הצפה כאן מכיוון ש-`ExactSizeIterator` מרמז שמספר האלמנטים משתלב ב-`usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// מחזיר את האלמנט המרבי של איטרטור.
    ///
    /// אם מספר אלמנטים הם מקסימלים באותה מידה, האלמנט האחרון מוחזר.
    /// אם האיטרטור ריק, [`None`] מוחזר.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// מחזיר את האלמנט המינימלי של איטרטור.
    ///
    /// אם כמה אלמנטים הם מינימליים באותה מידה, המרכיב הראשון מוחזר.
    /// אם האיטרטור ריק, [`None`] מוחזר.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// מחזיר את האלמנט שנותן את הערך המרבי מהפונקציה שצוינה.
    ///
    ///
    /// אם מספר אלמנטים הם מקסימלים באותה מידה, האלמנט האחרון מוחזר.
    /// אם האיטרטור ריק, [`None`] מוחזר.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// מחזיר את האלמנט שנותן את הערך המרבי ביחס לפונקציית ההשוואה שצוינה.
    ///
    ///
    /// אם מספר אלמנטים הם מקסימלים באותה מידה, האלמנט האחרון מוחזר.
    /// אם האיטרטור ריק, [`None`] מוחזר.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// מחזיר את האלמנט שנותן את הערך המינימלי מהפונקציה שצוינה.
    ///
    ///
    /// אם כמה אלמנטים הם מינימליים באותה מידה, המרכיב הראשון מוחזר.
    /// אם האיטרטור ריק, [`None`] מוחזר.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// מחזיר את האלמנט שנותן את הערך המינימלי ביחס לפונקציית ההשוואה שצוינה.
    ///
    ///
    /// אם כמה אלמנטים הם מינימליים באותה מידה, המרכיב הראשון מוחזר.
    /// אם האיטרטור ריק, [`None`] מוחזר.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// הופך כיוון של איטרטור.
    ///
    /// בדרך כלל איטרציות חוזרות משמאל לימין.
    /// לאחר השימוש ב-`rev()`, איטרטור יחזור במקום מימין לשמאל.
    ///
    /// זה אפשרי רק אם לאיטרטור יש סוף, ולכן `rev()` עובד רק ב-[`DoubleEndedIterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// ממיר איטרטר של זוגות לזוג מכולות.
    ///
    /// `unzip()` צורכת איטרטור שלם של זוגות, ומייצר שני אוספים: אחד מהאלמנטים השמאליים של הזוגות, ואחד מהאלמנטים הימניים.
    ///
    ///
    /// פונקציה זו היא, במובן מסוים, ההפך מ-[`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// יוצר איטרטור שמעתיק את כל האלמנטים שלו.
    ///
    /// זה שימושי כשיש לך איטרטור מעל `&T`, אבל אתה צריך איטרטור מעל `T`.
    ///
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // המועתק זהה ל-.map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// יוצר איטרטור אשר ["משובט"] את כל האלמנטים שלו.
    ///
    /// זה שימושי כשיש לך איטרטור מעל `&T`, אבל אתה צריך איטרטור מעל `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // משובט זהה ל-.map(|&x| x), למספרים שלמים
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// חוזר על איטרטר בלי סוף.
    ///
    /// במקום לעצור ב-[`None`], האיטרטור יתחיל מחדש מההתחלה.לאחר איטרציה שוב, הוא יתחיל שוב בהתחלה.ושוב.
    /// ושוב.
    /// Forever.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// מסכם את האלמנטים של איטרטור.
    ///
    /// לוקח כל אלמנט, מוסיף אותם יחד ומחזיר את התוצאה.
    ///
    /// איטרטור ריק מחזיר את ערך האפס של הסוג.
    ///
    /// # Panics
    ///
    /// בעת קריאה ל-`sum()` ומחזירים סוג שלם פרימיטיבי, שיטה זו תזכה ב-panic אם החישוב עולה על גדותיו וקביעות ניפוי באגים מופעלות.
    ///
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// מתבטל על פני כל האיטרטור, ומכפיל את כל האלמנטים
    ///
    /// איטרטור ריק מחזיר את הערך האחד מהסוג.
    ///
    /// # Panics
    ///
    /// בעת קריאה ל-`product()` ומחזירים סוג שלם פרימיטיבי, השיטה תהיה panic אם החישוב עולה על גדותיו וקביעות ניפוי באגים מופעלות.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) משווה את האלמנטים של [`Iterator`] זה לאלו של אחר.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) משווה את האלמנטים של [`Iterator`] זה לאלו של אחר ביחס לפונקציית ההשוואה שצוינה.
    ///
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) משווה את האלמנטים של [`Iterator`] זה לאלו של אחר.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) משווה את האלמנטים של [`Iterator`] זה לאלו של אחר ביחס לפונקציית ההשוואה שצוינה.
    ///
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// קובע אם האלמנטים של [`Iterator`] זה שווים לאלו של אחר.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// קובע אם האלמנטים של [`Iterator`] זה שווים לאלו של אחר ביחס לפונקציית השוויון שצוינה.
    ///
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// קובע אם האלמנטים של [`Iterator`] זה אינם שווים לאלו של אחר.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// קובע אם האלמנטים של [`Iterator`] זה [lexicographically](Ord#lexicographical-comparison) פחות מאלו של אחר.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// קובע אם האלמנטים של [`Iterator`] זה [lexicographically](Ord#lexicographical-comparison) פחות או שווה לאלו של אחר.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// קובע אם האלמנטים של [`Iterator`] זה גדולים [lexicographically](Ord#lexicographical-comparison) מאלו של אחר.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// קובע אם האלמנטים של [`Iterator`] זה גדולים [lexicographically](Ord#lexicographical-comparison) מאלה של אחרים.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// בודק אם האלמנטים של איטרטור זה ממוינים.
    ///
    /// כלומר, עבור כל רכיב `a` והרכיב הבא שלו `b`, `a <= b` חייב להחזיק.אם האיטרטור מניב אפס בדיוק או אלמנט אחד, `true` מוחזר.
    ///
    /// שים לב שאם `Self::Item` הוא `PartialOrd` בלבד, אך לא `Ord`, ההגדרה שלעיל מרמזת כי פונקציה זו מחזירה את `false` אם שני פריטים עוקבים אינם דומים.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// בודק אם האלמנטים של איטרטור זה ממוינים באמצעות פונקציית ההשוואה הנתונה.
    ///
    /// במקום להשתמש ב-`PartialOrd::partial_cmp`, פונקציה זו משתמשת בפונקציה `compare` הנתונה כדי לקבוע את הסדר של שני אלמנטים.
    /// מלבד זאת, זה שווה ערך ל-[`is_sorted`];עיין בתיעוד שלו למידע נוסף.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// בודק אם האלמנטים של איטרטור זה ממוינים באמצעות פונקציית חילוץ המפתח הנתונה.
    ///
    /// במקום להשוות בין אלמנטים של האיטרטור ישירות, פונקציה זו משווה את מקשי האלמנטים, כפי שנקבע על ידי `f`.
    /// מלבד זאת, זה שווה ערך ל-[`is_sorted`];עיין בתיעוד שלו למידע נוסף.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// ראה [TrustedRandomAccess]
    // השם יוצא הדופן הוא להימנע מהתנגשויות שמות ברזולוציית השיטה ראה #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}