/// איטרטור שתמיד ממשיך להניב `None` כשהוא מותש.
///
/// הקריאה הבאה לאיטרטור התמזג שהחזיר את `None` פעם אחת מובטחת שתחזיר את [`None`] שוב.
/// trait זה צריך להיות מיושם על ידי כל האיטרטורים שמתנהגים כך מכיוון שהוא מאפשר אופטימיזציה של [`Iterator::fuse()`].
///
///
/// Note: באופן כללי, אתה לא צריך להשתמש ב-`FusedIterator` בגבולות כלליים אם אתה זקוק לאיטרציה התמזגה.
/// במקום זאת, אתה פשוט צריך להתקשר ל-[`Iterator::fuse()`] באיטרטור.
/// אם האיטרטור כבר התמזג, עטיפת ה-[`Fuse`] הנוספת תהיה פעולה ללא עונש ביצוע.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// איטרטור המדווח על אורך מדויק באמצעות size_hint.
///
/// האיטרטור מדווח על רמז לגודל שבו הוא מדויק (הגבול התחתון שווה לגבול העליון), או שהגבול העליון הוא [`None`].
///
/// הגבול העליון חייב להיות [`None`] רק אם אורך האיטרטור בפועל גדול מ-[`usize::MAX`].
/// במקרה כזה, הגבול התחתון חייב להיות [`usize::MAX`], וכתוצאה מכך [`Iterator::size_hint()`] של `(usize::MAX, None)`.
///
/// על האיטרטור לייצר בדיוק את מספר האלמנטים עליו דיווח או לסטות לפני שהוא מגיע לסוף.
///
/// # Safety
///
/// יש ליישם את trait רק עם קיום החוזה.
/// צרכני trait זה חייבים לבדוק את הגבול העליון של [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// איטרטור שכאשר מניב פריט ייקח לפחות אלמנט אחד מה-[`SourceIter`] הבסיסי שלו.
///
/// קוראים לכל שיטה שמקדמת את האיטרטור, למשל
/// [`next()`] או [`try_fold()`], מבטיח כי לכל שלב לפחות ערך אחד ממקור הבסיס של האיטרטור הועבר והתוצאה של שרשרת האיטרטור יכולה להיות מוחדרת במקומה, בהנחה שמגבלות מבניות של המקור מאפשרות הכנסה כזו.
///
/// במילים אחרות trait זה מצביע על כך שניתן לאסוף צינור איטראטור במקום.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}