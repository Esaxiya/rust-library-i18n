/// איטרטור שיודע את אורכו המדויק.
///
/// רבים [`איטרטור`] לא יודעים כמה פעמים הם יחזרו, אבל חלקם כן.
/// אם איטרטור יודע כמה פעמים הוא יכול לחזור, מתן גישה למידע זה יכול להיות שימושי.
/// לדוגמא, אם אתה רוצה לחזור לאחור, התחלה טובה היא לדעת היכן הסוף.
///
/// בעת הטמעת `ExactSizeIterator`, עליך ליישם גם את [`Iterator`].
/// כשעושים זאת, היישום של [`Iterator::size_hint`]*חייב* להחזיר את הגודל המדויק של האיטרטור.
///
/// לשיטת [`len`] יש יישום ברירת מחדל, לכן בדרך כלל לא כדאי ליישם אותה.
/// עם זאת, יתכן שתוכל לספק יישום ביצועי יותר מברירת המחדל, ולכן הגיוס במקרה זה הגיוני.
///
///
/// שים לב ש-trait זה trait בטוח וככזה *לא* וגם *לא יכול* להבטיח שהאורך המוחזר נכון.
/// המשמעות היא שקוד `unsafe`**לא חייב** להסתמך על נכונות [`Iterator::size_hint`].
/// ה-[`TrustedLen`](super::marker::TrustedLen) trait הבלתי יציב והלא בטוח מעניק אחריות נוספת זו.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// // טווח סופי יודע בדיוק כמה פעמים הוא יחזור
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// ב-[module-level docs], יישמנו [`Iterator`], `Counter`.
/// בואו נשתמש ב-`ExactSizeIterator` גם עבורו:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // אנו יכולים לחשב בקלות את מספר החזרות שנותר.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // ועכשיו נוכל להשתמש בזה!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// מחזירה את אורכו המדויק של האיטרטור.
    ///
    /// היישום מבטיח שהאיטרטור יחזיר בדיוק `len()` יותר פעמים ערך [`Some(T)`], לפני שיחזיר את [`None`].
    ///
    /// לשיטה זו יש מימוש ברירת מחדל, ולכן בדרך כלל לא כדאי ליישם אותה ישירות.
    /// עם זאת, אם אתה יכול לספק יישום יעיל יותר, אתה יכול לעשות זאת.
    /// ראה דוגמאות במסמכי [trait-level].
    ///
    /// לפונקציה זו יש אותן הבטחות בטיחות כמו לפונקציה [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// // טווח סופי יודע בדיוק כמה פעמים הוא יחזור
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: קביעה זו מתגוננת יתר על המידה, אך היא בודקת את המשתנה
        // מובטח על ידי trait.
        // אם trait היה rust פנימי, נוכל להשתמש ב debug_assert !;assert_eq!יבדוק גם את כל יישומי המשתמשים של Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// מחזירה את `true` אם האיטרטור ריק.
    ///
    /// לשיטה זו יש מימוש ברירת מחדל באמצעות [`ExactSizeIterator::len()`], כך שאינך צריך ליישם אותה בעצמך.
    ///
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}