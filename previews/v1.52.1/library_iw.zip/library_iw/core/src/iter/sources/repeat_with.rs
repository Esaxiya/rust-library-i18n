use crate::iter::{FusedIterator, TrustedLen};

/// יוצר איטרטור חדש החוזר על אלמנטים מסוג `A` בלי סוף על ידי יישום הסגר המסופק, מהדר, `F: FnMut() -> A`.
///
/// פונקציית `repeat_with()` קוראת למהדר שוב ושוב.
///
/// איטרטורים אינסופיים כמו `repeat_with()` משמשים לעתים קרובות עם מתאמים כמו [`Iterator::take()`], על מנת להפוך אותם סופיים.
///
/// אם סוג האלמנט של האיטרטור שאתה זקוק לו מיישם את [`Clone`], וזה בסדר לשמור את אלמנט המקור בזיכרון, עליך להשתמש במקום זאת בפונקציה [`repeat()`].
///
///
/// איטרטור המיוצר על ידי `repeat_with()` אינו [`DoubleEndedIterator`].
/// אם אתה זקוק ל-`repeat_with()` להחזרת [`DoubleEndedIterator`], פתח גיליון של GitHub המסביר את מקרה השימוש שלך.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// use std::iter;
///
/// // נניח שיש לנו ערך כלשהו מסוג שאינו `Clone` או שאינו רוצה לזכור עדיין כי הוא יקר:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // ערך מסוים לנצח:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// שימוש במוטציה והולך סופית:
///
/// ```rust
/// use std::iter;
///
/// // מהאפס אל הכוח השלישי מבין שניים:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... ועכשיו סיימנו
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// איטרטור החוזר על אלמנטים מסוג `A` בלי סוף על ידי יישום הסגר `F: FnMut() -> A` שסופק.
///
///
/// `struct` זה נוצר על ידי פונקציית [`repeat_with()`].
/// עיין בתיעוד שלו לקבלת מידע נוסף.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}