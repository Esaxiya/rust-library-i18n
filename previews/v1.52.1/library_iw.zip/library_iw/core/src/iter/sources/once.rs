use crate::iter::{FusedIterator, TrustedLen};

/// יוצר איטרטור שמניב אלמנט פעם אחת בדיוק.
///
/// זה משמש בדרך כלל כדי להתאים ערך יחיד ל-[`chain()`] מסוגים אחרים של איטרציה.
/// אולי יש לך איטרטור שמכסה כמעט הכל, אבל אתה צריך מקרה מיוחד נוסף.
/// אולי יש לך פונקציה שעובדת על איטרטורים, אבל אתה רק צריך לעבד ערך אחד.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// use std::iter;
///
/// // האחד הוא המספר הבודד ביותר
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // רק אחד, זה כל מה שאנחנו מקבלים
/// assert_eq!(None, one.next());
/// ```
///
/// שרשור יחד עם איטרטור אחר.
/// בואו נגיד שאנחנו רוצים לחזור על כל קובץ בספריית `.foo`, אלא גם על קובץ תצורה,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // עלינו להמיר מאיטרטור של DirEntry-s לאיטרטור של PathBufs, לכן אנו משתמשים במפה
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // עכשיו, האיטרטור שלנו רק לקובץ התצורה שלנו
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // שרשר את שני האיטרטורים יחד לאיטרטור אחד גדול
/// let files = dirs.chain(config);
///
/// // זה ייתן לנו את כל הקבצים ב-.foo כמו גם ב-.foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// איטרטור שמניב אלמנט פעם אחת בדיוק.
///
/// `struct` זה נוצר על ידי פונקציית [`once()`].עיין בתיעוד שלו לקבלת מידע נוסף.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}