use crate::iter::{FusedIterator, TrustedLen};

/// יוצר איטרטר חדש החוזר בלי סוף על אלמנט יחיד.
///
/// פונקציית `repeat()` חוזרת על ערך יחיד שוב ושוב.
///
/// איטרטורים אינסופיים כמו `repeat()` משמשים לעתים קרובות עם מתאמים כמו [`Iterator::take()`], על מנת להפוך אותם סופיים.
///
/// אם סוג האלמנט של האיטרטור הדרוש לך אינו מיישם את `Clone`, או אם אינך מעוניין לשמור את האלמנט החוזר בזיכרון, תוכל להשתמש בפונקציה [`repeat_with()`] במקום זאת.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// use std::iter;
///
/// // המספר ארבע 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // כן, עדיין ארבע
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// הולך סופי עם [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // הדוגמה האחרונה הייתה יותר מדי ארבע.שיהיה לנו רק ארבע ארבע.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... ועכשיו סיימנו
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// איטרטר החוזר על אלמנט בלי סוף.
///
/// `struct` זה נוצר על ידי פונקציית [`repeat()`].עיין בתיעוד שלו לקבלת מידע נוסף.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}