use crate::iter::{FusedIterator, TrustedLen};

/// יוצר איטרטור שיוצר ערך בעצלתיים פעם אחת בדיוק על ידי הפעלת הסגירה הניתנת.
///
/// זה משמש בדרך כלל כדי להתאים מחולל ערכים יחיד ל-[`chain()`] מסוגים אחרים של איטרציה.
/// אולי יש לך איטרטור שמכסה כמעט הכל, אבל אתה צריך מקרה מיוחד נוסף.
/// אולי יש לך פונקציה שעובדת על איטרטורים, אבל אתה רק צריך לעבד ערך אחד.
///
/// שלא כמו [`once()`], פונקציה זו תניב את הערך בעצלתיים על פי בקשה.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// use std::iter;
///
/// // האחד הוא המספר הבודד ביותר
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // רק אחד, זה כל מה שאנחנו מקבלים
/// assert_eq!(None, one.next());
/// ```
///
/// שרשור יחד עם איטרטור אחר.
/// בואו נגיד שאנחנו רוצים לחזור על כל קובץ בספריית `.foo`, אלא גם על קובץ תצורה,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // עלינו להמיר מאיטרטור של DirEntry-s לאיטרטור של PathBufs, לכן אנו משתמשים במפה
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // עכשיו, האיטרטור שלנו רק לקובץ התצורה שלנו
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // שרשר את שני האיטרטורים יחד לאיטרטור אחד גדול
/// let files = dirs.chain(config);
///
/// // זה ייתן לנו את כל הקבצים ב-.foo כמו גם ב-.foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// איטרטור המניב אלמנט יחיד מסוג `A` על ידי החלת הסגירה הניתנת `F: FnOnce() -> A`.
///
///
/// `struct` זה נוצר על ידי פונקציית [`once_with()`].
/// עיין בתיעוד שלו לקבלת מידע נוסף.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}