//! איטרציה חיצונית מורכבת.
//!
//! אם מצאת את עצמך עם אוסף כלשהו, ואתה זקוק לביצוע פעולה על מרכיבי האוסף האמור, תיתקל במהירות ב-'iterators'.
//! משתמשים באינטרטורים בקוד Rust אידיומטי, ולכן כדאי להכיר אותם.
//!
//! לפני שנסביר יותר, בואו נדבר על אופן הבנייה של מודול זה:
//!
//! # Organization
//!
//! מודול זה מאורגן במידה רבה לפי סוג:
//!
//! * [Traits] הם חלק הליבה: traits אלה מגדירים איזה סוג של איטרטורים קיימים ומה אתה יכול לעשות איתם.השיטות של traits אלה שווה להשקיע זמן לימוד נוסף.
//! * [Functions] לספק כמה דרכים מועילות ליצור כמה איטרטורים בסיסיים.
//! * [Structs] הם לרוב סוגי ההחזרה של השיטות השונות ב-traits של מודול זה.בדרך כלל תרצה לבחון את השיטה שיוצרת את `struct`, ולא את ה-`struct` עצמו.
//! לפרטים נוספים על הסיבה, ראו '[Implementing Iterator](#implement-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! זהו זה!בואו נתעמק באיטרטורים.
//!
//! # Iterator
//!
//! הלב והנשמה של מודול זה הוא [`Iterator`] trait.הליבה של [`Iterator`] נראית כך:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! לאיטרטור יש שיטה, [`next`], שכאשר היא נקראת מחזירה ["אפשרות"]<Item>`.
//! [`next`] יחזיר את [`Some(Item)`] כל עוד יש אלמנטים, וברגע שמיצו את כולם, יחזיר את `None` כדי לציין שהאיטרציה הסתיימה.
//! איטרטורים בודדים עשויים לבחור לחדש את האיטרציה, ולכן קריאה שוב ל-[`next`] עשויה להתחיל להחזיר את [`Some(Item)`] שוב או לא, בשלב מסוים (למשל, ראה [`TryIter`]).
//!
//!
//! ההגדרה המלאה של [Iterator] כוללת מספר שיטות אחרות, אך הן שיטות ברירת מחדל, הבנויות על גבי [`next`], וכך אתה מקבל אותן בחינם.
//!
//! גם מחמירים ניתנים להלחנה, וזה מקובל לשרשר אותם יחד כדי לבצע צורות עיבוד מורכבות יותר.עיין בסעיף [Adapters](#adapters) להלן לפרטים נוספים.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # שלושת צורות האיטרציה
//!
//! ישנן שלוש שיטות נפוצות שיכולות ליצור איטרטורים מאוסף:
//!
//! * `iter()`, אשר חוזר על עצמו מעל `&T`.
//! * `iter_mut()`, אשר חוזר על עצמו מעל `&mut T`.
//! * `into_iter()`, אשר חוזר על עצמו מעל `T`.
//!
//! דברים שונים בספרייה הסטנדרטית עשויים ליישם אחד או יותר מהשלושה, במידת הצורך.
//!
//! # יישום איטרטור
//!
//! יצירת איטרטור משלך כוללת שני שלבים: יצירת `struct` כדי להחזיק את מצב האיטרטור, ולאחר מכן יישום [`Iterator`] עבור אותו `struct`.
//! זו הסיבה שיש כל כך הרבה `מבנים` במודול זה: יש אחד לכל איטרטור ומתאם איטרציה.
//!
//! בואו נכין איטרטור בשם `Counter` שנמנה בין `1` ל-`5`:
//!
//! ```
//! // ראשית, המבנה:
//!
//! /// איטרטור שנמנה בין אחד לחמש
//! struct Counter {
//!     count: usize,
//! }
//!
//! // אנו רוצים שהספירה שלנו תתחיל באחת, אז בואו נוסיף שיטת new() כדי לעזור.
//! // זה לא הכרחי בהחלט, אבל זה נוח.
//! // שים לב שאנחנו מתחילים את `count` באפס, נראה למה ביישום `next()`'s להלן.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // לאחר מכן אנו מיישמים את `Iterator` עבור ה-`Counter` שלנו:
//!
//! impl Iterator for Counter {
//!     // אנחנו נספור בעזרת גודל
//!     type Item = usize;
//!
//!     // next() היא השיטה הנדרשת היחידה
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // הגדל את הספירה שלנו.זו הסיבה שהתחלנו באפס.
//!         self.count += 1;
//!
//!         // בדוק אם סיימנו לספור או לא.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // ועכשיו נוכל להשתמש בזה!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! קריאה ל-[`next`] בדרך זו חוזרת על עצמה.ל-Rust יש מבנה שיכול להתקשר ל-[`next`] באיטרטור שלך, עד שהוא מגיע ל-`None`.בוא נעבור על זה בהמשך.
//!
//! שים לב גם ש-`Iterator` מספק יישום ברירת מחדל של שיטות כגון `nth` ו-`fold` המתקשרות ל-`next` באופן פנימי.
//! עם זאת, ניתן גם לכתוב יישום מותאם אישית של שיטות כמו `nth` ו-`fold` אם איטרטור יכול לחשב אותן בצורה יעילה יותר מבלי להתקשר ל-`next`.
//!
//! # `for` לולאות ו-`IntoIterator`
//!
//! תחביר הלולאה `for` של Rust הוא למעשה סוכר לאיטרציה.הנה דוגמה בסיסית ל-`for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! פעולה זו תדפיס את המספרים אחד עד חמש, כל אחד בשורה משלו.אבל תבחין כאן במשהו: מעולם לא התקשרנו לשום דבר ב-vector שלנו כדי לייצר איטרטור.מה נותן?
//!
//! בספריה הסטנדרטית יש trait להמרה של משהו לאיטרציה: [`IntoIterator`].
//! ל-trait יש שיטה אחת, [`into_iter`], הממירה את הדבר המיישם את [`IntoIterator`] לאיטרציה.
//! בואו נסתכל שוב על לולאת ה-`for` ההיא, ומה המהדר ממיר אותה ל:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-sugars זה לתוך:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! ראשית, אנו קוראים ל-`into_iter()` על הערך.לאחר מכן, אנו מתאימים על איטרטר החוזר, מתקשר [`next`] שוב ושוב עד שנראה `None`.
//! בשלב זה, אנחנו `break` מחוץ לולאה, וסיימנו לחזור.
//!
//! יש כאן עוד קצת עדין: הספרייה הסטנדרטית מכילה יישום מעניין של [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! במילים אחרות, כל [Iterator] מיישמים את [`IntoIterator`], רק על ידי החזרת עצמם.זה אומר שני דברים:
//!
//! 1. אם אתה כותב [`Iterator`], אתה יכול להשתמש בו עם לולאת `for`.
//! 2. אם אתה יוצר אוסף, יישום [`IntoIterator`] עבורו יאפשר להשתמש באוסף שלך עם הלולאה `for`.
//!
//! # התבוסס בהתייחסות
//!
//! מכיוון ש-[`into_iter()`] לוקח את `self` לפי ערך, שימוש בלולאת `for` כדי לחזור על אוסף גוזל את האוסף הזה.לעתים קרובות, ייתכן שתרצה לחזור על אוסף מבלי לצרוך אותו.
//! אוספים רבים מציעים שיטות המספקות איטרטורים על פני הפניות, הנקראות בדרך כלל `iter()` ו-`iter_mut()` בהתאמה:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` עדיין בבעלות פונקציה זו.
//! ```
//!
//! אם סוג אוסף `C` מספק `iter()`, הוא בדרך כלל מיישם את `IntoIterator` עבור `&C`, עם יישום שפשוט קורא ל-`iter()`.
//! כמו כן, אוסף `C` המספק את `iter_mut()` מיישם בדרך כלל את `IntoIterator` עבור `&mut C` על ידי האצלתו ל-`iter_mut()`.זה מאפשר קצר:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // זהה ל-`values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // זהה ל-`values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! בעוד שאוספים רבים מציעים `iter()`, לא כולם מציעים `iter_mut()`.
//! לדוגמא, מוטציה של מקשי ה-[`HashSet<T>`] או [`HashMap<K, V>`] עלולה להכניס את האוסף למצב לא עקבי אם חשיפת המפתח משתנה, ולכן אוספים אלה מציעים `iter()` בלבד.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! פונקציות שלוקחות [`Iterator`] ומחזירות [`Iterator`] אחר נקראות לעתים קרובות 'מתאמי איטרור', מכיוון שהן צורה של 'מתאם'
//! pattern'.
//!
//! מתאמי איטרטור נפוצים כוללים [`map`], [`take`] ו-[`filter`].
//! למידע נוסף, עיין בתיעוד שלהם.
//!
//! אם מתאם איטרציה panics, האיטרטור יהיה במצב לא מוגדר (אך בטוח בזיכרון).
//! לא ניתן להבטיח שמצב זה יישאר זהה בכל הגרסאות של Rust, לכן כדאי להימנע מלהסתמך על הערכים המדויקים שהוחזר על ידי איטרטור שנכנס לפאניקה.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! איטרטורים (ואיטרטור [adapters](#adapters)) הם *עצלנים*. פירוש הדבר שרק יצירת איטרטור לא _do_ הרבה. שום דבר לא באמת קורה עד שאתה מתקשר ל-[`next`].
//! לעיתים זהו מקור לבלבול בעת יצירת איטרטר אך ורק בשל תופעות הלוואי שלו.
//! לדוגמא, שיטת [`map`] קוראת לסגירה על כל אלמנט שהיא חוזרת עליו:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! פעולה זו לא תדפיס שום ערכים מכיוון שיצרנו איטרטר בלבד במקום להשתמש בו.המהדר יזהיר אותנו מפני התנהגות מסוג זה:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! הדרך האידיומטית לכתוב [`map`] על תופעות הלוואי שלו היא להשתמש בלולאת `for` או לקרוא לשיטת [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! דרך נפוצה נוספת להעריך איטרטור היא להשתמש בשיטת [`collect`] להפקת אוסף חדש.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! מחמירים אינם חייבים להיות סופיים.כדוגמה, טווח פתוח הוא איטרטר אינסופי:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! מקובל להשתמש במתאם איטרטור [`take`] כדי להפוך איטרטר אינסופי למוגמר סופי:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! פעולה זו תדפיס את המספרים `0` עד `4`, כל אחד בשורה משלו.
//!
//! זכור כי שיטות על איטרטורים אינסופיים, אפילו כאלה שניתן לקבוע תוצאה מתמטית בזמן קצוב, עשויות שלא להסתיים.
//! באופן ספציפי, שיטות כגון [`min`], שבמקרה הכללי מחייבות מעבר כל אלמנט באיטרציה, עשויות שלא לחזור בהצלחה עבור איטרטורים אינסופיים.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // אוי לא!לולאה אינסופית!
//! // `ones.min()` גורם לולאה אינסופית, כך שלא נגיע לנקודה זו!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;