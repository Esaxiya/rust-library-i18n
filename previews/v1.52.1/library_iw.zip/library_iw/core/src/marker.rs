//! פרימיטיבי traits וסוגים המייצגים מאפיינים בסיסיים של סוגים.
//!
//! ניתן לסווג סוגי Rust בדרכים שימושיות שונות על פי המאפיינים הפנימיים שלהם.
//! סיווגים אלה מיוצגים כ-traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// סוגים שניתן להעביר על גבולות החוט.
///
/// trait זה מיושם אוטומטית כאשר המהדר קובע שהוא מתאים.
///
/// דוגמה לסוג שאינו 'שלח' הוא מצביע ספירת הפניות [`rc::Rc`][`Rc`].
/// אם שני שרשורים מנסים לשכפל את ['Rc'] המצביעים על אותו ערך שנספר הפניה, הם עשויים לנסות לעדכן את ספירת ההתייחסות בו זמנית, כלומר [undefined behavior][ub] מכיוון ש-[`Rc`] אינו משתמש בפעולות אטומיות.
///
/// בן דודו [`sync::Arc`][arc] אכן משתמש בפעולות אטומיות (כרוך בתקורה כלשהי) וכך הוא `Send`.
///
/// לפרטים נוספים, ראה [the Nomicon](../../nomicon/send-and-sync.html).
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// סוגים עם גודל קבוע הידוע בזמן הקומפילציה.
///
/// לכל פרמטרי הסוג יש גבול מרומז של `Sized`.התחביר המיוחד `?Sized` יכול לשמש להסרת הכבול הזה אם זה לא מתאים.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // מבנה FooUse(Foo<[i32]>);//שגיאה: גודל לא מיושם עבור [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// היוצא מן הכלל היחיד הוא סוג `Self` המשתמע של trait.
/// ל-trait אין `Sized` מרומז מאחר וזה לא תואם לאובייקטים [trait] שבהם, בהגדרה, ה-trait צריך לעבוד עם כל המיישמים האפשריים, ולכן יכול להיות בכל גודל.
///
///
/// למרות ש Rust יאפשר לך לאגד את `Sized` ל-trait, לא תוכל להשתמש בו כדי ליצור אובייקט trait מאוחר יותר:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // תן ל-y: &dyn בר= &Impl;//שגיאה: לא ניתן להפוך את trait `Bar` לאובייקט
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // עבור ברירת מחדל, למשל, הדורש שניתן יהיה להעריך את `[T]: !Default`
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// סוגים שיכולים להיות "unsized" לסוג בגודל דינמי.
///
/// לדוגמה, סוג המערך בגודל `[i8; 2]` מיישם את `Unsize<[i8]>` ו-`Unsize<dyn fmt::Debug>`.
///
/// כל המימושים של `Unsize` מסופקים אוטומטית על ידי המהדר.
///
/// `Unsize` מיושם עבור:
///
/// - `[T; N]` הוא `Unsize<[T]>`
/// - `T` הוא `Unsize<dyn Trait>` כאשר `T: Trait`
/// - `Foo<..., T, ...>` הוא `Unsize<Foo<..., U, ...>>` אם:
///   - `T: Unsize<U>`
///   - פו הוא מבנה
///   - רק בשדה האחרון של `Foo` יש סוג של `T`
///   - `T` אינו חלק מסוג כלשהו של שדות אחרים
///   - `Bar<T>: Unsize<Bar<U>>`, אם בשדה האחרון של `Foo` יש סוג `Bar<T>`
///
/// `Unsize` משמש יחד עם [`ops::CoerceUnsized`] כדי לאפשר למכולות "user-defined" כגון [`Rc`] להכיל סוגים בגודל דינמי.
/// לפרטים נוספים, עיין ב-[DST coercion RFC][RFC982] ו-[the nomicon entry on coercion][nomicon-coerce].
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// נדרש trait עבור קבועים המשמשים בהתאמות תבניות.
///
/// כל סוג שמקורו ב-`PartialEq` מיישם באופן אוטומטי את ה-trait,*ללא קשר* אם פרמטרי הסוג שלו מיישמים את `Eq`.
///
/// אם פריט `const` מכיל סוג כלשהו שאינו מיישם את trait, אז סוג זה או (1.) אינו מיישם את `PartialEq` (מה שאומר שהקבוע לא יספק את אותה שיטת השוואה, אשר הדור הקוד מניח שהיא זמינה), או (2.) שהיא מיישמת * משלה גרסת `PartialEq` (שאנו מניחים שאינה תואמת להשוואה שוויונית מבנית).
///
///
/// באחד משני התרחישים לעיל, אנו דוחים שימוש בקבוע כזה בהתאמת תבנית.
///
/// ראה גם את [structural match RFC][RFC1445] ו-[issue 63438] שהניעו מעבר מעיצוב מבוסס תכונות ל-trait זה.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// נדרש trait עבור קבועים המשמשים בהתאמות תבניות.
///
/// כל סוג שמקורו `Eq` מיישם באופן אוטומטי את trait הזה,*ללא קשר* אם פרמטרי הסוג שלו מיישמים את `Eq`.
///
/// זו פריצה לעקוף מגבלה במערכת הסוגים שלנו.
///
/// # Background
///
/// אנו רוצים לדרוש שסוגי הקונסטות המשמשים בהתאמות תבניות יהיו בעלי התכונה `#[derive(PartialEq, Eq)]`.
///
/// בעולם אידיאלי יותר, נוכל לבדוק את הדרישה הזו רק על ידי בדיקה שהסוג הנתון מיישם גם את `StructuralPartialEq` trait * וגם את `Eq` trait.
/// עם זאת, אתה יכול לקבל מודעות ADT *שעושות*`derive(PartialEq, Eq)`, ולהיות מקרה שאנו רוצים שהמהדר יקבל, ובכל זאת סוג הקבוע לא מצליח ליישם את `Eq`.
///
/// כלומר, מקרה כזה:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (הבעיה בקוד לעיל היא ש-`Wrap<fn(&())>` אינו מיישם את `PartialEq`, וגם לא את `Eq`, מכיוון ש-עבור <'a> fn(&'a _)` does not implement those traits.)
///
/// לכן, איננו יכולים להסתמך על בדיקה נאיבית עבור `StructuralPartialEq` ועל `Eq` בלבד.
///
/// כפריצה לעקיפת הבעיה, אנו משתמשים בשני traits נפרדים המוזרקים על ידי כל אחד משני הנגזרות (`#[derive(PartialEq)]` ו-`#[derive(Eq)]`) ובודקים ששניהם נמצאים כחלק מבדיקת התאמה מבנית.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// סוגים שניתן לשכפל את הערכים שלהם פשוט על ידי העתקת ביטים.
///
/// כברירת מחדל, בכריכות משתנות יש 'העבר סמנטיקה'.במילים אחרות:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` עבר ל-`y`, ולכן לא ניתן להשתמש בו
///
/// // println! ("{: ?}", x);//שגיאה: שימוש בערך שהועבר
/// ```
///
/// עם זאת, אם סוג מיישם את `Copy`, יש לו במקום זאת 'סמנטיקה להעתיק':
///
/// ```
/// // אנו יכולים להפיק יישום `Copy`.
/// // `Clone` נדרש גם, מכיוון שמדובר בתוואי-על של `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` הוא עותק של `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// חשוב לציין כי בשתי הדוגמאות הללו, ההבדל היחיד הוא האם מותר לך לגשת ל-`x` לאחר ההקצאה.
/// מתחת למכסה המנוע, גם עותק וגם מהלך יכולים לגרום להעתקה של סיביות בזיכרון, אם כי לפעמים זה מותאם משם.
///
/// ## כיצד אוכל להטמיע את `Copy`?
///
/// ישנן שתי דרכים ליישם את `Copy` בסוג שלך.הפשוטה ביותר היא להשתמש ב-`derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// ניתן גם ליישם את `Copy` ו-`Clone` באופן ידני:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// יש הבדל קטן בין השניים: האסטרטגיה של `derive` תציב `Copy` גם כן על פרמטרי סוג, וזה לא תמיד רצוי.
///
/// ## מה ההבדל בין `Copy` ל-`Clone`?
///
/// העתקים מתרחשים באופן מרומז, למשל במסגרת מטלה `y = x`.ההתנהגות של `Copy` אינה ניתנת לעומס יתר;זה תמיד עותק פשוט מעט חכם.
///
/// שיבוט הוא פעולה מפורשת, `x.clone()`.היישום של [`Clone`] יכול לספק כל התנהגות ספציפית לסוג הדרושה לשכפול ערכים בבטחה.
/// לדוגמה, היישום של [`Clone`] עבור [`String`] צריך להעתיק את חיץ המחרוזת המופנה בערימה.
/// עותק פשוט, חכם, של ערכי [`String`] יעתיק רק את המצביע, ויוביל לכפול חופשי בהמשך הקו.
/// מסיבה זו, [`String`] הוא [`Clone`] אך לא `Copy`.
///
/// [`Clone`] הוא תוואי-על של `Copy`, כך שכל מה שהוא `Copy` חייב ליישם גם את [`Clone`].
/// אם סוג הוא `Copy`, היישום [`Clone`] שלו צריך להחזיר רק את `*self` (ראה הדוגמה לעיל).
///
/// ## מתי הסוג שלי יכול להיות `Copy`?
///
/// סוג יכול ליישם `Copy` אם כל מרכיביו מיישמים את `Copy`.לדוגמה, מבנה זה יכול להיות `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// מבנה יכול להיות `Copy`, ו-[`i32`] הוא `Copy`, ולכן `Point` זכאי להיות `Copy`.
/// לעומת זאת, שקול
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// המבנה `PointList` אינו יכול ליישם את `Copy`, מכיוון ש-[`Vec<T>`] אינו `Copy`.אם ננסה להפיק יישום `Copy`, נקבל שגיאה:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// הפניות משותפות (`&T`) הן גם `Copy`, כך שסוג יכול להיות `Copy`, גם כאשר הוא מחזיק בהפניות משותפות מסוג `T` שהן *לא*`Copy`.
/// שקול את המבנה הבא, שיכול ליישם את `Copy`, מכיוון שהוא מחזיק רק *התייחסות משותפת* לסוג `PointList` שאינו 'העתק' מלמעלה:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## מתי *הסוג שלי* לא יכול להיות `Copy`?
///
/// לא ניתן להעתיק סוגים מסוימים בבטחה.לדוגמא, העתקת `&mut T` תיצור התייחסות ניתנת לשינוי.
/// העתקת [`String`] תשכפל את האחריות לניהול המאגר של ['מחרוזת'], ותוביל לחופשי כפול.
///
/// הכללת המקרה האחרון, כל סוג שמיישם [`Drop`] אינו יכול להיות `Copy`, מכיוון שהוא מנהל משאב כלשהו מלבד הבתים [`size_of::<T>`] משלו.
///
/// אם תנסה ליישם את `Copy` על מבנה או אנום המכיל נתונים שאינם 'העתקה', תקבל את השגיאה [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## מתי *על* הסוג שלי להיות `Copy`?
///
/// באופן כללי, אם סוג _can_ שלך מיישם את `Copy`, הוא אמור לעשות זאת.
/// עם זאת, זכור כי יישום `Copy` הוא חלק מה-API הציבורי מסוגך.
/// אם הסוג עשוי להפוך ללא 'העתק' ב-future, זה יכול להיות זהיר להשמיט את יישום ה-`Copy` כעת, כדי למנוע שינוי פורץ של API.
///
/// ## מיישמים נוספים
///
/// בנוסף ל-[implementors listed below][impls], הסוגים הבאים מיישמים גם את `Copy`:
///
/// * סוגי פריטי פונקציה (כלומר, הסוגים המובהקים שהוגדרו עבור כל פונקציה)
/// * סוגי מצביעי פונקציה (למשל, `fn() -> i32`)
/// * סוגי מערכים, לכל הגדלים, אם סוג הפריט מיישם גם את `Copy` (למשל, `[i32; 123456]`)
/// * סוגי טופל, אם כל רכיב מיישם גם את `Copy` (למשל, `()`, `(i32, bool)`)
/// * סוגי סגירה, אם הם לא תופסים שום ערך מהסביבה או אם כל הערכים שנתפסו כאלה מיישמים את `Copy` בעצמם.
///   שים לב שמשתנים שנתפסו על ידי הפניה משותפת מיישמים תמיד את `Copy` (גם אם המפנה אינו עושה זאת), בעוד שמשתנים שנתפסו על ידי הפניה משתנה לעולם אינם מיישמים את `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) זה מאפשר להעתיק סוג שאינו מיישם את `Copy` בגלל גבולות חיים לא מרוצים (העתקת `A<'_>` כשרק `A<'static>: Copy` ו-`A<'_>: Clone`).
// יש לנו תכונה זו לעת עתה רק מכיוון שישנם לא מעט התמחויות קיימות ב-`Copy` שכבר קיימות בספרייה הסטנדרטית, ואין שום דרך להתנהל בבטחה ברגע זה.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// הפיק מאקרו ויצר תשתית של trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// סוגים שעבורם בטוח לשתף הפניות בין השרשור.
///
/// trait זה מיושם אוטומטית כאשר המהדר קובע שהוא מתאים.
///
/// ההגדרה המדויקת היא: סוג `T` הוא [`Sync`] אם ורק אם `&T` הוא [`Send`].
/// במילים אחרות, אם אין אפשרות ל-[undefined behavior][ub] (כולל מירוצי נתונים) בעת העברת הפניות `&T` בין האשכולות.
///
/// כפי שניתן היה לצפות, סוגים פרימיטיביים כמו [`u8`] ו-[`f64`] הם כולם [`Sync`], וכך גם סוגי אגרגטים פשוטים המכילים אותם, כמו צינורות, שרוכים ותלים.
/// דוגמאות נוספות לסוגי [`Sync`] בסיסיים כוללים סוגי "immutable" כמו `&T`, ואלו עם מוטציות פשוטות תורשתיות, כגון [`Box<T>`][box], [`Vec<T>`][vec] ורוב סוגי האוספים האחרים.
///
/// (פרמטרים כלליים צריכים להיות [`Sync`] כדי שהמכולה שלהם תהיה ['סנכרון'].)
///
/// תוצאה מעט מפתיעה של ההגדרה היא ש-`&mut T` הוא `Sync` (אם `T` הוא `Sync`) למרות שזה נראה כאילו זה עשוי לספק מוטציה לא מסונכרנת.
/// החוכמה היא שהתייחסות ניתנת לשינוי מאחורי הפניה משותפת (כלומר `& &mut T`) הופכת לקריאה בלבד, כאילו הייתה `& &T`.
/// מכאן שאין סיכון למירוץ נתונים.
///
/// סוגים שאינם `Sync` הם אלה שיש להם "interior mutability" בצורה שאינה בטוחה לברגה, כגון [`Cell`][cell] ו-[`RefCell`][refcell].
/// סוגים אלה מאפשרים מוטציה של תוכנם גם באמצעות התייחסות משותפת בלתי ניתנת לשינוי.
/// לדוגמה, שיטת `set` ב-[`Cell<T>`][cell] לוקחת `&self`, ולכן היא דורשת התייחסות משותפת [`&Cell<T>`][cell] בלבד.
/// השיטה לא מבצעת סנכרון, ולכן [`Cell`][cell] לא יכול להיות `Sync`.
///
/// דוגמה נוספת לסוג שאינו 'סינכרון' הוא מצביע ספירת הפניות [`Rc`][rc].
/// בהתחשב בכל התייחסות [`&Rc<T>`][rc], אתה יכול לשכפל [`Rc<T>`][rc] חדש, ולשנות את ספירות הייחוס באופן שאינו אטומי.
///
/// במקרים שבהם יש צורך במוטציה פנימית בטוחה בחוטים, Rust מספק [atomic data types], כמו גם נעילה מפורשת באמצעות [`sync::Mutex`][mutex] ו-[`sync::RwLock`][rwlock].
/// סוגים אלה מבטיחים שכל מוטציה אינה יכולה לגרום למירוצי נתונים, ומכאן שהסוגים הם `Sync`.
/// כמו כן, [`sync::Arc`][arc] מספק אנלוגי בטוח לחוטים של [`Rc`][rc].
///
/// כל הסוגים עם שינויים פנימיים חייבים להשתמש גם בעטיפת [`cell::UnsafeCell`][unsafecell] סביב ה-value(s) שניתן למוטציה באמצעות הפניה משותפת.
/// כישלון לעשות זאת הוא [undefined behavior][ub].
/// לדוגמה, ["transmute"][transmute]-ing מ-`&T` ל-`&mut T` אינו חוקי.
///
/// ראה [the Nomicon][nomicon-send-and-sync] לפרטים נוספים אודות `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): לאחר שתומכת בהוספת הערות ב-`rustc_on_unimplemented` נוחתת בגרסת בטא, והיא הורחבה כדי לבדוק אם סגירה נמצאת בכל מקום בשרשרת הדרישות, הרחב אותו ככזה (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// סוג בגודל אפס משמש לסימון דברים ש-"act like" שבבעלותם `T`.
///
/// הוספת שדה `PhantomData<T>` לסוג שלך אומרת למהדר שהסוג שלך פועל כאילו הוא שומר ערך מסוג `T`, למרות שהוא לא ממש.
/// מידע זה משמש בעת חישוב מאפייני בטיחות מסוימים.
///
/// להסבר מעמיק יותר אודות השימוש ב-`PhantomData<T>`, אנא עיין ב-[the Nomicon](../../nomicon/phantom-data.html).
///
/// # הערה מחרידה 👻👻👻
///
/// למרות שלשניהם שמות מפחידים, `PhantomData` ו'סוגי פנטום 'קשורים, אך אינם זהים.פרמטר מסוג פנטום הוא פשוט פרמטר מסוג שלעולם לא משתמשים בו.
/// ב-Rust זה לעתים קרובות גורם למהדר להתלונן, והפתרון הוא להוסיף שימוש ב-"dummy" בדרך של `PhantomData`.
///
/// # Examples
///
/// ## פרמטרים שאינם בשימוש לכל החיים
///
/// אולי מקרה השימוש הנפוץ ביותר עבור `PhantomData` הוא מבנה בעל פרמטר חיים שאינו בשימוש, בדרך כלל כחלק מקוד לא בטוח כלשהו.
/// לדוגמא, הנה מבנה `Slice` בעל שתי מצביעים מסוג `*const T`, ככל הנראה מצביע למערך איפשהו:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// הכוונה היא שהנתונים הבסיסיים תקפים לכל החיים `'a` בלבד, ולכן `Slice` לא אמור לעלות על `'a`.
/// עם זאת, כוונה זו אינה באה לידי ביטוי בקוד, מכיוון שאין שום שימוש בחיי ה-`'a` לכל החיים ולכן לא ברור לאילו נתונים הוא חל.
/// אנו יכולים לתקן זאת על ידי אמירה למהדר לנהוג *כאילו* המבנה `Slice` מכיל התייחסות `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// זה בתורו מחייב גם את ההערה `T: 'a`, המציין שכל הפניות ב-`T` תקפות לאורך כל החיים `'a`.
///
/// בעת אתחול `Slice` אתה פשוט מספק את הערך `PhantomData` עבור השדה `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## פרמטרים מסוג לא בשימוש
///
/// לפעמים קורה שיש לך פרמטרים מסוג שאינו בשימוש המציינים לאיזה סוג נתונים מבנה הוא "tied", למרות שנתונים אלה אינם נמצאים באמת במבנה עצמו.
/// הנה דוגמה שבה זה מתעורר עם [FFI].
/// הממשק הזר משתמש בידיות מסוג `*mut ()` להתייחס לערכי Rust מסוגים שונים.
/// אנו עוקבים אחר סוג Rust באמצעות פרמטר מסוג פנטום במבנה `ExternalResource` העוטף ידית.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## בעלות ובדיקת הצניחה
///
/// הוספת שדה מסוג `PhantomData<T>` מציינת כי לסוג שלך יש נתונים מסוג `T`.זה בתורו מרמז שכאשר הסוג שלך נשמט, הוא עלול לרדת למופע אחד או יותר מהסוג `T`.
/// זה משפיע על ניתוח ה-[drop check] של מהדר Rust.
///
/// אם ה-struct שלך לא *מחזיק* בנתונים מסוג `T`, עדיף להשתמש בסימוכין, כמו `PhantomData<&'a T>` (ideally) או `PhantomData<*const T>` (אם אין תקופת חיים), כדי לא לציין בעלות.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// ה-trait הפנימי המהדר משמש לציון סוג המפלים.
///
/// trait זה מיושם באופן אוטומטי לכל סוג ואינו מוסיף שום ערבויות ל-[`mem::Discriminant`].
/// זוהי **התנהגות לא מוגדרת** להעביר בין `DiscriminantKind::Discriminant` ל-`mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// סוג המפלה, אשר חייב לספק את trait bounds הנדרש על ידי `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// trait מהפנימי המשמש לקביעת האם סוג מכיל `UnsafeCell` כלשהו באופן פנימי, אך לא באמצעות כיוון.
///
/// זה משפיע, למשל, אם `static` מסוג זה ממוקם בזיכרון הסטטי לקריאה בלבד או בזיכרון הסטטי הניתן לכתב.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// סוגים שניתן להזיז בבטחה לאחר ההצמדה.
///
/// ל-Rust עצמו אין שום מושג מסוגים בלתי ניתנים לזיהוי, והוא רואה במהלכים (למשל, באמצעות הקצאה או [`mem::replace`]) תמיד בטוחים.
///
/// במקום זאת משתמשים בסוג [`Pin`][Pin] למניעת מהלכים במערכת הסוגים.לא ניתן להעביר את המצביעים `P<T>` עטופים בעטיפה [`Pin<P<T>>`][Pin].
/// עיין בתיעוד [`pin` module] למידע נוסף על הצמדה.
///
/// יישום ה-`Unpin` trait עבור `T` מעלה את מגבלות ההצמדה מהסוג, מה שמאפשר לאחר מכן להעביר את `T` אל מחוץ ל-[`Pin<P<T>>`][Pin] עם פונקציות כגון [`mem::replace`].
///
///
/// `Unpin` אין שום השלכה כלל לנתונים שאינם מוצמדים.
/// בפרט, [`mem::replace`] מעביר בשמחה נתוני `!Unpin` (זה עובד עבור כל `&mut T`, לא רק כאשר `T: Unpin`).
/// עם זאת, אינך יכול להשתמש ב-[`mem::replace`] בנתונים העטופים בתוך [`Pin<P<T>>`][Pin] מכיוון שלא תוכל להשיג את ה-`&mut T` הדרוש לך לשם כך, ו *זה* מה שגורם למערכת זו לעבוד.
///
/// כך, למשל, ניתן לעשות רק על סוגים המיישמים את `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // אנו זקוקים להפניה משתנה כדי להתקשר ל-`mem::replace`.
/// // אנו יכולים להשיג התייחסות כזו על ידי הפעלת (implicitly) על `Pin::deref_mut`, אך הדבר אפשרי רק מכיוון ש-`String` מיישם את `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// trait זה מיושם אוטומטית כמעט לכל סוג.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// סוג סמן שאינו מיישם `Unpin`.
///
/// אם סוג מכיל `PhantomPinned`, הוא לא יישם את `Unpin` כברירת מחדל.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// יישומי `Copy` לסוגים פרימיטיביים.
///
/// יישומים שלא ניתן לתאר ב-Rust מיושמים ב-`traits::SelectionContext::copy_clone_conditions()` ב-`rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// ניתן להעתיק הפניות משותפות, אך הפניות משתנות *אינן יכולות*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}