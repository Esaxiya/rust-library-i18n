use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// ממשק להתמודדות עם איטרטורים אסינכרוניים.
///
/// זהו הזרם הראשי trait.
/// למידע נוסף על מושג הזרמים בדרך כלל, עיין ב-[module-level documentation].
/// בפרט, ייתכן שתרצה לדעת כיצד [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// סוג הפריטים שמניב הזרם.
    type Item;

    /// נסה לשלוף את הערך הבא של זרם זה, לרשום את המשימה הנוכחית להתעוררות אם הערך עדיין לא זמין, ולהחזיר את `None` אם הזרם מוצה.
    ///
    /// # ערך החזרה
    ///
    /// ישנם מספר ערכי החזרה אפשריים, שכל אחד מהם מציין מצב זרם מובהק:
    ///
    /// - `Poll::Pending` פירושו שהערך הבא של הזרם הזה עדיין לא מוכן.יישומים יבטיחו שהמשימה הנוכחית תקבל הודעה כאשר הערך הבא עשוי להיות מוכן.
    ///
    /// - `Poll::Ready(Some(val))` פירושו שהזרם הפיק בהצלחה ערך, `val`, ועשוי לייצר ערכים נוספים בשיחות `poll_next` הבאות.
    ///
    /// - `Poll::Ready(None)` פירושו שהזרם הסתיים, ואין להפעיל את `poll_next` שוב.
    ///
    /// # Panics
    ///
    /// לאחר שזרם הסתיים (החזיר את `Ready(None)` from `poll_next`), קריאה לשיטת `poll_next` שוב עשויה panic, לחסום לנצח או לגרום לבעיות מסוג אחר; ה-`Stream` trait לא מציב דרישות לגבי ההשפעות של שיחה כזו.
    ///
    /// עם זאת, מכיוון ששיטת `poll_next` אינה מסומנת כ-`unsafe`, חלים הכללים הרגילים של Rust: שיחות אסור לעולם לגרום להתנהגות לא מוגדרת (פגיעה בזיכרון, שימוש לא נכון בפונקציות `unsafe` וכדומה), ללא קשר למצב הזרם.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// מחזיר את הגבולות לאורך הזרם שנותר.
    ///
    /// באופן ספציפי, `size_hint()` מחזיר כפולת כאשר האלמנט הראשון הוא הגבול התחתון, והאלמנט השני הוא הגבול העליון.
    ///
    /// המחצית השנייה של הטולפ המוחזר היא [`אפשרות`] <<[[גודל גודל]]>>.
    /// [`None`] כאן פירושו שאף אין גבולות עליונים ידועים, או שהגבול העליון גדול מ-[`usize`].
    ///
    /// # הערות יישום
    ///
    /// זה לא נאכף כי יישום זרם מניב את מספר האלמנטים המוצהר.זרם באגי עשוי להניב פחות מהגבול התחתון או יותר מהגבול העליון של האלמנטים.
    ///
    /// `size_hint()` מיועד בעיקר לשימוש באופטימיזציות כגון שמירת מקום לאלמנטים של הזרם, אך אסור לסמוך עליו למשל להשמיט בדיקות גבולות בקוד לא בטוח.
    /// יישום שגוי של `size_hint()` לא אמור להוביל להפרות בטיחות זיכרון.
    ///
    /// עם זאת, היישום אמור לספק הערכה נכונה, מכיוון שאחרת זו תהיה הפרה של פרוטוקול ה-trait.
    ///
    /// יישום ברירת המחדל מחזיר את '(0, `[' ללא ']') 'הנכון לכל זרם.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}