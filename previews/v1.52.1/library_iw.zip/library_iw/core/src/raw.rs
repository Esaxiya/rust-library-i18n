#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! מכיל הגדרות מבנה לפריסה של סוגי מובנים מהדרים.
//!
//! הם יכולים לשמש כמטרות של טרנסמוטים בקוד לא בטוח לצורך מניפולציה ישירות על הייצוגים הגולמיים.
//!
//!
//! ההגדרה שלהם תמיד צריכה להתאים ל-ABI שהוגדר ב-`rustc_middle::ty::layout`.
//!

/// הייצוג של אובייקט trait כמו `&dyn SomeTrait`.
///
/// מבנה זה כולל פריסה זהה לסוגים כמו `&dyn SomeTrait` ו-`Box<dyn AnotherTrait>`.
///
/// `TraitObject` מובטח שתתאים לפריסות, אך זה לא סוג האובייקטים של trait (למשל, השדות אינם נגישים ישירות ב-`&dyn SomeTrait`) וגם אינו שולט בפריסה זו (שינוי ההגדרה לא ישנה את הפריסה של `&dyn SomeTrait`).
///
/// זה נועד רק לשימוש על ידי קוד לא בטוח שצריך לתפעל את הפרטים ברמה הנמוכה.
///
/// אין שום דרך להתייחס לכל אובייקטים trait באופן כללי, ולכן הדרך היחידה ליצור ערכים מסוג זה היא באמצעות פונקציות כמו [`std::mem::transmute`][transmute].
/// באופן דומה, הדרך היחידה ליצור אובייקט trait אמיתי מערך `TraitObject` היא באמצעות `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// סינתזה של אובייקט trait עם סוגים לא תואמים-כזה שבו הטבלה vt אינו תואם לסוג הערך אליו מצביע הנתונים מצביע-סביר מאוד להוביל להתנהגות לא מוגדרת.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // דוגמה trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // תן למהדר ליצור אובייקט trait
/// let object: &dyn Foo = &value;
///
/// // להסתכל על הייצוג הגולמי
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // מצביע הנתונים הוא הכתובת של `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // לבנות אובייקט חדש, להצביע על `i32` אחר, ולהיזהר להשתמש בטבלת `i32` מ-`object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // זה אמור לעבוד בדיוק כאילו בנינו אובייקט trait מתוך `other_value` ישירות
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}