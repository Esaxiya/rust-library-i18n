//! מכולות ניתנות לשינוי הניתנות לשיתוף.
//!
//! בטיחות הזיכרון Rust מבוססת על כלל זה: בהינתן אובייקט `T`, ניתן לקבל רק אחד מהבאים:
//!
//! - בעל מספר התייחסויות בלתי משתנות (`&T`) לאובייקט (המכונה גם **aliasing**).
//! - בעל התייחסות משתנה אחת (`&mut T`) לאובייקט (המכונה גם **מוטציה**).
//!
//! זה נאכף על ידי מהדר Rust.עם זאת, ישנם מצבים בהם כלל זה אינו גמיש מספיק.לפעמים נדרש מספר הפניות לאובייקט ובכל זאת לשנות אותו.
//!
//! קיימים מיכלים ניתנים לשינוי הניתנים לשיתוף כדי לאפשר השתנות באופן מבוקר, אפילו בנוכחות כינוס.גם [`Cell<T>`] וגם [`RefCell<T>`] מאפשרים לעשות את זה בצורה הברגה אחת.
//! עם זאת, `Cell<T>` וגם `RefCell<T>` אינם בטוחים בחוטים (הם אינם מיישמים [`Sync`]).
//! אם אתה צריך לבצע כינויים ומוטציות בין מספר שרשורים ניתן להשתמש בסוגי [`Mutex<T>`], [`RwLock<T>`] או [`atomic`].
//!
//! ערכים מסוג `Cell<T>` ו-`RefCell<T>` עשויים להשתנות באמצעות הפניות משותפות (כלומר
//! סוג ה-`&T` הנפוץ), בעוד שרוב סוגי ה-Rust ניתנים למוטציה רק באמצעות הפניות ייחודיות (`&mut T`).
//! אנו אומרים כי `Cell<T>` ו-`RefCell<T>` מספקים 'שינויים פנימיים', בניגוד לסוגי Rust טיפוסיים המציגים 'מוטציה תורשתית'.
//!
//! סוגי תאים מגיעים בשני טעמים: `Cell<T>` ו-`RefCell<T>`.`Cell<T>` מיישם השתנות פנימית על ידי העברת ערכים אל מחוץ ל-`Cell<T>`.
//! כדי להשתמש בהפניות במקום בערכים, יש להשתמש בסוג `RefCell<T>`, לרכוש נעילת כתיבה לפני המוטציה.`Cell<T>` מספק שיטות לאחזור ושינוי הערך הפנימי הנוכחי:
//!
//!  - עבור סוגים המיישמים [`Copy`], שיטת [`get`](Cell::get) מאחזרת את ערך הפנים הנוכחי.
//!  - עבור סוגים המיישמים [`Default`], שיטת [`take`](Cell::take) מחליפה את ערך הפנים הנוכחי ב-[`Default::default()`] ומחזירה את הערך שהוחלף.
//!  - עבור כל הסוגים, שיטת [`replace`](Cell::replace) מחליפה את ערך הפנים הנוכחי ומחזירה את הערך שהוחלף ושיטת [`into_inner`](Cell::into_inner) צורכת את ה-`Cell<T>` ומחזירה את הערך הפנימי.
//!  בנוסף, שיטת [`set`](Cell::set) מחליפה את הערך הפנימי, ומפילה את הערך שהוחלף.
//!
//! `RefCell<T>` משתמש בחייה של Rust כדי ליישם 'הלוואה דינמית', תהליך לפיו ניתן לתבוע גישה זמנית, בלעדית, ניתנת לשינוי לערך הפנימי.
//! לווה עבור `RefCell<T>ניתן לעקוב אחר 'בזמן ריצה', בשונה מסוגי הייחוס המקוריים של Rust שעוקבים אחריהם באופן סטטי, בזמן הקומפילציה.
//! מכיוון שהלוואות של `RefCell<T>` הן דינמיות, ניתן לנסות ללוות ערך שכבר הושאל באופן משתנה;כשזה קורה זה גורם לחוט panic.
//!
//! # מתי לבחור מוטציה פנים
//!
//! המשתנות התורשתית הנפוצה יותר, בה חייבים להיות גישה ייחודית למוטציה של ערך, היא אחד ממרכיבי השפה המרכזיים המאפשרים ל-Rust לנמק בחוזקה לגבי כינויי מצביע, ומונע באופן סטטי באגי קריסה.
//! מסיבה זו, עדיפות מוטציה תורשתית, ומוטציה פנימית היא דבר מוצא אחרון.
//! מאחר וסוגי תאים מאפשרים מוטציה במקרים שבהם זה לא היה מותר אחרת, ישנם מקרים בהם מוטציה פנימית עשויה להיות מתאימה, או אפילו *יש להשתמש*, למשל
//!
//! * מציגים שינוי 'inside' של משהו שאינו משתנה
//! * פרטי יישום של שיטות בלתי ניתנות לשינוי הגיוני.
//! * מימוש מוטציות של [`Clone`].
//!
//! ## מציגים שינוי 'inside' של משהו שאינו משתנה
//!
//! סוגי מצביעים חכמים משותפים רבים, כולל [`Rc<T>`] ו-[`Arc<T>`], מספקים מכולות שניתן לשכפל ולשתף בין מספר גורמים.
//! מכיוון שהערכים הכלולים עשויים להיות מקבילים מכפלת, הם ניתנים להשאלה רק עם `&`, ולא עם `&mut`.
//! ללא תאים יהיה בלתי אפשרי בכלל לשנות נתונים בתוך המצביעים החכמים הללו.
//!
//! זה מאוד מקובל אז לשים `RefCell<T>` בתוך סוגי מצביעים משותפים כדי להציג מחדש את המוטציה.
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // צור בלוק חדש להגבלת היקף ההשאלה הדינמית
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // שים לב שאם לא היינו נותנים את ההשאלה הקודמת של המטמון מחוץ לתחום, ההשאלה הבאה תגרום לשרשור דינמי panic.
//!     //
//!     // זהו הסכנה העיקרית בשימוש ב-`RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! שים לב כי דוגמה זו משתמשת ב-`Rc<T>` ולא ב-`Arc<T>`.`RefCell<T>הם מיועדים לתרחישים עם הברגה אחת.שקול להשתמש ב-[`RwLock<T>`] או [`Mutex<T>`] אם אתה זקוק למוטביליות משותפת במצב רב-הברגה.
//!
//! ## פרטי יישום של שיטות בלתי ניתנות לשינוי הגיוני
//!
//! לפעמים זה יכול להיות רצוי לא לחשוף ב-API שיש מוטציה שקורה "under the hood".
//! זה יכול להיות כי מבחינה לוגית הפעולה אינה ניתנת לשינוי, אך למשל, שמירה מכריחה את היישום לבצע מוטציה;או משום שעליך להשתמש במוטציה בכדי ליישם שיטת trait שהוגדרה במקור לקחת `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // חישוב יקר הולך לכאן
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## מימוש מוטציות של `Clone`
//!
//! זהו פשוט מקרה מיוחד, אך נפוץ, של הקודם: הסתרת מוטציה לפעולות שנראות בלתי משתנות.
//! שיטת [`clone`](Clone::clone) צפויה לא לשנות את ערך המקור, והיא מוכרזת לקחת `&self`, ולא `&mut self`.
//! לכן, כל מוטציה שקורה בשיטת `clone` חייבת להשתמש בסוגי תאים.
//! לדוגמא, [`Rc<T>`] שומר על ספירת ההתייחסות שלו בתוך `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// מיקום זיכרון משתנה.
///
/// # Examples
///
/// בדוגמה זו, ניתן לראות כי `Cell<T>` מאפשר מוטציה בתוך מבנה בלתי ניתן לשינוי.
/// במילים אחרות, זה מאפשר "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // שגיאה: אי אפשר לשנות את `my_struct`
/// // my_struct.regular_field =new_value;
///
/// // עובד: למרות ש-`my_struct` אינו משתנה, `special_field` הוא `Cell`,
/// // שתמיד ניתן למוטציה
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// ראה [module-level documentation](self) לקבלת מידע נוסף.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// יוצר `Cell<T>`, עם הערך `Default` עבור T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// יוצר `Cell` חדש המכיל את הערך הנתון.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// מגדיר את הערך הכלול.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// מחליף את הערכים של שני תאים.
    /// ההבדל עם `std::mem::swap` הוא שפונקציה זו אינה דורשת התייחסות ל-`&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // בטיחות: זה יכול להיות מסוכן אם קוראים לו משרשורים נפרדים, אבל `Cell`
        // הוא `!Sync` אז זה לא יקרה.
        // זה גם לא יבטל את כל המצביעים מכיוון ש-`Cell` מוודא ששום דבר אחר לא יצביע לאף אחד מה-`Cell`s הללו.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// מחליף את הערך הכלול ב-`val` ומחזיר את הערך הכלול הישן.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // בטיחות: זה יכול לגרום למירוצי נתונים אם נקרא משרשור נפרד,
        // אבל `Cell` הוא `!Sync` אז זה לא יקרה.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// פורק את הערך.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// מחזיר עותק של הערך הכלול.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // בטיחות: זה יכול לגרום למירוצי נתונים אם נקרא משרשור נפרד,
        // אבל `Cell` הוא `!Sync` אז זה לא יקרה.
        unsafe { *self.value.get() }
    }

    /// מעדכן את הערך הכלול באמצעות פונקציה ומחזיר את הערך החדש.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// מחזיר מצביע גולמי לנתונים הבסיסיים בתא זה.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// מחזירה הפניה משתנה לנתונים הבסיסיים.
    ///
    /// שיחה זו שואלת את `Cell` באופן משתנה (בזמן קומפילציה) מה שמבטיח שיש לנו את ההתייחסות היחידה.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// מחזירה `&Cell<T>` מ-`&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // בטיחות: `&mut` מבטיח גישה ייחודית.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// לוקח את ערך התא ומשאיר את `Default::default()` במקומו.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// מחזירה `&[Cell<T>]` מ-`&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // בטיחות: ל-`Cell<T>` יש פריסת זיכרון זהה לזו של `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// מיקום זיכרון משתנה עם כללי השאלה שנבדקו באופן דינמי
///
/// ראה [module-level documentation](self) לקבלת מידע נוסף.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// שגיאה שהוחזרה על ידי [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// שגיאה שהוחזרה על ידי [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// ערכים חיוביים מייצגים את מספר `Ref` פעיל.ערכים שליליים מייצגים את מספר `RefMut` פעיל.
// מספר RefMut יכול להיות פעיל רק בכל פעם אם הם מתייחסים לרכיבים נפרדים ולא חופפים של `RefCell` (למשל, טווחים שונים של פרוסה).
//
// `Ref` ו-`RefMut` הן שתי מילים בגודל, ולכן סביר להניח שלעולם לא יהיו מספיק 'Ref' או 'RefMut' כדי לעלות על מחצית מטווח ה-`usize`.
// לפיכך, `BorrowFlag` כנראה לעולם לא יעלה על גדותיו או על זרימתו.
// עם זאת, זו אינה ערובה, מכיוון שתוכנית פתולוגית יכולה ליצור שוב ושוב mem::forget `Ref`s או`RefMut`s.
// לפיכך, על כל הקוד לבדוק במפורש אודות הצפה ותחתית כדי למנוע אי-בטיחות, או לפחות להתנהג כראוי במקרה שהצפה או זרימה יתרחשו (למשל, ראה BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// יוצר `RefCell` חדש המכיל `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// צורכת את ה-`RefCell` ומחזירה את הערך העטוף.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // מכיוון שפונקציה זו לוקחת `self` (ה-`RefCell`) לפי ערך, המהדר מוודא סטטית שהיא אינה מושאלת כרגע.
        //
        self.value.into_inner()
    }

    /// מחליף את הערך העטוף בערך חדש, ומחזיר את הערך הישן, מבלי לבטל את אתחול מחדש של אף אחד מהם.
    ///
    ///
    /// פונקציה זו תואמת ל-[`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics אם הערך מושאל כרגע.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// מחליף את הערך העטוף בערך חדש המחושב מ-`f`, ומחזיר את הערך הישן, מבלי לבטל מחדש את אף אחד מהם.
    ///
    ///
    /// # Panics
    ///
    /// Panics אם הערך מושאל כרגע.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// מחליף את הערך העטוף של `self` עם הערך העטוף של `other`, מבלי לבטל את אתחול מחדש של אף אחד מהם.
    ///
    ///
    /// פונקציה זו תואמת ל-[`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics אם הערך ב-`RefCell` מושאל כרגע.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// לווה לאין ערוך את הערך העטוף.
    ///
    /// ההשאלה נמשכת עד שה-`Ref` שהוחזר יוצא מההיקף.
    /// ניתן לקחת מספר הלוואות בלתי ניתנות לשינוי במקביל.
    ///
    /// # Panics
    ///
    /// Panics אם הערך מושאל כרגע.
    /// לקבלת גרסה ללא פאניקה, השתמש ב-[`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// דוגמה ל-panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// לווה באופן לא נכון את הערך העטוף, ומחזיר שגיאה אם הערך מושאל כרגע.
    ///
    ///
    /// ההשאלה נמשכת עד שה-`Ref` שהוחזר יוצא מההיקף.
    /// ניתן לקחת מספר הלוואות בלתי ניתנות לשינוי במקביל.
    ///
    /// זהו הגרסה הלא-מבוהלת של [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // בטיחות: `BorrowRef` מבטיח שיש גישה בלתי ניתנת לשינוי בלבד
            // לשווי בזמן שהושאל.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// לווה באופן מוטב את הערך העטוף.
    ///
    /// ההשאלה נמשכת עד שה-`RefMut` שהוחזר או כל ה'RefMut 'הנגזר ממנה היקף היציאה.
    ///
    /// לא ניתן לשאול את הערך בזמן שהלוואה זו פעילה.
    ///
    /// # Panics
    ///
    /// Panics אם הערך מושאל כרגע.
    /// לקבלת גרסה ללא פאניקה, השתמש ב-[`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// דוגמה ל-panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// לווה באופן שווה את הערך העטוף, ומחזיר שגיאה אם הערך מושאל כרגע.
    ///
    ///
    /// ההשאלה נמשכת עד שה-`RefMut` שהוחזר או כל ה'RefMut 'הנגזר ממנה היקף היציאה.
    /// לא ניתן לשאול את הערך בזמן שהלוואה זו פעילה.
    ///
    /// זהו הגרסה הלא-מבוהלת של [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // בטיחות: `BorrowRef` מבטיח גישה ייחודית.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// מחזיר מצביע גולמי לנתונים הבסיסיים בתא זה.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// מחזירה הפניה משתנה לנתונים הבסיסיים.
    ///
    /// שיחה זו לווה את `RefCell` באופן משתנה (בזמן הידור) כך שאין צורך בבדיקות דינמיות.
    ///
    /// עם זאת היזהר: שיטה זו מצפה ש-`self` יהיה משתנה, מה שבדרך כלל אינו המקרה בעת שימוש ב-`RefCell`.
    ///
    /// בדוק את שיטת [`borrow_mut`] במקום זאת אם `self` אינו ניתן לשינוי.
    ///
    /// כמו כן, אנא שים לב כי שיטה זו מיועדת רק לנסיבות מיוחדות ולרוב אינה מה שאתה רוצה.
    /// במקרה של ספק, השתמש במקום זאת ב-[`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// בטל את השפעתם של שומרים שהודלפו על מצב ההשאלה של ה-`RefCell`.
    ///
    /// שיחה זו דומה ל-[`get_mut`] אך מתמחה יותר.
    /// הוא לווה את `RefCell` באופן משתנה בכדי להבטיח שלא קיימות הלוואות ואז מאפס את המדינה שעוקבת אחר הלוואות משותפות.
    /// זה רלוונטי אם כמה הלוואות `Ref` או `RefMut` הודלפו.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// לווה באופן לא נכון את הערך העטוף, ומחזיר שגיאה אם הערך מושאל כרגע.
    ///
    /// # Safety
    ///
    /// בניגוד ל-`RefCell::borrow`, שיטה זו אינה בטוחה מכיוון שהיא אינה מחזירה `Ref` ובכך אינה משאירה את דגל ההשאלה.
    /// השאלה של ה-`RefCell` באופן הדדי בזמן שההפניה המוחזרת בשיטה זו חיה אינה התנהגות מוגדרת.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // בטיחות: אנחנו בודקים שאף אחד לא כותב באופן פעיל עכשיו, אבל זה כן
            // אחריותו של המתקשר לוודא שאיש אינו כותב עד שההפניה המוחזרת כבר אינה בשימוש.
            // כמו כן, `self.value.get()` מתייחס לערך שבבעלות `self` ובכך מובטח שהוא יהיה תקף לכל החיים של `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// לוקח את הערך העטוף ומשאיר את `Default::default()` במקומו.
    ///
    /// # Panics
    ///
    /// Panics אם הערך מושאל כרגע.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics אם הערך מושאל כרגע.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// יוצר `RefCell<T>`, עם הערך `Default` עבור T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics אם הערך ב-`RefCell` מושאל כרגע.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics אם הערך ב-`RefCell` מושאל כרגע.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics אם הערך ב-`RefCell` מושאל כרגע.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics אם הערך ב-`RefCell` מושאל כרגע.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics אם הערך ב-`RefCell` מושאל כרגע.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics אם הערך ב-`RefCell` מושאל כרגע.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics אם הערך ב-`RefCell` מושאל כרגע.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // הגדלת הלוואה יכולה לגרום לערך שאינו קריאה (<=0) במקרים הבאים:
            // 1. זה היה <0, כלומר יש הלוואות כתיבה, ולכן איננו יכולים לאפשר הלוואת קריאה עקב כללי ההתייחסות של Rust
            // 2.
            // זה היה isize::MAX (הכמות המקסימאלית של הלוואות קריאה) והוא עלה על גדותיו ל-isize::MIN (הכמות המקסימלית של הלוואות כתיבה) ולכן איננו יכולים לאפשר הלוואת קריאה נוספת מכיוון ש-isize אינו יכול לייצג כל כך הרבה הלוואות שקראו (זה יכול לקרות רק אם אתה mem::forget יותר מכמות קבועה קטנה של `Ref`s, וזה לא נוהג טוב)
            //
            //
            //
            //
            None
        } else {
            // הגדלת הלוואה יכולה לגרום לערך קריאה (> 0) במקרים הבאים:
            // 1. זה היה=0, כלומר הוא לא הושאל, ואנחנו לוקחים את הלוואת הקריאה הראשונה
            // 2. זה היה> 0 ו-<isize::MAX, כלומר
            // היו הלוואות שנקראו, ואיזי הוא מספיק גדול כדי לייצג שיש הלוואה נוספת לקריאה
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // מכיוון שרפרז זה קיים, אנו יודעים שדגל ההשאלה הוא הלוואת קריאה.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // מנע מדלפק ההשאלה לעלות על גדותיו להלוואת כתיבה.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// עוטף הפניה מושאלת לערך בתיבה `RefCell`.
/// סוג עטיפה עבור ערך מושאל ללא שינוי מ-`RefCell<T>`.
///
/// ראה [module-level documentation](self) לקבלת מידע נוסף.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// מעתיק `Ref`.
    ///
    /// ה-`RefCell` כבר מושאל ללא שינוי, כך שזה לא יכול להיכשל.
    ///
    /// זו פונקציה משויכת שיש להשתמש בה כ-`Ref::clone(...)`.
    /// יישום `Clone` או שיטה יפריעו לשימוש הנרחב ב-`r.borrow().clone()` לשיבוט תוכן ה-`RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// מכין `Ref` חדש לרכיב מהנתונים המושאלים.
    ///
    /// ה-`RefCell` כבר מושאל ללא שינוי, כך שזה לא יכול להיכשל.
    ///
    /// זו פונקציה משויכת שיש להשתמש בה כ-`Ref::map(...)`.
    /// שיטה תפריע לשיטות באותו שם בתוכן ה-`RefCell` המשמש דרך `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// מכין `Ref` חדש לרכיב אופציונלי של הנתונים המושאלים.
    /// השומר המקורי מוחזר כ-`Err(..)` אם הסגירה מחזירה את `None`.
    ///
    /// ה-`RefCell` כבר מושאל ללא שינוי, כך שזה לא יכול להיכשל.
    ///
    /// זו פונקציה משויכת שיש להשתמש בה כ-`Ref::filter_map(...)`.
    /// שיטה תפריע לשיטות באותו שם בתוכן ה-`RefCell` המשמש דרך `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// מפצל `Ref` למספר `Ref` עבור רכיבים שונים של הנתונים המושאלים.
    ///
    /// ה-`RefCell` כבר מושאל ללא שינוי, כך שזה לא יכול להיכשל.
    ///
    /// זו פונקציה משויכת שיש להשתמש בה כ-`Ref::map_split(...)`.
    /// שיטה תפריע לשיטות באותו שם בתוכן ה-`RefCell` המשמש דרך `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// המרה להפניה לנתונים הבסיסיים.
    ///
    /// לעולם לא ניתן לשאול את ה-`RefCell` העומד בבסיסו ותמיד יופיע כבר בהשאלה ללא שינוי.
    ///
    /// זה לא רעיון טוב לדלוף יותר ממספר קבוע של הפניות.
    /// ניתן לשאול ללא שינוי את ה-`RefCell` אם רק מספר קטן יותר של נזילות התרחשו בסך הכל.
    ///
    /// זו פונקציה משויכת שיש להשתמש בה כ-`Ref::leak(...)`.
    /// שיטה תפריע לשיטות באותו שם בתוכן ה-`RefCell` המשמש דרך `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // על ידי שכחת רפר זה אנו מבטיחים כי דלפק ההשאלה ב-RefCell אינו יכול לחזור ל-UNUSED במהלך החיים `'b`.
        // איפוס מצב מעקב ההפניה ידרוש התייחסות ייחודית ל-RefCell המושאל.
        // לא ניתן ליצור הפניות משתנות נוספות מהתא המקורי.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// מכין `RefMut` חדש לרכיב של הנתונים המושאלים, למשל, גרסת enum.
    ///
    /// ה-`RefCell` כבר מושאל באופן משתנה, כך שזה לא יכול להיכשל.
    ///
    /// זו פונקציה משויכת שיש להשתמש בה כ-`RefMut::map(...)`.
    /// שיטה תפריע לשיטות באותו שם בתוכן ה-`RefCell` המשמש דרך `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): לתקן צ'ק-הלוואה
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// מכין `RefMut` חדש לרכיב אופציונלי של הנתונים המושאלים.
    /// השומר המקורי מוחזר כ-`Err(..)` אם הסגירה מחזירה את `None`.
    ///
    /// ה-`RefCell` כבר מושאל באופן משתנה, כך שזה לא יכול להיכשל.
    ///
    /// זו פונקציה משויכת שיש להשתמש בה כ-`RefMut::filter_map(...)`.
    /// שיטה תפריע לשיטות באותו שם בתוכן ה-`RefCell` המשמש דרך `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): לתקן צ'ק-הלוואה
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // בטיחות: הפונקציה מחזיקה התייחסות בלעדית למשך הזמן
        // של שיחתו דרך `orig`, והמצביע אינו מופנה רק בתוך שיחת הפונקציה, לעולם אינו מאפשר להתייחסות הבלעדית להימלט.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // בטיחות: זהה לעיל.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// מפצל `RefMut` למספר `RefMut` עבור רכיבים שונים של הנתונים המושאלים.
    ///
    /// ה-`RefCell` העומד בבסיסו יישאר מושאל באופן מוטרף עד ששני ה-RefMut החוזרים ייצאו מחוץ לתחום.
    ///
    /// ה-`RefCell` כבר מושאל באופן משתנה, כך שזה לא יכול להיכשל.
    ///
    /// זו פונקציה משויכת שיש להשתמש בה כ-`RefMut::map_split(...)`.
    /// שיטה תפריע לשיטות באותו שם בתוכן ה-`RefCell` המשמש דרך `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// המרה להפניה משתנה לנתונים הבסיסיים.
    ///
    /// לא ניתן לשאול את ה-`RefCell` העומד בבסיסו ותמיד יופיע כבר בהשאלה משתנה, מה שהופך את ההתייחסות שהוחזרה להיות היחידה לחלל הפנים.
    ///
    ///
    /// זו פונקציה משויכת שיש להשתמש בה כ-`RefMut::leak(...)`.
    /// שיטה תפריע לשיטות באותו שם בתוכן ה-`RefCell` המשמש דרך `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // על ידי שכחה זו של BorrowRefMut אנו מבטיחים כי דלפק ההלוואות ב-RefCell לא יכול לחזור ל-UNUSED במהלך החיים `'b`.
        // איפוס מצב מעקב ההפניה ידרוש התייחסות ייחודית ל-RefCell המושאל.
        // לא ניתן ליצור הפניות נוספות מהתא המקורי בתוך אותו חיים, מה שהופך את ההשאלה הנוכחית להתייחסות היחידה למשך כל החיים שנותרו.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: בניגוד ל-BorrowRefMut::clone, חדש נקרא ליצור את הראשוני
        // הפניה ניתנת לשינוי, ולכן כרגע אסור שיהיו הפניות קיימות.
        // לפיכך, בעוד ששיבוט מגדיל את ספירת החידוש המשתנה, כאן אנו מאפשרים במפורש לעבור מ-UNUSED ל-UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // משכפל `BorrowRefMut`.
    //
    // זה תקף רק אם כל `BorrowRefMut` משמש למעקב אחר התייחסות משתנה לטווח מובחן ולא חופף של האובייקט המקורי.
    //
    // זה לא בשכפול של שיבוט, כך שקוד לא יקרא לזה באופן מרומז.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // מנע מדלפק ההשאלה את הזרימה.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// סוג עטיפה לערך שאול לשינוי מ-`RefCell<T>`.
///
/// ראה [module-level documentation](self) לקבלת מידע נוסף.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// הליבה הפרימיטיבית למשתנות פנים ב-Rust.
///
/// אם יש לך הפניה `&T`, אז בדרך כלל ב-Rust מהדר מבצע אופטימיזציות על סמך הידיעה ש-`&T` מצביע על נתונים בלתי ניתנים לשינוי.מוטציה של נתונים אלה, למשל באמצעות כינוי או על ידי העברת `&T` ל-`&mut T`, נחשבת להתנהגות לא מוגדרת.
/// `UnsafeCell<T>` מבטלת את התחייבות ה-immutability ל-`&T`: הפניה משותפת `&UnsafeCell<T>` עשויה להצביע על נתונים שעוברים מוטציה.זה נקרא "interior mutability".
///
/// כל הסוגים האחרים המאפשרים שינויים פנימיים, כגון `Cell<T>` ו-`RefCell<T>`, משתמשים באופן פנימי ב-`UnsafeCell` כדי לעטוף את הנתונים שלהם.
///
/// שים לב שרק ההתחייבות לאי-משתנות עבור הפניות משותפות מושפעת מ-`UnsafeCell`.ערבות הייחודיות להפניות משתנות אינה מושפעת.אין *דרך* חוקית להשיג כינוס `&mut`, אפילו לא עם `UnsafeCell<T>`.
///
/// ה-API של `UnsafeCell` עצמו פשוט מאוד מבחינה טכנית: [`.get()`] נותן לך מצביע גולמי `*mut T` לתוכנו.זה עד _you_ כמעצב ההפשטה להשתמש נכון בסמן הגולמי הזה.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// הכללים המדויקים של כינויי Rust משתנים במקצת, אך הנקודות העיקריות אינן שנויות במחלוקת:
///
/// - אם אתה יוצר הפניה בטוחה עם `'a` לכל החיים (או הפניה ל-`&T` או `&mut T`) הנגישה באמצעות קוד בטוח (למשל מכיוון שהחזרת אותה), אז אסור לך לגשת לנתונים בשום דרך הסותרת את ההפניה לשאר של `'a`.
/// לדוגמא, פירוש הדבר שאם אתה לוקח את ה-`*mut T` מ-`UnsafeCell<T>` והשליך אותו ל-`&T`, אז הנתונים ב-`T` חייבים להישאר ללא שינוי (מודול כל נתוני `UnsafeCell` שנמצאים בתוך `T`, כמובן) עד שתוקף חיי ההפניה יפוג.
/// באופן דומה, אם אתה יוצר הפניה ל-`&mut T` שמשוחררת לקוד בטוח, אסור לך לגשת לנתונים בתוך ה-`UnsafeCell` עד שתוקף הפניה זו יפוג.
///
/// - בכל עת עליך להימנע ממירוצי נתונים.אם למספר נושאים יש גישה לאותו `UnsafeCell`, אז כל כתיבה חייבת להיות ביחס שקורה נכון לפני כל הגישות האחרות (או להשתמש באטומים).
///
/// כדי לסייע בתכנון נכון, התרחישים הבאים מוכרזים במפורש כחוקיים עבור קוד הברגה אחת:
///
/// 1. ניתן לשחרר הפניה `&T` לקוד בטוח ושם היא יכולה להתקיים יחד עם הפניות `&T` אחרות, אך לא עם `&mut T`
///
/// 2. ניתן לשחרר הפניה ל-`&mut T` לקוד בטוח, בתנאי שלא `&mut T` ולא `&T` לא קיימים יחד.`&mut T` חייב להיות תמיד ייחודי.
///
/// שים לב שלמרות שהמוטציה של התוכן של `&UnsafeCell<T>` (אפילו בעוד `&UnsafeCell<T>` אחרים מתייחסת לכינוי התא) היא בסדר (בתנאי שתאכוף את המשתתפים לעיל בדרך אחרת), עדיין אין התנהגות מוגדרת שיש כינויים `&mut UnsafeCell<T>` מרובים.
/// כלומר, `UnsafeCell` הוא עטיפה המיועדת לקיים אינטראקציה מיוחדת עם _shared_ accesses (_i.e._, באמצעות הפניה ל-`&UnsafeCell<_>`);אין קסם כלשהו כאשר מתמודדים עם _exclusive_ accesses (_e.g._, באמצעות `&mut UnsafeCell<_>`): לא התא ולא הערך העטוף עשויים להיות מכוונים למשך אותה הלוואה של ה-`&mut`.
///
/// זה מוצג על ידי אביזר [`.get_mut()`], שהוא _safe_ getter המניב `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// הנה דוגמה המציגה כיצד לשנות בצורה מושלמת את התוכן של `UnsafeCell<_>` למרות שיש מספר הפניות שמכנות את התא:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // קבל הפניות מרובות/במקביל/משותפות לאותו `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // בטיחות: במסגרת זו אין התייחסויות אחרות לתוכן 'x',
///     // כך שלנו הוא ייחודי למעשה.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- ללוות-+
///     *p1_exclusive += 27; // |
/// } // <---------- לא יכול לחרוג מנקודה זו -------------------+
///
/// unsafe {
///     // בטיחות: במסגרת זו איש אינו מצפה לקבל גישה בלעדית לתכני 'x',
///     // כך שנוכל לקבל מספר גישות משותפות במקביל.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// הדוגמה הבאה מציגה את העובדה שגישה בלעדית ל-`UnsafeCell<T>` מרמזת על גישה בלעדית ל-`T` שלה:
///
/// ```rust
/// #![forbid(unsafe_code)] // עם גישה בלעדית,
///                         // `UnsafeCell` הוא עטיפה ללא שקוף, ולכן אין צורך ב-`unsafe` כאן.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // קבל סימוכין ייחודי שנבדק בזמן הידור ל-`x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // בהפניה בלעדית, אנו יכולים לשנות את התוכן בחינם.
/// *p_unique.get_mut() = 0;
/// // או, באופן שווה:
/// x = UnsafeCell::new(0);
///
/// // כאשר בבעלותנו הערך, אנו יכולים לחלץ את התוכן בחינם.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// בונה מופע חדש של `UnsafeCell` שיעטוף את הערך שצוין.
    ///
    ///
    /// כל הגישה לערך הפנימי באמצעות שיטות היא `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// פורק את הערך.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// מקבל מצביע משתנה לערך העטוף.
    ///
    /// זה יכול להיות מושלך למצביע מכל סוג שהוא.
    /// וודא שהגישה היא ייחודית (ללא הפניות פעילות, משתנות או לא) בעת הליהוק ל-`&mut T`, וודא שאין מוטציות או כינויים משתנים המתהווים בעת ליהוק ל-`&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // אנחנו יכולים פשוט להעביר את המצביע מ-`UnsafeCell<T>` ל-`T` בגלל #[repr(transparent)].
        // זה מנצל את הסטטוס המיוחד של libstd, אין שום ערובה לקוד משתמש שזה יעבוד בגרסאות future של המהדר!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// מחזירה הפניה משתנה לנתונים הבסיסיים.
    ///
    /// קריאה זו שואלת את ה-`UnsafeCell` באופן משתנה (בזמן הידור) מה שמבטיח שיש לנו את ההתייחסות היחידה.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// מקבל מצביע משתנה לערך העטוף.
    /// ההבדל ל-[`get`] הוא שהפונקציה הזו מקבלת מצביע גולמי, דבר שימושי כדי למנוע יצירת אזכורים זמניים.
    ///
    /// ניתן ללהק את התוצאה למצביע מכל סוג שהוא.
    /// וודא כי הגישה היא ייחודית (ללא הפניות פעילות, משתנות או לא) בעת הליהוק ל-`&mut T`, וודא כי לא מתקיימות מוטציות או כינויים משתנים בעת הליהוק ל-`&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// אתחול הדרגתי של `UnsafeCell` דורש `raw_get`, שכן קריאה ל-`get` תדרוש יצירת התייחסות לנתונים לא מאומתים:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // אנחנו יכולים פשוט להעביר את המצביע מ-`UnsafeCell<T>` ל-`T` בגלל #[repr(transparent)].
        // זה מנצל את הסטטוס המיוחד של libstd, אין שום ערובה לקוד משתמש שזה יעבוד בגרסאות future של המהדר!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// יוצר `UnsafeCell`, עם הערך `Default` עבור T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}