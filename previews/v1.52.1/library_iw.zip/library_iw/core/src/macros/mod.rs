#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // מתרחב ל `$crate::panic::panic_2015` או `$crate::panic::panic_2021` בהתאם למהדורה של המתקשר.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// קובע ששני ביטויים שווים זה לזה (באמצעות [`PartialEq`]).
///
/// ב-panic, מאקרו זה ידפיס את ערכי הביטויים עם ייצוג הבאגים שלהם.
///
///
/// כמו ל-[`assert!`], למקרו זה יש טופס שני, שבו ניתן לספק הודעת panic מותאמת אישית.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // ההלוואות החוזרות שלהלן הן מכוונות.
                    // בלעדיהם, חריץ החריץ להלוואות מאותחל עוד לפני השוואת הערכים, מה שמוביל להאטה ניכרת.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // ההלוואות החוזרות שלהלן הן מכוונות.
                    // בלעדיהם, חריץ החריץ להלוואות מאותחל עוד לפני השוואת הערכים, מה שמוביל להאטה ניכרת.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// קובע ששני ביטויים אינם שווים זה לזה (באמצעות [`PartialEq`]).
///
/// ב-panic, מאקרו זה ידפיס את ערכי הביטויים עם ייצוג הבאגים שלהם.
///
///
/// כמו ל-[`assert!`], למקרו זה יש טופס שני, שבו ניתן לספק הודעת panic מותאמת אישית.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // ההלוואות החוזרות שלהלן הן מכוונות.
                    // בלעדיהם, חריץ החריץ להלוואות מאותחל עוד לפני השוואת הערכים, מה שמוביל להאטה ניכרת.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // ההלוואות החוזרות שלהלן הן מכוונות.
                    // בלעדיהם, חריץ החריץ להלוואות מאותחל עוד לפני השוואת הערכים, מה שמוביל להאטה ניכרת.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// טוען כי ביטוי בוליאני הוא `true` בזמן הריצה.
///
/// פעולה זו תפעיל את המאקרו [`panic!`] אם לא ניתן להעריך את הביטוי שסופק ל-`true` בזמן הריצה.
///
/// כמו ל-[`assert!`], גם למאקרו זה יש גרסה שנייה, בה ניתן לספק הודעת panic מותאמת אישית.
///
/// # Uses
///
/// בניגוד ל-[`assert!`], הצהרות `debug_assert!` מופעלות רק במבנים שאינם מותאמים כברירת מחדל.
/// מבנה אופטימיזציה לא יבצע הצהרות `debug_assert!` אלא אם כן `-C debug-assertions` יועבר למהדר.
/// זה הופך את `debug_assert!` לשימושי לבדיקות יקרות מכדי להיות קיימות בבניית גרסאות אך עשויות להועיל במהלך הפיתוח.
/// התוצאה של הרחבת `debug_assert!` נבדקת תמיד.
///
/// קביעה לא מסומנת מאפשרת לתוכנית במצב לא עקבי להמשיך לפעול, שעלולה להיות לה השלכות בלתי צפויות אך אינה מציגה חוסר בטיחות כל עוד זה קורה רק בקוד בטוח.
///
/// עלות הביצוע של קביעות, לעומת זאת, אינה ניתנת למדידה באופן כללי.
/// החלפת [`assert!`] ב-`debug_assert!` מעודדת לפיכך רק לאחר פרופיל יסודי, וחשוב מכך, רק בקוד בטוח!
///
/// # Examples
///
/// ```
/// // ההודעה panic עבור קביעות אלה היא הערך המחמיר של הביטוי שניתן.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // פונקציה מאוד פשוטה
/// debug_assert!(some_expensive_computation());
///
/// // לטעון עם הודעה מותאמת אישית
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// קובע ששני ביטויים שווים זה לזה.
///
/// ב-panic, מאקרו זה ידפיס את ערכי הביטויים עם ייצוג הבאגים שלהם.
///
/// בניגוד ל-[`assert_eq!`], הצהרות `debug_assert_eq!` מופעלות רק במבנים שאינם מותאמים כברירת מחדל.
/// מבנה אופטימיזציה לא יבצע הצהרות `debug_assert_eq!` אלא אם כן `-C debug-assertions` יועבר למהדר.
/// זה הופך את `debug_assert_eq!` לשימושי לבדיקות יקרות מכדי להיות קיימות בבניית גרסאות אך עשויות להועיל במהלך הפיתוח.
///
/// התוצאה של הרחבת `debug_assert_eq!` נבדקת תמיד.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// טוען ששני ביטויים אינם שווים זה לזה.
///
/// ב-panic, מאקרו זה ידפיס את ערכי הביטויים עם ייצוג הבאגים שלהם.
///
/// בניגוד ל-[`assert_ne!`], הצהרות `debug_assert_ne!` מופעלות רק במבנים שאינם מותאמים כברירת מחדל.
/// מבנה אופטימיזציה לא יבצע הצהרות `debug_assert_ne!` אלא אם כן `-C debug-assertions` יועבר למהדר.
/// זה הופך את `debug_assert_ne!` לשימושי לבדיקות יקרות מכדי להיות קיימות בבניית גרסאות אך עשויות להועיל במהלך הפיתוח.
///
/// התוצאה של הרחבת `debug_assert_ne!` נבדקת תמיד.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// מחזירה אם הביטוי הנתון תואם לאחת מהתבניות הנתונות.
///
/// כמו בביטוי `match`, הדפוס יכול להיות מלווה באופציה `if` וביטוי שומר שיש לו גישה לשמות הקשורים לתבנית.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// מבטל את גלישת התוצאה או מפיץ את השגיאה שלה.
///
/// מפעיל ה-`?` התווסף להחלפת `try!` ויש להשתמש במקום זאת.
/// יתר על כן, `try` היא מילה שמורה ב-Rust 2018, כך שאם אתה חייב להשתמש בה, תצטרך להשתמש ב-[raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` תואם את [`Result`] הנתון.במקרה של גרסת `Ok`, לביטוי יש ערך הערך העטוף.
///
/// במקרה של גרסת `Err`, הוא מאחזר את השגיאה הפנימית.לאחר מכן `try!` מבצע המרה באמצעות `From`.
/// זה מספק המרה אוטומטית בין שגיאות מיוחדות לבין שגיאות כלליות יותר.
/// לאחר מכן מוחזרת מיד השגיאה שהתקבלה.
///
/// בגלל ההחזרה המוקדמת, ניתן להשתמש ב-`try!` רק בפונקציות שמחזירות את [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // השיטה המועדפת להחזרת שגיאות מהירות
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // השיטה הקודמת להחזרת שגיאות מהירות
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // זה שווה ערך ל:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// כותב נתונים מעוצבים למאגר.
///
/// מאקרו זה מקבל 'writer', מחרוזת פורמט ורשימת ארגומנטים.
/// הטיעונים יעוצבו על פי מחרוזת הפורמט שצוינה והתוצאה תועבר לסופר.
/// הכותב יכול להיות כל ערך בשיטת `write_fmt`;בדרך כלל זה מגיע מיישום של ה-[`fmt::Write`] או ה-[`io::Write`] trait.
/// המאקרו מחזיר את כל מה ששיטת `write_fmt` מחזירה;בדרך כלל [`fmt::Result`], או [`io::Result`].
///
/// ראה [`std::fmt`] למידע נוסף על תחביר המחרוזת בפורמט.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// מודול יכול לייבא את `std::fmt::Write` ו-`std::io::Write` ולהתקשר ל-`write!` על אובייקטים המיישמים אחד מהם, מכיוון שאובייקטים אינם מיישמים בדרך כלל את שניהם.
///
/// עם זאת, על המודול לייבא את המוסמכים traits כדי ששמם לא יתנגש:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // משתמש ב-fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // משתמש ב-io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: ניתן להשתמש במאקרו זה גם בהגדרות `no_std`.
/// בהתקנת `no_std` אתה אחראי לפרטי ההטמעה של הרכיבים.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// כתוב נתונים מעוצבים למאגר, עם צירוף קו חדש.
///
/// בכל הפלטפורמות, הקו החדש הוא דמות ה-LINE FEED (`\n`/`U+000A`) בלבד (ללא CARRIAGE RETURN (`\r`/`U+000D`) נוסף.
///
/// לקבלת מידע נוסף, ראה [`write!`].למידע על תחביר המחרוזת בפורמט, ראה [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// מודול יכול לייבא את `std::fmt::Write` ו-`std::io::Write` ולהתקשר ל-`write!` על אובייקטים המיישמים אחד מהם, מכיוון שאובייקטים אינם מיישמים בדרך כלל את שניהם.
/// עם זאת, על המודול לייבא את המוסמכים traits כדי ששמם לא יתנגש:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // משתמש ב-fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // משתמש ב-io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// מציין קוד שלא ניתן להגיע אליו.
///
/// זה שימושי בכל עת שהמהדר לא יכול לקבוע שקוד כלשהו אינו נגיש.לדוגמה:
///
/// * התאם זרועות עם תנאי שמירה.
/// * לולאות שמסתיימות באופן דינמי.
/// * מוחלפים שמסתיימים באופן דינמי.
///
/// אם הקביעה שהקוד אינו ניתן להשגה מוכיחה שגויה, התוכנית מסתיימת מייד עם [`panic!`].
///
/// המקביל הלא בטוח של מאקרו זה הוא פונקציית [`unreachable_unchecked`], שתגרום להתנהגות לא מוגדרת אם יגיעו לקוד.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// זה תמיד יהיה [`panic!`].
///
/// # Examples
///
/// התאמת זרועות:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // לקמפל שגיאה אם הגיבו
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // אחת היישומים הגרועים ביותר של x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// מציין קוד לא מיושם על ידי פאניקה עם הודעה של "not implemented".
///
/// זה מאפשר לקוד שלך לבדוק סוג, וזה שימושי אם אתה עושה טיפוס או מיישם trait שדורש מספר שיטות שאינך מתכנן להשתמש בכולן.
///
/// ההבדל בין `unimplemented!` ל-[`todo!`] הוא שבעוד ש-`todo!` מעביר כוונה ליישם את הפונקציונליות מאוחר יותר וההודעה היא "not yet implemented", `unimplemented!` לא טוען טענות כאלה.
/// המסר שלה הוא "not implemented".
/// כמו כן, חלק מה-IDE יסמנו טודו!
///
/// # Panics
///
/// זה תמיד יהיה [`panic!`] מכיוון ש `unimplemented!` הוא רק קיצור של `panic!` עם הודעה קבועה וספציפית.
///
/// בדומה ל-`panic!`, למקרו זה יש טופס שני להצגת ערכים מותאמים אישית.
///
/// # Examples
///
/// נגיד שיש לנו trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// אנו רוצים ליישם את `Foo` עבור 'MyStruct', אך משום מה הגיוני רק ליישם את פונקציית `bar()`.
/// `baz()` ו-`qux()` עדיין יצטרך להיות מוגדר ביישום שלנו `Foo`, אך אנו יכולים להשתמש ב-`unimplemented!` בהגדרות שלהם כדי לאפשר לקוד שלנו להיערך.
///
/// אנו עדיין רוצים להפסיק את הפעלת התוכנית אם יגיעו לשיטות הלא מיושמות.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // אין שום היגיון ל-`baz` ל-`MyStruct`, כך שאין לנו שום היגיון כאן בכלל.
/////
///         // פעולה זו תציג את "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // יש לנו קצת היגיון כאן, אנחנו יכולים להוסיף הודעה ללא מיושם!כדי להציג את המחדל שלנו.
///         // פעולה זו תציג: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// מציין קוד לא גמור.
///
/// זה יכול להיות שימושי אם אתה עושה טיפוס של טיפוס ורק רוצה לבדוק את סוג הקוד שלך.
///
/// ההבדל בין [`unimplemented!`] ל-`todo!` הוא שבעוד ש-`todo!` מעביר כוונה ליישם את הפונקציונליות מאוחר יותר וההודעה היא "not yet implemented", `unimplemented!` לא טוען טענות כאלה.
/// המסר שלה הוא "not implemented".
/// כמו כן, חלק מה-IDE יסמנו טודו!
///
/// # Panics
///
/// זה תמיד יהיה [`panic!`].
///
/// # Examples
///
/// הנה דוגמה לקוד מתמשך.יש לנו trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// אנו רוצים ליישם את `Foo` באחד מהסוגים שלנו, אך אנו רוצים לעבוד רק על `bar()` תחילה.על מנת שהקוד שלנו יתקבץ, עלינו ליישם את `baz()`, כדי שנוכל להשתמש ב-`todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // היישום הולך לכאן
///     }
///
///     fn baz(&self) {
///         // בואו לא נדאג ליישם את baz() לעת עתה
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // אנחנו אפילו לא משתמשים ב-baz(), אז זה בסדר.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// הגדרות של פקודות מאקרו מובנות.
///
/// רוב מאפייני המאקרו (יציבות, נראות וכו ') נלקחים מקוד המקור כאן, למעט פונקציות הרחבה שהופכות תשומות מאקרו ליציאות, פונקציות אלה מסופקות על ידי המהדר.
///
///
pub(crate) mod builtin {

    /// גורם לאוסף להיכשל עם הודעת השגיאה הנתונה כאשר נתקלים בו.
    ///
    /// יש להשתמש במאקרו זה כאשר crate משתמש באסטרטגיית קומפילציה מותנית כדי לספק הודעות שגיאה טובות יותר בתנאים שגויים.
    ///
    /// זו הצורה ברמת המהדר של [`panic!`], אך פולטת שגיאה במהלך *קומפילציה* ולא בזמן *זמן ריצה*.
    ///
    /// # Examples
    ///
    /// שתי דוגמאות כאלה הן פקודות מאקרו וסביבות `#[cfg]`.
    ///
    /// פולטים שגיאת מהדר טובה יותר אם מאקרו מועבר לערכים לא חוקיים.
    /// ללא ה-branch הסופי, המהדר עדיין היה פולט שגיאה, אך הודעת השגיאה לא תזכיר את שני הערכים התקפים.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// פלט שגיאת מהדר אם אחת ממספר התכונות אינה זמינה.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// בונה פרמטרים עבור פקודות המאקרו האחרות של עיצוב מחרוזות.
    ///
    /// מאקרו זה פועל על ידי לקיחת מחרוזת עיצוב מילולית המכילה `{}` עבור כל טיעון נוסף שהועבר.
    /// `format_args!` מכין את הפרמטרים הנוספים בכדי להבטיח שניתן יהיה לפרש את הפלט כמחרוזת וקנוניזציה של הטיעונים לסוג יחיד.
    /// כל ערך שמיישם את [`Display`] trait יכול להיות מועבר ל-`format_args!`, וכך גם כל יישום [`Debug`] יכול להיות מועבר ל-`{:?}` בתוך מחרוזת העיצוב.
    ///
    ///
    /// מאקרו זה מייצר ערך מסוג [`fmt::Arguments`].ניתן להעביר ערך זה למקרו בתוך [`std::fmt`] לצורך ביצוע הפניה שימושית.
    /// כל שאר המאקרו לעיצוב (['פורמט!'], [`write!`], [`println!`] וכו ') מקושרים באמצעות זה.
    /// `format_args!`, שלא כמו המאקרו הנגזרים שלו, נמנע מהקצאות ערימה.
    ///
    /// אתה יכול להשתמש בערך [`fmt::Arguments`] ש-`format_args!` מחזיר בהקשרים `Debug` ו-`Display` כפי שנראה למטה.
    /// הדוגמה מראה גם שפורמט `Debug` ו-`Display` לאותו הדבר: מחרוזת הפורמט האינטרפולציה ב-`format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// למידע נוסף, עיין בתיעוד ב-[`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// זהה ל-`format_args`, אך בסופו של דבר מוסיף שורה חדשה.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// בודק משתנה סביבה בזמן הידור.
    ///
    /// מאקרו זה יתרחב לערכו של משתנה הסביבה הנקוב בזמן הקומפילציה, ויניב ביטוי מסוג `&'static str`.
    ///
    ///
    /// אם לא מוגדר משתנה הסביבה, תיפלט שגיאת אוסף.
    /// כדי לא להוציא שגיאת קומפילציה, השתמש במקום זאת במאקרו [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// באפשרותך להתאים אישית את הודעת השגיאה על ידי העברת מחרוזת כפרמטר השני:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// אם משתנה הסביבה `documentation` אינו מוגדר, תקבל את השגיאה הבאה:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// באופן אופציונלי בודק משתנה סביבה בזמן הקומפילציה.
    ///
    /// אם משתנה הסביבה הנקוב קיים בזמן הקומפילציה, זה יתרחב לביטוי מסוג `Option<&'static str>` שערכו הוא `Some` מערכו של משתנה הסביבה.
    /// אם משתנה הסביבה אינו קיים, פעולה זו תתרחב ל-`None`.
    /// ראה [`Option<T>`][Option] למידע נוסף על סוג זה.
    ///
    /// שגיאת זמן קומפילציה לעולם אינה נפלטת בעת שימוש במאקרו זה ללא קשר אם משתנה הסביבה קיים או לא.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// לשרשר מזהים למזהה אחד.
    ///
    /// מאקרו זה לוקח מספר כלשהו של מזהים המופרדים בפסיקים, ומשרשר את כולם לאחד, ומניב ביטוי שהוא מזהה חדש.
    /// שים לב שההיגיינה הופכת אותו לכזה שמאקרו זה אינו יכול לתפוס משתנים מקומיים.
    /// כמו כן, ככלל, פקודות מאקרו מותרות רק במיקום הפריט, ההצהרה או הביטוי.
    /// כלומר, למרות שתוכל להשתמש במאקרו זה להתייחסות למשתנים קיימים, פונקציות או מודולים וכו ', אינך יכול להגדיר באמצעותו אחד חדש.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (חדש, כיף, שם) { }//לא שמיש בצורה כזו!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// משתרב ליטרלים לפרוסת מיתרים סטטית.
    ///
    /// מאקרו זה לוקח כל מספר של מילוליות מופרדות באמצעות פסיקים, ומניב ביטוי מסוג `&'static str` המייצג את כל המילוליות המורכבים משמאל לימין.
    ///
    ///
    /// מספרים שלמים ונקודות צף מחומרים על מנת לשרשר אותם.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// מתרחב למספר השורה עליו הופעל.
    ///
    /// עם [`column!`] ו-[`file!`], פקודות מאקרו אלה מספקות מידע על איתור באגים למפתחים אודות המיקום בתוך המקור.
    ///
    /// לביטוי המורחב יש סוג `u32` והוא מבוסס על 1, כך שהשורה הראשונה בכל קובץ מוערכת ל-1, השנייה ל-2 וכו '.
    /// זה עולה בקנה אחד עם הודעות שגיאה של מהדרים נפוצים או עורכים פופולריים.
    /// השורה המוחזרת היא *לא בהכרח* השורה של קריאת ה-`line!` עצמה, אלא קריאת המאקרו הראשונה המובילה להפעלת המאקרו `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// מתרחב למספר העמודה בו הופעל.
    ///
    /// עם [`line!`] ו-[`file!`], פקודות מאקרו אלה מספקות מידע על איתור באגים למפתחים אודות המיקום בתוך המקור.
    ///
    /// לביטוי המורחב יש סוג `u32` והוא מבוסס על 1, כך שהעמודה הראשונה בכל שורה מוערכת ל-1, השנייה ל-2 וכו '.
    /// זה עולה בקנה אחד עם הודעות שגיאה של מהדרים נפוצים או עורכים פופולריים.
    /// העמודה המוחזרת היא *לא בהכרח* השורה של קריאת ה-`column!` עצמה, אלא קריאת המאקרו הראשונה שמובילה להפעלת המאקרו `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// מתרחב לשם הקובץ בו הופעל.
    ///
    /// עם [`line!`] ו-[`column!`], פקודות מאקרו אלה מספקות מידע על איתור באגים למפתחים אודות המיקום בתוך המקור.
    ///
    /// לביטוי המורחב יש סוג `&'static str`, והקובץ שהוחזר אינו הפעלת המאקרו `file!` עצמו, אלא הפעלת המאקרו הראשונה המובילה להפעלת המאקרו `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// מחמיר את טיעוניו.
    ///
    /// מאקרו זה יניב ביטוי מסוג `&'static str` שהוא החמרה של כל ה-tokens שהועבר למקרו.
    /// לא מוגבלות תחביר של קריאת המאקרו עצמה.
    ///
    /// שים לב שהתוצאות המורחבות של קלט tokens עשויות להשתנות ב-future.אתה צריך להיות זהיר אם אתה מסתמך על הפלט.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// כולל קובץ מקודד UTF-8 כמחרוזת.
    ///
    /// הקובץ ממוקם ביחס לקובץ הנוכחי (בדומה למציאת המודולים).
    /// הנתיב המסופק מתפרש באופן ספציפי לפלטפורמה בזמן הקומפילציה.
    /// כך, למשל, קריאה עם נתיב Windows המכיל קו נטוי אחורי `\` לא תיאסף כראוי ב-Unix.
    ///
    ///
    /// מאקרו זה יניב ביטוי מסוג `&'static str` שהוא תוכן הקובץ.
    ///
    /// # Examples
    ///
    /// נניח שיש שני קבצים באותה ספרייה עם התוכן הבא:
    ///
    /// קובץ 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// קובץ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// קומפילציה של 'main.rs' והפעלת הבינארי המתקבל תדפיס את "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// כולל קובץ כהפניה למערך בתים.
    ///
    /// הקובץ ממוקם ביחס לקובץ הנוכחי (בדומה למציאת המודולים).
    /// הנתיב המסופק מתפרש באופן ספציפי לפלטפורמה בזמן הקומפילציה.
    /// כך, למשל, קריאה עם נתיב Windows המכיל קו נטוי אחורי `\` לא תיאסף כראוי ב-Unix.
    ///
    ///
    /// מאקרו זה יניב ביטוי מסוג `&'static [u8; N]` שהוא תוכן הקובץ.
    ///
    /// # Examples
    ///
    /// נניח שיש שני קבצים באותה ספרייה עם התוכן הבא:
    ///
    /// קובץ 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// קובץ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// קומפילציה של 'main.rs' והפעלת הבינארי המתקבל תדפיס את "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// מתרחב למחרוזת המייצגת את נתיב המודול הנוכחי.
    ///
    /// ניתן לחשוב על נתיב המודולים הנוכחי כהיררכיית המודולים המובילים חזרה אל crate root.
    /// המרכיב הראשון של הנתיב שהוחזר הוא שמו של ה-crate שמורכב כעת.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// מעריך שילובים בוליאניים של דגלי תצורה בזמן הידור.
    ///
    /// בנוסף לתכונה `#[cfg]`, מאקרו זה מסופק כדי לאפשר הערכת ביטוי בוליאני של דגלי תצורה.
    /// זה מוביל לעיתים קרובות לקוד פחות משוכפל.
    ///
    /// התחביר שניתן למקרו זה הוא תחביר זהה לתכונה [`cfg`].
    ///
    /// `cfg!`, בניגוד ל-`#[cfg]`, אינו מסיר שום קוד ומעריך רק נכון או לא נכון.
    /// לדוגמה, כל הבלוקים בביטוי if/else צריכים להיות תקפים כאשר משתמשים ב-`cfg!` לתנאי, ללא קשר למה שמעריך `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// מנתח קובץ כביטוי או פריט בהתאם להקשר.
    ///
    /// הקובץ ממוקם ביחס לקובץ הנוכחי (בדומה למציאת המודולים).הנתיב המסופק מתפרש באופן ספציפי לפלטפורמה בזמן הקומפילציה.
    /// כך, למשל, קריאה עם נתיב Windows המכיל קו נטוי אחורי `\` לא תיאסף כראוי ב-Unix.
    ///
    /// שימוש במאקרו זה הוא לרוב רעיון רע, מכיוון שאם הקובץ ינותח כביטוי, הוא ימוקם בקוד שמסביב באופן לא היגייני.
    /// זה יכול לגרום למשתנים או לפונקציות להיות שונים ממה שהקובץ ציפה אם יש משתנים או פונקציות שיש להם אותו שם בקובץ הנוכחי.
    ///
    ///
    /// # Examples
    ///
    /// נניח שיש שני קבצים באותה ספרייה עם התוכן הבא:
    ///
    /// קובץ 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// קובץ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// קומפילציה של 'main.rs' והפעלת הבינארי המתקבל תדפיס את "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// טוען כי ביטוי בוליאני הוא `true` בזמן הריצה.
    ///
    /// פעולה זו תפעיל את המאקרו [`panic!`] אם לא ניתן להעריך את הביטוי שסופק ל-`true` בזמן הריצה.
    ///
    /// # Uses
    ///
    /// קביעות נבדקות תמיד בבנייני ניפוי שגיאות וגם במהדורות, ולא ניתן להשביתן.
    /// ראה [`debug_assert!`] לקבלת טענות שאינן מופעלות ב-build build כברירת מחדל.
    ///
    /// קוד לא בטוח עשוי להסתמך על `assert!` כדי לאכוף את הזרמים בזמן הריצה שאם יופרו עלולים להוביל לחוסר בטיחות.
    ///
    /// מקרי שימוש אחרים של `assert!` כוללים בדיקה ואכיפה של משתמשי זמן ריצה בקוד בטוח (שהפרתם אינה יכולה לגרום לחוסר בטיחות).
    ///
    ///
    /// # הודעות בהתאמה אישית
    ///
    /// למאקרו זה יש טופס שני, שבו ניתן לספק הודעת panic מותאמת אישית עם או בלי ארגומנטים לעיצוב.
    /// ראה תחביר לטופס זה ב-[`std::fmt`].
    /// ביטויים המשמשים כטיעוני פורמט יוערכו רק אם הקביעה נכשלה.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // ההודעה panic עבור קביעות אלה היא הערך המחמיר של הביטוי שניתן.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // פונקציה מאוד פשוטה
    ///
    /// assert!(some_computation());
    ///
    /// // לטעון עם הודעה מותאמת אישית
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// הרכבה מוטבעת.
    ///
    /// קרא את [unstable book] לשימוש.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// הרכבה מוטבעת בסגנון LLVM.
    ///
    /// קרא את [unstable book] לשימוש.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// הרכבה מוטבעת ברמת המודול.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// הדפסות העבירו את tokens לפלט הסטנדרטי.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// מאפשר או משבית את פונקציונליות המעקב המשמשת לניפוי באגים במקרואים אחרים.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// מאקרו תכונות המשמש להחלת פקודות מאקרו נגזרות.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// מאקרו תכונה מוחל על פונקציה כדי להפוך אותה לבדיקת יחידה.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// מאקרו תכונה מוחל על פונקציה כדי להפוך אותה לבדיקת אמת מידה.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// פרט יישום של פקודות המאקרו `#[test]` ו-`#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// מאקרו תכונה מוחל על סטטי כדי לרשום אותו כמקצה גלובלי.
    ///
    /// ראה גם [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// שומר על הפריט שעליו הוא מוחל אם הנתיב שעבר נגיש, ומסיר אותו אחרת.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// מרחיב את כל מאפייני `#[cfg]` ו-`#[cfg_attr]` בקטע הקוד עליו הוא מוחל.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// פרט יישום לא יציב של מהדר `rustc`, אין להשתמש בו.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// פרט יישום לא יציב של מהדר `rustc`, אין להשתמש בו.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}