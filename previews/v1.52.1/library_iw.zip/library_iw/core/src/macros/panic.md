Panics החוט הנוכחי.

זה מאפשר לתוכנית להסתיים באופן מיידי ולספק משוב למתקשר לתוכנית.
`panic!` יש להשתמש כאשר תוכנית מגיעה למצב בלתי ניתן לשחזור.

מאקרו זה הוא הדרך המושלמת לקבוע תנאים בקוד לדוגמא ובבדיקות.
`panic!` קשורה קשר הדוק עם שיטת `unwrap` של XUMX ו-[`Result`][runwrap].
שתי היישומים קוראים ל-`panic!` כאשר הם מוגדרים לגרסאות [`None`] או [`Err`].

בעת שימוש ב-`panic!()` תוכלו לציין עומס מטען מחרוזת, שנבנה באמצעות התחביר [`format!`].
מטען זה משמש בעת הזרקת panic לחוט Rust הקורא, מה שגורם לשרשור ל-panic לחלוטין.

ההתנהגות של ברירת המחדל של `std` hook, כלומר
הקוד שפועל ישירות לאחר הפעלת panic הוא להדפיס את מטען ההודעה ל-`stderr` יחד עם המידע file/line/column של שיחת `panic!()`.

אתה יכול לעקוף את panic hook באמצעות [`std::panic::set_hook()`].
בתוך ה-hook ניתן לגשת אל panic כ-`&dyn Any + Send`, המכיל `&str` או `String` לצורך קריאות `panic!()` רגילות.
ל-panic עם ערך מסוג אחר, ניתן להשתמש ב-[`panic_any`].

[`Result`] enum הוא לרוב פיתרון טוב יותר להתאוששות משגיאות מאשר שימוש במאקרו `panic!`.
יש להשתמש במאקרו זה כדי למנוע המשך שימוש בערכים שגויים, כגון ממקורות חיצוניים.
מידע מפורט על טיפול בשגיאות נמצא ב-[book].

ראה גם מאקרו [`compile_error!`], להעלאת שגיאות במהלך הידור.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# יישום שוטף

אם החוט הראשי panics הוא יפסיק את כל השרשורים שלך ויסיים את התוכנית שלך בקוד `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





