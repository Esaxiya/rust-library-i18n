#![stable(feature = "core_hint", since = "1.27.0")]

//! רמזים למהדר שמשפיעים על אופן פליטת הקוד או אופטימיזציה.
//! רמזים עשויים להיות זמן קומפילציה או זמן ריצה.

use crate::intrinsics;

/// מודיע למהדר כי לא ניתן להגיע לנקודה זו בקוד, מה שמאפשר אופטימיזציות נוספות.
///
/// # Safety
///
/// הגעה לפונקציה זו היא התנהגות *לא מוגדרת*(UB) לחלוטין.בפרט, המהדר מניח כי כל ה-UB אסור לקרות לעולם, ולכן יבטל את כל הענפים שיגיעו לשיחה ל-`unreachable_unchecked()`.
///
/// כמו כל המקרים של UB, אם הנחה זו תתברר כשגויה, קרי, ניתן להגיע לשיחת `unreachable_unchecked()` בין כל זרימת השליטה האפשרית, המהדר ישתמש באסטרטגיית אופטימיזציה שגויה, ולעתים אף עלול להשחית קוד לכאורה לא קשור ולגרום לקושי בעיות לניפוי באגים.
///
///
/// השתמש בפונקציה זו רק כאשר תוכל להוכיח שהקוד לעולם לא יקרא לה.
/// אחרת, שקול להשתמש במאקרו [`unreachable!`], שאינו מאפשר אופטימיזציות אך יהיה panic בעת ביצועו.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` תמיד חיובי (לא אפס), ומכאן ש-`checked_div` לעולם לא יחזיר את `None`.
/////
///     // לכן, ה-branch האחר אינו ניתן להשגה.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // בטיחות: חוזה הבטיחות עבור `intrinsics::unreachable` חייב
    // יתקבל על ידי המתקשר.
    unsafe { intrinsics::unreachable() }
}

/// שולח הוראות מכונה לאותת למעבד שהוא פועל בלולאת ספין עמוסה המתנה ("נעילת סיבוב").
///
/// עם קבלת אות הלולאת הסיבוב המעבד יכול לייעל את התנהגותו על ידי, למשל, חיסכון בחשמל או החלפת חוטי hyper.
///
/// פונקציה זו שונה מ-[`thread::yield_now`] המניב ישירות לתזמן המערכת, ואילו `spin_loop` אינו מתקשר עם מערכת ההפעלה.
///
/// מקרה שימוש נפוץ עבור `spin_loop` הוא הטמעת ספינינג אופטימי מוגבל בלולאת CAS בפרימיטיביות לסנכרון.
/// כדי להימנע מבעיות כמו היפוך עדיפות, מומלץ בחום לסיים את לולאת הסיבוב לאחר כמות איטרציות סופית וביצוע מנגנון חסימה מתאים.
///
///
/// **הערה**: בפלטפורמות שאינן תומכות בקבלת רמזים על ספין לולאה פונקציה זו אינה עושה דבר.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // ערך אטומי משותף שמשתמש בו חוטים לתיאום
/// let live = Arc::new(AtomicBool::new(false));
///
/// // בסופו של דבר נקבע את הערך בשרשור הרקע
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // בצע עבודה ואז הפוך את הערך לחי
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // חזרה לשרשור הנוכחי שלנו, אנו מחכים להגדרת הערך
/// while !live.load(Ordering::Acquire) {
///     // לולאת הסיבוב היא רמז למעבד שאנחנו מחכים לו, אבל כנראה שלא הרבה זמן
/////
///     hint::spin_loop();
/// }
///
/// // הערך מוגדר כעת
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // בטיחות: ה-`cfg` attr מבטיח שנבצע זאת רק על יעדי x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // בטיחות: ה-`cfg` attr מבטיח שנבצע זאת רק על יעדי x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // בטיחות: ה-`cfg` attr מבטיח שנבצע זאת רק על יעדי aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // בטיחות: ה-`cfg` attr מבטיח שאנחנו מבצעים זאת רק על מטרות זרוע
            // עם תמיכה בתכונת v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// פונקציית זהות ש *__ רומזת __* למהדר להיות פסימית מקסימאלית לגבי מה ש-`black_box` יכול לעשות.
///
/// בניגוד ל-[`std::convert::identity`], מהדר Rust מוזמן להניח ש-`black_box` יכול להשתמש ב-`dummy` בכל דרך חוקית אפשרית שמותר לקוד Rust מבלי להכניס התנהגות לא מוגדרת בקוד החיוג.
///
/// מאפיין זה הופך את `black_box` לשימושי כתיבת קוד בו אופטימיזציות מסוימות אינן רצויות, כגון אמות מידה.
///
/// שים לב עם זאת, ש-`black_box` מסופק (וניתן רק) רק על בסיס "best-effort".המידה שבה היא יכולה לחסום אופטימיזציות עשויה להשתנות בהתאם לפלטפורמה ולגב הקוד של קוד.
/// תוכניות אינן יכולות להסתמך על `black_box` עבור *נכונות* בשום צורה שהיא.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // עלינו "use" את הטיעון באופן כלשהו LLVM לא יכול להתבונן פנימה, ועל יעדים התומכים בו אנו יכולים בדרך כלל למנף הרכבה מוטבעת לשם כך.
    // הפרשנות של LLVM להרכבה המובנית היא שזה, ובכן, קופסה שחורה.
    // זה לא היישום הגדול ביותר מכיוון שהוא כנראה מבטל אופטימיזציה יותר ממה שאנחנו רוצים, אבל זה מספיק טוב עד כה.
    //
    //

    #[cfg(not(miri))] // זה רק רמז, אז זה בסדר לדלג על מירי.
    // בטיחות: ההרכבה המובנית היא ללא-אופ.
    unsafe {
        // FIXME: לא ניתן להשתמש ב-`asm!` מכיוון שהוא אינו תומך ב-MIPS ובארכיטקטורות אחרות.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}