use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// מחזירה את `true` אם המצביע אפס.
    ///
    /// שים לב שלטיפוסים לא גדולים יש מצביעי אפס רבים אפשריים, מכיוון שרק מצביע הנתונים הגולמיים נחשב, לא אורכם, הטבלה וכו '.
    /// לכן, שתי מצביעים שאפסות עדיין אינן עשויות להשוות שוות זו לזו.
    ///
    /// ## התנהגות במהלך הערכת קונסט
    ///
    /// כאשר משתמשים בפונקציה זו במהלך הערכת const, היא עשויה להחזיר `false` עבור מצביעים שמתבררים כלא בזמן ריצה.
    /// באופן ספציפי, כאשר מצביע לזיכרון כלשהו מתקזז מעבר לתחום שלו באופן שהמצביע המתקבל אפס, הפונקציה עדיין תחזיר את `false`.
    ///
    /// אין שום דרך ש-CTFE ידע את מיקומו המוחלט של אותו זיכרון, ולכן איננו יכולים לדעת אם המצביע אפס או לא.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // השווה באמצעות גבס למצביע דק, כך שמצביעים שמנים שוקלים רק את חלק ה-"data" שלהם לבטלה.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// משליך למצביע מסוג אחר.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// פירוק מצביע (אולי רחב) לרכיבי כתובת ומטא נתונים.
    ///
    /// לאחר מכן ניתן לשחזר את המצביע באמצעות [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// מחזירה `None` אם המצביע הוא null, או אחרת מחזיר הפניה משותפת לערך העטוף ב-`Some`.אם ייתכן שהערך אינו מאוחד, יש להשתמש במקום זאת ב-[`as_uninit_ref`].
    ///
    /// עבור המקביל המשתנה ראה [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// כאשר אתה קורא לשיטה זו, עליך לוודא ש *או* המצביע הוא NULL *או* כל הדברים הבאים נכונים:
    ///
    /// * על המצביע להיות מיושר כהלכה.
    ///
    /// * זה חייב להיות "dereferencable" במובן שהוגדר ב-[the module documentation].
    ///
    /// * על המצביע להצביע על מופע מאותחל של `T`.
    ///
    /// * עליך לאכוף את כללי הכינוי של Rust, מכיוון שאורך החיים המוחזר `'a` נבחר באופן שרירותי ואינו משקף בהכרח את חיי הנתונים בפועל.
    ///   בפרט, לכל אורך החיים הזה, הזיכרון שהמצביע מצביע עליו אינו חייב להיות מוטציה (למעט בתוך `UnsafeCell`).
    ///
    /// זה חל גם אם התוצאה של שיטה זו אינה בשימוש!
    /// (החלק שעוסק באתחול עדיין לא הוחלט במלואו, אך עד שהוא, הגישה הבטוחה היחידה היא להבטיח שהם אכן מאותחלים).
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # גרסה ללא אפס
    ///
    /// אם אתה בטוח שהמצביע לעולם לא יכול להיות ריק ומחפש איזשהו סוג `as_ref_unchecked` שמחזיר את ה-`&T` במקום `Option<&T>`, דע שאתה יכול להעביר את המצביע ישירות.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // בטיחות: על המתקשר להבטיח ש-`self` תקף ל-
        // התייחסות אם היא לא בטלה.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// מחזירה את `None` אם המצביע הוא null, או מחזיר הפניה משותפת לערך העטוף ב-`Some`.
    /// בניגוד ל-[`as_ref`], זה לא דורש לאתחל את הערך.
    ///
    /// עבור המקביל המשתנה ראה [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// כאשר אתה קורא לשיטה זו, עליך לוודא ש *או* המצביע הוא NULL *או* כל הדברים הבאים נכונים:
    ///
    /// * על המצביע להיות מיושר כהלכה.
    ///
    /// * זה חייב להיות "dereferencable" במובן שהוגדר ב-[the module documentation].
    ///
    /// * עליך לאכוף את כללי הכינוי של Rust, מכיוון שאורך החיים המוחזר `'a` נבחר באופן שרירותי ואינו משקף בהכרח את חיי הנתונים בפועל.
    ///
    ///   בפרט, לכל אורך החיים הזה, הזיכרון שהמצביע מצביע עליו אינו חייב להיות מוטציה (למעט בתוך `UnsafeCell`).
    ///
    /// זה חל גם אם התוצאה של שיטה זו אינה בשימוש!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // בטיחות: על המתקשר להבטיח כי `self` עומד בכל
        // דרישות להפניה.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// מחשבת את הקיזוז ממצביע.
    ///
    /// `count` נמצא ביחידות T;למשל, `count` של 3 מייצג קיזוז מצביע של `3 * size_of::<T>()` בתים.
    ///
    /// # Safety
    ///
    /// אם אחד מהתנאים הבאים מופר, התוצאה היא התנהגות לא מוגדרת:
    ///
    /// * גם המצביע ההתחלתי וגם המוצא חייב להיות בגבול או בתים אחד מעבר לסוף אותו אובייקט שהוקצה.
    /// שים לב שב-Rust, כל משתנה (stack-allocated) נחשב לאובייקט שהוקצה נפרד.
    ///
    /// * הקיזוז המחושב,**בתים**, אינו יכול לעלות על `isize`.
    ///
    /// * הקיזוז הנמצא בגבול אינו יכול להסתמך על "wrapping around" במרחב הכתובות.כלומר, סכום הדיוק האינסופי,**בתים** חייב להתאים לגודל.
    ///
    /// המהדר והספרייה הסטנדרטית מנסים בדרך כלל להבטיח שההקצאות לעולם לא יגיעו לגודל שבו קיזוז הוא עניין.
    /// לדוגמה, `Vec` ו-`Box` מבטיחים שהם לעולם לא מקצים יותר מ-`isize::MAX` בתים, כך ש-`vec.as_ptr().add(vec.len())` תמיד בטוח.
    ///
    /// רוב הפלטפורמות ביסודן אינן יכולות אפילו לבנות הקצאה כזו.
    /// למשל, אף פלטפורמת 64 סיביות ידועה לא תוכל להגיש בקשה ל-2 <sup>63</sup> בתים, בגלל מגבלות של טבלת עמודים או פיצול שטח הכתובת.
    /// עם זאת, חלק מפלטפורמות 32 סיביות ו-16 סיביות עשויות להגיש בהצלחה בקשה ליותר מ-`isize::MAX` בתים עם דברים כמו סיומת כתובת פיזית.
    ///
    /// ככזה, זיכרון שנרכש ישירות ממקצים או מקבצי מיפוי זיכרון *עשוי* להיות גדול מכדי להתמודד עם פונקציה זו.
    ///
    /// שקול להשתמש ב-[`wrapping_offset`] במקום זאת אם קשה להגביל את המגבלות הללו.
    /// היתרון היחיד בשיטה זו הוא בכך שהיא מאפשרת אופטימיזציות מהדר יותר אגרסיביות.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `offset`.
        // המצביע שהתקבל תקף לכתיבה מכיוון שהמתקשר חייב להבטיח שהוא מצביע על אותו אובייקט שהוקצה כמו `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// מחשבת את הקיזוז ממצביע באמצעות חשבון עטיפה.
    /// `count` נמצא ביחידות T;למשל, `count` של 3 מייצג קיזוז מצביע של `3 * size_of::<T>()` בתים.
    ///
    /// # Safety
    ///
    /// פעולה זו עצמה תמיד בטוחה, אך השימוש במצביע שנוצר אינו.
    ///
    /// המצביע שנוצר נשאר מחובר לאותו אובייקט שהוקצה אליו `self`.
    /// יתכן ש *לא* ישמש לגישה לאובייקט שהוקצה אחר.שים לב שב-Rust, כל משתנה (stack-allocated) נחשב לאובייקט שהוקצה נפרד.
    ///
    /// במילים אחרות, `let z = x.wrapping_offset((y as isize) - (x as isize))`*לא* הופך את `z` לזה של `y` גם אם אנו מניחים של-`T` יש גודל `1` ואין הצפה: `z` עדיין מחובר לאובייקט ש-`x` מחובר אליו, וההפניה אליו היא התנהגות לא מוגדרת אלא אם כן `x` ו-נקודת `y` לאותו אובייקט שהוקצה.
    ///
    /// בהשוואה ל-[`offset`], שיטה זו בעצם מעכבת את הדרישה להישאר בתוך אותו אובייקט שהוקצה: [`offset`] הוא התנהגות בלתי מוגדרת מיידית בעת חציית גבולות האובייקט;`wrapping_offset` מייצר מצביע אך עדיין מוביל להתנהגות בלתי מוגדרת אם מצביע מופנה כאשר הוא מחוץ לתחום האובייקט אליו הוא מחובר.
    /// [`offset`] ניתן לבצע אופטימיזציה טובה יותר ולכן עדיף בקוד הרגיש לביצועים.
    ///
    /// הבדיקה המתעכבת מתייחסת רק לערך המצביע שהופנה אליו, ולא לערכי הביניים המשמשים במהלך חישוב התוצאה הסופית.
    /// לדוגמא, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` תמיד זהה ל-`x`.במילים אחרות, השארת האובייקט שהוקצה ואז הכניסה אליו מאוחר יותר מותרת.
    ///
    /// אם אתה צריך לחצות את גבולות האובייקט, הטיל את המצביע למספר שלם ועשה שם חשבון.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// // בוטל באמצעות מצביע גולמי במרווחים של שני אלמנטים
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // בטיחות: ל-`arith_offset` הפנימי אין דרישות קדם להיקרא.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// מחזירה `None` אם המצביע אפס, או אחרת מחזיר התייחסות ייחודית לערך העטוף ב-`Some`.אם ייתכן שהערך אינו מאוחד, יש להשתמש במקום זאת ב-[`as_uninit_mut`].
    ///
    /// עבור המקביל המשותף ראה [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// כאשר אתה קורא לשיטה זו, עליך לוודא ש *או* המצביע הוא NULL *או* כל הדברים הבאים נכונים:
    ///
    /// * על המצביע להיות מיושר כהלכה.
    ///
    /// * זה חייב להיות "dereferencable" במובן שהוגדר ב-[the module documentation].
    ///
    /// * על המצביע להצביע על מופע מאותחל של `T`.
    ///
    /// * עליך לאכוף את כללי הכינוי של Rust, מכיוון שאורך החיים המוחזר `'a` נבחר באופן שרירותי ואינו משקף בהכרח את חיי הנתונים בפועל.
    ///   בפרט, במשך תקופת החיים הזו, אל הזיכרון שהמצביע מצביע עליו אסור לגשת אליו (לקרוא או לכתוב) דרך שום מצביע אחר.
    ///
    /// זה חל גם אם התוצאה של שיטה זו אינה בשימוש!
    /// (החלק שעוסק באתחול עדיין לא הוחלט במלואו, אך עד שהוא, הגישה הבטוחה היחידה היא להבטיח שהם אכן מאותחלים).
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // זה יודפס: "[4, 2, 3]".
    /// ```
    ///
    /// # גרסה ללא אפס
    ///
    /// אם אתה בטוח שהמצביע לעולם לא יכול להיות ריק ומחפש איזשהו סוג `as_mut_unchecked` שמחזיר את ה-`&mut T` במקום `Option<&mut T>`, דע שאתה יכול להעביר את המצביע ישירות.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // זה יודפס: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // בטיחות: על המתקשר להבטיח ש-`self` תקף ל
        // התייחסות ניתנת לשינוי אם היא אינה אפסית.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// מחזירה את `None` אם המצביע הוא null, או מחזיר התייחסות ייחודית לערך העטוף ב-`Some`.
    /// בניגוד ל-[`as_mut`], זה לא דורש לאתחל את הערך.
    ///
    /// עבור המקביל המשותף ראה [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// כאשר אתה קורא לשיטה זו, עליך לוודא ש *או* המצביע הוא NULL *או* כל הדברים הבאים נכונים:
    ///
    /// * על המצביע להיות מיושר כהלכה.
    ///
    /// * זה חייב להיות "dereferencable" במובן שהוגדר ב-[the module documentation].
    ///
    /// * עליך לאכוף את כללי הכינוי של Rust, מכיוון שאורך החיים המוחזר `'a` נבחר באופן שרירותי ואינו משקף בהכרח את חיי הנתונים בפועל.
    ///
    ///   בפרט, במשך תקופת החיים הזו, אל הזיכרון שהמצביע מצביע עליו אסור לגשת אליו (לקרוא או לכתוב) דרך שום מצביע אחר.
    ///
    /// זה חל גם אם התוצאה של שיטה זו אינה בשימוש!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // בטיחות: על המתקשר להבטיח כי `self` עומד בכל
        // דרישות להפניה.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// מחזירה אם מובטח ששתי עצות יהיו שוות.
    ///
    /// בזמן ריצה פונקציה זו מתנהגת כמו `self == other`.
    /// עם זאת, בהקשרים מסוימים (למשל הערכת זמן קומפילציה), לא תמיד ניתן לקבוע שוויון של שתי מצביעים, ולכן פונקציה זו עשויה להחזיר באופן מזויף את `false` עבור מצביעים שלימים יתבררו כשווים.
    ///
    /// אך כאשר הוא מחזיר את `true`, מובטח כי המצביעים יהיו שווים.
    ///
    /// פונקציה זו היא המראה של [`guaranteed_ne`], אך אינה הפוכה.ישנן השוואות מצביעים ששתי הפונקציות מחזירות עבורן `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// ערך ההחזרה עשוי להשתנות בהתאם לגירסת המהדר והקוד הלא בטוח לא יכול להסתמך על התוצאה של פונקציה זו למען תקינות.
    /// מומלץ להשתמש בפונקציה זו רק לצורך אופטימיזציה של ביצועים כאשר ערכי החזרת `false` מזויפים על ידי פונקציה זו אינם משפיעים על התוצאה, אלא רק על הביצועים.
    /// לא נבדקו ההשלכות של שימוש בשיטה זו כדי לגרום לזמן ריצה וקוד קומפילציה להתנהג אחרת.
    /// אין להשתמש בשיטה זו כדי להציג הבדלים כאלה, ואין לייצב אותה לפני שנבין טוב יותר את הנושא הזה.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// מחזירה אם מובטח ששתי מצביעים לא יהיו שוות.
    ///
    /// בזמן ריצה פונקציה זו מתנהגת כמו `self != other`.
    /// עם זאת, בהקשרים מסוימים (למשל, הערכת זמן קומפילציה), לא תמיד ניתן לקבוע את אי השוויון בין שתי מצביעים, ולכן פונקציה זו עשויה להחזיר באופן מזויף את `false` עבור מצביעים שלימים יתבררו כלא שווים.
    ///
    /// אך כאשר הוא מחזיר את `true`, המצביעים מובטחים שלא יהיו שווים.
    ///
    /// פונקציה זו היא המראה של [`guaranteed_eq`], אך אינה הפוכה.ישנן השוואות מצביעים ששתי הפונקציות מחזירות עבורן `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// ערך ההחזרה עשוי להשתנות בהתאם לגירסת המהדר והקוד הלא בטוח לא יכול להסתמך על התוצאה של פונקציה זו למען תקינות.
    /// מומלץ להשתמש בפונקציה זו רק לצורך אופטימיזציה של ביצועים כאשר ערכי החזרת `false` מזויפים על ידי פונקציה זו אינם משפיעים על התוצאה, אלא רק על הביצועים.
    /// לא נבדקו ההשלכות של שימוש בשיטה זו כדי לגרום לזמן ריצה וקוד קומפילציה להתנהג אחרת.
    /// אין להשתמש בשיטה זו כדי להציג הבדלים כאלה, ואין לייצב אותה לפני שנבין טוב יותר את הנושא הזה.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// מחשבת את המרחק בין שתי מצביעים.הערך המוחזר הוא ביחידות T: המרחק בבייטים מחולק ב-`mem::size_of::<T>()`.
    ///
    /// פונקציה זו היא ההפוכה של [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// אם אחד מהתנאים הבאים מופר, התוצאה היא התנהגות לא מוגדרת:
    ///
    /// * המצביע ההתחלתי והמצביע האחר חייבים להיות בגבול או בתים אחד מעבר לסוף אותו אובייקט שהוקצה.
    /// שים לב שב-Rust, כל משתנה (stack-allocated) נחשב לאובייקט שהוקצה נפרד.
    ///
    /// * שתי המצביעות חייבות להיות *נגזרות מ-* מצביע לאותו אובייקט.
    ///   (ראה דוגמה למטה).
    ///
    /// * המרחק בין המצביעים, בתים, חייב להיות מכפיל מדויק בגודל `T`.
    ///
    /// * המרחק בין המצביעים,**בתים**, אינו יכול לעלות על `isize`.
    ///
    /// * המרחק הנמצא בגבול אינו יכול להסתמך על "wrapping around" במרחב הכתובות.
    ///
    /// סוגי Rust לעולם אינם גדולים מ `isize::MAX` והקצאות Rust לעולם אינן עוטפות את שטח הכתובת, כך ששתי מצביעים בערך כלשהו של כל סוג Rust מסוג `T` תמיד יעמדו בשני התנאים האחרונים.
    ///
    /// הספרייה הסטנדרטית גם מבטיחה בדרך כלל שההקצאות לעולם לא יגיעו לגודל שבו קיזוז הוא עניין.
    /// לדוגמה, `Vec` ו-`Box` מבטיחים שהם לעולם לא מקצים יותר מ-`isize::MAX` בתים, כך ש-`ptr_into_vec.offset_from(vec.as_ptr())` תמיד עומד בשני התנאים האחרונים.
    ///
    /// רוב הפלטפורמות ביסודן אינן יכולות אפילו לבנות הקצאה כה גדולה.
    /// למשל, אף פלטפורמת 64 סיביות ידועה לא תוכל להגיש בקשה ל-2 <sup>63</sup> בתים, בגלל מגבלות של טבלת עמודים או פיצול שטח הכתובת.
    /// עם זאת, חלק מפלטפורמות 32 סיביות ו-16 סיביות עשויות להגיש בהצלחה בקשה ליותר מ-`isize::MAX` בתים עם דברים כמו סיומת כתובת פיזית.
    /// ככזה, זיכרון שנרכש ישירות ממקצים או מקבצי מיפוי זיכרון *עשוי* להיות גדול מכדי להתמודד עם פונקציה זו.
    /// (שים לב שגם ל-[`offset`] ול-[`add`] יש מגבלה דומה ולכן גם לא ניתן להשתמש בהקצאות כה גדולות.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// פונקציה זו panics אם `T` הוא סוג אפס ("ZST").
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *שימוש שגוי*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // הפוך את ptr2_other ל-"alias" של ptr2, אך נגזר מ-ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // מכיוון ש-ptr2_other ו-ptr2 נגזרים מצביעים לאובייקטים שונים, מחשוב הקיזוז שלהם אינו התנהגות מוגדרת, למרות שהם מצביעים על אותה כתובת!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // התנהגות לא מוגדרת
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// מחשבת את הקיזוז ממצביע (נוחות ל-`.offset(count as isize)`).
    ///
    /// `count` נמצא ביחידות T;למשל, `count` של 3 מייצג קיזוז מצביע של `3 * size_of::<T>()` בתים.
    ///
    /// # Safety
    ///
    /// אם אחד מהתנאים הבאים מופר, התוצאה היא התנהגות לא מוגדרת:
    ///
    /// * גם המצביע ההתחלתי וגם המוצא חייב להיות בגבול או בתים אחד מעבר לסוף אותו אובייקט שהוקצה.
    /// שים לב שב-Rust, כל משתנה (stack-allocated) נחשב לאובייקט שהוקצה נפרד.
    ///
    /// * הקיזוז המחושב,**בתים**, אינו יכול לעלות על `isize`.
    ///
    /// * הקיזוז הנמצא בגבולות אינו יכול להסתמך על "wrapping around" במרחב הכתובות.כלומר, הסכום המדויק האינסופי חייב להתאים ל-`usize`.
    ///
    /// המהדר והספרייה הסטנדרטית מנסים בדרך כלל להבטיח שההקצאות לעולם לא יגיעו לגודל שבו קיזוז הוא עניין.
    /// לדוגמה, `Vec` ו-`Box` מבטיחים שהם לעולם לא מקצים יותר מ-`isize::MAX` בתים, כך ש-`vec.as_ptr().add(vec.len())` תמיד בטוח.
    ///
    /// רוב הפלטפורמות ביסודן אינן יכולות אפילו לבנות הקצאה כזו.
    /// למשל, אף פלטפורמת 64 סיביות ידועה לא תוכל להגיש בקשה ל-2 <sup>63</sup> בתים, בגלל מגבלות של טבלת עמודים או פיצול שטח הכתובת.
    /// עם זאת, חלק מפלטפורמות 32 סיביות ו-16 סיביות עשויות להגיש בהצלחה בקשה ליותר מ-`isize::MAX` בתים עם דברים כמו סיומת כתובת פיזית.
    ///
    /// ככזה, זיכרון שנרכש ישירות ממקצים או מקבצי מיפוי זיכרון *עשוי* להיות גדול מכדי להתמודד עם פונקציה זו.
    ///
    /// שקול להשתמש ב-[`wrapping_add`] במקום זאת אם קשה להגביל את המגבלות הללו.
    /// היתרון היחיד בשיטה זו הוא בכך שהיא מאפשרת אופטימיזציות מהדר יותר אגרסיביות.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// מחשבת את הקיזוז מצביע (נוחות עבור '. Offset ((נחשב כ-isize).wrapping_neg())`).
    ///
    /// `count` נמצא ביחידות T;למשל, `count` של 3 מייצג קיזוז מצביע של `3 * size_of::<T>()` בתים.
    ///
    /// # Safety
    ///
    /// אם אחד מהתנאים הבאים מופר, התוצאה היא התנהגות לא מוגדרת:
    ///
    /// * גם המצביע ההתחלתי וגם המוצא חייב להיות בגבול או בתים אחד מעבר לסוף אותו אובייקט שהוקצה.
    /// שים לב שב-Rust, כל משתנה (stack-allocated) נחשב לאובייקט שהוקצה נפרד.
    ///
    /// * הקיזוז המחושב לא יכול לחרוג מ-`isize::MAX`**בתים**.
    ///
    /// * הקיזוז הנמצא בגבול אינו יכול להסתמך על "wrapping around" במרחב הכתובות.כלומר סכום הדיוק האינסופי חייב להשתלב בגודל שימוש.
    ///
    /// המהדר והספרייה הסטנדרטית מנסים בדרך כלל להבטיח שההקצאות לעולם לא יגיעו לגודל שבו קיזוז הוא עניין.
    /// לדוגמה, `Vec` ו-`Box` מבטיחים שהם לעולם לא מקצים יותר מ-`isize::MAX` בתים, כך ש-`vec.as_ptr().add(vec.len()).sub(vec.len())` תמיד בטוח.
    ///
    /// רוב הפלטפורמות ביסודן אינן יכולות אפילו לבנות הקצאה כזו.
    /// למשל, אף פלטפורמת 64 סיביות ידועה לא תוכל להגיש בקשה ל-2 <sup>63</sup> בתים, בגלל מגבלות של טבלת עמודים או פיצול שטח הכתובת.
    /// עם זאת, חלק מפלטפורמות 32 סיביות ו-16 סיביות עשויות להגיש בהצלחה בקשה ליותר מ-`isize::MAX` בתים עם דברים כמו סיומת כתובת פיזית.
    ///
    /// ככזה, זיכרון שנרכש ישירות ממקצים או מקבצי מיפוי זיכרון *עשוי* להיות גדול מכדי להתמודד עם פונקציה זו.
    ///
    /// שקול להשתמש ב-[`wrapping_sub`] במקום זאת אם קשה להגביל את המגבלות הללו.
    /// היתרון היחיד בשיטה זו הוא בכך שהיא מאפשרת אופטימיזציות מהדר יותר אגרסיביות.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// מחשבת את הקיזוז ממצביע באמצעות חשבון עטיפה.
    /// (נוחות ל-`.wrapping_offset(count as isize)`)
    ///
    /// `count` נמצא ביחידות T;למשל, `count` של 3 מייצג קיזוז מצביע של `3 * size_of::<T>()` בתים.
    ///
    /// # Safety
    ///
    /// פעולה זו עצמה תמיד בטוחה, אך השימוש במצביע שנוצר אינו.
    ///
    /// המצביע שנוצר נשאר מחובר לאותו אובייקט שהוקצה אליו `self`.
    /// יתכן ש *לא* ישמש לגישה לאובייקט שהוקצה אחר.שים לב שב-Rust, כל משתנה (stack-allocated) נחשב לאובייקט שהוקצה נפרד.
    ///
    /// במילים אחרות, `let z = x.wrapping_add((y as usize) - (x as usize))`*לא* הופך את `z` לזה של `y` גם אם אנו מניחים של-`T` יש גודל `1` ואין הצפה: `z` עדיין מחובר לאובייקט ש-`x` מחובר אליו, וההפניה אליו היא התנהגות לא מוגדרת אלא אם כן `x` ו-נקודת `y` לאותו אובייקט שהוקצה.
    ///
    /// בהשוואה ל-[`add`], שיטה זו בעצם מעכבת את הדרישה להישאר בתוך אותו אובייקט שהוקצה: [`add`] הוא התנהגות בלתי מוגדרת מיידית בעת חציית גבולות האובייקט;`wrapping_add` מייצר מצביע אך עדיין מוביל להתנהגות בלתי מוגדרת אם מצביע מופנה כאשר הוא מחוץ לתחום האובייקט אליו הוא מחובר.
    /// [`add`] ניתן לבצע אופטימיזציה טובה יותר ולכן עדיף בקוד הרגיש לביצועים.
    ///
    /// הבדיקה המתעכבת מתייחסת רק לערך המצביע שהופנה אליו, ולא לערכי הביניים המשמשים במהלך חישוב התוצאה הסופית.
    /// לדוגמא, `x.wrapping_add(o).wrapping_sub(o)` תמיד זהה ל-`x`.במילים אחרות, השארת האובייקט שהוקצה ואז הכניסה אליו מאוחר יותר מותרת.
    ///
    /// אם אתה צריך לחצות את גבולות האובייקט, הטיל את המצביע למספר שלם ועשה שם חשבון.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// // בוטל באמצעות מצביע גולמי במרווחים של שני אלמנטים
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // לולאה זו מדפיסה את "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// מחשבת את הקיזוז ממצביע באמצעות חשבון עטיפה.
    /// (נוחות עבור .wrapping_offset ((נחשב כ-isize).wrapping_neg())`)
    ///
    /// `count` נמצא ביחידות T;למשל, `count` של 3 מייצג קיזוז מצביע של `3 * size_of::<T>()` בתים.
    ///
    /// # Safety
    ///
    /// פעולה זו עצמה תמיד בטוחה, אך השימוש במצביע שנוצר אינו.
    ///
    /// המצביע שנוצר נשאר מחובר לאותו אובייקט שהוקצה אליו `self`.
    /// יתכן ש *לא* ישמש לגישה לאובייקט שהוקצה אחר.שים לב שב-Rust, כל משתנה (stack-allocated) נחשב לאובייקט שהוקצה נפרד.
    ///
    /// במילים אחרות, `let z = x.wrapping_sub((x as usize) - (y as usize))`*לא* הופך את `z` לזה של `y` גם אם אנו מניחים של-`T` יש גודל `1` ואין הצפה: `z` עדיין מחובר לאובייקט ש-`x` מחובר אליו, וההפניה אליו היא התנהגות לא מוגדרת אלא אם כן `x` ו-נקודת `y` לאותו אובייקט שהוקצה.
    ///
    /// בהשוואה ל-[`sub`], שיטה זו בעצם מעכבת את הדרישה להישאר בתוך אותו אובייקט שהוקצה: [`sub`] הוא התנהגות בלתי מוגדרת מיידית בעת חציית גבולות האובייקט;`wrapping_sub` מייצר מצביע אך עדיין מוביל להתנהגות בלתי מוגדרת אם מצביע מופנה כאשר הוא מחוץ לתחום האובייקט אליו הוא מחובר.
    /// [`sub`] ניתן לבצע אופטימיזציה טובה יותר ולכן עדיף בקוד הרגיש לביצועים.
    ///
    /// הבדיקה המתעכבת מתייחסת רק לערך המצביע שהופנה אליו, ולא לערכי הביניים המשמשים במהלך חישוב התוצאה הסופית.
    /// לדוגמא, `x.wrapping_add(o).wrapping_sub(o)` תמיד זהה ל-`x`.במילים אחרות, השארת האובייקט שהוקצה ואז הכניסה אליו מאוחר יותר מותרת.
    ///
    /// אם אתה צריך לחצות את גבולות האובייקט, הטיל את המצביע למספר שלם ועשה שם חשבון.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// // בוטל באמצעות מצביע גולמי במרווחים של שני אלמנטים (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // לולאה זו מדפיסה את "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// מגדיר את ערך המצביע ל-`ptr`.
    ///
    /// במקרה ש-`self` הוא מצביע (fat) לסוג לא ממדים, פעולה זו תשפיע רק על חלק המצביע, ואילו עבור מצביעי (thin) לסוגים בגודל זה יש השפעה זהה למשימה פשוטה.
    ///
    /// המצביע המתקבל יהיה בעל מקור של `val`, כלומר עבור מצביע שומן פעולה זו זהה מבחינה סמנטית ליצירת מצביע שומן חדש עם ערך מצביע הנתונים `val` אך המטא נתונים של `self`.
    ///
    ///
    /// # Examples
    ///
    /// פונקציה זו שימושית בעיקר לאפשר חישוב מצביעי בתים על מצביעים שעלולים להיות שמנים:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // ידפיס "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // בטיחות: במקרה של מצביע דק, פעולות אלה זהות
        // למשימה פשוטה.
        // במקרה של מצביע שומן, עם הטמעת הפריסה הנוכחית של מצביע השומן, השדה הראשון של מצביע כזה הוא תמיד מצביע הנתונים, אשר מוקצה באופן דומה.
        //
        unsafe { *thin = val };
        self
    }

    /// קורא את הערך מ-`self` מבלי להזיז אותו.
    /// זה משאיר את הזיכרון ב-`self` ללא שינוי.
    ///
    /// ראה [`ptr::read`] לגבי חששות ודוגמאות בנושא בטיחות.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור ``.
        unsafe { read(self) }
    }

    /// מבצע קריאה נדיפה של הערך מ-`self` מבלי להזיז אותו.זה משאיר את הזיכרון ב-`self` ללא שינוי.
    ///
    /// פעולות נדיפות נועדו לפעול על פי זיכרון I/O, ומובטחות שלא יועברו או יוסדרו מחדש על ידי המהדר על פני פעולות נדיפות אחרות.
    ///
    ///
    /// ראה [`ptr::read_volatile`] לגבי חששות ודוגמאות בנושא בטיחות.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// קורא את הערך מ-`self` מבלי להזיז אותו.
    /// זה משאיר את הזיכרון ב-`self` ללא שינוי.
    ///
    /// בניגוד ל-`read`, ייתכן שהמצביע אינו מיושר.
    ///
    /// ראה [`ptr::read_unaligned`] לגבי חששות ודוגמאות בנושא בטיחות.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// מעתיק `count * size_of<T>` בתים מ-`self` ל-`dest`.
    /// המקור והיעד עשויים להיות חופפים זה לזה.
    ///
    /// NOTE: זה יש את אותו *סדר* טיעון כמו [`ptr::copy`].
    ///
    /// ראה [`ptr::copy`] לגבי חששות ודוגמאות בנושא בטיחות.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// מעתיק `count * size_of<T>` בתים מ-`self` ל-`dest`.
    /// המקור והיעד עשויים *לא* לחפוף.
    ///
    /// NOTE: זה יש את אותו *סדר* טיעון כמו [`ptr::copy_nonoverlapping`].
    ///
    /// ראה [`ptr::copy_nonoverlapping`] לגבי חששות ודוגמאות בנושא בטיחות.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// מעתיק `count * size_of<T>` בתים מ-`src` ל-`self`.
    /// המקור והיעד עשויים להיות חופפים זה לזה.
    ///
    /// NOTE: יש לזה סדר הטיעון *ההפוך* מ-[`ptr::copy`].
    ///
    /// ראה [`ptr::copy`] לגבי חששות ודוגמאות בנושא בטיחות.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `copy`.
        unsafe { copy(src, self, count) }
    }

    /// מעתיק `count * size_of<T>` בתים מ-`src` ל-`self`.
    /// המקור והיעד עשויים *לא* לחפוף.
    ///
    /// NOTE: יש לזה סדר הטיעון *ההפוך* מ-[`ptr::copy_nonoverlapping`].
    ///
    /// ראה [`ptr::copy_nonoverlapping`] לגבי חששות ודוגמאות בנושא בטיחות.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// מוציא להורג את ההרס (אם בכלל) של הערך המובהק.
    ///
    /// ראה [`ptr::drop_in_place`] לגבי חששות ודוגמאות בנושא בטיחות.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// מחליף מיקום זיכרון עם הערך הנתון מבלי לקרוא או להוריד את הערך הישן.
    ///
    ///
    /// ראה [`ptr::write`] לגבי חששות ודוגמאות בנושא בטיחות.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `write`.
        unsafe { write(self, val) }
    }

    /// קורא למצב הגדרת מצביע, ומגדיר `count * size_of::<T>()` בתים של זיכרון החל מ-`self` ל-`val`.
    ///
    ///
    /// ראה [`ptr::write_bytes`] לגבי חששות ודוגמאות בנושא בטיחות.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// מבצע כתיבה נדיפה של מיקום זיכרון עם הערך הנתון מבלי לקרוא או להוריד את הערך הישן.
    ///
    /// פעולות נדיפות נועדו לפעול על פי זיכרון I/O, ומובטחות שלא יועברו או יוסדרו מחדש על ידי המהדר על פני פעולות נדיפות אחרות.
    ///
    ///
    /// ראה [`ptr::write_volatile`] לגבי חששות ודוגמאות בנושא בטיחות.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// מחליף מיקום זיכרון עם הערך הנתון מבלי לקרוא או להוריד את הערך הישן.
    ///
    ///
    /// בניגוד ל-`write`, ייתכן שהמצביע אינו מיושר.
    ///
    /// ראה [`ptr::write_unaligned`] לגבי חששות ודוגמאות בנושא בטיחות.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// מחליף את הערך ב-`self` ב-`src`, ומחזיר את הערך הישן, מבלי לרדת.
    ///
    ///
    /// ראה [`ptr::replace`] לגבי חששות ודוגמאות בנושא בטיחות.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `replace`.
        unsafe { replace(self, src) }
    }

    /// מחליף את הערכים בשני מיקומים ניתנים לשינוי מאותו סוג, מבלי לבטל את אתחול מחדש.
    /// הם עשויים לחפוף, בניגוד ל-`mem::swap` אשר במקביל הוא שווה ערך.
    ///
    /// ראה [`ptr::swap`] לגבי חששות ודוגמאות בנושא בטיחות.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `swap`.
        unsafe { swap(self, with) }
    }

    /// מחשבת את הקיזוז שיש להחיל על המצביע על מנת להתאים אותו ל-`align`.
    ///
    /// אם לא ניתן ליישר את המצביע, היישום מחזיר את `usize::MAX`.
    /// מותר ליישום להחזיר `usize::MAX` תמיד.
    /// רק ביצועי האלגוריתם שלך יכולים להיות תלויים בקיזוז שמיש כאן, ולא בנכונותו.
    ///
    /// הקיזוז מתבטא במספר רכיבי `T`, ולא בתים.ניתן להשתמש בערך המוחזר בשיטת `wrapping_add`.
    ///
    /// אין כל ערבויות שקיזוז המצביע לא יעלה על גדותיו או יעלה על ההקצאה אליה מצביע המצביע.
    ///
    /// על המתקשר לוודא שהקיזוז שהוחזר נכון בכל המונחים למעט יישור.
    ///
    /// # Panics
    ///
    /// הפונקציה panics אם `align` אינו כוח לשניים.
    ///
    /// # Examples
    ///
    /// גישה ל-`u8` הסמוכה כ-`u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // בעוד שהמצביע יכול להיות מיושר באמצעות `offset`, הוא יצביע מחוץ להקצאה
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // בטיחות: `align` נבדק להיות כוח של 2 לעיל
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// מחזיר את אורכו של פרוסה גולמית.
    ///
    /// הערך המוחזר הוא מספר **האלמנטים**, ולא מספר הבתים.
    ///
    /// פונקציה זו בטוחה, גם כאשר לא ניתן להטיל את הנתח הגולמי להתייחסות לפרוסה מכיוון שהמצביע אפס או לא מיושר.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // בטיחות: זה בטוח מכיוון של-`*const [T]` ו-`FatPtr<T>` יש אותה פריסה.
            // רק `std` יכולה להגיש אחריות זו.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// מחזיר מצביע גולמי למאגר הנתח.
    ///
    /// זה שווה ערך ליציקת `self` ל-`*mut T`, אך בטיחותי יותר.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// מחזיר מצביע גולמי לאלמנט או למקטע משנה, מבלי לבצע בדיקת גבולות.
    ///
    /// קריאה לשיטה זו עם אינדקס מחוץ לתחום או כאשר `self` אינו ניתן להפניה ניתן *[התנהגות לא מוגדרת]* גם אם לא משתמשים במצביע שהתקבל.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // בטיחות: המתקשר מבטיח שה-`self` ניתן להפניה ותאריך `index`.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// מחזירה את `None` אם המצביע אפס, או מחזיר פרוסה משותפת לערך העטוף ב-`Some`.
    /// בניגוד ל-[`as_ref`], זה לא דורש לאתחל את הערך.
    ///
    /// עבור המקביל המשתנה ראה [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// כאשר אתה קורא לשיטה זו, עליך לוודא ש *או* המצביע הוא NULL *או* כל הדברים הבאים נכונים:
    ///
    /// * המצביע חייב להיות [valid] כדי לקרוא עבור `ptr.len() * mem::size_of::<T>()` בתים רבים, והוא חייב להיות מיושר כהלכה.פירוש הדבר במיוחד:
    ///
    ///     * כל טווח הזיכרון של פרוסה זו חייב להיות כלול בתוך אובייקט שהוקצה יחיד!
    ///       פרוסות לעולם אינן יכולות להשתרע על פני מספר עצמים שהוקצו.
    ///
    ///     * על המצביע להיות מיושר גם עבור פרוסות באורך אפס.
    ///     אחת הסיבות לכך היא שאופטימיזציה של פריסת enum עשויה להסתמך על כך שההפניות (כולל פרוסות בכל אורך) יהיו מיושרות ולא בטלות כדי להבדיל אותן מנתונים אחרים.
    ///
    ///     אתה יכול להשיג מצביע שניתן להשתמש בו כ-`data` עבור פרוסות באורך אפס באמצעות [`NonNull::dangling()`].
    ///
    /// * הגודל הכולל `ptr.len() * mem::size_of::<T>()` של הנתח לא יכול להיות גדול מ-`isize::MAX`.
    ///   עיין בתיעוד הבטיחות של [`pointer::offset`].
    ///
    /// * עליך לאכוף את כללי הכינוי של Rust, מכיוון שאורך החיים המוחזר `'a` נבחר באופן שרירותי ואינו משקף בהכרח את חיי הנתונים בפועל.
    ///   בפרט, לכל אורך החיים הזה, הזיכרון שהמצביע מצביע עליו אינו חייב להיות מוטציה (למעט בתוך `UnsafeCell`).
    ///
    /// זה חל גם אם התוצאה של שיטה זו אינה בשימוש!
    ///
    /// ראה גם [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// מחזירה את `None` אם המצביע הוא null, או מחזיר פרוסה ייחודית לערך העטוף ב-`Some`.
    /// בניגוד ל-[`as_mut`], זה לא דורש לאתחל את הערך.
    ///
    /// עבור המקביל המשותף ראה [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// כאשר אתה קורא לשיטה זו, עליך לוודא ש *או* המצביע הוא NULL *או* כל הדברים הבאים נכונים:
    ///
    /// * המצביע חייב להיות [valid] לקריאה וכתיבה עבור `ptr.len() * mem::size_of::<T>()` בתים רבים, והוא חייב להיות מיושר כהלכה.פירוש הדבר במיוחד:
    ///
    ///     * כל טווח הזיכרון של פרוסה זו חייב להיות כלול בתוך אובייקט שהוקצה יחיד!
    ///       פרוסות לעולם אינן יכולות להשתרע על פני מספר עצמים שהוקצו.
    ///
    ///     * על המצביע להיות מיושר גם עבור פרוסות באורך אפס.
    ///     אחת הסיבות לכך היא שאופטימיזציה של פריסת enum עשויה להסתמך על כך שההפניות (כולל פרוסות בכל אורך) יהיו מיושרות ולא בטלות כדי להבדיל אותן מנתונים אחרים.
    ///
    ///     אתה יכול להשיג מצביע שניתן להשתמש בו כ-`data` עבור פרוסות באורך אפס באמצעות [`NonNull::dangling()`].
    ///
    /// * הגודל הכולל `ptr.len() * mem::size_of::<T>()` של הנתח לא יכול להיות גדול מ-`isize::MAX`.
    ///   עיין בתיעוד הבטיחות של [`pointer::offset`].
    ///
    /// * עליך לאכוף את כללי הכינוי של Rust, מכיוון שאורך החיים המוחזר `'a` נבחר באופן שרירותי ואינו משקף בהכרח את חיי הנתונים בפועל.
    ///   בפרט, במשך תקופת החיים הזו, אל הזיכרון שהמצביע מצביע עליו אסור לגשת אליו (לקרוא או לכתוב) דרך שום מצביע אחר.
    ///
    /// זה חל גם אם התוצאה של שיטה זו אינה בשימוש!
    ///
    /// ראה גם [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// שוויון למצביעים
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}