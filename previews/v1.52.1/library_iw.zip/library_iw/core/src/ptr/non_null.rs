use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` אבל לא אפס ומשתנה.
///
/// לרוב זה הדבר הנכון לשימוש בבניית מבני נתונים באמצעות מצביעים גולמיים, אך בסופו של דבר הוא מסוכן יותר לשימוש בגלל המאפיינים הנוספים שלו.אם אינך בטוח אם עליך להשתמש ב-`NonNull<T>`, פשוט השתמש ב-`*mut T`!
///
/// בניגוד ל-`*mut T`, המצביע חייב להיות תמיד ללא אפס, גם אם המצביע לעולם אינו מופנה.זאת כדי שאנומות ישתמשו בערך האסור הזה כמפלה-ל-`Option<NonNull<T>>` יש אותו גודל כמו ל-`* mut T`.
/// עם זאת, המצביע עשוי עדיין להשתלשל אם הוא אינו מופנה.
///
/// שלא כמו `*mut T`, `NonNull<T>` נבחר להיות משתנה לעומת `T`.זה מאפשר להשתמש ב-`NonNull<T>` בבניית סוגים משתנים, אך מציג את הסיכון לאי-שקט אם משתמשים בו בסוג שאינו אמור להיות משתנה.
/// (הבחירה ההפוכה נעשתה עבור `*mut T` למרות שמבחינה טכנית אי הצלחות יכולה להיגרם רק על ידי קריאה לפונקציות לא בטוחות).
///
/// המשתנות נכונה עבור רוב ההפשטות הבטוחות, כגון `Box`, `Rc`, `Arc`, `Vec` ו-`LinkedList`.זה המקרה מכיוון שהם מספקים ממשק API ציבורי העוקב אחר כללי ה-XOR המשותפים הרגילים המשותפים של Rust.
///
/// אם הסוג שלך לא יכול להיות משתנה בבטחה, עליך לוודא שהוא מכיל שדה נוסף כלשהו כדי לספק סטייה.לעיתים קרובות שדה זה יהיה מסוג [`PhantomData`] כמו `PhantomData<Cell<T>>` או `PhantomData<&'a mut T>`.
///
/// שימו לב כי ל-`NonNull<T>` יש מופע `From` עבור `&T`.עם זאת, זה לא משנה את העובדה שהמוטציה באמצעות התייחסות משותפת (מצביע הנגזר מ-a) אינה התנהגות מוגדרת אלא אם כן המוטציה מתרחשת בתוך [`UnsafeCell<T>`].כנ"ל לגבי יצירת התייחסות ניתנת לשינוי מתוך התייחסות משותפת.
///
/// בעת שימוש במופע `From` זה ללא `UnsafeCell<T>`, באחריותך לוודא שלא יתקשר לעולם `as_mut`, ו-`as_ptr` לעולם לא משמש למוטציה.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` המצביעים אינם `Send` מכיוון שהנתונים אליהם הם מפנים עשויים להיות מקובלים.
// הערה, יישום זה מיותר, אך אמור לספק הודעות שגיאה טובות יותר.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` המצביעים אינם `Sync` מכיוון שהנתונים אליהם הם מפנים עשויים להיות מקובלים.
// הערה, יישום זה מיותר, אך אמור לספק הודעות שגיאה טובות יותר.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// יוצר `NonNull` חדש המשתלשל אך מיושר היטב.
    ///
    /// זה שימושי לאתחול סוגים המוקצים בעצלתיים, כמו `Vec::new`.
    ///
    /// שים לב שערך המצביע עשוי לייצג מצביע תקף ל-`T`, מה שאומר שאסור להשתמש בזה כערך זקיף "not yet initialized".
    /// סוגים המוקצים בעצלתיים חייבים לעקוב אחר אתחול באמצעים אחרים.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // בטיחות: mem::align_of() מחזיר שימוש שאינו אפס ויוצק לאחר מכן
        // ל * mut T.
        // לכן, `ptr` אינו בטל ומכובדים התנאים להתקשרות ל-new_unchecked().
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// מחזירה הפניות משותפות לערך.בניגוד ל-[`as_ref`], זה לא דורש לאתחל את הערך.
    ///
    /// עבור המקביל המשתנה ראה [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// כאשר אתה קורא לשיטה זו, עליך לוודא שכל הדברים הבאים נכונים:
    ///
    /// * על המצביע להיות מיושר כהלכה.
    ///
    /// * זה חייב להיות "dereferencable" במובן שהוגדר ב-[the module documentation].
    ///
    /// * עליך לאכוף את כללי הכינוי של Rust, מכיוון שאורך החיים המוחזר `'a` נבחר באופן שרירותי ואינו משקף בהכרח את חיי הנתונים בפועל.
    ///
    ///   בפרט, לכל אורך החיים הזה, הזיכרון שהמצביע מצביע עליו אינו חייב להיות מוטציה (למעט בתוך `UnsafeCell`).
    ///
    /// זה חל גם אם התוצאה של שיטה זו אינה בשימוש!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // בטיחות: על המתקשר להבטיח כי `self` עומד בכל
        // דרישות להפניה.
        unsafe { &*self.cast().as_ptr() }
    }

    /// מחזירה הפניות ייחודיות לערך.בניגוד ל-[`as_mut`], זה לא דורש לאתחל את הערך.
    ///
    /// עבור המקביל המשותף ראה [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// כאשר אתה קורא לשיטה זו, עליך לוודא שכל הדברים הבאים נכונים:
    ///
    /// * על המצביע להיות מיושר כהלכה.
    ///
    /// * זה חייב להיות "dereferencable" במובן שהוגדר ב-[the module documentation].
    ///
    /// * עליך לאכוף את כללי הכינוי של Rust, מכיוון שאורך החיים המוחזר `'a` נבחר באופן שרירותי ואינו משקף בהכרח את חיי הנתונים בפועל.
    ///
    ///   בפרט, במשך תקופת החיים הזו, אל הזיכרון שהמצביע מצביע עליו אסור לגשת אליו (לקרוא או לכתוב) דרך שום מצביע אחר.
    ///
    /// זה חל גם אם התוצאה של שיטה זו אינה בשימוש!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // בטיחות: על המתקשר להבטיח כי `self` עומד בכל
        // דרישות להפניה.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// יוצר `NonNull` חדש.
    ///
    /// # Safety
    ///
    /// `ptr` חייב להיות לא אפס.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // בטיחות: על המתקשר להבטיח ש-`ptr` אינו אפס.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// יוצר `NonNull` חדש אם `ptr` אינו ריק.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // בטיחות: המצביע כבר מסומן ואינו ריק
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// מבצע אותה פונקציונליות כמו [`std::ptr::from_raw_parts`], אלא שמוחזר מצביע `NonNull`, בניגוד למצביע גולמי `*const`.
    ///
    ///
    /// לפרטים נוספים, עיין בתיעוד של [`std::ptr::from_raw_parts`].
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // בטיחות: התוצאה של `ptr::from::raw_parts_mut` אינה בטוחה מכיוון ש-`data_address` היא.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// פירוק מצביע (אולי רחב) לרכיבי כתובת ומטא נתונים.
    ///
    /// ניתן לשחזר את המצביע מאוחר יותר באמצעות [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// רוכש את מצביע ה-`*mut` הבסיסי.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// מחזירה התייחסות משותפת לערך.אם ייתכן שהערך אינו מאוחד, יש להשתמש במקום זאת ב-[`as_uninit_ref`].
    ///
    /// עבור המקביל המשתנה ראה [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// כאשר אתה קורא לשיטה זו, עליך לוודא שכל הדברים הבאים נכונים:
    ///
    /// * על המצביע להיות מיושר כהלכה.
    ///
    /// * זה חייב להיות "dereferencable" במובן שהוגדר ב-[the module documentation].
    ///
    /// * על המצביע להצביע על מופע מאותחל של `T`.
    ///
    /// * עליך לאכוף את כללי הכינוי של Rust, מכיוון שאורך החיים המוחזר `'a` נבחר באופן שרירותי ואינו משקף בהכרח את חיי הנתונים בפועל.
    ///
    ///   בפרט, לכל אורך החיים הזה, הזיכרון שהמצביע מצביע עליו אינו חייב להיות מוטציה (למעט בתוך `UnsafeCell`).
    ///
    /// זה חל גם אם התוצאה של שיטה זו אינה בשימוש!
    /// (החלק שעוסק באתחול עדיין לא הוחלט במלואו, אך עד שהוא, הגישה הבטוחה היחידה היא להבטיח שהם אכן מאותחלים).
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // בטיחות: על המתקשר להבטיח כי `self` עומד בכל
        // דרישות להפניה.
        unsafe { &*self.as_ptr() }
    }

    /// מחזירה התייחסות ייחודית לערך.אם ייתכן שהערך אינו מאוחד, יש להשתמש במקום זאת ב-[`as_uninit_mut`].
    ///
    /// עבור המקביל המשותף ראה [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// כאשר אתה קורא לשיטה זו, עליך לוודא שכל הדברים הבאים נכונים:
    ///
    /// * על המצביע להיות מיושר כהלכה.
    ///
    /// * זה חייב להיות "dereferencable" במובן שהוגדר ב-[the module documentation].
    ///
    /// * על המצביע להצביע על מופע מאותחל של `T`.
    ///
    /// * עליך לאכוף את כללי הכינוי של Rust, מכיוון שאורך החיים המוחזר `'a` נבחר באופן שרירותי ואינו משקף בהכרח את חיי הנתונים בפועל.
    ///
    ///   בפרט, במשך תקופת החיים הזו, אל הזיכרון שהמצביע מצביע עליו אסור לגשת אליו (לקרוא או לכתוב) דרך שום מצביע אחר.
    ///
    /// זה חל גם אם התוצאה של שיטה זו אינה בשימוש!
    /// (החלק שעוסק באתחול עדיין לא הוחלט במלואו, אך עד שהוא, הגישה הבטוחה היחידה היא להבטיח שהם אכן מאותחלים).
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // בטיחות: על המתקשר להבטיח כי `self` עומד בכל
        // דרישות להתייחסות משתנה.
        unsafe { &mut *self.as_ptr() }
    }

    /// משליך למצביע מסוג אחר.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // בטיחות: `self` הוא מצביע `NonNull` שאינו בהכרח ריק
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// יוצר פרוסת גלם שאינה אפסית מצביע דק ואורך.
    ///
    /// הארגומנט `len` הוא מספר **האלמנטים**, ולא מספר הבתים.
    ///
    /// פונקציה זו בטוחה, אך התייחסות לערך ההחזרה אינה בטוחה.
    /// עיין בתיעוד של [`slice::from_raw_parts`] לקבלת דרישות בטיחות לפרוסות.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // צור מצביע פרוסה כאשר מתחילים עם מצביע לאלמנט הראשון
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (שים לב כי דוגמה זו מדגימה באופן מלאכותי שימוש בשיטה זו, אך `תן לחתוך= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // בטיחות: `data` הוא מצביע `NonNull` שהוא בהכרח לא אפס
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// מחזירה את אורך הנתח הגולמי שאינו אפס.
    ///
    /// הערך המוחזר הוא מספר **האלמנטים**, ולא מספר הבתים.
    ///
    /// פונקציה זו בטוחה, גם כאשר לא ניתן להתייחס לנתח הגולמי שאינו null לפרוסה מכיוון שלמצביע אין כתובת חוקית.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// מחזיר מצביע שאינו אפס למאגר הפרוסה.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // בטיחות: אנו יודעים ש-`self` אינו אפס.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// מחזיר מצביע גולמי למאגר הנתח.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// מחזירה התייחסות משותפת לפרוסת ערכים שאולי לא יוזמנו.בניגוד ל-[`as_ref`], זה לא דורש לאתחל את הערך.
    ///
    /// עבור המקביל המשתנה ראה [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// כאשר אתה קורא לשיטה זו, עליך לוודא שכל הדברים הבאים נכונים:
    ///
    /// * המצביע חייב להיות [valid] כדי לקרוא עבור `ptr.len() * mem::size_of::<T>()` בתים רבים, והוא חייב להיות מיושר כהלכה.פירוש הדבר במיוחד:
    ///
    ///     * כל טווח הזיכרון של פרוסה זו חייב להיות כלול בתוך אובייקט שהוקצה יחיד!
    ///       פרוסות לעולם אינן יכולות להשתרע על פני מספר עצמים שהוקצו.
    ///
    ///     * על המצביע להיות מיושר גם עבור פרוסות באורך אפס.
    ///     אחת הסיבות לכך היא שאופטימיזציה של פריסת enum עשויה להסתמך על כך שההפניות (כולל פרוסות בכל אורך) יהיו מיושרות ולא בטלות כדי להבדיל אותן מנתונים אחרים.
    ///
    ///     אתה יכול להשיג מצביע שניתן להשתמש בו כ-`data` עבור פרוסות באורך אפס באמצעות [`NonNull::dangling()`].
    ///
    /// * הגודל הכולל `ptr.len() * mem::size_of::<T>()` של הנתח לא יכול להיות גדול מ-`isize::MAX`.
    ///   עיין בתיעוד הבטיחות של [`pointer::offset`].
    ///
    /// * עליך לאכוף את כללי הכינוי של Rust, מכיוון שאורך החיים המוחזר `'a` נבחר באופן שרירותי ואינו משקף בהכרח את חיי הנתונים בפועל.
    ///   בפרט, לכל אורך החיים הזה, הזיכרון שהמצביע מצביע עליו אינו חייב להיות מוטציה (למעט בתוך `UnsafeCell`).
    ///
    /// זה חל גם אם התוצאה של שיטה זו אינה בשימוש!
    ///
    /// ראה גם [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// מחזירה התייחסות ייחודית לפרוסת ערכים שאולי לא יונו.בניגוד ל-[`as_mut`], זה לא דורש לאתחל את הערך.
    ///
    /// עבור המקביל המשותף ראה [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// כאשר אתה קורא לשיטה זו, עליך לוודא שכל הדברים הבאים נכונים:
    ///
    /// * המצביע חייב להיות [valid] לקריאה וכתיבה עבור `ptr.len() * mem::size_of::<T>()` בתים רבים, והוא חייב להיות מיושר כהלכה.פירוש הדבר במיוחד:
    ///
    ///     * כל טווח הזיכרון של פרוסה זו חייב להיות כלול בתוך אובייקט שהוקצה יחיד!
    ///       פרוסות לעולם אינן יכולות להשתרע על פני מספר עצמים שהוקצו.
    ///
    ///     * על המצביע להיות מיושר גם עבור פרוסות באורך אפס.
    ///     אחת הסיבות לכך היא שאופטימיזציה של פריסת enum עשויה להסתמך על כך שההפניות (כולל פרוסות בכל אורך) יהיו מיושרות ולא בטלות כדי להבדיל אותן מנתונים אחרים.
    ///
    ///     אתה יכול להשיג מצביע שניתן להשתמש בו כ-`data` עבור פרוסות באורך אפס באמצעות [`NonNull::dangling()`].
    ///
    /// * הגודל הכולל `ptr.len() * mem::size_of::<T>()` של הנתח לא יכול להיות גדול מ-`isize::MAX`.
    ///   עיין בתיעוד הבטיחות של [`pointer::offset`].
    ///
    /// * עליך לאכוף את כללי הכינוי של Rust, מכיוון שאורך החיים המוחזר `'a` נבחר באופן שרירותי ואינו משקף בהכרח את חיי הנתונים בפועל.
    ///   בפרט, במשך תקופת החיים הזו, אל הזיכרון שהמצביע מצביע עליו אסור לגשת אליו (לקרוא או לכתוב) דרך שום מצביע אחר.
    ///
    /// זה חל גם אם התוצאה של שיטה זו אינה בשימוש!
    ///
    /// ראה גם [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // זה בטוח שכן `memory` תקף לקריאה וכתיבה עבור `memory.len()` בתים רבים.
    /// // שים לב שהשיחה ל-`memory.as_mut()` אינה מותרת כאן מכיוון שהתוכן עשוי להיות לא מאופשר.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// מחזיר מצביע גולמי לאלמנט או למקטע משנה, מבלי לבצע בדיקת גבולות.
    ///
    /// קריאה לשיטה זו עם אינדקס מחוץ לתחום או כאשר `self` אינו ניתן להפניה ניתן *[התנהגות לא מוגדרת]* גם אם לא משתמשים במצביע שהתקבל.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // בטיחות: המתקשר מבטיח שה-`self` ניתן להפניה ותאריך `index`.
        // כתוצאה מכך, המצביע שנוצר אינו יכול להיות NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // בטיחות: מצביע ייחודי אינו יכול להיות ריק, ולכן התנאים עבור
        // new_unchecked() מכובדים.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // בטיחות: אסמכתא ניתנת לשינוי אינה יכולה להיות בטלה.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // בטיחות: הפניה לא יכולה להיות בטלה, ולכן התנאים ל
        // new_unchecked() מכובדים.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}