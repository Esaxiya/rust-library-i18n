use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// עטיפה סביב `*mut T` גולמי שאינו אפס המציין כי המחזיק בעטיפה זו הוא הבעלים של המפנה.
/// שימושי לבניית מופשטים כמו `Box<T>`, `Vec<T>`, `String` ו-`HashMap<K, V>`.
///
/// שלא כמו `*mut T`, `Unique<T>` מתנהג "as if" זה היה מופע של `T`.
/// הוא מיישם את `Send`/`Sync` אם `T` הוא `Send`/`Sync`.
/// זה גם מרמז על סוג ההתחייבות החיובית החזקה למופע של `T`:
/// אין לשנות את המפנה של המצביע ללא נתיב ייחודי לבעלותו ייחודי.
///
/// אם אינך בטוח אם נכון להשתמש ב-`Unique` למטרותיך, שקול להשתמש ב-`NonNull`, בעל סמנטיקה חלשה יותר.
///
///
/// בניגוד ל-`*mut T`, המצביע תמיד חייב להיות ללא אפס, גם אם המצביע לעולם אינו מופנה.
/// זאת כדי שאנומות ישתמשו בערך האסור הזה כמפלה-ל-`Option<Unique<T>>` יש אותו גודל כמו ל-`Unique<T>`.
/// עם זאת, המצביע עשוי עדיין להשתלשל אם הוא אינו מופנה.
///
/// שלא כמו `*mut T`, `Unique<T>` משתנה לעומת `T`.
/// זה תמיד צריך להיות נכון לכל סוג העומד בדרישות הכינוי של Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: לסמן זה אין השלכות על השונות, אך הוא הכרחי
    // כדי ש dropck יבין שיש לנו לוגיקה `T`.
    //
    // לפרטים ראו:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` המצביעים הם `Send` אם `T` הוא `Send` מכיוון שהנתונים שהם מתייחסים אליהם אינם משוערים.
/// שים לב כי מערכת הכינוי הזו אינה נאכפת על ידי מערכת הסוגים;ההפשטה באמצעות ה-`Unique` חייבת לאכוף אותה.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` המצביעים הם `Sync` אם `T` הוא `Sync` מכיוון שהנתונים שהם מתייחסים אליהם אינם משוערים.
/// שים לב כי מערכת הכינוי הזו אינה נאכפת על ידי מערכת הסוגים;ההפשטה באמצעות ה-`Unique` חייבת לאכוף אותה.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// יוצר `Unique` חדש המשתלשל אך מיושר היטב.
    ///
    /// זה שימושי לאתחול סוגים המוקצים בעצלתיים, כמו `Vec::new`.
    ///
    /// שים לב שערך המצביע עשוי לייצג מצביע תקף ל-`T`, מה שאומר שאסור להשתמש בזה כערך זקיף "not yet initialized".
    /// סוגים המוקצים בעצלתיים חייבים לעקוב אחר אתחול באמצעים אחרים.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // בטיחות: mem::align_of() מחזיר מצביע תקף ולא ריק.ה
        // תנאים להתקשר ל-new_unchecked() מכובדים לפיכך.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// יוצר `Unique` חדש.
    ///
    /// # Safety
    ///
    /// `ptr` חייב להיות לא אפס.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // בטיחות: על המתקשר להבטיח ש-`ptr` אינו אפס.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// יוצר `Unique` חדש אם `ptr` אינו ריק.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // בטיחות: המצביע כבר נבדק ואינו אפס.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// רוכש את מצביע ה-`*mut` הבסיסי.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// מפנה את התוכן.
    ///
    /// החיים המתקבלים קשורים לעצמי ולכן זה מתנהג "as if" זה היה למעשה מקרה של T שמושאל.
    /// אם יש צורך בחיים ארוכים יותר של (unbound), השתמש ב-`&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // בטיחות: על המתקשר להבטיח כי `self` עומד בכל
        // דרישות להפניה.
        unsafe { &*self.as_ptr() }
    }

    /// ניתן להפנות את התוכן באופן הדדי.
    ///
    /// החיים המתקבלים קשורים לעצמי ולכן זה מתנהג "as if" זה היה למעשה מקרה של T שמושאל.
    /// אם יש צורך בחיים ארוכים יותר של (unbound), השתמש ב-`&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // בטיחות: על המתקשר להבטיח כי `self` עומד בכל
        // דרישות להתייחסות משתנה.
        unsafe { &mut *self.as_ptr() }
    }

    /// משליך למצביע מסוג אחר.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // בטיחות: Unique::new_unchecked() יוצר ייחודיות וצרכים חדשים
        // המצביע הנתון לא להיות אפס.
        // מכיוון שאנו מעבירים את העצמי כמצביע, זה לא יכול להיות בטל.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // בטיחות: אסמכתא ניתנת לשינוי אינה יכולה להיות בטלה
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}