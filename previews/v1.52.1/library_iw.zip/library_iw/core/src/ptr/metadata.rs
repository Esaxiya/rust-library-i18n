#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// מספק את סוג המטא-נתונים של המצביע מכל סוג מצוין.
///
/// # מטא נתונים של מצביע
///
/// ניתן לחשוב על סוגי מצביעים גולמיים וסוגי ייחוס ב-Rust כמיוצרים משני חלקים:
/// מצביע נתונים המכיל את כתובת הזיכרון של הערך, וכמה מטא נתונים.
///
/// עבור סוגים בגודל סטטי (המיישמים את `Sized` traits) כמו גם עבור סוגי `extern`, מצביעים על כך שהם "דקים": מטא נתונים הם בגודל אפס וסוגם `()`.
///
///
/// מצביעים ל-[dynamically-sized types][dst] אמורים להיות "רחבים" או "שמנים", ויש להם מטא נתונים שאינם בגודל אפס:
///
/// * עבור סטרוקטות שהשדה האחרון שלהן הוא DST, מטא-נתונים הם המטא-נתונים עבור השדה האחרון
/// * עבור סוג `str`, מטא נתונים הם האורך בתים כ-`usize`
/// * עבור סוגי פרוסות כמו `[T]`, מטא נתונים הם האורך בפריטים כ-`usize`
/// * עבור אובייקטים trait כמו `dyn SomeTrait`, המטא נתונים הם [`DynMetadata<Self>`][DynMetadata] (למשל `DynMetadata<dyn SomeTrait>`)
///
/// ב-future, שפת Rust עשויה לזכות בסוגים חדשים של סוגים בעלי מטא-נתונים מצביעים שונים.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # ה-`Pointee` trait
///
/// הנקודה של trait זה הסוג המשויך ל-`Metadata`, שהוא `()` או `usize` או `DynMetadata<_>` כמתואר לעיל.
/// זה מיושם אוטומטית לכל סוג.
/// ניתן להניח שהוא מיושם בהקשר גנרי, גם ללא גבול מקביל.
///
/// # Usage
///
/// ניתן לפרק מצביעים גולמיים לכתובת הנתונים ולרכיבי המטא-נתונים בשיטת [`to_raw_parts`] שלהם.
///
/// לחלופין, ניתן לחלץ מטא-נתונים לבד באמצעות הפונקציה [`metadata`].
/// ניתן להעביר הפניה ל-[`metadata`] ולכפות עליה באופן מרומז.
///
/// ניתן להרכיב מצביע (possibly-wide) מהכתובת שלו וממטא הנתונים שלו עם [`from_raw_parts`] או [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// הסוג למטא-נתונים במצביעים והפניות ל-`Self`.
    #[lang = "metadata_type"]
    // NOTE: שמור על trait bounds ב-`static_assert_expected_bounds_for_metadata`
    //
    // ב-`library/core/src/ptr/metadata.rs` מסונכרן עם אלה כאן:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// מצביעים לסוגים המיישמים כינוי trait זה הם "רזים".
///
/// זה כולל סוגי "גודל" סטטי וסוגי `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: לא לייצב זאת לפני שכינויי trait יציבים בשפה?
pub trait Thin = Pointee<Metadata = ()>;

/// חלץ את רכיב המטא-נתונים של מצביע.
///
/// ערכים מסוג `*mut T`, `&T` או `&mut T` ניתנים להעברה ישירות לפונקציה זו מכיוון שהם מכריחים באופן מרומז ל-`* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // בטיחות: גישה לערך מאיחוד `PtrRepr` בטוחה שכן * const T
    // ו-PtrComponents<T>בעלי אותן פריסות זיכרון.
    // רק std יכול להגיש אחריות זו.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// יוצר מצביע גולמי (possibly-wide) מכתובת נתונים ומטא נתונים.
///
/// פונקציה זו בטוחה אך המצביע שהוחזר אינו בהכרח בטוח להפרעה.
/// לפרוסות, עיין בתיעוד של [`slice::from_raw_parts`] לקבלת דרישות בטיחות.
/// עבור אובייקטים trait, המטא נתונים חייבים להגיע ממצביע לאותו סוג בסיסי.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // בטיחות: גישה לערך מאיחוד `PtrRepr` בטוחה שכן * const T
    // ו-PtrComponents<T>בעלי אותן פריסות זיכרון.
    // רק std יכול להגיש אחריות זו.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// מבצע פונקציונליות זהה לזו של [`from_raw_parts`], אלא שמוחזר מצביע `*mut` גולמי, בניגוד למצביע `* const` גולמי.
///
///
/// לפרטים נוספים, עיין בתיעוד של [`from_raw_parts`].
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // בטיחות: גישה לערך מאיחוד `PtrRepr` בטוחה שכן * const T
    // ו-PtrComponents<T>בעלי אותן פריסות זיכרון.
    // רק std יכול להגיש אחריות זו.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// יש צורך ביישום ידני בכדי למנוע `T: Copy` מאוגד.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// יש צורך ביישום ידני כדי למנוע `T: Clone` מאוגד.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// המטא נתונים עבור סוג אובייקט `Dyn = dyn SomeTrait` trait.
///
/// זהו מצביע לטבלת vt (טבלת שיחות וירטואלית) המייצגת את כל המידע הדרוש כדי לתפעל את סוג הבטון המאוחסן בתוך אובייקט trait.
/// הטבלה vt במיוחד שהיא מכילה:
///
/// * גודל סוג
/// * יישור סוג
/// * מצביע ל-implant `drop_in_place` של הסוג (יכול להיות אי-אופציה לנתונים פשוטים ישנים)
/// * מצביעים על כל השיטות ליישום סוג ה-trait
///
/// שים לב ששלושת הראשונים הם מיוחדים מכיוון שהם נחוצים להקצאה, ירידה, והקצאה של כל אובייקט trait.
///
/// אפשר למנות את המבנה הזה בפרמטר מסוג שאינו אובייקט `dyn` trait (למשל `DynMetadata<u64>`) אך לא להשיג ערך משמעותי של אותו מבנה.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// הקידומת הנפוצה של כל הטבלאות.אחריו מצביעי פונקציות לשיטות trait.
///
/// פרט יישום פרטי של `DynMetadata::size_of` וכו '.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// מחזיר את הגודל של הסוג המשויך לטבלה זו.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// מחזירה את היישור של הסוג המשויך לטבלה זו.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// מחזיר את הגודל והיישור יחד כ-`Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // בטיחות: המהדר פלט טבלה זו עבור סוג Rust בטון אשר
        // ידוע שיש לו פריסה חוקית.אותו הרציונל כמו ב-`Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// מכשירים ידניים הדרושים כדי להימנע מגבולות `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}