//! נהל ידנית את הזיכרון באמצעות מצביעים גולמיים.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! פונקציות רבות במודול זה לוקחות מצביעים גולמיים כטיעונים וקוראות מהן או כותבות אליהן.כדי שיהיה בטוח, המצביעים האלה חייבים להיות *תקפים*.
//! אם המצביע תקף תלוי בפעולה שהיא משמשת לה (לקרוא או לכתוב), ולהיקף הזיכרון אליו מגיעים (כלומר, כמה בתים הם read/written).
//! מרבית הפונקציות משתמשות ב-`*mut T` וב-`* const T` כדי לגשת לערך יחיד בלבד, ובמקרה זה התיעוד משמיט את הגודל ומניח שהוא מרמז על בתים `size_of::<T>()`.
//!
//! הכללים המדויקים לתוקף עדיין לא נקבעים.הערבויות הניתנות בשלב זה הן מינימליות מאוד:
//!
//! * מצביע [null]*לעולם* אינו תקף, אפילו לא לגישות של [size zero][zst].
//! * כדי שהמצביע יהיה תקף, זה הכרחי, אך לא תמיד מספיק, שהמצביע יהיה *ניתן להפניה*: טווח הזיכרון בגודל הנתון המתחיל במצביע חייב להיות בגדר אובייקט שהוקצה יחיד.
//!
//! שים לב שב-Rust, כל משתנה (stack-allocated) נחשב לאובייקט שהוקצה נפרד.
//! * גם עבור פעולות של [size zero][zst], המצביע לא יכול להצביע על זיכרון מוקצה, כלומר, מיקום הדליקה הופך את המצביעים לפסולים אפילו עבור פעולות בגודל אפס.
//! עם זאת, השלכת כל מספר שלם שאינו אפס *מילולי* למצביע תקפה לגישות בגודל אפס, גם אם במקרה קיים זיכרון כלשהו בכתובת זו ומתמקם.
//! זה מתאים לכתיבת הקצאה משלך: הקצאת אובייקטים בגודל אפס אינה קשה במיוחד.
//! הדרך הקנונית להשיג מצביע שתקף לגישה בגודל אפס היא [`NonNull::dangling`].
//! * כל הגישות המבוצעות על ידי פונקציות במודול זה אינן *אטומיות* במובן ה-[atomic operations] המשמש לסינכרון בין האשכולות.
//! פירוש הדבר שזו התנהגות לא מוגדרת לבצע שתי גישות במקביל לאותו מיקום משרשורים שונים אלא אם כן שתי הגישות נקראות רק מהזיכרון.
//! שים לב שהדבר כולל במפורש [`read_volatile`] ו-[`write_volatile`]: לא ניתן להשתמש בגישות נדיפות לסינכרון בין חוטים.
//! * התוצאה של השלכת התייחסות למצביע תקפה כל עוד האובייקט הבסיסי חי ולא משתמשים בהפניה (רק מצביעים גולמיים) כדי לגשת לאותו זיכרון.
//!
//! אקסיומות אלה, יחד עם שימוש זהיר ב-[`offset`] לצורך חשבון מצביע, מספיקים בכדי ליישם נכון דברים שימושיים רבים בקוד לא בטוח.
//! בסופו של דבר יינתנו ערבויות חזקות יותר, ככל שייקבעו כללי [aliasing].
//! למידע נוסף, עיין ב-[book] וכן בסעיף בהתייחסות המוקדש ל-[undefined behavior][ub].
//!
//! ## Alignment
//!
//! מצביעי גלם תקפים, כפי שהוגדרו לעיל, אינם בהכרח מיושרים כראוי (כאשר יישור "proper" מוגדר על ידי סוג המצביע, כלומר, `*const T` חייב להיות מיושר ל-`mem::align_of::<T>()`).
//! עם זאת, רוב הפונקציות מחייבות התאמה נכונה של הטיעונים שלהן, ויצוין במפורש בדרישה זו בתיעוד שלהן.
//! יוצאים מן הכלל הבולטים לכך הם [`read_unaligned`] ו-[`write_unaligned`].
//!
//! כאשר פונקציה דורשת יישור נכון, היא עושה זאת גם אם הגישה היא בגודל 0, כלומר, גם אם לא נגע בפועל בזיכרון.שקול להשתמש ב-[`NonNull::dangling`] במקרים כאלה.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// מוציא להורג את ההרס (אם בכלל) של הערך המובהק.
///
/// זה שווה ערך מבחינה סמנטית להתקשרות ל-[`ptr::read`] ולמחיקת התוצאה, אך יש לו את היתרונות הבאים:
///
/// * נדרש * להשתמש ב-`drop_in_place` כדי להפיל סוגים לא גדולים כמו אובייקטים trait, מכיוון שלא ניתן לקרוא אותם על הערימה ולהפיל אותם כרגיל.
///
/// * זה יותר ידידותי למיטוב לעשות זאת על פני [`ptr::read`] כששחרר זיכרון שהוקצה ידנית (למשל, ביישומים של `Box`/`Rc`/`Vec`), מכיוון שהמהדר לא צריך להוכיח שזה נשמע כדי להעלות את העותק.
///
///
/// * ניתן להשתמש בו כדי להפיל נתוני [pinned] כאשר `T` אינו `repr(packed)` (אסור להזיז נתונים מוצמדים לפני שהם נושרים).
///
/// לא ניתן להוריד ערכים שלא מיושרים במקום, יש להעתיק אותם למיקום מיושר תחילה באמצעות [`ptr::read_unaligned`].עבור דרכים ארוזות, מהלך זה נעשה באופן אוטומטי על ידי המהדר.
/// פירוש הדבר ששדות התיקים הארוזים אינם נושרים במקום.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// ההתנהגות אינה מוגדרת אם מופר אחד מהתנאים הבאים:
///
/// * `to_drop` חייב להיות [valid] עבור קריאה וכתיבה.
///
/// * `to_drop` חייב להיות מיושר כהלכה.
///
/// * הערך ש-`to_drop` מצביע עליו חייב להיות תקף לירידה, מה שאולי אומר שהוא חייב לשמור על זרמים נוספים, זה תלוי בסוג.
///
/// בנוסף, אם `T` אינו [`Copy`], שימוש בערך הצביע לאחר קריאה ל-`drop_in_place` עלול לגרום להתנהגות לא מוגדרת.שים לב ש-`*to_drop = foo` נחשב כשימוש מכיוון שהוא יגרום להורדת הערך שוב.
/// [`write()`] ניתן להשתמש בהם כדי להחליף נתונים מבלי לגרום להם להישמט.
///
/// שים לב שגם אם ל-`T` יש גודל `0`, המצביע חייב להיות שאינו NULL ומיושר כראוי.
///
/// [valid]: self#safety
///
/// # Examples
///
/// הסר ידנית את הפריט האחרון מ-vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // קבל מצביע גולמי לאלמנט האחרון ב-`v`.
///     let ptr = &mut v[1] as *mut _;
///     // קצר את `v` כדי למנוע את ירידת הפריט האחרון.
///     // אנו עושים זאת תחילה, כדי למנוע בעיות אם ה-`drop_in_place` מתחת ל-panics.
///     v.set_len(1);
///     // ללא שיחת `drop_in_place`, הפריט האחרון לעולם לא יושמט, והזיכרון שהוא מנהל היה דולף.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // ודא שהפריט האחרון הושמט.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// שים לב שהמהדר מבצע עותק זה באופן אוטומטי כאשר הוא מפיל סטרוקטורות ארוזות, כלומר, בדרך כלל אינך צריך לדאוג לבעיות כאלה אלא אם תתקשר ידנית ל-`drop_in_place`.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // קוד כאן לא משנה, זה מוחלף על ידי דבק הטיפה האמיתי על ידי המהדר.
    //

    // בטיחות: ראה הערה לעיל
    unsafe { drop_in_place(to_drop) }
}

/// יוצר מצביע גולמי אפס.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// יוצר מצביע גולמי ללא שינוי.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// יש צורך ביישום ידני כדי למנוע `T: Clone` מאוגד.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// יש צורך ביישום ידני בכדי למנוע `T: Copy` מאוגד.
impl<T> Copy for FatPtr<T> {}

/// יוצר פרוסה גולמית מצביע ואורך.
///
/// הארגומנט `len` הוא מספר **האלמנטים**, ולא מספר הבתים.
///
/// פונקציה זו בטוחה, אך למעשה שימוש בערך ההחזרה אינו בטוח.
/// עיין בתיעוד של [`slice::from_raw_parts`] לקבלת דרישות בטיחות לפרוסות.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // צור מצביע פרוסה כאשר מתחילים עם מצביע לאלמנט הראשון
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // בטיחות: גישה לערך מהאיחוד `Repr` בטוחה שכן * const [T]
        //
        // ו-FatPtr יש אותן פריסות זיכרון.רק std יכול להגיש אחריות זו.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// מבצעת את אותה פונקציונליות כמו [`slice_from_raw_parts`], אלא שפרוסה ניתנת לשינוי גולמי מוחזרת, לעומת פרוסה בלתי ניתנת לשינוי גלם.
///
///
/// לפרטים נוספים, עיין בתיעוד של [`slice_from_raw_parts`].
///
/// פונקציה זו בטוחה, אך למעשה שימוש בערך ההחזרה אינו בטוח.
/// עיין בתיעוד של [`slice::from_raw_parts_mut`] לקבלת דרישות בטיחות לפרוסות.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // הקצה ערך באינדקס בפרוסה
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // בטיחות: גישה לערך מהאיחוד `Repr` בטוחה שכן * mut [T]
        // ו-FatPtr יש אותן פריסות זיכרון
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// מחליף את הערכים בשני מיקומים ניתנים לשינוי מאותו סוג, מבלי לבטל את אתחול מחדש.
///
/// אך בשני החריגים הבאים, פונקציה זו שווה ערך סמנטי ל-[`mem::swap`]:
///
///
/// * הוא פועל על מצביעים גולמיים במקום הפניות.
/// כאשר הפניות זמינות, יש להעדיף את [`mem::swap`].
///
/// * שני הערכים המופנים עשויים להיות חופפים זה לזה.
/// אם הערכים אכן חופפים, אז ישמש את אזור הזיכרון החופף מ-`x`.
/// זה מודגם בדוגמה השנייה להלן.
///
/// # Safety
///
/// ההתנהגות אינה מוגדרת אם מופר אחד מהתנאים הבאים:
///
/// * שניהם `x` ו-`y` חייבים להיות [valid] עבור קריאה וכתיבה.
///
/// * שניהם `x` ו-`y` חייבים להיות מיושרים כהלכה.
///
/// שים לב שגם אם ל-`T` יש גודל `0`, על המצביעים להיות לא NULL ולהתאים אותם כראוי.
///
/// [valid]: self#safety
///
/// # Examples
///
/// החלפת שני אזורים שאינם חופפים:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // זה `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // זה `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// החלפת שני אזורים חופפים:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // זה `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // זה `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // המדדים `1..3` של הנתח חופפים בין `x` ל-`y`.
///     // תוצאות סבירות יהיו עבורם `[2, 3]`, כך שמדדי `0..3` יהיו `[1, 2, 3]` (תואמים `y` לפני `swap`);או שהם יהיו `[0, 1]` כך שהמדדים `1..4` יהיו `[0, 1, 2]` (תואם `x` לפני ה-`swap`).
/////
///     // יישום זה מוגדר בכדי לעשות את הבחירה האחרונה.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // תנו לעצמנו קצת שטח שריטות לעבודה.
    // אנחנו לא צריכים לדאוג לטיפות: `MaybeUninit` לא עושה כלום כשמפילים אותה.
    let mut tmp = MaybeUninit::<T>::uninit();

    // בצע את החלפת הבטיחות: על המתקשר להבטיח ש-`x` ו-`y` תקפים לכתיבה ומייושרים כראוי.
    // `tmp` לא יכול להיות חופף את `x` או `y` מכיוון ש-`tmp` הוקצה רק בערימה כאובייקט שהוקצה נפרד.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` ו-`y` עשויים לחפוף
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// מחליף בתים `count * size_of::<T>()` בין שני אזורי הזיכרון שמתחילים ב-`x` וב-`y`.
/// על שני האזורים *לא* לחפוף.
///
/// # Safety
///
/// ההתנהגות אינה מוגדרת אם מופר אחד מהתנאים הבאים:
///
/// * שניהם `x` ו-`y` חייבים להיות [valid] עבור שניהם קוראים וכותבים של 'ספירה *
///   מידה של: :<T>() `בתים.
///
/// * שניהם `x` ו-`y` חייבים להיות מיושרים כהלכה.
///
/// * אזור הזיכרון החל מ-`x` בגודל של 'ספירה *
///   מידה של: :<T>() `בתים חייבים *לא* לחפוף לאזור הזיכרון שמתחיל ב-`y` באותו גודל.
///
/// שים לב שגם אם הגודל שהועתק ביעילות (`count * size_of: :<T>()`) הוא `0`, המצביעים חייבים להיות שאינם NULL ומיושרים כהלכה.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // בטיחות: על המתקשר להבטיח כי `x` ו-`y` הם
    // תקף לכתיבה ומיושר כהלכה.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // לסוגים קטנים יותר ממיטוב החסימה שלמטה, פשוט החלף ישירות כדי להימנע מפסימי קודגן.
    //
    if mem::size_of::<T>() < 32 {
        // בטיחות: על המתקשר להבטיח כי `x` ו-`y` תקפים
        // לכותבים, מיושרים כראוי ולא חופפים.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // הגישה כאן היא להשתמש ב-simd כדי להחליף x&y ביעילות.
    // בדיקה מגלה כי החלפת 32 בייט או 64 בתים בכל פעם יעילה ביותר עבור מעבדי אינטל Haswell E.
    // LLVM מסוגל יותר לבצע אופטימיזציה אם אנו נותנים ל-struct #[repr(simd)], גם אם איננו משתמשים ישירות ב-struct זה.
    //
    //
    // FIXME repr(simd) שבור על emscripten וחידוש
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // לולאה דרך x&y, להעתיק אותם `Block` בכל פעם האופטימיזציה צריכה לפתוח את הלולאה במלואה עבור רוב הסוגים NB.
    // אנחנו לא יכולים להשתמש ב-loop כי ה-`range` impl קורא ל-`mem::swap` באופן רקורסיבי
    //
    let mut i = 0;
    while i + block_size <= len {
        // צור זיכרון לא מאוזן כשטחי שריטה הצהרת `t` כאן מונעת יישור הערימה כאשר לולאה זו אינה בשימוש
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // בטיחות: כ-`i < len`, וכמתקשר חייב להבטיח ש-`x` ו-`y` תקפים
        // עבור בתים `len`, `x + i` ו-`y + i` חייבים להיות כתובות חוקיות, הממלאות את חוזה הבטיחות עבור `add`.
        //
        // כמו כן, על המתקשר להבטיח כי `x` ו-`y` תקפים לכתיבה, מיושרת כראוי ואינה חופפת, אשר ממלאת את חוזה הבטיחות עבור `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // החלף גוש בתים של x&y, תוך שימוש ב-t כחוצץ זמני. יש לבצע אופטימיזציה לפעולות SIMD יעילות היכן שיש
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // החלף בתים שנותרו
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // בטיחות: ראה הערת בטיחות קודמת.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// מעביר את `src` אל ה-`dst` המחודד ומחזיר את ערך ה-`dst` הקודם.
///
/// אף ערך לא נשמט.
///
/// פונקציה זו שווה ערך סמנטית ל-[`mem::replace`], אלא שהיא פועלת על מצביעים גולמיים במקום הפניות.
/// כאשר הפניות זמינות, יש להעדיף את [`mem::replace`].
///
/// # Safety
///
/// ההתנהגות אינה מוגדרת אם מופר אחד מהתנאים הבאים:
///
/// * `dst` חייב להיות [valid] עבור קריאה וכתיבה.
///
/// * `dst` חייב להיות מיושר כהלכה.
///
/// * `dst` חייב להצביע על ערך מאותחל כראוי מסוג `T`.
///
/// שים לב שגם אם ל-`T` יש גודל `0`, המצביע חייב להיות שאינו NULL ומיושר כראוי.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` תהיה לאותו השפעה מבלי לדרוש את החסימה הלא בטוחה.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // בטיחות: על המתקשר להבטיח ש-`dst` תקף להיות
    // יצוק להפניה משתנה (תקף לכתיבה, מיושר, מאותחל) ולא יכול לחפוף את `src` מכיוון ש-`dst` חייב להצביע על אובייקט שהוקצה מובחן.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // לא יכול לחפוף
    }
    src
}

/// קורא את הערך מ-`src` מבלי להזיז אותו.זה משאיר את הזיכרון ב-`src` ללא שינוי.
///
/// # Safety
///
/// ההתנהגות אינה מוגדרת אם מופר אחד מהתנאים הבאים:
///
/// * `src` חייב להיות [valid] לקריאות.
///
/// * `src` חייב להיות מיושר כהלכה.השתמש ב-[`read_unaligned`] אם זה לא המקרה.
///
/// * `src` חייב להצביע על ערך מאותחל כראוי מסוג `T`.
///
/// שים לב שגם אם ל-`T` יש גודל `0`, המצביע חייב להיות שאינו NULL ומיושר כראוי.
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// יישום ידני של [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // צור עותק קצת חכם של הערך ב-`a` ב-`tmp`.
///         let tmp = ptr::read(a);
///
///         // יציאה בנקודה זו (או על ידי חזרה מפורשת או על ידי קריאה לפונקציה ש-panics) תביא לירידה בערך ב-`tmp` בעוד אותו ערך עדיין מופנה על ידי `a`.
///         // זה יכול לעורר התנהגות לא מוגדרת אם `T` אינו `Copy`.
/////
/////
///
///         // צור עותק קצת חכם של הערך ב-`b` ב-`a`.
///         // זה בטוח מכיוון שלא ניתן לכנות הפניות משתנות.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // כאמור לעיל, יציאה מכאן עלולה לעורר התנהגות לא מוגדרת מכיוון שהערך מופנה על ידי `a` ו-`b`.
/////
///
///         // העבר את `tmp` ל-`b`.
///         ptr::write(b, tmp);
///
///         // `tmp` הועבר (`write` לוקח בעלות על הטיעון השני שלה), כך ששום דבר לא נושר באופן מרומז כאן.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## בעלות על הערך המוחזר
///
/// `read` יוצר עותק קצת חכם של `T`, ללא קשר לשאלה האם `T` הוא [`Copy`].
/// אם `T` אינו [`Copy`], שימוש הן בערך המוחזר והן בערך ב-`*src` עלול להפר את בטיחות הזיכרון.
/// שים לב שהקצאה ל-`*src` נחשבת לשימוש מכיוון שהיא תנסה להוריד את הערך ב-`* src`.
///
/// [`write()`] ניתן להשתמש בהם כדי להחליף נתונים מבלי לגרום להם להישמט.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` מצביע כעת על אותו זיכרון בסיסי כמו `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // הקצאה ל-`s2` גורמת לביטול הערך המקורי שלה.
///     // מעבר לנקודה זו, אין להשתמש עוד ב-`s` מכיוון שהזיכרון הבסיסי שוחרר.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // הקצאה ל-`s` תגרום להורדת הערך הישן שוב, וכתוצאה מכך התנהגות לא מוגדרת.
/////
///     // s= String::from("bar");//שגיאה
///
///     // `ptr::write` ניתן להשתמש בה כדי להחליף ערך מבלי להפיל אותו.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // בטיחות: על המתקשר להבטיח כי `src` תקף לקריאות.
    // `src` לא יכול לחפוף את `tmp` מכיוון ש-`tmp` הוקצה רק על הערימה כאובייקט שהוקצה נפרד.
    //
    //
    // כמו כן, מכיוון שזה עתה כתבנו ערך תקף ל-`tmp`, מובטח שהוא יאותחל כהלכה.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// קורא את הערך מ-`src` מבלי להזיז אותו.זה משאיר את הזיכרון ב-`src` ללא שינוי.
///
/// שלא כמו [`read`], `read_unaligned` עובד עם מצביעים שלא מיושרים.
///
/// # Safety
///
/// ההתנהגות אינה מוגדרת אם מופר אחד מהתנאים הבאים:
///
/// * `src` חייב להיות [valid] לקריאות.
///
/// * `src` חייב להצביע על ערך מאותחל כראוי מסוג `T`.
///
/// כמו [`read`], `read_unaligned` יוצר עותק bitwise של `T`, ללא קשר לשאלה האם `T` הוא [`Copy`].
/// אם `T` אינו [`Copy`], השימוש בערך המוחזר והן בערך ב-`*src` יכול [violate memory safety][read-ownership].
///
/// שים לב שגם אם ל-`T` יש גודל `0`, המצביע חייב להיות שאינו NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## על סטרוקטורות `packed`
///
/// כרגע אי אפשר ליצור מצביעים גולמיים לשדות לא מיושרים של מבנה ארוז.
///
/// ניסיון ליצור מצביע גולמי לשדה מבנה `unaligned` עם ביטוי כמו `&packed.unaligned as *const FieldType` יוצר התייחסות ביניים שלא מיושרת לפני שממירים את זה למצביע גולמי.
///
/// שההתייחסות הזו היא זמנית וההרכב המיידי אינו חשוב מכיוון שהמהדר תמיד מצפה שההפניות ייושרו כהלכה.
/// כתוצאה מכך, השימוש ב-`&packed.unaligned as *const FieldType` גורם לתנהגות מיידית* לא מוגדרת * בתוכנית שלך.
///
/// דוגמה למה לא לעשות ואיך זה קשור ל-`read_unaligned` היא:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // כאן אנו מנסים לקחת את הכתובת של מספר שלם של 32 סיביות שאינו מיושר.
///     let unaligned =
///         // נוצרת כאן הפניה זמנית שלא מיושרה, מה שמביא להתנהגות לא מוגדרת ללא קשר אם נעשה שימוש בהפניה או לא.
/////
///         &packed.unaligned
///         // יציקה למצביע גולמי לא עוזרת;הטעות כבר קרתה.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// גישה עם זאת לשדות לא מיושרים ישירות עם למשל `packed.unaligned` היא בטוחה.
///
///
///
///
///
///
// FIXME: עדכן מסמכים על בסיס תוצאות RFC #2582 וחברים.
/// # Examples
///
/// קרא ערך שימוש ממאגר בתים:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // בטיחות: על המתקשר להבטיח כי `src` תקף לקריאות.
    // `src` לא יכול לחפוף את `tmp` מכיוון ש-`tmp` הוקצה רק על הערימה כאובייקט שהוקצה נפרד.
    //
    //
    // כמו כן, מכיוון שזה עתה כתבנו ערך תקף ל-`tmp`, מובטח שהוא יאותחל כהלכה.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// מחליף מיקום זיכרון עם הערך הנתון מבלי לקרוא או להוריד את הערך הישן.
///
/// `write` אינו מוריד את תוכן ה-`dst`.
/// זה בטוח, אך זה עלול לדלוף הקצאות או משאבים, ולכן צריך להיזהר שלא להחליף אובייקט שיש להפיל.
///
///
/// בנוסף, הוא אינו מוריד את `src`.מבחינה סמנטית, `src` מועבר למיקום שה-`dst` מצביע עליו.
///
/// זה מתאים לאתחול זיכרון לא מאוזן, או להחלפת זיכרון שקודם לכן היה [`read`].
///
/// # Safety
///
/// ההתנהגות אינה מוגדרת אם מופר אחד מהתנאים הבאים:
///
/// * `dst` חייב להיות [valid] לכתיבה.
///
/// * `dst` חייב להיות מיושר כהלכה.השתמש ב-[`write_unaligned`] אם זה לא המקרה.
///
/// שים לב שגם אם ל-`T` יש גודל `0`, המצביע חייב להיות שאינו NULL ומיושר כראוי.
///
/// [valid]: self#safety
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// יישום ידני של [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // צור עותק קצת חכם של הערך ב-`a` ב-`tmp`.
///         let tmp = ptr::read(a);
///
///         // יציאה בנקודה זו (או על ידי חזרה מפורשת או על ידי קריאה לפונקציה ש-panics) תביא לירידה בערך ב-`tmp` בעוד אותו ערך עדיין מופנה על ידי `a`.
///         // זה יכול לעורר התנהגות לא מוגדרת אם `T` אינו `Copy`.
/////
/////
///
///         // צור עותק קצת חכם של הערך ב-`b` ב-`a`.
///         // זה בטוח מכיוון שלא ניתן לכנות הפניות משתנות.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // כאמור לעיל, יציאה מכאן עלולה לעורר התנהגות לא מוגדרת מכיוון שהערך מופנה על ידי `a` ו-`b`.
/////
///
///         // העבר את `tmp` ל-`b`.
///         ptr::write(b, tmp);
///
///         // `tmp` הועבר (`write` לוקח בעלות על הטיעון השני שלה), כך ששום דבר לא נושר באופן מרומז כאן.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // אנו מתקשרים ישירות לאינטרינס כדי להימנע משיחות פונקציה בקוד שנוצר מכיוון ש-`intrinsics::copy_nonoverlapping` הוא פונקציית עטיפה.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // בטיחות: על המתקשר להבטיח ש-`dst` תקף לכתיבה.
    // `dst` לא יכול לחפוף את `src` מכיוון שלמתקשר יש גישה משתנה ל-`dst` בעוד ש-`src` נמצא בבעלות פונקציה זו.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// מחליף מיקום זיכרון עם הערך הנתון מבלי לקרוא או להוריד את הערך הישן.
///
/// בניגוד ל-[`write()`], ייתכן שהמצביע אינו מיושר.
///
/// `write_unaligned` אינו מוריד את תוכן ה-`dst`.זה בטוח, אך זה עלול לדלוף הקצאות או משאבים, ולכן צריך להיזהר שלא להחליף אובייקט שיש להפיל.
///
/// בנוסף, הוא אינו מוריד את `src`.מבחינה סמנטית, `src` מועבר למיקום שה-`dst` מצביע עליו.
///
/// זה מתאים לאתחול זיכרון לא מאוזן, או להחלפת זיכרון שקראו בעבר עם [`read_unaligned`].
///
/// # Safety
///
/// ההתנהגות אינה מוגדרת אם מופר אחד מהתנאים הבאים:
///
/// * `dst` חייב להיות [valid] לכתיבה.
///
/// שים לב שגם אם ל-`T` יש גודל `0`, המצביע חייב להיות שאינו NULL.
///
/// [valid]: self#safety
///
/// ## על סטרוקטורות `packed`
///
/// כרגע אי אפשר ליצור מצביעים גולמיים לשדות לא מיושרים של מבנה ארוז.
///
/// ניסיון ליצור מצביע גולמי לשדה מבנה `unaligned` עם ביטוי כמו `&packed.unaligned as *const FieldType` יוצר התייחסות ביניים שלא מיושרת לפני שממירים את זה למצביע גולמי.
///
/// שההתייחסות הזו היא זמנית וההרכב המיידי אינו חשוב מכיוון שהמהדר תמיד מצפה שההפניות ייושרו כהלכה.
/// כתוצאה מכך, השימוש ב-`&packed.unaligned as *const FieldType` גורם לתנהגות מיידית* לא מוגדרת * בתוכנית שלך.
///
/// דוגמה למה לא לעשות ואיך זה קשור ל-`write_unaligned` היא:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // כאן אנו מנסים לקחת את הכתובת של מספר שלם של 32 סיביות שאינו מיושר.
///     let unaligned =
///         // נוצרת כאן הפניה זמנית שלא מיושרה, מה שמביא להתנהגות לא מוגדרת ללא קשר אם נעשה שימוש בהפניה או לא.
/////
///         &mut packed.unaligned
///         // יציקה למצביע גולמי לא עוזרת;הטעות כבר קרתה.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// גישה עם זאת לשדות לא מיושרים ישירות עם למשל `packed.unaligned` היא בטוחה.
///
///
///
///
///
///
///
///
///
// FIXME: עדכן מסמכים על בסיס תוצאות RFC #2582 וחברים.
/// # Examples
///
/// כתוב ערך שימוש למאגר בתים:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // בטיחות: על המתקשר להבטיח ש-`dst` תקף לכתיבה.
    // `dst` לא יכול לחפוף את `src` מכיוון שלמתקשר יש גישה משתנה ל-`dst` בעוד ש-`src` נמצא בבעלות פונקציה זו.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // אנו קוראים ישירות אל הפנימי כדי להימנע משיחות פונקציה בקוד שנוצר.
        intrinsics::forget(src);
    }
}

/// מבצע קריאה נדיפה של הערך מ-`src` מבלי להזיז אותו.זה משאיר את הזיכרון ב-`src` ללא שינוי.
///
/// פעולות נדיפות נועדו לפעול על פי זיכרון I/O, ומובטחות שלא יועברו או יוסדרו מחדש על ידי המהדר על פני פעולות נדיפות אחרות.
///
/// # Notes
///
/// ל-Rust אין כיום מודל זיכרון מוגדר בצורה קפדנית, ולכן הסמנטיקה המדויקת של משמעות "volatile" כאן עשויה להשתנות לאורך זמן.
/// עם זאת, הסמנטיקה כמעט תמיד תסתיים די דומה ל-[C11's definition of volatile][c11].
///
/// המהדר לא אמור לשנות את הסדר היחסי או את מספר פעולות הזיכרון ההפכפכות.
/// עם זאת, פעולות זיכרון נדיפות בסוגים בגודל אפס (למשל, אם סוג בגודל אפס מועבר ל-`read_volatile`) אינן יכולות להתעלם.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// ההתנהגות אינה מוגדרת אם מופר אחד מהתנאים הבאים:
///
/// * `src` חייב להיות [valid] לקריאות.
///
/// * `src` חייב להיות מיושר כהלכה.
///
/// * `src` חייב להצביע על ערך מאותחל כראוי מסוג `T`.
///
/// כמו [`read`], `read_volatile` יוצר עותק bitwise של `T`, ללא קשר לשאלה האם `T` הוא [`Copy`].
/// אם `T` אינו [`Copy`], השימוש בערך המוחזר והן בערך ב-`*src` יכול [violate memory safety][read-ownership].
/// עם זאת, אחסון של סוגים שאינם ["העתק"] בזיכרון נדיף אינו בטוח כמעט.
///
/// שים לב שגם אם ל-`T` יש גודל `0`, המצביע חייב להיות שאינו NULL ומיושר כראוי.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// בדיוק כמו ב-C, אם פעולה היא תנודתיות אין לה שום השפעה בשאלות הקשורות לגישה בו זמנית ממספר שרשורים.גישות נדיפות מתנהגות בדיוק כמו גישות שאינן אטומיות בעניין זה.
///
/// בפרט, מרוץ בין `read_volatile` וכל פעולת כתיבה לאותו מיקום הוא התנהגות לא מוגדרת.
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // לא נבהל כדי להקטין את ההשפעה על קודגן.
        abort();
    }
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// מבצע כתיבה נדיפה של מיקום זיכרון עם הערך הנתון מבלי לקרוא או להוריד את הערך הישן.
///
/// פעולות נדיפות נועדו לפעול על פי זיכרון I/O, ומובטחות שלא יועברו או יוסדרו מחדש על ידי המהדר על פני פעולות נדיפות אחרות.
///
/// `write_volatile` אינו מוריד את תוכן ה-`dst`.זה בטוח, אך זה עלול לדלוף הקצאות או משאבים, ולכן צריך להיזהר שלא להחליף אובייקט שיש להפיל.
///
/// בנוסף, הוא אינו מוריד את `src`.מבחינה סמנטית, `src` מועבר למיקום שה-`dst` מצביע עליו.
///
/// # Notes
///
/// ל-Rust אין כיום מודל זיכרון מוגדר בצורה קפדנית, ולכן הסמנטיקה המדויקת של משמעות "volatile" כאן עשויה להשתנות לאורך זמן.
/// עם זאת, הסמנטיקה כמעט תמיד תסתיים די דומה ל-[C11's definition of volatile][c11].
///
/// המהדר לא אמור לשנות את הסדר היחסי או את מספר פעולות הזיכרון ההפכפכות.
/// עם זאת, פעולות זיכרון נדיפות בסוגים בגודל אפס (למשל, אם סוג בגודל אפס מועבר ל-`write_volatile`) אינן יכולות להתעלם.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// ההתנהגות אינה מוגדרת אם מופר אחד מהתנאים הבאים:
///
/// * `dst` חייב להיות [valid] לכתיבה.
///
/// * `dst` חייב להיות מיושר כהלכה.
///
/// שים לב שגם אם ל-`T` יש גודל `0`, המצביע חייב להיות שאינו NULL ומיושר כראוי.
///
/// [valid]: self#safety
///
/// בדיוק כמו ב-C, אם פעולה היא תנודתיות אין לה שום השפעה בשאלות הקשורות לגישה בו זמנית ממספר שרשורים.גישות נדיפות מתנהגות בדיוק כמו גישות שאינן אטומיות בעניין זה.
///
/// בפרט, מרוץ בין `write_volatile` וכל פעולה אחרת (קריאה או כתיבה) באותו מיקום היא התנהגות לא מוגדרת.
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // לא נבהל כדי להקטין את ההשפעה על קודגן.
        abort();
    }
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// יישר את המצביע `p`.
///
/// חשב קיזוז (במונחים של אלמנטים של צעד `stride`) שיש להחיל על מצביע `p` כך שמצביע `p` יתיישר ל-`a`.
///
/// Note: יישום זה הותאם בקפידה לא ל-panic.זה UB בשביל זה ל-panic.
/// השינוי האמיתי היחיד שניתן לעשות כאן הוא שינוי `INV_TABLE_MOD_16` וקבועים נלווים.
///
/// אם אי פעם נחליט לאפשר להתקשר למצב הפנימי עם `a` שאינו כוח של שניים, זה יהיה כנראה זהיר יותר פשוט לשנות ליישום נאיבי ולא לנסות להתאים את זה כדי להתאים לשינוי זה.
///
///
/// כל שאלה עבור אל@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): שימוש ישיר בפנימיות אלה משפר את קודגן באופן משמעותי ברמת אופטי <=
    // 1, כאשר גרסאות השיטה של פעולות אלה אינן מונחות.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// חישוב הפוך מודולרי כפול של `x` מודולו `m`.
    ///
    /// יישום זה מותאם ל-`align_offset` ויש לו תנאים מוקדמים הבאים:
    ///
    /// * `m` הוא כוח של שניים;
    /// * `x < m`; (אם `x ≥ m`, העבירו במקום `x % m`)
    ///
    /// יישום פונקציה זו לא יהיה panic.אֵיִ פַּעַם.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// טבלה הפוכה מודולרית מכפלת מודולו 2⁴=16.
        ///
        /// שים לב, כי טבלה זו אינה מכילה ערכים שבהם ההופכי אינו קיים (כלומר עבור `0⁻¹ mod 16`, `2⁻¹ mod 16` וכו ').
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// מודולו אליו מיועד ה-`INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // בטיחות: `m` נדרש להיות כוח של שני, ומכאן שאינו אפס.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // אנו חוזרים על "up" באמצעות הנוסחה הבאה:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // עד 2²ⁿ ≥ מ '.אז נוכל להפחית ל-`m` הרצוי על ידי לקיחת התוצאה `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // שים לב, שאנחנו משתמשים כאן בכוונות בפעולות עטיפה-הנוסחה המקורית משתמשת למשל בחיסור `mod n`.
                // זה בסדר גמור לעשות אותם `mod usize::MAX` במקום זאת, כי בכל מקרה אנחנו לוקחים את התוצאה `mod n` בסוף.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // בטיחות: `a` הוא כוח של שניים, ולכן אינו אפס.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` ניתן לחשב את המקרה בצורה פשוטה יותר באמצעות `-p (mod a)`, אך פעולה זו מעכבת את יכולתו של LLVM לבחור הוראות כמו `lea`.במקום זאת אנו מחשבים
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // המפיץ פעולות סביב נושאת העומס, אך פסימיזציה של `and` מספיק כדי ש-LLVM יוכל לנצל את האופטימיזציות השונות שהוא יודע עליהן.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // כבר מיושר.יש!
        return 0;
    } else if stride == 0 {
        // אם המצביע אינו מיושר והאלמנט בגודל אפס, אז אף כמות של אלמנטים לא תתאים לעולם את המצביע.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // בטיחות: a הוא כוח של שניים ומכאן שאינו אפס.צעד==0 התיק מטופל לעיל.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // בטיחות: ל-gcdpow יש גבול עליון שהוא לכל היותר מספר הביטים בגודל השימוש.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // בטיחות: gcd תמיד גדול או שווה ל-1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // branch זה פותר את משוואת ההתאמה הליניארית הבאה:
        //
        // ` p + so = 0 mod a `
        //
        // `p` הנה ערך המצביע, `s`, צעד של `T`, `o` קיזוז ב-T ו-`a`, היישור המבוקש.
        //
        // כאשר `g = gcd(a, s)`, והתנאי שלעיל טוען כי `p` ניתן לחלוקה גם ב-`g`, נוכל לציין `a' = a/g`, `s' = s/g`, `p' = p/g`, ואז זה הופך לשווה ערך ל:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // המונח הראשון הוא "the relative alignment of `p` to `a`" (מחולק על ידי `g`), המונח השני הוא "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (שוב מחולק על ידי `g`).
        //
        // חלוקה לפי `g` נחוצה כדי להפוך את ההופכי בצורה טובה אם `a` ו-`s` אינם ראשוניים משותפים.
        //
        // יתר על כן, התוצאה המיוצרת על ידי פתרון זה אינה "minimal", ולכן יש צורך לקחת את התוצאה `o mod lcm(s, a)`.אנו יכולים להחליף את `lcm(s, a)` ב-`a'` בלבד.
        //
        //
        //
        //
        //

        // בטיחות: ל-`gcdpow` יש גבול עליון שאינו גדול ממספר ה 0-סיביות הנגררים ב-`a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // בטיחות: `a2` אינו אפס.העברת `a` על ידי `gcdpow` אינה יכולה להזיז אף אחד מהביטים שנקבעו
        // ב-`a` (שמתוכו יש לו בדיוק אחד).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // בטיחות: ל-`gcdpow` יש גבול עליון שאינו גדול ממספר ה 0-סיביות הנגררים ב-`a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // בטיחות: ל-`gcdpow` יש גבול עליון שאינו גדול ממספר ה 0 סיביות הנגררים פנימה
        // `a`.
        // יתר על כן, החיסור לא יכול לעלות על גדותיו, מכיוון ש-`a2 = a >> gcdpow` תמיד יהיה גדול מ-`(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // בטיחות: `a2` הוא כוח של שניים, כפי שהוכח לעיל.`s2` הוא פחות מ-`a2`
        // מכיוון ש-`(s % a) >> gcdpow` הוא פחות מ-`a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // לא ניתן ליישר כלל.
    usize::MAX
}

/// משווה מצביעים גולמיים לשוויון.
///
/// זה זהה לשימוש במפעיל `==`, אך פחות כללי:
/// הוויכוחים צריכים להיות מצביעי גלם `*const T`, לא שום דבר שמיישם את `PartialEq`.
///
/// ניתן להשתמש בזה כדי להשוות הפניות של `&T` (אשר מכריחות את `*const T` באופן מרומז) לפי הכתובת שלהם ולא להשוות בין הערכים אליהם הם מצביעים (וזה מה שהיישום `PartialEq for &T` עושה).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// פרוסות מושוות גם לפי אורכן (מצביעי שומן):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits מושווים גם על ידי יישומם:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // למצביעים יש כתובות שוות.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // לאובייקטים יש כתובות שוות, אך ל-`Trait` יש יישומים שונים.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // המרת הפניה ל-`*const u8` משווה לפי כתובת.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// האש מצביע גולמי.
///
/// זה יכול לשמש לחשיש הפניה ל-`&T` (אשר מכריח את `*const T` באופן מרומז) לפי הכתובת שלה ולא לפי הערך שהוא מצביע עליו (וזה מה שהיישום `Hash for &T` עושה).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// מכשירים למצביעים על פונקציות
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: יציקת הביניים כגודל שימוש נדרשת עבור AVR
                // כך שמרחב הכתובת של מצביע פונקציית המקור יישמר במצביע הפונקציה הסופי.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: יציקת הביניים כגודל שימוש נדרשת עבור AVR
                // כך שמרחב הכתובת של מצביע פונקציית המקור יישמר במצביע הפונקציה הסופי.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // אין פונקציות שונות עם 0 פרמטרים
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// צור מצביע גולמי `const` למקום, מבלי ליצור התייחסות ביניים.
///
/// יצירת הפניה באמצעות `&`/`&mut` מותרת רק אם המצביע מיושר כראוי ומצביע על נתונים מאותחל.
/// במקרים בהם דרישות אלה אינן מתקיימות, יש להשתמש במקום זאת במצבי גלם.
/// עם זאת, `&expr as *const _` יוצר הפניה לפני השלכתו למצביע גולמי, וההפניה הזו כפופה לאותם כללים כמו כל הפניות האחרות.
///
/// מאקרו זה יכול ליצור מצביע גולמי *מבלי* ליצור תחילה הפניה.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` תיצור התייחסות לא מיושרת, וכך תהיה התנהגות לא מוגדרת!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// צור מצביע גולמי `mut` למקום, מבלי ליצור התייחסות ביניים.
///
/// יצירת הפניה באמצעות `&`/`&mut` מותרת רק אם המצביע מיושר כראוי ומצביע על נתונים מאותחל.
/// במקרים בהם דרישות אלה אינן מתקיימות, יש להשתמש במקום זאת במצבי גלם.
/// עם זאת, `&mut expr as *mut _` יוצר הפניה לפני השלכתו למצביע גולמי, וההפניה הזו כפופה לאותם כללים כמו כל הפניות האחרות.
///
/// מאקרו זה יכול ליצור מצביע גולמי *מבלי* ליצור תחילה הפניה.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` תיצור התייחסות לא מיושרת, וכך תהיה התנהגות לא מוגדרת!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` מאלץ להעתיק את השדה במקום ליצור הפניה.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}