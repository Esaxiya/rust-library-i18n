//! מודול לעבודה עם נתונים מושאלים.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait להלוואות נתונים.
///
/// ב-Rust מקובל לספק ייצוגים שונים מסוג למקרי שימוש שונים.
/// לדוגמא, ניתן לבחור במיקום אחסון וניהול של ערך באופן ספציפי כמתאים לשימוש מסוים באמצעות סוגי מצביעים כגון [`Box<T>`] או [`Rc<T>`].
/// מעבר לעטיפות גנריות אלה שניתן להשתמש בהן בכל סוג, ישנם סוגים המספקים היבטים אופציונליים המספקים פונקציונליות יקרה.
/// דוגמא לסוג כזה הוא [`String`] שמוסיף את היכולת להאריך מחרוזת ל-[`str`] הבסיסי.
/// זה דורש שמירה על מידע נוסף מיותר עבור מחרוזת פשוטה ובלתי ניתנת לשינוי.
///
/// סוגים אלה מספקים גישה לנתונים הבסיסיים באמצעות הפניות לסוג הנתונים.אומרים שהם 'מושאלים' כאותו סוג.
/// לדוגמא, ניתן להשאיל [`Box<T>`] כ-`T` ואילו [`String`] ניתן להשאיל כ-`str`.
///
/// סוגים מבטאים שניתן להשאיל אותם כסוג `T` כלשהו על ידי יישום `Borrow<T>`, תוך מתן התייחסות ל-`T` בשיטת [`borrow`] של trait.סוג ניתן ללוות בחינם כמספר סוגים שונים.
/// אם היא מעוניינת ללוות באופן משתנה כסוג-ומאפשרת לשנות את הנתונים הבסיסיים, היא יכולה ליישם בנוסף את [`BorrowMut<T>`].
///
/// יתר על כן, כאשר אנו מספקים יישומים עבור traits נוספים, יש לשקול אם עליהם להתנהג זהים לאלו מהסוג הבסיסי כתוצאה מפעולה כייצוג מאותו סוג בסיסי.
/// קוד גנרי בדרך כלל משתמש ב-`Borrow<T>` כאשר הוא מסתמך על התנהגות זהה של יישומי trait נוספים אלה.
/// traits אלה יופיעו ככל הנראה כ-trait bounds נוספים.
///
/// בפרט `Eq`, `Ord` ו-`Hash` חייבים להיות שווים לערכים שאולים ובבעלות: `x.borrow() == y.borrow()` צריך לתת את אותה תוצאה כמו `x == y`.
///
/// אם קוד גנרי רק צריך לעבוד עבור כל הסוגים שיכולים לספק התייחסות לסוג `T` קשור, לעתים קרובות עדיף להשתמש ב-[`AsRef<T>`] מכיוון שסוגים רבים יותר יכולים ליישם אותו בבטחה.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// כאוסף נתונים, [`HashMap<K, V>`] מחזיק גם במפתחות וגם בערכים.אם הנתונים האמיתיים של המפתח עטופים בסוג ניהול מסוג כלשהו, עם זאת, בכל זאת, יהיה אפשר לחפש ערך באמצעות התייחסות לנתוני המפתח.
/// לדוגמא, אם המפתח הוא מחרוזת, סביר להניח שהוא נשמר עם מפת החשיש כ-[`String`], בעוד שאפשר יהיה לחפש באמצעות [`&str`][`str`].
/// לפיכך, `insert` צריך לפעול ב-`String` בעוד ש-`get` צריך להיות מסוגל להשתמש ב-`&str`.
///
/// הפשטות מעט, החלקים הרלוונטיים של `HashMap<K, V>` נראים כך:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // שדות שהושמטו
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// כל מפת החשיש היא כללית על פני סוג מפתח `K`.מכיוון שמפתחות אלה מאוחסנים עם מפת החשיש, על סוג זה להחזיק בנתוני המפתח.
/// בעת הכנסת זוג ערכי מפתח, המפה ניתנת כ-`K` וצריכה למצוא את דלי ה-hash הנכונים ולבדוק אם המפתח כבר קיים על בסיס ה-`K`.לכן זה דורש `K: Hash + Eq`.
///
/// בעת חיפוש ערך במפה, עם זאת, צורך לספק התייחסות ל-`K` כמפתח לחיפוש ידרוש תמיד ליצור ערך כזה בבעלות.
/// עבור מקשי מחרוזות, פירוש הדבר שיש ליצור ערך `String` רק לחיפוש אחר מקרים בהם רק `str` זמין.
///
/// במקום זאת, שיטת `get` היא כללית על סוג נתוני המפתח הבסיסיים, הנקראים `Q` בחתימת השיטה לעיל.זה קובע כי `K` לווה כ-`Q` על ידי דרישה ל-`K: Borrow<Q>`.
/// על ידי דרישה נוספת של `Q: Hash + Eq`, זה מאותת על הדרישה של-`K` ו-`Q` יש יישומים של ה-`Hash` ו-`Eq` traits המניבים תוצאות זהות.
///
/// היישום של `get` מסתמך במיוחד על יישומים זהים של `Hash` על ידי קביעת דלי החשיש של המפתח על ידי קריאה ל-`Hash::hash` על ערך `Q` למרות שהוא הכניס את המפתח על בסיס ערך החשיש המחושב מערך `K`.
///
///
/// כתוצאה מכך, מפת החשיש נשברת אם `K` העוטף ערך `Q` מייצר חשיש שונה מ-`Q`.לדוגמה, דמיין שיש לך סוג העוטף מחרוזת אך משווה אותיות ASCII המתעלמות מהמקרה שלהן:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// מכיוון ששני ערכים שווים צריכים לייצר את אותו ערך חשיש, היישום של `Hash` צריך להתעלם גם ממקרה ASCII:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// האם `CaseInsensitiveString` יכול ליישם את `Borrow<str>`?זה בהחלט יכול לספק התייחסות לפרוסת מחרוזת דרך המחרוזת הכלולה שלה.
/// אך מכיוון שיישום ה-`Hash` שונה, הוא מתנהג אחרת מ-`str` ולכן אסור לו, למעשה, ליישם את `Borrow<str>`.
/// אם היא רוצה לאפשר לאחרים גישה ל-`str` הבסיסי, היא יכולה לעשות זאת באמצעות `AsRef<str>` שאינו מצריך דרישות נוספות.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// לווה לאין ערוך משווי בעלות.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait לצורך השאלת נתונים באופן משתנה.
///
/// כמלווה ל-[`Borrow<T>`], trait זה מאפשר לסוג ללוות כסוג בסיסי על ידי מתן הפניה משתנה.
/// ראה [`Borrow<T>`] למידע נוסף על הלוואה כסוג אחר.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// לווה באופן מוטרלי משווי בעלות.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}