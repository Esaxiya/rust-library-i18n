use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// אמנם נעשה שימוש בפונקציה זו במקום אחד והיישום שלה יכול להיות מודגש, אך הניסיונות הקודמים לעשות זאת הפכו את rustc לאט יותר:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// פריסת גוש זיכרון.
///
/// מופע של `Layout` מתאר פריסת זיכרון מסוימת.
/// אתה בונה `Layout` למעלה כקלט לתת להקצאה.
///
/// לכל הפריסות יש גודל משויך ויישור כוח לשניים.
///
/// (שים לב כי פריסות *לא* נדרשות לגודל שאינו אפס, למרות ש-`GlobalAlloc` דורש שכל בקשות הזיכרון אינן אפסות בגודלן.
/// על המתקשר לוודא כי מתקיימים תנאים כאלה, להשתמש בהקצאות ספציפיות עם דרישות רופפות יותר, או להשתמש בממשק `Allocator` הקל יותר).
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // גודל גוש הזיכרון המבוקש, נמדד בתים.
    size_: usize,

    // יישור גוש הזיכרון המבוקש, נמדד בתים.
    // אנו מבטיחים שמדובר תמיד בכוח של שניים, מכיוון שממשק API כמו `posix_memalign` דורש זאת וזה אילוץ סביר להטיל על בוני פריסה.
    //
    //
    // (עם זאת, איננו דורשים באופן אנלוגי `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// בונה `Layout` מ-`size` ו-`align` נתון, או מחזיר `LayoutError` אם לא מתקיים אחד מהתנאים הבאים:
    ///
    /// * `align` לא יכול להיות אפס,
    ///
    /// * `align` חייב להיות כוח של שניים,
    ///
    /// * `size`, כאשר מעוגלים כלפי מעלה לכפולה הקרובה ביותר של `align`, אסור להם לעלות על גדותיהם (כלומר, הערך המעוגל חייב להיות קטן או שווה ל-`usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (כוח של שני מרמז על יישור!=0.)

        // גודל מעוגל הוא:
        //   size_rounded_up=(גודל + יישור, 1)&! (יישור, 1);
        //
        // אנו יודעים מלמעלה כי היישור!=0.
        // אם הוספה (יישור, 1) אינה עולה על גדותיו, אז העיגול כלפי מעלה יהיה בסדר.
        //
        // לעומת זאת&&מיסוך עם! (יישור, 1) יפחית רק סיביות בסדר נמוך.
        // לפיכך אם הצפה מתרחשת עם הסכום, המסכה&לא יכולה לחסר מספיק כדי לבטל הצפה זו.
        //
        //
        // לעיל מרמז כי בדיקת הצפת סיכום היא הכרחית ומספיקה כאחד.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // בטיחות: התנאים ל-`from_size_align_unchecked` היו
        // נבדק לעיל.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// יוצר פריסה ועוקף את כל הבדיקות.
    ///
    /// # Safety
    ///
    /// פונקציה זו אינה בטוחה מכיוון שהיא אינה מאמתת את התנאים המוקדמים מ-[`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // בטיחות: על המתקשר לוודא ש-`align` גדול מאפס.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// הגודל המינימלי בתים עבור חסימת זיכרון בפריסה זו.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// יישור בתים מינימלי לחסימת זיכרון בפריסה זו.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// בונה `Layout` המתאים להחזקת ערך מסוג `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // בטיחות: היישור מובטח על ידי Rust להיות כוח של שניים ו
        // משולבת גודל + יישור מובטחת שתשתלב במרחב הכתובות שלנו.
        // כתוצאה מכך השתמש כאן בבנאי הלא מסומן כדי להימנע מהכנסת קוד panics אם הוא לא מותאם מספיק.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// מייצר פריסה המתארת רשומה בה ניתן להקצות מבנה גיבוי ל-`T` (שיכול להיות trait או סוג אחר לא גודל כמו פרוסה).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // בטיחות: ראה נימוק ב-`new` מדוע זה משתמש בגרסה הלא בטוחה
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// מייצר פריסה המתארת רשומה בה ניתן להקצות מבנה גיבוי ל-`T` (שיכול להיות trait או סוג אחר לא גודל כמו פרוסה).
    ///
    /// # Safety
    ///
    /// ניתן להתקשר לפונקציה זו רק אם מתקיימים התנאים הבאים:
    ///
    /// - אם `T` הוא `Sized`, פונקציה זו תמיד בטוחה להתקשרות.
    /// - אם הזנב הלא גדול של `T` הוא:
    ///     - [slice], אז אורך זנב הפרוסה חייב להיות מספר שלם אינטליזציה, וגודל הערך * כולו (אורך הזנב הדינמי + קידומת בגודל סטטי) חייב להתאים ל-`isize`.
    ///     - [trait object], אז החלק vtable של המצביע חייב להצביע על vtable חוקי עבור הסוג `T` שנרכש על ידי כפיה לא מגדילה, וגודל הערך * כולו (אורך זנב דינמי + קידומת בגודל סטטי) חייב להתאים ל-`isize`.
    ///
    ///     - (unstable) [extern type], אז פונקציה זו תמיד בטוחה להתקשרות, אך ייתכן ש-panic או אחרת יחזיר את הערך הלא נכון, מכיוון שפריסת הסוג החיצוני אינה ידועה.
    ///     זו אותה התנהגות כמו [`Layout::for_value`] בהתייחס לזנב מסוג חיצוני.
    ///     - אחרת, אסור בשמירה לקרוא לפונקציה זו.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // בטיחות: אנו מעבירים את התנאים המוקדמים של פונקציות אלה למתקשר
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // בטיחות: ראה נימוק ב-`new` מדוע זה משתמש בגרסה הלא בטוחה
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// יוצר `NonNull` המשתלשל, אך מיושר היטב לפריסה זו.
    ///
    /// שים לב שערך המצביע עשוי לייצג מצביע חוקי, כלומר אסור להשתמש בזה כערך זקיף "not yet initialized".
    /// סוגים המוקצים בעצלתיים חייבים לעקוב אחר אתחול באמצעים אחרים.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // בטיחות: מובטח שהיישור אינו אפס
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// יוצר פריסה המתארת את הרשומה שיכולה להחזיק ערך של אותה פריסה כמו `self`, אך גם מיושרת ליישור `align` (נמדד בתים).
    ///
    ///
    /// אם `self` כבר עומד ביישור שנקבע, מחזיר את `self`.
    ///
    /// שים לב ששיטה זו אינה מוסיפה ריפוד לגודל הכללי, ללא קשר אם לפריסה שהוחזרה יש יישור שונה.
    /// במילים אחרות, אם ל-`K` יש גודל 16, ל-`K.align_to(32)`*עדיין* יהיה גודל 16.
    ///
    /// מחזירה שגיאה אם השילוב של `self.size()` ו-`align` הנתון מפר את התנאים המפורטים ב-[`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// מחזירה את כמות הריפודים שעלינו להכניס לאחר `self` כדי להבטיח שהכתובת הבאה תספק את `align` (נמדד בתים).
    ///
    /// לדוגמא, אם `self.size()` הוא 9, אז `self.padding_needed_for(4)` מחזיר 3, מכיוון שזה המספר המינימלי של בתים של ריפוד הנדרש לקבלת כתובת המיושרת לארבעה (בהנחה שבלוק הזיכרון המתאים מתחיל בכתובת 4 מיושרת).
    ///
    ///
    /// לערך ההחזרה של פונקציה זו אין משמעות אם `align` אינו כוח של שניים.
    ///
    /// שים לב שהתועלת של הערך המוחזר מחייבת את `align` להיות פחות או שווה ליישור כתובת ההתחלה עבור כל גוש הזיכרון שהוקצה.אחת הדרכים לעמוד במגבלה זו היא להבטיח את `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // הערך המעוגל הוא:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // ואז אנו מחזירים את הפרש הריפוד: `len_rounded_up - len`.
        //
        // אנו משתמשים בחשבון מודולרי לאורך כל הדרך:
        //
        // 1. יישור מובטח להיות> 0, אז יישור, 1 תמיד תקף.
        //
        // 2.
        // `len + align - 1` יכול לגלוש לכל היותר ב-`align - 1`, ולכן&-מסכה עם `!(align - 1)` תבטיח שבמקרה של הצפה, `len_rounded_up` עצמו יהיה 0.
        //
        //    כך שהריפוד המוחזר, כשהוא מתווסף ל-`len`, מניב 0, המספק באופן טריוויאלי את היישור `align`.
        //
        // (כמובן, ניסיונות להקצות גושי זיכרון שגודלם וריפודם עולה על הצורה לעיל אמורים לגרום למקצה להניב שגיאה בכל מקרה.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// יוצר פריסה על ידי עיגול הגודל של פריסה זו עד לכפולה של יישור הפריסה.
    ///
    ///
    /// זה שווה ערך להוספת התוצאה של `padding_needed_for` לגודל הנוכחי של הפריסה.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // זה לא יכול לעלות על גדותיו.הצעת מחיר ממתכונת הפריסה:
        // > `size`, כאשר מעוגלים כלפי מעלה לכפולה הקרובה ביותר של `align`,
        // > אסור לעלות על גדותיו (כלומר, הערך המעוגל חייב להיות קטן מ-
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// יוצר פריסה המתארת את הרשומה למופעי `n` של `self`, עם כמות ריפוד מתאימה בין כל אחד כדי להבטיח שכל מופע יקבל את הגודל והיישור המבוקשים.
    /// בהצלחה, מחזירה את `(k, offs)` כאשר `k` הוא פריסת המערך ו-`offs` הוא המרחק בין התחלת כל אלמנט במערך.
    ///
    /// על הצפת חשבון, מחזירה את `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // זה לא יכול לעלות על גדותיו.הצעת מחיר ממתכונת הפריסה:
        // > `size`, כאשר מעוגלים כלפי מעלה לכפולה הקרובה ביותר של `align`,
        // > אסור לעלות על גדותיו (כלומר, הערך המעוגל חייב להיות קטן מ-
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // בטיחות: ידוע שכבר ידוע כי self.align תקף וההקצאה_גודל הייתה
        // מרופד כבר.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// יוצר פריסה המתארת את הרשומה עבור `self` ואחריה `next`, כולל כל ריפוד הדרוש בכדי להבטיח כי `next` יהיה מיושר כראוי, אך *ללא ריפוד נגרר*.
    ///
    /// על מנת להתאים לפריסת ייצוג C `repr(C)`, עליך להתקשר ל-`pad_to_align` לאחר הארכת הפריסה עם כל השדות.
    /// (אין דרך להתאים לפריסת ייצוג Rust המוגדרת כברירת מחדל `repr(Rust)`, as it is unspecified.)
    ///
    /// שים לב כי יישור הפריסה המתקבלת יהיה המקסימלי של `self` ו-`next`, על מנת להבטיח יישור של שני החלקים.
    ///
    /// מחזירה את `Ok((k, offset))`, כאשר `k` הוא פריסת הרשומה המשורשרת ו-`offset` הוא המיקום היחסי, בתים, של תחילת ה-`next` המוטמע ברשומה המצורפת (בהנחה שהרשומה עצמה מתחילה בקיזוז 0).
    ///
    ///
    /// על הצפת חשבון, מחזירה את `LayoutError`.
    ///
    /// # Examples
    ///
    /// כדי לחשב את הפריסה של מבנה `#[repr(C)]` ואת קיזוזי השדות מפריסת השדות שלו:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // זכור לסיים עם `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // לבדוק שזה עובד
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// יוצר פריסה המתארת את הרשומה עבור מופעי `n` של `self`, ללא ריפוד בין כל מופע.
    ///
    /// שים לב שבניגוד ל-`repeat`, `repeat_packed` אינו מתחייב שהמופעים החוזרים ונשנים של `self` יהיו מיושרים כראוי, גם אם מופע מסוים של `self` מיושר כהלכה.
    /// במילים אחרות, אם הפריסה שהוחזרה על ידי `repeat_packed` משמשת להקצאת מערך, לא מובטח שכל האלמנטים במערך יהיו מיושרים כהלכה.
    ///
    /// על הצפת חשבון, מחזירה את `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// יוצר פריסה המתארת את הרשומה ל-`self` ואחריה `next` ללא ריפוד נוסף בין השניים.
    /// מכיוון שלא מכניסים שום ריפוד, היישור של `next` אינו רלוונטי, ואינו משולב *כלל* בפריסה המתקבלת.
    ///
    ///
    /// על הצפת חשבון, מחזירה את `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// יוצר פריסה המתארת את הרשומה עבור `[T; n]`.
    ///
    /// על הצפת חשבון, מחזירה את `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// הפרמטרים שניתנו ל-`Layout::from_size_align` או לבנאי `Layout` אחר אינם עומדים באילוצים המתועדים שלו.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (אנו זקוקים לכך לצורך יישום שגיאה trait במורד הזרם)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}