//! ממשקי API להקצאת זיכרון

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// שגיאת `AllocError` מציינת כשל בהקצאה שעשוי להיות בגלל מיצוי משאבים או ממשהו לא תקין בשילוב ארגומנטים של קלט נתון עם מקצה זה.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (אנו זקוקים לכך לצורך יישום שגיאה trait במורד הזרם)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// יישום של `Allocator` יכול להקצות, לגדול, לכווץ ולהתקין חסימות נתונים שרירותיות המתוארות באמצעות [`Layout`][].
///
/// `Allocator` מיועד ליישום ב-ZST, הפניות או מצביעים חכמים מכיוון שלא ניתן להזיז מקצה כמו `MyAlloc([u8; N])` מבלי לעדכן את המצביעים לזיכרון שהוקצה.
///
/// בניגוד ל-[`GlobalAlloc`][], הקצאות בגודל אפס מותרות ב-`Allocator`.
/// אם מקצה בסיסי אינו תומך בכך (כמו jemalloc) או מחזיר מצביע אפס (כגון `libc::malloc`), יש ליישם זאת ביישום.
///
/// ### זיכרון שהוקצה כעת
///
/// חלק מהשיטות מחייבות *חסימת זיכרון* שתוקצה כעת * באמצעות מקצה.זה אומר ש:
///
/// * כתובת ההתחלה של אותו חסימת זיכרון הוחזרה בעבר על ידי [`allocate`], [`grow`] או [`shrink`], ו-
///
/// * חסימת הזיכרון לא הועברה לאחר מכן, כאשר החסימות ממוקמות ישירות על ידי העברה ל-[`deallocate`] או שהוחלפו על ידי העברה ל-[`grow`] או [`shrink`] המחזירה `Ok`.
///
/// אם `grow` או `shrink` החזירו את `Err`, המצביע שעבר נשאר תקף.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### התאמת זיכרון
///
/// חלק מהשיטות דורשות כי פריסה *תתאים* לחסימת זיכרון.
/// המשמעות של פריסה ל-"fit" פירוש של חסימת זיכרון (או שווה ערך, עבור חסימת זיכרון ל-"fit" פריסה) הוא שהתנאים הבאים חייבים להתקיים:
///
/// * יש להקצות את החסימה עם אותה יישור כמו [`layout.align()`] ו-
///
/// * ה-[`layout.size()`] המסופק חייב להיות בטווח `min ..= max`, שם:
///   - `min` הוא גודל הפריסה ששימש לאחרונה להקצאת החסימה, ו-
///   - `max` הוא הגודל האמיתי האחרון שהוחזר מ-[`allocate`], [`grow`] או [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * חסימות זיכרון המוחזרות מקצה חייבות להצביע על זיכרון תקף ולשמור על תקפותן עד שהמופע וכל שיבוטיו נשמטים,
///
/// * אסור לשכפל או להזיז את ההקצאה לפסול חסימות זיכרון שהוחזרו ממקצה זה.מקצה משובט חייב להתנהג כמו אותו מקצה, ו
///
/// * כל מצביע לבלוק זיכרון שהוא [*currently allocated*] יכול להיות מועבר לכל שיטה אחרת של המקצה.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// ניסיונות להקצות גוש זיכרון.
    ///
    /// בהצלחה, מחזירה [`NonNull<[u8]>`][NonNull] העומד בגודל וערבויות היישור של `layout`.
    ///
    /// לגוש שהוחזר יכול להיות גודל גדול יותר ממה שצוין על ידי `layout.size()`, וייתכן כי התוכן שלו אותחל.
    ///
    /// # Errors
    ///
    /// החזרת `Err` מצביעה על כך שזיכרון אוזל או ש-`layout` אינו עומד במגבלות ההקצאה או במגבלות היישור.
    ///
    /// יישומים מוזמנים להחזיר את `Err` למיצוי הזיכרון במקום להיבהל או להפסיק, אך זו אינה דרישה מחמירה.
    /// (באופן ספציפי: זה *חוקי* ליישם את ה-trait על גבי ספריית הקצאות מקורית העומדת על מיצוי זיכרון.)
    ///
    /// לקוחות המעוניינים להפסיק את החישוב בתגובה לשגיאת הקצאה מוזמנים להתקשר לפונקציה [`handle_alloc_error`], במקום להפעיל ישירות את `panic!` או דומה.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// מתנהג כמו `allocate`, אך גם מבטיח שהזיכרון שהוחזר יותחל לאפס.
    ///
    /// # Errors
    ///
    /// החזרת `Err` מצביעה על כך שזיכרון אוזל או ש-`layout` אינו עומד במגבלות ההקצאה או במגבלות היישור.
    ///
    /// יישומים מוזמנים להחזיר את `Err` למיצוי הזיכרון במקום להיבהל או להפסיק, אך זו אינה דרישה מחמירה.
    /// (באופן ספציפי: זה *חוקי* ליישם את ה-trait על גבי ספריית הקצאות מקורית העומדת על מיצוי זיכרון.)
    ///
    /// לקוחות המעוניינים להפסיק את החישוב בתגובה לשגיאת הקצאה מוזמנים להתקשר לפונקציה [`handle_alloc_error`], במקום להפעיל ישירות את `panic!` או דומה.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // בטיחות: `alloc` מחזיר חסימת זיכרון תקפה
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// מיקום מחדש את הזיכרון אליו מפנה `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` חייב לציין גוש זיכרון [*currently allocated*] באמצעות מקצה זה, ו
    /// * `layout` חייב [*fit*] זה גוש הזיכרון.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// ניסיונות להאריך את חסימת הזיכרון.
    ///
    /// מחזירה [`NonNull<[u8]>`][NonNull] חדש המכיל מצביע ואת הגודל האמיתי של הזיכרון שהוקצה.המצביע מתאים לאחסון נתונים המתוארים על ידי `new_layout`.
    /// כדי להשיג זאת, המקצה רשאי להאריך את ההקצאה אליה מפנה `ptr` כך שתתאים לפריסה החדשה.
    ///
    /// אם פעולה זו מחזירה את `Ok`, הבעלות על גוש הזיכרון שהופנה על ידי `ptr` הועברה להקצאה זו.
    /// ייתכן שהזיכרון שוחרר או לא, ויש לראותו כבלתי שמיש אלא אם כן הועבר חזרה למתקשר שוב באמצעות ערך ההחזרה של שיטה זו.
    ///
    /// אם שיטה זו מחזירה את `Err`, הבעלות על גוש הזיכרון לא הועברה להקצאה זו, ותוכן גוש הזיכרון אינו משתנה.
    ///
    /// # Safety
    ///
    /// * `ptr` חייב לציין גוש זיכרון [*currently allocated*] באמצעות מקצה זה.
    /// * `old_layout` חייב [*fit*] באותו גוש זיכרון (הטיעון `new_layout` לא צריך להתאים לו.).
    /// * `new_layout.size()` חייב להיות גדול או שווה ל-`old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// מחזירה `Err` אם הפריסה החדשה אינה עומדת בגודל ההקצאה ובאילוצי היישור של ההקצה, או אם הצמיחה אחרת נכשלת.
    ///
    /// יישומים מוזמנים להחזיר את `Err` למיצוי הזיכרון במקום להיבהל או להפסיק, אך זו אינה דרישה מחמירה.
    /// (באופן ספציפי: זה *חוקי* ליישם את ה-trait על גבי ספריית הקצאות מקורית העומדת על מיצוי זיכרון.)
    ///
    /// לקוחות המעוניינים להפסיק את החישוב בתגובה לשגיאת הקצאה מוזמנים להתקשר לפונקציה [`handle_alloc_error`], במקום להפעיל ישירות את `panic!` או דומה.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // בטיחות: מכיוון ש-`new_layout.size()` חייב להיות גדול או שווה ל-
        // `old_layout.size()`, הקצאת הזיכרון הישנה והחדשה תקפה לקריאה וכתיבה עבור בתים `old_layout.size()`.
        // כמו כן, מכיוון שההקצאה הישנה טרם הוקצה, היא אינה יכולה לחפוף את `new_ptr`.
        // לפיכך, השיחה ל-`copy_nonoverlapping` בטוחה.
        // חוזה הבטיחות ל-`dealloc` חייב להתקיים על ידי המתקשר.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// מתנהג כמו `grow`, אך גם מבטיח שהתכנים החדשים מוגדרים לאפס לפני החזרתם.
    ///
    /// חסימת הזיכרון תכיל את התכנים הבאים לאחר שיחה מוצלחת אל
    /// `grow_zeroed`:
    ///   * בתים `0..old_layout.size()` נשמרים מההקצאה המקורית.
    ///   * בתים `old_layout.size()..old_size` יישמרו או יאופסו, בהתאם ליישום ההקצאה.
    ///   `old_size` מתייחס לגודל גוש הזיכרון לפני השיחה `grow_zeroed`, שעשוי להיות גדול מהגודל שבמקור התבקש בעת הקצאתו.
    ///   * בתים `old_size..new_size` אפסים.`new_size` מתייחס לגודל בלוק הזיכרון שהוחזר על ידי שיחת `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` חייב לציין גוש זיכרון [*currently allocated*] באמצעות מקצה זה.
    /// * `old_layout` חייב [*fit*] באותו גוש זיכרון (הטיעון `new_layout` לא צריך להתאים לו.).
    /// * `new_layout.size()` חייב להיות גדול או שווה ל-`old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// מחזירה `Err` אם הפריסה החדשה אינה עומדת בגודל ההקצאה ובאילוצי היישור של ההקצה, או אם הצמיחה אחרת נכשלת.
    ///
    /// יישומים מוזמנים להחזיר את `Err` למיצוי הזיכרון במקום להיבהל או להפסיק, אך זו אינה דרישה מחמירה.
    /// (באופן ספציפי: זה *חוקי* ליישם את ה-trait על גבי ספריית הקצאות מקורית העומדת על מיצוי זיכרון.)
    ///
    /// לקוחות המעוניינים להפסיק את החישוב בתגובה לשגיאת הקצאה מוזמנים להתקשר לפונקציה [`handle_alloc_error`], במקום להפעיל ישירות את `panic!` או דומה.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // בטיחות: מכיוון ש-`new_layout.size()` חייב להיות גדול או שווה ל-
        // `old_layout.size()`, הקצאת הזיכרון הישנה והחדשה תקפה לקריאה וכתיבה עבור בתים `old_layout.size()`.
        // כמו כן, מכיוון שההקצאה הישנה טרם הוקצה, היא אינה יכולה לחפוף את `new_ptr`.
        // לפיכך, השיחה ל-`copy_nonoverlapping` בטוחה.
        // חוזה הבטיחות ל-`dealloc` חייב להתקיים על ידי המתקשר.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// ניסיונות לכווץ את גוש הזיכרון.
    ///
    /// מחזירה [`NonNull<[u8]>`][NonNull] חדש המכיל מצביע ואת הגודל האמיתי של הזיכרון שהוקצה.המצביע מתאים לאחסון נתונים המתוארים על ידי `new_layout`.
    /// כדי להשיג זאת, המקצה עשוי לכווץ את ההקצאה שה-`ptr` מפנה אליה כך שתתאים לפריסה החדשה.
    ///
    /// אם פעולה זו מחזירה את `Ok`, הבעלות על גוש הזיכרון שהופנה על ידי `ptr` הועברה להקצאה זו.
    /// ייתכן שהזיכרון שוחרר או לא, ויש לראותו כבלתי שמיש אלא אם כן הועבר חזרה למתקשר שוב באמצעות ערך ההחזרה של שיטה זו.
    ///
    /// אם שיטה זו מחזירה את `Err`, הבעלות על גוש הזיכרון לא הועברה להקצאה זו, ותוכן גוש הזיכרון אינו משתנה.
    ///
    /// # Safety
    ///
    /// * `ptr` חייב לציין גוש זיכרון [*currently allocated*] באמצעות מקצה זה.
    /// * `old_layout` חייב [*fit*] באותו גוש זיכרון (הטיעון `new_layout` לא צריך להתאים לו.).
    /// * `new_layout.size()` חייב להיות קטן או שווה ל-`old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// מחזירה `Err` אם הפריסה החדשה אינה עומדת בגודל ההקצאה ובאילוצי היישור של ההקצה, או אם התכווצות אחרת נכשלת.
    ///
    /// יישומים מוזמנים להחזיר את `Err` למיצוי הזיכרון במקום להיבהל או להפסיק, אך זו אינה דרישה מחמירה.
    /// (באופן ספציפי: זה *חוקי* ליישם את ה-trait על גבי ספריית הקצאות מקורית העומדת על מיצוי זיכרון.)
    ///
    /// לקוחות המעוניינים להפסיק את החישוב בתגובה לשגיאת הקצאה מוזמנים להתקשר לפונקציה [`handle_alloc_error`], במקום להפעיל ישירות את `panic!` או דומה.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // בטיחות: מכיוון ש-`new_layout.size()` חייב להיות נמוך או שווה ל-
        // `old_layout.size()`, הקצאת הזיכרון הישנה והחדשה תקפה לקריאה וכתיבה עבור בתים `new_layout.size()`.
        // כמו כן, מכיוון שההקצאה הישנה טרם הוקצה, היא אינה יכולה לחפוף את `new_ptr`.
        // לפיכך, השיחה ל-`copy_nonoverlapping` בטוחה.
        // חוזה הבטיחות ל-`dealloc` חייב להתקיים על ידי המתקשר.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// יוצר מתאם "by reference" למופע זה של `Allocator`.
    ///
    /// המתאם שהוחזר מיישם גם את `Allocator` ופשוט ישאיל את זה.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // בטיחות: על חוזה הבטיחות להתקיים על ידי המתקשר
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // בטיחות: על חוזה הבטיחות להתקיים על ידי המתקשר
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // בטיחות: על חוזה הבטיחות להתקיים על ידי המתקשר
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // בטיחות: על חוזה הבטיחות להתקיים על ידי המתקשר
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}