use crate::iter::FromIterator;

/// מכווץ את כל פריטי היחידה מאיטרציה לאחד.
///
/// זה שימושי יותר בשילוב עם הפשטות ברמה גבוהה יותר, כמו איסוף ל-`Result<(), E>` שבו אכפת לך רק משגיאות:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}