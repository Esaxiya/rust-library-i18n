//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// נקודת הקוד הכי תקפה שיכולה להיות ל-`char`.
    ///
    /// `char` הוא [Unicode Scalar Value], כלומר מדובר ב-[Code Point], אך רק בטווח מסוים.
    /// `MAX` היא נקודת הקוד הכי תקפה שהיא [Unicode Scalar Value] תקפה.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () משמש ב-Unicode כדי לייצג שגיאת פענוח.
    ///
    /// זה יכול להתרחש, למשל, כאשר נותנים בתים UTF-8 בצורה לא טובה ל-[`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// הגרסה של [Unicode](http://www.unicode.org/) שעליה מבוססות חלקי ה-Unicode בשיטות `char` ו-`str`.
    ///
    /// גרסאות חדשות של Unicode מתפרסמות באופן קבוע ובהמשך מתעדכנות כל השיטות בספריה הסטנדרטית, בהתאם ל-Unicode.
    /// לכן ההתנהגות של כמה משיטות `char` ו-`str` והערך של קבוע זה משתנה לאורך זמן.
    /// זה *לא* נחשב לשינוי שבור.
    ///
    /// ערכת מספור הגרסאות מוסברת ב-[Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// יוצר איטרטור מעל נקודות הקוד המקודדות UTF-16 ב-`iter`, ומחזיר פונדקאיות לא מזווגות כ-'Err`s.
    ///
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// ניתן להשיג מפענח אבוד על ידי החלפת תוצאות `Err` בתו החלופי:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// ממיר `u32` ל-`char`.
    ///
    /// שים לב שכל 'char's תקפים [`u32`], וניתן להטיל אותם עם אחד
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// עם זאת, ההפך אינו נכון: לא כל [`u32`] תקפים הם char.
    /// `from_u32()` יחזיר את `None` אם הקלט אינו ערך תקף עבור `char`.
    ///
    /// לקבלת גרסה לא בטוחה של פונקציה זו המתעלמת מבדיקות אלה, ראה [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// החזרת `None` כאשר הקלט אינו `char` תקף:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// ממיר `u32` ל-`char`, תוך התעלמות מתוקף.
    ///
    /// שים לב שכל 'char's תקפים [`u32`], וניתן להטיל אותם עם אחד
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// עם זאת, ההפך אינו נכון: לא כל [`u32`] תקפים הם char.
    /// `from_u32_unchecked()` יתעלם מכך, וישליך באופן עיוור ל-`char`, ואולי ייצור אחד לא חוקי.
    ///
    ///
    /// # Safety
    ///
    /// פונקציה זו אינה בטוחה מכיוון שהיא עשויה לבנות ערכי `char` לא חוקיים.
    ///
    /// לקבלת גרסה בטוחה של פונקציה זו, עיין בפונקציה [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // בטיחות: על חוזה הבטיחות להתקיים על ידי המתקשר.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// ממיר ספרה ברדיקס הנתון ל-`char`.
    ///
    /// 'radix' כאן נקרא לפעמים גם 'base'.
    /// רדיקס של שניים מציין מספר בינארי, רדיקל של עשר, עשרוני ורדיקל של שש עשרה, הקסדצימלי, כדי לתת כמה ערכים משותפים.
    ///
    /// תומכים ברדיאטורים שרירותיים.
    ///
    /// `from_digit()` יחזיר את `None` אם הקלט אינו ספרה ברדיקס הנתון.
    ///
    /// # Panics
    ///
    /// Panics אם מקבלים רדיקל גדול מ-36.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // עשרוני 11 הוא ספרה אחת בבסיס 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// החזרת `None` כאשר הקלט אינו ספרה:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// מעבירים רדיקס גדול וגורמים ל-panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// בודק אם `char` הוא ספרה ברדיקס הנתון.
    ///
    /// 'radix' כאן נקרא לפעמים גם 'base'.
    /// רדיקס של שניים מציין מספר בינארי, רדיקל של עשר, עשרוני ורדיקל של שש עשרה, הקסדצימלי, כדי לתת כמה ערכים משותפים.
    ///
    /// תומכים ברדיאטורים שרירותיים.
    ///
    /// בהשוואה ל-[`is_numeric()`], פונקציה זו מזהה רק את התווים `0-9`, `a-z` ו-`A-Z`.
    ///
    /// 'Digit' מוגדר להיות התווים הבאים בלבד:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// להבנה מקיפה יותר של 'digit', ראה [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics אם מקבלים רדיקל גדול מ-36.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// מעבירים רדיקס גדול וגורמים ל-panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// ממיר `char` לספרה ברדיקס הנתון.
    ///
    /// 'radix' כאן נקרא לפעמים גם 'base'.
    /// רדיקס של שניים מציין מספר בינארי, רדיקל של עשר, עשרוני ורדיקל של שש עשרה, הקסדצימלי, כדי לתת כמה ערכים משותפים.
    ///
    /// תומכים ברדיאטורים שרירותיים.
    ///
    /// 'Digit' מוגדר להיות התווים הבאים בלבד:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// מחזירה `None` אם ה-`char` אינו מתייחס לספרה ברדיקס הנתון.
    ///
    /// # Panics
    ///
    /// Panics אם מקבלים רדיקל גדול מ-36.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// העברת ספרה שאינה ספרתית גורמת לכישלון:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// מעבירים רדיקס גדול וגורמים ל-panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // הקוד מחולק כאן כדי לשפר את מהירות הביצוע במקרים בהם `radix` קבוע ו-10 ומטה
        //
        let val = if likely(radix <= 10) {
            // אם לא ספרה, ייווצר מספר גדול מ-Radix.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// מחזירה איטרטור שמביא את בריחת Unicode ההקסדצימאלית של תו כ-char.
    ///
    /// זה יברח מתווים עם התחביר Rust של הטופס `\u{NNNNNN}` כאשר `NNNNNN` הוא ייצוג הקסדצימלי.
    ///
    ///
    /// # Examples
    ///
    /// כאיטרטור:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// שימוש ישיר ב-`println!`:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// שניהם שווים ל:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// שימוש ב-`to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 מבטיח כי עבור c==0 הקוד יחשב שיש להדפיס ספרה אחת ו (וזהה) ימנע את הזרימה (31, 32)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // אינדקס הספרה המשושה המשמעותית ביותר
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// גרסה מורחבת של `escape_debug` המאפשרת אפשרות לברוח מנקודות קוד מורחבות של Grapheme.
    /// זה מאפשר לנו לעצב תווים כמו סימני רווח טובים יותר כשהם בתחילת מחרוזת.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// מחזיר איטרטור שמניב את קוד הבריחה המילולי של תו כ-char.
    ///
    /// זה יברח מהתווים הדומים ליישומי `Debug` של `str` או `char`.
    ///
    ///
    /// # Examples
    ///
    /// כאיטרטור:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// שימוש ישיר ב-`println!`:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// שניהם שווים ל:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// שימוש ב-`to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// מחזיר איטרטור שמניב את קוד הבריחה המילולי של תו כ-char.
    ///
    /// ברירת המחדל נבחרת עם הטיה לייצור מילוליות חוקיות במגוון שפות, כולל C++ 11 ושפות דומות של משפחת C.
    /// הכללים המדויקים הם:
    ///
    /// * הכרטיסייה נמלטת כ-`\t`.
    /// * החזרת הובלה נמלטה כ-`\r`.
    /// * הזנת הקווים נמלטת כ-`\n`.
    /// * הצעת מחיר בודדת נמלטת כ-`\'`.
    /// * הצעת מחיר כפולה נמלטת כ-`\"`.
    /// * נטייה אחורית נמלטת כ-`\\`.
    /// * כל תו בטווח 'ASCII להדפסה' `0x20` .. `0x7e` כולל אינו נמלט.
    /// * כל שאר התווים מקבלים בריחות Unicode הקסדצימליות;ראה [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// כאיטרטור:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// שימוש ישיר ב-`println!`:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// שניהם שווים ל:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// שימוש ב-`to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// מחזיר את מספר הבתים ש-`char` יצטרך לו אם הוא מקודד ב-UTF-8.
    ///
    /// מספר הבתים הזה הוא תמיד בין 1 ל-4, כולל.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// סוג ה-`&str` מבטיח כי תוכנו הוא UTF-8, ולכן אנו יכולים להשוות את אורכו שיידרש אם כל נקודת קוד תוצג כ-`char` לעומת ב-`&str` עצמה:
    ///
    ///
    /// ```
    /// // כמו תווים
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // שניהם יכולים להיות מיוצגים כשלושה בתים
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // כ-&str, שני אלה מקודדים ב-UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // אנו יכולים לראות שהם לוקחים שישה בתים בסך הכל ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... בדיוק כמו ה-&str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// מחזיר את מספר יחידות הקוד של 16 סיביות ש-`char` יזדקק לו אם הוא מקודד ב-UTF-16.
    ///
    ///
    /// ראה תיעוד ל-[`len_utf8()`] להסבר נוסף על מושג זה.
    /// פונקציה זו היא מראה, אך עבור UTF-16 במקום UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// מקודד תו זה כ-UTF-8 למאגר בתים המסופק, ואז מחזיר את תת החלק של המאגר המכיל את התו המקודד.
    ///
    ///
    /// # Panics
    ///
    /// Panics אם המאגר אינו גדול מספיק.
    /// חיץ באורך ארבע גדול מספיק כדי לקודד כל `char`.
    ///
    /// # Examples
    ///
    /// בשתי הדוגמאות הללו, 'ß' לוקח שני בתים לקידוד.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// חיץ קטן מדי:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // בטיחות: `char` אינו פונדקאית, ולכן זה UTF-8 תקף.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// מקודד תו זה כ-UTF-16 למאגר ה-`u16` שסופק, ואז מחזיר את תת החלק של המאגר המכיל את התו המקודד.
    ///
    ///
    /// # Panics
    ///
    /// Panics אם המאגר אינו גדול מספיק.
    /// חיץ באורך 2 גדול מספיק כדי לקודד כל `char`.
    ///
    /// # Examples
    ///
    /// בשתי הדוגמאות הללו, ל-'𝕊' צריך לקודד שני U16.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// חיץ קטן מדי:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// מחזירה `true` אם ל-`char` הזה יש המאפיין `Alphabetic`.
    ///
    /// `Alphabetic` מתואר בפרק 4 (מאפייני תווים) של ה-[Unicode Standard] ומוגדר ב-[Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // אהבה היא דברים רבים, אך היא אינה אלפביתית
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// מחזירה `true` אם ל-`char` הזה יש המאפיין `Lowercase`.
    ///
    /// `Lowercase` מתואר בפרק 4 (מאפייני תווים) של ה-[Unicode Standard] ומוגדר ב-[Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // לתסריטים ולפיסוק הסינית השונים אין המקרה, וכך:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// מחזירה `true` אם ל-`char` הזה יש המאפיין `Uppercase`.
    ///
    /// `Uppercase` מתואר בפרק 4 (מאפייני תווים) של ה-[Unicode Standard] ומוגדר ב-[Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // לתסריטים ולפיסוק הסינית השונים אין המקרה, וכך:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// מחזירה `true` אם ל-`char` הזה יש המאפיין `White_Space`.
    ///
    /// `White_Space` מוגדר ב-[Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // מרחב לא שובר
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// מחזירה `true` אם `char` זה עומד ב-[`is_alphabetic()`] או [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// מחזירה `true` אם ל-`char` זה יש את הקטגוריה הכללית לקודי בקרה.
    ///
    /// קודי בקרה (נקודות קוד עם הקטגוריה הכללית של `Cc`) מתוארים בפרק 4 (מאפייני תווים) של ה-[Unicode Standard] ומוגדר ב-[Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// // U + 009C, מחזק מחרוזת
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// מחזירה `true` אם ל-`char` הזה יש המאפיין `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` מתואר ב-[Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] ומוגדר ב-[Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// מחזירה `true` אם ל-`char` זה יש אחת הקטגוריות הכלליות למספרים.
    ///
    /// הקטגוריות הכלליות למספרים (`Nd` עבור ספרות עשרוניות, `Nl` עבור תווים מספריים דמויי אות ו-`No` עבור תווים מספריים אחרים) מוגדרות ב-[Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// מחזירה איטרטור שמביא למיפוי קטן של `char` זה כאחד או יותר
    /// `char`s.
    ///
    /// אם ל-`char` זה אין מיפוי קטן, האיטרטור מניב את אותו `char`.
    ///
    /// אם ל-`char` זה מיפוי קטן לאחד שניתן על ידי [Unicode Character Database][ucd] [`UnicodeData.txt`], האיטרטור מניב את ה-`char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// אם `char` זה דורש שיקולים מיוחדים (למשל `char`s מרובים) האיטרטור מניב את ה-`char` (ים) הניתנים על ידי [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// פעולה זו מבצעת מיפוי ללא תנאי ללא התאמה.כלומר, הגיור אינו תלוי בהקשר ובשפה.
    ///
    /// ב-[Unicode Standard], פרק 4 (מאפייני תווים) דן במיפוי מקרים באופן כללי ופרק 3 (Conformance) דן באלגוריתם ברירת המחדל להמרת מקרה.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// כאיטרטור:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// שימוש ישיר ב-`println!`:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// שניהם שווים ל:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// שימוש ב-`to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // לפעמים התוצאה היא יותר מדמות אחת:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // תווים שאין להם גם אותיות רישיות וגם קטנות, הופכים לעצמם.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// מחזירה איטרטור שמביא את המיפוי האותיות של `char` זה כאחד או יותר
    /// `char`s.
    ///
    /// אם ל-`char` זה אין מיפוי רישיות, האיטרטור מניב את אותו `char`.
    ///
    /// אם ל-`char` יש מיפוי רישיות אחד לאחד שניתן על ידי [Unicode Character Database][ucd] [`UnicodeData.txt`], האיטרטור מניב את ה-`char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// אם `char` זה דורש שיקולים מיוחדים (למשל `char`s מרובים) האיטרטור מניב את ה-`char` (ים) הניתנים על ידי [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// פעולה זו מבצעת מיפוי ללא תנאי ללא התאמה.כלומר, הגיור אינו תלוי בהקשר ובשפה.
    ///
    /// ב-[Unicode Standard], פרק 4 (מאפייני תווים) דן במיפוי מקרים באופן כללי ופרק 3 (Conformance) דן באלגוריתם ברירת המחדל להמרת מקרה.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// כאיטרטור:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// שימוש ישיר ב-`println!`:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// שניהם שווים ל:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// שימוש ב-`to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // לפעמים התוצאה היא יותר מדמות אחת:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // תווים שאין להם גם אותיות רישיות וגם קטנות, הופכים לעצמם.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # הערה על המקום
    ///
    /// בטורקית, המקבילה ל-'i' בלטינית יש חמש צורות במקום שתיים:
    ///
    /// * 'Dotless': אני/ı, לפעמים נכתב ï
    /// * 'Dotted': İ/i
    ///
    /// שים לב שה-'i' המנוקד באותיות קטנות זהה לטיני.לָכֵן:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// הערך של `upper_i` כאן מסתמך על שפת הטקסט: אם אנחנו ב-`en-US`, זה צריך להיות `"I"`, אבל אם אנחנו ב-`tr_TR`, זה צריך להיות `"İ"`.
    /// `to_uppercase()` לא לוקח זאת בחשבון, וכך:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// מחזיק בשפות שונות.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// בודק אם הערך נמצא בטווח ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// יוצר עותק של הערך במקביל ל-ASCII באותיות רישיות.
    ///
    /// אותיות ASCII 'a' ל-'z' ממופות ל-'A' ל-'Z', אך אותיות שאינן ASCII אינן משתנות.
    ///
    /// כדי להשתמש באותיות רישיות באותיות גדולות, השתמש ב-[`make_ascii_uppercase()`].
    ///
    /// כדי להשתמש בתווים גדולים של ASCII בנוסף לתווים שאינם ASCII, השתמש ב-[`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// יוצר עותק של הערך בשווי המקביל של ASCII.
    ///
    /// אותיות ASCII 'A' ל-'Z' ממופות ל-'a' ל-'z', אך אותיות שאינן ASCII אינן משתנות.
    ///
    /// כדי להקטין את הערך במקום, השתמש ב-[`make_ascii_lowercase()`].
    ///
    /// כדי להשתמש בתווי ASCII באותיות קטנות בנוסף לתווים שאינם ASCII, השתמש ב-[`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// בודק ששני ערכים הם התאמה ללא רישיות של ASCII.
    ///
    /// שווה ערך ל-`to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// ממיר סוג זה למקבילה המקדימה של ASCII באותה מקום.
    ///
    /// אותיות ASCII 'a' ל-'z' ממופות ל-'A' ל-'Z', אך אותיות שאינן ASCII אינן משתנות.
    ///
    /// כדי להחזיר ערך רישום חדש ללא שינוי בערך הקיים, השתמש ב-[`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// ממיר סוג זה למקבילה הקטנה של ה-ASCII במקום.
    ///
    /// אותיות ASCII 'A' ל-'Z' ממופות ל-'a' ל-'z', אך אותיות שאינן ASCII אינן משתנות.
    ///
    /// כדי להחזיר ערך חדש נמוך יותר מבלי לשנות את הערך הקיים, השתמש ב-[`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// בודק אם הערך הוא תו אלפביתי ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', או
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// בודק אם הערך הוא תו גדול של ASCII:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// בודק אם הערך הוא תו קטן של ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// בודק אם הערך הוא תו אלפא-נומרי ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', או
    /// - U + 0061 'a' ..=U + 007A 'z', או
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// בודק אם הערך הוא ספרה עשרונית של ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// בודק אם הערך הוא ספרת הקסדצימלי של ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', או
    /// - U + 0041 'A' ..=U + 0046 'F', או
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// בודק אם הערך הוא תו פיסוק ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, או
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, או
    /// - U + 005B ..=U + 0060 "[\] ^ _" ``, או
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// בודק אם הערך הוא תו גרפי של ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// בודק אם הערך הוא תו ASCII לבן:
    /// U + 0020 SPACE, U + 0009 TAB HORIZONTAL, U + 000A FEED FEED, U + 000C FORM FEED, או U + 000D CARARAGE RETURN.
    ///
    /// Rust משתמש ב-[definition of ASCII whitespace][infra-aw] של WhatWG Infra Standard.ישנן מספר הגדרות אחרות בשימוש נרחב.
    /// לדוגמא, [the POSIX locale][pct] כולל U + 000B TAB VERTICAL כמו גם את כל התווים שלעיל, אך-מאותה מפרט ממש-[כלל ברירת המחדל עבור "field splitting" ב-Bourne shell][bfs] שוקל *רק* SPACE, HORIZONTAL TAB ו-הזנת קו כמרחב לבן.
    ///
    ///
    /// אם אתה כותב תוכנית שתעבד פורמט קובץ קיים, בדוק מהי הגדרת התבנית של מרחב לבן לפני שתשתמש בפונקציה זו.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// בודק אם הערך הוא תו בקרה ASCII:
    /// U + 0000 NUL ..=מפריד יחידת U + 001F, או מחיקת U + 007F.
    /// שים לב שרוב תווי ה-ASCII הרווחים הלבנים הם תווי שליטה, אך SPACE אינו.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// מקודד ערך u32 גולמי כ-UTF-8 למאגר בתים המסופק, ואז מחזיר את תת המשנה של המאגר שמכיל את התו המקודד.
///
///
/// בניגוד ל-`char::encode_utf8`, שיטה זו מטפלת גם בנקודות קוד בתחום הפונדקאות.
/// (יצירת `char` בתחום הפונדקאות היא UB.) התוצאה תקפה [generalized UTF-8] אך אינה תקפה UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics אם המאגר אינו גדול מספיק.
/// חיץ באורך ארבע גדול מספיק כדי לקודד כל `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// מקודד ערך u32 גולמי כ-UTF-16 למאגר ה-`u16` שסופק, ואז מחזיר את תת החלק של המאגר שמכיל את התו המקודד.
///
///
/// בניגוד ל-`char::encode_utf16`, שיטה זו מטפלת גם בנקודות קוד בתחום הפונדקאות.
/// (יצירת `char` בתחום הפונדקאות היא UB).
///
/// # Panics
///
/// Panics אם המאגר אינו גדול מספיק.
/// חיץ באורך 2 גדול מספיק כדי לקודד כל `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // בטיחות: כל זרוע בודקת אם יש מספיק סיביות לכתוב
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // ה-BMP נופל
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // מטוסים משלימים פורצים לפונדקאים.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}