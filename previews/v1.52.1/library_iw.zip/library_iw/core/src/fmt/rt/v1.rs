//! זהו מודול פנימי המשמש את ifmt!זמן ריצה.מבנים אלה נפלטים למערכים סטטיים כדי להרכיב מראש מחרוזות פורמט.
//!
//! הגדרות אלה דומות למקבילות ה-`ct` שלהן, אך נבדלות בכך שניתן להקצות אותן סטטית ומותאמות מעט לזמן הריצה.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// יישור אפשרי שניתן לבקש במסגרת הוראת עיצוב.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// אינדיקציה כי יש ליישר את התוכן.
    Left,
    /// אינדיקציה כי יש ליישר את התוכן לימין.
    Right,
    /// אינדיקציה כי התוכן צריך להיות מותאם למרכז.
    Center,
    /// לא התבקש יישור.
    Unknown,
}

/// משמש על ידי מפרט [width](https://doc.rust-lang.org/std/fmt/#width) ו-[precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// מצוין עם מספר מילולי, מאחסן את הערך
    Is(usize),
    /// מוגדר באמצעות תחביר `$` ו-`*`, מאחסן את האינדקס ב-`args`
    Param(usize),
    /// לא מוגדר
    Implied,
}