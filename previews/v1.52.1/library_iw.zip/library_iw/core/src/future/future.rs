#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future מייצג חישוב אסינכרוני.
///
/// future הוא ערך שאולי עדיין לא סיים את המחשוב.
/// סוג זה של "asynchronous value" מאפשר לשרשור להמשיך ולעשות עבודה שימושית בזמן שהוא ממתין שהערך יהיה זמין.
///
///
/// # שיטת `poll`
///
/// שיטת הליבה של future, `poll`,*מנסה* לפתור את future לערך סופי.
/// שיטה זו אינה חוסמת אם הערך אינו מוכן.
/// במקום זאת, המשימה הנוכחית מתוכננת להתעורר כשאפשר להתקדם עוד על ידי 'שוב'.
/// ה-`context` שהועבר לשיטת `poll` יכול לספק [`Waker`], המהווה ידית להעיר את המשימה הנוכחית.
///
/// בעת שימוש ב-future, בדרך כלל לא תתקשר ישירות ל-`poll`, אלא במקום זאת ל-`.await` לערך.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// סוג הערך המיוצר בסיום.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// נסה לפתור את ה-future לערך סופי, תוך רישום המשימה הנוכחית להתעוררות אם הערך עדיין אינו זמין.
    ///
    /// # ערך החזרה
    ///
    /// פונקציה זו מחזירה:
    ///
    /// - [`Poll::Pending`] אם future עדיין לא מוכן
    /// - [`Poll::Ready(val)`] עם התוצאה `val` של future זה אם הוא הסתיים בהצלחה.
    ///
    /// לאחר סיום future, לקוחות לא צריכים `poll` אותו שוב.
    ///
    /// כאשר future עדיין לא מוכן, `poll` מחזיר את `Poll::Pending` ומאחסן שיבוט של ה-[`Waker`] שהועתק מה-[`Context`] הנוכחי.
    /// [`Waker`] זה מתעורר לאחר ש-future יכול להתקדם.
    /// לדוגמה, future שמחכה לשקע שיהיה קריא יתקשר ל-`.clone()` ב-[`Waker`] ויאחסן אותו.
    /// כאשר מגיע אות אחר למקום המציין כי השקע קריא, [`Waker::wake`] נקרא ומשימת השקע future מתעוררת.
    /// לאחר שהמשימה הושמעה, עליה לנסות `poll` שוב את future, אשר עשוי לייצר ערך סופי או לא.
    ///
    /// שים לב שבשיחות מרובות ל-`poll`, יש לתזמן רק את ה-[`Waker`] מה-[`Context`] שעבר לשיחה האחרונה לקבל התעוררות.
    ///
    /// # מאפייני זמן ריצה
    ///
    /// Futures לבדם *אינרטי*;הם חייבים להיות "אקטיביים" בסקר כדי להתקדם, כלומר בכל פעם שהמשימה הנוכחית מתעוררת, היא צריכה לפעול מחדש "לנקות" בהמתנה ל-futures שעדיין יש לה עניין.
    ///
    /// הפונקציה `poll` אינה נקראת שוב ושוב בלולאה הדוקה-במקום זאת, יש לקרוא לה רק כאשר ה-future מציין שהיא מוכנה להתקדם (על ידי קריאה ל-`wake()`).
    /// אם אתה מכיר את הסקולות של `poll(2)` או `select(2)` ב-Unix, כדאי לציין ש-futures בדרך כלל *לא* סובלים מאותן בעיות של "all wakeups must poll all events";הם דומים יותר ל-`epoll(4)`.
    ///
    /// יישום של `poll` צריך לשאוף לחזור במהירות, ולא צריך לחסום אותו.חזרה במהירות מונעת סתימה מיותרת של חוטים או לולאות אירועים.
    /// אם ידוע מבעוד מועד כי שיחה ל-`poll` עשויה להסתיים זמן מה, יש להוריד את העבודה לבריכת אשכולות (או משהו דומה) בכדי להבטיח ש-`poll` יוכל לחזור במהירות.
    ///
    /// # Panics
    ///
    /// ברגע ש-future הושלם (הוחזר `Ready` מ-`poll`), קריאה לשיטת `poll` שוב עשויה panic, לחסום לנצח או לגרום לבעיות מסוג אחר;ה-`Future` trait אינו מציב דרישות לגבי השפעות שיחה כזו.
    /// עם זאת, מכיוון ששיטת `poll` אינה מסומנת כ-`unsafe`, חלים הכללים הרגילים של Rust: שיחות אסור לעולם לגרום להתנהגות לא מוגדרת (פגיעה בזיכרון, שימוש לא נכון בפונקציות `unsafe` וכדומה), ללא קשר למצב ה-future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}