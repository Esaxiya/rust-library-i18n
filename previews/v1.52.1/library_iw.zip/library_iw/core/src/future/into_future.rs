use crate::future::Future;

/// המרה ל-`Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// הפלט ש-future יפיק עם השלמתו.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// לאיזה סוג של future אנחנו הופכים את זה?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// יוצר future מערך.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}