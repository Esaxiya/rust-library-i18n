use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// עטיפה למניעת מהדר להתקשר אוטומטית להרס של T.
/// עטיפה זו היא 0 עלות.
///
/// `ManuallyDrop<T>` כפוף לאופטימיזציות פריסה זהות לזו `T`.
/// כתוצאה מכך, אין לזה *כל השפעה* על ההנחות שמניח המהדר לגבי תוכנו.
/// לדוגמה, אתחול `ManuallyDrop<&mut T>` עם [`mem::zeroed`] הוא התנהגות לא מוגדרת.
/// אם אתה צריך לטפל בנתונים לא מאוחדים, השתמש במקום זאת ב-[`MaybeUninit<T>`].
///
/// שים לב שגישה לערך בתוך `ManuallyDrop<T>` בטוחה.
/// פירוש הדבר שאסור לחשוף `ManuallyDrop<T>` שתוכנו הושמט באמצעות ממשק API לציבור.
/// בהתאמה, `ManuallyDrop::drop` אינו בטוח.
///
/// # `ManuallyDrop` ולהוריד סדר.
///
/// ל-Rust יש [drop order] ערכים מוגדר היטב.
/// כדי לוודא ששדות או תושבים מקומיים יושמטו בסדר מסוים, סדר מחדש את ההצהרות כך שסדר הנפילה הגלום הוא הנכון.
///
/// ניתן להשתמש ב-`ManuallyDrop` כדי לשלוט בסדר הטיפה, אך הדבר דורש קוד לא בטוח וקשה לעשות זאת נכון בנוכחות פריקה.
///
///
/// לדוגמה, אם ברצונך לוודא ששדה ספציפי ירד אחרי האחרים, הפוך אותו לשדה האחרון של מבנה:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` יושמט לאחר `children`.
///     // Rust מבטיח כי שדות יושמטו לפי סדר ההכרזה.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// עטוף ערך שיושמט ידנית.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // אתה עדיין יכול לעבוד בבטחה על הערך
    /// assert_eq!(*x, "Hello");
    /// // אבל `Drop` לא יופעל כאן
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// מחלץ את הערך ממיכל `ManuallyDrop`.
    ///
    /// זה מאפשר להוריד את הערך שוב.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // זה מפיל את ה-`Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// מוציא את הערך ממכולה `ManuallyDrop<T>`.
    ///
    /// שיטה זו מיועדת בעיקר להעברת ערכים בטיפה.
    /// במקום להשתמש ב-[`ManuallyDrop::drop`] כדי להוריד את הערך באופן ידני, אתה יכול להשתמש בשיטה זו כדי לקחת את הערך ולהשתמש בו ככל שתרצה.
    ///
    /// במידת האפשר, עדיף להשתמש ב-[`into_inner`][`ManuallyDrop::into_inner`] במקום זאת, מה שמונע שכפול תוכן ה-`ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// פונקציה זו מעבירה באופן סמנטי את הערך הכלול מבלי למנוע שימוש נוסף, ומשאירה את מצב המיכל הזה ללא שינוי.
    /// באחריותך לוודא שלא נעשה שימוש חוזר ב-`ManuallyDrop` זה.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // בטיחות: אנו קוראים מתוך הפניה, וזה מובטח
        // להיות תקף לקריאות.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// באופן ידני מוריד את הערך הכלול.זה שווה ערך להתקשרות ל-[`ptr::drop_in_place`] עם מצביע לערך הכלול.
    /// ככזה, אלא אם כן הערך הכלול הוא מבנה ארוז, המשמיד ייקרא במקום מבלי להזיז את הערך, וכך ניתן להשתמש בו להפלת נתונים [pinned] בבטחה.
    ///
    /// אם יש לך בעלות על הערך, אתה יכול להשתמש ב-[`ManuallyDrop::into_inner`] במקום זאת.
    ///
    /// # Safety
    ///
    /// פונקציה זו מפעילה את הורס הערך הכלול.
    /// מלבד שינויים שביצע המשחית עצמו, הזיכרון נותר ללא שינוי, ומבחינת המהדר עדיין מחזיק בתבנית סיבית שתקפה לסוג `T`.
    ///
    ///
    /// עם זאת, אין לחשוף ערך "zombie" זה לקוד בטוח, ואין לקרוא לפונקציה זו יותר מפעם אחת.
    /// שימוש בערך לאחר ירידתו, או ירידה בערך מספר פעמים, עלול לגרום להתנהגות לא מוגדרת (תלוי מה `drop` עושה).
    /// בדרך כלל זה מונע על ידי מערכת הסוגים, אך על המשתמשים ב-`ManuallyDrop` לעמוד בערבויות אלה ללא סיוע מהמהדר.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // בטיחות: אנו מורידים את הערך אליו מצביע התייחסות ניתנת לשינוי
        // שמובטח שיהיה תקף לכותבים.
        // על המתקשר לוודא ש-`slot` לא ירד שוב.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}