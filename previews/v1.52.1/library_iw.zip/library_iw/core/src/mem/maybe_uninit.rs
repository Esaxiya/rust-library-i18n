use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// סוג עטיפה לבניית מופעים לא מאוחרים של `T`.
///
/// # אתחול קבוע
///
/// המהדר, באופן כללי, מניח כי משתנה מאותחל כראוי בהתאם לדרישות מסוג המשתנה.לדוגמה, משתנה מסוג הפניה חייב להיות מיושר ולא NULL.
/// מדובר במשתנה שיש לשמור עליו *תמיד*, אפילו בקוד לא בטוח.
/// כתוצאה מכך, אפס אתחול של משתנה מסוג התייחסות גורם ל-[undefined behavior][ub] מיידי, לא משנה אם הפניה זו מתרגלת אי פעם לגישה לזיכרון:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // התנהגות לא מוגדרת!⚠️
/// // הקוד המקביל ל-`MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // התנהגות לא מוגדרת!⚠️
/// ```
///
/// זה מנוצל על ידי המהדר לאופטימיזציות שונות, כגון ביטול בדיקות זמן ריצה ומיטוב פריסת `enum`.
///
/// באופן דומה, זיכרון לא מאוחד לחלוטין עשוי להכיל תוכן כלשהו, בעוד ש-`bool` חייב להיות תמיד `true` או `false`.לפיכך, יצירת `bool` שאינה מאוחדת היא התנהגות לא מוגדרת:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // התנהגות לא מוגדרת!⚠️
/// // הקוד המקביל ל-`MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // התנהגות לא מוגדרת!⚠️
/// ```
///
/// יתר על כן, זיכרון לא מאוזן מיוחד בכך שאין לו ערך קבוע ("fixed" שמשמעותו "it won't change without being written to").קריאה של אותו בית שאינו מאושר מספר פעמים יכולה לתת תוצאות שונות.
/// זה הופך את ההתנהגות הלא מוגדרת לכך שיש נתונים לא מורשים במשתנה, גם אם למשתנה זה יש מספר שלם, שאחרת יכול להכיל כל תבנית סיבית *קבועה*:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // התנהגות לא מוגדרת!⚠️
/// // הקוד המקביל ל-`MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // התנהגות לא מוגדרת!⚠️
/// ```
/// (שים לב שהכללים סביב מספרים שלמים לא מאוחדים עדיין לא סופיים, אך עד שהם כן, רצוי להימנע מהם.)
///
/// נוסף על כך, זכור כי ברוב הסוגים יש זרמים נוספים מעבר לכך שהם רק נחשבים לאתחילים ברמת הסוג.
/// לדוגמא, [`Vec<T>`] מאותחל ל-'1' נחשב כמאותחל (תחת היישום הנוכחי; זה אינו מהווה ערובה יציבה) מכיוון שהדרישה היחידה שהמהדר יודע עליה היא שמצביע הנתונים חייב להיות ללא אפס.
/// יצירת `Vec<T>` כזה אינה גורמת להתנהגות *לא* מוגדרת מיידית, אלא תגרום להתנהגות לא מוגדרת עם הפעולות הבטוחות ביותר (כולל הטלתה).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` משמש לאפשר לקוד לא בטוח להתמודד עם נתונים שאינם מאוחדים.
/// זהו אות למהדר המציין כי הנתונים כאן עשויים *לא* להיות מאותחלים:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // צור סימוכין שאינו מאושר במפורש.
/// // המהדר יודע שנתונים בתוך `MaybeUninit<T>` עשויים להיות לא חוקיים, ולכן זה לא UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // הגדר אותו לערך חוקי.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // חלץ את הנתונים מאותחל-זה מותר רק *לאחר* אתחול נכון של `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// המהדר יודע שלא לבצע הנחות או אופטימיזציות שגויות בקוד זה.
///
/// אתה יכול לחשוב על `MaybeUninit<T>` כאילו הוא קצת כמו `Option<T>` אך ללא מעקב אחר זמן הריצה וללא כל בדיקות הבטיחות.
///
/// ## out-pointers
///
/// אתה יכול להשתמש ב-`MaybeUninit<T>` כדי להטמיע את "out-pointers": במקום להחזיר נתונים מפונקציה, העבר אותו מצביע לזיכרון (uninitialized) כלשהו כדי להכניס את התוצאה אליו.
/// זה יכול להיות שימושי כאשר חשוב למתקשר לשלוט על אופן הקצאת הזיכרון בו נשמרת התוצאה, ותרצה להימנע ממהלכים מיותרים.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` לא מוריד את התוכן הישן, וזה חשוב.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // עכשיו אנחנו יודעים ש-`v` מאותחל!זה גם מוודא שה-vector יירד כראוי.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## אתחול מערך אלמנט אחר אלמנט
///
/// `MaybeUninit<T>` ניתן להשתמש בו לאתחול של מערך גדול של אלמנט אחר אלמנט:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // צור מערך `MaybeUninit` לא מאומת.
///     // ה-`assume_init` בטוח מכיוון שהסוג שאנחנו טוענים שאותחלנו כאן הוא חבורה של 'אולי יוניניט', שאינם דורשים אתחול.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // הטלת `MaybeUninit` לא עושה כלום.
///     // לפיכך שימוש בהקצאת מצביע גולמי במקום `ptr::write` אינו גורם להורדת הערך הישן שאינו ממוגן.
/////
///     // כמו כן אם יש panic במהלך הלולאה הזו, יש לנו דליפת זיכרון, אך אין בעיית בטיחות זיכרון.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // הכל מאותחל.
///     // העבר את המערך לסוג האתחול.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// אתה יכול גם לעבוד עם מערכים מאותחלים חלקית, אשר ניתן למצוא במבני נתונים ברמה נמוכה.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // צור מערך `MaybeUninit` לא מאומת.
/// // ה-`assume_init` בטוח מכיוון שהסוג שאנחנו טוענים שאותחלנו כאן הוא חבורה של 'אולי יוניניט', שאינם דורשים אתחול.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // ספרו את מספר האלמנטים שהקצנו.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // עבור כל פריט במערך, שחרר אם הקצנו אותו.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## אתחול מבנה שדה אחר שדה
///
/// אתה יכול להשתמש ב-`MaybeUninit<T>` ובמקרו [`std::ptr::addr_of_mut`] כדי לאתחל שורות לפי שדה:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // אתחול שדה `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // אתחול שדה `list` אם יש כאן panic, `String` בשדה `name` דולף.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // כל השדות מאותחלים, לכן אנו מתקשרים ל-`assume_init` כדי לקבל Foo מאותחל.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` מובטח שיהיה באותו גודל, יישור ו-ABI כמו `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// עם זאת זכרו שסוג *המכיל*`MaybeUninit<T>` אינו בהכרח אותה פריסה;Rust אינו מבטיח באופן כללי כי השדות של `Foo<T>` הם בסדר זהה לזה של `Foo<U>`, גם אם ל-`T` ו-`U` יש אותו גודל ויישור.
///
/// יתר על כן מכיוון שכל ערך סיביות תקף ל-`MaybeUninit<T>`, המהדר אינו יכול ליישם אופטימיזציות non-zero/niche-filling, מה שעלול לגרום לגודל גדול יותר:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// אם `T` בטוח ל-FFI, כך גם `MaybeUninit<T>`.
///
/// בעוד `MaybeUninit` הוא `#[repr(transparent)]` (המציין שהוא מבטיח את אותו גודל, יישור ו-ABI כמו `T`), זה לא *משנה* אף אחד מהאזהרות הקודמות.
/// `Option<T>` ו-`Option<MaybeUninit<T>>` עדיין עשויים להיות בגדלים שונים, וסוגים המכילים שדה מסוג `T` עשויים להיות מונחים (וגדלים) באופן שונה מאשר אם שדה זה היה `MaybeUninit<T>`.
/// `MaybeUninit` הוא סוג איחוד, ו-`#[repr(transparent)]` באיגודים אינו יציב (ראה [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// לאורך זמן, הערבויות המדויקות של `#[repr(transparent)]` לאיגודים עשויים להתפתח, ו-`MaybeUninit` עשויים להישאר `#[repr(transparent)]`.
/// עם זאת, `MaybeUninit<T>`*תמיד* יבטיח שיש לו אותו גודל, יישור ו-ABI כמו `T`;פשוט האופן שבו `MaybeUninit` מיישם את הערבות עשויה להתפתח.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// פריט לאנג כדי שנוכל לעטוף בו סוגים אחרים.זה שימושי עבור גנרטורים.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // לא מתקשרים ל-`T::clone()`, אנחנו לא יכולים לדעת אם אנחנו מאותתים מספיק בשביל זה.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// יוצר `MaybeUninit<T>` חדש מאותחל עם הערך הנתון.
    /// זה בטוח להתקשר [`assume_init`] על ערך ההחזרה של פונקציה זו.
    ///
    /// שים לב שהטלת `MaybeUninit<T>` לעולם לא תתקשר לקוד הצניחה של 'T'.
    /// באחריותך לוודא ש-`T` יורד אם הוא יותחל.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// יוצר `MaybeUninit<T>` חדש במצב שאינו מאושר.
    ///
    /// שים לב שהטלת `MaybeUninit<T>` לעולם לא תתקשר לקוד הצניחה של 'T'.
    /// באחריותך לוודא ש-`T` יורד אם הוא יותחל.
    ///
    /// ראה [type-level documentation][MaybeUninit] לדוגמאות.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// צור מערך חדש של פריטי `MaybeUninit<T>`, במצב שאינו מאושר.
    ///
    /// Note: בגרסת future Rust שיטה זו עשויה להיות מיותרת כאשר התחביר המילולי של המערך מאפשר [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// הדוגמה הבאה יכולה להשתמש ב-`let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// מחזיר פרוסת נתונים (אולי קטנה יותר) שנקראה בפועל
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // בטיחות: `[MaybeUninit<_>; LEN]` לא מאוחסן תקף.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// יוצר `MaybeUninit<T>` חדש במצב שאינו מאושר, כשהזיכרון מתמלא בתים `0`.זה תלוי ב-`T` אם זה כבר גורם לאתחול נכון.
    ///
    /// לדוגמה, `MaybeUninit<usize>::zeroed()` מאותחל, אך `MaybeUninit<&'static i32>::zeroed()` אינו בגלל שההפניות לא יכולות להיות ריקות.
    ///
    /// שים לב שהטלת `MaybeUninit<T>` לעולם לא תתקשר לקוד הצניחה של 'T'.
    /// באחריותך לוודא ש-`T` יורד אם הוא יותחל.
    ///
    /// # Example
    ///
    /// שימוש נכון בפונקציה זו: אתחול מבנה עם אפס, כאשר כל שדות המבנה יכולים להחזיק את תבנית הסיביות 0 כערך חוקי.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *שגוי* שימוש בפונקציה זו: קריאה ל-`x.zeroed().assume_init()` כאשר `0` אינו תבנית ביט חוקית לסוג:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // בתוך זוג אנו יוצרים `NotZero` שאין בו מפלה תקף.
    /// // זו התנהגות לא מוגדרת.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // בטיחות: נקודות `u.as_mut_ptr()` לזיכרון שהוקצה.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// מגדיר את הערך של ה-`MaybeUninit<T>`.
    /// זה מחליף כל ערך קודם מבלי להפיל אותו, אז היזהר לא להשתמש בו פעמיים אלא אם כן ברצונך לדלג על הפעלת המשמיד.
    ///
    /// לנוחיותכם, זה גם מחזיר התייחסות ניתנת לשינוי לתוכן (המאתחל כעת בבטחה) של `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // בטיחות: רק אתחול ערך זה.
        unsafe { self.assume_init_mut() }
    }

    /// מקבל מצביע לערך הכלול.
    /// קריאה ממצביע זה או הפיכתו להפניה אינה התנהגות מוגדרת אלא אם כן אתחול ה-`MaybeUninit<T>`.
    /// כתיבה לזיכרון שהמצביע הזה (non-transitively) מצביע עליו היא התנהגות לא מוגדרת (למעט בתוך `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// שימוש נכון בשיטה זו:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // צור הפניה ל-`MaybeUninit<T>`.זה בסדר כי אתחלנו את זה.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// שימוש שגוי בשיטה זו:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // יצרנו הפניה ל-vector לא מאוחסן!זו התנהגות לא מוגדרת.⚠️
    /// ```
    ///
    /// (שים לב שהכללים סביב הפניות לנתונים לא מאומתים עדיין לא סופיים, אך עד שהם יהיו, רצוי להימנע מהם.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` ו-`ManuallyDrop` שניהם `repr(transparent)` כדי שנוכל להטיל את המצביע.
        self as *const _ as *const T
    }

    /// מקבל מצביע משתנה לערך הכלול.
    /// קריאה ממצביע זה או הפיכתו להפניה אינה התנהגות מוגדרת אלא אם כן אתחול ה-`MaybeUninit<T>`.
    ///
    /// # Examples
    ///
    /// שימוש נכון בשיטה זו:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // צור הפניה ל-`MaybeUninit<Vec<u32>>`.
    /// // זה בסדר כי אתחלנו את זה.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// שימוש שגוי בשיטה זו:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // יצרנו הפניה ל-vector לא מאוחסן!זו התנהגות לא מוגדרת.⚠️
    /// ```
    ///
    /// (שים לב שהכללים סביב הפניות לנתונים לא מאומתים עדיין לא סופיים, אך עד שהם יהיו, רצוי להימנע מהם.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` ו-`ManuallyDrop` שניהם `repr(transparent)` כדי שנוכל להטיל את המצביע.
        self as *mut _ as *mut T
    }

    /// מחלץ את הערך ממיכל `MaybeUninit<T>`.זוהי דרך נהדרת להבטיח שהנתונים יישמטו מכיוון ש-`T` שנוצר כפוף לטיפול הרגיל בטיפות.
    ///
    /// # Safety
    ///
    /// על המתקשר להבטיח שה-`MaybeUninit<T>` באמת נמצא במצב מאותחל.קריאה לכך כאשר התוכן עדיין לא מאותחל לחלוטין גורמת להתנהגות בלתי מוגדרת מיידית.
    /// ה-[type-level documentation][inv] מכיל מידע נוסף אודות משתנה אתחול זה.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// נוסף על כך, זכור כי ברוב הסוגים יש זרמים נוספים מעבר לכך שהם רק נחשבים לאתחילים ברמת הסוג.
    /// לדוגמא, [`Vec<T>`] מאותחל ל-'1' נחשב כמאותחל (תחת היישום הנוכחי; זה אינו מהווה ערובה יציבה) מכיוון שהדרישה היחידה שהמהדר יודע עליה היא שמצביע הנתונים חייב להיות ללא אפס.
    ///
    /// יצירת `Vec<T>` כזה אינה גורמת להתנהגות *לא* מוגדרת מיידית, אלא תגרום להתנהגות לא מוגדרת עם הפעולות הבטוחות ביותר (כולל הטלתה).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// שימוש נכון בשיטה זו:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// שימוש שגוי בשיטה זו:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` עדיין לא אותחל, ולכן השורה האחרונה הזו גרמה להתנהגות לא מוגדרת.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // בטיחות: על המתקשר להבטיח כי אתחול ה-`self`.
        // זה גם אומר ש-`self` חייב להיות גרסת `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// קורא את הערך ממיכל `MaybeUninit<T>`.ה-`T` המתקבל כפוף לטיפול הרגיל בטיפות.
    ///
    /// במידת האפשר, עדיף להשתמש ב-[`assume_init`] במקום זאת, מה שמונע שכפול תוכן ה-`MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// על המתקשר להבטיח שה-`MaybeUninit<T>` באמת נמצא במצב מאותחל.קריאה זו כאשר התוכן עדיין לא מאותחל לחלוטין גורמת להתנהגות לא מוגדרת.
    /// ה-[type-level documentation][inv] מכיל מידע נוסף אודות משתנה אתחול זה.
    ///
    /// יתר על כן, זה משאיר עותק של אותם נתונים מאחור ב-`MaybeUninit<T>`.
    /// בעת שימוש במספר עותקים של הנתונים (על ידי התקשרות ל-`assume_init_read` מספר פעמים, או תחילה להתקשר ל-`assume_init_read` ואז ל-[`assume_init`]), באחריותך לוודא כי הנתונים אכן עשויים להיות משוכפלים.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// שימוש נכון בשיטה זו:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` הוא `Copy`, לכן אנו עשויים לקרוא מספר פעמים.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // שכפול ערך `None` הוא בסדר, לכן אנו עשויים לקרוא מספר פעמים.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// שימוש שגוי בשיטה זו:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // כעת יצרנו שני עותקים של אותו vector, מה שמוביל לחינם כפול ⚠️ כאשר שניהם יורדים!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // בטיחות: על המתקשר להבטיח כי אתחול ה-`self`.
        // קריאה מ-`self.as_ptr()` בטוחה מאחר ויש לאתחל את `self`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// מוריד את הערך הכלול במקום.
    ///
    /// אם יש לך בעלות על ה-`MaybeUninit`, תוכל להשתמש ב-[`assume_init`] במקום זאת.
    ///
    /// # Safety
    ///
    /// על המתקשר להבטיח שה-`MaybeUninit<T>` באמת נמצא במצב מאותחל.קריאה זו כאשר התוכן עדיין לא מאותחל לחלוטין גורמת להתנהגות לא מוגדרת.
    ///
    /// נוסף על כך, על כל הזרמים הנוספים מהסוג `T` להיות מרוצים, שכן יישום ה-`Drop` של `T` (או חבריו) עשוי להסתמך על כך.
    /// לדוגמא, [`Vec<T>`] מאותחל ל-'1' נחשב כמאותחל (תחת היישום הנוכחי; זה אינו מהווה ערובה יציבה) מכיוון שהדרישה היחידה שהמהדר יודע עליה היא שמצביע הנתונים חייב להיות ללא אפס.
    ///
    /// הטלת `Vec<T>` שכזו עם זאת תגרום להתנהגות לא מוגדרת.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // בטיחות: על המתקשר להבטיח ש-`self` מאותחל ו
        // מספק את כל משתמשי ה-`T`.
        // הורדת הערך במקום בטוחה אם זה המקרה.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// מקבל התייחסות משותפת לערך הכלול.
    ///
    /// זה יכול להיות שימושי כשאנחנו רוצים לגשת ל-`MaybeUninit` שעברו אתחול אך אין לנו בעלות על `MaybeUninit` (מה שמונע את השימוש ב-`.assume_init()`).
    ///
    /// # Safety
    ///
    /// קריאה זו כאשר התוכן עדיין לא מאותחל לחלוטין גורמת להתנהגות לא מוגדרת: על המתקשר להבטיח שה-`MaybeUninit<T>` באמת נמצא במצב מאותחל.
    ///
    ///
    /// # Examples
    ///
    /// ### שימוש נכון בשיטה זו:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // אתחל את `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // עכשיו, כידוע ש-`MaybeUninit<_>` שלנו מאותחל, זה בסדר ליצור התייחסות משותפת אליו:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // בטיחות: `x` כבר מאותחל.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### שימושים *שגויים* בשיטה זו:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // יצרנו הפניה ל-vector לא מאוחסן!זו התנהגות לא מוגדרת.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // אתחל את ה-`MaybeUninit` באמצעות `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // התייחסות ל-`Cell<bool>` לא מאומת: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // בטיחות: על המתקשר להבטיח כי אתחול ה-`self`.
        // זה גם אומר ש-`self` חייב להיות גרסת `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// מקבל הפניה (unique) משתנה לערך הכלול.
    ///
    /// זה יכול להיות שימושי כשאנחנו רוצים לגשת ל-`MaybeUninit` שעברו אתחול אך אין לנו בעלות על `MaybeUninit` (מה שמונע את השימוש ב-`.assume_init()`).
    ///
    /// # Safety
    ///
    /// קריאה זו כאשר התוכן עדיין לא מאותחל לחלוטין גורמת להתנהגות לא מוגדרת: על המתקשר להבטיח שה-`MaybeUninit<T>` באמת נמצא במצב מאותחל.
    /// לדוגמה, לא ניתן להשתמש ב-`.assume_init_mut()` לאתחול `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### שימוש נכון בשיטה זו:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// מאותחל * את כל הבתים של מאגר הקלט.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // אתחל את `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // עכשיו אנחנו יודעים ש-`buf` אותחל, אז נוכל `.assume_init()`.
    /// // עם זאת, שימוש ב-`.assume_init()` עשוי להפעיל `memcpy` של 2048 בתים.
    /// // כדי לקבוע שהמאגר שלנו אותחל מבלי להעתיק אותו, אנו משדרגים את ה-`&mut MaybeUninit<[u8; 2048]>` ל-`&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // בטיחות: `buf` אותחל.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // כעת אנו יכולים להשתמש ב-`buf` כנתח רגיל:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### שימושים *שגויים* בשיטה זו:
    ///
    /// אינך יכול להשתמש ב-`.assume_init_mut()` כדי לאתחל ערך:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // יצרנו הפניה ל-(mutable) ל-`bool` שאינו מאושר!
    ///     // זו התנהגות לא מוגדרת.⚠️
    /// }
    /// ```
    ///
    /// לדוגמה, אתה לא יכול [`Read`] למאגר לא מאוחד:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) התייחסות לזיכרון לא מאוחד!
    ///                             // זו התנהגות לא מוגדרת.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// אתה גם לא יכול להשתמש בגישה ישירה של השדה כדי לבצע אתחול הדרגתי לפי שדה:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) התייחסות לזיכרון לא מאוחד!
    ///                  // זו התנהגות לא מוגדרת.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) התייחסות לזיכרון לא מאוחד!
    ///                  // זו התנהגות לא מוגדרת.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): כרגע אנו מסתמכים על כך שהאמור לעיל אינו נכון, כלומר יש לנו הפניות לנתונים לא מאוחדים (למשל ב-`libcore/fmt/float.rs`).
    // עלינו לקבל החלטה סופית לגבי הכללים לפני התייצבות.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // בטיחות: על המתקשר להבטיח כי אתחול ה-`self`.
        // זה גם אומר ש-`self` חייב להיות גרסת `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// מחלץ את הערכים ממערך של מיכלי `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// על המתקשר להבטיח שכל האלמנטים במערך נמצאים במצב מאותחל.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // בטיחות: עכשיו בטוח כשאותחלנו את כל האלמנטים
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * המתקשר מבטיח כי כל מרכיבי המערך מאותחלים
        // * `MaybeUninit<T>` ו-T מובטח שאותה פריסה תהיה
        // * אולי יונינט לא צונח, ולכן אין כפל-חופשי וכך ההמרה בטוחה
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// בהנחה שכל האלמנטים מאותחלים, קבל פרוסה אליהם.
    ///
    /// # Safety
    ///
    /// על המתקשר להבטיח שאלמנטים `MaybeUninit<T>` אכן נמצאים במצב מאותחל.
    ///
    /// קריאה זו כאשר התוכן עדיין לא מאותחל לחלוטין גורמת להתנהגות לא מוגדרת.
    ///
    /// ראה [`assume_init_ref`] לפרטים נוספים ודוגמאות.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // בטיחות: השלכת פרוסה ל-`*const [T]` היא בטוחה שכן המתקשר מבטיח זאת
        // `slice` מאותחל, ו-'MaybeUninit' מובטח שתהיה לו אותה פריסה כמו `T`.
        // המצביע שהתקבל תקף מכיוון שהוא מתייחס לזיכרון שבבעלות `slice` שהוא הפניה ובכך מובטח שהוא תקף לקריאות.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// בהנחה שכל האלמנטים מאותחלים, קבל להם פרוסה ניתנת לשינוי.
    ///
    /// # Safety
    ///
    /// על המתקשר להבטיח שאלמנטים `MaybeUninit<T>` אכן נמצאים במצב מאותחל.
    ///
    /// קריאה זו כאשר התוכן עדיין לא מאותחל לחלוטין גורמת להתנהגות לא מוגדרת.
    ///
    /// ראה [`assume_init_mut`] לפרטים נוספים ודוגמאות.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // בטיחות: דומה להערות בטיחות עבור `slice_get_ref`, אך יש לנו
        // התייחסות משתנה המובטחת גם לתוקף לכתיבה.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// מקבל מצביע לאלמנט הראשון של המערך.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// מקבל מצביע משתנה לאלמנט הראשון של המערך.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// מעתיק את האלמנטים מ-`src` ל-`this`, ומחזיר הפניה ניתנת לשינוי לתכנים המאויישים כעת ב-`this`.
    ///
    /// אם `T` אינו מיישם את `Copy`, השתמש ב-[`write_slice_cloned`]
    ///
    /// זה דומה ל-[`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// פונקציה זו תהיה panic אם לשתי הפרוסות אורכים שונים.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // בטיחות: הרק העתקנו את כל האלמנטים של len ליכולת הפנוי
    /// // רכיבי ה-src.len() הראשונים של ה-vec תקפים כעת.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // בטיחות: &[T] ו-&[אולי יוניניט<T>] בעלי אותה פריסה
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // בטיחות: אלמנטים תקפים הועתקו זה עתה ל-`this` ולכן הוא מנוטרל
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// משכפל את האלמנטים מ-`src` ל-`this`, ומחזיר התייחסות ניתנת לשינוי לתכנים המאויישים כעת ב-`this`.
    /// אלמנטים שכבר לא אושרלו לא יימחקו.
    ///
    /// אם `T` מיישם את `Copy`, השתמש ב-[`write_slice`]
    ///
    /// זה דומה ל-[`slice::clone_from_slice`] אך לא מוריד אלמנטים קיימים.
    ///
    /// # Panics
    ///
    /// פונקציה זו תהיה panic אם לשתי הפרוסות אורכים שונים, או אם היישום של `Clone` panics.
    ///
    /// אם יש panic, האלמנטים המשובטים שכבר יושמטו.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // בטיחות: הרגע שיבטנו את כל האלמנטים של הלן ליכולת הפנוי
    /// // רכיבי ה-src.len() הראשונים של ה-vec תקפים כעת.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // שלא כמו copy_from_slice זה לא קורא clone_from_slice על הנתח זה בגלל ש-`MaybeUninit<T: Clone>` לא מיישם Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // בטיחות: הנתח הגולמי הזה יכיל רק אובייקטים מאותחל
                // לכן מותר להפיל אותו.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: עלינו לחתוך אותם במפורש לאותו אורך
        // לבדיקת גבולות להתבטל, וכלי האופטימיזציה יפיק memcpy למקרים פשוטים (למשל T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // יש צורך בשומר b/c panic עשוי לקרות במהלך שיבוט
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // בטיחות: אלמנטים תקפים נכתבו זה עתה ל-`this` ולכן הוא מנוטרל
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}