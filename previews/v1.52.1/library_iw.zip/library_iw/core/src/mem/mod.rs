//! פונקציות בסיסיות להתמודדות עם זיכרון.
//!
//! מודול זה מכיל פונקציות לשאילתת הגודל והיישור של הסוגים, אתחול וניהול זיכרון.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// לוקח בעלות ו-"forgets" על הערך **מבלי להריץ את משחיתו**.
///
/// כל המשאבים שהערך מנהל, כגון זיכרון ערימה או ידית קובץ, יתעכבו לנצח במצב בלתי נגיש.עם זאת, אין זה מתחייב כי מצביעים לזיכרון זה יישארו תקפים.
///
/// * אם ברצונך לדלוף זיכרון, ראה [`Box::leak`].
/// * אם ברצונך להשיג מצביע גולמי לזיכרון, ראה [`Box::into_raw`].
/// * אם ברצונך להשליך ערך כהלכה, תוך הפעלת הורסו, ראה [`mem::drop`].
///
/// # Safety
///
/// `forget` אינו מסומן כ-`unsafe`, מכיוון שערבויות הבטיחות של Rust אינן כוללות ערבות לכך שההרסנים תמיד יפעלו.
/// לדוגמה, תוכנית יכולה ליצור מחזור הפניה באמצעות [`Rc`][rc], או להתקשר ל-[`process::exit`][exit] כדי לצאת מבלי להריץ הרסנים.
/// לפיכך, התרת `mem::forget` מקוד בטוח איננה משנה באופן מהותי את ערבויות הבטיחות של Rust.
///
/// עם זאת, דליפת משאבים כגון זיכרון או אובייקטים I/O אינה רצויה בדרך כלל.
/// הצורך עולה בכמה מקרי שימוש מיוחדים עבור FFI או קוד לא בטוח, אך גם אז, [`ManuallyDrop`] עדיף בדרך כלל.
///
/// מכיוון ששכחת ערך מותרת, כל קוד `unsafe` שאתה כותב חייב לאפשר אפשרות זו.אינך יכול להחזיר ערך ולצפות שהמתקשר ינהל בהכרח את הורס הערך.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// השימוש הבטוח הקנוני ב-`mem::forget` הוא לעקוף את הורס הערך המיושם על ידי `Drop` trait.לדוגמה, זה ידלוף `File`, כלומר
/// להחזיר את המרחב שנלקח על ידי המשתנה אך לעולם אל תסגור את משאב המערכת הבסיסי:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// זה שימושי כאשר הבעלות על המשאב הבסיסי הועברה בעבר לקוד מחוץ ל-Rust, למשל באמצעות העברת מתאר הקבצים הגולמי לקוד C.
///
/// # הקשר עם `ManuallyDrop`
///
/// בעוד ש-`mem::forget` יכול לשמש גם להעברת בעלות *על זיכרון*, הדבר נוטה לשגיאות.
/// [`ManuallyDrop`] צריך להשתמש במקום.שקול, למשל, את הקוד הזה:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // בנה `String` באמצעות התוכן של `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // לדלוף את `v` מכיוון שזכרונו מנוהל כעת על ידי `s`
/// mem::forget(v);  // שגיאה, v אינו חוקי ואסור להעביר אותו לפונקציה
/// assert_eq!(s, "Az");
/// // `s` נשמט באופן מרומז והזיכרון שלו הוקצה.
/// ```
///
/// ישנן שתי סוגיות בדוגמה שלעיל:
///
/// * אם נוסף קוד נוסף בין בניית ה-`String` לבין ההפעלה של ה-`mem::forget()`, panic בתוכו יגרום לפנוי כפול מכיוון שאותו זיכרון מטופל הן על ידי `v` והן על `s`.
/// * לאחר קריאה ל-`v.as_mut_ptr()` והעברת הבעלות על הנתונים ל-`s`, ערך `v` אינו חוקי.
/// גם כאשר ערך רק מועבר ל-`mem::forget` (שלא יבדוק אותו), ישנם סוגים שיש להם דרישות קפדניות לגבי הערכים שלהם שגורמים להם להיות לא תקפים כאשר הם משתלשלים או שאינם בבעלותם.
/// שימוש בערכים לא חוקיים בכל דרך שהיא, לרבות העברתם לפונקציות או החזרתם מפונקציות, מהווה התנהגות לא מוגדרת ועשוי לשבור את ההנחות שהניח המהדר.
///
/// מעבר ל-`ManuallyDrop` נמנע משתי הבעיות:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // לפני שנפרק את `v` לחלקים הגולמיים שלו, וודאו שהוא לא ייפול!
/////
/// let mut v = ManuallyDrop::new(v);
/// // עכשיו לפרק את `v`.פעולות אלה אינן יכולות panic, ולכן לא יכולה להיות דליפה.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // לבסוף, בנה `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` נשמט באופן מרומז והזיכרון שלו הוקצה.
/// ```
///
/// `ManuallyDrop` מונע באופן חסין כפליים מכיוון שאנו משביתים את ההרס של v לפני שעשינו דבר אחר.
/// `mem::forget()` אינו מאפשר זאת מכיוון שהוא צורך את הטיעון שלו, ומכריח אותנו להתקשר אליו רק לאחר חילוץ כל מה שאנחנו צריכים מ-`v`.
/// גם אם הוצג panic בין בניית `ManuallyDrop` לבניית המחרוזת (מה שלא יכול לקרות בקוד כפי שמוצג), זה יביא לדליפה ולא לחופשי כפול.
/// במילים אחרות, `ManuallyDrop` טועה בצד הדליפה במקום בטעות בצניחה (כפולה).
///
/// כמו כן, `ManuallyDrop` מונע מאיתנו להצטרך ל-"touch" `v` לאחר העברת הבעלות ל-`s`-השלב האחרון של אינטראקציה עם `v` כדי להיפטר ממנו מבלי להריץ את הורסו, נמנע לחלוטין.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// כמו [`forget`], אך מקבל גם ערכים לא גדולים.
///
/// פונקציה זו היא רק שים המיועד להסרה כאשר תכונת `unsized_locals` מתייצבת.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// מחזיר את הגודל של סוג בתים.
///
/// באופן ספציפי יותר, זה הקיזוז בתים בין אלמנטים עוקבים במערך עם אותו פריט כולל ריפוד יישור.
///
/// לפיכך, לכל סוג `T` ולאורך `n`, ל-`[T; n]` יש גודל של `n * size_of::<T>()`.
///
/// באופן כללי, גודלו של סוג אינו יציב על פני אוספים, אך סוגים ספציפיים כגון פרימיטיביים הם.
///
/// הטבלה הבאה מציגה את הגודל לפרימיטיבים.
///
/// סוג |מידה של: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// יתר על כן, `usize` ו-`isize` הם בעלי אותו גודל.
///
/// הסוגים `*const T`, `&T`, `Box<T>`, `Option<&T>` ו-`Option<Box<T>>` הם בגודל זהה.
/// אם גודל `T` הוא, לכל הסוגים האלה יש אותו גודל כמו `usize`.
///
/// המשתנות של מצביע לא משנה את גודלו.ככזה, `&T` ו-`&mut T` הם באותו הגודל.
/// כמו כן עבור `*const T` ו-`* mut T`.
///
/// # גודל פריטי `#[repr(C)]`
///
/// לייצוג `C` לפריטים יש פריסה מוגדרת.
/// עם פריסה זו, גודל הפריטים יציב גם כל עוד יש לכל השדות גודל יציב.
///
/// ## גודל סטרוקטורים
///
/// עבור `structs`, הגודל נקבע על ידי האלגוריתם הבא.
///
/// עבור כל שדה במבנה המוזמן על פי צו הכרזה:
///
/// 1. הוסף את גודל השדה.
/// 2. לעגל את הגודל הנוכחי לכפולה הקרובה ביותר ל-[alignment] של השדה הבא.
///
/// לבסוף, לעגל את גודל המבנה לכפול הקרוב ביותר ל-[alignment].
/// היישור של המבנה הוא בדרך כלל היישור הגדול ביותר של כל שדותיו;ניתן לשנות זאת באמצעות השימוש ב-`repr(align(N))`.
///
/// שלא כמו `C`, סטרוקטורות בגודל אפס אינן מעוגלות בגודל של בת אחד.
///
/// ## גודל האנומים
///
/// לתמונות שאינן נושאות נתונים מלבד המפלה יש את אותו הגודל של גופי C בפלטפורמה אליה הם נערכים.
///
/// ## גודל האיגודים
///
/// גודלו של איחוד הוא גודל התחום הגדול ביותר שלו.
///
/// בניגוד ל-`C`, איגודים בגודל אפס אינם מעוגלים לגודל של בת אחד.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // כמה פרימיטיבים
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // כמה מערכים
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // שוויון גודל מצביע
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// באמצעות `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // גודל השדה הראשון הוא 1, אז הוסף 1 לגודל.הגודל הוא 1.
/// // היישור של השדה השני הוא 2, אז הוסף 1 לגודל לריפוד.הגודל הוא 2.
/// // גודל השדה השני הוא 2, אז הוסף 2 לגודל.הגודל הוא 4.
/// // היישור של השדה השלישי הוא 1, אז הוסף 0 לגודל לריפוד.הגודל הוא 4.
/// // גודל השדה השלישי הוא 1, לכן הוסף 1 לגודל.הגודל הוא 5.
/// // לבסוף, היישור של המבנה הוא 2 (מכיוון שהיישור הגדול ביותר בין שדותיו הוא 2), לכן הוסף 1 לגודל לריפוד.
/// // הגודל הוא 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // דרגות ציצית עומדות באותם כללים.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // שים לב כי סדר מחדש של השדות יכול להקטין את הגודל.
/// // אנו יכולים להסיר את שני בתים הריפוד על ידי הצבת `third` לפני `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // גודל האיחוד הוא גודל השדה הגדול ביותר.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// מחזיר את הגודל של הערך המופנה בתים.
///
/// זה בדרך כלל זהה ל-`size_of::<T>()`.
/// עם זאת, כאשר ל-`T` * אין גודל ידוע סטטית, למשל פרוסה [`[T]`][slice] או [trait object], ניתן להשתמש ב-`size_of_val` כדי לקבל את הגודל הידוע באופן דינמי.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // בטיחות: `val` הוא הפניה, ולכן הוא מצביע גולמי תקף
    unsafe { intrinsics::size_of_val(val) }
}

/// מחזיר את הגודל של הערך המופנה בתים.
///
/// זה בדרך כלל זהה ל-`size_of::<T>()`.עם זאת, כאשר ל-`T` * אין גודל ידוע סטטית, למשל פרוסה [`[T]`][slice] או [trait object], ניתן להשתמש ב-`size_of_val_raw` כדי לקבל את הגודל הידוע באופן דינמי.
///
/// # Safety
///
/// ניתן להתקשר לפונקציה זו רק אם מתקיימים התנאים הבאים:
///
/// - אם `T` הוא `Sized`, פונקציה זו תמיד בטוחה להתקשרות.
/// - אם הזנב הלא גדול של `T` הוא:
///     - [slice], אז אורך זנב הפרוסה חייב להיות מספר שלם מאותחל, וגודל הערך *כולו*(אורך הזנב הדינמי + קידומת בגודל סטטי) חייב להתאים ל-`isize`.
///     - [trait object], אז החלק vtable של המצביע חייב להצביע על vtable תקף שנרכש על ידי כפייה לא מגדילה, וגודל הערך * כולו (אורך זנב דינמי + קידומת בגודל סטטי) חייב להתאים ל-`isize`.
///
///     - (unstable) [extern type], אז פונקציה זו תמיד בטוחה להתקשרות, אך ייתכן ש-panic או אחרת יחזיר את הערך הלא נכון, מכיוון שפריסת הסוג החיצוני אינה ידועה.
///     זו אותה התנהגות כמו [`size_of_val`] בהתייחס לסוג עם זנב מסוג חיצוני.
///     - אחרת, אסור בשמירה לקרוא לפונקציה זו.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // בטיחות: על המתקשר לספק מצביע גולמי תקף
    unsafe { intrinsics::size_of_val(val) }
}

/// מחזיר את היישור המינימלי הנדרש [ABI] של סוג.
///
/// כל התייחסות לערך מהסוג `T` חייבת להיות מכפלה של המספר הזה.
///
/// זו היישור המשמש לשדות מבנה.זה עשוי להיות קטן יותר מהיישור המועדף.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// מחזירה את היישור המינימלי הנדרש [ABI] לסוג הערך שאליו `val` מצביע.
///
/// כל התייחסות לערך מהסוג `T` חייבת להיות מכפלה של המספר הזה.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // בטיחות: val הוא הפניה, ולכן זה מצביע גולמי תקף
    unsafe { intrinsics::min_align_of_val(val) }
}

/// מחזיר את היישור המינימלי הנדרש [ABI] של סוג.
///
/// כל התייחסות לערך מהסוג `T` חייבת להיות מכפלה של המספר הזה.
///
/// זו היישור המשמש לשדות מבנה.זה עשוי להיות קטן יותר מהיישור המועדף.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// מחזירה את היישור המינימלי הנדרש [ABI] לסוג הערך שאליו `val` מצביע.
///
/// כל התייחסות לערך מהסוג `T` חייבת להיות מכפלה של המספר הזה.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // בטיחות: val הוא הפניה, ולכן זה מצביע גולמי תקף
    unsafe { intrinsics::min_align_of_val(val) }
}

/// מחזירה את היישור המינימלי הנדרש [ABI] לסוג הערך שאליו `val` מצביע.
///
/// כל התייחסות לערך מהסוג `T` חייבת להיות מכפלה של המספר הזה.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// ניתן להתקשר לפונקציה זו רק אם מתקיימים התנאים הבאים:
///
/// - אם `T` הוא `Sized`, פונקציה זו תמיד בטוחה להתקשרות.
/// - אם הזנב הלא גדול של `T` הוא:
///     - [slice], אז אורך זנב הפרוסה חייב להיות מספר שלם מאותחל, וגודל הערך *כולו*(אורך הזנב הדינמי + קידומת בגודל סטטי) חייב להתאים ל-`isize`.
///     - [trait object], אז החלק vtable של המצביע חייב להצביע על vtable תקף שנרכש על ידי כפייה לא מגדילה, וגודל הערך * כולו (אורך זנב דינמי + קידומת בגודל סטטי) חייב להתאים ל-`isize`.
///
///     - (unstable) [extern type], אז פונקציה זו תמיד בטוחה להתקשרות, אך ייתכן ש-panic או אחרת יחזיר את הערך הלא נכון, מכיוון שפריסת הסוג החיצוני אינה ידועה.
///     זו אותה התנהגות כמו [`align_of_val`] בהתייחס לסוג עם זנב מסוג חיצוני.
///     - אחרת, אסור בשמירה לקרוא לפונקציה זו.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // בטיחות: על המתקשר לספק מצביע גולמי תקף
    unsafe { intrinsics::min_align_of_val(val) }
}

/// מחזירה `true` אם שחרור ערכים מסוג `T` חשוב.
///
/// זהו רמז אופטימיזציה בלבד, וניתן ליישמו באופן שמרני:
/// זה עשוי להחזיר `true` עבור סוגים שלמעשה אין צורך להפיל אותם.
/// ככזה תמיד החזרת `true` תהיה יישום תקף של פונקציה זו.עם זאת, אם פונקציה זו אכן מחזירה את `false`, אתה יכול להיות בטוח שלשחרור ל-`T` אין שום תופעת לוואי.
///
/// יישומים ברמה נמוכה של דברים כמו אוספים, שצריכים להוריד את הנתונים שלהם באופן ידני, צריכים להשתמש בפונקציה זו כדי להימנע מנסיון מיותר להפיל את כל התוכן שלהם כשהם נהרסים.
///
/// זה אולי לא ישפיע על בניית הגרסאות (כאשר לולאה שאין לה תופעות לוואי מתגלה ומתבטלת בקלות), אך לרוב מהווה זכייה גדולה לבניית ניפוי באגים.
///
/// שים לב ש-[`drop_in_place`] כבר מבצע בדיקה זו, כך שאם ניתן להפחית את עומס העבודה שלך למספר קטן של שיחות [`drop_in_place`], השימוש בזה אינו מיותר.
/// במיוחד שים לב שאתה יכול [`drop_in_place`] פרוסה, וזה יעשה בדיקת צרכים אחת של כל הערכים.
///
/// לכן סוגים כמו Vec הם רק `drop_in_place(&mut self[..])` מבלי להשתמש במפורש ב-`needs_drop`.
/// לעומת זאת, סוגים כמו [`HashMap`] צריכים להוריד ערכים אחד בכל פעם ועליהם להשתמש ב-API זה.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// הנה דוגמה לאופן שבו אוסף עשוי להשתמש ב-`needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // זרוק את הנתונים
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// מחזירה את הערך של סוג `T` המיוצג על ידי תבנית בתים הכוללת אפס.
///
/// המשמעות היא שלמשל, למשל, בית הריפוד ב-`(u8, u16)` אינו מאופס בהכרח.
///
/// אין שום ערובה לכך שתבנית בתים הכוללת אפס מייצגת ערך תקף מסוג `T` כלשהו.
/// לדוגמא, תבנית בתים הכול-אפס אינה ערך תקף עבור סוגי הפניה (`&T`, `&mut T`) ומצביעים על פונקציות.
/// השימוש ב-`zeroed` בסוגים כאלה גורם ל-[undefined behavior][ub] מיידי מכיוון ש-[the Rust compiler assumes][inv] שתמיד יש ערך תקף במשתנה שהוא רואה כמאותחל.
///
///
/// השפעה זהה לזו של [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// זה שימושי עבור FFI לפעמים, אך בדרך כלל יש להימנע ממנו.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// שימוש נכון בפונקציה זו: אתחול מספר שלם עם אפס.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// שימוש שגוי בפונקציה זו: אתחול הפניה עם אפס.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // התנהגות לא מוגדרת!
/// let _y: fn() = unsafe { mem::zeroed() }; // ושוב!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // בטיחות: על המתקשר להבטיח שערך אפס תקף ל-`T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// עוקף את בדיקות אתחול הזיכרון הרגילות של Rust על ידי העמדת פנים כמייצרת ערך מסוג `T`, תוך שהיא לא עושה כלום.
///
/// **פונקציה זו הוצאה משימוש.** השתמש ב-[`MaybeUninit<T>`] במקום זאת.
///
/// הסיבה להתאפקות היא שלא ניתן להשתמש בפונקציה בצורה נכונה: יש לה אותה השפעה כמו [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// כפי שמסביר ה-[`assume_init` documentation][assume_init], [the Rust compiler assumes][inv] שערכים מאותחל כראוי.
/// כתוצאה מכך, קורא למשל
/// `mem::uninitialized::<bool>()` גורם להתנהגות בלתי מוגדרת מיידית להחזרת `bool` שאינו בהחלט `true` או `false`.
/// גרוע מכך, זיכרון לא ממותג באמת כמו מה שחוזר כאן מיוחד בכך שהמהדר יודע שאין לו ערך קבוע.
/// זה הופך את ההתנהגות הלא מוגדרת לכך שיש נתונים לא מאוחדים במשתנה גם אם למשתנה זה יש מספר שלם.
/// (שים לב שהכללים סביב מספרים שלמים לא מאוחדים עדיין לא סופיים, אך עד שהם כן, רצוי להימנע מהם.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // בטיחות: על המתקשר להבטיח שערך מאוחד הוא תקף ל-`T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// מחליף את הערכים בשני מיקומים ניתנים לשינוי, מבלי לבטל את אתחול אף אחד מחדש.
///
/// * אם ברצונך להחליף עם ערך ברירת מחדל או דמה, ראה [`take`].
/// * אם ברצונך להחליף עם ערך שעבר, להחזיר את הערך הישן, ראה [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // בטיחות: המצביעים הגולמיים נוצרו מתוך אזכורים בטוחים הניתנים לשינוי
    // אילוצים ב-`ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// מחליף את `dest` בערך ברירת המחדל של `T`, ומחזיר את ערך `dest` הקודם.
///
/// * אם ברצונך להחליף את הערכים של שני משתנים, ראה [`swap`].
/// * אם ברצונך להחליף בערך שעבר במקום בערך ברירת המחדל, ראה [`replace`].
///
/// # Examples
///
/// דוגמה פשוטה:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` מאפשר לקיחת בעלות על שדה מבנה על ידי החלפתו בערך "empty".
/// ללא `take` אתה יכול להיתקל בבעיות כמו אלה:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// שים לב ש-`T` לא בהכרח מיישם את [`Clone`], כך שהוא לא יכול אפילו לשכפל ולאפס את `self.buf`.
/// אך ניתן להשתמש ב-`take` כדי לנתק את הערך המקורי של `self.buf` מ-`self`, ומאפשר להחזירו:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// מעביר את `src` אל ה-`dest` שהוזכר, ומחזיר את ערך ה-`dest` הקודם.
///
/// אף ערך לא נשמט.
///
/// * אם ברצונך להחליף את הערכים של שני משתנים, ראה [`swap`].
/// * אם ברצונך להחליף בערך ברירת מחדל, ראה [`take`].
///
/// # Examples
///
/// דוגמה פשוטה:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` מאפשר צריכת שדה מבנה על ידי החלפתו בערך אחר.
/// ללא `replace` אתה יכול להיתקל בבעיות כמו אלה:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// שים לב ש-`T` אינו מיישם בהכרח את [`Clone`], ולכן איננו יכולים אפילו לשכפל את `self.buf[i]` כדי להימנע מהמהלך.
/// אך ניתן להשתמש ב-`replace` כדי לנתק את הערך המקורי באינדקס זה מ-`self`, ומאפשר להחזירו:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // בטיחות: אנו קוראים מ-`dest` אך כותבים ישירות את `src` לתוכו לאחר מכן,
    // כזה שהערך הישן אינו משוכפל.
    // שום דבר לא נשמט ושום דבר כאן לא יכול panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// סילוק ערך.
///
/// זה עושה זאת על ידי קריאת יישום הטיעון של [`Drop`][drop].
///
/// זה למעשה לא עושה דבר עבור סוגים שמיישמים `Copy`, למשל
/// integers.
/// ערכים כאלה מועתקים ו-_then_ מועבר לפונקציה, כך שהערך נמשך לאחר קריאת פונקציה זו.
///
///
/// פונקציה זו אינה קסם;זה ממש מוגדר כ
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// מכיוון ש-`_x` מועבר לפונקציה, הוא נשמט אוטומטית לפני שהפונקציה חוזרת.
///
/// [drop]: Drop
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // זרוק במפורש את vector
/// ```
///
/// מכיוון ש-[`RefCell`] אוכף את כללי ההשאלה בזמן הריצה, `drop` יכולה לשחרר הלוואה ל-[`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // לוותר על ההלוואה המשתנה במשבצת זו
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// שלמים וסוגים אחרים המיישמים את [`Copy`] אינם מושפעים מ-`drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // עותק של `x` מועבר ושומט
/// drop(y); // עותק של `y` מועבר ושומט
///
/// println!("x: {}, y: {}", x, y.0); // עדיין פנוי
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// מפרש את `src` כבעל סוג `&U`, ואז קורא את `src` מבלי להזיז את הערך הכלול.
///
/// פונקציה זו תניח באופן לא בטוח שהמצביע `src` תקף לבתים [`size_of::<U>`][size_of] על ידי העברת `&T` ל-`&U` ואז קריאת ה-`&U` (אלא שזה נעשה בצורה נכונה גם כאשר `&U` מחייב דרישות יישור מחמירות יותר מ-`&T`).
/// היא גם תיצור עותק של הערך הכלול באופן בטוח במקום לצאת מ-`src`.
///
/// זו לא שגיאת זמן הידור אם ל-`T` ו-`U` יש גדלים שונים, אך מומלץ מאוד להפעיל פונקציה זו רק כאשר ל-`T` ו-`U` יש אותו גודל.פונקציה זו מפעילה את [undefined behavior][ub] אם `U` גדול מ-`T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // העתק את הנתונים מ-'foo_array' והתייחס אליהם כאל 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // שנה את הנתונים שהועתקו
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // התוכן של 'foo_array' לא היה צריך להשתנות
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // אם ל-U יש דרישת יישור גבוהה יותר, יתכן ש-src לא יהיה מיושר כהלכה.
    if align_of::<U>() > align_of::<T>() {
        // בטיחות: `src` הוא הפניה אשר מובטחת שתקף לקריאות.
        // על המתקשר להבטיח שההתמרה בפועל בטוחה.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // בטיחות: `src` הוא הפניה אשר מובטחת שתקף לקריאות.
        // בדיוק בדקנו שה-`src as *const U` מיושר כהלכה.
        // על המתקשר להבטיח שההתמרה בפועל בטוחה.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// טיפוס אטום המייצג את המפלה של האומה.
///
/// עיין בפונקציה [`discriminant`] במודול זה למידע נוסף.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. לא ניתן לגזור את יישומי trait מכיוון שאיננו רוצים גבולות על T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// מחזיר ערך המזהה באופן ייחודי את גרסת enum ב-`v`.
///
/// אם `T` אינו אנום, קריאה לפונקציה זו לא תביא להתנהגות לא מוגדרת, אך ערך ההחזרה אינו מוגדר.
///
///
/// # Stability
///
/// המפלה של וריאנט enum עשוי להשתנות אם הגדרת enum משתנה.
/// מפלה של גרסה כלשהי לא ישתנה בין אוסף עם אותו מהדר.
///
/// # Examples
///
/// ניתן להשתמש בזה להשוואה של enums הנושאים נתונים, תוך התעלמות מהנתונים בפועל:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// מחזירה את מספר הגרסאות מסוג enum `T`.
///
/// אם `T` אינו אנום, קריאה לפונקציה זו לא תביא להתנהגות לא מוגדרת, אך ערך ההחזרה אינו מוגדר.
/// באותה מידה, אם `T` הוא אנום עם יותר גרסאות מ-`usize::MAX` ערך ההחזר אינו מוגדר.
/// גרסאות לא מיושבות נספרו.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}