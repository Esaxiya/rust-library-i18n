//! תמיכה ב-Panic ב-libcore
//!
//! ספריית הליבה אינה יכולה להגדיר פאניקה, אך היא מכריזה * על פאניקה.
//! משמעות הדבר היא כי הפונקציות בתוך libcore מורשות ל panic, אך כדי להיות שימושי, crate במעלה הזרם חייב להגדיר פאניקה לשימוש עבור libcore.
//! הממשק הנוכחי לפאניקה הוא:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! הגדרה זו מאפשרת להיכנס לפאניקה עם כל הודעה כללית, אך היא אינה מאפשרת כישלון עם ערך `Box<Any>`.
//! (`PanicInfo` מכיל רק `&(dyn Any + Send)`, שעבורו אנו ממלאים ערך דמה ב-'PanicInfo: : internal_constructor'.) הסיבה לכך היא ש-libcore אינו רשאי להקצות.
//!
//!
//! מודול זה מכיל כמה פונקציות בהלה אחרות, אך אלה רק פריטי ה-Lang הדרושים עבור המהדר.כל panics עוברים דרך פונקציה אחת זו.
//! הסמל בפועל מוכרז באמצעות התכונה `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// היישום הבסיסי של מאקרו `panic!` של libcore כאשר לא נעשה שימוש בעיצוב.
#[cold]
// לעולם אל תטמיע אלא אם כן panic_immediate_abort כדי להימנע ככל האפשר מהנפח קוד באתרי השיחות
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // נדרש על ידי קודגן עבור panic בהצפה ומסופי `Assert` MIR אחרים
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // השתמש ב-Arguments::new_v1 במקום בפורמט_ארגס! ("{}", Expr) כדי להפחית את תקרת הגודל.
    // פורמט_ארגס!המאקרו משתמש בתצוגה של trait של str כדי לכתוב expr, המכנה Formatter::pad, שעליו להתאים לקטיעת מחרוזות וריפוד (למרות שאף אחד לא משמש כאן).
    //
    // שימוש ב-Arguments::new_v1 עשוי לאפשר למהדר להשמיט את Formatter::pad מהפלט הבינארי ולחסוך עד כמה קילובייט.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // נדרש עבור panics המוערך באופן קבוע
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // נדרש על ידי codegen עבור panic בגישה OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// היישום הבסיסי של המאקרו `panic!` של libcore בעת השימוש בעיצוב.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // הערה פונקציה זו לעולם אינה חוצה את גבול ה-FFI;זוהי שיחת Rust-to-Rust שנפתרת לפונקציה `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // בטיחות: `panic_impl` מוגדר בקוד Rust בטוח ולכן בטוח להתקשר אליו.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// פונקציה פנימית למקרו `assert_eq!` ו-`assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}