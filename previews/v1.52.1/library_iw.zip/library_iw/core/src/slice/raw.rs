//! פונקציות בחינם ליצירת `&[T]` ו-`&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// יוצר פרוסה ממצביע ואורך.
///
/// הארגומנט `len` הוא מספר **האלמנטים**, ולא מספר הבתים.
///
/// # Safety
///
/// ההתנהגות אינה מוגדרת אם מופר אחד מהתנאים הבאים:
///
/// * `data` חייב להיות [valid] לקריאות עבור `len * mem::size_of::<T>()` בתים רבים, והוא חייב להיות מיושר כהלכה.פירוש הדבר במיוחד:
///
///     * כל טווח הזיכרון של פרוסה זו חייב להיות כלול בתוך אובייקט שהוקצה יחיד!
///       פרוסות לעולם לא יכולות להשתרע על פני מספר עצמים שהוקצו.ראה [below](#incorrect-usage) לדוגמא באופן שגוי שאינו לוקח בחשבון זאת.
///     * `data` חייב להיות ללא אפס ומיושר אפילו לפרוסות באורך אפס.
///     אחת הסיבות לכך היא שאופטימיזציה של פריסת enum עשויה להסתמך על כך שההפניות (כולל פרוסות בכל אורך) יהיו מיושרות ולא בטלות כדי להבדיל אותן מנתונים אחרים.
///     אתה יכול להשיג מצביע שניתן להשתמש בו כ-`data` עבור פרוסות באורך אפס באמצעות [`NonNull::dangling()`].
///
/// * `data` חייב להצביע על ערכים מאותחלים כראוי של `len` מסוג `T`.
///
/// * אסור למוטט את הזיכרון שמפנה אליו הפרוסה המוחזרת למשך כל החיים `'a`, למעט בתוך `UnsafeCell`.
///
/// * הגודל הכולל `len * mem::size_of::<T>()` של הנתח לא יכול להיות גדול מ-`isize::MAX`.
///   עיין בתיעוד הבטיחות של [`pointer::offset`].
///
/// # Caveat
///
/// תוחלת החיים של הנתח שהוחזר נגזרת משימוש בו.
/// כדי למנוע שימוש לרעה בשוגג, מומלץ לקשור את אורך החיים לכל חיי המקור שהוא בטוח בהקשר, כגון על ידי מתן פונקציית עוזר שלוקחת את חייו של ערך מארח לפרוסה, או על ידי הערה מפורשת.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // גלה פרוסה לאלמנט יחיד
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### שימוש שגוי
///
/// הפונקציה הבאה של `join_slices` היא **לא נשמעת** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // הקביעה לעיל מבטיחה ש-`fst` ו-`snd` רציפים, אך הם עדיין עשויים להיכלל בתוך _different allocated objects_, ובמקרה זה יצירת פרוסה זו אינה התנהגות מוגדרת.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` ו-`b` הם אובייקטים שהוקצו שונים ...
///     let a = 42;
///     let b = 27;
///     // ... אשר בכל זאת עשוי להיות מונח ברצף בזיכרון: |א |ב |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// מבצע את אותה פונקציונליות כמו [`from_raw_parts`], אלא שפרוסה ניתנת לשינוי מוחזרת.
///
/// # Safety
///
/// ההתנהגות אינה מוגדרת אם מופר אחד מהתנאים הבאים:
///
/// * `data` חייב להיות [valid] לקריאה וכתיבה עבור `len * mem::size_of::<T>()` בתים רבים, והוא חייב להיות מיושר כהלכה.פירוש הדבר במיוחד:
///
///     * כל טווח הזיכרון של פרוסה זו חייב להיות כלול בתוך אובייקט שהוקצה יחיד!
///       פרוסות לעולם אינן יכולות להשתרע על פני מספר עצמים שהוקצו.
///     * `data` חייב להיות ללא אפס ומיושר אפילו לפרוסות באורך אפס.
///     אחת הסיבות לכך היא שאופטימיזציה של פריסת enum עשויה להסתמך על כך שההפניות (כולל פרוסות בכל אורך) יהיו מיושרות ולא בטלות כדי להבדיל אותן מנתונים אחרים.
///
///     אתה יכול להשיג מצביע שניתן להשתמש בו כ-`data` עבור פרוסות באורך אפס באמצעות [`NonNull::dangling()`].
///
/// * `data` חייב להצביע על ערכים מאותחלים כראוי של `len` מסוג `T`.
///
/// * אין לגשת לזיכרון שהפרוסה המוחזרת מפנה אליה דרך שום מצביע אחר (שאינו נגזר מערך ההחזרה) למשך כל חיי `'a`.
///   גישה לקריאה וגם לכתיבה אסורה.
///
/// * הגודל הכולל `len * mem::size_of::<T>()` של הנתח לא יכול להיות גדול מ-`isize::MAX`.
///   עיין בתיעוד הבטיחות של [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// ממיר הפניה ל-T לפרוסת אורך 1 (ללא העתקה).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// ממיר הפניה ל-T לפרוסת אורך 1 (ללא העתקה).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}