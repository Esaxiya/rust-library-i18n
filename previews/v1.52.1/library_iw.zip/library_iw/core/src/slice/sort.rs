//! מיון פרוסות
//!
//! מודול זה מכיל אלגוריתם מיון המבוסס על המפתח המהיר של אורסון פיטרס המנצח תבנית, שפורסם בכתובת: <https://github.com/orlp/pdqsort>
//!
//!
//! מיון לא יציב תואם ל-libcore מכיוון שהוא אינו מקצה זיכרון, בניגוד ליישום המיון היציב שלנו.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// כאשר הוא נשמט, העתקים מ-`src` ל-`dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // בטיחות: זהו מעמד עוזר.
        //          אנא עיין בשימוש בו לצורך נכונות.
        //          כלומר, חייבים להיות בטוחים ש-`src` ו-`dst` אינם חופפים כנדרש על ידי `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// מעביר את האלמנט הראשון ימינה עד שהוא נתקל באלמנט גדול או שווה.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // בטיחות: הפעולות הלא בטוחות שלהלן כוללות אינדקס ללא צ'ק מאוגד (`get_unchecked` ו-`get_unchecked_mut`)
    // והעתקת זיכרון (`ptr::copy_nonoverlapping`).
    //
    // א.אינדקס:
    //  1. בדקנו את גודל המערך ל>=2.
    //  2. כל האינדקסים שנעשה הוא תמיד בין {0 <= index < len} לכל היותר.
    //
    // ב.העתקת זיכרון
    //  1. אנו מקבלים עצות להפניות המובטחות להיות תקפות.
    //  2. הם לא יכולים לחפוף כיוון שאנחנו מקבלים מצביעים למדדי ההבדל של הנתח.
    //     כלומר, `i` ו-`i-1`.
    //  3. אם הנתח מיושר כהלכה, האלמנטים מיושרים כהלכה.
    //     באחריות המתקשר לוודא שהפרוסה מיושרת כהלכה.
    //
    // ראה הערות למטה לפרטים נוספים.
    unsafe {
        // אם שני האלמנטים הראשונים אינם בסדר ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // קרא את האלמנט הראשון למשתנה שהוקצה לערימה.
            // אם פעולת השוואה הבאה panics, `hole` יירד ויכתוב את האלמנט באופן אוטומטי לפרוסה.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // הזז את האלמנט ה-i` מקום אחד שמאלה ובכך העבר את החור ימינה.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` יורד וכך מעתיק את `tmp` לחור שנותר ב-`v`.
        }
    }
}

/// מעביר את האלמנט האחרון שמאלה עד שהוא נתקל באלמנט קטן יותר או שווה.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // בטיחות: הפעולות הלא בטוחות שלהלן כוללות אינדקס ללא צ'ק מאוגד (`get_unchecked` ו-`get_unchecked_mut`)
    // והעתקת זיכרון (`ptr::copy_nonoverlapping`).
    //
    // א.אינדקס:
    //  1. בדקנו את גודל המערך ל>=2.
    //  2. כל האינדקסים שנעשה הוא תמיד בין `0 <= index < len-1` לכל היותר.
    //
    // ב.העתקת זיכרון
    //  1. אנו מקבלים עצות להפניות המובטחות להיות תקפות.
    //  2. הם לא יכולים לחפוף כיוון שאנחנו מקבלים מצביעים למדדי ההבדל של הנתח.
    //     כלומר, `i` ו-`i+1`.
    //  3. אם הנתח מיושר כהלכה, האלמנטים מיושרים כהלכה.
    //     באחריות המתקשר לוודא שהפרוסה מיושרת כהלכה.
    //
    // ראה הערות למטה לפרטים נוספים.
    unsafe {
        // אם שני האלמנטים האחרונים אינם בסדר ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // קרא את האלמנט האחרון למשתנה שהוקצה לערימה.
            // אם פעולת השוואה הבאה panics, `hole` יירד ויכתוב את האלמנט באופן אוטומטי לפרוסה.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // הזז את האלמנט ה-i` מקום אחד ימינה ובכך העבר את החור שמאלה.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` יורד וכך מעתיק את `tmp` לחור שנותר ב-`v`.
        }
    }
}

/// חלקית ממיינת פרוסה על ידי העברת מספר אלמנטים שאינם בסדר.
///
/// מחזירה את `true` אם הפרוסה ממוינת בסוף.פונקציה זו היא *O*(*n*) במקרה הגרוע ביותר.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // המספר המקסימלי של זוגות סמוכים מחוץ לסדר שיעברו שינוי.
    const MAX_STEPS: usize = 5;
    // אם הנתח קצר מזה, אל תעבירו אלמנטים כלשהם.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // בטיחות: כבר ביצענו במפורש את הבדיקה הכרוכה ב-`i < len`.
        // כל האינדקסים הבאים שלנו הם רק בטווח `0 <= index < len`
        unsafe {
            // מצא את הזוג הבא של אלמנטים סמוכים מחוץ לסדר.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // סיימנו?
        if i == len {
            return true;
        }

        // אל תעביר אלמנטים על מערכים קצרים, בעלות ביצועים.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // החלף את צמד האלמנטים שנמצא.זה מכניס אותם לסדר הנכון.
        v.swap(i - 1, i);

        // הסט את האלמנט הקטן יותר שמאלה.
        shift_tail(&mut v[..i], is_less);
        // העבר את האלמנט הגדול ימינה.
        shift_head(&mut v[i..], is_less);
    }

    // לא הצלחתי למיין את הנתח במספר הצעדים המוגבל.
    false
}

/// ממיין פרוסה באמצעות מיון הכנסה, שהוא *O*(*n*^ 2) במקרה הגרוע ביותר.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// ממיין את `v` באמצעות heapsort, מה שמבטיח *O*(*n*\*log(* n*)) במקרה הגרוע ביותר.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ערימה בינארית זו מכבדת את ה-`parent >= child` המשתנה.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // ילדי `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // בחר את הילד הגדול יותר.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // עצור אם הדומיין מחזיק ב-`node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // החלף את `node` עם הילד הגדול יותר, זז צעד אחד למטה והמשיך לנפות.
            v.swap(node, greater);
            node = greater;
        }
    };

    // בנה את הערימה בזמן ליניארי.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // פופ אלמנטים מקסימליים מהערימה.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// מחיצות `v` לאלמנטים קטנים מ-`pivot`, ואחריה אלמנטים הגדולים או שווים ל-`pivot`.
///
///
/// מחזיר את מספר האלמנטים הקטנים מ-`pivot`.
///
/// החלוקה מתבצעת גוש-על-בלוק על מנת למזער את עלות פעולות הסניף.
/// רעיון זה מוצג במאמר [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // מספר האלמנטים בבלוק טיפוסי.
    const BLOCK: usize = 128;

    // אלגוריתם החלוקה חוזר על השלבים הבאים עד לסיומו:
    //
    // 1. עקוב אחר בלוק מצד שמאל כדי לזהות אלמנטים הגדולים או שווים לציר.
    // 2. עקוב אחר בלוק מהצד הימני כדי לזהות אלמנטים קטנים יותר מהציר.
    // 3. החלף את האלמנטים המזוהים בין צד שמאל וימין.
    //
    // אנו שומרים על המשתנים הבאים עבור בלוק של אלמנטים:
    //
    // 1. `block` - מספר האלמנטים בבלוק.
    // 2. `start` - התחל מצביע למערך `offsets`.
    // 3. `end` - סמן את המצביע למערך `offsets`.
    // 4. `קיזוזים, מדדים של אלמנטים שלא בסדר בתוך הבלוק.

    // החסימה הנוכחית בצד שמאל (מ-`l` ל-`l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // החסימה הנוכחית בצד ימין (מ-`r.sub(block_r)` to `r`).
    // בטיחות: התיעוד ל-.add() מציין במפורש כי `vec.as_ptr().add(vec.len())` תמיד בטוח '
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: כשאנחנו מקבלים VLAs, נסה ליצור מערך אחד באורך `min(v.len(), 2 * BLOCK) `במקום זאת
    // משני מערכים בגודל קבוע באורך `BLOCK`.VLAs עשויים להיות יעילים יותר במטמון.

    // מחזיר את מספר האלמנטים בין המצביעים `l` (inclusive) ו-`r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // סיימנו עם מחיצה בלוק אחר בלוק כאשר `l` ו-`r` מתקרבים מאוד.
        // לאחר מכן אנו מבצעים עבודות טלאים על מנת לחלק את האלמנטים הנותרים בין לבין.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // מספר האלמנטים שנותרו (עדיין לא בהשוואה לציר).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // התאם את גדלי הבלוקים כך שהגוש השמאלי והימני לא יחפפו, אלא יישר קו בצורה מושלמת כדי לכסות את כל הפער שנותר.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // עקוב אחר אלמנטים `block_l` מצד שמאל.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // בטיחות: הפעולות הלא בטיחותיות שלהלן כוללות שימוש ב-`offset`.
                //         על פי התנאים הנדרשים על ידי הפונקציה, אנו מספקים אותם מכיוון:
                //         1. `offsets_l` מוקצה בערימה, ולכן נחשב לאובייקט מוקצה נפרד.
                //         2. הפונקציה `is_less` מחזירה `bool`.
                //            יציקת `bool` לעולם לא תעלה על `isize`.
                //         3. הבטחנו ש-`block_l` יהיה `<= BLOCK`.
                //            בנוסף, `end_l` הוגדר בתחילה לסמן ההתחלה של `offsets_` שהוכרז על הערימה.
                //            לפיכך, אנו יודעים שגם במקרה הגרוע ביותר (כל הקריאות ל-`is_less` מחזירות שקר) אנו נצטרך לכל היותר 1 בתים לעבור את הסוף.
                //        פעולה נוספת שאינה בטיחותית כאן היא התייחסות ל-`elem`.
                //        עם זאת, `elem` היה בתחילה מצביע ההתחלה לפרוסה שתמיד תקפה.
                unsafe {
                    // השוואה ללא ענף.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // עקוב אחר רכיבי `block_r` מצד ימין.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // בטיחות: הפעולות הלא בטיחותיות שלהלן כוללות שימוש ב-`offset`.
                //         על פי התנאים הנדרשים על ידי הפונקציה, אנו מספקים אותם מכיוון:
                //         1. `offsets_r` מוקצה בערימה, ולכן נחשב לאובייקט מוקצה נפרד.
                //         2. הפונקציה `is_less` מחזירה `bool`.
                //            יציקת `bool` לעולם לא תעלה על `isize`.
                //         3. הבטחנו ש-`block_r` יהיה `<= BLOCK`.
                //            בנוסף, `end_r` הוגדר בתחילה לסמן ההתחלה של `offsets_` שהוכרז על הערימה.
                //            לפיכך, אנו יודעים שגם במקרה הגרוע ביותר (כל הקריאות ל-`is_less` מחזירות נכונות) אנו נעבור לכל היותר רק בת אחד.
                //        פעולה נוספת שאינה בטיחותית כאן היא התייחסות ל-`elem`.
                //        עם זאת, `elem` היה בתחילה `1 *sizeof(T)` אחרי הסוף ואנחנו מקטינים אותו על ידי `1* sizeof(T)` לפני שניגש אליו.
                //        בנוסף, נטען כי `block_r` נמוך מ-`BLOCK` ו-`elem` ימצאו לכל היותר את תחילת הנתח.
                unsafe {
                    // השוואה ללא ענף.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // מספר האלמנטים שאינם בסדר להחלפה בין הצד השמאלי לימין.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // במקום להחליף זוג אחד בכל פעם, יעיל יותר לבצע תמורה מחזורית.
            // זה לא שווה ערך להחלפה, אך מייצר תוצאה דומה באמצעות פחות פעולות זיכרון.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // כל האלמנטים הלא מסודרים בבלוק השמאלי הועברו.עבור לחסום הבא.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // כל האלמנטים הלא תקינים בבלוק הימני הועברו.עבור לחסימה הקודמת.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // כל שנותר עכשיו הוא לכל היותר בלוק אחד (שמאל או ימין) עם אלמנטים לא מסודרים שיש להזיזם.
    // אלמנטים שנותרו כאלה ניתן פשוט להעביר לסוף בתוך הבלוק שלהם.
    //

    if start_l < end_l {
        // הבלוק השמאלי נשאר.
        // העבר את האלמנטים הנותרים מחוץ לסדר לקצה הימין.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // הבלוק הימני נשאר.
        // העבר את האלמנטים הנותרים מחוץ לסדר לשמאל הקיצוני.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // שום דבר אחר לעשות, סיימנו.
        width(v.as_mut_ptr(), l)
    }
}

/// מחיצות `v` לאלמנטים קטנים מ-`v[pivot]`, ואחריה אלמנטים הגדולים או שווים ל-`v[pivot]`.
///
///
/// מחזיר כפל של:
///
/// 1. מספר האלמנטים הקטנים מ-`v[pivot]`.
/// 2. נכון אם `v` כבר היה מחולק.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // מניחים את הציר בתחילת הנתח.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // קרא את הציר למשתנה שהוקצה לערימה לצורך יעילות.
        // אם פעולת השוואה הבאה panics, הציר ייכתב באופן אוטומטי לפרוסה.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // מצא את הזוג הראשון של אלמנטים שאינם בסדר.
        let mut l = 0;
        let mut r = v.len();

        // בטיחות: אי הבטיחות שלהלן כוללת אינדקס מערך.
        // לראשונה: אנחנו כבר עושים את גבולות הבדיקה כאן עם `l < r`.
        // לשני: בתחילה יש לנו `l == 0` ו-`r == v.len()` ובדקנו את ה-`l < r` בכל פעולת אינדקס.
        //                     מכאן אנו יודעים כי `r` חייב להיות לפחות `r == l` שהוכח שהוא תקף מהראשון.
        unsafe {
            // מצא את האלמנט הראשון גדול או שווה לציר.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // מצא את האלמנט האחרון הקטן יותר בציר.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` יוצא מהתחום וכותב את הציר (שהוא משתנה שהוקצה למחסנית) בחזרה לפרוסה בה היה במקור.
        // שלב זה הוא קריטי בהבטחת הבטיחות!
        //
    };

    // מקם את הציר בין שתי המחיצות.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// מחיצות `v` לאלמנטים השווים ל-`v[pivot]` ואחריה אלמנטים הגדולים מ-`v[pivot]`.
///
/// מחזיר את מספר האלמנטים השווים לציר.
/// ההנחה היא כי `v` אינו מכיל אלמנטים קטנים יותר מהציר.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // מניחים את הציר בתחילת הנתח.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // קרא את הציר למשתנה שהוקצה לערימה לצורך יעילות.
    // אם פעולת השוואה הבאה panics, הציר ייכתב באופן אוטומטי לפרוסה.
    // בטיחות: המצביע כאן תקף מכיוון שהוא מתקבל מהפניה לפרוסה.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // עכשיו מחלקים את הנתח.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // בטיחות: אי הבטיחות שלהלן כוללת אינדקס מערך.
        // לראשונה: אנחנו כבר עושים את גבולות הבדיקה כאן עם `l < r`.
        // לשני: בתחילה יש לנו `l == 0` ו-`r == v.len()` ובדקנו את ה-`l < r` בכל פעולת אינדקס.
        //                     מכאן אנו יודעים כי `r` חייב להיות לפחות `r == l` שהוכח שהוא תקף מהראשון.
        unsafe {
            // מצא את האלמנט הראשון גדול יותר מהציר.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // מצא את האלמנט האחרון השווה לציר.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // סיימנו?
            if l >= r {
                break;
            }

            // החלף את זוג האלמנטים שנמצאו מחוץ לסדר.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // מצאנו אלמנטים של `l` שווים לציר.הוסף 1 לחשבון עבור הציר עצמו.
    l + 1

    // `_pivot_guard` יוצא מהתחום וכותב את הציר (שהוא משתנה שהוקצה למחסנית) בחזרה לפרוסה בה היה במקור.
    // שלב זה הוא קריטי בהבטחת הבטיחות!
}

/// מפזר כמה אלמנטים מסביב בניסיון לשבור דפוסים העלולים לגרום למחיצות לא מאוזנות בקוויסט.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // מחולל מספרים פסאודורדום מעיתון "Xorshift RNGs" מאת ג'ורג 'מרסאגליה.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // קח מספרים אקראיים מודול מספר זה.
        // המספר מתאים ל-`usize` מכיוון ש-`len` אינו גדול מ-`isize::MAX`.
        let modulus = len.next_power_of_two();

        // כמה מועמדי ציר יהיו בסמוך לאינדקס זה.בואו אקרא אותם.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // צור מספר אקראי מודולו `len`.
            // עם זאת, על מנת להימנע מפעולות יקרות, ראשית אנו לוקחים אותו בהספק של שניים, ואז יורד ב-`len` עד שהוא נכנס לטווח `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` מובטח שהוא יהיה פחות מ-`2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// בוחר ציר ב-`v` ומחזיר את האינדקס ו-`true` אם סביר להניח שהמקטע כבר ממוין.
///
/// רכיבים ב-`v` עשויים להיות מסודרים מחדש בתהליך.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // אורך מינימלי לבחירת שיטת חציון-מדיה.
    // פרוסות קצרות יותר משתמשות בשיטת החציון-שלוש הפשוטה.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // מספר מקסימלי של החלפות שניתן לבצע בפונקציה זו.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // שלושה מדדים שלידם אנו עומדים לבחור ציר.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // מונה את מספר ההחלפות הכולל שאנחנו עומדים לבצע בזמן מיון המדדים.
    let mut swaps = 0;

    if len >= 8 {
        // מחליף מדדים כך ש-`v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // מחליף מדדים כך ש-`v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // מוצא את החציון של `v[a - 1], v[a], v[a + 1]` ומאחסן את האינדקס ב-`a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // מצא חציונים בשכונות `a`, `b` ו-`c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // מצא את החציון בין `a`, `b` ו-`c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // מספר ההחלפות המרבי בוצע.
        // רוב הסיכויים שהפרוסה יורדת או בעיקר יורדת, כך שההיפוך יכול כנראה לעזור למיין אותה מהר יותר.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// ממיין את `v` באופן רקורסיבי.
///
/// אם לפרוסה היה קודם במערך המקורי, הוא מוגדר כ-`pred`.
///
/// `limit` הוא מספר המחיצות הלא מאוזנות המותרות לפני המעבר ל-`heapsort`.
/// אם אפס, פונקציה זו תעבור מיד ל-heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // פרוסות עד אורך זה ממוינות באמצעות מיון הכנסה.
    const MAX_INSERTION: usize = 20;

    // נכון אם החלוקה האחרונה הייתה מאוזנת באופן סביר.
    let mut was_balanced = true;
    // נכון אם המחיצה האחרונה לא ערבבה אלמנטים (הנתח כבר מחולק).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // פרוסות קצרות מאוד ממוינות באמצעות מיון הכנסה.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // אם נעשו יותר מדי אפשרויות ציר גרועות, פשוט חזור למגוון גדול כדי להבטיח את המקרה הגרוע ביותר של `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // אם המחיצה האחרונה לא הייתה מאוזנת, נסה לשבור דפוסים בפרוסה על ידי דשדוש כמה אלמנטים מסביב.
        // אני מקווה שנבחר ציר טוב יותר הפעם.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // בחר ציר ונסה לנחש אם הנתח כבר ממוין.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // אם המחיצה האחרונה הייתה מאוזנת בצורה הגונה ולא דשדשה אלמנטים, ואם בחירת ציר מנבאת שהנתח כבר ממוין ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // נסה לזהות כמה אלמנטים שאינם בסדר ולהעביר אותם למיקומים הנכונים.
            // אם הפרוסה בסופו של דבר ממוינת לחלוטין, סיימנו.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // אם הציר הנבחר שווה לקודמו, אז זה האלמנט הקטן ביותר בפרוסה.
        // מחלקים את הנתח לאלמנטים שווים ואלמנטים גדולים מהציר.
        // מקרה זה נפגע בדרך כלל כאשר הנתח מכיל אלמנטים כפולים רבים.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // המשך במיון אלמנטים הגדולים יותר מהציר.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // מחלקים את הנתח.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // פצל את הנתח ל-`left`, `pivot` ו-`right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // התחל לצד הקצר יותר רק על מנת למזער את המספר הכולל של שיחות רקורסיביות ולצרוך פחות שטח מחסנית.
        // ואז פשוט להמשיך עם הצד הארוך יותר (זה דומה לרקורסיה של הזנב).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// ממיין את `v` באמצעות סיבוב מהיר של תבנית, שהוא *O*(*n*\*log(* n*)) במקרה הגרוע ביותר.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // למיון אין התנהגות משמעותית בסוגים בגודל אפס.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // הגבל את מספר המחיצות הלא מאוזנות ל-`floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // עבור פרוסות של עד אורך זה זה כנראה מהיר יותר פשוט למיין אותן.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // בחר ציר
        let (pivot, _) = choose_pivot(v, is_less);

        // אם הציר הנבחר שווה לקודמו, אז זה האלמנט הקטן ביותר בפרוסה.
        // מחלקים את הנתח לאלמנטים שווים ואלמנטים גדולים מהציר.
        // מקרה זה נפגע בדרך כלל כאשר הנתח מכיל אלמנטים כפולים רבים.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // אם עברנו את האינדקס שלנו, אז אנחנו טובים.
                if mid > index {
                    return;
                }

                // אחרת, המשך במיון אלמנטים הגדולים יותר מהציר.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // פצל את הנתח ל-`left`, `pivot` ו-`right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // אם אמצע==אינדקס, סיימנו, מכיוון ש-partition() הבטיח שכל האלמנטים אחרי אמצע גדולים או שווים לאמצע.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // למיון אין התנהגות משמעותית בסוגים בגודל אפס.לעשות כלום.
    } else if index == v.len() - 1 {
        // מצא את האלמנט המרבי והציב אותו במיקום האחרון של המערך.
        // אנו חופשיים להשתמש ב-`unwrap()` כאן מכיוון שאנחנו יודעים ש-V לא יכול להיות ריק.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // מצא את האלמנט המינימלי והמקם אותו במיקום הראשון של המערך.
        // אנו חופשיים להשתמש ב-`unwrap()` כאן מכיוון שאנחנו יודעים ש-V לא יכול להיות ריק.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}