// ignore-tidy-filelength

//! ניהול ומניפולציה של פרוסות.
//!
//! לפרטים נוספים ראה [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// יישום memchr טהור של rust, נלקח מ-rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// פונקציה זו היא ציבורית רק מכיוון שאין דרך אחרת לבחון את כמות הקבוצות היחידות.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// מחזיר את מספר האלמנטים בפרוסה.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // בטיחות: צליל קונסט מכיוון שאנחנו משדרים את שדה האורך כמשתמש (שהוא חייב להיות)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // בטיחות: זה בטוח מכיוון של-`&[T]` ו-`FatPtr<T>` יש אותה פריסה.
            // רק `std` יכולה להגיש אחריות זו.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: החלף ב-`crate::ptr::metadata(self)` כשזה יציב.
            // נכון לכתיבת שורות אלה הדבר גורם לשגיאת "Const-stable functions can only call other const-stable functions".
            //

            // בטיחות: גישה לערך מאיחוד `PtrRepr` בטוחה שכן * const T
            // ו-PtrComponents<T>בעלי אותן פריסות זיכרון.
            // רק std יכול להגיש אחריות זו.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// מחזירה את `true` אם האורך של הנתח הוא 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// מחזיר את האלמנט הראשון של הנתח, או `None` אם הוא ריק.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// מחזיר מצביע משתנה לאלמנט הראשון של הנתח, או `None` אם הוא ריק.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// מחזיר את כל שאר האלמנטים של הנתח, או את `None` אם הוא ריק.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// מחזיר את כל שאר האלמנטים של הנתח, או את `None` אם הוא ריק.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// מחזיר את כל האלמנטים האחרים של הפרוסה וכל שאר הפרסים, או `None` אם היא ריקה.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// מחזיר את כל האלמנטים האחרים של הפרוסה וכל שאר הפרסים, או `None` אם היא ריקה.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// מחזיר את האלמנט האחרון של הנתח, או `None` אם הוא ריק.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// מחזיר מצביע משתנה לפריט האחרון בפרוסה.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// מחזיר הפניה לאלמנט או למקטע משנה בהתאם לסוג האינדקס.
    ///
    /// - אם ניתנת עמדה, מחזיר הפניה לאלמנט במיקום זה או `None` אם הוא מחוץ לתחום.
    ///
    /// - אם ניתן לו טווח, מחזיר את תת המשנה המתאים לטווח זה, או `None` אם הוא מחוץ לתחום.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// מחזירה הפניה משתנה לאלמנט או למקטע משנה תלוי בסוג האינדקס (ראה [`get`]) או `None` אם האינדקס מחוץ לתחום.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// מחזירה הפניה לאלמנט או תת-פרוסה, מבלי לבצע בדיקת גבולות.
    ///
    /// לקבלת אלטרנטיבה בטוחה ראה [`get`].
    ///
    /// # Safety
    ///
    /// קריאה לשיטה זו עם אינדקס מחוץ לתחום היא *[התנהגות לא מוגדרת]* גם אם לא משתמשים בהפניה המתקבלת.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // בטיחות: על המתקשר לעמוד ברוב דרישות הבטיחות עבור `get_unchecked`;
        // הנתח ניתן להפניה מכיוון ש-`self` הוא הפניה בטוחה.
        // המצביע שהוחזר בטוח מפני ש-implants של `SliceIndex` חייבים להבטיח שכן.
        unsafe { &*index.get_unchecked(self) }
    }

    /// מחזירה הפניה משתנה לאלמנט או למקטע משנה, מבלי לבצע בדיקת גבולות.
    ///
    /// לקבלת אלטרנטיבה בטוחה ראה [`get_mut`].
    ///
    /// # Safety
    ///
    /// קריאה לשיטה זו עם אינדקס מחוץ לתחום היא *[התנהגות לא מוגדרת]* גם אם לא משתמשים בהפניה המתקבלת.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // בטיחות: על המתקשר לעמוד בדרישות הבטיחות עבור `get_unchecked_mut`;
        // הנתח ניתן להפניה מכיוון ש-`self` הוא הפניה בטוחה.
        // המצביע שהוחזר בטוח מפני ש-implants של `SliceIndex` חייבים להבטיח שכן.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// מחזיר מצביע גולמי למאגר הנתח.
    ///
    /// על המתקשר לוודא שהפרוסה תעלה על מצביע זה מחזירה, אחרת היא תצביע על זבל.
    ///
    /// על המתקשר גם לוודא שהזיכרון אליו מצביע ה-(non-transitively) מצביע לעולם אינו נכתב (למעט בתוך `UnsafeCell`) באמצעות מצביע זה או כל מצביע שנגזר ממנו.
    /// אם אתה צריך לשנות את תוכן הנתח, השתמש ב-[`as_mut_ptr`].
    ///
    /// שינוי המכולה אליה מפניה פרוסה זו עלול לגרום להקצאה מחדש של המאגר שלה, מה שגם יהפוך את כל המצביעים אליה ללא חוקיים.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// מחזיר מצביע משתנה לא בטוח למאגר הנתח.
    ///
    /// על המתקשר לוודא שהפרוסה תעלה על מצביע זה מחזירה, אחרת היא תצביע על זבל.
    ///
    /// שינוי המכולה אליה מפניה פרוסה זו עלול לגרום להקצאה מחדש של המאגר שלה, מה שגם יהפוך את כל המצביעים אליה ללא חוקיים.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// מחזיר את שני המצביעים הגולמיים המשתרעים על הנתח.
    ///
    /// הטווח המוחזר פתוח למחצה, כלומר מצביע הסיום מפנה *אחד מעבר* לאלמנט האחרון של הפרוסה.
    /// בדרך זו, פרוסה ריקה מיוצגת על ידי שתי מצביעות שוות, וההפרש בין שתי המצביעים מייצג את גודל הנתח.
    ///
    /// ראה [`as_ptr`] לקבלת אזהרות לגבי השימוש בעצות אלה.מצביע הסיום דורש זהירות נוספת, מכיוון שהוא אינו מצביע על אלמנט חוקי בפרוסה.
    ///
    /// פונקציה זו שימושית לאינטראקציה עם ממשקים זרים המשתמשים בשתי מצביעים כדי להתייחס למגוון אלמנטים בזיכרון, כמקובל ב-C ++.
    ///
    ///
    /// זה יכול להיות שימושי גם לבדוק אם מצביע לאלמנט מתייחס לאלמנט של הנתח הזה:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // בטיחות: ה-`add` כאן בטוח כי:
        //
        //   - שתי המצביעות הן חלק מאותו עצם, שכן הצבעה ישירות מעבר לאובייקט נחשבת גם היא.
        //
        //   - גודל הנתח לעולם אינו גדול מ-isize::MAX בתים, כפי שצוין כאן:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - אין שום עטיפה מעורבת, מכיוון שפרוסות אינן עוטפות את קצה שטח הכתובת.
        //
        // עיין בתיעוד של pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// מחזירה את שני המצביעים המשתנים הלא בטוחים הפורשים את הנתח.
    ///
    /// הטווח המוחזר פתוח למחצה, כלומר מצביע הסיום מפנה *אחד מעבר* לאלמנט האחרון של הפרוסה.
    /// בדרך זו, פרוסה ריקה מיוצגת על ידי שתי מצביעות שוות, וההפרש בין שתי המצביעים מייצג את גודל הנתח.
    ///
    /// ראה [`as_mut_ptr`] לקבלת אזהרות לגבי השימוש בעצות אלה.
    /// מצביע הסיום דורש זהירות נוספת, מכיוון שהוא אינו מצביע על אלמנט חוקי בפרוסה.
    ///
    /// פונקציה זו שימושית לאינטראקציה עם ממשקים זרים המשתמשים בשתי מצביעים כדי להתייחס למגוון אלמנטים בזיכרון, כמקובל ב-C ++.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // בטיחות: ראה as_ptr_range() לעיל מדוע `add` כאן בטוח.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// מחליף שני אלמנטים בפרוסה.
    ///
    /// # Arguments
    ///
    /// * א, אינדקס האלמנט הראשון
    /// * ב, אינדקס האלמנט השני
    ///
    /// # Panics
    ///
    /// Panics אם `a` או `b` הם מחוץ לתחום.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // אינך יכול לקחת שתי הלוואות ניתנות לשינוי מ-vector אחד, לכן השתמש במצבי גלם.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // בטיחות: `pa` ו-`pb` נוצרו מתוך הפניות וניתנות לשינוי בטוח
        // לאלמנטים בפרוסה ולכן מובטח שהם תקפים ומיישרים.
        // שים לב כי הגישה לאלמנטים שמאחורי `a` ו-`b` מסומנת והיא תהיה panic כאשר היא מחוץ לתחום.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// הופך את סדר האלמנטים בפרוסה, במקום.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // עבור סוגים קטנים מאוד, כל הקוראים בדרך הרגילה מתפקדים בצורה גרועה.
        // אנו יכולים לעשות טוב יותר, בהינתן load/store יעיל ללא יישור, על ידי העמסת נתח גדול יותר והיפוך רישום.
        //

        // באופן אידיאלי LLVM יעשה זאת עבורנו, מכיוון שהוא יודע טוב יותר מאיתנו האם קריאות לא מתואמות יעילות (שכן זה משתנה בין גרסאות ARM שונות, למשל) ומה יהיה גודל הנתח הטוב ביותר.
        // למרבה הצער, נכון ל-LLVM 4.0 (2017-05) הוא רק מסיר את הלולאה, אז אנחנו צריכים לעשות זאת בעצמנו.
        // (השערה: הפוך הוא בעייתי מכיוון שהצדדים יכולים להיות מיושרים אחרת-יהיו כאשר האורך מוזר-כך שאין שום אפשרות להוציא מראש ולפיגור להשתמש ב-SIMD מיושר לחלוטין באמצע.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // השתמש ב-llvm.bswap הפנימי כדי להפוך את u8s בשימוש
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // בטיחות: יש כמה דברים שצריך לבדוק כאן:
                //
                // - שים לב כי `chunk` הוא 4 או 8 עקב בדיקת ה-CFG לעיל.אז `chunk - 1` חיובי.
                // - אינדקס עם מדד `i` הוא בסדר כפי שמבטיח בדיקת הלולאה
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - אינדקס עם אינדקס `ln - i - chunk = ln - (i + chunk)` הוא בסדר:
                //   - `i + chunk > 0` נכון באופן טריוויאלי.
                //   - בדיקת הלולאה מבטיחה:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, ולכן החיסור אינו זורם.
                // - השיחות `read_unaligned` ו-`write_unaligned` בסדר:
                //   - `pa` מצביע על אינדקס `i` כאשר `i < ln / 2 - (chunk - 1)` (ראה לעיל) ו-`pb` מצביע על אינדקס `ln - i - chunk`, כך ששניהם נמצאים לפחות `chunk` בתים רבים הרחק מסוף `self`.
                //
                //   - כל זיכרון מאותחל הוא `usize` תקף.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // השתמש בסיבוב על ידי 16 כדי להפוך u16s ב-u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // בטיחות: ניתן לקרוא u32 ללא יישור מ-`i` אם `i + 1 < ln`
                // (וברור ש-`i < ln`) מכיוון שכל אלמנט הוא 2 בתים ואנחנו קוראים 4.
                //
                // `i + chunk - 1 < ln / 2` # בעוד מצב
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // מכיוון שזה פחות מהאורך חלקי 2, אז זה חייב להיות בגבול.
                //
                // המשמעות היא גם שמכבדים את התנאי `0 < i + chunk <= ln` תמיד, ומבטיחים שניתן להשתמש בבטחה במצבע `pb`.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // בטיחות: `i` נחות מחצי אורך הנתח כך
            // גישה ל-`i` ו-`ln - i - 1` בטוחה (`i` מתחיל ב-0 ולא יגיע רחוק יותר מ-`ln / 2 - 1`).
            // המצביעים שהתקבלו `pa` ו-`pb` תקפים ולכן מיושרים, וניתן לקרוא אותם ולכתוב אותם.
            //
            //
            unsafe {
                // החלפה לא בטוחה כדי להימנע מבדיקת הגבולות בהחלפה בטוחה.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// מחזיר איטרטר מעל הנתח.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// מחזירה איטרטור המאפשר לשנות כל ערך.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// מחזירה איטרטור על כל windows האורך `size` הרציף.
    /// החפיפה של windows.
    /// אם הנתח קצר מ-`size`, האיטרטור לא מחזיר שום ערכים.
    ///
    /// # Panics
    ///
    /// Panics אם `size` הוא 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// אם הנתח קצר מ-`size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// מחזיר איטרטור מעל רכיבי `chunk_size` של הנתח בכל פעם, ומתחיל בתחילת הנתח.
    ///
    /// הנתחים הם פרוסות ואינם חופפים.אם `chunk_size` אינו מחלק את אורך הנתח, הרי שלגוש האחרון לא יהיה אורך `chunk_size`.
    ///
    /// ראה [`chunks_exact`] לקבלת גרסה של איטרטור זה המחזיר נתחים של אלמנטים `chunk_size` תמיד בדיוק, ו-[`rchunks`] עבור אותו איטרטור אך מתחיל בסוף הנתח.
    ///
    ///
    /// # Panics
    ///
    /// Panics אם `chunk_size` הוא 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// מחזיר איטרטור מעל רכיבי `chunk_size` של הנתח בכל פעם, ומתחיל בתחילת הנתח.
    ///
    /// הנתחים הם פרוסות משתנות, ואינם חופפים.אם `chunk_size` אינו מחלק את אורך הנתח, הרי שלגוש האחרון לא יהיה אורך `chunk_size`.
    ///
    /// ראה [`chunks_exact_mut`] לקבלת גרסה של איטרטור זה המחזיר נתחים של אלמנטים `chunk_size` תמיד בדיוק, ו-[`rchunks_mut`] עבור אותו איטרטור אך מתחיל בסוף הנתח.
    ///
    ///
    /// # Panics
    ///
    /// Panics אם `chunk_size` הוא 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// מחזיר איטרטור מעל רכיבי `chunk_size` של הנתח בכל פעם, ומתחיל בתחילת הנתח.
    ///
    /// הנתחים הם פרוסות ואינם חופפים.
    /// אם `chunk_size` אינו מחלק את אורך הפרוסה, אזי האלמנטים האחרונים עד `chunk_size-1` יושמטו וניתן לשלוף אותם מפונקציית `remainder` של האיטרטור.
    ///
    ///
    /// בגלל שלכל נתח יש בדיוק אלמנטים של `chunk_size`, המהדר יכול לרוב לייעל את הקוד המתקבל בצורה טובה יותר מאשר במקרה של [`chunks`].
    ///
    /// ראה [`chunks`] לקבלת גרסה של איטרטור זה המחזיר גם את השאר כנתח קטן יותר, ו-[`rchunks_exact`] עבור אותו איטרטור אך מתחיל בסוף הנתח.
    ///
    /// # Panics
    ///
    /// Panics אם `chunk_size` הוא 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// מחזיר איטרטור מעל רכיבי `chunk_size` של הנתח בכל פעם, ומתחיל בתחילת הנתח.
    ///
    /// הנתחים הם פרוסות משתנות, ואינם חופפים.
    /// אם `chunk_size` אינו מחלק את אורך הפרוסה, אזי האלמנטים האחרונים עד `chunk_size-1` יושמטו וניתן לשלוף אותם מפונקציית `into_remainder` של האיטרטור.
    ///
    ///
    /// בגלל שלכל נתח יש בדיוק אלמנטים של `chunk_size`, המהדר יכול לרוב לייעל את הקוד המתקבל בצורה טובה יותר מאשר במקרה של [`chunks_mut`].
    ///
    /// ראה [`chunks_mut`] לקבלת גרסה של איטרטור זה המחזיר גם את השאר כנתח קטן יותר, ו-[`rchunks_exact_mut`] עבור אותו איטרטור אך מתחיל בסוף הנתח.
    ///
    /// # Panics
    ///
    /// Panics אם `chunk_size` הוא 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// פיצול הנתח לפרוסת מערכי אלמנט N, בהנחה שאין שום שארית.
    ///
    ///
    /// # Safety
    ///
    /// זה יכול להיקרא רק מתי
    /// - הנתח מתפצל בדיוק לנתחי אלמנט N (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // בטיחות: לנתחי אלמנט אחד לעולם אין שארית
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // בטיחות: אורך הנתח (6) הוא מכפיל של 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // אלה לא נשמעים:
    /// // תן לחתיכות: &[[_;5]]= slice.as_chunks_unchecked()//אורך הפרוסה אינו מכפיל של 5 נתחים:&[[_;0]]= slice.as_chunks_unchecked()//אף פעם אין להכניס נתחים באורך אפס
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // בטיחות: התנאי המוקדם שלנו הוא בדיוק מה שצריך כדי לקרוא לזה
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // בטיחות: אנחנו מטילים פרוסת אלמנטים `new_len * N`
        // נתח של `new_len` רבים נתחי `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// מחלק את הנתח לפרוסת מערכי אלמנט N`, שמתחילים בתחילת הנתח, ופרוסה שארית באורך פחות מ-`N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics אם `N` הוא 0. סביר להניח כי בדיקה זו תשתנה לשגיאת זמן קומפילציה לפני ששיטה זו תתייצב.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // בטיחות: כבר נבהלנו מאפס והבטחנו בבנייה
        // שאורך תת המשנה הוא מכפלה של N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// פיצול הנתח לפרוסת מערכי אלמנט N, החל בסוף הפרוסה, ופרוסה שארית באורך פחות מ-`N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics אם `N` הוא 0. סביר להניח כי בדיקה זו תשתנה לשגיאת זמן קומפילציה לפני ששיטה זו תתייצב.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // בטיחות: כבר נבהלנו מאפס והבטחנו בבנייה
        // שאורך תת המשנה הוא מכפלה של N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// מחזיר איטרטור מעל רכיבי `N` של הנתח בכל פעם, ומתחיל בתחילת הנתח.
    ///
    /// הנתחים הם הפניות למערך ואינם חופפים.
    /// אם `N` אינו מחלק את אורך הפרוסה, אזי האלמנטים האחרונים עד `N-1` יושמטו וניתן לשלוף אותם מפונקציית `remainder` של האיטרטור.
    ///
    ///
    /// שיטה זו היא המקבילה הגנרית של [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics אם `N` הוא 0. סביר להניח כי בדיקה זו תשתנה לשגיאת זמן קומפילציה לפני ששיטה זו תתייצב.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// פיצול הנתח לפרוסת מערכי אלמנט N, בהנחה שאין שום שארית.
    ///
    ///
    /// # Safety
    ///
    /// זה יכול להיקרא רק מתי
    /// - הנתח מתפצל בדיוק לנתחי אלמנט N (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // בטיחות: לנתחי אלמנט אחד לעולם אין שארית
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // בטיחות: אורך הנתח (6) הוא מכפיל של 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // אלה לא נשמעים:
    /// // תן לחתיכות: &[[_;5]]= slice.as_chunks_unchecked_mut()//אורך הפרוסה אינו מכפיל של 5 נתחים:&[[_;0]]= slice.as_chunks_unchecked_mut()//אף פעם אין להכניס נתחים באורך אפס
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // בטיחות: התנאי המוקדם שלנו הוא בדיוק מה שצריך כדי לקרוא לזה
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // בטיחות: אנחנו מטילים פרוסת אלמנטים `new_len * N`
        // נתח של `new_len` רבים נתחי `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// מחלק את הנתח לפרוסת מערכי אלמנט N`, שמתחילים בתחילת הנתח, ופרוסה שארית באורך פחות מ-`N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics אם `N` הוא 0. סביר להניח כי בדיקה זו תשתנה לשגיאת זמן קומפילציה לפני ששיטה זו תתייצב.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // בטיחות: כבר נבהלנו מאפס והבטחנו בבנייה
        // שאורך תת המשנה הוא מכפלה של N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// פיצול הנתח לפרוסת מערכי אלמנט N, החל בסוף הפרוסה, ופרוסה שארית באורך פחות מ-`N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics אם `N` הוא 0. סביר להניח כי בדיקה זו תשתנה לשגיאת זמן קומפילציה לפני ששיטה זו תתייצב.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // בטיחות: כבר נבהלנו מאפס והבטחנו בבנייה
        // שאורך תת המשנה הוא מכפלה של N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// מחזיר איטרטור מעל רכיבי `N` של הנתח בכל פעם, ומתחיל בתחילת הנתח.
    ///
    /// הנתחים הם הפניות למערך משתנה ואינם חופפים.
    /// אם `N` אינו מחלק את אורך הפרוסה, אזי האלמנטים האחרונים עד `N-1` יושמטו וניתן לשלוף אותם מפונקציית `into_remainder` של האיטרטור.
    ///
    ///
    /// שיטה זו היא המקבילה הגנרית של [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics אם `N` הוא 0. סביר להניח כי בדיקה זו תשתנה לשגיאת זמן קומפילציה לפני ששיטה זו תתייצב.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// מחזירה איטרטור חופף windows של רכיבי `N` של פרוסה, מתחיל בתחילת הפרוסה.
    ///
    ///
    /// זהו המקבילה הגנרית של [`windows`].
    ///
    /// אם `N` גדול מגודל הנתח, הוא לא יחזיר שום windows.
    ///
    /// # Panics
    ///
    /// Panics אם `N` הוא 0.
    /// סביר להניח שבדיקה זה ישתנה לשגיאת זמן הידור לפני שמתייצבת שיטה זו.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// מחזירה איטרטור על פני אלמנטים `chunk_size` של הנתח בכל פעם, החל בסוף הפרוסה.
    ///
    /// הנתחים הם פרוסות ואינם חופפים.אם `chunk_size` אינו מחלק את אורך הנתח, הרי שלגוש האחרון לא יהיה אורך `chunk_size`.
    ///
    /// ראה [`rchunks_exact`] לקבלת גרסה של איטרטור זה המחזיר נתחים של אלמנטים `chunk_size` תמיד בדיוק, ו-[`chunks`] עבור אותו איטרטור אך מתחיל בתחילת הנתח.
    ///
    ///
    /// # Panics
    ///
    /// Panics אם `chunk_size` הוא 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// מחזירה איטרטור על פני אלמנטים `chunk_size` של הנתח בכל פעם, החל בסוף הפרוסה.
    ///
    /// הנתחים הם פרוסות משתנות, ואינם חופפים.אם `chunk_size` אינו מחלק את אורך הנתח, הרי שלגוש האחרון לא יהיה אורך `chunk_size`.
    ///
    /// ראה [`rchunks_exact_mut`] לקבלת גרסה של איטרטור זה המחזיר נתחים של אלמנטים `chunk_size` תמיד בדיוק, ו-[`chunks_mut`] עבור אותו איטרטור אך מתחיל בתחילת הנתח.
    ///
    ///
    /// # Panics
    ///
    /// Panics אם `chunk_size` הוא 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// מחזירה איטרטור על פני אלמנטים `chunk_size` של הנתח בכל פעם, החל בסוף הפרוסה.
    ///
    /// הנתחים הם פרוסות ואינם חופפים.
    /// אם `chunk_size` אינו מחלק את אורך הפרוסה, אזי האלמנטים האחרונים עד `chunk_size-1` יושמטו וניתן לשלוף אותם מפונקציית `remainder` של האיטרטור.
    ///
    /// בגלל שלכל נתח יש בדיוק אלמנטים של `chunk_size`, המהדר יכול לרוב לייעל את הקוד המתקבל בצורה טובה יותר מאשר במקרה של [`chunks`].
    ///
    /// ראה [`rchunks`] לקבלת גרסה של איטרטור זה המחזיר גם את השאר כנתח קטן יותר, ו-[`chunks_exact`] עבור אותו איטרטור אך מתחיל בתחילת הנתח.
    ///
    ///
    /// # Panics
    ///
    /// Panics אם `chunk_size` הוא 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// מחזירה איטרטור על פני אלמנטים `chunk_size` של הנתח בכל פעם, החל בסוף הפרוסה.
    ///
    /// הנתחים הם פרוסות משתנות, ואינם חופפים.
    /// אם `chunk_size` אינו מחלק את אורך הפרוסה, אזי האלמנטים האחרונים עד `chunk_size-1` יושמטו וניתן לשלוף אותם מפונקציית `into_remainder` של האיטרטור.
    ///
    /// בגלל שלכל נתח יש בדיוק אלמנטים של `chunk_size`, המהדר יכול לרוב לייעל את הקוד המתקבל בצורה טובה יותר מאשר במקרה של [`chunks_mut`].
    ///
    /// ראה [`rchunks_mut`] לקבלת גרסה של איטרטור זה המחזיר גם את השאר כנתח קטן יותר, ו-[`chunks_exact_mut`] עבור אותו איטרטור אך מתחיל בתחילת הנתח.
    ///
    ///
    /// # Panics
    ///
    /// Panics אם `chunk_size` הוא 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// מחזירה איטרטור מעל הנתח המייצר ריצות אלמנטים לא חופפות באמצעות הפרדיקט להפרדתם.
    ///
    /// הפרדיקט נקרא בשני אלמנטים הבאים אחריהם, זה אומר שהפרדיקט נקרא ב-`slice[0]` ו-`slice[1]` ואז ב-`slice[1]` ו-`slice[2]` וכן הלאה.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ניתן להשתמש בשיטה זו כדי לחלץ את קטעי המשנה הממוינים:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// מחזירה איטרטר מעל הנתח המייצר ריצות משתנות של אלמנטים שאינם חופפים באמצעות הפרדיקט להפרדתם.
    ///
    /// הפרדיקט נקרא בשני אלמנטים הבאים אחריהם, זה אומר שהפרדיקט נקרא ב-`slice[0]` ו-`slice[1]` ואז ב-`slice[1]` ו-`slice[2]` וכן הלאה.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ניתן להשתמש בשיטה זו כדי לחלץ את קטעי המשנה הממוינים:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// מחלק פרוסה אחת לשניים באינדקס.
    ///
    /// הראשון יכיל את כל המדדים מ-`[0, mid)` (לא כולל את המדד `mid` עצמו) והשני יכיל את כל המדדים מ-`[mid, len)` (לא כולל את המדד `len` עצמו).
    ///
    ///
    /// # Panics
    ///
    /// Panics אם `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // בטיחות: `[ptr; mid]` ו-`[mid; len]` נמצאים בתוך `self`, אשר
        // ממלא את הדרישות של `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// מחלק פרוסה אחת ניתנת לשינוי באינדקס.
    ///
    /// הראשון יכיל את כל המדדים מ-`[0, mid)` (לא כולל את המדד `mid` עצמו) והשני יכיל את כל המדדים מ-`[mid, len)` (לא כולל את המדד `len` עצמו).
    ///
    ///
    /// # Panics
    ///
    /// Panics אם `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // בטיחות: `[ptr; mid]` ו-`[mid; len]` נמצאים בתוך `self`, אשר
        // ממלא את הדרישות של `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// מחלק פרוסה אחת לשניים באינדקס, מבלי לבצע בדיקת גבולות.
    ///
    /// הראשון יכיל את כל המדדים מ-`[0, mid)` (לא כולל את המדד `mid` עצמו) והשני יכיל את כל המדדים מ-`[mid, len)` (לא כולל את המדד `len` עצמו).
    ///
    ///
    /// לקבלת אלטרנטיבה בטוחה ראה [`split_at`].
    ///
    /// # Safety
    ///
    /// קריאה לשיטה זו עם אינדקס מחוץ לתחום היא *[התנהגות לא מוגדרת]* גם אם לא משתמשים בהפניה המתקבלת.על המתקשר לוודא כי `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // בטיחות: המתקשר צריך לבדוק את ה-`0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// מחלק פרוסה אחת ניתנת לשינוי באינדקס, מבלי לבצע בדיקת גבולות.
    ///
    /// הראשון יכיל את כל המדדים מ-`[0, mid)` (לא כולל את המדד `mid` עצמו) והשני יכיל את כל המדדים מ-`[mid, len)` (לא כולל את המדד `len` עצמו).
    ///
    ///
    /// לקבלת אלטרנטיבה בטוחה ראה [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// קריאה לשיטה זו עם אינדקס מחוץ לתחום היא *[התנהגות לא מוגדרת]* גם אם לא משתמשים בהפניה המתקבלת.על המתקשר לוודא כי `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // בטיחות: המתקשר צריך לבדוק את ה-`0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` ו-`[mid; len]` אינם חופפים, ולכן החזרת התייחסות משתנה היא בסדר.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// מחזירה איטרטור על פני תת-קבוצות מופרדות על ידי אלמנטים התואמים ל-`pred`.
    /// האלמנט המותאם אינו כלול ברשימות המשנה.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// אם התאמת האלמנט הראשון, פרוסה ריקה תהיה הפריט הראשון שיוחזר על ידי האיטרטור.
    /// באופן דומה, אם התאמת האלמנט האחרון בפרוסה, פרוסה ריקה תהיה הפריט האחרון שיוחזר על ידי האיטרטור:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// אם שני אלמנטים תואמים צמודים ישירות, פרוסה ריקה תהיה ביניהם:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// מחזירה איטרטור על פני חלקיקי משנה משתנים המופרדים על ידי אלמנטים התואמים ל-`pred`.
    /// האלמנט המותאם אינו כלול ברשימות המשנה.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// מחזירה איטרטור על פני תת-קבוצות מופרדות על ידי אלמנטים התואמים ל-`pred`.
    /// האלמנט המותאם נכלל בסוף המשנה הקודמת כמסיים.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// אם התאמת האלמנט האחרון של הפרוסה, אלמנט זה ייחשב כמסיים את הנתח הקודם.
    ///
    /// הנתח הזה יהיה הפריט האחרון שיוחזר על ידי איטררטור.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// מחזירה איטרטור על פני חלקיקי משנה משתנים המופרדים על ידי אלמנטים התואמים ל-`pred`.
    /// האלמנט המותאם כלול בתת המשנה הקודמת כמסיים.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// מחזיר איטרטור על פני תת-קבוצות מופרדות על ידי אלמנטים התואמים ל-`pred`, החל בסוף הפרוסה ועובד לאחור.
    /// האלמנט המותאם אינו כלול ברשימות המשנה.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// כמו ב-`split()`, אם התאמת האלמנט הראשון או האחרון, פרוסה ריקה תהיה הפריט הראשון (או האחרון) שיוחזר על ידי האיטרטור.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// מחזירה איטרטור על פני קטעי משנה משתנים המופרדים על ידי אלמנטים התואמים ל-`pred`, החל בסוף הפרוסה ועובד לאחור.
    /// האלמנט המותאם אינו כלול ברשימות המשנה.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// מחזירה איטרטר על פני תת-קבוצות מופרדות על ידי אלמנטים התואמים ל-`pred`, מוגבלת להחזרת פריטי `n` לכל היותר.
    /// האלמנט המותאם אינו כלול ברשימות המשנה.
    ///
    /// האלמנט האחרון שהוחזר, אם בכלל, יכיל את שארית הנתח.
    ///
    /// # Examples
    ///
    /// הדפס את הנתח המפוצל פעם אחת במספרים המתחלקים ב-3 (כלומר `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// מחזירה איטרטר על פני תת-קבוצות מופרדות על ידי אלמנטים התואמים ל-`pred`, מוגבלת להחזרת פריטי `n` לכל היותר.
    /// האלמנט המותאם אינו כלול ברשימות המשנה.
    ///
    /// האלמנט האחרון שהוחזר, אם בכלל, יכיל את שארית הנתח.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// מחזירה איטרטור על פני תת-קבוצות מופרדות על ידי אלמנטים התואמים ל-`pred` מוגבל להחזרת פריטי `n` לכל היותר.
    /// זה מתחיל בסוף הנתח ועובד לאחור.
    /// האלמנט המותאם אינו כלול ברשימות המשנה.
    ///
    /// האלמנט האחרון שהוחזר, אם בכלל, יכיל את שארית הנתח.
    ///
    /// # Examples
    ///
    /// הדפיס את הנתח המפוצל פעם אחת, מהסוף, לפי מספרים המתחלקים ב-3 (כלומר, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// מחזירה איטרטור על פני תת-קבוצות מופרדות על ידי אלמנטים התואמים ל-`pred` מוגבל להחזרת פריטי `n` לכל היותר.
    /// זה מתחיל בסוף הנתח ועובד לאחור.
    /// האלמנט המותאם אינו כלול ברשימות המשנה.
    ///
    /// האלמנט האחרון שהוחזר, אם בכלל, יכיל את שארית הנתח.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// מחזירה `true` אם הפרוסה מכילה אלמנט עם הערך הנתון.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// אם אין לך `&T`, אלא רק `&U` כזה ש-`T: Borrow<U>` (למשל
    /// `מחרוזת: לווה<str>`), אתה יכול להשתמש ב-`iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // נתח של `String`
    /// assert!(v.iter().any(|e| e == "hello")); // חפש באמצעות `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// מחזירה `true` אם `needle` הוא קידומת של הנתח.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// מחזיר תמיד את `true` אם `needle` הוא פרוסה ריקה:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// מחזירה `true` אם `needle` הוא סיומת של הנתח.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// מחזיר תמיד את `true` אם `needle` הוא פרוסה ריקה:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// מחזיר תת-חלקה עם הקידומת שהוסרה.
    ///
    /// אם הנתח מתחיל ב-`prefix`, מחזיר את החלק התחתון אחרי הקידומת, עטוף ב-`Some`.
    /// אם `prefix` ריק, פשוט מחזיר את הנתח המקורי.
    ///
    /// אם הנתח אינו מתחיל ב-`prefix`, מחזיר את `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // פונקציה זו תזדקק לשכתוב אם וכאשר SlicePattern מתוחכם יותר.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// מחזירה תת-משנה עם הסיומת שהוסרה.
    ///
    /// אם הנתח מסתיים ב-`suffix`, מחזיר את תת המשנה לפני הסיומת, עטוף ב-`Some`.
    /// אם `suffix` ריק, פשוט מחזיר את הנתח המקורי.
    ///
    /// אם הנתח אינו מסתיים ב-`suffix`, מחזיר את `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // פונקציה זו תזדקק לשכתוב אם וכאשר SlicePattern מתוחכם יותר.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// בינארי מחפש פרוסה ממוינת אחר אלמנט נתון.
    ///
    /// אם נמצא הערך מוחזר [`Result::Ok`], המכיל את אינדקס האלמנט התואם.
    /// אם ישנם התאמות מרובות, ניתן להחזיר כל אחד מהגפרורים.
    /// אם הערך לא נמצא, מוחזר [`Result::Err`], המכיל את האינדקס שבו ניתן להכניס אלמנט תואם תוך שמירה על הסדר הממוין.
    ///
    ///
    /// ראה גם [`binary_search_by`], [`binary_search_by_key`] ו-[`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// מחפש סדרה של ארבעה אלמנטים.
    /// הראשון נמצא, עם עמדה נחושה באופן ייחודי;השני והשלישי לא נמצא;הרביעי יכול להתאים לכל מיקום ב-`[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// אם ברצונך להוסיף פריט ל-vector ממוין, תוך שמירה על סדר המיון:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// בינארי מחפש פרוסה ממוינת זו עם פונקציית השוואה.
    ///
    /// על פונקציית ההשוואה ליישם סדר התואם את סדר המיון של הנתח הבסיסי, ולהחזיר קוד הזמנה המציין אם הארגומנט שלה הוא `Less`, `Equal` או `Greater` היעד הרצוי.
    ///
    ///
    /// אם נמצא הערך מוחזר [`Result::Ok`], המכיל את אינדקס האלמנט התואם.אם ישנם התאמות מרובות, ניתן להחזיר כל אחד מהגפרורים.
    /// אם הערך לא נמצא, מוחזר [`Result::Err`], המכיל את האינדקס שבו ניתן להכניס אלמנט תואם תוך שמירה על הסדר הממוין.
    ///
    /// ראה גם [`binary_search`], [`binary_search_by_key`] ו-[`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// מחפש סדרה של ארבעה אלמנטים.הראשון נמצא, עם עמדה נחושה באופן ייחודי;השני והשלישי לא נמצא;הרביעי יכול להתאים לכל מיקום ב-`[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // בטיחות: השיחה נעשית בטוחה על ידי הזרים הבאים:
            // - `mid >= 0`
            // - `mid < size`: `mid` מוגבל על ידי `[left; right)` מאוגד.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // הסיבה שבגללה אנו משתמשים בזרימת בקרת X00 במקום בהתאמה היא מכיוון שההתאמה מסדירה מחדש את פעולות ההשוואה, שהיא רגישה לחלוטין.
            //
            // זהו x86 asm עבור u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// בינארי מחפש פרוסה ממוינת זו עם פונקציית חילוץ מפתח.
    ///
    /// מניח שהפרוסה ממוינת לפי המפתח, למשל עם [`sort_by_key`] באמצעות אותה פונקציית חילוץ מקשים.
    ///
    /// אם נמצא הערך מוחזר [`Result::Ok`], המכיל את אינדקס האלמנט התואם.
    /// אם ישנם התאמות מרובות, ניתן להחזיר כל אחד מהגפרורים.
    /// אם הערך לא נמצא, מוחזר [`Result::Err`], המכיל את האינדקס שבו ניתן להכניס אלמנט תואם תוך שמירה על הסדר הממוין.
    ///
    ///
    /// ראה גם [`binary_search`], [`binary_search_by`] ו-[`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// מחפש סדרה של ארבעה אלמנטים בפרוסת זוגות ממוינת לפי האלמנטים השנייה שלהם.
    /// הראשון נמצא, עם עמדה נחושה באופן ייחודי;השני והשלישי לא נמצא;הרביעי יכול להתאים לכל מיקום ב-`[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links מותר שכן `slice::sort_by_key` נמצא ב-crate `alloc`, וככזה עדיין לא קיים בעת בניית `core`.
    //
    // קישורים למורד הזרם crate: #74481.מכיוון שפרימיטיבים מתועדים רק ב-libstd (#73423), זה לעולם לא מוביל לקישורים שבורים בפועל.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// ממיין את הנתח, אך לא יכול לשמור על סדר האלמנטים השווים.
    ///
    /// מין זה אינו יציב (כלומר, עשוי לסדר מחדש אלמנטים שווים), במקום (כלומר אינו מקצה) ו-*O*(*n*\*log(* n*)) במקרה הגרוע ביותר.
    ///
    /// # יישום שוטף
    ///
    /// האלגוריתם הנוכחי מבוסס על [pattern-defeating quicksort][pdqsort] של אורסון פיטרס, המשלב את המקרה הממוצע המהיר של סיבית אקראית אקראית עם המקרה הגרוע ביותר של ערימה גדולה, תוך השגת זמן ליניארי על פרוסות עם תבניות מסוימות.
    /// הוא משתמש באקראיות מסוימת כדי למנוע מקרים מנווונים, אך עם seed קבוע כדי לספק תמיד התנהגות דטרמיניסטית.
    ///
    /// זה בדרך כלל מהיר יותר ממיון יציב, למעט בכמה מקרים מיוחדים, למשל, כאשר הנתח מורכב מכמה רצפים ממוינים משורשרים.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// ממיין את הנתח עם פונקציית השוואה, אך לא יכול לשמור על סדר האלמנטים השווים.
    ///
    /// מין זה אינו יציב (כלומר, עשוי לסדר מחדש אלמנטים שווים), במקום (כלומר אינו מקצה) ו-*O*(*n*\*log(* n*)) במקרה הגרוע ביותר.
    ///
    /// על פונקציית ההשוואה להגדיר סדר כולל עבור האלמנטים בפרוסה.אם ההזמנה אינה מוחלטת, סדר האלמנטים אינו מוגדר.הזמנה היא הזמנה כוללת אם היא (לכל `a`, `b` ו-`c`):
    ///
    /// * כולל ואנטי-סימטרי: בדיוק אחד מ-`a < b`, `a == b` או `a > b` נכון, וגם
    /// * מעבר, `a < b` ו-`b < c` מרמז על `a < c`.אותו הדבר חייב להחזיק גם ב-`==` וגם ב-`>`.
    ///
    /// לדוגמא, בעוד ש-[`f64`] אינו מיישם את [`Ord`] מכיוון ש-`NaN != NaN`, אנו יכולים להשתמש ב-`partial_cmp` כפונקציית המיון שלנו כשאנו יודעים שהפרוסה אינה מכילה `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # יישום שוטף
    ///
    /// האלגוריתם הנוכחי מבוסס על [pattern-defeating quicksort][pdqsort] של אורסון פיטרס, המשלב את המקרה הממוצע המהיר של סיבית אקראית אקראית עם המקרה הגרוע ביותר של ערימה גדולה, תוך השגת זמן ליניארי על פרוסות עם תבניות מסוימות.
    /// הוא משתמש באקראיות מסוימת כדי למנוע מקרים מנווונים, אך עם seed קבוע כדי לספק תמיד התנהגות דטרמיניסטית.
    ///
    /// זה בדרך כלל מהיר יותר ממיון יציב, למעט בכמה מקרים מיוחדים, למשל, כאשר הנתח מורכב מכמה רצפים ממוינים משורשרים.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // מיון הפוך
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// ממיין את הנתח עם פונקציית חילוץ מפתח, אך לא יכול לשמור על סדר האלמנטים השווים.
    ///
    /// מיון זה אינו יציב (כלומר, עשוי לסדר מחדש אלמנטים שווים), במקום (כלומר אינו מקצה) ו-*O*(m\* * n *\* log(*n*)) במקרה הגרוע ביותר, כאשר פונקציית המפתח היא *O*(*M*).
    ///
    /// # יישום שוטף
    ///
    /// האלגוריתם הנוכחי מבוסס על [pattern-defeating quicksort][pdqsort] של אורסון פיטרס, המשלב את המקרה הממוצע המהיר של סיבית אקראית אקראית עם המקרה הגרוע ביותר של ערימה גדולה, תוך השגת זמן ליניארי על פרוסות עם תבניות מסוימות.
    /// הוא משתמש באקראיות מסוימת כדי למנוע מקרים מנווונים, אך עם seed קבוע כדי לספק תמיד התנהגות דטרמיניסטית.
    ///
    /// בשל אסטרטגיית הקריאה העיקרית שלה, סביר להניח ש-[`sort_unstable_by_key`](#method.sort_unstable_by_key) יהיה איטי יותר מ-[`sort_by_cached_key`](#method.sort_by_cached_key) במקרים בהם פונקציית המפתח יקרה.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// סדר מחדש את הנתח כך שהאלמנט ב-`index` יהיה בממויו הסופי.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// סדר מחדש את הנתח עם פונקציית השוואה כך שהאלמנט ב-`index` נמצא בממויו הסופי.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// סדר מחדש את הנתח בעזרת פונקציית חילוץ מקשים כך שהאלמנט ב-`index` נמצא בממויו הסופי.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// סדר מחדש את הנתח כך שהאלמנט ב-`index` יהיה בממויו הסופי.
    ///
    /// לסדר מחדש זה יש את המאפיין הנוסף שכל ערך במיקום `i < index` יהיה קטן או שווה לערך כלשהו במיקום `j > index`.
    /// בנוסף, סידור מחדש זה אינו יציב (כלומר
    /// כל מספר של אלמנטים שווים עשוי להגיע למצב `index`) במקום (כלומר
    /// לא מקצה), ו-*O*(*n*) במקרה הגרוע ביותר.
    /// פונקציה זו ידועה גם בשם "kth element" בספריות אחרות.
    /// הוא מחזיר שלישייה של הערכים הבאים: כל האלמנטים פחות מזה שבאינדקס הנתון, הערך באינדקס הנתון וכל האלמנטים גדולים יותר מזה שבאינדקס הנתון.
    ///
    ///
    /// # יישום שוטף
    ///
    /// האלגוריתם הנוכחי מבוסס על החלק המהיר של אותו אלגוריתם מהיר המשמש עבור [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics כאשר `index >= len()`, כלומר תמיד panics על פרוסות ריקות.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // מצא את החציון
    /// v.select_nth_unstable(2);
    ///
    /// // מובטח לנו רק שהפרוסה תהיה אחת מהבאות, בהתבסס על הדרך בה אנו ממיינים את האינדקס שצוין.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// סדר מחדש את הנתח עם פונקציית השוואה כך שהאלמנט ב-`index` נמצא בממויו הסופי.
    ///
    /// לסדר מחדש זה יש את המאפיין הנוסף שכל ערך במיקום `i < index` יהיה קטן או שווה לערך כלשהו במיקום `j > index` באמצעות פונקציית המשווה.
    /// בנוסף, סידור מחדש זה אינו יציב (כלומר כל מספר של אלמנטים שווים עשוי להגיע למיקום `index`), במקום (כלומר לא מקצה), ו-*O*(*n*) במקרה הגרוע ביותר.
    /// פונקציה זו ידועה גם בשם "kth element" בספריות אחרות.
    /// הוא מחזיר שלישייה של הערכים הבאים: כל האלמנטים פחות מזה שבאינדקס הנתון, הערך באינדקס הנתון, וכל האלמנטים הגדולים מזה שבאינדקס הנתון, באמצעות פונקציית ההשוואה המסופקת.
    ///
    ///
    /// # יישום שוטף
    ///
    /// האלגוריתם הנוכחי מבוסס על החלק המהיר של אותו אלגוריתם מהיר המשמש עבור [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics כאשר `index >= len()`, כלומר תמיד panics על פרוסות ריקות.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // מצא את החציון כאילו הפרוסה ממוינת בסדר יורד.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // מובטח לנו רק שהפרוסה תהיה אחת מהבאות, בהתבסס על הדרך בה אנו ממיינים את האינדקס שצוין.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// סדר מחדש את הנתח בעזרת פונקציית חילוץ מקשים כך שהאלמנט ב-`index` נמצא בממויו הסופי.
    ///
    /// לסדר מחדש זה יש את המאפיין הנוסף שכל ערך במיקום `i < index` יהיה קטן או שווה לכל ערך במיקום `j > index` באמצעות פונקציית חילוץ המפתחות.
    /// בנוסף, סידור מחדש זה אינו יציב (כלומר כל מספר של אלמנטים שווים עשוי להגיע למיקום `index`), במקום (כלומר לא מקצה), ו-*O*(*n*) במקרה הגרוע ביותר.
    /// פונקציה זו ידועה גם בשם "kth element" בספריות אחרות.
    /// הוא מחזיר שלישייה של הערכים הבאים: כל האלמנטים פחות מזה שבאינדקס הנתון, הערך באינדקס הנתון, וכל האלמנטים הגדולים מזה שבאינדקס הנתון, באמצעות פונקציית חילוץ המפתח המסופקת.
    ///
    ///
    /// # יישום שוטף
    ///
    /// האלגוריתם הנוכחי מבוסס על החלק המהיר של אותו אלגוריתם מהיר המשמש עבור [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics כאשר `index >= len()`, כלומר תמיד panics על פרוסות ריקות.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // להחזיר את החציון כאילו המערך ממוין לפי ערך מוחלט.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // מובטח לנו רק שהפרוסה תהיה אחת מהבאות, בהתבסס על הדרך בה אנו ממיינים את האינדקס שצוין.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// מעביר את כל האלמנטים החוזרים ונשנים לסוף הנתח בהתאם ליישום [`PartialEq`] trait.
    ///
    ///
    /// מחזיר שתי פרוסות.הראשון אינו מכיל אלמנטים חוזרים ונשנים.
    /// השנייה מכילה את כל הכפילויות ללא סדר מוגדר.
    ///
    /// אם הפרוסה ממוינת, הפרוסה הראשונה שהוחזרה אינה כוללת כפילויות.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// מעביר את כל היסודות מלבד הראשון ברציפות לסוף הנתח המספק יחס שוויון נתון.
    ///
    /// מחזיר שתי פרוסות.הראשון אינו מכיל אלמנטים חוזרים ונשנים.
    /// השנייה מכילה את כל הכפילויות ללא סדר מוגדר.
    ///
    /// הפונקציה `same_bucket` מועברת הפניות לשני אלמנטים מהפרוסה ועליה לקבוע אם האלמנטים משתווים זהים.
    /// האלמנטים מועברים בסדר הפוך מהסדר שלהם בפרוסה, כך שאם `same_bucket(a, b)` מחזיר `true`, `a` מועבר בסוף הפרוסה.
    ///
    ///
    /// אם הפרוסה ממוינת, הפרוסה הראשונה שהוחזרה אינה כוללת כפילויות.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // למרות שיש לנו התייחסות משתנה ל-`self`, אנחנו לא יכולים לבצע שינויים *שרירותיים*.שיחות `same_bucket` יכולות להיות panic, לכן עלינו לוודא שהפרוסה נמצאת במצב תקף בכל עת.
        //
        // הדרך בה אנו מטפלים בכך היא באמצעות החלפות;אנו חוזרים על כל האלמנטים, מחליפים תוך כדי כך שבסופו האלמנטים שאנחנו רוצים לשמור נמצאים בחזית, ואלה שאנחנו רוצים לדחות נמצאים בחלק האחורי.
        // לאחר מכן נוכל לפצל את הנתח.
        // פעולה זו היא עדיין `O(n)`.
        //
        // דוגמה: אנו מתחילים במצב זה, שבו `r` מייצג את "הבא
        // קרא "ו-`w` מייצג את" הבא_כתוב`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // בהשוואת self[r] מול עצמי [w-1], זה לא כפילויות, לכן אנו מחליפים את self[r] ו-self[w] (אין השפעה כ-r==w) ואז מגדילים את r ו-w ומשאירים אותנו עם:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // בהשוואת self[r] מול עצמי [w-1], ערך זה הוא כפילות, לכן אנו מגדילים את `r` אך משאירים את כל השאר ללא שינוי:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // בהשוואת self[r] מול עצמי [w-1], זה לא כפילות, אז החלף self[r] ו-self[w] וקדם את r ו-w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // לא כפילות, חזור על:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // שכפול, advance r. End של פרוסה.פיצול ב-w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // בטיחות: מצב `while` מבטיח `next_read` ו-`next_write`
        // הם פחות מ-`len`, ולכן נמצאים בתוך `self`.
        // `prev_ptr_write` מצביע על אלמנט אחד לפני `ptr_write`, אך `next_write` מתחיל ב-1, כך ש-`prev_ptr_write` לעולם אינו פחות מ-0 ונמצא בתוך הנתח.
        // זה ממלא את הדרישות לדיפרנסציה `ptr_read`, `prev_ptr_write` ו-`ptr_write`, ולשימוש `ptr.add(next_read)`, `ptr.add(next_write - 1)` ו-`prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` הוא גם מצטבר לכל היותר פעם לכל לולאה לכל היותר, כלומר לא מדלגים על שום אלמנט כשייתכן שיהיה צורך להחליף אותו.
        //
        // `ptr_read` ו-`prev_ptr_write` לעולם לא מצביעים על אותו אלמנט.זה נדרש כדי ש-`&mut *ptr_read`, `&mut* prev_ptr_write` יהיו בטוחים.
        // ההסבר הוא פשוט ש-`next_read >= next_write` תמיד נכון, ולכן גם `next_read > next_write - 1`.
        //
        //
        //
        //
        //
        unsafe {
            // הימנע מבדיקת גבולות באמצעות מצביעים גולמיים.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// מעביר את כל האלמנטים מלבד הראשון ברצף לסוף הנתח הנפתרים לאותו מפתח.
    ///
    ///
    /// מחזיר שתי פרוסות.הראשון אינו מכיל אלמנטים חוזרים ונשנים.
    /// השנייה מכילה את כל הכפילויות ללא סדר מוגדר.
    ///
    /// אם הפרוסה ממוינת, הפרוסה הראשונה שהוחזרה אינה כוללת כפילויות.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// מסובב את הנתח במקום כך שאלמנטים `mid` הראשונים של הנתח עוברים לקצה ואילו האלמנטים האחרונים `self.len() - mid` עוברים לחזית.
    /// לאחר קריאה ל-`rotate_left`, האלמנט שהיה קודם באינדקס `mid` יהפוך לאלמנט הראשון בפרוסה.
    ///
    /// # Panics
    ///
    /// פונקציה זו תהיה panic אם `mid` גדול מאורך הפרוסה.שים לב ש-`mid == self.len()` עושה _not_ panic והוא סיבוב ללא פעולה.
    ///
    /// # Complexity
    ///
    /// לוקח ליניארי (בזמן `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// סיבוב תת חלקה:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // בטיחות: הטווח `[p.add(mid) - mid, p.add(mid) + k)` הוא טריוויאלי
        // תקף לקריאה וכתיבה, כנדרש על ידי `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// מסובב את הנתח במקום כך שאלמנטים `self.len() - k` הראשונים של הנתח עוברים לקצה ואילו האלמנטים האחרונים `k` עוברים לחזית.
    /// לאחר קריאה ל-`rotate_right`, האלמנט שהיה קודם באינדקס `self.len() - k` יהפוך לאלמנט הראשון בפרוסה.
    ///
    /// # Panics
    ///
    /// פונקציה זו תהיה panic אם `k` גדול מאורך הפרוסה.שים לב ש-`k == self.len()` עושה _not_ panic והוא סיבוב ללא פעולה.
    ///
    /// # Complexity
    ///
    /// לוקח ליניארי (בזמן `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// סובב תת-פרוסה:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // בטיחות: הטווח `[p.add(mid) - mid, p.add(mid) + k)` הוא טריוויאלי
        // תקף לקריאה וכתיבה, כנדרש על ידי `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// ממלא את `self` באלמנטים על ידי שיבוט `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// ממלא את `self` באלמנטים שהוחזרו על ידי קריאה לסגירה שוב ושוב.
    ///
    /// שיטה זו משתמשת בסגירה כדי ליצור ערכים חדשים.אם אתה מעדיף [`Clone`] לערך נתון, השתמש ב-[`fill`].
    /// אם ברצונך להשתמש ב-[`Default`] trait כדי ליצור ערכים, תוכל להעביר את [`Default::default`] כארגומנט.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// מעתיק את האלמנטים מ-`src` ל-`self`.
    ///
    /// אורכו של `src` חייב להיות זהה ל-`self`.
    ///
    /// אם `T` מיישם את `Copy`, השימוש ב-[`copy_from_slice`] יכול להיות יותר ביצועי.
    ///
    /// # Panics
    ///
    /// פונקציה זו תהיה panic אם לשתי הפרוסות אורכים שונים.
    ///
    /// # Examples
    ///
    /// שיבוט שני אלמנטים מפרוסה לאחרת:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // מכיוון שהפרוסות צריכות להיות באותו אורך, אנו פורסים את פרוסת המקור מארבעה אלמנטים לשניים.
    /// // זה יהיה panic אם לא נעשה זאת.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust אוכף שיכולה להיות רק הפניה אחת ניתנת לשינוי ללא התייחסויות בלתי ניתנות לשינוי לפיסת נתונים מסוימת בהיקף מסוים.
    /// מסיבה זו, ניסיון להשתמש ב-`clone_from_slice` בפרוסה אחת יביא לכשל קומפילציה:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// כדי לעקוף את זה, נוכל להשתמש ב-[`split_at_mut`] כדי ליצור שתי פרוסות משנה מובחנות מפרוסה:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// מעתיק את כל האלמנטים מ-`src` ל-`self`, באמצעות memcpy.
    ///
    /// אורכו של `src` חייב להיות זהה ל-`self`.
    ///
    /// אם `T` אינו מיישם את `Copy`, השתמש ב-[`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// פונקציה זו תהיה panic אם לשתי הפרוסות אורכים שונים.
    ///
    /// # Examples
    ///
    /// העתקת שני אלמנטים מפרוסה לאחרת:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // מכיוון שהפרוסות צריכות להיות באותו אורך, אנו פורסים את פרוסת המקור מארבעה אלמנטים לשניים.
    /// // זה יהיה panic אם לא נעשה זאת.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust אוכף שיכולה להיות רק הפניה אחת ניתנת לשינוי ללא התייחסויות בלתי ניתנות לשינוי לפיסת נתונים מסוימת בהיקף מסוים.
    /// מסיבה זו, ניסיון להשתמש ב-`copy_from_slice` בפרוסה אחת יביא לכשל קומפילציה:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// כדי לעקוף את זה, נוכל להשתמש ב-[`split_at_mut`] כדי ליצור שתי פרוסות משנה מובחנות מפרוסה:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // נתיב הקוד panic הוכנס לפונקציה קרה כדי לא לנפח את אתר השיחה.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // בטיחות: `self` תקף לרכיבי `self.len()` בהגדרה, ו-`src` היה
        // בדק את אותו אורך.
        // הפרוסות אינן יכולות לחפוף מכיוון שהפניות משתנות אינן בלעדיות.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// מעתיק אלמנטים מחלק אחד של הפרוסה לחלק אחר של עצמה, באמצעות ממובה.
    ///
    /// `src` הוא הטווח בתוך `self` להעתקה.
    /// `dest` הוא אינדקס ההתחלה של הטווח בתוך `self` להעתקה, אשר יהיה באורך זהה ל-`src`.
    /// שני הטווחים עשויים לחפוף.
    /// הקצוות של שני הטווחים חייבים להיות קטנים או שווים ל-`self.len()`.
    ///
    /// # Panics
    ///
    /// פונקציה זו תהיה panic אם אחד הטווחים יעלה על סוף הנתח, או אם סוף ה-`src` לפני ההתחלה.
    ///
    ///
    /// # Examples
    ///
    /// העתקת ארבעה בתים בתוך פרוסה:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // בטיחות: התנאים ל-`ptr::copy` נבדקו לעיל,
        // כמו גם עבור `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// מחליף את כל האלמנטים ב-`self` עם אלה שב-`other`.
    ///
    /// אורכו של `other` חייב להיות זהה ל-`self`.
    ///
    /// # Panics
    ///
    /// פונקציה זו תהיה panic אם לשתי הפרוסות אורכים שונים.
    ///
    /// # Example
    ///
    /// החלפת שני אלמנטים על פרוסות:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust אוכף שיכולה להיות רק התייחסות משתנה אחת לפיסת נתונים מסוימת בהיקף מסוים.
    ///
    /// מסיבה זו, ניסיון להשתמש ב-`swap_with_slice` בפרוסה אחת יביא לכשל קומפילציה:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// כדי לעקוף זאת, נוכל להשתמש ב-[`split_at_mut`] כדי ליצור שתי פרוסות משנה ניתנות לשינוי מפלח:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // בטיחות: `self` תקף לרכיבי `self.len()` בהגדרה, ו-`src` היה
        // בדק את אותו אורך.
        // הפרוסות אינן יכולות לחפוף מכיוון שהפניות משתנות אינן בלעדיות.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// פונקציה לחישוב אורכי הנתח האמצעי והנגרר עבור `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // מה שאנחנו הולכים לעשות בקשר ל-`rest` הוא להבין איזה מכפל של U נוכל להכניס למספר הנמוך ביותר של T.
        //
        // וכמה `T` אנו זקוקים לכל "multiple" כזה.
        //
        // קחו למשל T=u8 U=u16.אז נוכל להכניס 1 U ל-2 Ts.פָּשׁוּט.
        // עכשיו שקול למשל מקרה שבו size_of: :<T>=16, size_of::<U>=24.</u>
        // אנחנו יכולים לשים 2 Us במקום כל 3 Ts בפרוסת `rest`.
        // קצת יותר מסובך.
        //
        // הנוסחה לחישוב זה היא:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // מורחב ופשוט:
        //
        // אותנו=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // למרבה המזל מכיוון שכל זה מוערך כל הזמן ... ביצועים כאן לא חשובים!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // האלגוריתם של iterative stein אנחנו עדיין צריכים לעשות את ה-`const fn` הזה (ונחזור לאלגוריתם רקורסיבי אם נעשה זאת) מכיוון שהסתמכות על llvm כדי לכלול את כל זה ... ובכן, זה גורם לי להיות לא נוח.
            //
            //

            // בטיחות: `a` ו-`b` מסומנים כערכים שאינם אפסים.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // הסר את כל הגורמים של 2 מ-b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // בטיחות: `b` מסומן כלא אפס.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // חמושים בידע זה, אנו יכולים למצוא כמה U's אנו יכולים להתאים!
        let us_len = self.len() / ts * us;
        // וכמה `T` יהיו בפרוסה הנגררת!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// העבירו את הנתח לפרוסה מסוג אחר, וודאו כי יישור הסוגים נשמר.
    ///
    /// שיטה זו מחלקת את הפרוסה לשלוש פרוסות נפרדות: קידומת, פרוסת אמצע מיושרת כהלכה מסוג חדש, ופרוסת הסיומת.
    /// השיטה עשויה להפוך את הנתח האמצעי לאורך הגדול ביותר האפשרי עבור סוג נתח ופרוסת קלט, אך רק ביצועי האלגוריתם שלך צריכים להיות תלויים בכך, ולא בנכונותו.
    ///
    /// מותר להחזיר את כל נתוני הקלט כקידומת או קידומת הסיומת.
    ///
    /// לשיטה זו אין מטרה כאשר אלמנט הקלט `T` או אלמנט הפלט `U` הם בגודל אפס ויחזיר את הנתח המקורי מבלי לפצל דבר.
    ///
    /// # Safety
    ///
    /// שיטה זו היא למעשה `transmute` ביחס לאלמנטים בנתח האמצעי המוחזר, ולכן כל האזהרות הרגילות הנוגעות ל-`transmute::<T, U>` חלות גם כאן.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // שים לב שרוב הפונקציה הזו תוערך באופן קבוע,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // להתמודד עם ZST במיוחד, כלומר-לא לטפל בהם בכלל.
            return (self, &[], &[]);
        }

        // ראשית, מצא באיזו נקודה אנו מתחלקים בין הנתח הראשון ל-2.
        // קל עם ptr.align_offset.
        let ptr = self.as_ptr();
        // בטיחות: עיין בשיטת `align_to_mut` להערת בטיחות מפורטת.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // בטיחות: עכשיו `rest` בהחלט מיושר, אז `from_raw_parts` למטה זה בסדר,
            // מכיוון שהמתקשר מבטיח שנוכל להעביר את `T` ל-`U` בבטחה.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// העבירו את הנתח לפרוסה מסוג אחר, וודאו כי יישור הסוגים נשמר.
    ///
    /// שיטה זו מחלקת את הפרוסה לשלוש פרוסות נפרדות: קידומת, פרוסת אמצע מיושרת כהלכה מסוג חדש, ופרוסת הסיומת.
    /// השיטה עשויה להפוך את הנתח האמצעי לאורך הגדול ביותר האפשרי עבור סוג נתח ופרוסת קלט, אך רק ביצועי האלגוריתם שלך צריכים להיות תלויים בכך, ולא בנכונותו.
    ///
    /// מותר להחזיר את כל נתוני הקלט כקידומת או קידומת הסיומת.
    ///
    /// לשיטה זו אין מטרה כאשר אלמנט הקלט `T` או אלמנט הפלט `U` הם בגודל אפס ויחזיר את הנתח המקורי מבלי לפצל דבר.
    ///
    /// # Safety
    ///
    /// שיטה זו היא למעשה `transmute` ביחס לאלמנטים בנתח האמצעי המוחזר, ולכן כל האזהרות הרגילות הנוגעות ל-`transmute::<T, U>` חלות גם כאן.
    ///
    /// # Examples
    ///
    /// שימוש בסיסי:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // שים לב שרוב הפונקציה הזו תוערך באופן קבוע,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // להתמודד עם ZST במיוחד, כלומר-לא לטפל בהם בכלל.
            return (self, &mut [], &mut []);
        }

        // ראשית, מצא באיזו נקודה אנו מתחלקים בין הנתח הראשון ל-2.
        // קל עם ptr.align_offset.
        let ptr = self.as_ptr();
        // בטיחות: כאן אנו מבטיחים שנשתמש במצביעים מיושרים עבור U עבור ה-
        // שאר השיטה.זה נעשה על ידי העברת מצביע אל&[T] עם יישור הממוקד ל-U.
        // `crate::ptr::align_offset` נקרא עם מצביע מיושר ותקף כהלכה `ptr` (הוא מגיע מהפניה ל-`self`) ועם גודל שהוא כוח של שניים (מכיוון שהוא מגיע מהיישור ל-U), המספק את מגבלות הבטיחות שלו.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // לא נוכל להשתמש ב-`rest` שוב לאחר מכן, זה יבטל את כינויו `mut_ptr`!בטיחות: ראה הערות ל-`align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// בודק אם האלמנטים של הנתח הזה ממוינים.
    ///
    /// כלומר, עבור כל רכיב `a` והרכיב הבא שלו `b`, `a <= b` חייב להחזיק.אם הנתח מניב בדיוק אפס או אלמנט אחד, `true` מוחזר.
    ///
    /// שים לב שאם `Self::Item` הוא `PartialOrd` בלבד, אך לא `Ord`, ההגדרה שלעיל מרמזת כי פונקציה זו מחזירה את `false` אם שני פריטים עוקבים אינם דומים.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// בודק אם מרכיבי הפרוסה הזו ממוינים באמצעות פונקציית ההשוואה הנתונה.
    ///
    /// במקום להשתמש ב-`PartialOrd::partial_cmp`, פונקציה זו משתמשת בפונקציה `compare` הנתונה כדי לקבוע את הסדר של שני אלמנטים.
    /// מלבד זאת, זה שווה ערך ל-[`is_sorted`];עיין בתיעוד שלו למידע נוסף.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// בודק אם האלמנטים של פרוסה זו ממוינים באמצעות פונקציית חילוץ המפתח הנתונה.
    ///
    /// במקום להשוות את אלמנטים של הפרוסה ישירות, פונקציה זו משווה את מקשי האלמנטים, כפי שנקבע על ידי `f`.
    /// מלבד זאת, זה שווה ערך ל-[`is_sorted`];עיין בתיעוד שלו למידע נוסף.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// מחזיר את האינדקס של נקודת המחיצה בהתאם לפרדיקט הנתון (אינדקס האלמנט הראשון של המחיצה השנייה).
    ///
    /// ההנחה היא שהפרוסה מחולקת על פי הקביעה הנתונה.
    /// המשמעות היא שכל האלמנטים שעבורם הקבץ מחזיר נכון נמצאים בתחילת הפרוסה וכל האלמנטים שעבורם הפרדיקט מחזיר שווא נמצאים בסוף.
    ///
    /// לדוגמה, [7, 15, 3, 5, 4, 12, 6] מחולקת תחת הפרדיקט x% 2!=0 (כל המספרים המוזרים נמצאים בהתחלה, כולם אפילו בסוף).
    ///
    /// אם פרוסה זו אינה מחולקת, התוצאה שהוחזרה אינה מוגדרת וחסרת משמעות, מכיוון ששיטה זו מבצעת מעין חיפוש בינארי.
    ///
    /// ראה גם [`binary_search`], [`binary_search_by`] ו-[`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // בטיחות: כאשר `left < right`, `left <= mid < right`.
            // לכן `left` תמיד גדל ו-`right` תמיד יורד, ואחד מהם נבחר.בשני המקרים `left <= right` מרוצה.לכן אם `left < right` בשלב, `left <= right` מרוצה בשלב הבא.
            //
            // לכן כל עוד `left != right`, `0 <= left < right <= len` מרוצה ואם גם במקרה זה `0 <= mid < len` מרוצה.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: עלינו לחתוך אותם במפורש לאותו אורך
        // כדי להקל על האופטימיזציה להגדיל את בדיקת הגבולות.
        // אך מכיוון שאי אפשר לסמוך עליו יש לנו גם התמחות מפורשת עבור T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// יוצר פרוסה ריקה.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// יוצר פרוסה ריקה ניתנת לשינוי.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// דפוסים בפרוסות, כיום משמשים רק את `strip_prefix` ו-`strip_suffix`.
/// בנקודת future, אנו מקווים להכליל את `core::str::Pattern` (אשר בזמן כתיבת שורות אלה מוגבל ל-`str`) לפרוסות, ואז ה-trait יוחלף או יבוטל.
///
pub trait SlicePattern {
    /// סוג האלמנט של הנתח שמתאים אליו.
    type Item;

    /// נכון לעכשיו, צרכני `SlicePattern` זקוקים לפרוסה.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}