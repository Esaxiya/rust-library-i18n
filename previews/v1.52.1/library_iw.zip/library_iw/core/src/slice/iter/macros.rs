//! פקודות מאקרו המשמשות איטרציה של פרוסה.

// ההטבעה היא_מתוחה ולן עושה הבדל עצום בביצועים
macro_rules! is_empty {
    // האופן שבו אנו מקודדים את אורכו של איטרטור ZST, זה עובד גם עבור ZST וגם לא על ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// כדי להיפטר מבדיקות גבולות (ראה `position`), אנו מחשבים את האורך בצורה מעט לא צפויה.
// (נבדק על ידי 'codegen/slice-position-bounds-check'.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // אנו משמשים לפעמים בתוך בלוק לא בטוח

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // _cannot_ זה משתמש ב-`unchecked_sub` מכיוון שאנו תלויים בעטיפה כדי לייצג את אורכם של איטרטורי פרוסות ZST ארוכים.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // אנו יודעים כי `start <= end`, כך יכול לעשות טוב יותר מ-`offset_from`, אשר צריך להתמודד חתום.
            // על ידי הגדרת דגלים מתאימים כאן אנו יכולים לומר ל-LLVM זאת, מה שעוזר לה להסיר בדיקות גבולות.
            // בטיחות: לפי סוג המשתנה, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // בכך שהוא גם אומר ל-LLVM שהמצביעים זה מזה על ידי מכפיל מדויק של גודל הסוג, זה יכול לייעל את `len() == 0` עד `start == end` במקום `(end - start) < size`.
            //
            // בטיחות: לפי סוג המשתנה, המצביעים מיושרים כך
            //         המרחק ביניהם חייב להיות מכפיל בגודל הנקודה
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// ההגדרה המשותפת של האיטרטורים `Iter` ו-`IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // מחזיר את האלמנט הראשון ומעביר את התחלת האיטרטור קדימה ב-1.
        // משפר מאוד ביצועים בהשוואה לפונקציה מוטמעת.
        // אסור שהאיטרטור יהיה ריק.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // מחזיר את האלמנט האחרון ומעביר את קצה האיטרטור לאחור ב-1.
        // משפר מאוד ביצועים בהשוואה לפונקציה מוטמעת.
        // אסור שהאיטרטור יהיה ריק.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // מכווץ את האיטרטור כאשר T הוא ZST, על ידי הזזת קצה האיטרטור לאחור על ידי `n`.
        // `n` לא יעלה על `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // פונקציית עוזר ליצירת פרוסה מאיטרטור.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // בטיחות: האיטרטור נוצר מפרוסה עם מצביע
                // `self.ptr` ואורך `len!(self)`.
                // זה מבטיח כי כל התנאים המוקדמים ל-`from_raw_parts` יתמלאו.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // פונקציית עוזר להנעת ההתחלה של האיטרטור קדימה על ידי אלמנטים `offset`, החזרת ההתחלה הישנה.
            //
            // לא בטוח מכיוון שהקיזוז לא יעלה על `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // בטיחות: המתקשר מבטיח כי `offset` אינו עולה על `self.len()`,
                    // אז המצביע החדש נמצא בתוך `self` ובכך מובטח שהוא לא אפס.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // פונקצית עוזר להנעת קצה האיטרטור לאחור על ידי אלמנטים `offset`, החזרת הקצה החדש.
            //
            // לא בטוח מכיוון שהקיזוז לא יעלה על `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // בטיחות: המתקשר מבטיח כי `offset` אינו עולה על `self.len()`,
                    // שמובטח שלא יציף `isize`.
                    // כמו כן, המצביע המתקבל נמצא בגבול של `slice`, אשר ממלא אחר הדרישות האחרות עבור `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // יכול להיות מיושם עם פרוסות, אך הדבר נמנע מבדיקת גבולות

                // בטיחות: שיחות `assume` בטוחות מאז מצביע ההתחלה של הנתח
                // חייב להיות לא אפס, ופרוסות מעל לא ZST חייבות לכלול גם מצביע קצה שאינו אפס.
                // השיחה ל-`next_unchecked!` בטוחה מאחר ואנחנו בודקים אם האיטרטור ריק תחילה.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // איטרטר זה ריק כעת.
                    if mem::size_of::<T>() == 0 {
                        // עלינו לעשות זאת בדרך מכיוון ש-`ptr` אולי לעולם לא יהיה 0, אך `end` יכול להיות (בגלל עטיפה).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // בטיחות: סוף לא יכול להיות 0 אם T אינו ZST מכיוון ש-ptr אינו 0 וסיום>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // בטיחות: אנחנו בגבולות.`post_inc_start` עושה את הדבר הנכון אפילו עבור ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // אנו עוקפים את הטמעת ברירת המחדל, המשתמשת ב-`try_fold`, מכיוון שהטמעה פשוטה זו מייצרת פחות IR LLVM ומהירה יותר להידור.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // אנו עוקפים את הטמעת ברירת המחדל, המשתמשת ב-`try_fold`, מכיוון שהטמעה פשוטה זו מייצרת פחות IR LLVM ומהירה יותר להידור.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // אנו עוקפים את הטמעת ברירת המחדל, המשתמשת ב-`try_fold`, מכיוון שהטמעה פשוטה זו מייצרת פחות IR LLVM ומהירה יותר להידור.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // אנו עוקפים את הטמעת ברירת המחדל, המשתמשת ב-`try_fold`, מכיוון שהטמעה פשוטה זו מייצרת פחות IR LLVM ומהירה יותר להידור.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // אנו עוקפים את הטמעת ברירת המחדל, המשתמשת ב-`try_fold`, מכיוון שהטמעה פשוטה זו מייצרת פחות IR LLVM ומהירה יותר להידור.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // אנו עוקפים את הטמעת ברירת המחדל, המשתמשת ב-`try_fold`, מכיוון שהטמעה פשוטה זו מייצרת פחות IR LLVM ומהירה יותר להידור.
            // כמו כן, ה-`assume` נמנע מבדיקת גבולות.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // בטיחות: מובטח לנו שתהיה גבולות על ידי משתנה הלולאה:
                        // כאשר `i >= n`, `self.next()` מחזיר את `None` והלולאה נשברת.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // אנו עוקפים את הטמעת ברירת המחדל, המשתמשת ב-`try_fold`, מכיוון שהטמעה פשוטה זו מייצרת פחות IR LLVM ומהירה יותר להידור.
            // כמו כן, ה-`assume` נמנע מבדיקת גבולות.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // בטיחות: `i` חייב להיות נמוך מ-`n` מכיוון שהוא מתחיל ב-`n`
                        // ורק יורד.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // בטיחות: על המתקשר להבטיח ש-`i` נמצא בגבול של
                // הנתח הבסיסי, כך ש-`i` לא יכול לעלות על `isize`, וההפניות שהוחזרו מובטחות מתייחסות לאלמנט של הנתח ובכך מובטחת שהן תקפות.
                //
                // שים לב גם שהמתקשר מבטיח שלעולם לא נקרא שוב עם אותו אינדקס, ושלא מתקשרות לשיטות אחרות שיגשו לתת-חלקה זו, ולכן היא תקפה שההפניה המוחזרת תהיה ניתנת לשינוי במקרה של
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // יכול להיות מיושם עם פרוסות, אך הדבר נמנע מבדיקת גבולות

                // בטיחות: שיחות `assume` בטוחות מכיוון שמצביע ההתחלה של הנתח חייב להיות לא אפס,
                // ופרוסות מעל שאינן ZST חייבות לכלול גם מצביע קצה שאינו ריק.
                // השיחה ל-`next_back_unchecked!` בטוחה מאחר ואנחנו בודקים אם האיטרטור ריק תחילה.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // איטרטר זה ריק כעת.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // בטיחות: אנחנו בגבולות.`pre_dec_end` עושה את הדבר הנכון אפילו עבור ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}