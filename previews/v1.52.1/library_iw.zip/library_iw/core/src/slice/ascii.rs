//! פעולות ב-ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// בודק אם כל הבייטים בפרוסה זו נמצאים בטווח ה-ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// בודק ששתי פרוסות הן התאמה שאינה רגישה לאותיות רישיות.
    ///
    /// זהה ל-`to_ascii_lowercase(a) == to_ascii_lowercase(b)`, אך ללא הקצאה והעתקה של זמני.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// ממיר פרוסה זו למקבילה הגדולה של ASCII במקומה.
    ///
    /// אותיות ASCII 'a' ל-'z' ממופות ל-'A' ל-'Z', אך אותיות שאינן ASCII אינן משתנות.
    ///
    /// כדי להחזיר ערך רישום חדש ללא שינוי בערך הקיים, השתמש ב-[`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// ממיר פרוסה זו למקבילה הקטנה של ה-ASCII במקום.
    ///
    /// אותיות ASCII 'A' ל-'Z' ממופות ל-'a' ל-'z', אך אותיות שאינן ASCII אינן משתנות.
    ///
    /// כדי להחזיר ערך חדש נמוך יותר מבלי לשנות את הערך הקיים, השתמש ב-[`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// מחזירה `true` אם בתים כלשהם במילה `v` הם nonascii (>=128).
/// נרקח מ-`../str/mod.rs`, שעושה משהו דומה לצורך אימות utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// בדיקת ASCII מותאמת שתשתמש בפעולות שימוש-בכל פעם במקום בפעולות בתים-בכל פעם (במידת האפשר).
///
/// האלגוריתם בו אנו משתמשים כאן הוא די פשוט.אם `s` קצר מדי, אנחנו פשוט בודקים כל בתים ומסיימים איתו.אחרת:
///
/// - קרא את המילה הראשונה עם עומס לא מיושר.
/// - יישר את המצביע, קרא את המילים הבאות עד הסוף עם עומסים מיושרים.
/// - קרא את ה-`usize` האחרון מ-`s` עם עומס לא מיושר.
///
/// אם אחד מהעומסים הללו מייצר משהו שעבורו `contains_nonascii` (above) מחזיר נכון, אנו יודעים שהתשובה שקרית.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // אם לא היינו מרוויחים דבר מהיישום המילה-בכל-פעם, חזור לולאה סקלרית.
    //
    // אנו עושים זאת גם עבור ארכיטקטורות שבהן `size_of::<usize>()` אינו יישור מספיק עבור `usize`, מכיוון שזה מקרה edge מוזר.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // אנו תמיד קוראים את המילה הראשונה ללא יישור, כלומר `align_offset` היא
    // 0, נקרא שוב את אותו ערך עבור הקריאה המיושרת.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // בטיחות: אנו מאמתים את `len < USIZE_SIZE` לעיל.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // בדקנו זאת לעיל, באופן קצת מרומז.
    // שים לב ש-`offset_to_aligned` הוא `align_offset` או `USIZE_SIZE`, שניהם נבדקים במפורש לעיל.
    //
    debug_assert!(offset_to_aligned <= len);

    // בטיחות: word_ptr הוא ה-ptr בגודל (מיושר כהלכה) שאנו משתמשים בו לקריאת ה-
    // נתח אמצעי של הנתח.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` הוא אינדקס בתים של `word_ptr`, המשמש לבדיקות סוף לולאה.
    let mut byte_pos = offset_to_aligned;

    // פרנויה בודקת לגבי יישור, מכיוון שאנחנו עומדים לעשות חבורה של עומסים לא מיושרים.
    // בפועל זה אמור להיות בלתי אפשרי לחסום באג ב-`align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // קרא את המילים הבאות עד למילה האחרונה המיושרת, לא כולל את המילה האחרונה המיושרת כשלעצמה שתיעשה בבדיקת הזנב מאוחר יותר, כדי להבטיח שהזנב הוא תמיד `usize` לכל היותר ל-branch `byte_pos == len` נוסף.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // שפיות לבדוק שהקריאה היא בגבולות
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // ושההנחות שלנו לגבי `byte_pos` מחזיקות.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // בטיחות: אנו יודעים ש-`word_ptr` מיושר כהלכה (בגלל
        // 'align_offset'), ואנחנו יודעים שיש לנו מספיק בתים בין `word_ptr` לסוף
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // בטיחות: אנו יודעים כי `byte_pos <= len - USIZE_SIZE`, כלומר
        // אחרי `add` זה, `word_ptr` יהיה לכל היותר אחד מהסוף.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // בדיקת שפיות כדי לוודא שנותר רק `usize` אחד.
    // זה צריך להיות מובטח על ידי מצב הלולאה שלנו.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // בטיחות: זה מסתמך על `len >= USIZE_SIZE`, אותו אנו בודקים בהתחלה.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}