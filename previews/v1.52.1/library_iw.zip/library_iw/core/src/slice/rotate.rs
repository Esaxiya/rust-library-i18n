// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// מסובב את הטווח `[mid-left, mid+right)` כך שהאלמנט ב-`mid` יהפוך לאלמנט הראשון.באופן שווה, מסובב את רכיבי `left` לטווח שמאלה או רכיבי `right` ימינה.
///
/// # Safety
///
/// הטווח שצוין חייב להיות תקף לקריאה וכתיבה.
///
/// # Algorithm
///
/// אלגוריתם 1 משמש לערכים קטנים של `left + right` או עבור `T` גדול.
/// האלמנטים מועברים למיקומם הסופי בזה אחר זה החל מ-`mid - left` ומתקדמים במדרגות `right` מודולו `left + right`, כך שיש צורך רק זמני אחד.
/// בסופו של דבר, אנחנו מגיעים חזרה ל-`mid - left`.
/// עם זאת, אם `gcd(left + right, right)` אינו 1, השלבים שלעיל דילגו על אלמנטים.
/// לדוגמה:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// למרבה המזל, מספר הדילוגים בין האלמנטים בין האלמנטים הסופיים תמיד שווה, כך שאנחנו יכולים פשוט לקזז את עמדת ההתחלה שלנו ולעשות יותר סיבובים (המספר הכולל של הסיבובים הוא `gcd(left + right, right)` value).
///
/// התוצאה הסופית היא שכל האלמנטים מסתיימים פעם אחת ופעם אחת בלבד.
///
/// משתמשים באלגוריתם 2 אם `left + right` גדול אך `min(left, right)` קטן מספיק כדי להתאים למאגר הערימה.
/// אלמנטים `min(left, right)` מועתקים על המאגר, `memmove` מוחל על האחרים, ואלה על המאגר מועברים חזרה לחור בצד הנגדי למקום בו הם מקורם.
///
/// אלגוריתמים הניתנים לווקטורציה עולים על האמור לעיל ברגע ש-`left + right` נהיה גדול מספיק.
/// ניתן ליצור וקטור של אלגוריתם 1 על ידי חתיכה וביצוע סיבובים רבים בבת אחת, אך ישנם מעט סיבובים בממוצע עד ש-`left + right` יהיה עצום, והמקרה הגרוע ביותר של סיבוב יחיד תמיד קיים.
/// במקום זאת, אלגוריתם 3 משתמש בהחלפה חוזרת של אלמנטים `min(left, right)` עד שנותרה בעיית סיבוב קטנה יותר.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// כאשר `left < right` ההחלפה מתרחשת משמאל במקום.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. האלגוריתמים שלהלן עלולים להיכשל אם מקרים אלה לא נבדקים
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // אלגוריתם 1 סימני מיקרו-בנצ'ים מצביעים על כך שהביצועים הממוצעים עבור משמרות אקראיות טובים יותר עד ל-`left + right == 32` בערך, אך הביצועים הגרועים ביותר נשברים אפילו בסביבות השעה 16.
            // 24 נבחרה כאמצע.
            // אם גודלו של `T` גדול מ-4 "גודל", האלגוריתם הזה עולה על אלגוריתמים אחרים.
            //
            //
            let x = unsafe { mid.sub(left) };
            // תחילת הסיבוב הראשון
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` ניתן למצוא לפני היד על ידי חישוב `gcd(left + right, right)`, אך מהיר יותר לעשות לולאה אחת המחשבת את ה-gcd כתופעת לוואי, ואז לבצע את שאר הנתח
            //
            //
            let mut gcd = right;
            // מדדים מגלים כי מהיר יותר להחליף זמניים לאורך כל הדרך במקום לקרוא פעם אחת אחת, להעתיק לאחור, ואז לכתוב אותה זמנית ממש בסוף.
            // זה אולי נובע מהעובדה שהחלפה או החלפה של זמני משתמשות בכתובת זיכרון אחת בלבד בלולאה במקום צורך לנהל שתיים.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // במקום להגדיל את `i` ואז לבדוק אם הוא נמצא מחוץ לתחום, אנחנו בודקים אם `i` יעבור מחוץ לתחום בתוספת הבאה.
                // זה מונע כל גלישת מצביעים או `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // סוף הסיבוב הראשון
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // תנאי זה חייב להיות כאן אם `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // לסיים את הנתח עם עוד סיבובים
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` אינו סוג בגודל אפס, אז זה בסדר לחלק לפי הגודל שלו.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // אלגוריתם 2 `[T; 0]` כאן הוא להבטיח כי זה מיושר כראוי עבור T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // אלגוריתם 3 קיימת דרך חלופית להחלפה הכוללת מציאת היכן תהיה ההחלפה האחרונה של האלגוריתם הזה, והחלפה באמצעות החלק האחרון האחרון במקום החלפת נתחים סמוכים כמו שעושה האלגוריתם הזה, אך דרך זו היא עדיין מהירה יותר.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // אלגוריתם 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}