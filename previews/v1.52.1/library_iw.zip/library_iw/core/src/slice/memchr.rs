// יישום מקורי שנלקח מ-rust-memchr.
// זכויות יוצרים 2015 אנדרו גלנט, בלוס וניקולה קוך

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// השתמש בקטיעה.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// מחזירה `true` אם `x` מכיל בתים אפסיים כלשהם.
///
/// מאת *ענייני חישוב*, ג'יי ארנדט:
///
/// "הרעיון הוא להפחית אחד מכל אחד מהבתים ואז לחפש בתים שבהם ההלוואה התפשטה עד המשמעותית ביותר
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// מחזיר את האינדקס הראשון התואם לבית `x` ב-`text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // נתיב מהיר לפרוסות קטנות
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // חפש ערך בתים בודדים על ידי קריאת שתי מילים `usize` בכל פעם.
    //
    // פיצול `text` בשלושה חלקים
    // - חלק ראשוני לא מיושר, לפני הכתובת המיושרת למילה הראשונה בטקסט
    // - גוף, סרוק לפי 2 מילים בכל פעם
    // - החלק שנותר האחרון, <גודל 2 מילים

    // חפש עד גבול מיושר
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // חיפוש בגוף הטקסט
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // בטיחות: הקבץ של זמן מבטיח מרחק של לפחות 2 * usize_bytes
        // בין הקיזוז לסוף הנתח.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // לשבור אם יש בתים תואמים
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // מצא את הבית אחרי הנקודה בה נעצר לולאת הגוף.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// מחזיר את האינדקס האחרון התואם לבית `x` ב-`text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // חפש ערך בתים בודדים על ידי קריאת שתי מילים `usize` בכל פעם.
    //
    // פיצול `text` בשלושה חלקים:
    // - זנב לא מיושר, אחרי הכתובת המיושרת האחרונה במילה בטקסט,
    // - גוף, נסרק בשתי מילים בכל פעם,
    // - הבתים הראשונים שנותרו, <גודל 2 מילים.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // אנו קוראים לזה רק כדי להשיג את אורך הקידומת והסיומת.
        // באמצע אנחנו תמיד מעבדים שני נתחים בבת אחת.
        // בטיחות: העברת `[u8]` ל-`[usize]` בטוחה למעט הבדלי גודל שטופלו על ידי `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // חפש בגוף הטקסט, וודא שלא נחצה את קצב ההפרשה min_aligned_.
    // קיזוז תמיד מיושר, כך שרק בדיקת `>` מספיקה ומונעת הצפה אפשרית.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // בטיחות: הקיזוז מתחיל ב-len, suffix.len(), כל עוד הוא גדול מ-
        // min_aligned_offset (prefix.len()) המרחק שנותר הוא לפחות 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // הפסקה אם יש בתים תואמים.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // מצא את הבית לפני הנקודה בה לולאת הגוף נעצרה.
    text[..offset].iter().rposition(|elt| *elt == x)
}