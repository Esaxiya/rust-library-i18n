//! טיפוסים אטומיים
//!
//! סוגים אטומיים מספקים תקשורת פרימיטיבית של זיכרון משותף בין חוטים, והם אבני הבניין של סוגים מקבילים אחרים.
//!
//! מודול זה מגדיר גרסאות אטומיות למספר נבחר של סוגים פרימיטיביים, כולל [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] וכו '.
//! סוגים אטומיים מציגים פעולות שכאשר משתמשים בהן נכון מסנכרנים עדכונים בין השרשור.
//!
//! כל שיטה לוקחת [`Ordering`] המייצג את חוזק מחסום הזיכרון לפעולה זו.הזמנות אלו זהות ל-[C++20 atomic orderings][1].למידע נוסף עיין ב-[nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! משתנים אטומיים בטוחים לשיתוף בין השרשור (הם מיישמים את [`Sync`]) אך הם אינם עצמם מספקים את מנגנון השיתוף ועוקבים אחר ה-[threading model](../../../std/thread/index.html#the-threading-model) של Rust.
//!
//! הדרך הנפוצה ביותר לשתף משתנה אטומי היא להכניס אותו ל-[`Arc`][arc] (מצביע משותף שנספר אטומית).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! ניתן לאחסן סוגים אטומיים במשתנים סטטיים, מאותחל באמצעות אתחולים קבועים כמו [`AtomicBool::new`].סטטיסטיקה אטומית משמשת לעיתים קרובות לאתחול גלובלי עצל.
//!
//! # Portability
//!
//! מובטח כי כל סוגי האטומים במודול זה יהיו [lock-free] אם הם זמינים.משמעות הדבר היא שהם לא רוכשים מוטציה עולמית באופן פנימי.לא מובטח כי סוגי אטומים ופעולות יהיו ללא המתנה.
//! המשמעות היא שפעולות כמו `fetch_or` עשויות להיות מיושמות באמצעות לולאת השוואה והחלפה.
//!
//! ניתן ליישם פעולות אטומיות בשכבת ההוראות עם אטומים גדולים יותר.לדוגמא, חלק מהפלטפורמות משתמשות בהוראות אטומיות בעלות 4 בתים ליישום `AtomicI8`.
//! שים לב כי לאמולציה זו לא אמורה להיות השפעה על תקינות הקוד, זה רק משהו שצריך להיות מודע אליו.
//!
//! ייתכן שהסוגים האטומיים במודול זה אינם זמינים בכל הפלטפורמות.הסוגים האטומיים כאן זמינים באופן נרחב, עם זאת, ובדרך כלל ניתן להסתמך על קיומם.כמה יוצאים מן הכלל הם:
//!
//! * PowerPC ולפלטפורמות MIPS עם מצביעי 32 סיביות אין סוגי `AtomicU64` או `AtomicI64`.
//! * ARM פלטפורמות כמו `armv5te` שאינן מיועדות ל-Linux מספקות פעולות `load` ו-`store` בלבד, ואינן תומכות בהשוואה והחלפת פעולות (CAS), כגון `swap`, `fetch_add` וכו '.
//! בנוסף ב-Linux, פעולות CAS אלה מיושמות באמצעות [operating system support], שעשויות להגיע לעונש ביצוע.
//! * ARM יעדים עם `thumbv6m` מספקים רק פעולות `load` ו-`store`, ואינם תומכים בהשוואה והחלפת פעולות (CAS), כגון `swap`, `fetch_add` וכו '.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! שים לב כי ניתן להוסיף פלטפורמות future שגם אין להן תמיכה בפעולות אטומיות מסוימות.קוד נייד מקסימאלי ירצה להיזהר באילו סוגי אטומים משתמשים.
//! `AtomicUsize` ו-`AtomicIsize` הם בדרך כלל הניידים ביותר, אבל גם אז הם לא זמינים בכל מקום.
//! לצורך התייחסות, ספריית `std` דורשת אטומיות בגודל מצביע, אם כי `core` לא.
//!
//! נכון לעכשיו תצטרך להשתמש ב-`#[cfg(target_arch)]` בעיקר כדי להרכיב באופן מותנה בקוד עם אטומים.יש גם `#[cfg(target_has_atomic)]` לא יציב אשר עשוי להיות מיוצב ב-future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! ספינלוק פשוט:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // המתן עד שהחוט השני ישחרר את המנעול
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! שמור על ספירה עולמית של אשכולות חיים:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// סוג בוליאני שניתן לחלוק בבטחה בין השרשור.
///
/// לסוג זה יש אותו ייצוג בזיכרון כמו [`bool`].
///
/// **הערה**: סוג זה זמין רק בפלטפורמות התומכות בעומסים אטומיים ובמאגרי `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// יוצר `AtomicBool` מאותחל ל-`false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// השליחה מיושמת באופן מרומז עבור AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// סוג מצביע גולמי שניתן לשתף בבטחה בין השרשור.
///
/// לסוג זה יש אותו ייצוג בזיכרון כמו `*mut T`.
///
/// **הערה**: סוג זה זמין רק בפלטפורמות התומכות בעומסים אטומיים ובמאגרי מצביעים.
/// גודלו תלוי בגודל מצביע היעד.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// יוצר `AtomicPtr<T>` אפס.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// סדרי זיכרון אטומיים
///
/// סדרי זיכרון מציינים את האופן שבו פעולות אטומיות מסנכרנות זיכרון.
/// ב-[`Ordering::Relaxed`] החלש ביותר שלו, רק הזיכרון שנגיעה בו ישירות על ידי הפעולה מסונכרן.
/// מצד שני, צמד עומסי חנות של פעולות [`Ordering::SeqCst`] מסנכרן זיכרון אחר תוך שמירה על הסדר הכולל של פעולות כאלה בכל הנושאים.
///
///
/// הזמנות הזיכרון של Rust הן [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// למידע נוסף עיין ב-[nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// אין אילוצי סדר, רק פעולות אטומיות.
    ///
    /// תואם ל-[`memory_order_relaxed`] ב-C ++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// בשילוב עם חנות, כל הפעולות הקודמות מוזמנות לפני כל עומס של ערך זה עם הזמנת [`Acquire`] (או יותר).
    ///
    /// בפרט, כל הכתיבות הקודמות הופכות לגלויות לכל הנושאים המבצעים עומס [`Acquire`] (או חזק יותר) של ערך זה.
    ///
    /// שימו לב כי שימוש בהזמנה זו לפעולה המשלבת עומסים ומאחסנים מובילה לפעולת עומס [`Relaxed`]!
    ///
    /// הזמנה זו חלה רק על פעולות שיכולות לבצע חנות.
    ///
    /// תואם ל-[`memory_order_release`] ב-C ++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// בשילוב עם עומס, אם הערך הטעון נכתב על ידי פעולת חנות עם הזמנת [`Release`] (או יותר), אז כל הפעולות הבאות הופכות להזמנה לאחר אותה חנות.
    /// בפרט, כל העומסים הבאים יראו נתונים שנכתבו לפני החנות.
    ///
    /// שימו לב כי שימוש בהזמנה זו לפעולה המשלבת עומסים ואחסנות מובילה לפעולת חנות [`Relaxed`]!
    ///
    /// הזמנה זו חלה רק על פעולות שיכולות לבצע עומס.
    ///
    /// תואם ל-[`memory_order_acquire`] ב-C ++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// יש את ההשפעות של [`Acquire`] ו-[`Release`] יחד:
    /// בעומסים הוא משתמש בהזמנת [`Acquire`].עבור חנויות הוא משתמש בהזמנת [`Release`].
    ///
    /// שימו לב שבמקרה של `compare_and_swap`, ייתכן שהפעולה בסופו של דבר לא מבצעת שום חנות ומכאן שיש לה הזמנת [`Acquire`] בלבד.
    ///
    /// עם זאת, `AcqRel` לעולם לא יבצע גישות ל-[`Relaxed`].
    ///
    /// הזמנה זו חלה רק על פעולות המשלבות מטענים וחנויות כאחד.
    ///
    /// תואם ל-[`memory_order_acq_rel`] ב-C ++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// כמו [`Acquire`]/[`Release`]/[`AcqRel`](עבור פעולות טעינה, חנות וטען עם חנות בהתאמה) עם אחריות נוספת שכל השרשור רואה את כל הפעולות העקביות ברצף באותו סדר .
    ///
    ///
    /// תואם ל-[`memory_order_seq_cst`] ב-C ++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] מאותחל ל-`false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// יוצר `AtomicBool` חדש.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// מחזירה הפניה משתנה ל-[`bool`] הבסיסי.
    ///
    /// זה בטוח מכיוון שההתייחסות המשתנה מבטיחה שאף חוטים אחרים אינם ניגשים במקביל לנתונים האטומיים.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // בטיחות: ההפניה המשתנה מבטיחה בעלות ייחודית.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// קבל גישה אטומית ל-`&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // בטיחות: ההתייחסות המשתנה מבטיחה בעלות ייחודית, ו
        // היישור של `bool` ו-`Self` הוא 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// צורכת את האטום ומחזירה את הערך הכלול.
    ///
    /// זה בטוח כי העברת `self` לפי ערך מבטיחה שאף חוטים אחרים אינם ניגשים במקביל לנתונים האטומיים.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// טוען ערך מ-bool.
    ///
    /// `load` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.
    /// הערכים האפשריים הם [`SeqCst`], [`Acquire`] ו-[`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics אם `order` הוא [`Release`] או [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // בטיחות: כל מירוצי נתונים מונעים על ידי הפנימיות האטומית והגולמיים
        // המצביע שהועבר תקף מכיוון שקיבלנו אותו מהפניה.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// שומר ערך ב-bool.
    ///
    /// `store` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.
    /// הערכים האפשריים הם [`SeqCst`], [`Release`] ו-[`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics אם `order` הוא [`Acquire`] או [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // בטיחות: כל מירוצי נתונים מונעים על ידי הפנימיות האטומית והגולמיים
        // המצביע שהועבר תקף מכיוון שקיבלנו אותו מהפניה.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// שומר ערך ב-bool ומחזיר את הערך הקודם.
    ///
    /// `swap` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.כל מצבי ההזמנה אפשריים.
    /// שים לב ששימוש ב-[`Acquire`] הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], ושימוש ב-[`Release`] הופך את החלק לטעון ל-[`Relaxed`].
    ///
    ///
    /// **Note:** שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב-`u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// שומר ערך ב-[`bool`] אם הערך הנוכחי זהה לערך `current`.
    ///
    /// ערך ההחזר הוא תמיד הערך הקודם.אם זה שווה ל-`current`, הערך עודכן.
    ///
    /// `compare_and_swap` לוקח גם טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.
    /// שים לב שגם בעת שימוש ב-[`AcqRel`], הפעולה עלולה להיכשל ולכן פשוט לבצע עומס `Acquire`, אך לא להיות בעל סמנטיקה של `Release`.
    /// השימוש ב-[`Acquire`] הופך את החנות לחלק מפעולה זו ל-[`Relaxed`] אם זה קורה, והשימוש ב-[`Release`] הופך את החלק לטעון ל-[`Relaxed`].
    ///
    /// **Note:** שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב-`u8`.
    ///
    /// # מעבר ל-`compare_exchange` ו-`compare_exchange_weak`
    ///
    /// `compare_and_swap` שווה ערך ל-`compare_exchange` עם המיפוי הבא להזמנות זיכרון:
    ///
    /// מקורי |הצלחה |כישלון
    /// -------- | ------- | -------
    /// נינוח |נינוח |רוכש רגוע |לרכוש |רכישת שחרור |שחרור |AcqRel רגוע |AcqRel |לרכוש SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` מותר להיכשל באופן מזויף גם כאשר ההשוואה מצליחה, מה שמאפשר למהדר לייצר קוד הרכבה טוב יותר כאשר נעשה שימוש בהשוואה והחלפה.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// שומר ערך ב-[`bool`] אם הערך הנוכחי זהה לערך `current`.
    ///
    /// ערך ההחזר הוא תוצאה המציינת האם הערך החדש נכתב ומכיל את הערך הקודם.
    /// בהצלחה ערך זה מובטח להיות שווה ל-`current`.
    ///
    /// `compare_exchange` לוקח שני ארגומנטים של [`Ordering`] כדי לתאר את סדר הזיכרון של פעולה זו.
    /// `success` מתאר את הסדר הנדרש עבור פעולת הקריאה-שינוי-כתיבה המתרחשת אם ההשוואה עם `current` מצליחה.
    /// `failure` מתאר את ההזמנה הנדרשת עבור פעולת הטעינה המתרחשת כאשר ההשוואה נכשלת.
    /// השימוש ב-[`Acquire`] כהזמנת הצלחה הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], והשימוש ב-[`Release`] הופך את העומס המוצלח ל-[`Relaxed`].
    ///
    /// הזמנת הכשל יכולה להיות רק [`SeqCst`], [`Acquire`] או [`Relaxed`] וחייבת להיות שווה ערך או חלשה יותר מהזמנת ההצלחה.
    ///
    /// **Note:** שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב-`u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// שומר ערך ב-[`bool`] אם הערך הנוכחי זהה לערך `current`.
    ///
    /// בניגוד ל-[`AtomicBool::compare_exchange`], פונקציה זו מותרת להיכשל באופן מזויף גם כאשר ההשוואה מצליחה, מה שעלול לגרום לקוד יעיל יותר בפלטפורמות מסוימות.
    ///
    /// ערך ההחזר הוא תוצאה המציינת האם הערך החדש נכתב ומכיל את הערך הקודם.
    ///
    /// `compare_exchange_weak` לוקח שני ארגומנטים של [`Ordering`] כדי לתאר את סדר הזיכרון של פעולה זו.
    /// `success` מתאר את הסדר הנדרש עבור פעולת הקריאה-שינוי-כתיבה המתרחשת אם ההשוואה עם `current` מצליחה.
    /// `failure` מתאר את ההזמנה הנדרשת עבור פעולת הטעינה המתרחשת כאשר ההשוואה נכשלת.
    /// השימוש ב-[`Acquire`] כהזמנת הצלחה הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], והשימוש ב-[`Release`] הופך את העומס המוצלח ל-[`Relaxed`].
    /// הזמנת הכשל יכולה להיות רק [`SeqCst`], [`Acquire`] או [`Relaxed`] וחייבת להיות שווה ערך או חלשה יותר מהזמנת ההצלחה.
    ///
    /// **Note:** שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב-`u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// "and" לוגי עם ערך בוליאני.
    ///
    /// מבצע פעולת "and" לוגית על הערך הנוכחי והארגומנט `val`, ומגדיר את הערך החדש לתוצאה.
    ///
    /// מחזירה את הערך הקודם.
    ///
    /// `fetch_and` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.כל מצבי ההזמנה אפשריים.
    /// שים לב ששימוש ב-[`Acquire`] הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], ושימוש ב-[`Release`] הופך את החלק לטעון ל-[`Relaxed`].
    ///
    ///
    /// **Note:** שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב-`u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// "nand" לוגי עם ערך בוליאני.
    ///
    /// מבצע פעולת "nand" לוגית על הערך הנוכחי והארגומנט `val`, ומגדיר את הערך החדש לתוצאה.
    ///
    /// מחזירה את הערך הקודם.
    ///
    /// `fetch_nand` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.כל מצבי ההזמנה אפשריים.
    /// שים לב ששימוש ב-[`Acquire`] הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], ושימוש ב-[`Release`] הופך את החלק לטעון ל-[`Relaxed`].
    ///
    ///
    /// **Note:** שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב-`u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // אנחנו לא יכולים להשתמש כאן ב atomic_nand כי זה יכול לגרום ל-bool עם ערך לא חוקי.
        // זה קורה מכיוון שהפעולה האטומית נעשית עם מספר שלם של 8 סיביות באופן פנימי, שיקבע את 7 הסיביות העליונות.
        //
        // אז פשוט נשתמש ב-fetch_xor או בהחלפה.
        if val {
            // ! (x&true)== !x עלינו להפוך את bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true עלינו להגדיר את bool ל-true.
            //
            self.swap(true, order)
        }
    }

    /// "or" לוגי עם ערך בוליאני.
    ///
    /// מבצע פעולת "or" לוגית על הערך הנוכחי והארגומנט `val`, ומגדיר את הערך החדש לתוצאה.
    ///
    /// מחזירה את הערך הקודם.
    ///
    /// `fetch_or` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.כל מצבי ההזמנה אפשריים.
    /// שים לב ששימוש ב-[`Acquire`] הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], ושימוש ב-[`Release`] הופך את החלק לטעון ל-[`Relaxed`].
    ///
    ///
    /// **Note:** שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב-`u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// "xor" לוגי עם ערך בוליאני.
    ///
    /// מבצע פעולת "xor" לוגית על הערך הנוכחי והארגומנט `val`, ומגדיר את הערך החדש לתוצאה.
    ///
    /// מחזירה את הערך הקודם.
    ///
    /// `fetch_xor` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.כל מצבי ההזמנה אפשריים.
    /// שים לב ששימוש ב-[`Acquire`] הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], ושימוש ב-[`Release`] הופך את החלק לטעון ל-[`Relaxed`].
    ///
    ///
    /// **Note:** שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב-`u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// מחזיר מצביע משתנה ל-[`bool`] הבסיסי.
    ///
    /// ביצוע קריאה וכתיבה לא אטומית על המספר השלם המתקבל יכול להיות גזע נתונים.
    /// שיטה זו שימושית בעיקר עבור FFI, כאשר חתימת הפונקציה עשויה להשתמש ב-`*mut bool` במקום ב-`&AtomicBool`.
    ///
    /// החזרת מצביע `*mut` מהתייחסות משותפת לאטום זה בטוחה מכיוון שסוגי האטום עובדים עם מוטציה פנימית.
    /// כל השינויים של אטום משנים את הערך באמצעות הפניה משותפת, ויכולים לעשות זאת בבטחה כל עוד הם משתמשים בפעולות אטומיות.
    /// כל שימוש במצביע הגולמי המוחזר דורש חסימת `unsafe` ועדיין צריך לשמור על אותה מגבלה: הפעולות עליו חייבות להיות אטומיות.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// מביא את הערך ומחיל עליו פונקציה המחזירה ערך חדש אופציונלי.מחזירה `Result` של `Ok(previous_value)` אם הפונקציה החזירה `Some(_)`, אחרת `Err(previous_value)`.
    ///
    /// Note: זה עשוי לקרוא לפונקציה מספר פעמים אם הערך הוחלף משרשורים אחרים בינתיים, כל עוד הפונקציה מחזירה `Some(_)`, אך הפונקציה תוחל רק פעם אחת על הערך המאוחסן.
    ///
    ///
    /// `fetch_update` לוקח שני ארגומנטים של [`Ordering`] כדי לתאר את סדר הזיכרון של פעולה זו.
    /// הראשון מתאר את ההזמנה הנדרשת כאשר הפעולה תצליח לבסוף ואילו השנייה מתארת את ההזמנה הנדרשת לעומסים.
    /// אלה תואמים להזמנות ההצלחה והכישלון של [`AtomicBool::compare_exchange`] בהתאמה.
    ///
    /// השימוש ב-[`Acquire`] כהזמנת הצלחה הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], והשימוש ב-[`Release`] הופך את העומס המוצלח הסופי ל-[`Relaxed`].
    /// הזמנת העומס (failed) יכולה להיות רק [`SeqCst`], [`Acquire`] או [`Relaxed`] וחייבת להיות שווה ערך או חלשה יותר מהזמנת ההצלחה.
    ///
    /// **Note:** שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב-`u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// יוצר `AtomicPtr` חדש.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// מחזירה הפניה משתנה למצביע הבסיסי.
    ///
    /// זה בטוח מכיוון שההתייחסות המשתנה מבטיחה שאף חוטים אחרים אינם ניגשים במקביל לנתונים האטומיים.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// קבל גישה אטומית למצביע.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - ההפניה המשתנה מבטיחה בעלות ייחודית.
        //  - היישור של `*mut T` ו-`Self` זהה בכל הפלטפורמות הנתמכות על ידי rust, כמאושר לעיל.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// צורכת את האטום ומחזירה את הערך הכלול.
    ///
    /// זה בטוח כי העברת `self` לפי ערך מבטיחה שאף חוטים אחרים אינם ניגשים במקביל לנתונים האטומיים.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// טוען ערך מהמצביע.
    ///
    /// `load` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.
    /// הערכים האפשריים הם [`SeqCst`], [`Acquire`] ו-[`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics אם `order` הוא [`Release`] או [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// שומר ערך בסמן.
    ///
    /// `store` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.
    /// הערכים האפשריים הם [`SeqCst`], [`Release`] ו-[`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics אם `order` הוא [`Acquire`] או [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// שומר ערך במצביע ומחזיר את הערך הקודם.
    ///
    /// `swap` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.כל מצבי ההזמנה אפשריים.
    /// שים לב ששימוש ב-[`Acquire`] הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], ושימוש ב-[`Release`] הופך את החלק לטעון ל-[`Relaxed`].
    ///
    ///
    /// **Note:** שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות על מצביעים.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// שומר ערך במצביע אם הערך הנוכחי זהה לערך `current`.
    ///
    /// ערך ההחזר הוא תמיד הערך הקודם.אם זה שווה ל-`current`, הערך עודכן.
    ///
    /// `compare_and_swap` לוקח גם טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.
    /// שים לב שגם בעת שימוש ב-[`AcqRel`], הפעולה עלולה להיכשל ולכן פשוט לבצע עומס `Acquire`, אך לא להיות בעל סמנטיקה של `Release`.
    /// השימוש ב-[`Acquire`] הופך את החנות לחלק מפעולה זו ל-[`Relaxed`] אם זה קורה, והשימוש ב-[`Release`] הופך את החלק לטעון ל-[`Relaxed`].
    ///
    /// **Note:** שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות על מצביעים.
    ///
    /// # מעבר ל-`compare_exchange` ו-`compare_exchange_weak`
    ///
    /// `compare_and_swap` שווה ערך ל-`compare_exchange` עם המיפוי הבא להזמנות זיכרון:
    ///
    /// מקורי |הצלחה |כישלון
    /// -------- | ------- | -------
    /// נינוח |נינוח |רוכש רגוע |לרכוש |רכישת שחרור |שחרור |AcqRel רגוע |AcqRel |לרכוש SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` מותר להיכשל באופן מזויף גם כאשר ההשוואה מצליחה, מה שמאפשר למהדר לייצר קוד הרכבה טוב יותר כאשר נעשה שימוש בהשוואה והחלפה.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// שומר ערך במצביע אם הערך הנוכחי זהה לערך `current`.
    ///
    /// ערך ההחזר הוא תוצאה המציינת האם הערך החדש נכתב ומכיל את הערך הקודם.
    /// בהצלחה ערך זה מובטח להיות שווה ל-`current`.
    ///
    /// `compare_exchange` לוקח שני ארגומנטים של [`Ordering`] כדי לתאר את סדר הזיכרון של פעולה זו.
    /// `success` מתאר את הסדר הנדרש עבור פעולת הקריאה-שינוי-כתיבה המתרחשת אם ההשוואה עם `current` מצליחה.
    /// `failure` מתאר את ההזמנה הנדרשת עבור פעולת הטעינה המתרחשת כאשר ההשוואה נכשלת.
    /// השימוש ב-[`Acquire`] כהזמנת הצלחה הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], והשימוש ב-[`Release`] הופך את העומס המוצלח ל-[`Relaxed`].
    ///
    /// הזמנת הכשל יכולה להיות רק [`SeqCst`], [`Acquire`] או [`Relaxed`] וחייבת להיות שווה ערך או חלשה יותר מהזמנת ההצלחה.
    ///
    /// **Note:** שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות על מצביעים.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// שומר ערך במצביע אם הערך הנוכחי זהה לערך `current`.
    ///
    /// בניגוד ל-[`AtomicPtr::compare_exchange`], פונקציה זו מותרת להיכשל באופן מזויף גם כאשר ההשוואה מצליחה, מה שעלול לגרום לקוד יעיל יותר בפלטפורמות מסוימות.
    ///
    /// ערך ההחזר הוא תוצאה המציינת האם הערך החדש נכתב ומכיל את הערך הקודם.
    ///
    /// `compare_exchange_weak` לוקח שני ארגומנטים של [`Ordering`] כדי לתאר את סדר הזיכרון של פעולה זו.
    /// `success` מתאר את הסדר הנדרש עבור פעולת הקריאה-שינוי-כתיבה המתרחשת אם ההשוואה עם `current` מצליחה.
    /// `failure` מתאר את ההזמנה הנדרשת עבור פעולת הטעינה המתרחשת כאשר ההשוואה נכשלת.
    /// השימוש ב-[`Acquire`] כהזמנת הצלחה הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], והשימוש ב-[`Release`] הופך את העומס המוצלח ל-[`Relaxed`].
    /// הזמנת הכשל יכולה להיות רק [`SeqCst`], [`Acquire`] או [`Relaxed`] וחייבת להיות שווה ערך או חלשה יותר מהזמנת ההצלחה.
    ///
    /// **Note:** שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות על מצביעים.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // בטיחות: הפנימיות הזו אינה בטוחה מכיוון שהיא פועלת על מצביע גולמי
        // אך אנו יודעים בוודאות שהמצביע תקף (הרגע קיבלנו אותו מ-`UnsafeCell` שיש לנו בהפניה) והפעולה האטומית עצמה מאפשרת לנו לשנות בבטחה את תוכן ה-`UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// מביא את הערך ומחיל עליו פונקציה המחזירה ערך חדש אופציונלי.מחזירה `Result` של `Ok(previous_value)` אם הפונקציה החזירה `Some(_)`, אחרת `Err(previous_value)`.
    ///
    /// Note: זה עשוי לקרוא לפונקציה מספר פעמים אם הערך הוחלף משרשורים אחרים בינתיים, כל עוד הפונקציה מחזירה `Some(_)`, אך הפונקציה תוחל רק פעם אחת על הערך המאוחסן.
    ///
    ///
    /// `fetch_update` לוקח שני ארגומנטים של [`Ordering`] כדי לתאר את סדר הזיכרון של פעולה זו.
    /// הראשון מתאר את ההזמנה הנדרשת כאשר הפעולה תצליח לבסוף ואילו השנייה מתארת את ההזמנה הנדרשת לעומסים.
    /// אלה תואמים להזמנות ההצלחה והכישלון של [`AtomicPtr::compare_exchange`] בהתאמה.
    ///
    /// השימוש ב-[`Acquire`] כהזמנת הצלחה הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], והשימוש ב-[`Release`] הופך את העומס המוצלח הסופי ל-[`Relaxed`].
    /// הזמנת העומס (failed) יכולה להיות רק [`SeqCst`], [`Acquire`] או [`Relaxed`] וחייבת להיות שווה ערך או חלשה יותר מהזמנת ההצלחה.
    ///
    /// **Note:** שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות על מצביעים.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// ממיר `bool` ל-`AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // בסופו של דבר, המאקרו הזה אינו בשימוש בחלק מהארכיטקטורות.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// סוג שלם אשר ניתן לשתף בבטחה בין שרשור.
        ///
        /// לסוג זה יש ייצוג בזיכרון זהה לסוג המספר השלם הבסיסי, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// לקבלת מידע נוסף על ההבדלים בין סוגי אטומים לסוגים שאינם אטומים, כמו גם מידע אודות הניידות מסוג זה, עיין ב-[module-level documentation].
        ///
        ///
        /// **Note:** סוג זה זמין רק בפלטפורמות התומכות בעומסים אטומיים ובחנויות של [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// מספר שלם אטומי מאותחל ל-`0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // השליחה מיושמת באופן מרומז.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// יוצר מספר שלם אטומי חדש.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// מחזירה הפניה משתנה למספר השלם הבסיסי.
            ///
            /// זה בטוח מכיוון שההתייחסות המשתנה מבטיחה שאף חוטים אחרים אינם ניגשים במקביל לנתונים האטומיים.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// תן למוט some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - ההפניה המשתנה מבטיחה בעלות ייחודית.
                //  - היישור של `$int_type` ו-`Self` זהה, כפי שהובטח על ידי $cfg_align ואומת לעיל.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// צורכת את האטום ומחזירה את הערך הכלול.
            ///
            /// זה בטוח כי העברת `self` לפי ערך מבטיחה שאף חוטים אחרים אינם ניגשים במקביל לנתונים האטומיים.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// טוען ערך מהמספר השלם האטומי.
            ///
            /// `load` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.
            /// הערכים האפשריים הם [`SeqCst`], [`Acquire`] ו-[`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics אם `order` הוא [`Release`] או [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// שומר ערך במספר השלם האטומי.
            ///
            /// `store` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.
            ///  הערכים האפשריים הם [`SeqCst`], [`Release`] ו-[`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics אם `order` הוא [`Acquire`] או [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// שומר ערך במספר השלם האטומי, ומחזיר את הערך הקודם.
            ///
            /// `swap` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.כל מצבי ההזמנה אפשריים.
            /// שים לב ששימוש ב-[`Acquire`] הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], ושימוש ב-[`Release`] הופך את החלק לטעון ל-[`Relaxed`].
            ///
            ///
            /// **הערה**: שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// שומר ערך במספר השלם האטומי אם הערך הנוכחי זהה לערך `current`.
            ///
            /// ערך ההחזר הוא תמיד הערך הקודם.אם זה שווה ל-`current`, הערך עודכן.
            ///
            /// `compare_and_swap` לוקח גם טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.
            /// שים לב שגם בעת שימוש ב-[`AcqRel`], הפעולה עלולה להיכשל ולכן פשוט לבצע עומס `Acquire`, אך לא להיות בעל סמנטיקה של `Release`.
            ///
            /// השימוש ב-[`Acquire`] הופך את החנות לחלק מפעולה זו ל-[`Relaxed`] אם זה קורה, והשימוש ב-[`Release`] הופך את החלק לטעון ל-[`Relaxed`].
            ///
            /// **הערה**: שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # מעבר ל-`compare_exchange` ו-`compare_exchange_weak`
            ///
            /// `compare_and_swap` שווה ערך ל-`compare_exchange` עם המיפוי הבא להזמנות זיכרון:
            ///
            /// מקורי |הצלחה |כישלון
            /// -------- | ------- | -------
            /// נינוח |נינוח |רוכש רגוע |לרכוש |רכישת שחרור |שחרור |AcqRel רגוע |AcqRel |לרכוש SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` מותר להיכשל באופן מזויף גם כאשר ההשוואה מצליחה, מה שמאפשר למהדר לייצר קוד הרכבה טוב יותר כאשר נעשה שימוש בהשוואה והחלפה.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// שומר ערך במספר השלם האטומי אם הערך הנוכחי זהה לערך `current`.
            ///
            /// ערך ההחזר הוא תוצאה המציינת האם הערך החדש נכתב ומכיל את הערך הקודם.
            /// בהצלחה ערך זה מובטח להיות שווה ל-`current`.
            ///
            /// `compare_exchange` לוקח שני ארגומנטים של [`Ordering`] כדי לתאר את סדר הזיכרון של פעולה זו.
            /// `success` מתאר את הסדר הנדרש עבור פעולת הקריאה-שינוי-כתיבה המתרחשת אם ההשוואה עם `current` מצליחה.
            /// `failure` מתאר את ההזמנה הנדרשת עבור פעולת הטעינה המתרחשת כאשר ההשוואה נכשלת.
            /// השימוש ב-[`Acquire`] כהזמנת הצלחה הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], והשימוש ב-[`Release`] הופך את העומס המוצלח ל-[`Relaxed`].
            ///
            /// הזמנת הכשל יכולה להיות רק [`SeqCst`], [`Acquire`] או [`Relaxed`] וחייבת להיות שווה ערך או חלשה יותר מהזמנת ההצלחה.
            ///
            /// **הערה**: שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// שומר ערך במספר השלם האטומי אם הערך הנוכחי זהה לערך `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// פונקציה זו מותרת להיכשל באופן מזויף גם כאשר ההשוואה מצליחה, מה שעלול לגרום לקוד יעיל יותר בפלטפורמות מסוימות.
            /// ערך ההחזר הוא תוצאה המציינת האם הערך החדש נכתב ומכיל את הערך הקודם.
            ///
            /// `compare_exchange_weak` לוקח שני ארגומנטים של [`Ordering`] כדי לתאר את סדר הזיכרון של פעולה זו.
            /// `success` מתאר את הסדר הנדרש עבור פעולת הקריאה-שינוי-כתיבה המתרחשת אם ההשוואה עם `current` מצליחה.
            /// `failure` מתאר את ההזמנה הנדרשת עבור פעולת הטעינה המתרחשת כאשר ההשוואה נכשלת.
            /// השימוש ב-[`Acquire`] כהזמנת הצלחה הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], והשימוש ב-[`Release`] הופך את העומס המוצלח ל-[`Relaxed`].
            ///
            /// הזמנת הכשל יכולה להיות רק [`SeqCst`], [`Acquire`] או [`Relaxed`] וחייבת להיות שווה ערך או חלשה יותר מהזמנת ההצלחה.
            ///
            /// **הערה**: שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// תן mut ישן= val.load(Ordering::Relaxed);
            /// לולאה {let new=old * 2;
            ///     להתאים val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// מוסיף לערך הנוכחי ומחזיר את הערך הקודם.
            ///
            /// פעולה זו עוטפת על הצפה.
            ///
            /// `fetch_add` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.כל מצבי ההזמנה אפשריים.
            /// שים לב ששימוש ב-[`Acquire`] הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], ושימוש ב-[`Release`] הופך את החלק לטעון ל-[`Relaxed`].
            ///
            ///
            /// **הערה**: שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// מחסר מהערך הנוכחי ומחזיר את הערך הקודם.
            ///
            /// פעולה זו עוטפת על הצפה.
            ///
            /// `fetch_sub` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.כל מצבי ההזמנה אפשריים.
            /// שים לב ששימוש ב-[`Acquire`] הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], ושימוש ב-[`Release`] הופך את החלק לטעון ל-[`Relaxed`].
            ///
            ///
            /// **הערה**: שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" עם הערך הנוכחי.
            ///
            /// מבצע פעולת "and" בצורה חכמה על הערך הנוכחי והארגומנט `val`, ומגדיר את הערך החדש לתוצאה.
            ///
            /// מחזירה את הערך הקודם.
            ///
            /// `fetch_and` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.כל מצבי ההזמנה אפשריים.
            /// שים לב ששימוש ב-[`Acquire`] הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], ושימוש ב-[`Release`] הופך את החלק לטעון ל-[`Relaxed`].
            ///
            ///
            /// **הערה**: שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" עם הערך הנוכחי.
            ///
            /// מבצע פעולת "nand" בצורה חכמה על הערך הנוכחי והארגומנט `val`, ומגדיר את הערך החדש לתוצאה.
            ///
            /// מחזירה את הערך הקודם.
            ///
            /// `fetch_nand` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.כל מצבי ההזמנה אפשריים.
            /// שים לב ששימוש ב-[`Acquire`] הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], ושימוש ב-[`Release`] הופך את החלק לטעון ל-[`Relaxed`].
            ///
            ///
            /// **הערה**: שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" עם הערך הנוכחי.
            ///
            /// מבצע פעולת "or" בצורה חכמה על הערך הנוכחי והארגומנט `val`, ומגדיר את הערך החדש לתוצאה.
            ///
            /// מחזירה את הערך הקודם.
            ///
            /// `fetch_or` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.כל מצבי ההזמנה אפשריים.
            /// שים לב ששימוש ב-[`Acquire`] הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], ושימוש ב-[`Release`] הופך את החלק לטעון ל-[`Relaxed`].
            ///
            ///
            /// **הערה**: שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" עם הערך הנוכחי.
            ///
            /// מבצע פעולת "xor" בצורה חכמה על הערך הנוכחי והארגומנט `val`, ומגדיר את הערך החדש לתוצאה.
            ///
            /// מחזירה את הערך הקודם.
            ///
            /// `fetch_xor` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.כל מצבי ההזמנה אפשריים.
            /// שים לב ששימוש ב-[`Acquire`] הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], ושימוש ב-[`Release`] הופך את החלק לטעון ל-[`Relaxed`].
            ///
            ///
            /// **הערה**: שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// מביא את הערך ומחיל עליו פונקציה המחזירה ערך חדש אופציונלי.מחזירה `Result` של `Ok(previous_value)` אם הפונקציה החזירה `Some(_)`, אחרת `Err(previous_value)`.
            ///
            /// Note: זה עשוי לקרוא לפונקציה מספר פעמים אם הערך הוחלף משרשורים אחרים בינתיים, כל עוד הפונקציה מחזירה `Some(_)`, אך הפונקציה תוחל רק פעם אחת על הערך המאוחסן.
            ///
            ///
            /// `fetch_update` לוקח שני ארגומנטים של [`Ordering`] כדי לתאר את סדר הזיכרון של פעולה זו.
            /// הראשון מתאר את ההזמנה הנדרשת כאשר הפעולה תצליח לבסוף ואילו השנייה מתארת את ההזמנה הנדרשת לעומסים.אלה תואמים לסדרי ההצלחה והכישלון של
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// השימוש ב-[`Acquire`] כהזמנת הצלחה הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], והשימוש ב-[`Release`] הופך את העומס המוצלח הסופי ל-[`Relaxed`].
            /// הזמנת העומס (failed) יכולה להיות רק [`SeqCst`], [`Acquire`] או [`Relaxed`] וחייבת להיות שווה ערך או חלשה יותר מהזמנת ההצלחה.
            ///
            /// **הערה**: שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (הזמנה: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (הזמנה: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// מקסימום עם הערך הנוכחי.
            ///
            /// מוצא את המקסימום של הערך הנוכחי ואת הארגומנט `val`, וקובע את הערך החדש לתוצאה.
            ///
            /// מחזירה את הערך הקודם.
            ///
            /// `fetch_max` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.כל מצבי ההזמנה אפשריים.
            /// שים לב ששימוש ב-[`Acquire`] הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], ושימוש ב-[`Release`] הופך את החלק לטעון ל-[`Relaxed`].
            ///
            ///
            /// **הערה**: שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// תן בר=42;
            /// תן max_foo=foo.fetch_max (סרגל, Ordering::SeqCst).max(bar);
            /// טוענים! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// מינימום עם הערך הנוכחי.
            ///
            /// מוצא את המינימום של הערך הנוכחי ואת הארגומנט `val`, ומגדיר את הערך החדש לתוצאה.
            ///
            /// מחזירה את הערך הקודם.
            ///
            /// `fetch_min` לוקח טיעון [`Ordering`] המתאר את סדר הזיכרון של פעולה זו.כל מצבי ההזמנה אפשריים.
            /// שים לב ששימוש ב-[`Acquire`] הופך את החנות לחלק מפעולה זו ל-[`Relaxed`], ושימוש ב-[`Release`] הופך את החלק לטעון ל-[`Relaxed`].
            ///
            ///
            /// **הערה**: שיטה זו זמינה רק בפלטפורמות התומכות בפעולות אטומיות ב
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// תן בר=12;
            /// תן ל-min_foo=foo.fetch_min (סרגל, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // בטיחות: מירוצי נתונים מונעים על ידי פנימיות אטומית.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// מחזיר מצביע משתנה למספר השלם הבסיסי.
            ///
            /// ביצוע קריאה וכתיבה לא אטומית על המספר השלם המתקבל יכול להיות גזע נתונים.
            /// שיטה זו שימושית בעיקר עבור FFI, שם חתימת הפונקציה עשויה להשתמש
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// החזרת מצביע `*mut` מהתייחסות משותפת לאטום זה בטוחה מכיוון שסוגי האטום עובדים עם מוטציה פנימית.
            /// כל השינויים של אטום משנים את הערך באמצעות הפניה משותפת, ויכולים לעשות זאת בבטחה כל עוד הם משתמשים בפעולות אטומיות.
            /// כל שימוש במצביע הגולמי המוחזר דורש חסימת `unsafe` ועדיין צריך לשמור על אותה מגבלה: הפעולות עליו חייבות להיות אטומיות.
            ///
            ///
            /// # Examples
            ///
            /// "התעלם מ-(extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// "C" חיצוני {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // בטיחות: בטוח כל עוד `my_atomic_op` הוא אטומי.
            /// לא בטוח {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// מחזיר את הערך הקודם (כמו __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// מחזירה את הערך הקודם (כמו __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// מחזירה את הערך המקסימלי (השוואה חתומה)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// מחזירה את הערך המינימלי (השוואה חתומה)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// מחזירה את הערך המקסימלי (השוואה לא חתומה)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// מחזירה את הערך המינימלי (השוואה לא חתומה)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// גדר אטומית.
///
/// בהתאם לסדר שצוין, גדר מונעת מהמהדר והמעבד לסדר מחדש סוגים מסוימים של פעולות זיכרון סביבו.
/// זה יוצר סנכרון עם יחסים בינו לבין פעולות אטומיות או גדרות בחוטים אחרים.
///
/// גדר 'A' שיש לה (לפחות) סמנטיקה מזמינה [`Release`], מסתנכרנת עם גדר 'B' עם סמנטיקה [`Acquire`] (לפחות), אם ורק אם קיימים פעולות X ו-Y, שתיהן פועלות על אובייקט אטומי כלשהו 'M' כזה ש-A רצף לפני X, Y מסונכרן לפני B ו-Y מתבונן בשינוי ל-M.
/// זה מספק תלות שקורה לפני A ו-B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// פעולות אטומיות עם סמנטיקה [`Release`] או [`Acquire`] יכולות גם להסתנכרן עם גדר.
///
/// גדר שיש בה הזמנת [`SeqCst`], בנוסף להיותה סמנטיקה [`Acquire`] ו-[`Release`], משתתפת בסדר התוכנית הגלובלי של פעולות ו/או גדרות [`SeqCst`] האחרות.
///
/// מקבל הזמנות [`Acquire`], [`Release`], [`AcqRel`] ו-[`SeqCst`].
///
/// # Panics
///
/// Panics אם `order` הוא [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // פרימיטיבי של הדרה הדדית המבוסס על ספינלוק.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // המתן עד שהערך הישן יהיה `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // גדר זו מסתנכרנת עם חנות ב-`unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // בטיחות: שימוש בגדר אטומית הוא בטוח.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// גדר זיכרון מהדר.
///
/// `compiler_fence` אינו פולט שום קוד מכונה, אך מגביל את סוגי הזיכרון שמותר להזמין מחדש למהדר.באופן ספציפי, תלוי בסמנטיקה [`Ordering`] הנתונה, מהנדס עשוי להיות מנוע מלהעביר קריאות או כתיבה מלפני או אחרי השיחה לצד השני של השיחה ל-`compiler_fence`.שים לב שהוא **לא** מונע מ-*החומרה* לבצע הזמנה מחדש כזו.
///
/// זו לא בעיה בהקשר ביצוע עם הברגה אחת, אך כאשר שרשורים אחרים עשויים לשנות את הזיכרון בו זמנית, נדרשים פרימיטיביים חזקים יותר לסינכרון כגון [`fence`].
///
/// ההזמנה מחדש שנמנעה על ידי סמנטיקה שונה של ההזמנות היא:
///
///  - עם [`SeqCst`], לא ניתן להזמין מחדש קריאות וכתיבה על פני נקודה זו.
///  - עם [`Release`], לא ניתן להעביר את הקריאות והכתיבה הקודמות מעבר לכתיבות הבאות.
///  - עם [`Acquire`], לא ניתן להזיז את הקריאות והכתיבה הבאים לפני הקריאות הקודמות.
///  - עם [`AcqRel`], שני הכללים לעיל נאכפים.
///
/// `compiler_fence` הוא בדרך כלל שימושי רק למניעת חוט מתחרה *עם עצמו*.כלומר, אם שרשור נתון מבצע פיסת קוד אחת, ואז הוא נקטע, ומתחיל לבצע קוד במקום אחר (בעודו עדיין באותו פתיל, ומושגית עדיין על אותה ליבה).בתוכניות מסורתיות זה יכול להתרחש רק כאשר מטפל באותות נרשם.
/// בקוד ברמה נמוכה יותר, מצבים כאלו יכולים להיווצר גם בעת טיפול בהפרעות, בעת יישום שרשורים ירוקים עם קדם-אישור וכו '.
/// קוראים סקרנים מוזמנים לקרוא את הדיון של ליבת Linux על [memory barriers].
///
/// # Panics
///
/// Panics אם `order` הוא [`Relaxed`].
///
/// # Examples
///
/// ללא `compiler_fence`, ה-`assert_eq!` בקוד הבא *לא* מובטח להצליח, למרות שהכל קורה בשרשור אחד.
/// כדי לראות מדוע, זכרו כי המהדר חופשי להחליף את החנויות ל-`IMPORTANT_VARIABLE` ו-`IS_READ` מכיוון ששניהם `Ordering::Relaxed`.אם כן, ומטפל האות יופעל מיד לאחר עדכון `IS_READY`, אז המטפל באיתות יראה `IS_READY=1`, אך `IMPORTANT_VARIABLE=0`.
/// שימוש ב-`compiler_fence` פותר מצב זה.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // למנוע מלהעביר כתבים קודמים מעבר לנקודה זו
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // בטיחות: שימוש בגדר אטומית הוא בטוח.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// מאותת למעבד שהוא נמצא בתוך לולאת ספין עמוסה להמתין ("נעילת סיבוב").
///
/// פונקציה זו הוצאה משימוש לטובת [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}