//! פנימיות מהדר.
//!
//! ההגדרות המקבילות הן ב-`compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! היישומים המתאימים של const נמצאים ב-`compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # פנימיות קונסט
//!
//! Note: יש לדון עם צוות השפה בכל שינוי בקביעות הפנימיות.
//! זה כולל שינויים ביציבות הקונסטיות.
//!
//! על מנת להפוך את הפנימי לשמיש בזמן הקומפילציה, יש להעתיק את היישום מ-<https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> ל-`compiler/rustc_mir/src/interpret/intrinsics.rs` ולהוסיף `#[rustc_const_unstable(feature = "foo", issue = "01234")]` לפנימי.
//!
//!
//! אם אמור לשמש פנימי מ-`const fn` עם תכונה `rustc_const_stable`, גם תכונת הפנימיות חייבת להיות `rustc_const_stable`.
//! אסור לעשות שינוי כזה ללא התייעצות עם T-lang, מכיוון שהוא אופה תכונה לשפה שלא ניתן לשכפל בקוד המשתמש ללא תמיכה במהדר.
//!
//! # Volatiles
//!
//! הפנימיות הפכפכה מספקת פעולות שנועדו לפעול על פי זיכרון I/O, שמובטח שלא יוסדר מחדש על ידי המהדר על פני פנימיות הפכפכות אחרות.עיין בתיעוד LLVM ב-[[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! הפנימיות האטומית מספקת פעולות אטומיות נפוצות על מילות מכונה, עם מספר סדרי זיכרון אפשריים.הם מצייתים לאותה סמנטיקה כמו C++ 11.עיין בתיעוד LLVM ב-[[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! רענון מהיר על הזמנת זיכרון:
//!
//! * לרכוש, מחסום לרכישת מנעול.קריאות וכתיבות שלאחר מכן מתרחשות לאחר המחסום.
//! * שחרור, מחסום לשחרור מנעול.הקריאה והכתיבה הקודמת מתרחשים לפני המחסום.
//! * מובטחת שפעולות עקביות ברצף, עקביות ברצף, בסדר.זהו המצב הסטנדרטי לעבודה עם סוגי אטומים והוא שווה ערך ל-`volatile` של Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// יבוא זה משמש לפשט קישורים פנים-דוקיים
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // בטיחות: ראה `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // שים לב, פנימיות אלה לוקחות מצביעים גולמיים מכיוון שהן ממתנות זיכרון מוטה, שאינו תקף עבור `&` או `&mut`.
    //

    /// שומר ערך אם הערך הנוכחי זהה לערך `old`.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `compare_exchange` על ידי העברת [`Ordering::SeqCst`] כפרמטרים `success` ו-`failure`.
    ///
    /// לדוגמה, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// שומר ערך אם הערך הנוכחי זהה לערך `old`.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `compare_exchange` על ידי העברת [`Ordering::Acquire`] כפרמטרים `success` ו-`failure`.
    ///
    /// לדוגמה, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// שומר ערך אם הערך הנוכחי זהה לערך `old`.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `compare_exchange` על ידי העברת [`Ordering::Release`] כ-`success` ו-[`Ordering::Relaxed`] כפרמטרים `failure`.
    /// לדוגמה, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// שומר ערך אם הערך הנוכחי זהה לערך `old`.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `compare_exchange` על ידי העברת [`Ordering::AcqRel`] כ-`success` ו-[`Ordering::Acquire`] כפרמטרים `failure`.
    /// לדוגמה, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// שומר ערך אם הערך הנוכחי זהה לערך `old`.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `compare_exchange` על ידי העברת [`Ordering::Relaxed`] כפרמטרים `success` ו-`failure`.
    ///
    /// לדוגמה, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// שומר ערך אם הערך הנוכחי זהה לערך `old`.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `compare_exchange` על ידי העברת [`Ordering::SeqCst`] כ-`success` ו-[`Ordering::Relaxed`] כפרמטרים `failure`.
    /// לדוגמה, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// שומר ערך אם הערך הנוכחי זהה לערך `old`.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `compare_exchange` על ידי העברת [`Ordering::SeqCst`] כ-`success` ו-[`Ordering::Acquire`] כפרמטרים `failure`.
    /// לדוגמה, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// שומר ערך אם הערך הנוכחי זהה לערך `old`.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `compare_exchange` על ידי העברת [`Ordering::Acquire`] כ-`success` ו-[`Ordering::Relaxed`] כפרמטרים `failure`.
    /// לדוגמה, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// שומר ערך אם הערך הנוכחי זהה לערך `old`.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `compare_exchange` על ידי העברת [`Ordering::AcqRel`] כ-`success` ו-[`Ordering::Relaxed`] כפרמטרים `failure`.
    /// לדוגמה, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// שומר ערך אם הערך הנוכחי זהה לערך `old`.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `compare_exchange_weak` על ידי העברת [`Ordering::SeqCst`] כפרמטרים `success` ו-`failure`.
    ///
    /// לדוגמה, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// שומר ערך אם הערך הנוכחי זהה לערך `old`.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `compare_exchange_weak` על ידי העברת [`Ordering::Acquire`] כפרמטרים `success` ו-`failure`.
    ///
    /// לדוגמה, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// שומר ערך אם הערך הנוכחי זהה לערך `old`.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `compare_exchange_weak` על ידי העברת [`Ordering::Release`] כ-`success` ו-[`Ordering::Relaxed`] כפרמטרים `failure`.
    /// לדוגמה, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// שומר ערך אם הערך הנוכחי זהה לערך `old`.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `compare_exchange_weak` על ידי העברת [`Ordering::AcqRel`] כ-`success` ו-[`Ordering::Acquire`] כפרמטרים `failure`.
    /// לדוגמה, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// שומר ערך אם הערך הנוכחי זהה לערך `old`.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `compare_exchange_weak` על ידי העברת [`Ordering::Relaxed`] כפרמטרים `success` ו-`failure`.
    ///
    /// לדוגמה, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// שומר ערך אם הערך הנוכחי זהה לערך `old`.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `compare_exchange_weak` על ידי העברת [`Ordering::SeqCst`] כ-`success` ו-[`Ordering::Relaxed`] כפרמטרים `failure`.
    /// לדוגמה, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// שומר ערך אם הערך הנוכחי זהה לערך `old`.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `compare_exchange_weak` על ידי העברת [`Ordering::SeqCst`] כ-`success` ו-[`Ordering::Acquire`] כפרמטרים `failure`.
    /// לדוגמה, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// שומר ערך אם הערך הנוכחי זהה לערך `old`.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `compare_exchange_weak` על ידי העברת [`Ordering::Acquire`] כ-`success` ו-[`Ordering::Relaxed`] כפרמטרים `failure`.
    /// לדוגמה, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// שומר ערך אם הערך הנוכחי זהה לערך `old`.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `compare_exchange_weak` על ידי העברת [`Ordering::AcqRel`] כ-`success` ו-[`Ordering::Relaxed`] כפרמטרים `failure`.
    /// לדוגמה, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// טוען את הערך הנוכחי של המצביע.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `load` על ידי העברת [`Ordering::SeqCst`] כ-`order`.
    /// לדוגמה, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// טוען את הערך הנוכחי של המצביע.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `load` על ידי העברת [`Ordering::Acquire`] כ-`order`.
    /// לדוגמה, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// טוען את הערך הנוכחי של המצביע.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `load` על ידי העברת [`Ordering::Relaxed`] כ-`order`.
    /// לדוגמה, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// שומר את הערך במיקום הזיכרון שצוין.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `store` על ידי העברת [`Ordering::SeqCst`] כ-`order`.
    /// לדוגמה, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// שומר את הערך במיקום הזיכרון שצוין.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `store` על ידי העברת [`Ordering::Release`] כ-`order`.
    /// לדוגמה, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// שומר את הערך במיקום הזיכרון שצוין.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `store` על ידי העברת [`Ordering::Relaxed`] כ-`order`.
    /// לדוגמה, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// מאחסן את הערך במיקום הזיכרון שצוין, ומחזיר את הערך הישן.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `swap` על ידי העברת [`Ordering::SeqCst`] כ-`order`.
    /// לדוגמה, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// מאחסן את הערך במיקום הזיכרון שצוין, ומחזיר את הערך הישן.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `swap` על ידי העברת [`Ordering::Acquire`] כ-`order`.
    /// לדוגמה, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// מאחסן את הערך במיקום הזיכרון שצוין, ומחזיר את הערך הישן.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `swap` על ידי העברת [`Ordering::Release`] כ-`order`.
    /// לדוגמה, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// מאחסן את הערך במיקום הזיכרון שצוין, ומחזיר את הערך הישן.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `swap` על ידי העברת [`Ordering::AcqRel`] כ-`order`.
    /// לדוגמה, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// מאחסן את הערך במיקום הזיכרון שצוין, ומחזיר את הערך הישן.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `swap` על ידי העברת [`Ordering::Relaxed`] כ-`order`.
    /// לדוגמה, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// מוסיף לערך הנוכחי ומחזיר את הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_add` על ידי העברת [`Ordering::SeqCst`] כ-`order`.
    /// לדוגמה, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// מוסיף לערך הנוכחי ומחזיר את הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_add` על ידי העברת [`Ordering::Acquire`] כ-`order`.
    /// לדוגמה, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// מוסיף לערך הנוכחי ומחזיר את הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_add` על ידי העברת [`Ordering::Release`] כ-`order`.
    /// לדוגמה, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// מוסיף לערך הנוכחי ומחזיר את הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_add` על ידי העברת [`Ordering::AcqRel`] כ-`order`.
    /// לדוגמה, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// מוסיף לערך הנוכחי ומחזיר את הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_add` על ידי העברת [`Ordering::Relaxed`] כ-`order`.
    /// לדוגמה, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// מחסירים מהערך הנוכחי ומחזירים את הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_sub` על ידי העברת [`Ordering::SeqCst`] כ-`order`.
    /// לדוגמה, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// מחסירים מהערך הנוכחי ומחזירים את הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_sub` על ידי העברת [`Ordering::Acquire`] כ-`order`.
    /// לדוגמה, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// מחסירים מהערך הנוכחי ומחזירים את הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_sub` על ידי העברת [`Ordering::Release`] כ-`order`.
    /// לדוגמה, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// מחסירים מהערך הנוכחי ומחזירים את הערך הקודם.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_sub` על ידי העברת [`Ordering::AcqRel`] כ-`order`.
    /// לדוגמה, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// מחסירים מהערך הנוכחי ומחזירים את הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_sub` על ידי העברת [`Ordering::Relaxed`] כ-`order`.
    /// לדוגמה, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// סיבית ועם הערך הנוכחי, החזרת הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_and` על ידי העברת [`Ordering::SeqCst`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// סיבית ועם הערך הנוכחי, החזרת הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_and` על ידי העברת [`Ordering::Acquire`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// סיבית ועם הערך הנוכחי, החזרת הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_and` על ידי העברת [`Ordering::Release`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// סיבית ועם הערך הנוכחי, החזרת הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_and` על ידי העברת [`Ordering::AcqRel`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// סיבית ועם הערך הנוכחי, החזרת הערך הקודם.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_and` על ידי העברת [`Ordering::Relaxed`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand עם הערך הנוכחי, מחזיר את הערך הקודם.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוג [`AtomicBool`] באמצעות שיטת `fetch_nand` על ידי העברת [`Ordering::SeqCst`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand עם הערך הנוכחי, מחזיר את הערך הקודם.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוג [`AtomicBool`] באמצעות שיטת `fetch_nand` על ידי העברת [`Ordering::Acquire`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand עם הערך הנוכחי, מחזיר את הערך הקודם.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוג [`AtomicBool`] באמצעות שיטת `fetch_nand` על ידי העברת [`Ordering::Release`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand עם הערך הנוכחי, מחזיר את הערך הקודם.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוג [`AtomicBool`] באמצעות שיטת `fetch_nand` על ידי העברת [`Ordering::AcqRel`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand עם הערך הנוכחי, מחזיר את הערך הקודם.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוג [`AtomicBool`] באמצעות שיטת `fetch_nand` על ידי העברת [`Ordering::Relaxed`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// סיבית או עם הערך הנוכחי, החזרת הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_or` על ידי העברת [`Ordering::SeqCst`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// סיבית או עם הערך הנוכחי, החזרת הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_or` על ידי העברת [`Ordering::Acquire`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// סיבית או עם הערך הנוכחי, החזרת הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_or` על ידי העברת [`Ordering::Release`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// סיבית או עם הערך הנוכחי, החזרת הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_or` על ידי העברת [`Ordering::AcqRel`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// סיבית או עם הערך הנוכחי, החזרת הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_or` על ידי העברת [`Ordering::Relaxed`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor עם הערך הנוכחי, מחזיר את הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_xor` על ידי העברת [`Ordering::SeqCst`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor עם הערך הנוכחי, מחזיר את הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_xor` על ידי העברת [`Ordering::Acquire`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor עם הערך הנוכחי, מחזיר את הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_xor` על ידי העברת [`Ordering::Release`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor עם הערך הנוכחי, מחזיר את הערך הקודם.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_xor` על ידי העברת [`Ordering::AcqRel`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor עם הערך הנוכחי, מחזיר את הערך הקודם.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה בסוגי [`atomic`] באמצעות שיטת `fetch_xor` על ידי העברת [`Ordering::Relaxed`] כ-`order`.
    /// לדוגמה, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// מקסימום עם הערך הנוכחי באמצעות השוואה חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי המספרים השלמים החתומים [`atomic`] באמצעות שיטת `fetch_max` על ידי העברת [`Ordering::SeqCst`] כ-`order`.
    /// לדוגמה, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// מקסימום עם הערך הנוכחי באמצעות השוואה חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי המספרים השלמים החתומים [`atomic`] באמצעות שיטת `fetch_max` על ידי העברת [`Ordering::Acquire`] כ-`order`.
    /// לדוגמה, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// מקסימום עם הערך הנוכחי באמצעות השוואה חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי המספרים השלמים החתומים [`atomic`] באמצעות שיטת `fetch_max` על ידי העברת [`Ordering::Release`] כ-`order`.
    /// לדוגמה, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// מקסימום עם הערך הנוכחי באמצעות השוואה חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי המספרים השלמים החתומים [`atomic`] באמצעות שיטת `fetch_max` על ידי העברת [`Ordering::AcqRel`] כ-`order`.
    /// לדוגמה, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// מקסימום עם הערך הנוכחי.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי המספרים השלמים החתומים [`atomic`] באמצעות שיטת `fetch_max` על ידי העברת [`Ordering::Relaxed`] כ-`order`.
    /// לדוגמה, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// מינימום עם הערך הנוכחי באמצעות השוואה חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי המספרים השלמים החתומים [`atomic`] באמצעות שיטת `fetch_min` על ידי העברת [`Ordering::SeqCst`] כ-`order`.
    /// לדוגמה, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// מינימום עם הערך הנוכחי באמצעות השוואה חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי המספרים השלמים החתומים [`atomic`] באמצעות שיטת `fetch_min` על ידי העברת [`Ordering::Acquire`] כ-`order`.
    /// לדוגמה, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// מינימום עם הערך הנוכחי באמצעות השוואה חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי המספרים השלמים החתומים [`atomic`] באמצעות שיטת `fetch_min` על ידי העברת [`Ordering::Release`] כ-`order`.
    /// לדוגמה, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// מינימום עם הערך הנוכחי באמצעות השוואה חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי המספרים השלמים החתומים [`atomic`] באמצעות שיטת `fetch_min` על ידי העברת [`Ordering::AcqRel`] כ-`order`.
    /// לדוגמה, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// מינימום עם הערך הנוכחי באמצעות השוואה חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי המספרים השלמים החתומים [`atomic`] באמצעות שיטת `fetch_min` על ידי העברת [`Ordering::Relaxed`] כ-`order`.
    /// לדוגמה, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// מינימום עם הערך הנוכחי באמצעות השוואה שלא חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי השלמים הלא חתומים [`atomic`] באמצעות שיטת `fetch_min` על ידי העברת [`Ordering::SeqCst`] כ-`order`.
    /// לדוגמה, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// מינימום עם הערך הנוכחי באמצעות השוואה שלא חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי השלמים הלא חתומים [`atomic`] באמצעות שיטת `fetch_min` על ידי העברת [`Ordering::Acquire`] כ-`order`.
    /// לדוגמה, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// מינימום עם הערך הנוכחי באמצעות השוואה שלא חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי השלמים הלא חתומים [`atomic`] באמצעות שיטת `fetch_min` על ידי העברת [`Ordering::Release`] כ-`order`.
    /// לדוגמה, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// מינימום עם הערך הנוכחי באמצעות השוואה שלא חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי השלמים הלא חתומים [`atomic`] באמצעות שיטת `fetch_min` על ידי העברת [`Ordering::AcqRel`] כ-`order`.
    /// לדוגמה, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// מינימום עם הערך הנוכחי באמצעות השוואה שלא חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי השלמים הלא חתומים [`atomic`] באמצעות שיטת `fetch_min` על ידי העברת [`Ordering::Relaxed`] כ-`order`.
    /// לדוגמה, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// מקסימום עם הערך הנוכחי באמצעות השוואה שלא חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי השלמים הלא חתומים [`atomic`] באמצעות שיטת `fetch_max` על ידי העברת [`Ordering::SeqCst`] כ-`order`.
    /// לדוגמה, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// מקסימום עם הערך הנוכחי באמצעות השוואה שלא חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי השלמים הלא חתומים [`atomic`] באמצעות שיטת `fetch_max` על ידי העברת [`Ordering::Acquire`] כ-`order`.
    /// לדוגמה, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// מקסימום עם הערך הנוכחי באמצעות השוואה שלא חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי השלמים הלא חתומים [`atomic`] באמצעות שיטת `fetch_max` על ידי העברת [`Ordering::Release`] כ-`order`.
    /// לדוגמה, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// מקסימום עם הערך הנוכחי באמצעות השוואה שלא חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי השלמים הלא חתומים [`atomic`] באמצעות שיטת `fetch_max` על ידי העברת [`Ordering::AcqRel`] כ-`order`.
    /// לדוגמה, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// מקסימום עם הערך הנוכחי באמצעות השוואה שלא חתומה.
    ///
    /// הגרסה המייצבת של מהות זו זמינה בסוגי השלמים הלא חתומים [`atomic`] באמצעות שיטת `fetch_max` על ידי העברת [`Ordering::Relaxed`] כ-`order`.
    /// לדוגמה, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ה-`prefetch` הפנימי הוא רמז למחולל הקוד כדי להכניס הוראה מראש אם היא נתמכת;אחרת, זהו אי-אופ.
    /// לאיסוף מראש אין השפעה על התנהגות התוכנית, אך הם יכולים לשנות את מאפייני הביצועים שלה.
    ///
    /// הארגומנט `locality` חייב להיות מספר שלם קבוע והוא מפרט יישוב זמני, שנע בין (0), ללא יישוב, ל-(3), שמירה מקומית במיוחד במטמון.
    ///
    ///
    /// אין מהותית מקבילה יציבה.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// ה-`prefetch` הפנימי הוא רמז למחולל הקוד כדי להכניס הוראה מראש אם היא נתמכת;אחרת, זהו אי-אופ.
    /// לאיסוף מראש אין השפעה על התנהגות התוכנית, אך הם יכולים לשנות את מאפייני הביצועים שלה.
    ///
    /// הארגומנט `locality` חייב להיות מספר שלם קבוע והוא מפרט יישוב זמני, שנע בין (0), ללא יישוב, ל-(3), שמירה מקומית במיוחד במטמון.
    ///
    ///
    /// אין מהותית מקבילה יציבה.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// ה-`prefetch` הפנימי הוא רמז למחולל הקוד כדי להכניס הוראה מראש אם היא נתמכת;אחרת, זהו אי-אופ.
    /// לאיסוף מראש אין השפעה על התנהגות התוכנית, אך הם יכולים לשנות את מאפייני הביצועים שלה.
    ///
    /// הארגומנט `locality` חייב להיות מספר שלם קבוע והוא מפרט יישוב זמני, שנע בין (0), ללא יישוב, ל-(3), שמירה מקומית במיוחד במטמון.
    ///
    ///
    /// אין מהותית מקבילה יציבה.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// ה-`prefetch` הפנימי הוא רמז למחולל הקוד כדי להכניס הוראה מראש אם היא נתמכת;אחרת, זהו אי-אופ.
    /// לאיסוף מראש אין השפעה על התנהגות התוכנית, אך הם יכולים לשנות את מאפייני הביצועים שלה.
    ///
    /// הארגומנט `locality` חייב להיות מספר שלם קבוע והוא מפרט יישוב זמני, שנע בין (0), ללא יישוב, ל-(3), שמירה מקומית במיוחד במטמון.
    ///
    ///
    /// אין מהותית מקבילה יציבה.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// גדר אטומית.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה ב-[`atomic::fence`] על ידי העברת [`Ordering::SeqCst`] כ-`order`.
    ///
    ///
    pub fn atomic_fence();
    /// גדר אטומית.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה ב-[`atomic::fence`] על ידי העברת [`Ordering::Acquire`] כ-`order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// גדר אטומית.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה ב-[`atomic::fence`] על ידי העברת [`Ordering::Release`] כ-`order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// גדר אטומית.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה ב-[`atomic::fence`] על ידי העברת [`Ordering::AcqRel`] כ-`order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// מחסום זיכרון מהדר בלבד.
    ///
    /// הגישות לזיכרון לעולם לא יוסדרו מחדש על ידי מחסום זה על ידי המהדר, אך לא יופלטו הוראות עבורו.
    /// זה מתאים לפעולות באותו חוט שעשוי להיות מוקדם, כמו למשל בעת אינטראקציה עם מטפלי האותות.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה ב-[`atomic::compiler_fence`] על ידי העברת [`Ordering::SeqCst`] כ-`order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// מחסום זיכרון מהדר בלבד.
    ///
    /// הגישות לזיכרון לעולם לא יוסדרו מחדש על ידי מחסום זה על ידי המהדר, אך לא יופלטו הוראות עבורו.
    /// זה מתאים לפעולות באותו חוט שעשוי להיות מוקדם, כמו למשל בעת אינטראקציה עם מטפלי האותות.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה ב-[`atomic::compiler_fence`] על ידי העברת [`Ordering::Acquire`] כ-`order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// מחסום זיכרון מהדר בלבד.
    ///
    /// הגישות לזיכרון לעולם לא יוסדרו מחדש על ידי מחסום זה על ידי המהדר, אך לא יופלטו הוראות עבורו.
    /// זה מתאים לפעולות באותו חוט שעשוי להיות מוקדם, כמו למשל בעת אינטראקציה עם מטפלי האותות.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה ב-[`atomic::compiler_fence`] על ידי העברת [`Ordering::Release`] כ-`order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// מחסום זיכרון מהדר בלבד.
    ///
    /// הגישות לזיכרון לעולם לא יוסדרו מחדש על ידי מחסום זה על ידי המהדר, אך לא יופלטו הוראות עבורו.
    /// זה מתאים לפעולות באותו חוט שעשוי להיות מוקדם, כמו למשל בעת אינטראקציה עם מטפלי האותות.
    ///
    /// הגרסה המיוצבת של מהות זו זמינה ב-[`atomic::compiler_fence`] על ידי העברת [`Ordering::AcqRel`] כ-`order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// קסם מהותי ששואב את משמעותו מתכונות המצורפות לפונקציה.
    ///
    /// לדוגמה, זרימת נתונים משתמשת בזה כדי להזריק קביעות סטטיות כך ש-`rustc_peek(potentially_uninitialized)` אכן יבדוק פעמיים שזרם הנתונים אכן חישב שהוא אינו מאוזן בנקודה זו בזרימת הבקרה.
    ///
    ///
    /// אין להשתמש במהות זו מחוץ למהדר.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// מבטל את ביצוע התהליך.
    ///
    /// גרסה ידידותית יותר ויציבה יותר של פעולה זו היא [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// מודיע למייעל כי לא ניתן להגיע לנקודה זו בקוד, מה שמאפשר אופטימיזציות נוספות.
    ///
    /// הערה, זה שונה מאוד ממאקרו `unreachable!()`: בניגוד למאקרו, אשר panics כאשר הוא מבוצע, זה *התנהגות לא מוגדרת* להגיע לקוד המסומן בפונקציה זו.
    ///
    ///
    /// הגרסה המיוצבת של מהות זו היא [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// מודיע למייעל שתנאי הוא תמיד נכון.
    /// אם התנאי כוזב, ההתנהגות אינה מוגדרת.
    ///
    /// לא נוצר קוד עבור מהותי זה, אך מייעל האופטימיזציה ינסה לשמר אותו (ואת מצבו) בין המעברים, מה שעלול להפריע לאופטימיזציה של הקוד שמסביב ולהפחית את הביצועים.
    /// אין להשתמש בו אם המיטוב יכול לגלות את המשתנה באופן עצמאי, או אם הוא אינו מאפשר אופטימיזציות משמעותיות כלשהן.
    ///
    /// אין מהותית מקבילה יציבה.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// רמזים למהדר שמצב branch עשוי להיות נכון.
    /// מחזיר את הערך שהועבר אליו.
    ///
    /// ככל הנראה כל שימוש שאינו עם הצהרות `if` לא ישפיע.
    ///
    /// אין מהותית מקבילה יציבה.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// רמזים למהדר שמצב branch עשוי להיות שקרי.
    /// מחזיר את הערך שהועבר אליו.
    ///
    /// ככל הנראה כל שימוש שאינו עם הצהרות `if` לא ישפיע.
    ///
    /// אין מהותית מקבילה יציבה.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// מבצע מלכודת נקודת עצירה, לבדיקה על ידי ניפוי באגים.
    ///
    /// אין מהותית מקבילה יציבה.
    pub fn breakpoint();

    /// גודלו של סוג בתים.
    ///
    /// באופן ספציפי יותר, זה הקיזוז בבייטים בין פריטים עוקבים מאותו סוג, כולל ריפוד יישור.
    ///
    ///
    /// הגרסה המיוצבת של מהות זו היא [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// היישור המינימלי של סוג.
    ///
    /// הגרסה המיוצבת של מהות זו היא [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// היישור המועדף על סוג.
    ///
    /// אין מהותית מקבילה יציבה.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// גודל הערך המוזכר בתים.
    ///
    /// הגרסה המיוצבת של מהות זו היא [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// היישור הנדרש של הערך המוזכר.
    ///
    /// הגרסה המיוצבת של מהות זו היא [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// מקבל נתח מחרוזת סטטי המכיל את שם הסוג.
    ///
    /// הגרסה המיוצבת של מהות זו היא [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// מקבל מזהה שהוא ייחודי בעולם לסוג שצוין.
    /// פונקציה זו תחזיר את אותו הערך עבור סוג ללא קשר לאיזו crate הוא מופעל.
    ///
    ///
    /// הגרסה המיוצבת של מהות זו היא [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// שומר לפונקציות לא בטוחות שאי אפשר לבצע אי פעם אם `T` אינו מיושב:
    /// זה יהיה סטטי או panic, או לא יעשה דבר.
    ///
    /// אין מהותית מקבילה יציבה.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// שומר לפונקציות לא בטוחות שאי אפשר לבצע אי פעם אם `T` אינו מאפשר אתחול אפס: פעולה זו תהיה סטטיסטית או panic, או לא תעשה דבר.
    ///
    ///
    /// אין מהותית מקבילה יציבה.
    pub fn assert_zero_valid<T>();

    /// שומר לפונקציות לא בטוחות שלא ניתן לבצע אי פעם אם ל-`T` יש דפוסי סיביות לא חוקיים: זה יהיה סטטי או panic, או לא יעשה דבר.
    ///
    ///
    /// אין מהותית מקבילה יציבה.
    pub fn assert_uninit_valid<T>();

    /// מקבל הפניה ל-`Location` סטטי המציין לאן הוא נקרא.
    ///
    /// שקול להשתמש במקום זאת ב-[`core::panic::Location::caller`](crate::panic::Location::caller).
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// מעביר ערך מחוץ לתחום מבלי להפעיל דבק טיפה.
    ///
    /// זה קיים אך ורק עבור [`mem::forget_unsized`];`forget` רגיל משתמש במקום זאת ב-`ManuallyDrop`.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// מפרש מחדש את סיביות הערך מסוג אחד כסוג אחר.
    ///
    /// שני הסוגים חייבים להיות באותו הגודל.
    /// לא המקור ולא התוצאה עשויים להיות [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` שווה ערך סמנטית למעבר קצת חכם מסוג אחד למשנהו.הוא מעתיק את הביטים מערך המקור לערך היעד ואז שוכח את המקור.
    /// זה שווה ערך ל-`memcpy` של C מתחת למכסה המנוע, בדיוק כמו `transmute_copy`.
    ///
    /// מכיוון ש-`transmute` הוא פעולה בערך לוואי, יישור הערכים *המועברים עצמם* אינו מהווה עניין.
    /// כמו בכל פונקציה אחרת, המהדר כבר מבטיח שגם `T` וגם `U` מיושרים כהלכה.
    /// עם זאת, כאשר מעבירים ערכים ש *מצביעים למקום אחר*(כגון מצביעים, הפניות, תיבות ...), על המתקשר לדאוג ליישור נכון של הערכים המופנים.
    ///
    /// `transmute` אינו **מדהים**.יש מספר עצום של דרכים לגרום ל-[undefined behavior][ub] באמצעות פונקציה זו.`transmute` צריך להיות המוצא האחרון המוחלט.
    ///
    /// ל-[nomicon](../../nomicon/transmutes.html) יש תיעוד נוסף.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// יש כמה דברים ש-`transmute` באמת שימושי עבורם.
    ///
    /// הפיכת מצביע למצביע פונקציה.זה *לא* נייד למכונות בהן מצביעי פונקציה ומצביעי נתונים בגדלים שונים.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// הארכת חיים, או קיצור חיים בלתי משתנים.זה Rust מתקדם, מאוד לא בטוח!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// אל תתייאש: ניתן להשיג שימושים רבים ב-`transmute` באמצעים אחרים.
    /// להלן יישומים נפוצים של `transmute` הניתנים להחלפה במבנים בטוחים יותר.
    ///
    /// הפיכת bytes(`&[u8]`) גולמי ל-`u32`, `f64` וכו ':
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // השתמש במקום זאת ב-`u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // או השתמש ב-`u32::from_le_bytes` או `u32::from_be_bytes` כדי לציין את הקביעות
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// הפיכת מצביע ל-`usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // השתמש במקום זאת בקבוצת `as`
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// הפיכת `*mut T` ל-`&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // השתמש במקום זאת מחדש
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// הפיכת `&mut T` ל-`&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // עכשיו, להרכיב את `as` ולהשאיל מחדש, שים לב לשרשור של `as` `as` אינו חולף
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// הפיכת `&str` ל-`&[u8]`:
    ///
    /// ```
    /// // זו לא דרך טובה לעשות זאת.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // אתה יכול להשתמש ב-`str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // לחלופין, פשוט השתמש במחרוזת בתים, אם יש לך שליטה על המיתר המילולי
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// הפיכת `Vec<&T>` ל-`Vec<Option<&T>>`.
    ///
    /// כדי להעביר את הסוג הפנימי של תכולת המכולה, עליכם לוודא שלא להפר את כל אחד מגורמי הדליפה של המכולה.
    /// עבור `Vec` זה אומר שגם הגודל *וגם היישור* של הסוגים הפנימיים צריכים להתאים.
    /// מכולות אחרות עשויות להסתמך על גודל הסוג, היישור, או אפילו ה-`TypeId`, ובמקרה כזה השינוי לא יהיה אפשרי בכלל מבלי להפר את תושבי המכולה.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // שיבט את ה-vector שכן נשתמש בהם מאוחר יותר
    /// let v_clone = v_orig.clone();
    ///
    /// // באמצעות טרנסמוט: זה מסתמך על פריסת הנתונים הלא מוגדרת של `Vec`, שזה רעיון רע שעלול לגרום להתנהגות לא מוגדרת.
    /////
    /// // עם זאת, אין זה עותק.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // זו הדרך המוצעת והבטוחה.
    /// // עם זאת, הוא מעתיק את כל ה-vector למערך חדש.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // זוהי הדרך הנכונה ללא העתקה ולא בטיחותית של "transmuting" ל-`Vec`, מבלי להסתמך על פריסת הנתונים.
    /// // במקום לקרוא ל-`transmute` פשוטו כמשמעו, אנו מבצעים צוות מצביע, אך מבחינת המרת הסוג הפנימי המקורי (`&i32`) לזה החדש (`Option<&i32>`), יש לכך את כל אותם אזהרות.
    /////
    /// // מלבד המידע המסופק לעיל, עיין גם בתיעוד [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME עדכן זאת כאשר vec_into_raw_parts מיוצב.
    ///     // ודא ש-vector המקורי לא נושר.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// יישום `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // ישנן מספר דרכים לעשות זאת, וישנן מספר בעיות בדרך ה-(transmute) הבאה.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // ראשית: טרנסמוט אינו סוג בטוח;כל מה שבודק הוא ש-T ו-
    ///         // U באותו גודל.
    ///         // שנית, ממש כאן, יש לך שתי הפניות משתנות המפנות לאותו זיכרון.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // זה נפטר מבעיות הבטיחות בסוג;`&mut *` ייתן לך* רק *`&mut T` מ-`&mut T` או `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // עם זאת, עדיין יש לך שתי הפניות משתנות המפנות לאותו זיכרון.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // כך הספרייה הסטנדרטית עושה זאת.
    /// // זו השיטה הטובה ביותר, אם אתה צריך לעשות משהו כזה
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // כעת יש לזה שלוש אזכורים ניתנים לשינוי המפנים לאותו זיכרון.`slice`, ה-rvalue ret.0, וה-rvalue ret.1.
    ///         // `slice` אף פעם לא משתמשים בו לאחר `let ptr = ...`, ולכן אפשר להתייחס אליו כאל "dead", ולכן יש לך רק שתי פרוסות ניתנות לשינוי אמיתיות.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: אמנם זה הופך את const הפנימי ליציב, אבל יש לנו קוד מותאם אישית ב-const fn
    // בדיקות המונעות את השימוש בה ב-`const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// מחזירה `true` אם הסוג האמיתי שניתן כ-`T` דורש דבק טיפה;מחזירה את `false` אם הסוג האמיתי המסופק עבור `T` מיישם את `Copy`.
    ///
    ///
    /// אם הסוג בפועל לא מצריך דבק טיפה ואינו מיישם `Copy`, אז ערך ההחזרה של פונקציה זו אינו מוגדר.
    ///
    /// הגרסה המיוצבת של מהות זו היא [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// מחשבת את הקיזוז ממצביע.
    ///
    /// זה מיושם כאינטרנטי כדי למנוע המרה למספר שלם וממנו, מכיוון שההמרה תזרוק מידע כינוי.
    ///
    /// # Safety
    ///
    /// גם המצביע ההתחלתי וגם המוצא חייב להיות בגבול או בתים אחד מעבר לסוף האובייקט שהוקצה.
    /// אם מצביע אחד מחוץ לתחום או מתרחשת הצפה אריתמטית, אז כל שימוש נוסף בערך המוחזר יביא להתנהגות לא מוגדרת.
    ///
    ///
    /// הגרסה המיוצבת של מהות זו היא [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// מחשבת את הקיזוז ממצביע, ועוטף באופן פוטנציאלי.
    ///
    /// זה מיושם כאינטרנטי כדי למנוע המרה למספר שלם וממנו, מכיוון שההמרה מעכבת אופטימיזציות מסוימות.
    ///
    /// # Safety
    ///
    /// בניגוד ל-`offset` הפנימי, הפנימיות הזו אינה מגבילה את המצביע שנוצר להצביע או בתים אחד מעבר לקצה של אובייקט שהוקצה, והוא עוטף בחשבון משלים של שניים.
    /// הערך המתקבל אינו בהכרח תקף לשימוש בכדי לגשת לזיכרון בפועל.
    ///
    /// הגרסה המיוצבת של מהות זו היא [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// שווה ערך פנימי `llvm.memcpy.p0i8.0i8.*` המתאים, עם גודל של `count`*`size_of::<T>()` ויישור של
    ///
    /// `min_align_of::<T>()`
    ///
    /// הפרמטר ההפכפך מוגדר ל-`true`, כך שהוא לא יעשה אופטימיזציה אלא אם הגודל שווה לאפס.
    ///
    /// אין מהותית מקבילה יציבה.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// שווה ערך פנימי `llvm.memmove.p0i8.0i8.*` המתאים, עם גודל `count* size_of::<T>()` ויישור של
    ///
    /// `min_align_of::<T>()`
    ///
    /// הפרמטר ההפכפך מוגדר ל-`true`, כך שהוא לא יעשה אופטימיזציה אלא אם הגודל שווה לאפס.
    ///
    /// אין מהותית מקבילה יציבה.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// שווה ערך ל-`llvm.memset.p0i8.*` הפנימי המתאים, בגודל `count* size_of::<T>()` וביישור `min_align_of::<T>()`.
    ///
    ///
    /// הפרמטר ההפכפך מוגדר ל-`true`, כך שהוא לא יעשה אופטימיזציה אלא אם הגודל שווה לאפס.
    ///
    /// אין מהותית מקבילה יציבה.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// מבצע עומס נדיף מהמצביע `src`.
    ///
    /// הגרסה המיוצבת של מהות זו היא [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// מבצע חנות נדיפה למצביע `dst`.
    ///
    /// הגרסה המיוצבת של מהות זו היא [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// מבצע עומס נדיף מהמצביע `src` אין צורך ליישר את המצביע.
    ///
    ///
    /// אין מהותית מקבילה יציבה.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// מבצע חנות נדיפה למצביע `dst`.
    /// אין צורך ליישר את המצביע.
    ///
    /// אין מהותית מקבילה יציבה.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// מחזיר את השורש הריבועי של `f32`
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// מחזיר את השורש הריבועי של `f64`
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// מעלה `f32` לכוח שלם.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// מעלה `f64` לכוח שלם.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// מחזיר את הסינוס של `f32`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// מחזיר את הסינוס של `f64`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// מחזיר את הקוסינוס של `f32`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// מחזיר את הקוסינוס של `f64`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// מעלה `f32` לכוח `f32`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// מעלה `f64` לכוח `f64`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// מחזירה את האקספוננציאלי של `f32`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// מחזירה את האקספוננציאלי של `f64`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// מחזיר 2 שהועלה בכוחו של `f32`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// מחזיר 2 שהועלה בכוחו של `f64`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// מחזיר את הלוגריתם הטבעי של `f32`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// מחזיר את הלוגריתם הטבעי של `f64`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// מחזיר את הלוגריתם הבסיסי 10 של `f32`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// מחזיר את הלוגריתם הבסיסי 10 של `f64`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// מחזיר את לוגריתם הבסיס 2 של `f32`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// מחזיר את לוגריתם הבסיס 2 של `f64`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// מחזירה `a * b + c` לערכי `f32`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// מחזירה `a * b + c` לערכי `f64`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// מחזירה את הערך המוחלט של `f32`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// מחזירה את הערך המוחלט של `f64`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// מחזירה את המינימום של שני ערכי `f32`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// מחזירה את המינימום של שני ערכי `f64`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// מחזירה מקסימום שני ערכי `f32`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// מחזירה מקסימום שני ערכי `f64`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// מעתיק את השלט מ-`y` ל-`x` לערכי `f32`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// מעתיק את השלט מ-`y` ל-`x` לערכי `f64`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// מחזירה את המספר השלם הגדול ביותר שקטן או שווה ל-`f32`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// מחזירה את המספר השלם הגדול ביותר שקטן או שווה ל-`f64`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// מחזיר את המספר השלם הקטן ביותר הגדול או שווה ל-`f32`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// מחזיר את המספר השלם הקטן ביותר הגדול או שווה ל-`f64`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// מחזיר את החלק השלם של `f32`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// מחזיר את החלק השלם של `f64`.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// מחזירה את המספר השלם הקרוב ביותר ל-`f32`.
    /// עשוי להעלות חריג שאינו מדויק של נקודה צפה אם הארגומנט אינו מספר שלם.
    pub fn rintf32(x: f32) -> f32;
    /// מחזירה את המספר השלם הקרוב ביותר ל-`f64`.
    /// עשוי להעלות חריג שאינו מדויק של נקודה צפה אם הארגומנט אינו מספר שלם.
    pub fn rintf64(x: f64) -> f64;

    /// מחזירה את המספר השלם הקרוב ביותר ל-`f32`.
    ///
    /// אין מהותית מקבילה יציבה.
    pub fn nearbyintf32(x: f32) -> f32;
    /// מחזירה את המספר השלם הקרוב ביותר ל-`f64`.
    ///
    /// אין מהותית מקבילה יציבה.
    pub fn nearbyintf64(x: f64) -> f64;

    /// מחזירה את המספר השלם הקרוב ביותר ל-`f32`.מסובב מקרים באמצע הדרך מאפס.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// מחזירה את המספר השלם הקרוב ביותר ל-`f64`.מסובב מקרים באמצע הדרך מאפס.
    ///
    /// הגרסה המיוצבת של מהות זו היא
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// תוספת צפה המאפשרת אופטימיזציות על בסיס כללים אלגבריים.
    /// יכול להניח שהתשומות סופיות.
    ///
    /// אין מהותית מקבילה יציבה.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// חיסור צף המאפשר אופטימיזציות על בסיס כללים אלגבריים.
    /// יכול להניח שהתשומות סופיות.
    ///
    /// אין מהותית מקבילה יציבה.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// כפל צף המאפשר אופטימיזציות על בסיס כללים אלגבריים.
    /// יכול להניח שהתשומות סופיות.
    ///
    /// אין מהותית מקבילה יציבה.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// חלוקת צף המאפשרת אופטימיזציות על בסיס כללים אלגבריים.
    /// יכול להניח שהתשומות סופיות.
    ///
    /// אין מהותית מקבילה יציבה.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// שארית צף המאפשרת אופטימיזציות על בסיס כללים אלגבריים.
    /// יכול להניח שהתשומות סופיות.
    ///
    /// אין מהותית מקבילה יציבה.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// המרה באמצעות fptoui/fptosi של LLVM, שעשויה להחזיר undef עבור ערכים מחוץ לטווח
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// מיוצב כ-[`f32::to_int_unchecked`] ו-[`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// מחזיר את מספר הסיביות שנקבעו בסוג מספר שלם `T`
    ///
    /// הגרסאות המיוצבות של מהות זו זמינות בפרימיטיביות השלמות באמצעות שיטת `count_ones`.
    /// לדוגמה,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// מחזיר את מספר הביטים המובילים שלא הוגדרו (zeroes) בסוג מספר שלם `T`.
    ///
    /// הגרסאות המיוצבות של מהות זו זמינות בפרימיטיביות השלמות באמצעות שיטת `leading_zeros`.
    /// לדוגמה,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` עם הערך `0` יחזיר את רוחב הסיביות של `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// כמו `ctlz`, אך לא בטוח יותר מכיוון שהוא מחזיר את `undef` כאשר ניתן לו `x` עם ערך `0`.
    ///
    ///
    /// אין מהותית מקבילה יציבה.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// מחזירה את מספר הביטים שלא נגררו (zeroes) בסוג שלם `T`.
    ///
    /// הגרסאות המיוצבות של מהות זו זמינות בפרימיטיביות השלמות באמצעות שיטת `trailing_zeros`.
    /// לדוגמה,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` עם הערך `0` יחזיר את רוחב הסיביות של `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// כמו `cttz`, אך לא בטוח יותר מכיוון שהוא מחזיר את `undef` כאשר ניתן לו `x` עם ערך `0`.
    ///
    ///
    /// אין מהותית מקבילה יציבה.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// הופך את הבתים בסוג שלם `T`.
    ///
    /// הגרסאות המיוצבות של מהות זו זמינות בפרימיטיביות השלמות באמצעות שיטת `swap_bytes`.
    /// לדוגמה,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// מהפך את הביטים בסוג שלם `T`.
    ///
    /// הגרסאות המיוצבות של מהות זו זמינות בפרימיטיביות השלמות באמצעות שיטת `reverse_bits`.
    /// לדוגמה,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// מבצע תוספת שלמה מסומנת.
    ///
    /// הגרסאות המיוצבות של מהות זו זמינות בפרימיטיביות השלמות באמצעות שיטת `overflowing_add`.
    /// לדוגמה,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// מבצע חיסור שלם שלם
    ///
    /// הגרסאות המיוצבות של מהות זו זמינות בפרימיטיביות השלמות באמצעות שיטת `overflowing_sub`.
    /// לדוגמה,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// מבצע כפל שלם מסומן
    ///
    /// הגרסאות המיוצבות של מהות זו זמינות בפרימיטיביות השלמות באמצעות שיטת `overflowing_mul`.
    /// לדוגמה,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// מבצע חלוקה מדויקת, וכתוצאה מכך התנהגות לא מוגדרת כאשר `x % y != 0` או `y == 0` או `x == T::MIN && y == -1`
    ///
    ///
    /// אין מהותית מקבילה יציבה.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// מבצע חלוקה לא מסומנת, וכתוצאה מכך התנהגות לא מוגדרת כאשר `y == 0` או `x == T::MIN && y == -1`
    ///
    ///
    /// עטיפות בטוחות עבור מהותי זה זמינות בפרימיטיביות השלמות בשיטת `checked_div`.
    /// לדוגמה,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// מחזירה את שארית החלוקה שלא מסומנת, וכתוצאה מכך התנהגות לא מוגדרת כאשר `y == 0` או `x == T::MIN && y == -1`
    ///
    ///
    /// עטיפות בטוחות עבור מהותי זה זמינות בפרימיטיביות השלמות בשיטת `checked_rem`.
    /// לדוגמה,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// מבצע משמרת שמאל לא מסומנת, וכתוצאה מכך התנהגות לא מוגדרת כאשר `y < 0` או `y >= N`, כאשר N הוא רוחב ה-T בסיביות.
    ///
    ///
    /// עטיפות בטוחות עבור מהותי זה זמינות בפרימיטיביות השלמות בשיטת `checked_shl`.
    /// לדוגמה,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// מבצע תזוזה ימנית לא מסומנת, וכתוצאה מכך התנהגות לא מוגדרת כאשר `y < 0` או `y >= N`, כאשר N הוא רוחב ה-T בסיביות.
    ///
    ///
    /// עטיפות בטוחות עבור מהותי זה זמינות בפרימיטיביות השלמות בשיטת `checked_shr`.
    /// לדוגמה,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// מחזירה את התוצאה של תוספת לא מסומנת, וכתוצאה מכך התנהגות לא מוגדרת כאשר `x + y > T::MAX` או `x + y < T::MIN`.
    ///
    ///
    /// אין מהותית מקבילה יציבה.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// מחזירה את התוצאה של חיסור לא מסומן, וכתוצאה מכך התנהגות לא מוגדרת כאשר `x - y > T::MAX` או `x - y < T::MIN`.
    ///
    ///
    /// אין מהותית מקבילה יציבה.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// מחזירה את התוצאה מכפל לא מסומן, וכתוצאה מכך התנהגות לא מוגדרת כאשר `x *y > T::MAX` או `x* y < T::MIN`.
    ///
    ///
    /// אין מהותית מקבילה יציבה.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// מבצע סובב שמאלה.
    ///
    /// הגרסאות המיוצבות של מהות זו זמינות בפרימיטיביות השלמות באמצעות שיטת `rotate_left`.
    /// לדוגמה,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// מבצע לסובב ימינה.
    ///
    /// הגרסאות המיוצבות של מהות זו זמינות בפרימיטיביות השלמות באמצעות שיטת `rotate_right`.
    /// לדוגמה,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// מחזיר (a + b) mod 2 <sup>N</sup>, כאשר N הוא רוחב ה-T בסיביות.
    ///
    /// הגרסאות המיוצבות של מהות זו זמינות בפרימיטיביות השלמות באמצעות שיטת `wrapping_add`.
    /// לדוגמה,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// מחזיר (a, b) mod 2 <sup>N</sup>, כאשר N הוא רוחב ה-T בסיביות.
    ///
    /// הגרסאות המיוצבות של מהות זו זמינות בפרימיטיביות השלמות באמצעות שיטת `wrapping_sub`.
    /// לדוגמה,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// מחזיר (a * b) mod 2 <sup>N</sup>, כאשר N הוא רוחב ה-T בסיביות.
    ///
    /// הגרסאות המיוצבות של מהות זו זמינות בפרימיטיביות השלמות באמצעות שיטת `wrapping_mul`.
    /// לדוגמה,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// מחשב `a + b`, רווי בגבולות המספריים.
    ///
    /// הגרסאות המיוצבות של מהות זו זמינות בפרימיטיביות השלמות באמצעות שיטת `saturating_add`.
    /// לדוגמה,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// מחשב `a - b`, רווי בגבולות המספריים.
    ///
    /// הגרסאות המיוצבות של מהות זו זמינות בפרימיטיביות השלמות באמצעות שיטת `saturating_sub`.
    /// לדוגמה,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// מחזירה את ערך המפלה עבור הגרסה ב-'v';
    /// אם ל-`T` אין הבחנה, מחזירה את `0`.
    ///
    /// הגרסה המיוצבת של מהות זו היא [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// מחזיר את מספר הגרסאות מהסוג `T` יצוק ל-`usize`;
    /// אם ל-`T` אין גרסאות, מחזיר את `0`.גרסאות לא מיושבות נספרו.
    ///
    /// הגרסה המיועדת לייצוב של מהות זו היא [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// מבנה ה-"try catch" של Rust הקורא את מצביע הפונקציה `try_fn` עם מצביע הנתונים `data`.
    ///
    /// הטיעון השלישי הוא פונקציה הנקראת אם מתרחש panic.
    /// פונקציה זו מעבירה את מצביע הנתונים ומצביע לאובייקט החריג הספציפי למטרה שנתפס.
    ///
    /// למידע נוסף עיין במקור המהדר, כמו גם ביישום התפיסה של std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// פולט חנות `!nontemporal` על פי LLVM (ראה מסמכים).
    /// כנראה שלעולם לא יהפוך ליציב.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// לפרטים, עיין בתיעוד של `<*const T>::offset_from`.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// לפרטים, עיין בתיעוד של `<*const T>::guaranteed_eq`.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// לפרטים, עיין בתיעוד של `<*const T>::guaranteed_ne`.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// הקצה בזמן הידור.לא צריך להתקשר בזמן הריצה.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// פונקציות מסוימות מוגדרות כאן מכיוון שהן זמינות בטעות במודול זה ביציבות.
// ראה <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` נופל גם לקטגוריה זו, אך לא ניתן לעטוף אותו בגלל הבדיקה ש-`T` ו-`U` הם בגודל זהה.)
//

/// בודק אם `ptr` מיושר כראוי ביחס ל-`align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// מעתיק `count *size_of::<T>()` בתים מ-`src` ל-`dst`.המקור והיעד חייבים* לא * לחפוף.
///
/// עבור אזורי זיכרון שעשויים להיות חופפים, השתמש במקום זאת ב-[`copy`].
///
/// `copy_nonoverlapping` שווה ערך סמנטי ל-[`memcpy`] של C, אך עם הסדר הטיעון הוחלף.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// ההתנהגות אינה מוגדרת אם מופר אחד מהתנאים הבאים:
///
/// * `src` חייב להיות [valid] לקריאת בתים `count * size_of::<T>()`.
///
/// * `dst` חייב להיות [valid] לכתיבה של בתים `count * size_of::<T>()`.
///
/// * שניהם `src` ו-`dst` חייבים להיות מיושרים כהלכה.
///
/// * אזור הזיכרון החל מ-`src` בגודל של 'ספירה *
///   מידה של: :<T>() `בתים חייבים *לא* לחפוף לאזור הזיכרון שמתחיל ב-`dst` באותו גודל.
///
/// כמו [`read`], `copy_nonoverlapping` יוצר עותק bitwise של `T`, ללא קשר לשאלה האם `T` הוא [`Copy`].
/// אם `T` אינו [`Copy`], השימוש ב-*שניהם* בערכים באזור שמתחיל ב-`*src` ובאזור שמתחיל ב-`* dst` יכול [violate memory safety][read-ownership].
///
///
/// שים לב שגם אם הגודל שהועתק ביעילות (`count * size_of: :<T>()`) הוא `0`, המצביעים חייבים להיות שאינם NULL ומיושרים כהלכה.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// יישום ידני של [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// מעביר את כל האלמנטים של `src` ל-`dst` ומשאיר את `src` ריק.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // וודא של-`dst` יש מספיק יכולת להכיל את כל ה-`src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // הקריאה לקיזוז תמיד בטוחה מכיוון ש-`Vec` לעולם לא יקצה יותר מ-`isize::MAX` בתים.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // חתוך את `src` מבלי להפיל את תוכנו.
///         // אנו עושים זאת תחילה, כדי להימנע מבעיות במקרה שמשהו בהמשך panics.
///         src.set_len(0);
///
///         // שני האזורים אינם יכולים לחפוף מכיוון שהפניות משתנות אינן כינוי, ושני vectors שונים אינם יכולים להחזיק באותו זיכרון.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // הודע ל-`dst` שהוא מכיל כעת את תוכן ה-`src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: בצע בדיקות אלה רק בזמן הריצה
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // לא נבהל כדי להקטין את ההשפעה על קודגן.
        abort();
    }*/

    // בטיחות: חוזה הבטיחות עבור `copy_nonoverlapping` חייב להיות
    // מאושר על ידי המתקשר.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// מעתיק `count * size_of::<T>()` בתים מ-`src` ל-`dst`.המקור והיעד עשויים להיות חופפים זה לזה.
///
/// אם המקור והיעד *לעולם* לא יחפפו, ניתן להשתמש ב-[`copy_nonoverlapping`] במקום זאת.
///
/// `copy` שווה ערך סמנטי ל-[`memmove`] של C, אך עם הסדר הטיעון הוחלף.
/// ההעתקה מתבצעת כאילו הבתים הועתקו מ-`src` למערך זמני ואז הועתקו מהמערך ל-`dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// ההתנהגות אינה מוגדרת אם מופר אחד מהתנאים הבאים:
///
/// * `src` חייב להיות [valid] לקריאת בתים `count * size_of::<T>()`.
///
/// * `dst` חייב להיות [valid] לכתיבה של בתים `count * size_of::<T>()`.
///
/// * שניהם `src` ו-`dst` חייבים להיות מיושרים כהלכה.
///
/// כמו [`read`], `copy` יוצר עותק bitwise של `T`, ללא קשר לשאלה האם `T` הוא [`Copy`].
/// אם `T` אינו [`Copy`], השימוש בערכים באזור שמתחילים ב-`*src` ובאזור שמתחיל ב-`* dst` יכול [violate memory safety][read-ownership].
///
///
/// שים לב שגם אם הגודל שהועתק ביעילות (`count * size_of: :<T>()`) הוא `0`, המצביעים חייבים להיות שאינם NULL ומיושרים כהלכה.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// צור ביעילות Rust vector ממאגר לא בטוח:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` חייב להיות מיושר כהלכה לסוגו ולא לאפס.
/// /// * `ptr` חייב להיות תקף לקריאת אלמנטים רציפים `elts` מסוג `T`.
/// /// * אסור להשתמש באלמנטים אלה לאחר קריאה לפונקציה זו אלא אם כן `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // בטיחות: התנאי המוקדם שלנו מבטיח שהמקור יהיה מיושר ותקף,
///     // ו-`Vec::with_capacity` מבטיח שיש לנו מקום שמיש לכתוב אותם.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // בטיחות: יצרנו את זה עם יכולת כה רבה קודם לכן,
///     // ו-`copy` הקודם אתחל אלמנטים אלה.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: בצע בדיקות אלה רק בזמן הריצה
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // לא נבהל כדי להקטין את ההשפעה על קודגן.
        abort();
    }*/

    // בטיחות: על חוזה הבטיחות עבור `copy` להתקיים על ידי המתקשר.
    unsafe { copy(src, dst, count) }
}

/// מגדיר `count * size_of::<T>()` בתים של זיכרון החל מ-`dst` עד `val`.
///
/// `write_bytes` דומה ל-[`memset`] של C, אך מגדיר `count * size_of::<T>()` בתים ל-`val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// ההתנהגות אינה מוגדרת אם מופר אחד מהתנאים הבאים:
///
/// * `dst` חייב להיות [valid] לכתיבה של בתים `count * size_of::<T>()`.
///
/// * `dst` חייב להיות מיושר כהלכה.
///
/// בנוסף, על המתקשר לוודא שכתיבת בתים `count * size_of::<T>()` לאזור הזיכרון הנתון מביאה לערך תקף של `T`.
/// השימוש באזור של זיכרון שהוקלד כ-`T` המכיל ערך לא חוקי של `T` אינו התנהגות מוגדרת.
///
/// שים לב שגם אם הגודל שהועתק ביעילות (`count * size_of: :<T>()`) הוא `0`, המצביע חייב להיות שאינו NULL ומיושר כהלכה.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// שימוש בסיסי:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// יצירת ערך לא חוקי:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // מדליף את הערך שהוחזק בעבר על ידי החלפת ה-`Box<T>` עם מצביע אפס.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // בשלב זה, שימוש או הטלה של `v` מביא להתנהגות לא מוגדרת.
/// // drop(v); // ERROR
///
/// // אפילו דולף `v` "uses" אותו, ומכאן התנהגות לא מוגדרת.
/// // mem::forget(v); // ERROR
///
/// // למעשה, `v` אינו חוקי על פי משתמשי פריסת סוג בסיסית, כך ש *כל* פעולה הנוגעת בו אינה התנהגות מוגדרת.
/////
/// // תן ל-v2 =v;//שגיאה
///
/// unsafe {
///     // הבה נכניס במקום ערך תקף
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // עכשיו התיבה בסדר
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // בטיחות: על חוזה הבטיחות עבור `write_bytes` להתקיים על ידי המתקשר.
    unsafe { write_bytes(dst, val, count) }
}