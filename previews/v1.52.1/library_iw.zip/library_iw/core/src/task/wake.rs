#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` מאפשר למיישם של מבצע משימות ליצור [`Waker`] המספק התנהגות התעוררות מותאמת אישית.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// הוא מורכב מצביע נתונים ו-[virtual function pointer table (vtable)][vtable] המותאם אישית את התנהגות ה-`RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// מצביע נתונים, אשר יכול לשמש לאחסון נתונים שרירותיים כנדרש על ידי המבצע.
    /// זה יכול להיות למשל
    /// מצביע מחוק לסוג `Arc` המשויך למשימה.
    /// הערך של שדה זה מועבר לכל הפונקציות שהן חלק מהטבלה כפרמטר הראשון.
    ///
    data: *const (),
    /// טבלת מצביעים לפונקציה וירטואלית המתאימה אישית את התנהגותו של הווייקר הזה.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// יוצר `RawWaker` חדש מהמצביע `data` שסופק ו-`vtable`.
    ///
    /// באמצעות מצביע ה-`data` ניתן לאחסן נתונים שרירותיים כנדרש על ידי המבצע.זה יכול להיות למשל
    /// מצביע מחוק לסוג `Arc` המשויך למשימה.
    /// הערך של המצביע הזה יועבר לכל הפונקציות שהן חלק מה-`vtable` כפרמטר הראשון.
    ///
    /// ה-`vtable` מותאם אישית את ההתנהגות של `Waker` שנוצר מ-`RawWaker`.
    /// עבור כל פעולה ב-`Waker`, הפונקציה המשויכת ב-`vtable` של ה-`RawWaker` הבסיסית תיקרא.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// טבלת מצביע פונקציה וירטואלית (vtable) המפרטת את התנהגות ה-[`RawWaker`].
///
/// המצביע שהועבר לכל הפונקציות בתוך הטבלה הוא מצביע ה-`data` מאובייקט ה-[`RawWaker`] הסוגר.
///
/// הפונקציות בתוך מבנה זה נועדו להיקרא רק על מצביע `data` של אובייקט [`RawWaker`] שנבנה כראוי מתוך היישום [`RawWaker`].
/// קריאה לאחת מהפונקציות הכלולות באמצעות כל מצביע `data` אחר תגרום להתנהגות לא מוגדרת.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// פונקציה זו תיקרא כאשר [`RawWaker`] משובט, למשל כאשר [`Waker`] שבו מאוחסן [`RawWaker`] משובט.
    ///
    /// יישום פונקציה זו חייב לשמור על כל המשאבים הנדרשים למופע נוסף זה של [`RawWaker`] ומשימה קשורה.
    /// קריאה ל-`wake` ב-[`RawWaker`] שהתקבל אמורה לגרום להתעוררות של אותה משימה שהייתה מתעוררת על ידי ה-[`RawWaker`] המקורי.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// פונקציה זו תיקרא כאשר `wake` נקרא ב-[`Waker`].
    /// עליו להעיר את המשימה הקשורה ל-[`RawWaker`] זה.
    ///
    /// על יישום פונקציה זו לוודא שחרור כל המשאבים הקשורים למופע זה של [`RawWaker`] ומשימה משויכת.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// פונקציה זו תיקרא כאשר `wake_by_ref` נקרא ב-[`Waker`].
    /// עליו להעיר את המשימה הקשורה ל-[`RawWaker`] זה.
    ///
    /// פונקציה זו דומה ל-`wake`, אך אסור לה לצרוך את מצביע הנתונים שסופק.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// פונקציה זו מתקשרת כאשר [`RawWaker`] יורד.
    ///
    /// על יישום פונקציה זו לוודא שחרור כל המשאבים הקשורים למופע זה של [`RawWaker`] ומשימה משויכת.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// יוצר `RawWakerVTable` חדש מהפונקציות `clone`, `wake`, `wake_by_ref` ו-`drop` המסופקות.
    ///
    /// # `clone`
    ///
    /// פונקציה זו תיקרא כאשר [`RawWaker`] משובט, למשל כאשר [`Waker`] שבו מאוחסן [`RawWaker`] משובט.
    ///
    /// יישום פונקציה זו חייב לשמור על כל המשאבים הנדרשים למופע נוסף זה של [`RawWaker`] ומשימה קשורה.
    /// קריאה ל-`wake` ב-[`RawWaker`] שהתקבל אמורה לגרום להתעוררות של אותה משימה שהייתה מתעוררת על ידי ה-[`RawWaker`] המקורי.
    ///
    /// # `wake`
    ///
    /// פונקציה זו תיקרא כאשר `wake` נקרא ב-[`Waker`].
    /// עליו להעיר את המשימה הקשורה ל-[`RawWaker`] זה.
    ///
    /// על יישום פונקציה זו לוודא שחרור כל המשאבים הקשורים למופע זה של [`RawWaker`] ומשימה משויכת.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// פונקציה זו תיקרא כאשר `wake_by_ref` נקרא ב-[`Waker`].
    /// עליו להעיר את המשימה הקשורה ל-[`RawWaker`] זה.
    ///
    /// פונקציה זו דומה ל-`wake`, אך אסור לה לצרוך את מצביע הנתונים שסופק.
    ///
    /// # `drop`
    ///
    /// פונקציה זו מתקשרת כאשר [`RawWaker`] יורד.
    ///
    /// על יישום פונקציה זו לוודא שחרור כל המשאבים הקשורים למופע זה של [`RawWaker`] ומשימה משויכת.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// ה-`Context` של משימה אסינכרונית.
///
/// נכון לעכשיו, `Context` משמש רק לספק גישה ל-`&Waker` אשר באמצעותו ניתן להעיר את המשימה הנוכחית.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // ודא שאנחנו הוכחות future כנגד שינויים בשונות על ידי אילוץ של החיים להיות בלתי משתנים (משך החיים של עמדת הטיעון מנוגד ואילו חיי המיקום של המיקום הם משתנים).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// צור `Context` חדש מ-`&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// מחזירה הפניה ל-`Waker` עבור המשימה הנוכחית.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` הוא ידית להתעוררות משימה על ידי הודעה למבצעה שהיא מוכנה להפעלה.
///
/// ידית זו מקפלת מופע [`RawWaker`], המגדיר את התנהגות ההשכמה הספציפית למבצע.
///
///
/// מיישם [`Clone`], [`Send`] ו-[`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// העיר את המשימה הקשורה ל-`Waker` זה.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // קריאת ההשכמה בפועל מועברת באמצעות שיחת פונקציה וירטואלית ליישום המוגדר על ידי המוציא לפועל.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // אל תתקשר ל-`drop`-הוויקר ייצרך על ידי `wake`.
        crate::mem::forget(self);

        // בטיחות: זה בטוח כי `Waker::from_raw` היא הדרך היחידה
        // לאתחל את `wake` ו-`data` המחייבים את המשתמש להכיר בכך שהחוזה של `RawWaker` נשמר.
        //
        unsafe { (wake)(data) };
    }

    /// העיר את המשימה הקשורה ל-`Waker` מבלי לצרוך את ה-`Waker`.
    ///
    /// זה דומה ל-`wake`, אך עשוי להיות מעט פחות יעיל במקרה בו `Waker` בבעלות זמין.
    /// יש להעדיף שיטה זו על פני שיחה ל-`waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // קריאת ההשכמה בפועל מועברת באמצעות שיחת פונקציה וירטואלית ליישום המוגדר על ידי המוציא לפועל.
        //

        // בטיחות: ראה `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// מחזירה `true` אם `Waker` זה ו-`Waker` אחר העירו את אותה משימה.
    ///
    /// פונקציה זו פועלת על בסיס המאמצים הטובים ביותר, והיא עשויה להחזיר שקר גם כאשר "Waker`s יעירו את אותה משימה.
    /// עם זאת, אם פונקציה זו מחזירה את `true`, מובטח ש-'Waker`s יעירו את אותה משימה.
    ///
    /// פונקציה זו משמשת בעיקר למטרות אופטימיזציה.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// יוצר `Waker` חדש מ-[`RawWaker`].
    ///
    /// ההתנהגות של ה-`Waker` שהוחזר אינה מוגדרת אם החוזה המוגדר בתיעוד ["RawWaker"] וב-"RawWakerVTable"] אינו מתקיים.
    ///
    /// לכן שיטה זו אינה בטוחה.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // בטיחות: זה בטוח כי `Waker::from_raw` היא הדרך היחידה
            // לאתחל את `clone` ו-`data` המחייבים את המשתמש להכיר בכך שהחוזה של [`RawWaker`] נשמר.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // בטיחות: זה בטוח כי `Waker::from_raw` היא הדרך היחידה
        // לאתחל את `drop` ו-`data` המחייבים את המשתמש להכיר בכך שהחוזה של `RawWaker` נשמר.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}