//! ה-Libcore prelude
//!
//! מודול זה מיועד למשתמשים ב-libcore שאינם מקשרים גם ל-libstd.
//! מודול זה מיובא כברירת מחדל כאשר נעשה שימוש ב-`#![no_std]` באותו אופן כמו prelude של הספרייה הסטנדרטית.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// גרסת 2015 של הליבה prelude.
///
/// ראה [module-level documentation](self) לקבלת מידע נוסף.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// גרסת 2018 של הליבה prelude.
///
/// ראה [module-level documentation](self) לקבלת מידע נוסף.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// גרסת 2021 של הליבה prelude.
///
/// ראה [module-level documentation](self) לקבלת מידע נוסף.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: הוסף עוד דברים.
}