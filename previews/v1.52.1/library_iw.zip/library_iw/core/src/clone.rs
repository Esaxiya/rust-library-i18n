//! ה-`Clone` trait לסוגים שלא ניתן 'להעתיק באופן מרומז'.
//!
//! ב-Rust, כמה סוגים פשוטים הם "implicitly copyable" וכאשר אתה מקצה אותם או מעביר אותם כוויכוחים, המקבל יקבל עותק וישאיר את הערך המקורי במקום.
//! סוגים אלה אינם מחייבים הקצאה להעתקה ואין להם מסופי גמר (כלומר, הם אינם מכילים תיבות בבעלות או מיישמים [`Drop`]), ולכן המהדר רואה בהם זול ובטוח להעתקה.
//!
//! עבור סוגים אחרים יש ליצור עותקים במפורש, על ידי אמנה ליישום ה-[`Clone`] trait וקריאה לשיטת [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! דוגמה לשימוש בסיסי:
//!
//! ```
//! let s = String::new(); // יישומי סוג מחרוזת משובטים
//! let copy = s.clone(); // כדי שנוכל לשבט את זה
//! ```
//!
//! כדי ליישם את ה-Clone trait בקלות, אתה יכול גם להשתמש ב-`#[derive(Clone)]`.דוגמא:
//!
//! ```
//! #[derive(Clone)] // אנו מוסיפים את המשובט trait למורפיאוס סטרוקטור
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ועכשיו נוכל לשבט את זה!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait נפוץ ליכולת שכפול מפורש של אובייקט.
///
/// שונה מ-[`Copy`] בכך ש-[`Copy`] הוא משתמע וזול ביותר, בעוד ש-`Clone` הוא תמיד מפורש ועשוי להיות יקר או לא.
/// על מנת לאכוף מאפיינים אלה, Rust אינו מאפשר לך להטמיע מחדש את [`Copy`], אך אתה רשאי להטמיע מחדש את `Clone` ולהפעיל קוד שרירותי.
///
/// מכיוון ש-`Clone` הוא כללי יותר מ-[`Copy`], אתה יכול להפוך את כל מה ש-[`Copy`] יהיה גם כן `Clone` באופן אוטומטי.
///
/// ## Derivable
///
/// ניתן להשתמש ב-trait עם `#[derive]` אם כל השדות הם `Clone`.היישום `נגזר` של [`Clone`] קורא ל-[`clone`] בכל שדה.
///
/// [`clone`]: Clone::clone
///
/// עבור מבנה גנרי, `#[derive]` מיישם את `Clone` באופן מותנה על ידי הוספת `Clone` מאוגד על פרמטרים גנריים.
///
/// ```
/// // `derive` מיישמת שיבוט לקריאה<T>כאשר T הוא שיבוט.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## כיצד אוכל ליישם את `Clone`?
///
/// לסוגים שהם [`Copy`] צריך להיות מיושם טריוויאלי של `Clone`.יותר פורמלי:
/// אם `T: Copy`, `x: T` ו-`y: &T`, אז `let x = y.clone();` שווה ערך ל-`let x = *y;`.
/// יישומים ידניים צריכים להקפיד על שמירה על סטנדרט זה;עם זאת, קוד לא בטוח אסור להסתמך עליו כדי להבטיח את בטיחות הזיכרון.
///
/// דוגמה היא מבנה גנרי המחזיק מצביע פונקציה.במקרה זה, ההטמעה של `Clone` אינה יכולה להיות "נגזרת", אלא ניתן ליישמה כ:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## מיישמים נוספים
///
/// בנוסף ל-[implementors listed below][impls], הסוגים הבאים מיישמים גם את `Clone`:
///
/// * סוגי פריטי פונקציה (כלומר, הסוגים המובהקים שהוגדרו עבור כל פונקציה)
/// * סוגי מצביעי פונקציה (למשל, `fn() -> i32`)
/// * סוגי מערכים, לכל הגדלים, אם סוג הפריט מיישם גם את `Clone` (למשל, `[i32; 123456]`)
/// * סוגי טופל, אם כל רכיב מיישם גם את `Clone` (למשל, `()`, `(i32, bool)`)
/// * סוגי סגירה, אם הם לא תופסים ערך מהסביבה או אם כל הערכים שנתפסו כאלה מיישמים את `Clone` בעצמם.
///   שים לב שמשתנים שנתפסו על ידי הפניה משותפת מיישמים תמיד את `Clone` (גם אם המפנה אינו עושה זאת), בעוד שמשתנים שנתפסו על ידי הפניה משתנה לעולם אינם מיישמים את `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// מחזיר עותק של הערך.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str מיישמת שיבוט
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// מבצע הקצאת העתקים מ-`source`.
    ///
    /// `a.clone_from(&b)` שווה ערך לפונקציונליות של `a = b.clone()`, אך ניתן לבטל אותה בכדי לעשות שימוש חוזר במשאבי `a` כדי למנוע הקצאות מיותרות.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// הפיק מאקרו ויצר תשתית של trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): סטרוקטורים אלה משמשים אך ורק על ידי#[נגזר] כדי להצהיר שכל רכיב מסוג מיישם שיבוט או העתקה.
//
//
// סטרוקטורות אלה לעולם לא צריכות להופיע בקוד המשתמש.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// יישומי `Clone` לסוגים פרימיטיביים.
///
/// יישומים שלא ניתן לתאר ב-Rust מיושמים ב-`traits::SelectionContext::copy_clone_conditions()` ב-`rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// ניתן לשכפל הפניות משותפות, אך הפניות משתנות *אינן יכולות*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// ניתן לשכפל הפניות משותפות, אך הפניות משתנות *אינן יכולות*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}