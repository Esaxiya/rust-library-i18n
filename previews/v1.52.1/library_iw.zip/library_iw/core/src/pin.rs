//! סוגים שמצמידים נתונים למיקומם בזיכרון.
//!
//! לעיתים מועיל שיהיו חפצים שמובטחים שלא יזוזו, במובן שמיקומם בזיכרון אינו משתנה, וכך ניתן לסמוך עליהם.
//! דוגמה מצוינת לתרחיש כזה תהיה בניית סטרוקטורות להתייחסות עצמית, שכן העברת אובייקט עם מצביעים לעצמו תביא לפסילתם, מה שעלול לגרום להתנהגות לא מוגדרת.
//!
//! ברמה גבוהה, [`Pin<P>`] מבטיח שלמצוין של כל מצביע מסוג `P` יהיה מיקום יציב בזיכרון, כלומר לא ניתן להזיז אותו למקום אחר ולא ניתן יהיה להקצות את הזיכרון שלו עד שהוא יורד.אנו אומרים שהמצביע הוא "pinned".הדברים נעשים עדינים יותר כאשר דנים בסוגים המשלבים מוצמדים עם נתונים שאינם מוצמדים;[see below](#projections-and-structural-pinning) לפרטים נוספים.
//!
//! כברירת מחדל, כל הסוגים ב-Rust ניתנים להזזה.
//! Rust מאפשר העברה של כל סוגי הערכים לפי סוגים שונים, וסוגי מצביעים חכמים נפוצים כגון [`Box<T>`] ו-`&mut T` מאפשרים להחליף ולהעביר את הערכים שהם מכילים: אתה יכול לצאת מ-[`Box<T>`], או להשתמש [`mem::swap`].
//! [`Pin<P>`] עוטף מצביע מסוג `P`, אז [`Pin`]`<`[`Box`] `<T>> מתפקד כמו רגיל
//!
//! [`Box<T>`]: when a [`Pin"] `<` [`Box`]`<T>>"יורד, כך גם תוכנו, והזיכרון מקבל
//!
//! מוקצה.באופן דומה, ["Pin"] `<&mut T>` דומה מאוד ל-`&mut T`.עם זאת, [`Pin<P>`] אינו מאפשר ללקוחות להשיג [`Box<T>`] או `&mut T` לנתונים מוצמדים בפועל, מה שמרמז כי אינך יכול להשתמש בפעולות כגון [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` זקוק ל-`&mut T`, אך איננו יכולים להשיג זאת.
//!     // אנו תקועים, איננו יכולים להחליף את תוכן הפניות.
//!     // אנו יכולים להשתמש ב-`Pin::get_unchecked_mut`, אך זה לא בטוח מסיבה:
//!     // אסור לנו להשתמש בו להעברת דברים מה-`Pin`.
//! }
//! ```
//!
//! ראוי לחזור ולהדגיש כי [`Pin<P>`] לא *משנה* את העובדה שמהדר Rust מחשיב את כל הסוגים למטלטלים.[`mem::swap`] נותר להתקשר לכל `T`.במקום זאת, [`Pin<P>`] מונע העברה של *ערכים* מסוימים (עליהם מצביעים מצביעים עטופים ב-[`Pin<P>`]) בכך שאי אפשר לקרוא לשיטות הדורשות `&mut T` עליהם (כמו [`mem::swap`]).
//!
//! [`Pin<P>`] ניתן להשתמש בכדי לעטוף כל סוג מצביע `P`, וככזה הוא מתקשר עם [`Deref`] ו-[`DerefMut`].[`Pin<P>`] שבו `P: Deref` צריך להיחשב כ-"`P`-style pointer" ל-`P::Target` מוצמד-כך, [[Pin "]" <"[" Box "]"<T>> "הוא מצביע בבעלות ל-`T` מוצמד, ו-[" Pin "]" <"[" Rc "]"<T>> הוא מצביע נספר להפניה ל-`T` מוצמד.
//! לצורך נכונות, [`Pin<P>`] מסתמך על היישומים של [`Deref`] ו-[`DerefMut`] שלא יעברו מהפרמטר `self` שלהם, ורק תמיד יחזירו מצביע לנתונים מוצמדים כאשר הם נקראים למצביע מוצמד.
//!
//! # `Unpin`
//!
//! סוגים רבים תמיד ניתנים להזזה באופן חופשי, גם כשהם מוצמדים, מכיוון שהם אינם מסתמכים על כך שיש להם כתובת יציבה.זה כולל את כל הסוגים הבסיסיים (כמו [`bool`], [`i32`] והפניות) וכן סוגים המורכבים אך ורק מסוגים אלה.סוגים שלא אכפת להם מהצמדה מיישמים את ה-[`Unpin`] auto-trait, שמבטל את ההשפעה של [`Pin<P>`].
//! עבור `T: Unpin`, [`Pin`]`<`[`Box`] '<T>> `ו-[`Box<T>`] מתפקדים באופן זהה, כמו גם [` Pin`]`<&mut T>` ו-`&mut T`.
//!
//! שים לב כי הצמדה ו-[`Unpin`] משפיעים רק על סוג `P::Target` המופנה, ולא על סוג המצביע `P` עצמו שנעטף ב-[`Pin<P>`].לדוגמא, האם [`Box<T>`] הוא [`Unpin`] ובין אם לאו, אין לו השפעה על ההתנהגות של [`Pin`]`<`[`Box`] `<T>>"(כאן, `T` הוא הסוג המחודד).
//!
//! # דוגמה: מבנה התייחסות עצמי
//!
//! לפני שנכנס לפרטים נוספים כדי להסביר את הערבויות והבחירות הקשורות ל-`Pin<T>`, נדון בכמה דוגמאות לאופן השימוש בהן.
//! אתה מוזמן ל-[skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // זהו מבנה התייחסות עצמי מכיוון ששדה הפרוסה מצביע על שדה הנתונים.
//! // איננו יכולים ליידע את המהדר על כך בהתייחסות רגילה, מכיוון שלא ניתן לתאר דפוס זה בכללי ההשאלה הרגילים.
//! //
//! // במקום זאת אנו משתמשים במצביע גולמי, אם כי ידוע שהוא אינו ריק, כידוע הוא מצביע על המחרוזת.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // כדי להבטיח שהנתונים לא זזים כאשר הפונקציה חוזרת, אנו מניחים אותם בערימה בה הם יישארו לכל אורך החיים של האובייקט, והדרך היחידה לגשת אליו תהיה באמצעות מצביע אליו.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // אנו יוצרים את המצביע רק לאחר שהנתונים נמצאים במקום אחרת הם כבר עברו לפני שהתחלנו
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // אנו יודעים שזה בטוח מכיוון ששינוי שדה לא מזיז את כל המבנה
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // המצביע צריך להצביע על המיקום הנכון, כל עוד המבנה לא זז.
//! //
//! // בינתיים אנו חופשיים להזיז את המצביע.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // מכיוון שהסוג שלנו לא מיישם Unpin, זה לא יצליח לקמפל:
//! // let mut_new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # דוגמה: רשימה פולשנית כפולת פולשנית
//!
//! ברשימה פולשנית המקושרת כפליים, האוסף אינו מקצה את הזיכרון לאלמנטים עצמם.
//! ההקצאה נשלטת על ידי הלקוחות, ואלמנטים יכולים לחיות על מסגרת מחסנית שחיה קצרה מזו של האוסף.
//!
//! כדי לגרום לעבודה זו, לכל אלמנט יש עצות לקודמו ויורשו ברשימה.ניתן להוסיף אלמנטים רק כאשר הם מוצמדים, מכיוון שהעברת האלמנטים מסביב תבטל את המצביעים.יתר על כן, הטמעת ה-[`Drop`] של אלמנט רשימה מקושר תדביק את המצביעים של קודמו ויורשו להסיר את עצמו מהרשימה.
//!
//! מכריע, עלינו להיות מסוגלים להסתמך על כך ש-[`drop`] נקרא.אם ניתן היה להקצות אלמנט או לפסול אותו בדרך אחרת מבלי להתקשר ל-[`drop`], המצביעים אליו מהאלמנטים הסמוכים שלו יהפכו לפסולים, מה שיפר את מבנה הנתונים.
//!
//! לכן, הצמדה מגיעה גם עם ערבות הקשורה [`טיפה`].
//!
//! # `Drop` guarantee
//!
//! מטרת ההצמדה היא להיות מסוגלים להסתמך על מיקום נתונים מסוימים בזיכרון.
//! כדי לגרום לכך לעבוד, לא רק העברת הנתונים מוגבלת;גם חלוקה לזיהוי, שימוש חוזר או ביטול אחר של הזיכרון המשמש לאחסון הנתונים מוגבלת.
//! באופן קונקרטי, עבור נתונים מוצמדים אתה צריך לשמור על המשתנה ש *הזיכרון שלו לא יבוטל או יוחזר לרגע מהרגע שהוא מוצמד ועד מתי נקרא [`drop`]*.רק ברגע ש-[`drop`] חוזר או panics, ניתן לעשות שימוש חוזר בזיכרון.
//!
//! זיכרון יכול להיות "invalidated" על ידי מיקום מיקום, אך גם על ידי החלפת [`Some(v)`] על ידי [`None`], או על ידי קריאת [`Vec::set_len`] ל-"kill" כמה אלמנטים מחוץ ל-vector.ניתן להחזיר אותו מחדש באמצעות [`ptr::write`] כדי להחליף אותו מבלי להתקשר לראשונה עם המשמיד.כל זה מותר לנתונים מוצמדים מבלי להתקשר ל-[`drop`].
//!
//! זה בדיוק סוג הערבות לכך שרשימת הקישורים החודרנית מהסעיף הקודם צריכה לתפקד כראוי.
//!
//! שימו לב שהתחייבות זו *לא* פירושה שהזיכרון לא דולף!זה עדיין בסדר לגמרי שלא להתקשר [`drop`] על אלמנט מוצמד (למשל, אתה עדיין יכול להתקשר ל-[`mem::forget`] על [[Pin "]" <"[" Box "]"<T>> `).בדוגמה של הרשימה המקושרת כפול, אלמנט זה פשוט יישאר ברשימה.עם זאת, אינך רשאי לפנות או לעשות שימוש חוזר באחסון *מבלי להתקשר אל [`drop`]*.
//!
//! # `Drop` implementation
//!
//! אם הסוג שלך משתמש בהצמדה (כגון שתי הדוגמאות לעיל), עליך להיות זהיר בעת יישום [`Drop`].הפונקציה [`drop`] לוקחת `&mut self`, אך זה נקרא *גם אם הסוג שלך הוצמד בעבר*!זה כאילו המהדר נקרא אוטומטית [`Pin::get_unchecked_mut`].
//!
//! זה לעולם לא יכול לגרום לבעיה בקוד בטוח מכיוון שיישום סוג שמסתמך על הצמדה דורש קוד לא בטוח, אך שים לב שהחלטה לעשות שימוש בהצמדה בסוג שלך (למשל על ידי ביצוע פעולה כלשהי על [`Pin`]`<&Self>"או [`Pin`] `<&mut Self>`) יש השלכות גם על יישום ה-[`Drop`] שלך: אם היה ניתן להצמיד אלמנט מהסוג שלך, עליך להתייחס ל-[`Drop`] כמי שנטל באופן מרומז [`Pin`]`<&mut עצמי>`.
//!
//!
//! לדוגמה, תוכל ליישם את `Drop` באופן הבא:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` זה בסדר מכיוון שאנו יודעים שערך זה אינו משמש שוב לאחר שנשמט.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // קוד הצניחה האמיתי מופיע כאן.
//!         }
//!     }
//! }
//! ```
//!
//! לפונקציה `inner_drop` יש את הסוג ש-[`drop`]*אמור להיות*, כך שזה מוודא שלא תשתמש בטעות ב-`self`/`this` באופן שעומד בסתירה להצמדה.
//!
//! יתר על כן, אם הסוג שלך הוא `#[repr(packed)]`, המהדר יעביר שדות באופן אוטומטי כדי להיות מסוגל להפיל אותם.זה עשוי אפילו לעשות זאת בשדות שבמקרה מיושרים מספיק.כתוצאה מכך, אינך יכול להשתמש בהצמדה עם סוג `#[repr(packed)]`.
//!
//! # תחזיות והצמדה מבנית
//!
//! כשעובדים עם סטרקטים מוצמדים, נשאלת השאלה כיצד ניתן לגשת לשדות של אותו מבנה בשיטה שלוקחת רק [`Pin"] `<&mut Struct>`.
//! הגישה המקובלת היא לכתוב שיטות עוזרות (מה שמכונה *תחזיות*) שהופכות את [`Pin"] `<&mut Struct>` להתייחסות לשדה, אך איזה סוג צריך להיות להפניה זו?האם זה [`Pin`]`<&mut Field>`או `&mut Field`?
//! אותה שאלה מתעוררת בשדות `enum`, וגם כאשר בוחנים סוגי container/wrapper כגון [`Vec<T>`], [`Box<T>`] או [`RefCell<T>`].
//! (שאלה זו מתייחסת הן להפניות משתנות והן להפניות משותפות, אנו משתמשים רק במקרה הנפוץ יותר של הפניות משתנות כאן להמחשה.)
//!
//! מתברר שלמעשה על מחבר מבנה הנתונים להחליט אם ההקרנה המוצמדת עבור שדה מסוים הופכת את [`Pin"] "<&mut Struct>" ל-["Pin"] "<&mut Field>" או `&mut Field`.ישנן אילוצים אף, והאילוץ החשוב ביותר הוא *עקביות*:
//! כל שדה יכול להיות *או* מוקרן להפניה מוצמדת,*או* להסרת הצמדה כחלק מההקרנה.
//! אם שניהם נעשים עבור אותו שדה, סביר להניח שזה לא נשמע!
//!
//! בתור המחבר של מבנה נתונים אתה יכול להחליט עבור כל תחום אם להצמיד "propagates" לשדה זה או לא.
//! הצמדה המופצת נקראת גם "structural" מכיוון שהיא עוקבת אחר מבנה הסוג.
//! בסעיפי המשנה הבאים אנו מתארים את השיקולים שיש לעשות בכל אחת מהבחירות.
//!
//! ## הצמדה *אינה* מבנית עבור `field`
//!
//! זה אולי נראה אינטואיטיבי שלא ניתן להצמיד את שדה המבנה המוצמד, אך זו למעשה הבחירה הקלה ביותר: אם [[Pin "]` <&mut Field> "לעולם לא נוצר, שום דבר לא יכול להשתבש!לכן, אם תחליט שלשדה כלשהו אין הצמדה מבנית, כל שעליך להבטיח הוא שלא תיצור לעולם הפניה מוצמדת לשדה זה.
//!
//! בשדות ללא הצמדה מבנית עשויה להיות שיטת השלכה שהופכת את [`Pin"] <&mut Struct> `ל-`&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // זה בסדר מכיוון ש-`field` מעולם לא נחשב כמוצמד.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! אתה יכול גם `impl Unpin for Struct`*גם אם* סוג `field` אינו [`Unpin`].מה הסוג ההוא חושב על הצמדה אינו רלוונטי כאשר מעולם לא נוצר [`Pin`]` <&mut Field>.
//!
//! ## הצמדה *היא* מבנית עבור `field`
//!
//! האפשרות האחרת היא להחליט כי הצמדה היא "structural" עבור `field`, כלומר אם המבנה מוצמד אז גם השדה.
//!
//! זה מאפשר כתיבת השלכה שיוצרת ["Pin"] "<&mut Field>", וכך ניתן לראות שהשדה מוצמד:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // זה בסדר מכיוון ש-`field` מוצמד כאשר `self` נמצא.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! עם זאת, הצמדה מבנית מגיעה עם כמה דרישות נוספות:
//!
//! 1. המבנה חייב להיות [`Unpin`] רק אם כל השדות המבניים הם [`Unpin`].זוהי ברירת המחדל, אך [`Unpin`] הוא trait בטוח, לכן ככותב המבנה באחריותך *לא* להוסיף משהו כמו `impl<T> Unpin for Struct<T>`.
//! (שימו לב כי הוספת פעולת הקרנה דורשת קוד לא בטוח, כך שהעובדה ש-[`Unpin`] הוא trait בטוח אינו מפר את העיקרון שעליכם לדאוג לכל זה אם אתם משתמשים ב'לא בטוח ').
//! 2. אסור להרוס המבנה להעביר שדות מבניים מהטיעון שלו.זו הנקודה המדויקת שהועלתה ב-[previous section][drop-impl]: `drop` לוקח `&mut self`, אך ייתכן שהמבנה (ומכאן השדות שלו) הוצמד בעבר.
//!     עליך להבטיח כי אינך מעביר שדה בתוך יישום ה-[`Drop`] שלך.
//!     בפרט, כפי שהוסבר קודם לכן, המשמעות היא שה-struct שלך חייב *לא* להיות `#[repr(packed)]`.
//!     עיין בסעיף זה כיצד לכתוב [`drop`] באופן שהמהדר יכול לעזור לך לא לשבור את הצמדה בטעות.
//! 3. עליך לוודא שאתה מקיים את ה-[`Drop` guarantee][drop-guarantee]:
//!     ברגע שהמבנה שלך מוצמד, הזיכרון שמכיל את התוכן אינו מוחלף או מועבר מבלי לקרוא למשמידי התוכן.
//!     זה יכול להיות מסובך, כפי שמעידים [`VecDeque<T>`]: המשמיד של [`VecDeque<T>`] יכול להיכשל בקריאה ל-[`drop`] על כל האלמנטים אם אחד ההורסים panics.זה מפר את התחייבות ה-[`Drop`], מכיוון שזה יכול להוביל למקצה של אלמנטים מבלי שייקרא הרס שלהם.(ל-[`VecDeque<T>`] אין תחזיות הצמדה, כך שהדבר אינו גורם לאי נוחות.)
//! 4. אסור לך להציע פעולות אחרות העלולות להוביל להעברת נתונים מהשדות המבניים כאשר סוגך מוצמד.לדוגמא, אם המבנה מכיל [`Option<T>`] וישנה פעולה כמו 'קח' עם סוג `fn(Pin<&mut Struct<T>>) -> Option<T>`, ניתן להשתמש בפעולה זו להעברת `T` מתוך `Struct<T>` מוצמד-מה שאומר שסיכה לא יכולה להיות מבנית עבור השדה המחזיק את זה נתונים.
//!
//!     לדוגמא מורכבת יותר להעברת נתונים מהסוג המוצמד, דמיין אם ל-[`RefCell<T>`] הייתה שיטה `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     ואז נוכל לעשות את הפעולות הבאות:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     זה קטסטרופלי, זה אומר שאנחנו יכולים קודם להצמיד את תוכן ה-[`RefCell<T>`] (באמצעות `RefCell::get_pin_mut`) ואז להזיז את התוכן באמצעות ההפניה המשתנה שקיבלנו מאוחר יותר.
//!
//! ## Examples
//!
//! עבור סוג כמו [`Vec<T>`], שתי האפשרויות (הצמדה מבנית או לא) הגיוניות.
//! ל-[`Vec<T>`] עם הצמדה מבנית יכולות להיות שיטות `get_pin`/`get_pin_mut` כדי לקבל הפניות מוצמדות לאלמנטים.עם זאת, זה לא יכול *לא* לאפשר קריאה ל-[`pop`][Vec::pop] ב-[`Vec<T>`] מוצמד מכיוון שזה יעביר את התוכן (המוצמד מבחינה מבנית)!זה גם לא יכול לאפשר [`push`][Vec::push], שעשוי להקצות מחדש וכך גם להזיז את התוכן.
//!
//! [`Vec<T>`] ללא הצמדה מבנית יכול היה `impl<T> Unpin for Vec<T>`, מכיוון שהתוכן לעולם אינו מוצמד וה-[`Vec<T>`] עצמו בסדר גם עם העברתו.
//! בשלב זה להצמדת פשוט אין כל השפעה על ה-vector.
//!
//! בספרייה הסטנדרטית, לרוב סוגי המצביעים אין הצמדה מבנית, ולכן הם אינם מציעים תחזיות הצמדה.זו הסיבה ש-`Box<T>: Unpin` מחזיק עבור כל `T`.
//! זה הגיוני לעשות זאת עבור סוגי מצביעים, מכיוון שהזזת ה-`Box<T>` לא ממש מעבירה את ה-`T`: ה-[`Box<T>`] יכול להיות זז בחופשיות (aka `Unpin`) גם אם ה-`T` אינו.למעשה, אפילו [`Pin`]`<`[`Box`] `<T>>`ו-[`Pin`] `<&mut T>` הם תמיד [`Unpin`] עצמם, מאותה סיבה: התוכן שלהם (ה-`T`) מוצמד, אך ניתן להזיז את המצביעים עצמם מבלי להזיז את הנתונים המוצמדים.
//! הן עבור [`Box<T>`] והן [`Pin`]`<`[`Box`] '<T>>, האם התוכן מוצמד אינו תלוי לחלוטין אם המצביע מוצמד, כלומר הצמדה *אינה* מבנית.
//!
//! בעת יישום קומבינטור [`Future`], בדרך כלל תזדקק להצמדה מבנית עבור ה-futures המקוננים, מכיוון שאתה צריך לקבל הפניות מוצמדות אליהם כדי להתקשר ל-[`poll`].
//! אך אם המשלב שלך מכיל נתונים אחרים שאין צורך להצמיד אותם, אתה יכול להפוך את השדות לא למבניים ולכן לגשת אליהם בחופשיות עם הפניה ניתנת לשינוי גם כשיש לך רק "Pin"] <&mut Self> (כגון כמו ביישום [`poll`] משלך).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// מצביע מוצמד.
///
/// זהו עטיפה סביב סוג של מצביע שהופך את אותו מצביע "pin" לערכו במקום, ומונע את העברת הערך שמפנה אותו מצביע אלא אם כן הוא מיישם את [`Unpin`].
///
///
/// *לקבלת הסבר על הצמדה, עיין בתיעוד של [`pin` module].*
///
/// [`pin` module]: self
///
// Note: נגזרת ה-`Clone` שלמטה גורמת לאי סביבה מכיוון שאפשר ליישם אותה
// `Clone` להפניות משתנות.
// לפרטים נוספים, ראה <https://internals.rust-lang.org/t/unsoundness-in-pin/11311>.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// היישומים הבאים אינם נגזרים על מנת להימנע מבעיות תקינות.
// `&self.pointer` לא אמור להיות נגיש ליישומי trait שאינם מהימנים.
//
// לפרטים נוספים, ראה <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73>.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// בנה `Pin<P>` חדש סביב מצביע לכמה נתונים מהסוג המיישם את [`Unpin`].
    ///
    /// בניגוד ל-`Pin::new_unchecked`, שיטה זו בטוחה מכיוון שהמצביע `P` מפנה לסוג [`Unpin`], המבטל את התחייבויות ההצמדה.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // בטיחות: הערך שמצביע עליו הוא `Unpin`, ולכן אין דרישות
        // סביב הצמדה.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// מבטל את העטיפה של ה-`Pin<P>` ומחזיר את המצביע הבסיסי.
    ///
    /// זה דורש שהנתונים בתוך `Pin` זה הם [`Unpin`], כך שנוכל להתעלם מהמשתנים הצמודים כאשר אנו עוטפים אותם.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// בנה `Pin<P>` חדש סביב הפניה לנתונים מסוימים מהסוג שאולי מיישם `Unpin` או לא.
    ///
    /// אם `pointer` מפנים סוג `Unpin`, יש להשתמש במקום זאת ב-`Pin::new`.
    ///
    /// # Safety
    ///
    /// קונסטרוקטור זה אינו בטיחותי מכיוון שאיננו יכולים להבטיח שהנתונים אליהם הצביע `pointer` מוצמדים, כלומר הנתונים לא יועברו או שהאחסון שלהם יבוטל עד שיישמט.
    /// אם ה-`Pin<P>` שנבנה אינו מבטיח שהנתונים ש-`P` מצביע עליהם מוצמדים, זו הפרה של חוזה ה-API ועלול להוביל להתנהגות לא מוגדרת בפעולות (safe) מאוחרות יותר.
    ///
    /// באמצעות שיטה זו, אתה מבצע promise לגבי יישומי `P::Deref` ו-`P::DerefMut`, אם הם קיימים.
    /// והכי חשוב, אסור להם לצאת מטיעוני `self` שלהם: `Pin::as_mut` ו-`Pin::as_ref` יתקשרו ל `DerefMut::deref_mut` ו-`Deref::deref`*על המצביע המוצמד* ויצפו כי שיטות אלה ישמרו על הזרמים הצמודים.
    /// יתר על כן, על ידי קריאת שיטה זו אתה promise שההפניות `P` להפניות אליה לא יועברו שוב;בפרט, לא יתכן שיהיה אפשר להשיג `&mut P::Target` ואז לצאת מההפניה (באמצעות, למשל [`mem::swap`]).
    ///
    ///
    /// לדוגמה, קריאה ל-`Pin::new_unchecked` ב-`&'a mut T` אינה בטוחה מכיוון שאמנם אתה מסוגל להצמיד אותה לכל אורך החיים הנתון ל-`'a`, אך אין לך שליטה אם היא נשמרת מוצמנת לאחר סיום `'a`:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // פירוש הדבר שהמצוין `a` לעולם לא יוכל לזוז שוב.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // הכתובת של `a` השתנתה לחריץ המחסנית של 'b', כך ש-`a` התרגש למרות שהצמדנו אותו בעבר!הפרנו את חוזה ה-API הצמוד.
    /////
    /// }
    /// ```
    ///
    /// ערך, לאחר שהוצמד, חייב להישאר מוצמד לנצח (אלא אם כן סוגו מיישם את `Unpin`).
    ///
    /// באופן דומה, קריאה ל-`Pin::new_unchecked` ב-`Rc<T>` אינה בטוחה מכיוון שיכולות להיות כינויים לאותם נתונים שאינם כפופים למגבלות הצמדה:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // זה אומר שהמצוין לעולם לא יכול לזוז שוב.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // כעת, אם `x` היה ההתייחסות היחידה, יש לנו התייחסות ניתנת לשינוי לנתונים שהצמדנו לעיל, בה נוכל להשתמש כדי להזיז אותם כפי שראינו בדוגמה הקודמת.
    ///     // הפרנו את חוזה ה-API הצמוד.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// מקבל הפניה משותפת מוצמדת מהמצביע המוצמד הזה.
    ///
    /// זוהי שיטה כללית לעבור מ-`&Pin<Pointer<T>>` ל-`Pin<&T>`.
    /// זה בטוח מכיוון שכחלק מהחוזה של `Pin::new_unchecked`, המציע לא יכול לנוע לאחר יצירת `Pin<Pointer<T>>`.
    ///
    /// "Malicious" יישומי `Pointer::Deref` נשללים גם הם על ידי החוזה של `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // בטיחות: עיין בתיעוד על פונקציה זו
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// מבטל את העטיפה של ה-`Pin<P>` ומחזיר את המצביע הבסיסי.
    ///
    /// # Safety
    ///
    /// פונקציה זו אינה בטוחה.עליכם להבטיח כי תמשיכו להתייחס למצביע `P` כמוצמד לאחר שתקראו לפונקציה זו, כך שניתן יהיה לשמור על המשתתפים מהסוג `Pin`.
    /// אם הקוד המשתמש ב-`P` המתקבל אינו ממשיך לשמור על תושבי ההצמדה המהווים הפרה של חוזה ה-API ועלול להוביל להתנהגות לא מוגדרת בפעולות (safe) מאוחרות יותר.
    ///
    ///
    /// אם הנתונים הבסיסיים הם [`Unpin`], במקום זאת יש להשתמש ב-[`Pin::into_inner`].
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// מקבל הפניה משתנה מוצמדת מהמצביע המוצמד הזה.
    ///
    /// זוהי שיטה כללית לעבור מ-`&mut Pin<Pointer<T>>` ל-`Pin<&mut T>`.
    /// זה בטוח מכיוון שכחלק מהחוזה של `Pin::new_unchecked`, המציע לא יכול לנוע לאחר יצירת `Pin<Pointer<T>>`.
    ///
    /// "Malicious" יישומי `Pointer::DerefMut` נשללים גם הם על ידי החוזה של `Pin::new_unchecked`.
    ///
    /// שיטה זו שימושית בעת ביצוע שיחות מרובות לפונקציות הצורכות את הסוג המוצמד.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // עשה משהו
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` צורכת `self`, אז חזרו על ה-`Pin<&mut Self>` באמצעות `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // בטיחות: עיין בתיעוד על פונקציה זו
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// מקצה ערך חדש לזיכרון שמאחורי ההפניה המוצמדת.
    ///
    /// זה מחליף נתונים מוצמדים, אבל זה בסדר: המשמיד שלה מתנהל לפני שיעתוק, ולכן לא הופרה כל ערבות הצמדה.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// בונה סיכה חדשה על ידי מיפוי ערך הפנים.
    ///
    /// לדוגמה, אם אתה רוצה להשיג `Pin` של שדה של משהו, אתה יכול להשתמש בזה כדי לקבל גישה לשדה זה בשורת קוד אחת.
    /// עם זאת, ישנם מספר gotchas עם "pinning projections" אלה;
    /// עיין בתיעוד [`pin` module] לפרטים נוספים בנושא זה.
    ///
    /// # Safety
    ///
    /// פונקציה זו אינה בטוחה.
    /// עליך להבטיח שהנתונים שאתה מחזיר לא יזוזו כל עוד ערך הארגומנט לא זז (למשל מכיוון שהם אחד מהשדות של אותו ערך), וגם שאתה לא זז מהוויכוח שאתה מקבל אליו פונקציית הפנים.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // בטיחות: חוזה הבטיחות עבור `new_unchecked` חייב להיות
        // מאושר על ידי המתקשר.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// מקבל הפניה משותפת מתוך סיכה.
    ///
    /// זה בטוח כי לא ניתן לצאת מהפניה משותפת.
    /// זה אולי נראה שיש כאן בעיה עם שינויים בפנים: למעשה, אפשר * להעביר `T` מ-`&RefCell<T>`.
    /// עם זאת, זו לא בעיה כל עוד אין גם `Pin<&T>` שמצביע על אותם נתונים, ו-`RefCell<T>` לא מאפשר לך ליצור סימוכין מוצמד לתוכנו.
    ///
    /// ראה דיון ב-["pinning projections"] לפרטים נוספים.
    ///
    /// Note: `Pin` מיישם גם את `Deref` אל היעד, שניתן להשתמש בו כדי לגשת לערך הפנימי.
    /// עם זאת, `Deref` מספק רק הפניה שחיה כל עוד ההשאלה של ה-`Pin`, ולא חייו של ה-`Pin` עצמו.
    /// שיטה זו מאפשרת להפוך את ה-`Pin` להפניה עם אותו חיים כמו ה-`Pin` המקורי.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// ממיר את ה-`Pin<&mut T>` הזה ל-`Pin<&T>` עם אותו החיים.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// מקבל התייחסות משתנה לנתונים בתוך ה-`Pin` הזה.
    ///
    /// זה דורש שהנתונים בתוך `Pin` זה הם `Unpin`.
    ///
    /// Note: `Pin` מיישם גם את `DerefMut` לנתונים, שניתן להשתמש בהם כדי לגשת לערך הפנימי.
    /// עם זאת, `DerefMut` מספק רק הפניה שחיה כל עוד ההשאלה של ה-`Pin`, ולא חייו של ה-`Pin` עצמו.
    ///
    /// שיטה זו מאפשרת להפוך את ה-`Pin` להפניה עם אותו חיים כמו ה-`Pin` המקורי.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// מקבל התייחסות משתנה לנתונים בתוך ה-`Pin` הזה.
    ///
    /// # Safety
    ///
    /// פונקציה זו אינה בטוחה.
    /// עליכם להבטיח שלעולם לא תעבירו את הנתונים מההפניה הניתנת לשינוי שתקבלו כשאתם קוראים לפונקציה זו, כך שניתן יהיה לשמור על המשתמרים מהסוג `Pin`.
    ///
    ///
    /// אם הנתונים הבסיסיים הם `Unpin`, במקום זאת יש להשתמש ב-`Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// בנה סיכה חדשה על ידי מיפוי הערך הפנימי.
    ///
    /// לדוגמה, אם אתה רוצה להשיג `Pin` של שדה של משהו, אתה יכול להשתמש בזה כדי לקבל גישה לשדה זה בשורת קוד אחת.
    /// עם זאת, ישנם מספר gotchas עם "pinning projections" אלה;
    /// עיין בתיעוד [`pin` module] לפרטים נוספים בנושא זה.
    ///
    /// # Safety
    ///
    /// פונקציה זו אינה בטוחה.
    /// עליך להבטיח שהנתונים שאתה מחזיר לא יזוזו כל עוד ערך הארגומנט לא זז (למשל מכיוון שהם אחד מהשדות של אותו ערך), וגם שאתה לא זז מהוויכוח שאתה מקבל אליו פונקציית הפנים.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // בטיחות: המתקשר אחראי לא להזיז את
        // ערך מתוך התייחסות זו.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // בטיחות: שכן הערך של `this` מובטח שלא יהיה
        // הועבר החוצה, השיחה הזו ל-`new_unchecked` בטוחה.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// קבל הפניה מוצמדת מהפניה סטטית.
    ///
    /// זה בטוח כי `T` מושאל לכל החיים `'static`, שלעולם לא מסתיים.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // בטיחות: ההלוואות הסטטיות מבטיחות שהנתונים לא יהיו
        // moved/invalidated עד שהוא יורד (וזה אף פעם לא).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// קבל הפניה משתנה מוצמדת מהפניה משתנה סטטית.
    ///
    /// זה בטוח כי `T` מושאל לכל החיים `'static`, שלעולם לא מסתיים.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // בטיחות: ההלוואות הסטטיות מבטיחות שהנתונים לא יהיו
        // moved/invalidated עד שהוא יורד (וזה אף פעם לא).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: המשמעות היא שכל יישום של `CoerceUnsized` המאפשר כפייה מ
// סוג שמשתמש ב-`Deref<Target=impl !Unpin>` לסוג שמשתמש ב-`Deref<Target=Unpin>` אינו נשמע.
// ככל הנראה כל מכשיר כזה לא יהיה נשמע מסיבות אחרות, ולכן עלינו רק לדאוג לא לאפשר לנחלים כאלה לנחות ב-std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}