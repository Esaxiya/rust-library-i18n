//! מודול זה מיישם את `Any` trait, המאפשר הקלדה דינמית של כל סוג `'static` באמצעות השתקפות בזמן ריצה.
//!
//! `Any` עצמו יכול לשמש לקבלת `TypeId`, ויש לו יותר תכונות כאשר הוא משמש כאובייקט trait.
//! כ-`&dyn Any` (אובייקט trait שאול), יש לו את השיטות `is` ו-`downcast_ref`, כדי לבדוק אם הערך הכלול הוא מסוג נתון, וכדי לקבל התייחסות לערך הפנימי כסוג.
//! כ-`&mut dyn Any`, קיימת גם שיטת `downcast_mut`, לקבלת התייחסות משתנה לערך הפנימי.
//! `Box<dyn Any>` מוסיף את שיטת `downcast`, המנסה להמיר ל-`Box<T>`.
//! לפרטים המלאים עיין בתיעוד [`Box`].
//!
//! שים לב ש-`&dyn Any` מוגבל לבדיקה אם ערך הוא מסוג בטון מוגדר, ולא ניתן להשתמש בו כדי לבדוק אם סוג מיישם trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # מצביעים חכמים ו-`dyn Any`
//!
//! פיסת התנהגות אחת שיש לזכור בעת השימוש ב-`Any` כאובייקט trait, במיוחד עם סוגים כמו `Box<dyn Any>` או `Arc<dyn Any>`, היא שפשוט קריאה ל-`.type_id()` בערך תייצר את ה-`TypeId` של *המכולה*, ולא האובייקט trait הבסיסי.
//!
//! ניתן להימנע מכך על ידי המרת המצביע החכם ל-`&dyn Any` במקום, שיחזיר את ה-`TypeId` של האובייקט.
//! לדוגמה:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // סביר יותר שתרצה את זה:
//! let actual_id = (&*boxed).type_id();
//! // ... מאשר זה:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! שקול סיטואציה בה אנו רוצים להתנתק מערך המועבר לפונקציה.
//! אנו יודעים את הערך שאנו עובדים על יישומי Debug, אך איננו יודעים מהו סוג הבטון שלו.אנו רוצים לתת יחס מיוחד לסוגים מסוימים: במקרה זה הדפסת אורך ערכי המחרוזת לפני ערכם.
//! איננו יודעים את סוג הקונקרטי של הערך שלנו בזמן הקומפילציה, ולכן עלינו להשתמש בהשתקפות זמן ריצה במקום.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // פונקציית לוגר לכל סוג שמיישם את הבאגים.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // נסה להמיר את הערך שלנו ל-`String`.
//!     // אם יצליח, אנו רוצים להפיק את אורך המחרוזת` כמו גם את ערכו.
//!     // אם לא, זה סוג אחר: פשוט הדפיסו אותו ללא קישוט.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // פונקציה זו מעוניינת להתנתק מהפרמטר שלה לפני שהיא עושה איתה עבודה.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... לעשות עבודה אחרת
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// כל trait
///////////////////////////////////////////////////////////////////////////////

/// trait לחיקוי הקלדה דינמית.
///
/// רוב הסוגים מיישמים את `Any`.עם זאת, כל סוג המכיל התייחסות שאינה "סטטית" לא.
/// לפרטים נוספים, עיין ב-[module-level documentation][mod].
///
/// [mod]: crate::any
// trait זה לא בטוח, אם כי אנו מסתמכים על הפרטים של פונקציית `type_id` של ה-impl היחידה בקוד לא בטוח (למשל, `downcast`).בדרך כלל, זו תהיה בעיה, אך מכיוון שהיישום היחיד של `Any` הוא יישום שמיכה, שום קוד אחר אינו יכול ליישם את `Any`.
//
// אנו יכולים להפוך את trait באופן לא סביר-זה לא יגרום לשבירה, מכיוון שאנו שולטים בכל היישומים-אך אנו בוחרים שלא כי זה גם לא הכרחי ועשויים לבלבל את המשתמשים לגבי הבחנה בין traits לא בטוחים ושיטות לא בטוחות (כלומר `type_id` עדיין יהיה בטוח להתקשר אליו, אך סביר להניח שנרצה לציין ככזה בתיעוד).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// מקבל את ה-`TypeId` של ה-`self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// שיטות הרחבה לכל אובייקט trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// ודא כי ניתן להדפיס את התוצאה של למשל הצטרפות לשרשור ולהשתמש בה עם `unwrap`.
// בסופו של דבר לא יהיה צורך יותר אם המשלוח יעבוד עם עדנות.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// מחזירה `true` אם סוג התיבה זהה ל-`T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // קבל `TypeId` מהסוג שהפונקציה הזו מיומנת איתו.
        let t = TypeId::of::<T>();

        // קבל `TypeId` מהסוג באובייקט trait (`self`).
        let concrete = self.type_id();

        // השווה בין שני סוגי ה-ID בנושא שוויון.
        t == concrete
    }

    /// מחזיר איזשהו התייחסות לערך התיבה אם הוא מסוג `T`, או `None` אם הוא לא.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // בטיחות: פשוט בדק אם אנחנו מצביעים על הסוג הנכון, ואנחנו יכולים לסמוך עליו
            // זה בודק את בטיחות הזיכרון מכיוון שיישמנו את Any לכל הסוגיםשום מכשירים אחרים לא יכולים להתקיים מכיוון שהם היו מתנגשים עם המשתמע שלנו
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// מחזירה איזשהו הפניה משתנה לערך התיבה אם היא מסוג `T`, או `None` אם היא לא.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // בטיחות: פשוט בדק אם אנחנו מצביעים על הסוג הנכון, ואנחנו יכולים לסמוך עליו
            // זה בודק את בטיחות הזיכרון מכיוון שיישמנו את Any לכל הסוגיםשום מכשירים אחרים לא יכולים להתקיים מכיוון שהם היו מתנגשים עם המשתמע שלנו
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// מעביר לשיטה המוגדרת בסוג `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// מעביר לשיטה המוגדרת בסוג `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// מעביר לשיטה המוגדרת בסוג `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// מעביר לשיטה המוגדרת בסוג `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// מעביר לשיטה המוגדרת בסוג `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// מעביר לשיטה המוגדרת בסוג `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID ושיטותיה
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` מייצג מזהה ייחודי בעולם לסוג.
///
/// כל `TypeId` הוא אובייקט אטום שאינו מאפשר בדיקה של מה שבתוכו, אך מאפשר פעולות בסיסיות כגון שיבוט, השוואה, הדפסה והצגה.
///
///
/// `TypeId` זמין כרגע רק לסוגים המייחסים ל-`'static`, אך ניתן להסיר מגבלה זו ב-future.
///
/// בעוד ש-`TypeId` מיישם את `Hash`, `PartialOrd` ו-`Ord`, ראוי לציין כי החשיפה וההזמנה ישתנו בין מהדורות Rust.
/// היזהר מלהסתמך עליהם בתוך הקוד שלך!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// מחזירה את ה-`TypeId` מהסוג שהפונקציה הגנרית הזו הותקנה איתו.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// מחזיר את שם הסוג כפרוסת מחרוזת.
///
/// # Note
///
/// זה מיועד לשימוש אבחוני.
/// התוכן והפורמט המדויק של המחרוזת שהוחזרה אינם מוגדרים, מלבד תיאור המאמץ הטוב ביותר של הסוג.
/// לדוגמא, בין המיתרים ש-`type_name::<Option<String>>()` עשוי להחזיר הם `"Option<String>"` ו-`"std::option::Option<std::string::String>"`.
///
///
/// אין להחשיב את המחרוזת שהוחזרה כמזהה ייחודי מסוג, מכיוון שסוגים מרובים עשויים למפות לאותו שם סוג.
/// באופן דומה, אין כל ערובה לכך שכל חלקי הסוג יופיעו במחרוזת המוחזרת: למשל, מצייני חיים אינם כלולים כרגע.
/// בנוסף, הפלט עשוי להשתנות בין גרסאות המהדר.
///
/// היישום הנוכחי משתמש באותה תשתית כמו אבחון מהדר ו-debuginfo, אך הדבר אינו מובטח.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// מחזיר את שם סוג הערך המופנה כפרוסת מחרוזת.
/// זה זהה ל-`type_name::<T>()`, אך ניתן להשתמש בו כאשר סוג המשתנה אינו זמין בקלות.
///
/// # Note
///
/// זה מיועד לשימוש אבחוני.התוכן והפורמט המדויק של המחרוזת אינם מוגדרים, למעט תיאור המאמץ הטוב ביותר של הסוג.
/// לדוגמה, `type_name_of_val::<Option<String>>(None)` יכול להחזיר `"Option<String>"` או `"std::option::Option<std::string::String>"`, אך לא `"foobar"`.
///
/// בנוסף, הפלט עשוי להשתנות בין גרסאות המהדר.
///
/// פונקציה זו אינה פותרת אובייקטים של trait, כלומר `type_name_of_val(&7u32 as &dyn Debug)` עשוי להחזיר `"dyn Debug"`, אך לא `"u32"`.
///
/// אין לראות את שם הסוג כמזהה ייחודי מסוג;
/// מספר סוגים עשויים לשתף את אותו שם סוג.
///
/// היישום הנוכחי משתמש באותה תשתית כמו אבחון מהדר ו-debuginfo, אך הדבר אינו מובטח.
///
/// # Examples
///
/// מדפיס את סוגי המספרים השלמים והציפה המוגדרים כברירת מחדל.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}