//! מגדיר את האיטרטור שבבעלות `IntoIter` למערכים.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// איטררטור [array] בעל ערך.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// זהו המערך עליו אנו חוזרים.
    ///
    /// אלמנטים עם אינדקס `i` שבו `alive.start <= i < alive.end` טרם הובאו והם רשומות מערך תקפות.
    /// אלמנטים עם מדדים `i < alive.start` או `i >= alive.end` כבר הושגו ואין לגשת אליהם יותר!אותם גורמים מתים עשויים אפילו להיות במצב לא מאוחד לחלוטין!
    ///
    ///
    /// אז הפושעים הם:
    /// - `data[alive]` חי (כלומר מכיל אלמנטים תקפים)
    /// - `data[..alive.start]` ו-`data[alive.end..]` מתים (כלומר, האלמנטים כבר נקראו ואסור לגעת בהם יותר!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// האלמנטים ב-`data` שעוד לא הופקו.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// יוצר איטרטור חדש על `array` הנתון.
    ///
    /// *הערה*: שיטה זו עשויה להיות מוצלחת ב-future, לאחר [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // סוג ה-`value` הוא `i32` כאן, במקום `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // בטיחות: התמורה כאן היא למעשה בטוחה.המסמכים של `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` מובטח שיהיה באותו הגודל והיישור
        // > כמו `T`.
        //
        // המסמכים אפילו מראים טרנסמטר ממערך של `MaybeUninit<T>` למערך של `T`.
        //
        //
        // עם זאת, אתחול זה מספק את הפושעים.

        // FIXME(LukasKalbertodt): למעשה השתמש ב-`mem::transmute` כאן, ברגע שזה עובד עם const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // עד אז נוכל להשתמש ב-`mem::transmute_copy` כדי ליצור עותק סיבתי כסוג אחר, ואז לשכוח את `array` כדי שלא יישמט.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// מחזיר פרוסה בלתי ניתנת לשינוי של כל האלמנטים שעדיין לא הופקו.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // בטיחות: אנו יודעים שכל האלמנטים ב-`alive` מאותחל כראוי.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// מחזיר פרוסה ניתנת לשינוי של כל האלמנטים שעדיין לא הופקו.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // בטיחות: אנו יודעים שכל האלמנטים ב-`alive` מאותחל כראוי.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // קבל את האינדקס הבא מלפנים.
        //
        // הגדלת ה-`alive.start` ב-1 שומרת על המשתנה לגבי `alive`.
        // עם זאת, בשל שינוי זה, לזמן קצר, אזור החיים אינו `data[alive]` יותר, אלא `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // קרא את האלמנט מהמערך.
            // בטיחות: `idx` הוא אינדקס לאזור "alive" לשעבר של
            // מַעֲרָך.קריאת אלמנט זה פירושה ש-`data[idx]` נחשב למת עכשיו (כלומר אל תיגע).
            // מכיוון ש-`idx` היה תחילתו של אזור החיים, אזור החיים הוא כעת שוב `data[alive]`, ומשחזר את כל הפושעים.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // קבל את האינדקס הבא מאחור.
        //
        // הפחתת `alive.end` ב-1 שומרת על המשתנה הקבוע לגבי `alive`.
        // עם זאת, בשל שינוי זה, לזמן קצר, אזור החיים אינו `data[alive]` יותר, אלא `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // קרא את האלמנט מהמערך.
            // בטיחות: `idx` הוא אינדקס לאזור "alive" לשעבר של
            // מַעֲרָך.קריאת אלמנט זה פירושה ש-`data[idx]` נחשב למת עכשיו (כלומר אל תיגע).
            // מכיוון ש-`idx` היה סוף אזור החיים, אזור החיים הוא כעת שוב `data[alive]`, ומשקם את כל הפושעים.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // בטיחות: זה בטוח: `as_mut_slice` מחזיר בדיוק את פרוסת המשנה
        // של אלמנטים שעוד לא הוצאו החוצה ונותרו להפיל.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // לעולם לא יעבור זרימה עקב המשתנה "חי. התחלה <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// האיטרטור אכן מדווח על האורך הנכון.
// מספר האלמנטים "alive" (שעדיין יניב) הוא אורך הטווח `alive`.
// טווח זה מצטמצם באורך ב-`next` או `next_back`.
// בשיטות אלה מצטמצם תמיד ב-1, אך רק אם מחזירים את `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // שים לב, אנחנו לא באמת צריכים להתאים את אותו טווח חיים בדיוק, אז אנחנו יכולים פשוט לשכפל לקיזוז 0 ללא קשר למיקום `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // שיבט את כל האלמנטים החיים.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // כתוב שיבוט למערך החדש ואז עדכן את טווח החיים שלו.
            // אם שיבוט של panics, נשמט נכון את הפריטים הקודמים.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // הדפס רק את האלמנטים שעדיין לא הובאו: איננו יכולים לגשת יותר לאלמנטים שהופקו.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}