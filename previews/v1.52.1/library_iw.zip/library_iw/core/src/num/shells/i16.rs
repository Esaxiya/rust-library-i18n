//! קבועים לסוג שלם של 16 סיביות חתום.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! קוד חדש אמור להשתמש בקבועים המשויכים ישירות על הסוג הפרימיטיבי.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }