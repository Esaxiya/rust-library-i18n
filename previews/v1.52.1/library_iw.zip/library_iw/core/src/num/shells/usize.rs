//! קבועים לסוג שלם לא חתום בגודל המצביע.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! קוד חדש אמור להשתמש בקבועים המשויכים ישירות על הסוג הפרימיטיבי.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }