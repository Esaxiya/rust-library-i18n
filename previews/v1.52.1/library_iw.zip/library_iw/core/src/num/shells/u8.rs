//! קבועים לסוג השלם שלם שאינו חתום עם 8 סיביות.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! קוד חדש אמור להשתמש בקבועים המשויכים ישירות על הסוג הפרימיטיבי.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }