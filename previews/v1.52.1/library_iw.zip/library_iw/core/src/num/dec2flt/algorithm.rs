//! האלגוריתמים השונים מהנייר.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// מספר הביטים המשמעותיים ב-Fp
const P: u32 = 64;

// אנו פשוט שומרים את הקירוב הטוב ביותר עבור *כל* המעריכים, כך שניתן להשמיט את המשתנה "h" והתנאים הנלווים.
// זה סוחר ביצועים עבור כמה קילובייט של שטח.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// ברוב הארכיטקטורות, לפעולות של נקודה צפה יש גודל סיביות מפורש, ולכן דיוק החישוב נקבע על בסיס פעולה.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// ב-x86, ה-FPU x87 משמש לפעולות ציפה אם סיומות ה-SSE/SSE2 אינן זמינות.
// XP x87 FPU פועל כברירת מחדל עם 80 סיביות של דיוק, מה שאומר שפעולות יעגלו ל 80 סיביות ויביאו לעיגול כפול כאשר הערכים יוצגו בסופו של דבר כ
//
// 32/64 ערכי צף קצת.כדי להתגבר על כך, ניתן להגדיר את מילת הבקרה FPU כך שהחישובים יבוצעו בדיוק הרצוי.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// מבנה המשמש לשמירה על הערך המקורי של מילת הבקרה FPU, כך שניתן יהיה לשחזר אותו כאשר המבנה נשמט.
    ///
    ///
    /// ה-FPU של x87 הוא פנקס של 16 סיביות ששדותיו הם כדלקמן:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// התיעוד לכל השדות זמין במדריך למפתחי תוכנת IA-32 אדריכלות (כרך 1).
    ///
    /// השדה היחיד שרלוונטי לקוד הבא הוא PC, Precision Control.
    /// שדה זה קובע את דיוק הפעולות המבוצעות על ידי ה-FPU.
    /// ניתן להגדיר את זה ל:
    ///  - 0b00, דיוק יחיד כלומר 32 ביט
    ///  - 0b10, דיוק כפול כלומר 64 ביט
    ///  - 0b11, דיוק מורחב כפול כלומר 80 סיביות (מצב ברירת מחדל) הערך 0b01 שמור ואין להשתמש בו.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // בטיחות: ההוראה של `fldcw` נבדקה כדי לעבוד איתה בצורה נכונה
        // כל `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: אנו משתמשים בתחביר ATT לתמיכה ב-LLVM 8 ו-LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// מגדיר את שדה הדיוק של ה-FPU ל-`T` ומחזיר `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // חישבו את הערך עבור השדה בקרת דיוק המתאים ל-`T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 ביטים
            8 => 0x0200, // 64 ביטים
            _ => 0x0300, // ברירת מחדל, 80 ביט
        };

        // קבל את הערך המקורי של מילת הבקרה כדי לשחזר אותה מאוחר יותר, כאשר מבנה `FPUControlWord` נשמט בטיחות: ההוראה `fnstcw` נבדקה על מנת שתוכל לעבוד כראוי עם כל `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: אנו משתמשים בתחביר ATT לתמיכה ב-LLVM 8 ו-LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // הגדר את מילת הבקרה לדיוק הרצוי.
        // זה מושג על ידי מיסוך הדיוק הישן (ביטים 8 ו-9, 0x300) והחלפתו בדגל הדיוק המחושב לעיל.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// הנתיב המהיר של בלרופון באמצעות מספרים שלמים וצפים בגודל מכונה.
///
/// זה מופק לפונקציה נפרדת כך שניתן יהיה לנסות לפני בניית ביגנום.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // אנו משווים את הערך המדויק ל-MAX_SIG בסמוך לסוף, זו רק דחייה מהירה וזולה (וגם משחררת את שאר הקוד מדאגה לזרימה).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // הנתיב המהיר תלוי באופן מכריע בחשבון המעוגל למספר הסיביות הנכון ללא עיגול ביניים.
    // ב-x86 (ללא SSE או SSE2) לשם כך יש לשנות את דיוק ערימת ה-FPU של x87 כך שהיא תעגל ישירות לסיבית 64/32.
    // פונקציית `set_precision` דואגת לקבוע את הדיוק בארכיטקטורות הדורשות הגדרתו על ידי שינוי המצב הגלובלי (כמו מילת הבקרה של ה-x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // לא ניתן לקפל את המקרה e <0 ל-branch האחר.
    // כוחות שליליים גורמים לחלק חלקי חוזר ונשנה בבינארי, המעוגל, מה שגורם לשגיאות אמיתיות (ומדי פעם משמעותיות למדי!) בתוצאה הסופית.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// אלגוריתם בלרופון הוא קוד טריוויאלי המוצדק על ידי ניתוח מספרי לא טריוויאלי.
///
/// הוא מעוגל "f" לצוף עם משמעות של 64 סיביות ומכפיל אותו בקירוב הטוב ביותר של `10^e` (באותו פורמט של נקודה צפה).זה מספיק לעתים קרובות כדי להשיג את התוצאה הנכונה.
/// עם זאת, כאשר התוצאה קרובה למחצית הדרך בין שני צפי (ordinary) סמוכים, שגיאת העיגול המורכבת מכפלת שני קירובים פירושה שהתוצאה עשויה להיות כבויה בכמה ביטים.
/// כשזה קורה, האלגוריתם החזרתי R מתקן את העניינים.
///
/// ה-"close to halfway" גלי הידני מדויק על ידי הניתוח המספרי בעיתון.
/// במילותיו של קלינגר:
///
/// > סלופ, המתבטא ביחידות של הסיבית הכי פחות משמעותית, הוא גבול כולל לשגיאה
/// > הצטבר במהלך חישוב הנקודה הצפה של הקירוב ל-f * 10 ^ e.(סלופ הוא
/// > אינו מחויב לשגיאה האמיתית, אך מגביל את ההבדל בין הקירוב z ל-
/// > הקירוב הטוב ביותר האפשרי המשתמש בפיסות p משמעותיות.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // המקרים abs(e) <log5(2^N) נמצאים ב-fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // האם המדרון גדול מספיק בכדי לחולל שינוי בעיגול ל-n ביטים?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// אלגוריתם איטרטיבי המשפר קירוב של נקודה צפה של `f * 10^e`.
///
/// כל איטרציה מתקרבת יחידה אחת במקום האחרון, שכמובן לוקח זמן רב להתכנס אם `z0` בכלל לא פעיל.
/// למרבה המזל, כאשר נעשה שימוש בתגובה חדה עבור בלרופון, הקירוב ההתחלתי מושבת על ידי ULP אחד לכל היותר.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // מצא מספרים שלמים חיוביים `x`, `y` כך ש-`x / y` הוא בדיוק `(f *10^e) / (m* 2^k)`.
        // זה לא רק נמנע מלהתמודד עם הסימנים של `e` ו-`k`, אלא גם מבטל את הכוח של שני המשותפים ל-`10^e` ו-`2^k` כדי להקטין את המספרים.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // זה נכתב מעט במבוכה מכיוון שה-bignums שלנו לא תומכים במספרים שליליים, ולכן אנו משתמשים במידע הערך המוחלט + סימן.
        // הכפל עם m_digits אינו יכול לעלות על גדותיו.
        // אם `x` או `y` מספיק גדולים כדי שנצטרך לדאוג להצפה, הם גם גדולים מספיק כדי ש-`make_ratio` הפחית את השבר בגורם 2 ^ 64 ומעלה.
        //
        //
        let (d2, d_negative) = if x >= y {
            // לא צריך x יותר, שמור clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // עדיין זקוק y, תעשה עותק.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// בהינתן `x = f` ו-`y = m` כאשר `f` מייצגים ספרות עשרוניות קלט כרגיל ו-`m` הוא המשמעות של קירוב נקודה צפה, הפוך את היחס `x / y` לשווה ל-`(f *10^e) / (m* 2^k)`, אולי מופחת בעוצמה של שני המשותף.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, אלא שאנחנו מקטינים את השבר בכוח כלשהו של שניים.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m זה לא יכול לעלות על גדותיו מכיוון שהוא דורש `e` חיובי ו-`k` שלילי, מה שיכול לקרות רק בערכים קרובים מאוד ל-1, כלומר `e` ו-`k` יהיו זעירים יחסית.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k גם זה לא יכול לעלות על גדותיו, ראה לעיל.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), שוב מצמצם בכוח משותף של שניים.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// מבחינה מושגית, האלגוריתם M הוא הדרך הפשוטה ביותר להמיר עשרוני לצוף.
///
/// אנו יוצרים יחס השווה ל-`f * 10^e`, ואז משליכים כוחות של שניים עד שהוא נותן משמעות צפה תקפה.
/// המעריך הבינארי `k` הוא מספר הפעמים שהכפלנו את המונה או המכנה בשניים, כלומר, בכל עת `f *10^e` שווה ל-`(u / v)* 2^k`.
/// לאחר שגילינו משמעות משמעותית, עלינו רק לעגל על ידי בדיקת יתרת החלוקה, המתבצעת בתפקודי עוזר בהמשך.
///
///
/// אלגוריתם זה איטי במיוחד, אפילו עם האופטימיזציה המתוארת ב-`quick_start()`.
/// עם זאת, זה הפשוט ביותר מבין האלגוריתמים להתאים לתוצאות הצפה, תת-זרימה ותת-נורמליות.
/// יישום זה משתלט כאשר בלרופון ואלגוריתם R המומים.
/// איתור זרימה ושיטפון קל: היחס עדיין אינו משמעות בטווח, אך עם זאת הגיע למעריך minimum/maximum.
/// במקרה של הצפה, אנחנו פשוט מחזירים אינסוף.
///
/// הטיפול בתת-זרימה ותת-נורמליות הוא מסובך יותר.
/// בעיה אחת גדולה היא שעם המעריך המינימלי, היחס עשוי עדיין להיות גדול מדי עבור משמעות.
/// לפרטים ראה underflow().
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // אופטימיזציה אפשרית של FIXME: הכללת big_to_fp כך שנוכל לעשות כאן את המקבילה ל-fp_to_float(big_to_fp(u)), רק בלי העיגול הכפול.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // עלינו לעצור במעריך המינימלי, אם נחכה ל-`k < T::MIN_EXP_INT`, אז נצטרך גורם שניים.
            // למרבה הצער זה אומר שעלינו למקם מספרים נורמליים מיוחדים עם המינימום.
            // FIXME מוצא ניסוח אלגנטי יותר, אך הפעל את מבחן `tiny-pow10` כדי לוודא שהוא אכן נכון!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// מדלג על רוב איטרציות M אלגוריתם על ידי בדיקת אורך הסיביות.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // אורך הסיביות הוא אומדן של שני הלוגריתמים הבסיסיים ו-log(u / v) = log(u), log(v).
    // האומדן מושבת לכל היותר 1, אך תמיד הערכה נמוכה יותר, כך שהשגיאה ב-log(u) וב-log(v) הם מאותו סימן ומבטלת (אם שניהם גדולים).
    // לכן השגיאה ב-log(u / v) היא לכל היותר גם אחת.
    // יחס היעד הוא אחד שבו u/v נמצא במשמעות בטווח.לפיכך מצב הסיום שלנו הוא log2(u / v) שהוא הסיביות המשמעותיות, plus/minus אחת.
    // FIXME הסתכלות על הסיבית השנייה יכולה לשפר את ההערכה ולהימנע מחלוקה נוספת.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // תת זרם או תת-נורמלי.השאר את זה לתפקיד הראשי.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // הצפה.השאר את זה לתפקיד הראשי.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // יחס אינו משמעות משמעותית עם המעריך המינימלי, לכן עלינו לעגל ביטים עודפים ולהתאים את המעריך בהתאם.
    // הערך האמיתי נראה כעת כך:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(מיוצג על ידי rem)
    //
    // לכן, כאשר החלקים המעוגלים הם!= 0.5 ULP, הם מחליטים את העיגול בכוחות עצמם.
    // כאשר הם שווים והשאר אינו אפס, עדיין צריך לעגל את הערך.
    // רק כאשר הסיביות המעוגלות הן 1/2 והשאר אפס, יש לנו מצב של חצי עד שווה.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// עגול-שווה רגיל, מעורפל בכך שצריך לעגל על בסיס שארית חלוקה.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}