//! קצת התעסקות בצף חיובי IEEE 754.מספרים שליליים אינם וצריכים להיות מטופלים.
//! למספרי נקודה צפה רגילה יש ייצוג קנוני כ-(frac, exp) כך שהערך הוא 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) כאשר N הוא מספר הסיביות.
//!
//! תת-טבעיות מעט שונות ומשונות, אך אותו עיקרון חל.
//!
//! אולם כאן אנו מייצגים אותם כ-(sig, k) עם f חיובי, כך שהערך הוא f *
//! 2 <sup>ה</sup> .מלבד הפיכת ה-"hidden bit" למפורש, זה משנה את המעריך על ידי מה שמכונה משמרת מנטיסה.
//!
//! במילים אחרות, בדרך כלל צפים נכתבים כ-(1) אך כאן הם נכתבים כ-(2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! אנו מכנים (1) את **ייצוג השבר** ו-(2) את **הייצוג האינטגרלי**.
//!
//! פונקציות רבות במודול זה מטפלות רק במספרים רגילים.שגרת ה-dec2flt עוברת בצורה שמרנית בדרך האיטית הנכונה באופן אוניברסלי (אלגוריתם M) למספרים קטנים מאוד וגדולים.
//! אלגוריתם זה זקוק רק ל-next_float() אשר מטפל בתת-נורמליות ובאפסים.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// עוזר trait כדי למנוע שכפול בעצם את כל קוד ההמרה עבור `f32` ו-`f64`.
///
/// עיין בהערת המסמך של מודול האב מדוע זה הכרחי.
///
/// לעולם אל ** אמור להיות מיושם עבור סוגים אחרים או להשתמש בו מחוץ למודול dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// סוג המשמש את `to_bits` ו-`from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// מבצע התמרה גולמית למספר שלם.
    fn to_bits(self) -> Self::Bits;

    /// מבצע התמרה גולמית ממספר שלם.
    fn from_bits(v: Self::Bits) -> Self;

    /// מחזירה את הקטגוריה אליה מספר זה נופל.
    fn classify(self) -> FpCategory;

    /// מחזיר את המנטיסה, מעריך וחותם כמספרים שלמים.
    fn integer_decode(self) -> (u64, i16, i8);

    /// מפענח את המצוף.
    fn unpack(self) -> Unpacked;

    /// יציקות ממספר שלם קטן שניתן לייצג במדויק.
    /// Panic אם לא ניתן לייצג את המספר השלם, הקוד האחר במודול זה מקפיד לעולם לא לתת לזה לקרות.
    fn from_int(x: u64) -> Self;

    /// מקבל את הערך 10 <sup>e</sup> מטבלה מחושבת מראש.
    /// Panics ל-`e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// מה השם אומר.
    /// קל יותר לקודד מאשר ללהטט פנימיות ולקוות ש-LLVM קבוע מקפל אותו.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // שמרנית המחויבת בספרות העשרוניות של קלטים שאינם יכולים לייצר הצפה או אפס או
    /// תת-טבעיות.כנראה המעריך העשרוני של הערך הנורמלי המרבי, ומכאן השם.
    const MAX_NORMAL_DIGITS: usize;

    /// כאשר לספרה העשרונית המשמעותית ביותר יש ערך מקום גדול מזה, המספר בהחלט מעוגל עד אינסוף.
    ///
    const INF_CUTOFF: i64;

    /// כאשר לספרה העשרונית המשמעותית ביותר יש ערך מקום פחות מזה, המספר בהחלט מעוגל לאפס.
    ///
    const ZERO_CUTOFF: i64;

    /// מספר הביטים במעריך.
    const EXP_BITS: u8;

    /// מספר הביטים במשמעות,*כולל* הביט הסמוי.
    const SIG_BITS: u8;

    /// מספר הסיביות במשמעות,*לא כולל* הסיבית הנסתרת.
    const EXPLICIT_SIG_BITS: u8;

    /// המעריך המשפטי המרבי בייצוג חלקי.
    const MAX_EXP: i16;

    /// המעריך המשפטי המינימלי בייצוג חלקי, למעט תת-טבעיות.
    const MIN_EXP: i16;

    /// `MAX_EXP` לייצוג אינטגרלי, כלומר, כאשר השינוי מוחל.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` מקודד (כלומר עם הטיה מקוזזת)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` לייצוג אינטגרלי, כלומר, כאשר השינוי מוחל.
    const MIN_EXP_INT: i16;

    /// המשמעות המנורמלת המרבית בייצוג אינטגרלי.
    const MAX_SIG: u64;

    /// המשמעות הנורמלית המנורמלת בייצוג אינטגרלי.
    const MIN_SIG: u64;
}

// בעיקר דרך לעקיפת הבעיה עבור #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// מחזיר את המנטיסה, מעריך וחותם כמספרים שלמים.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // הטיה מעריכית + משמרת מנטיסה
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe לא בטוח אם `as` מסתובב נכון בכל הפלטפורמות.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// מחזיר את המנטיסה, מעריך וחותם כמספרים שלמים.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // הטיה מעריכית + משמרת מנטיסה
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe לא בטוח אם `as` מסתובב נכון בכל הפלטפורמות.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// ממיר `Fp` לסוג הצף המכונה הקרוב ביותר.
/// לא מטפל בתוצאות תת-נורמליות.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f הוא 64 סיביות, ולכן ל-xe יש שינוי של מנטיסה של 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// עיגול את המשמעות של 64 סיביות עד סיביות T::SIG_BITS עם חצי עד שווה.
/// אינו מטפל בהצפת מעריכי.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // התאם את משמרת המנטיסה
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// הפוך של `RawFloat::unpack()` למספרים מנורמלים.
/// Panics אם המשמעות או המעריך אינם תקפים למספרים מנורמלים.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // הסר את הסיבית הנסתרת
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // התאם את המעריך להטיה של מעריכי ומעבר מנטיסה
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // השאירו את סימן הסימן ב 0 ("+"), המספרים שלנו כולם חיוביים
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// לבנות תת-נורמלי.מנטיסה של 0 מותרת ובונה אפס.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // אקספוננט מקודד הוא 0, ביט הסימן הוא 0, אז אנחנו רק צריכים לפרש מחדש את הסיביות.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// הערך משוער עם Fp.מסתובב בתוך 0.5 ULP עם חצי עד שווה.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // ניתק את כל הסיביות לפני האינדקס `start`, כלומר, אנו מעבירים ימינה בכמות של `start`, כך שזה גם המעריך שאנחנו צריכים.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // עגול (half-to-even) תלוי בסיביות הקטומות.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// מוצא את המספר הגדול ביותר של נקודה צפה הקטן ביותר מהוויכוח.
/// לא מטפל בתת-נורמליות, אפס או תת-זרם מעריכי.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// מצא את מספר הנקודה הצפה הקטן ביותר מהוויכוח.
// פעולה זו רוויה, כלומר next_float(inf) ==inf.
// בניגוד לרוב הקוד במודול זה, פונקציה זו אכן מטפלת באפס, תת-נורמליות ואינסוף.
// עם זאת, כמו כל הקוד האחר כאן, הוא לא עוסק ב-NaN ובמספרים שליליים.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // זה נראה טוב מכדי להיות אמיתי, אבל זה עובד.
        // 0.0 מקודדת כמילה הכול-אפס.תת-טבעיות הן 0x000 מ '... מ' כאשר מ 'היא המנטיסה.
        // בפרט, תת-נורמלי הקטן ביותר הוא 0x0 ... 01 והגדול ביותר הוא 0x000F ... F.
        // המספר הרגיל הקטן ביותר הוא 0x0010 ... 0, כך שהמקרה הפינתי הזה עובד גם כן.
        // אם התוספת עולה על גדותיו של המנטיסה, סיבית הנשיאה מגדילה את האקספוננט כרצוננו, וסיביות המנטיסה הופכות לאפס.
        // בגלל מוסכמת הסיביות הנסתרת, גם זה בדיוק מה שאנחנו רוצים!
        // לבסוף, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}