//! פונקציות שירות עבור bignums שלא הגיוני מדי להפוך לשיטות.

// FIXME שמו של מודול זה מעט מצער, מכיוון שמודולים אחרים מייבאים גם את `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// בדוק אם קטיעת כל הביטים פחות משמעותיים מ-`ones_place` מציגה שגיאה יחסית פחות, שווה או גדולה מ-0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // אם כל הסיביות שנותרו אפסות, זה= 0.5 ULP, אחרת> 0.5 אם אין יותר סיביות (half_bit==0), להלן גם מחזיר כראוי שווה.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// ממיר מחרוזת ASCII המכילה ספרות עשרוניות בלבד ל-`u64`.
///
/// אינו מבצע בדיקות של תווים הצפים או לא חוקיים, כך שאם המתקשר לא נזהר, התוצאה מזויפת ויכולה panic (אם כי זה לא יהיה `unsafe`).
/// בנוסף, מתייחסים לחוטים ריקים כאל אפס.
/// פונקציה זו קיימת בגלל
///
/// 1. שימוש ב-`FromStr` ב-`&[u8]` דורש `from_utf8_unchecked`, וזה רע, וכן
/// 2. לחבר את התוצאות של `integral.parse()` ו-`fractional.parse()` מורכב יותר מכל הפונקציה הזו.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// ממיר מחרוזת של ספרות ASCII לבגינום.
///
/// בדומה ל-`from_str_unchecked`, פונקציה זו מסתמכת על המנתח לעשב את הספרות שאינן ספרות.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// פורש את הביגנום למספר שלם של 64 סיביות.Panics אם המספר גדול מדי.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// מחלץ מגוון ביטים.

/// אינדקס 0 הוא החלק הפחות משמעותי והטווח פתוח למחצה כרגיל.
/// Panics אם תתבקש לחלץ יותר ביטים מאשר להתאים לסוג ההחזרה.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}