//! מפענח ערך נקודה צפה לחלקים בודדים וטווחי שגיאה.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// ערך סופי לא מפוענח מפוענח, כך ש:
///
/// - הערך המקורי שווה ל-`mant * 2^exp`.
///
/// - כל מספר מ-`(mant - minus)*2^exp` ל-`(mant + plus)* 2^exp` יעגל לערך המקורי.
/// הטווח כולל רק כאשר `inclusive` הוא `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// המנטיסה המוקטנת.
    pub mant: u64,
    /// טווח השגיאות התחתון.
    pub minus: u64,
    /// טווח השגיאות העליון.
    pub plus: u64,
    /// המעריך המשותף בבסיס 2.
    pub exp: i16,
    /// נכון כאשר טווח השגיאות כולל.
    ///
    /// ב-IEEE 754 זה נכון כאשר המנטיסה המקורית הייתה אחידה.
    pub inclusive: bool,
}

/// ערך לא חתום מפוענח.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// אינסוף, חיובי או שלילי.
    Infinite,
    /// אפס, חיובי או שלילי.
    Zero,
    /// מספרים סופיים עם שדות מפוענחים נוספים.
    Finite(Decoded),
}

/// סוג נקודה צפה שניתן 'לפענח' d.
pub trait DecodableFloat: RawFloat + Copy {
    /// הערך המינימלי המנורמל החיובי.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// מחזירה סימן (נכון כאשר הוא שלילי) וערך `FullDecoded` ממספר הנקודה הצפה הנתונה.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // שכנים: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode תמיד משמר את האקספוננט, כך שהמאנטיסה מוגדלת עבור תת-טבעיות.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // שכנים: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // איפה maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // שכנים: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}