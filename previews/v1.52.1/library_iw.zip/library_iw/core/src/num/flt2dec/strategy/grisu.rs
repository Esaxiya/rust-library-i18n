//! התאמת Rust לאלגוריתם Grisu3 המתואר בסעיף "הדפסת מספרי נקודה צפה במהירות ובמדויק עם שלמים" [^ 1].
//! הוא משתמש בערך 1KB של טבלה מחושבת מראש, ובתורו, זה מהיר מאוד עבור רוב הקלטים.
//!
//! [^1]: Florian לויטש.2010. הדפסת מספרי נקודות צפות במהירות ו
//!   במדויק עם מספרים שלמים.SIGPLAN לא.45, 6 (יוני 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// ראה את ההערות ב-`format_shortest_opt` לרציונל.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-אני;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// בהינתן `x > 0`, מחזיר `(k, 10^k)` כך ש-`10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// יישום המצב הקצר ביותר עבור גריסו.
///
/// הוא מחזיר את `None` כשהוא היה מחזיר ייצוג לא מדויק אחרת.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // אנו זקוקים לפחות לשלוש סיביות של דיוק נוסף

    // התחל עם הערכים המנורמלים עם המעריך המשותף
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // מצא כל `cached = 10^minusk` כזה ש-`ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // מכיוון ש-`plus` מנורמל, פירושו `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // בהתחשב בבחירות שלנו בין `ALPHA` ו-`GAMMA`, זה מכניס את `plus * cached` ל-`[4, 2^32)`.
    //
    // ברור שרצוי למקסם את ה-`GAMMA - ALPHA`, כך שלא נצטרך הרבה כוחות מטמון של 10, אך ישנם כמה שיקולים:
    //
    //
    // 1. אנו רוצים לשמור על `floor(plus * cached)` בתוך `u32` מכיוון שהוא זקוק לחלוקה יקרה.
    //    (זה לא ממש ניתן להימנע, שארית נדרשת לצורך הערכת דיוק).
    // 2.
    // שאר ה-`floor(plus * cached)` מוכפל שוב ושוב ב-10, והוא לא אמור לעלות על גדותיו.
    //
    // הראשון נותן `64 + GAMMA <= 32`, ואילו השני נותן `10 * 2^-ALPHA <= 2^64`;
    // -60 ו--32 הוא הטווח המקסימלי עם אילוץ זה, וגם V8 משתמש בהם.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // קנה מידה fps.זה נותן את השגיאה המקסימלית של 1 ulp (הוכח ממשפט 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-טווח בפועל של מינוס
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // מעל `minus`, `v` ו-`plus` הם *כימות* בקירוב (שגיאה <1 ulp).
    // מכיוון שאיננו יודעים שהשגיאה חיובית או שלילית, אנו משתמשים בשני קירובים המרווחים באופן שווה ויש לנו את השגיאה המקסימלית של 2 אולפים.
    //
    // ה-"unsafe region" הוא מרווח ליברלי אותו אנו מייצרים בתחילה.
    // ה-"safe region" הוא מרווח שמרני שאנו מקבלים רק.
    // אנו מתחילים עם ה-repr הנכון בתוך האזור הלא בטוח ומנסים למצוא את ה-repr הקרוב ביותר ל-`v` שנמצא גם באזור הבטוח.
    // אם אנחנו לא יכולים, אנחנו מוותרים.
    //
    let plus1 = plus.f + 1;
    // תן ל-plus0 = plus.f, 1;//רק להסבר תן minus0 = minus.f + 1;//רק להסבר
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // מעריך משותף

    // חלק את `plus1` לחלקים אינטגרליים וחלקים.
    // מובטח כי חלקים אינטגרליים יתאימו ל-u32, מכיוון שהספק במטמון מבטיח `plus < 2^32` ו-`plus.f` מנורמל הוא תמיד פחות מ-`2^64 - 2^4` עקב דרישת הדיוק.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // לחשב את `10^max_kappa` הגדול ביותר לא יותר מ-`plus1` (ובכך `plus1 < 10^(max_kappa+1)`).
    // זהו גבול עליון של `kappa` למטה.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // משפט 6.2: אם `k` הוא מספר השלמים הגדול ביותר
    // `0 <= y mod 10^k <= y - x`,              ואז `V = floor(y / 10^k) * 10^k` נמצא ב-`[x, y]` ואחד הייצוגים הקצרים ביותר (עם המספר המינימלי של ספרות משמעותיות) בתחום זה.
    //
    //
    // מצא את אורך הספרות `kappa` בין `(minus1, plus1)` לפי משפט 6.2.
    // משפט 6.2 ניתן לאמץ כדי לא לכלול את `x` על ידי דרישה של `y mod 10^k < y - x` במקום זאת.
    // (למשל, `x` =32000, `y` =32777; `kappa` =2 מאז `y mod 10 ^ 3=777 <y, x=777 '.) האלגוריתם מסתמך על שלב האימות המאוחר יותר כדי לא לכלול את `y`.
    //
    let delta1 = plus1 - minus1;
    // תן delta1int=(delta1>> e) כמשתמש;//רק להסבר
    let delta1frac = delta1 & ((1 << e) - 1);

    // לעבד חלקים אינטגרליים, תוך בדיקת הדיוק בכל שלב.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // ספרות שטרם הוצגו
    loop {
        // תמיד יש לנו ספרה אחת לפחות לעבד, כמשתמשי `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (מכאן ש-`remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // חלק את `remainder` ב-`10^kappa`.שניהם מוגדלים לפי `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; מצאנו את ה-`kappa` הנכון.
            let ten_kappa = (ten_kappa as u64) << e; // קנה מידה 10 ^ קאפה חזרה למעריך המשותף
            return round_and_weed(
                // בטיחות: אותנו את הזיכרון לעיל.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // לשבור את הלולאה כאשר העברנו את כל הספרות האינטגרליות.
        // המספר המדויק של הספרות הוא `max_kappa + 1` כ-`plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // לשחזר את הפונדקים
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // עיבוד חלקים חלקים, תוך בדיקת הדיוק בכל שלב.
    // הפעם אנו מסתמכים על כפל חוזר, מכיוון שחלוקה תאבד את הדיוק.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // הספרה הבאה צריכה להיות משמעותית מכיוון שבדקנו את זה לפני שפרצנו אנשים זרים, שם `m = max_kappa + 1` (מספר ספרות בחלק האינטגרלי):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // לא יעלה על גדותיו, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // חלק את `remainder` ב-`10^kappa`.
        // שניהם משורטטים על ידי `2^e / 10^kappa`, כך שהאחרון משתמע כאן.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // מחלק מרומז
            return round_and_weed(
                // בטיחות: אותנו את הזיכרון לעיל.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // לשחזר את הפונדקים
        kappa -= 1;
        remainder = r;
    }

    // יצרנו את כל הספרות המשמעותיות של `plus1`, אך לא בטוחים אם היא הספרה האופטימלית.
    // לדוגמה, אם `minus1` הוא 3.14153 ... ו-`plus1` הוא 3.14158 ..., יש 5 ייצוגים קצרים שונים מ-3.14154 ל-3.14158, אך יש לנו רק את הגדול ביותר.
    // עלינו להקטין את הספרה האחרונה ברציפות ולבדוק אם זו החזרה האופטימלית.
    // יש לכל היותר 9 מועמדים (..1 עד ..9), כך שזה מהיר למדי.(שלב "rounding")
    //
    // הפונקציה בודקת אם ה-"optimal" repr הזה נמצא למעשה בטווחי ה-ulp, וגם ייתכן ש-"second-to-optimal" repr יכול להיות אופטימלי בגלל שגיאת העיגול.
    // בשני המקרים זה מחזיר את `None`.
    // (שלב "weeding")
    //
    // כל הטיעונים כאן משוחזרים לפי הערך המשותף (אך המשתמע) `k`, כך:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (וגם, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (וגם, `threshold > plus1v` ממגורים קודמים)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // לייצר שתי קירובים ל-`v` (למעשה `plus1 - v`) בתוך 1.5 ulps.
        // הייצוג המתקבל צריך להיות הייצוג הקרוב ביותר לשניהם.
        //
        // כאן נעשה שימוש ב-`plus1 - v` מכיוון שנעשים חישובים ביחס ל-`plus1` על מנת להימנע מ-overflow/underflow (ומכאן השמות שהוחלפו לכאורה).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // להקטין את הספרה האחרונה ולעצור בייצוג הקרוב ביותר ל-`v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // אנו עובדים עם הספרות המקורבות `w(n)`, ששוות בהתחלה ל-`plus1 - plus1 % 10^kappa`.לאחר הפעלת גוף הלולאה פי `n`, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // הגדרנו את `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (ובכך `שארית= plus1w(0)`) כדי לפשט את הבדיקות.
            // שימו לב ש-`plus1w(n)` תמיד עולה.
            //
            // יש לנו שלושה תנאים לסיום.כל אחד מהם יגרום לכך שהלולאה לא תוכל להמשיך, אך יש לנו לפחות ייצוג תקף אחד שידוע שהוא הקרוב ביותר ל-`v + 1 ulp` בכל מקרה.
            // נציין אותם כ-TC1 עד TC3 לשם קיצור.
            //
            // TC1: `w(n) <= v + 1 ulp`, כלומר, זה ה-repr האחרון שיכול להיות הקרוב ביותר.
            // זה שווה ערך ל-`plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // בשילוב עם TC2 (שבודק אם `w(n+1)` is valid), זה מונע הצפה אפשרית בחישוב של `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, כלומר, ה-repr הבא בהחלט לא מסתובב ל-`v`.
            // זה שווה ערך ל-`plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // הצד השמאלי יכול לעלות על גדותיו, אך אנו מכירים את `threshold > plus1v`, כך שאם TC1 אינו נכון, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` ואנחנו יכולים לבדוק בבטחה אם `threshold - plus1w(n) < 10^kappa` במקום זאת.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, כלומר, ה-repr הבא הוא
            // לא קרוב יותר ל-`v + 1 ulp` מאשר ה-repr הנוכחי.
            // בהינתן `z(n) = plus1v_up - plus1w(n)`, זה הופך ל-`abs(z(n)) <= abs(z(n+1))`.שוב בהנחה ש-TC1 הוא שקר, יש לנו `z(n) > 0`.יש לנו שני מקרים לשקול:
            //
            // - כאשר `z(n+1) >= 0`: TC3 הופך ל-`z(n) <= z(n+1)`.
            // כאשר `plus1w(n)` גדל, `z(n)` צריך להיות בירידה וזה ברור שקרי.
            // - כאשר `z(n+1) < 0`:
            //   - TC3a: התנאי המוקדם הוא `plus1v_up < plus1w(n) + 10^kappa`.בהנחה ש-TC2 הוא שקר, `threshold >= plus1w(n) + 10^kappa` כך שהוא לא יכול לעלות על גדותיו.
            //   - TC3b: TC3 הופך ל-`z(n) <= -z(n+1)`, כלומר, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   ה-TC1 המושלל נותן את `plus1v_up > plus1w(n)`, כך שהוא לא יכול לעלות על גדותיו או לזרום אותו בשילוב עם TC3a.
            //
            // כתוצאה מכך, עלינו לעצור כאשר `TC1 || TC2 || (TC3a && TC3b)`.להלן שווה להופכי שלה, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // ה-repr הקצר ביותר לא יכול להסתיים ב-`0`
                plus1w += ten_kappa;
            }
        }

        // בדוק אם ייצוג זה הוא גם הייצוג הקרוב ביותר ל-`v - 1 ulp`.
        //
        // זה פשוט זהה לתנאי הסיום של `v + 1 ulp`, כאשר כל `plus1v_up` מוחלף במקום `plus1v_down`.
        // ניתוח הצפה מחזיק באותה מידה.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // עכשיו יש לנו את הייצוג הכי קרוב ל-`v` בין `plus1` ל-`minus1`.
        // אולם זה ליברלי מדי, לכן אנו דוחים כל `w(n)` שלא בין `plus0` ל-`minus0`, כלומר `plus1 - plus1w(n) <= minus0` או `plus1 - plus1w(n) >= plus0`.
        // אנו משתמשים בעובדות ש-`threshold = plus1 - minus1` ו-`plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// יישום המצב הקצר ביותר עבור גריסו עם דרקון נסיגה.
///
/// זה אמור לשמש ברוב המקרים.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // בטיחות: בודק ההלוואות אינו מספיק חכם בכדי לאפשר לנו להשתמש ב-`buf`
    // ב branch השני, אז אנחנו מכבסים את החיים כאן.
    // אך אנו משתמשים ב-`buf` רק מחדש אם `format_shortest_opt` החזיר את `None` אז זה בסדר.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// יישום המצב המדויק והקבוע עבור Grisu.
///
/// הוא מחזיר את `None` כשהוא היה מחזיר ייצוג לא מדויק אחרת.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // אנו זקוקים לפחות לשלוש סיביות של דיוק נוסף
    assert!(!buf.is_empty());

    // לנרמל ולגודל `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // חלק את `v` לחלקים אינטגרליים וחלקים.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // גם ב-`v` הישן וגם ב-`v` החדש (המוגדל על ידי `10^-k`) יש שגיאה של <1 ulp (משפט 5.1).
    // מכיוון שאיננו יודעים שהשגיאה חיובית או שלילית, אנו משתמשים בשני קירובים המרווחים באופן שווה ויש לנו את השגיאה המקסימלית של 2 אולפים (זהה למקרה הקצר ביותר).
    //
    //
    // המטרה היא למצוא את סדרת הספרות המעוגלות בדיוק המשותפות גם ל-`v - 1 ulp` וגם ל-`v + 1 ulp`, כך שנהיה בטוחים ביותר.
    // אם זה לא אפשרי, אנחנו לא יודעים איזו מהן היא הפלט הנכון עבור `v`, אז אנחנו מוותרים ונובעים אחורה.
    //
    // `err` מוגדר כ-`1 ulp * 2^e` כאן (זהה לאולפ ב-`vfrac`), ואנחנו נמדד אותו בכל פעם ש `v` יתחזק.
    //
    //
    //
    let mut err = 1;

    // לחשב את `10^max_kappa` הגדול ביותר לא יותר מ-`v` (ובכך `v < 10^(max_kappa+1)`).
    // זהו גבול עליון של `kappa` למטה.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // אם אנו עובדים עם המגבלה האחרונה של הספרות, עלינו לקצר את המאגר לפני העיבוד בפועל כדי למנוע עיגול כפול.
    //
    // שימו לב שעלינו להגדיל את המאגר שוב כאשר מתרחש עיגול למעלה!
    let len = if exp <= limit {
        // אופס, אנחנו אפילו לא יכולים לייצר *ספרה אחת*.
        // זה אפשרי כאשר נניח שיש לנו משהו כמו 9.5 וזה מעוגל ל-10.
        //
        // באופן עקרוני אנו יכולים להתקשר מיידית ל-`possibly_round` עם מאגר ריק, אך קנה המידה של `max_ten_kappa << e` ב-10 יכול לגרום להצפה.
        //
        // לפיכך אנו מרושלים כאן ומרחיבים את טווח השגיאות בגורם 10.
        // זה יגדיל את שיעור שלילי כוזב, אבל רק מאוד,*מאוד* מעט;
        // זה יכול להיות חשוב רק כאשר המנטיסה גדולה מ-60 ביטים.
        //
        // בטיחות: `len=0`, לכן החובה לאתחל זיכרון זה היא טריוויאלית.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // לעבד חלקים אינטגרליים.
    // השגיאה היא חלקית לחלוטין, ולכן איננו צריכים לבדוק אותה בחלק זה.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // ספרות שטרם הוצגו
    loop {
        // תמיד יש לנו לפחות ספרה אחת כדי לעבד את הפונדקים:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (מכאן ש-`remainder = vint % 10^(kappa+1)`)
        //
        //

        // חלק את `remainder` ב-`10^kappa`.שניהם מוגדלים לפי `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // המאגר מלא?הפעל את המעבר לעגל עם השאר.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // בטיחות: אותנו `len` בתים רבים.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // לשבור את הלולאה כאשר העברנו את כל הספרות האינטגרליות.
        // המספר המדויק של הספרות הוא `max_kappa + 1` כ-`plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // לשחזר את הפונדקים
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // לדקלם חלקים חלקיים.
    //
    // באופן עקרוני אנו יכולים להמשיך לספרה האחרונה הזמינה ולבדוק את הדיוק.
    // למרבה הצער אנו עובדים עם מספרים שלמים בגודל סופי, ולכן אנו זקוקים לקריטריון כלשהו כדי לזהות את הצפתו.
    // V8 משתמש ב-`remainder > err`, שהופך להיות שקר כאשר הספרות המשמעותיות הראשונות של `i` של `v - 1 ulp` ו-`v` נבדלות.
    // אולם זה דוחה יותר מדי קלט תקף אחרת.
    //
    // מכיוון שלשלב המאוחר יש זיהוי הצפה נכון, אנו משתמשים בקריטריון הדוק יותר:
    // אנו ממשיכים עד ש-`err` עולה על `10^kappa / 2`, כך שהטווח שבין `v - 1 ulp` ל-`v + 1 ulp` בהחלט מכיל שני ייצוגים מעוגלים או יותר.
    //
    // זה אותו דבר לשתי ההשוואות הראשונות מ-`possibly_round`, לצורך ההפניה.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariants, כאשר `m = max_kappa + 1` (מספר ספרות בחלק האינטגרלי):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // לא יעלה על גדותיו, `2^e * 10 < 2^64`
        err *= 10; // לא יעלה על גדותיו, `err * 10 < 2^e * 5 < 2^64`

        // חלק את `remainder` ב-`10^kappa`.
        // שניהם משורטטים על ידי `2^e / 10^kappa`, כך שהאחרון משתמע כאן.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // המאגר מלא?הפעל את המעבר לעגל עם השאר.
        if i == len {
            // בטיחות: אותנו `len` בתים רבים.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // לשחזר את הפונדקים
        remainder = r;
    }

    // חישוב נוסף הוא חסר תועלת (`possibly_round` בהחלט נכשל), אז אנחנו מוותרים.
    return None;

    // יצרנו את כל הספרות המבוקשות של `v`, שאמורות להיות זהות גם לספרות המקבילות של `v - 1 ulp`.
    // כעת אנו בודקים אם יש ייצוג ייחודי המשותף הן ל-`v - 1 ulp` והן ל-`v + 1 ulp`;זה יכול להיות זהה לספרות שנוצרו, או לגרסה המעוגלת של הספרות האלה.
    //
    // אם הטווח מכיל ייצוגים מרובים באותו אורך, איננו יכולים להיות בטוחים ועלינו להחזיר `None` במקום זאת.
    //
    // כל הטיעונים כאן משוחזרים לפי הערך המשותף (אך המשתמע) `k`, כך:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // בטיחות: יש לאתחל את הבתים הראשונים של `len` של `buf`.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (לצורך ההפניה, הקו המקווקו מציין את הערך המדויק לייצוגים אפשריים במספר ספרות נתון.)
        //
        //
        // השגיאה גדולה מכדי שיש לפחות שלושה ייצוגים אפשריים בין `v - 1 ulp` ל-`v + 1 ulp`.
        // איננו יכולים לקבוע איזה מהם נכון.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // למעשה, די ב-1/2 ulp כדי להציג שני ייצוגים אפשריים.
        // (זכרו שאנחנו זקוקים לייצוג ייחודי הן ל-`v - 1 ulp` והן ל-'v + 1 ulp'). זה לא יעלה על גדותיו, כ-`ulp < ten_kappa` מהבדיקה הראשונה.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ קאפה---------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // אם `v + 1 ulp` קרוב יותר לייצוג המעוגל (שנמצא כבר ב-`buf`), נוכל לחזור בבטחה.
        // שימו לב ש-`v - 1 ulp`*יכול* להיות פחות מהייצוג הנוכחי, אך כ-`1 ulp < 10^kappa / 2`, מצב זה מספיק:
        // המרחק בין `v - 1 ulp` לייצוג הנוכחי לא יעלה על `10^kappa / 2`.
        //
        // התנאי שווה ל-`remainder + ulp < 10^kappa / 2`.
        // מכיוון שהדבר יכול לעלות על גדותיו בקלות, בדוק תחילה אם `remainder < 10^kappa / 2`.
        // כבר אימתנו ש-`ulp < 10^kappa / 2`, כך שכל עוד `10^kappa` לא עלה על גדותיו, הבדיקה השנייה בסדר.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // בטיחות: המתקשר שלנו איתחל את הזיכרון הזה.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------שארית------> |:
        //   :                          |   :
        //   : <---------10 ^ קאפה--------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // מצד שני, אם `v - 1 ulp` קרוב יותר לייצוג המעוגל, עלינו להתקדם ולחזור.
        // מאותה סיבה אנחנו לא צריכים לבדוק את `v + 1 ulp`.
        //
        // התנאי שווה ל-`remainder - ulp >= 10^kappa / 2`.
        // שוב אנו בודקים תחילה אם `remainder > ulp` (שימו לב שזה לא `remainder >= ulp`, מכיוון ש `10^kappa` לעולם אינו אפס).
        //
        // שים לב גם ל-`remainder - ulp <= 10^kappa`, כך שהצ'ק השני לא עולה על גדותיו.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // בטיחות: המתקשר שלנו חייב לאתחל את הזיכרון הזה.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // הוסף ספרה נוספת רק כאשר התבקשנו את הדיוק הקבוע.
                // עלינו גם לבדוק שאם המאגר המקורי היה ריק, ניתן להוסיף את הספרה הנוספת רק כאשר `exp == limit` (מקרה edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // בטיחות: אנו והמתקשר שלנו אותנו את הזיכרון.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // אחרת אנחנו נידונים (כלומר, ערכים מסוימים בין `v - 1 ulp` ל-`v + 1 ulp` מתעגלים כלפי מטה ואחרים מתעגלים כלפי מעלה) ומוותרים.
        //
        None
    }
}

/// יישום המצב המדויק והקבוע עבור Grisu עם Dragonback.
///
/// זה אמור לשמש ברוב המקרים.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // בטיחות: בודק ההלוואות אינו מספיק חכם בכדי לאפשר לנו להשתמש ב-`buf`
    // ב branch השני, אז אנחנו מכבסים את החיים כאן.
    // אך אנו משתמשים ב-`buf` רק מחדש אם `format_exact_opt` החזיר את `None` אז זה בסדר.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}