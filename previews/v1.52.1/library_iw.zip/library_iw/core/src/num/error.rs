//! סוגי שגיאות להמרה לסוגים אינטגרליים.

use crate::convert::Infallible;
use crate::fmt;

/// סוג השגיאה הוחזר כאשר המרה מסוג אינטגרלי מסומן נכשלת.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // התאם ולא להכריח כדי לוודא שקוד כמו `From<Infallible> for TryFromIntError` לעיל ימשיך לעבוד כאשר `Infallible` יהפוך לכינוי ל-`!`.
        //
        //
        match never {}
    }
}

/// שגיאה שניתן להחזיר בעת ניתוח מספר שלם.
///
/// שגיאה זו משמשת כסוג השגיאה לפונקציות `from_str_radix()` בסוגי השלמים הפרימיטיביים, כגון [`i8::from_str_radix`].
///
/// # סיבות אפשריות
///
/// בין גורמים אחרים, ניתן לזרוק את `ParseIntError` בגלל רווח לבן מוביל או נגרר במחרוזת, למשל, כאשר הוא מתקבל מהקלט הסטנדרטי.
///
/// שימוש בשיטת [`str::trim()`] מבטיח שלא יישאר רווח לבן לפני הניתוח.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum לאחסון סוגים שונים של שגיאות העלולות לגרום לניתוח מספר שלם להיכשל.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// הערך המנותח ריק.
    ///
    /// בין שאר הסיבות, גרסה זו תיבנה בעת ניתוח מחרוזת ריקה.
    Empty,
    /// מכיל ספרה לא חוקית בהקשר שלה.
    ///
    /// בין שאר הסיבות, גרסה זו תיבנה בעת ניתוח מחרוזת המכילה תו שאינו ASCII.
    ///
    /// גרסה זו בנויה גם כאשר `+` או `-` ממוקמים בצורה לא נכונה בתוך מחרוזת בפני עצמה או באמצע מספר.
    ///
    ///
    InvalidDigit,
    /// המספר השלם גדול מכדי לאחסן בסוג היעד השלם.
    PosOverflow,
    /// מספר שלם קטן מכדי לאחסן בסוג שלם היעד.
    NegOverflow,
    /// הערך היה אפס
    ///
    /// גרסה זו תונפק כאשר למחרוזת הניתוח ערך אפס, מה שלא יהיה חוקי עבור סוגים שאינם אפסיים.
    ///
    Zero,
}

impl ParseIntError {
    /// מוציא את הסיבה המפורטת לניתוח מספר שלם שנכשל.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}