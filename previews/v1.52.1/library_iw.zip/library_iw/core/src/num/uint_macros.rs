macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// הערך הקטן ביותר שניתן לייצג על ידי סוג שלם זה.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// הערך הגדול ביותר שניתן לייצג על ידי סוג שלם זה.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// הגודל של סוג שלם זה בסיביות.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// ממיר פרוסת מחרוזת בבסיס נתון למספר שלם.
        ///
        /// המחרוזת צפויה להיות סימן `+` אופציונלי ואחריו ספרות.
        ///
        /// רווח לבן מוביל ונגרר מייצג שגיאה.
        /// ספרות הן קבוצת משנה של תווים אלה, תלוי ב-`radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// פונקציה זו panics אם `radix` אינו נמצא בטווח שבין 2 ל 36.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// מחזיר את מספר אלה בייצוג הבינארי של `self`.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// מחזיר את מספר האפסים בייצוג הבינארי של `self`.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// מחזירה את מספר האפסים המובילים בייצוג הבינארי של `self`.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// מחזירה את מספר האפסים הנגררים בייצוג הבינארי של `self`.
        ///
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// מחזיר את מספר המובילים בייצוג הבינארי של `self`.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// מחזירה את מספר הנגררים בייצוג הבינארי של `self`.
        ///
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// מעביר את הסיביות שמאלה בכמות מוגדרת, `n`, העוטפת את הסיביות הקטומות לקצה המספר השלם המתקבל.
        ///
        ///
        /// שים לב שזו אינה אותה פעולה כמו מפעיל העברת `<<`!
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// מעביר את הביטים ימינה בכמות מוגדרת, `n`, העוטפת את הביטים הקטומים לתחילת המספר השלם המתקבל.
        ///
        ///
        /// שים לב שזו אינה אותה פעולה כמו מפעיל העברת `>>`!
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// הופך את סדר הבתים של המספר השלם.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// תן ל-m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// הופך את סדר הביטים במספר השלם.
        /// הסיבית הכי פחות משמעותית הופכת לסיבית הכי משמעותית, הסיבית השנייה הכי פחות משמעותית הופכת לסיבית השנייה הכי משמעותית וכו '.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// תן ל-m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// ממיר מספר שלם מאנדיאן גדול לסופיות היעד.
        ///
        /// על אנדיאן גדול זהו אי-אופ.
        /// על אנדיאן קטן הבתים מוחלפים.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// אם CFG! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } אחר {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// ממיר מספר שלם מאנדיאן קטן לסופיות היעד.
        ///
        /// על אנדיאן קטן זה אי-אופ.
        /// על אנדיאן גדול הבתים מוחלפים.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// אם CFG! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } אחר {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// ממיר את `self` לאנדיאן הגדול מאיניות המטרה.
        ///
        /// על אנדיאן גדול זהו אי-אופ.
        /// על אנדיאן קטן הבתים מוחלפים.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// אם CFG! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } { assert_eq!(n.to_be(), n.swap_bytes()) } אחר
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // או לא להיות?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// ממיר `self` לאנדיאן קטן מאיכות המטרה.
        ///
        /// על אנדיאן קטן זה אי-אופ.
        /// על אנדיאן גדול הבתים מוחלפים.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// אם CFG! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } { assert_eq!(n.to_le(), n.swap_bytes()) } אחר
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// תוספת שלמה מסומנת.
        /// מחשבת את `self + rhs`, מחזירה את `None` אם התרחשה הצפה.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// תוספת מספרים שלמה לא מסומנת.מחשבת `self + rhs`, בהנחה שהצפה לא יכולה להתרחש.
        /// התוצאה היא התנהגות לא מוגדרת כאשר
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// חיסור שלם שלם.
        /// מחשבת את `self - rhs`, מחזירה את `None` אם התרחשה הצפה.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// חיסור שלם שלם.מחשבת `self - rhs`, בהנחה שהצפה לא יכולה להתרחש.
        /// התוצאה היא התנהגות לא מוגדרת כאשר
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// כפל שלם מסומן.
        /// מחשבת את `self * rhs`, מחזירה את `None` אם התרחשה הצפה.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// כפל שלם לא מסומן.מחשבת `self * rhs`, בהנחה שהצפה לא יכולה להתרחש.
        /// התוצאה היא התנהגות לא מוגדרת כאשר
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // בטיחות: על המתקשר לקיים את חוזה הבטיחות עבור `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// חלוקה שלמה מסומנת.
        /// מחשבת `self / rhs`, מחזירה `None` אם `rhs == 0`.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // בטיחות: חלוקה באפס נבדקה לעיל ולסוגים שאינם חתומים אין אחרים
                // מצבי כישלון לחלוקה
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// חלוקה אוקלידית נבדקה.
        /// מחשבת `self.div_euclid(rhs)`, מחזירה `None` אם `rhs == 0`.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// שארית מספרים שלמה נבדקה.
        /// מחשבת `self % rhs`, מחזירה `None` אם `rhs == 0`.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // בטיחות: חלוקה באפס נבדקה לעיל ולסוגים שאינם חתומים אין אחרים
                // מצבי כישלון לחלוקה
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// נבדק מודול אוקלידי.
        /// מחשבת `self.rem_euclid(rhs)`, מחזירה `None` אם `rhs == 0`.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// שלילה בדוקה.מחשבת `-self`, מחזירה `None` אלא אם כן `self==
        /// 0`.
        ///
        /// שים לב כי שלילת כל מספר שלם חיובי תעלה על גדותיו.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// בדק משמרת שמאלה.
        /// מחשבת `self << rhs` ומחזירה `None` אם `rhs` גדול או שווה למספר הביטים ב-`self`.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// נבדק משמרת ימינה.
        /// מחשבת `self >> rhs` ומחזירה `None` אם `rhs` גדול או שווה למספר הביטים ב-`self`.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// אקספוננציה נבדקה.
        /// מחשבת את `self.pow(exp)`, מחזירה את `None` אם התרחשה הצפה.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // מאז exp!=0, סוף סוף exp צריך להיות 1.
            // התמודד עם החלק האחרון של האקספוננט בנפרד, מכיוון שריבוע הבסיס לאחר מכן אינו הכרחי ועלול לגרום להצפה מיותרת.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// רוויה תוספת שלמה.
        /// מחשבים את `self + rhs`, רווים בגבולות המספריים במקום לעלות על גדותיהם.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// חיסור מספר שלם רווי.
        /// מחשבים את `self - rhs`, רווים בגבולות המספריים במקום לעלות על גדותיהם.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// כפל שלם רווי.
        /// מחשבים את `self * rhs`, רווים בגבולות המספריים במקום לעלות על גדותיהם.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// ריבוי התפשטות שלם.
        /// מחשבים את `self.pow(exp)`, רווים בגבולות המספריים במקום לעלות על גדותיהם.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// תוספת עטיפה של (modular).
        /// מחשב `self + rhs`, עוטף את גבול הסוג.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// חיסור (modular) עוטף.
        /// מחשב `self - rhs`, עוטף את גבול הסוג.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// עטיפת כפל (modular).
        /// מחשב `self * rhs`, עוטף את גבול הסוג.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// שימו לב כי דוגמה זו משותפת בין סוגי מספרים שלמים.
        /// מה שמסביר מדוע משתמשים כאן ב-`u8`.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// חטיבת (modular) עוטפת.מחשב `self / rhs`.
        /// חלוקה עטופה על סוגים לא חתומים היא רק חלוקה רגילה.
        /// אין שום דרך שעיטוף יכול לקרות.
        /// פונקציה זו קיימת, כך שכל הפעולות מתחשבות בפעולות העטיפה.
        ///
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// עטיפת אוגדה אוקלידית.מחשב `self.div_euclid(rhs)`.
        /// חלוקה עטופה על סוגים לא חתומים היא רק חלוקה רגילה.
        /// אין שום דרך שעיטוף יכול לקרות.
        /// פונקציה זו קיימת, כך שכל הפעולות מתחשבות בפעולות העטיפה.
        /// מכיוון שמבחינת המספרים השלמים החיוביים, כל ההגדרות הנפוצות של חלוקה שוות, זה שווה בדיוק ל-`self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// שארית עטיפה של (modular).מחשב `self % rhs`.
        /// חישוב שאריות עטוף על סוגים לא חתומים הוא רק חישוב השארית הרגיל.
        ///
        /// אין שום דרך שעיטוף יכול לקרות.
        /// פונקציה זו קיימת, כך שכל הפעולות מתחשבות בפעולות העטיפה.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// עוטף מודולו אוקלידי.מחשב `self.rem_euclid(rhs)`.
        /// חישוב מודולו עטוף על סוגים לא חתומים הוא רק חישוב השארית הרגיל.
        /// אין שום דרך שעיטוף יכול לקרות.
        /// פונקציה זו קיימת, כך שכל הפעולות מתחשבות בפעולות העטיפה.
        /// מכיוון שמבחינת המספרים השלמים החיוביים, כל ההגדרות הנפוצות של חלוקה שוות, זה שווה בדיוק ל-`self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// עטיפת שלילת (modular).
        /// מחשב `-self`, עוטף את גבול הסוג.
        ///
        /// מכיוון שלסוגים לא חתומים אין מקבילים שליליים, כל היישומים של פונקציה זו יעטפו (למעט `-0`).
        /// עבור ערכים הקטנים מהמקסימום של הסוג החתום התואם התוצאה זהה להטלת הערך החתום המתאים.
        ///
        /// כל ערכים גדולים יותר שווים ל-`MAX + 1 - (val - MAX - 1)` כאשר `MAX` הוא המקסימום של החתימה המתאימה.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// שימו לב כי דוגמה זו משותפת בין סוגי מספרים שלמים.
        /// מה שמסביר מדוע משתמשים כאן ב-`i8`.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic ללא משמרת סיבית-שמאלה;
        /// מניב `self << mask(rhs)`, כאשר `mask` מסיר כל סיביות בסדר גודל גבוה של `rhs` שיגרום לשינוי לחרוג מרוחב הסיביות של הסוג.
        ///
        /// שים לב שזה *לא* זהה לסיבוב שמאלה;ה-RHS של משמרת-שמאל עוטפת מוגבל לטווח הסוג, במקום שהסיביות שהועברו מחוץ ל-LHS הוחזרו לקצה השני.
        /// כל סוגי השלמים הפרימיטיביים מיישמים פונקציה [`rotate_left`](Self::rotate_left), שעשויה להיות מה שאתה רוצה במקום.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // בטיחות: מיסוך לפי סיביות מהסוג מבטיח שלא נשתנה
            // מחוץ לתחום
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic ללא כיוון משמרת ימינה;
        /// מניב `self >> mask(rhs)`, כאשר `mask` מסיר כל סיביות בסדר גודל גבוה של `rhs` שיגרום לשינוי לחרוג מרוחב הסיביות של הסוג.
        ///
        /// שים לב שזה *לא* זהה לסיבוב ימינה;ה-RHS של משמרת-ימינה עוטפת מוגבל לטווח הסוג, במקום שהסיביות שהועברו מחוץ ל-LHS הוחזרו לקצה השני.
        /// כל סוגי השלמים הפרימיטיביים מיישמים פונקציה [`rotate_right`](Self::rotate_right), שעשויה להיות מה שאתה רוצה במקום.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // בטיחות: מיסוך לפי סיביות מהסוג מבטיח שלא נשתנה
            // מחוץ לתחום
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// אריזת אקספונטנט (modular).
        /// מחשב `self.pow(exp)`, עוטף את גבול הסוג.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // מאז exp!=0, סוף סוף exp צריך להיות 1.
            // התמודד עם החלק האחרון של האקספוננט בנפרד, מכיוון שריבוע הבסיס לאחר מכן אינו הכרחי ועלול לגרום להצפה מיותרת.
            //
            //
            acc.wrapping_mul(base)
        }

        /// מחשבת `self` + `rhs`
        ///
        /// מחזיר כפל של התוספת יחד עם בוליאן המציין אם תתרחש הצפת חשבון.
        /// אם הייתה מתרחשת הצפה, מוחזר הערך העטוף.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// מחשבת `self`, `rhs`
        ///
        /// מחזיר כפל של החיסור יחד עם בוליאנית המציינת אם תתרחש הצפת חשבון.
        /// אם הייתה מתרחשת הצפה, מוחזר הערך העטוף.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// מחשבת את הכפל של `self` ו-`rhs`.
        ///
        /// מחזיר כפל של הכפל יחד עם בוליאן המציין אם תתרחש הצפת חשבון.
        /// אם הייתה מתרחשת הצפה, מוחזר הערך העטוף.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// שימו לב כי דוגמה זו משותפת בין סוגי מספרים שלמים.
        /// מה שמסביר מדוע משתמשים כאן ב-`u32`.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// מחשבת את המחלק כאשר `self` מחולק ל-`rhs`.
        ///
        /// מחזיר כפול של המחלק יחד עם בוליאן המציין אם תתרחש הצפת חשבון.
        /// שים לב שעבור מספרים שלמים לא חתומים אף פעם אין הצפה, ולכן הערך השני הוא תמיד `false`.
        ///
        /// # Panics
        ///
        /// פונקציה זו תהיה panic אם `rhs` הוא 0.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// מחשבת את המנה של החלוקה האוקלידית `self.div_euclid(rhs)`.
        ///
        /// מחזיר כפול של המחלק יחד עם בוליאן המציין אם תתרחש הצפת חשבון.
        /// שים לב שעבור מספרים שלמים לא חתומים אף פעם אין הצפה, ולכן הערך השני הוא תמיד `false`.
        /// מכיוון שמבחינת המספרים השלמים החיוביים, כל ההגדרות הנפוצות של חלוקה שוות, זה שווה בדיוק ל-`self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// פונקציה זו תהיה panic אם `rhs` הוא 0.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// מחשבת את השאר כאשר `self` מחולק ל-`rhs`.
        ///
        /// מחזיר כפול מהשאר לאחר החלוקה יחד עם בוליאן המציין אם תתרחש הצפת חשבון.
        /// שים לב שעבור מספרים שלמים לא חתומים אף פעם אין הצפה, ולכן הערך השני הוא תמיד `false`.
        ///
        /// # Panics
        ///
        /// פונקציה זו תהיה panic אם `rhs` הוא 0.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// מחשבת את יתרת ה-`self.rem_euclid(rhs)` כאילו לפי חלוקה אוקלידית.
        ///
        /// מחזיר גוון של המודולו לאחר החלוקה יחד עם בוליאני המציין אם תתרחש הצפת חשבון.
        /// שים לב שעבור מספרים שלמים לא חתומים אף פעם אין הצפה, ולכן הערך השני הוא תמיד `false`.
        /// מכיוון שמבחינת המספרים השלמים החיוביים, כל ההגדרות הנפוצות של חלוקה שוות, פעולה זו שווה בדיוק ל-`self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// פונקציה זו תהיה panic אם `rhs` הוא 0.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// שולל את עצמי באופן שוצף.
        ///
        /// מחזירה את `!self + 1` באמצעות פעולות עטיפה להחזרת הערך המייצג את שלילת הערך הלא חתום הזה.
        /// שים לב שעבור ערכים חיוביים שלא חתומים הצפה מתרחשת תמיד, אך שלילת 0 אינה עולה על גדותיה.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// מעביר את עצמי שנותר על ידי ביטים `rhs`.
        ///
        /// מחזיר כפל של הגרסה המוסטה של העצמי יחד עם בוליאנית המציינת אם ערך ההחלפה היה גדול או שווה למספר הביטים.
        /// אם ערך המשמרת גדול מדי, הערך מוסווה (N-1) כאשר N הוא מספר הביטים, וערך זה משמש לביצוע ההסטה.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// מעביר את הזכות העצמית על ידי `rhs` ביטים.
        ///
        /// מחזיר כפל של הגרסה המוסטה של העצמי יחד עם בוליאנית המציינת אם ערך ההחלפה היה גדול או שווה למספר הביטים.
        /// אם ערך המשמרת גדול מדי, הערך מוסווה (N-1) כאשר N הוא מספר הביטים, וערך זה משמש לביצוע ההסטה.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// מעלה את עצמי לעוצמה של `exp`, תוך שימוש באקספורנטציה על ידי ריבוע.
        ///
        /// מחזיר כפול מההרחבה יחד עם bool המציין אם התרחשה הצפה.
        ///
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, נכון));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // שטח שריטה לאחסון תוצאות Overflow_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // מאז exp!=0, סוף סוף exp צריך להיות 1.
            // התמודד עם החלק האחרון של האקספוננט בנפרד, מכיוון שריבוע הבסיס לאחר מכן אינו הכרחי ועלול לגרום להצפה מיותרת.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// מעלה את עצמי לעוצמה של `exp`, תוך שימוש באקספורנטציה על ידי ריבוע.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // מאז exp!=0, סוף סוף exp צריך להיות 1.
            // התמודד עם החלק האחרון של האקספוננט בנפרד, מכיוון שריבוע הבסיס לאחר מכן אינו הכרחי ועלול לגרום להצפה מיותרת.
            //
            //
            acc * base
        }

        /// מבצע חטיבה אוקלידית.
        ///
        /// מכיוון שמבחינת המספרים השלמים החיוביים, כל ההגדרות הנפוצות של חלוקה שוות, זה שווה בדיוק ל-`self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// פונקציה זו תהיה panic אם `rhs` הוא 0.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// מחשבת את שארית הפחות מ-`self (mod rhs)`.
        ///
        /// מכיוון שמבחינת המספרים השלמים החיוביים, כל ההגדרות הנפוצות של חלוקה שוות, זה שווה בדיוק ל-`self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// פונקציה זו תהיה panic אם `rhs` הוא 0.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// מחזירה `true` אם ורק אם `self == 2^k` עבור `k` כלשהו.
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // מחזירה עוצמה פחותה מהספק הבא של שניים.
        // (עבור 8u8 ההספק הבא של שניים הוא 8u8 ועבור 6u8 זה 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // שיטה זו אינה יכולה לעלות על גדותיה, שכן במקרי הצפת `next_power_of_two` היא מחזירה בסופו של דבר את הערך המקסימלי של הסוג, ויכולה להחזיר 0 ל-0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // בטיחות: מכיוון ש-`p > 0`, הוא לא יכול להיות מורכב לחלוטין מאפסים מובילים.
            // פירוש הדבר שהשינוי תמיד נמצא בתחומי הגבול, ולחלק מהמעבדים (כגון intel pre-haswell) יש פנימיות ctlz יעילה יותר כאשר הטיעון אינו אפס.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// מחזיר את העוצמה הקטנה ביותר מבין שניים הגדולים או שווים ל-`self`.
        ///
        /// כאשר ערך ההחזרה עולה על גדותיו (כלומר, `self > (1 << (N-1))` לסוג `uN`), הוא panics במצב ניפוי באגים וערך ההחזרה עטוף ל 0 במצב שחרור (המצב היחיד שבו השיטה יכולה להחזיר 0).
        ///
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// מחזיר את העוצמה הקטנה ביותר מבין שניים הגדולים או שווים ל-`n`.
        /// אם ההספק הבא של שניים גדול מהערך המרבי של הסוג, `None` מוחזר, אחרת הכוח של שניים עטוף ב-`Some`.
        ///
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// מחזיר את העוצמה הקטנה ביותר מבין שניים הגדולים או שווים ל-`n`.
        /// אם ההספק הבא של שניים גדול מהערך המרבי של הסוג, ערך ההחזרה נעטף ל-`0`.
        ///
        ///
        /// # Examples
        ///
        /// שימוש בסיסי:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// החזר את ייצוג הזיכרון של מספר שלם זה כמערך בתים בסדר בתים (network) גדול-אנדי.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// החזר את ייצוג הזיכרון של מספר שלם זה כמערך בתים בסדר בתים קטן-אנדי.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// החזר את ייצוג הזיכרון של מספר שלם זה כמערך בתים בסדר בתים מקורי.
        ///
        /// כאשר משתמשים בסיומיות הילידים של פלטפורמת היעד, על קוד נייד להשתמש ב-[`to_be_bytes`] או [`to_le_bytes`], לפי הצורך, במקום זאת.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     בתים, אם cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } אחר {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // בטיחות: צליל קונסט מכיוון שמספרים שלמים הם סוגי נתונים ישנים רגילים כך שנוכל תמיד
        // להעביר אותם למערכים של בתים
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // בטיחות: מספרים שלמים הם סוגי נתונים ישנים רגילים כך שנוכל תמיד להעביר אותם אליהם
            // מערכי בתים
            unsafe { mem::transmute(self) }
        }

        /// החזר את ייצוג הזיכרון של מספר שלם זה כמערך בתים בסדר בתים מקורי.
        ///
        ///
        /// [`to_ne_bytes`] יש להעדיף על פני זה במידת האפשר.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// תן בתים= num.as_ne_bytes();
        /// assert_eq!(
        ///     בתים, אם cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } אחר {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // בטיחות: מספרים שלמים הם סוגי נתונים ישנים רגילים כך שנוכל תמיד להעביר אותם אליהם
            // מערכי בתים
            unsafe { &*(self as *const Self as *const _) }
        }

        /// צור ערך שלם מקומי של האנדיאן מהייצוג שלו כמערך בתים באנדיאן גדול.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// השתמש ב-std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * קלט=מנוחה;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// צור ערך שלם מקומי של האנדיאן מהייצוג שלו כמערך בתים באנדיאן קטן.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// השתמש ב-std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * קלט=מנוחה;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// צור ערך שלם מקומי של אנדיאן מייצוג הזיכרון שלו כמערך בתים באנדיות מקורית.
        ///
        /// ככל שמשתמשים בסיומיות הילידים של פלטפורמת היעד, קוד נייד ככל הנראה רוצה להשתמש ב-[`from_be_bytes`] או [`from_le_bytes`], לפי הצורך במקום זאת.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } אחר {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// השתמש ב-std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * קלט=מנוחה;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // בטיחות: צליל קונסט מכיוון שמספרים שלמים הם סוגי נתונים ישנים רגילים כך שנוכל תמיד
        // משנים אליהם
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // בטיחות: מספרים שלמים הם סוגי נתונים ישנים פשוטים כך שנוכל תמיד להעביר אליהם
            unsafe { mem::transmute(bytes) }
        }

        /// קוד חדש צריך להעדיף להשתמש
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// מחזירה את הערך הקטן ביותר שניתן לייצג על ידי סוג שלם זה.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// קוד חדש צריך להעדיף להשתמש
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// מחזירה את הערך הגדול ביותר שניתן לייצג על ידי סוג שלם זה.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}