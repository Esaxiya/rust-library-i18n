use backtrace::Backtrace;

// שם מודול בן 50 תווים
mod _234567890_234567890_234567890_234567890_234567890 {
    // שם מבנה בן 50 תווים
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// יש לקצץ שמות פונקציות ארוכים לתווים (MAX_SYM_NAME, 1).
// הפעל בדיקה זו רק עבור msvc, מכיוון ש-gnu מדפיס "<no info>" לכל המסגרות.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // 10 חזרות של שם המבנה, כך ששם פונקציה מוסמך לחלוטין הוא לפחות 10 *(50 + 50)* 2=2000 תווים.
    //
    // זה למעשה ארוך יותר מכיוון שהוא כולל גם `::`, `<>` ושם המודול הנוכחי
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}