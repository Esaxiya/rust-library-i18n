# backtrace-rs

[Documentation](https://docs.rs/backtrace)

ספרייה לרכישת מעקב אחורי בזמן ריצה עבור Rust.
ספרייה זו שואפת לשפר את התמיכה של הספרייה הסטנדרטית על ידי מתן ממשק פרוגרמטי לעבודה, אך היא גם תומכת בפשטות בהדפסת המעקב האחורי הנוכחי כמו panics של libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

כדי פשוט לתפוס מעקב אחורי ולדחות את ההתמודדות איתו עד למועד מאוחר יותר, אתה יכול להשתמש בסוג `Backtrace` ברמה העליונה.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

אם, עם זאת, תרצה לקבל יותר גישה גולמית לפונקציונליות האיתור בפועל, תוכל להשתמש ישירות בפונקציות `trace` ו-`resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // פתור את מצביע ההוראות לשם סמל
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // המשך ללכת למסגרת הבאה
    });
}
```

# License

פרויקט זה מורשה תחת אחת מהן

 * רישיון Apache, גרסה 2.0, ([LICENSE-APACHE](LICENSE-APACHE) או http://www.apache.org/licenses/LICENSE-2.0)
 * רישיון MIT ([LICENSE-MIT](LICENSE-MIT) או http://opensource.org/licenses/MIT)

לבחירתך.

### Contribution

אלא אם כן אתה מצהיר במפורש אחרת, כל תרומה שהוגשה בכוונה להכללה ב-trace-rs על ידך, כהגדרתה ברישיון Apache-2.0, תהיה ברישיון כפול כאמור לעיל, ללא תנאים או תנאים נוספים.







