//! מודול לסיוע בניהול כריכות dbghelp ב-Windows
//!
//! עקבות אחורה ב-Windows (לפחות ב-MSVC) מופעלות במידה רבה באמצעות `dbghelp.dll` והפונקציות השונות שהוא מכיל.
//! פונקציות אלה נטענות כרגע *באופן דינמי* במקום קישור ל-`dbghelp.dll` באופן סטטי.
//! זה נעשה כיום על ידי הספרייה הסטנדרטית (והיא נדרשת בתיאוריה שם), אך היא מאמץ לסייע בהפחתת תלות ה-dll הסטטית של ספרייה מכיוון שעקבות אחזור הן בדרך כלל די אופציונליות.
//!
//! עם זאת, `dbghelp.dll` נטען כמעט תמיד בהצלחה ב-Windows.
//!
//! שים לב שמכיוון שאנחנו טוענים את כל התמיכה הזו באופן דינמי איננו יכולים להשתמש בהגדרות הגולמיות ב-`winapi`, אלא עלינו להגדיר את סוגי מצביעי הפונקציה בעצמנו ולהשתמש בזה.
//! אנחנו לא באמת רוצים לעסוק בשכפול winapi, ולכן יש לנו תכונת Cargo `verify-winapi` שמצהירה שכל הכריכות תואמות את אלה ב-winapi ותכונה זו מופעלת ב-CI.
//!
//! לבסוף, תציין כאן ש-dll עבור `dbghelp.dll` לעולם לא נפרק, וזה כרגע מכוון.
//! החשיבה היא שאנחנו יכולים לשמור אותו במטמון ברחבי העולם ולהשתמש בו בין שיחות ל-API, תוך הימנעות מ-loads/unloads יקר.
//! אם זו בעיה לגלאי נזילה או משהו כזה נוכל לחצות את הגשר כשנגיע לשם.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// עבוד סביב `SymGetOptions` ו-`SymSetOptions` שלא נמצאים ב-winapi עצמו.
// אחרת זה משמש רק כשאנחנו בודקים סוגים כנגד winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // עדיין לא הוגדר ב-winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // זה מוגדר ב-winapi, אך זה לא נכון (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // עדיין לא הוגדר ב-winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// מאקרו זה משמש להגדרת מבנה `Dbghelp` המכיל באופן פנימי את כל מצביעי הפונקציה שאנו עשויים לטעון.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// ה-DLL הטעון עבור `dbghelp.dll`
            dll: HMODULE,

            // כל מצביע פונקציה עבור כל פונקציה שאנו עשויים להשתמש בה
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // בתחילה לא טעינו את ה-DLL
            dll: 0 as *mut _,
            // ראשית כל הפונקציות מוגדרות לאפס כדי לומר שהן צריכות להיות טעינות באופן דינמי.
            //
            $($name: 0,)*
        };

        // סוג הנוחות עבור כל סוג פונקציה.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// ניסיונות לפתוח את `dbghelp.dll`.
            /// מחזיר הצלחה אם זה עובד או שגיאה אם `LoadLibraryW` נכשל.
            ///
            /// Panics אם הספרייה כבר טעונה.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // פונקציה לכל שיטה בה נרצה להשתמש.
            // כאשר הוא נקרא הוא יקרא את מצביע הפונקציה במטמון או יטען אותו ויחזיר את הערך הטעון.
            // טוענים כי עומסים יצליחו.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // פרוקסי נוחות לשימוש במנעולי הניקוי להפניה לפונקציות dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// אתחל את כל התמיכה הדרושה לגישה לפונקציות `dbghelp` API מ-crate זה.
///
///
/// שים לב כי פונקציה זו היא **בטוחה**, יש לה סינכרון משלה באופן פנימי.
/// שים לב גם כי ניתן לקרוא לפונקציה זו מספר פעמים רקורסיבית.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // הדבר הראשון שעלינו לעשות הוא לסנכרן פונקציה זו.ניתן לקרוא לזה במקביל משרשורים אחרים או רקורסיבית בתוך שרשור אחד.
        // שים לב שזה מסובך יותר מכיוון שמה שאנחנו משתמשים כאן, `dbghelp`,*גם* צריך להיות מסונכרן עם כל שאר המתקשרים ל-`dbghelp` בתהליך זה.
        //
        // בדרך כלל אין באמת שיחות רבות ל-`dbghelp` באותו תהליך, וכנראה שנוכל להניח בבטחה שאנחנו היחידים שניגשים אליו.
        // יש, עם זאת, משתמש עיקרי אחד אחר שעלינו לדאוג שהוא באופן אירוני עצמנו, אך בספרייה הסטנדרטית.
        // הספרייה הסטנדרטית Rust תלויה ב-crate זה לצורך תמיכה במעקב אחורה, ו-crate זה קיים גם ב-crates.io.
        // המשמעות היא שאם הספרייה הסטנדרטית מדפיסה מעקב אחורי של panic היא עשויה להתמודד עם crate זה שמגיע מ-crates.io ולגרום לתקלות.
        //
        // כדי לעזור בפתרון בעיית סנכרון זו אנו משתמשים כאן בטריק ספציפי ל-Windows (אחרי הכל, מדובר במגבלה ספציפית ל-Windows לגבי סנכרון).
        // אנו יוצרים *מושב מקומי* בשם mutex כדי להגן על שיחה זו.
        // הכוונה כאן היא שהספריה הסטנדרטית ו-crate זה לא צריכים לשתף ממשקי API ברמת Rust כדי לסנכרן כאן אלא יכולים לעבוד מאחורי הקלעים כדי לוודא שהם מסתנכרנים זה עם זה.
        //
        // באופן זה כאשר פונקציה זו נקראת דרך הספרייה הרגילה או דרך crates.io אנו יכולים להיות בטוחים כי אותו Mutex נרכש.
        //
        // אז כל זה אומר שהדבר הראשון שאנו עושים כאן הוא אנו יוצרים באופן אטומי `HANDLE` שהוא שם mutex ב-Windows.
        // אנו מסנכרנים מעט עם שרשורים אחרים המשתפים פונקציה זו באופן ספציפי ומוודאים שנוצר רק ידית אחת לכל מופע של פונקציה זו.
        // שים לב שהידית לעולם אינה סגורה ברגע שהיא מאוחסנת בעולם.
        //
        // אחרי שנעבור את המנעול פשוט נרכוש אותו, וידית ה-`Init` שאנו מחלקים תהיה אחראית להפלתו בסופו של דבר.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // אוקיי, פאי!עכשיו כשכולנו מסונכרנים בבטחה, בואו נתחיל לעבד הכל.
        // ראשית עלינו לוודא כי `dbghelp.dll` נטען בפועל בתהליך זה.
        // אנו עושים זאת באופן דינמי כדי למנוע תלות סטטית.
        // זה נעשה מבחינה היסטורית בכדי לעקוף בעיות מוזרות של קישורים ונועד להפוך את הבינאריות לניידות יותר, מכיוון שמדובר בעיקר בכלי ניפוי באגים.
        //
        //
        // לאחר שפתחנו את `dbghelp.dll` עלינו לקרוא לכמה פונקציות אתחול בו, וזה מפורט בהמשך.
        // אנחנו עושים זאת רק פעם אחת, אז יש לנו בוליאני גלובלי המציין אם סיימנו עדיין או לא.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // וודא כי דגל ה-`SYMOPT_DEFERRED_LOADS` מוגדר, מכיוון שעל פי המסמכים של MSVC עצמו בנושא זה: "This is the fastest, most efficient way to use the symbol handler.", אז בוא נעשה את זה!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // למעשה אתחל סמלים באמצעות MSVC.שים לב שהדבר עלול להיכשל, אך אנו מתעלמים מכך.
        // אין המון אמנות קודמת לכך כשלעצמה, אך נראה כי LLVM באופן פנימי מתעלם מערך ההחזר כאן ואחת מספריות החיטוי ב-LLVM מדפיסה אזהרה מפחידה אם זה נכשל אך בעצם מתעלם ממנו בטווח הארוך.
        //
        //
        // מקרה אחד זה עולה הרבה עבור Rust הוא שהספריה הסטנדרטית ו-crate ב-crates.io שניהם רוצים להתחרות על `SymInitializeW`.
        // ההיסטוריה של הספרייה הסטנדרטית רצתה לאתחל ואז לנקות אותה רוב הזמן, אך כעת כשהיא משתמשת ב-crate זה אומר שמישהו יתחיל לאתחול והשני יאסוף את האתחול הזה.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}