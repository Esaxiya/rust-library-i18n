use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// פתרון כתובת לסמל והעברת הסמל לסגירה שצוינה.
///
/// פונקציה זו תחפש את הכתובת הנתונה באזורים כגון טבלת הסמלים המקומית, טבלת הסמלים הדינמית או מידע על איתור באגים ב-DWARF (תלוי ביישום המופעל) כדי למצוא סמלים להניב.
///
///
/// ייתכן שלא ניתן יהיה לקרוא לסגירה אם לא ניתן היה לבצע רזולוציה, וניתן לקרוא לה יותר מפעם אחת במקרה של פונקציות מוטבעות.
///
/// סמלים שהופקו מייצגים את הביצוע ב-`addr` שצוין, ומחזירים זוגות file/line עבור אותה כתובת (אם קיימת).
///
/// שים לב שאם יש לך `Frame`, מומלץ להשתמש בפונקציה `resolve_frame` במקום זה.
///
/// # תכונות נדרשות
///
/// פונקציה זו מחייבת את תכונת `std` של `backtrace` crate כדי להיות מופעלת, ותכונת `std` מופעלת כברירת מחדל.
///
/// # Panics
///
/// פונקציה זו שואפת לעולם לא panic, אך אם ה-`cb` סיפק panics אז יש פלטפורמות שיאלצו panic כפול לבטל את התהליך.
/// פלטפורמות מסוימות משתמשות בספריית C המשתמשת באופן פנימי בשיחות חוזרות שלא ניתן לפרק אותן, ולכן פאניקה מ-`cb` עשויה לגרום להפסקת תהליך.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // רק להסתכל על המסגרת העליונה
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// פתור מסגרת שלכידה בעבר לסמל, והעבר את הסמל לסגירה שצוינה.
///
/// פונקציה זו מבצעת את אותה פונקציה כמו `resolve`, אלא שהיא לוקחת `Frame` כארגומנט במקום כתובת.
/// זה יכול לאפשר ליישומי פלטפורמה מסוימים של backtracing לספק מידע סמלי מדויק יותר או מידע על מסגרות מוטבעות למשל.
///
/// מומלץ להשתמש בזה אם אתה יכול.
///
/// # תכונות נדרשות
///
/// פונקציה זו מחייבת את תכונת `std` של `backtrace` crate כדי להיות מופעלת, ותכונת `std` מופעלת כברירת מחדל.
///
/// # Panics
///
/// פונקציה זו שואפת לעולם לא panic, אך אם ה-`cb` סיפק panics אז יש פלטפורמות שיאלצו panic כפול לבטל את התהליך.
/// פלטפורמות מסוימות משתמשות בספריית C המשתמשת באופן פנימי בשיחות חוזרות שלא ניתן לפרק אותן, ולכן פאניקה מ-`cb` עשויה לגרום להפסקת תהליך.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // רק להסתכל על המסגרת העליונה
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// ערכי IP ממסגרות מחסנית הם בדרך כלל (always?) ההוראה *אחרי* השיחה שהיא עקבות הערימה בפועל.
// מסמל את זה גורם למספר filename/line להיות אחד קדימה ואולי לריק אם זה קרוב לסוף הפונקציה.
//
// נראה כי זה בעצם תמיד המקרה בכל הפלטפורמות, ולכן אנו מחסירים אחד מ-IP נפתר כדי לפתור אותו להוראות השיחה הקודמות במקום שההוראה תחזור אליה.
//
//
// באופן אידיאלי לא היינו עושים זאת.
// באופן אידיאלי היינו נדרשים שמתקשרים של ממשקי ה-API של `resolve` כאן יבצעו ידנית את ה--1 ויחשבו שהם רוצים מידע מיקום עבור ההוראה *הקודמת*, ולא הנוכחית.
// באופן אידיאלי אנו חושפים גם ב-`Frame` אם אנו אכן הכתובת של ההוראה הבאה או הנוכחית.
//
// לעת עתה, אם כי זהו עניין נישה למדי, כך שאנחנו רק באופן פנימי מחסירים אחד כזה.
// הצרכנים צריכים להמשיך לעבוד ולהשיג תוצאות די טובות, אז אנחנו צריכים להיות מספיק טובים.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// זהה ל-`resolve`, רק לא בטוח מכיוון שהוא לא מסונכרן.
///
/// לפונקציה זו אין ערבי סינכרון, אך היא זמינה כאשר תכונת `std` של crate זו אינה מורכבת.
/// עיין בפונקציה `resolve` לקבלת תיעוד ודוגמאות נוספות.
///
/// # Panics
///
/// ראה מידע על `resolve` לקבלת אזהרות על `cb` בהלה.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// זהה ל-`resolve_frame`, רק לא בטוח מכיוון שהוא לא מסונכרן.
///
/// לפונקציה זו אין ערבי סינכרון, אך היא זמינה כאשר תכונת `std` של crate זו אינה מורכבת.
/// עיין בפונקציה `resolve_frame` לקבלת תיעוד ודוגמאות נוספות.
///
/// # Panics
///
/// ראה מידע על `resolve_frame` לקבלת אזהרות על `cb` בהלה.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait המייצג את הרזולוציה של סמל בקובץ.
///
/// trait זה מופק כאובייקט trait לסגירה שניתנה לפונקציה `backtrace::resolve`, והוא נשלח כמעט מכיוון שלא ידוע איזו יישום עומד מאחוריו.
///
///
/// סמל יכול לתת מידע קונטקסטואלי על פונקציה, למשל שם, שם קובץ, מספר שורה, כתובת מדויקת וכו '.
/// לא כל המידע זמין תמיד בסמל, אולם כל השיטות מחזירות `Option`.
///
///
pub struct Symbol {
    // TODO: חייבים להתמיד בסופו של דבר עד `Symbol`,
    // אבל כרגע זה שינוי שבור.
    // נכון לעכשיו זה בטוח שכן `Symbol` מועבר רק על ידי הפניה ולא ניתן לשכפל אותו.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// מחזירה את השם של פונקציה זו.
    ///
    /// ניתן להשתמש במבנה המוחזר לשאילתת מאפיינים שונים אודות שם הסמל:
    ///
    ///
    /// * יישום ה-`Display` ידפיס את הסמל המסולסל.
    /// * ניתן לגשת לערך ה-`str` הגולמי של הסמל (אם הוא תקף utf-8).
    /// * ניתן לגשת לבייטים הגולמיים לשם הסמל.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// מחזירה את כתובת ההתחלה של פונקציה זו.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// מחזיר את שם הקובץ הגולמי כפרוסה.
    /// זה שימושי בעיקר בסביבות `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// מחזיר את מספר העמודה למקום בו סמל זה מבוצע כעת.
    ///
    /// רק gimli מספק כעת ערך כאן וגם אז רק אם `filename` מחזיר את `Some`, ולכן הוא נתון לפיכך לאזהרות דומות.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// מחזיר את מספר השורה למקום בו סמל זה מבוצע כעת.
    ///
    /// ערך החזרה זה הוא בדרך כלל `Some` אם `filename` מחזיר את `Some`, וכתוצאה מכך כפוף לאזהרות דומות.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// מחזיר את שם הקובץ שבו הוגדרה פונקציה זו.
    ///
    /// זה זמין כרגע רק כאשר משתמשים ב-libbacktrace או gimli (למשל
    /// unix פלטפורמות אחרות) וכאשר מחובר בינארי עם debuginfo.
    /// אם לא מתקיים אף אחד מהתנאים הללו סביר להניח שהדבר יחזיר את `None`.
    ///
    /// # תכונות נדרשות
    ///
    /// פונקציה זו מחייבת את תכונת `std` של `backtrace` crate כדי להיות מופעלת, ותכונת `std` מופעלת כברירת מחדל.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // אולי סמל C++ מנותח, אם הניתוח של הסמל המנומר כ-Rust נכשל.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // הקפד לשמור על גודל אפס זה, כך שתכונת `cpp_demangle` אינה כרוכה בעלות כאשר היא מושבתת.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// עטיפה סביב שם סמל כדי לספק גישה ארגונומית לשם המסולסל, בתים גולמיים, מחרוזת גולמית וכו '.
///
// אפשר קוד מת כאשר התכונה `cpp_demangle` אינה מופעלת.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// יוצר שם סמל חדש מהבתים הגולמיים הבסיסיים.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// מחזירה את שם סמל ה-(mangled) הגולמי כ-`str` אם הסמל תקף ל-utf-8.
    ///
    /// השתמש ביישום `Display` אם אתה רוצה את הגרסה המפוצלת.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// מחזיר את שם הסמל הגולמי כרשימת בתים
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // זה עשוי להדפיס אם הסמל המפולג אינו תקף בפועל, לכן התמודד עם השגיאה כאן בחן על ידי לא להפיץ אותה כלפי חוץ.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// נסה להחזיר לעצמו את הזיכרון השמור במטרה לסמל כתובות.
///
/// שיטה זו תנסה לשחרר כל מבני נתונים גלובליים שנשמרו במטמון באופן גלובלי או בשרשור, המייצגים בדרך כלל מידע DWARF מנותח או דומה.
///
///
/// # Caveats
///
/// אמנם פונקציה זו תמיד זמינה אך למעשה אינה עושה דבר ברוב היישומים.
/// ספריות כמו dbghelp או libbacktrace אינן מספקות מתקנים להתמודדות עם המדינה ולניהול הזיכרון שהוקצה.
/// לעת עתה תכונת `gimli-symbolize` של crate זו היא התכונה היחידה שיש לפונקציה זו השפעה כלשהי.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}