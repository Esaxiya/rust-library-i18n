//! אסטרטגיית סימולציה באמצעות קוד ניתוח ה DWARF ב libbacktrace.
//!
//! הספרייה libbacktrace C, המופצת בדרך כלל עם gcc, תומכת לא רק ביצירת מעקב אחורי (שאיננו משתמשים בו בפועל) אלא גם מסמלת את המסלול האחורי וטיפול במידע ניפוי באגים על דברים כמו מסגרות מוטבעות ומה לא.
//!
//!
//! זה מסובך יחסית בגלל הרבה חששות שונים כאן, אבל הרעיון הבסיסי הוא:
//!
//! * ראשית אנו קוראים ל-`backtrace_syminfo`.זה מקבל מידע על סמלים מטבלת הסמלים הדינמיים אם אנחנו יכולים.
//! * לאחר מכן אנו קוראים `backtrace_pcinfo`.פעולה זו תנתח טבלאות מידע על ניפוי באגים אם הן זמינות ותאפשר לנו לשחזר מידע על מסגרות מוטבעות, שמות קבצים, מספרי שורות וכו '.
//!
//! יש הרבה תחבולות לגבי הכנסת שולחנות הגמדים למסלול libbacktrace, אבל אני מקווה שזה לא סוף העולם וברור מספיק כשקוראים למטה.
//!
//! זוהי אסטרטגיית הסימון המוגדרת כברירת מחדל לפלטפורמות שאינן MSVC ולא OSX.ב-libstd אף שזו אסטרטגיית ברירת המחדל עבור OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // אם אפשר העדיף את שם `function` שמגיע מ-debuginfo ובדרך כלל יכול להיות מדויק יותר למסגרות מוטבעות למשל.
                // אם זה לא קיים אם כי חזור לשם טבלת הסמלים שצוינה ב-`symname`.
                //
                // שים לב שלעיתים `function` יכול להרגיש מעט פחות מדויק, למשל רישום כ-`try<i32,closure>` אינו במקום `std::panicking::try::do_call`.
                //
                // לא ממש ברור מדוע, אך בסך הכל השם `function` נראה מדויק יותר.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // לא לעשות כלום בינתיים
}

/// סוג המצביע `data` שהועבר ל-`syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // ברגע שההחזרה הזו מופעלת מ-`backtrace_syminfo` כשאנחנו מתחילים לפתור אנחנו הולכים רחוק יותר להתקשר ל-`backtrace_pcinfo`.
    // הפונקציה `backtrace_pcinfo` תתייעץ במידע איתור באגים ותנסה לעשות דברים כמו לשחזר מידע file/line כמו גם למסגרות מוטבעות.
    // שים לב ש-`backtrace_pcinfo` יכול להיכשל או לא לעשות הרבה אם אין מידע על ניפוי באגים, כך שאם זה קורה אנו בטוחים להתקשר להתקשרות חוזרת עם לפחות סמל אחד מה-`syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// סוג המצביע `data` שהועבר ל-`pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// ממשק ה-API של libbacktrace תומך ביצירת מדינה, אך הוא אינו תומך בהשמדת מדינה.
// אני באופן אישי רואה בזה פירושו שמדינה נועדה להיווצר ואז תחיה לנצח.
//
// אשמח לרשום מטפל at_exit() שמנקה את המצב הזה, אך libbacktrace אינו מספק דרך לעשות זאת.
//
// עם אילוצים אלה, לפונקציה זו יש מצב שמור במטמון סטטי שמחושב בפעם הראשונה שזו מתבקשת.
//
// זכור כי מעקב לאחור מתרחש באופן סדרתי (נעילה גלובלית אחת).
//
// שימו לב שחוסר הסנכרון כאן נובע מהדרישה ש-`resolve` יסונכרן חיצונית.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // אל תממש יכולות threadsafe של libbacktrace מכיוון שאנחנו תמיד קוראים לזה באופן מסונכרן.
        //
        0,
        error_cb,
        ptr::null_mut(), // אין נתונים נוספים
    );

    return STATE;

    // שים לב שכדי ש libbacktrace יפעל בכלל, הוא צריך למצוא את פרטי הבאגים של DWARF עבור ההפעלה הנוכחית.זה בדרך כלל עושה זאת באמצעות מספר מנגנונים, כולל, אך לא מוגבל ל:
    //
    // * /proc/self/exe בפלטפורמות נתמכות
    // * שם הקובץ הועבר במפורש בעת יצירת המדינה
    //
    // ספריית libbacktrace היא מעט גדול של קוד C.זה אומר באופן טבעי שיש לו פגיעות בנושא בטיחות זיכרון, במיוחד כאשר מטפלים בדיבוג מידע שגוי.
    // ליבסטד נתקלה בשפע כאלה מבחינה היסטורית.
    //
    // אם משתמשים ב-/proc/self/exe, אנו יכולים בדרך כלל להתעלם מאלה מכיוון שאנו מניחים ש libbacktrace הוא "mostly correct" ואחרת אינו עושה דברים מוזרים עם מידע על ניפוי באגים "attempted to be correct".
    //
    //
    // אם אנו מעבירים שם קובץ, עם זאת, יתכן שבפלטפורמות מסוימות (כמו BSD) שבהן שחקן זדוני יכול לגרום להצבת קובץ שרירותי במקום זה.
    // פירוש הדבר שאם נספר על libbacktrace על שם קובץ ייתכן שהוא משתמש בקובץ שרירותי, מה שעלול לגרום לתקלות.
    // אם אנחנו לא מספרים על libbacktrace שום דבר, אז זה לא יעשה שום דבר בפלטפורמות שלא תומכות בנתיבים כמו /proc/self/exe!
    //
    // בהתחשב בכל מה שאנחנו משתדלים כמה שיותר *לא* להעביר שם קובץ, אבל אנחנו חייבים בפלטפורמות שכלל לא תומכות ב-/proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // שים לב שבאופן אידיאלי נשתמש ב-`std::env::current_exe`, אך איננו יכולים לדרוש `std` כאן.
            //
            // השתמש ב-`_NSGetExecutablePath` כדי לטעון את נתיב ההפעלה הנוכחי לאזור סטטי (שאם הוא קטן מדי פשוט מוותר).
            //
            //
            // שים לב שאנחנו סומכים ברצינות על libbacktrace כאן שלא ימות על הפעלות מושחתות, אבל זה בוודאי כן ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows יש מצב של פתיחת קבצים שלאחר מחיקתו לא ניתן למחוק אותו.
            // זה באופן כללי מה שאנחנו רוצים כאן מכיוון שאנחנו רוצים להבטיח שההפעלה שלנו לא תשתנה מתחתינו אחרי שנמסור אותו ל libbacktrace, בתקווה להקטין את היכולת להעביר נתונים שרירותיים ל libbacktrace (שעשוי להיות מטופל).
            //
            //
            // בהתחשב בעובדה שאנחנו עושים קצת ריקוד כאן כדי לנסות להשיג סוג של נעילה על הדימוי שלנו:
            //
            // * קבל טיפול בתהליך הנוכחי, טען את שם הקובץ שלו.
            // * פתח קובץ לשם קובץ זה עם הדגלים הנכונים.
            // * טען מחדש את שם הקובץ של התהליך הנוכחי וודא שהוא זהה
            //
            // אם כל זה יעבור, תיאורטית אכן פתחנו את קובץ התהליך שלנו ומובטח שהוא לא ישתנה.FWIW חבורה זו מועתקת מ-libstd מבחינה היסטורית, כך שזו הפרשנות הטובה ביותר שלי למתרחש.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // זה חי בזיכרון סטטי כדי שנוכל להחזיר אותו ..
                static mut BUF: [i8; N] = [0; N];
                // ... וזה חי בערימה מכיוון שהוא זמני
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // בכוונה לדלוף את `handle` מכיוון שיש את זה פתוח צריך לשמור על הנעילה שלנו בשם הקובץ הזה.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // אנו רוצים להחזיר פרוסה שמסתיימת באפס, כך שאם הכל התמלא וזה שווה לאורך הכולל אז השווה את זה לכישלון.
                //
                //
                // אחרת כשאתה מחזיר הצלחה, ודא שבית האפס נכלל בפרוסה.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // שגיאות עקיבה נסחפות כרגע מתחת לשטיח
    let state = init_state();
    if state.is_null() {
        return;
    }

    // התקשר ל-`backtrace_syminfo` API אשר (מקריאת הקוד) אמור להתקשר ל-`syminfo_cb` בדיוק פעם אחת (או להיכשל עם שגיאה ככל הנראה).
    // לאחר מכן אנו מטפלים יותר ב-`syminfo_cb`.
    //
    // שים לב שאנו עושים זאת מכיוון ש-`syminfo` יתייעץ בטבלת הסמלים ונמצא שמות סמלים גם אם אין מידע ניפוי באגים בינארי.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}