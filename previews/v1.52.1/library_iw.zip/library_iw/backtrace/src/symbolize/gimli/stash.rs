// משמש רק ב-Linux כרגע, אז אפשר קוד מת במקום אחר
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// מקצה זירה פשוט עבור מאגרי בתים.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// מקצה מאגר בגודל שצוין ומחזיר אליו הפניה משתנה.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // בטיחות: זו הפונקציה היחידה שבונה אי פעם משתנה
        // התייחסות ל-`self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // בטיחות: אנחנו אף פעם לא מסירים אלמנטים מ-`self.buffers`, אז התייחסות
        // לנתונים בתוך כל מאגר יחיה כל עוד `self` עושה זאת.
        &mut buffers[i]
    }
}