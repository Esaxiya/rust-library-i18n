use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr לוקח החזרה שתקבל מצביע dl_phdr_info עבור כל DSO שקושר לתהליך.
    // dl_iterate_phdr גם מבטיח שהקישור הדינמי נעול מתחילתו ועד סופו של האיטרציה.
    // אם השיבה החוזרת מחזירה ערך שאינו אפס, האיטרציה מסתיימת מוקדם.
    // 'data' יועבר כטיעון השלישי להתקשרות חוזרת בכל שיחה.
    // 'size' נותן את גודל ה-dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// עלינו לנתח את מזהה ה-build וכמה נתוני כותרת בסיסיים של התוכנית, מה שאומר שאנחנו צריכים גם קצת דברים ממפרט ה-ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// כעת עלינו לשכפל, קצת אחר ביט, את מבנה הסוג dl_phdr_info המשמש את המקשר הדינמי הנוכחי של פוקסיה.
// לכרום יש גם גבול ABI זה כמו גם משטח קריסה.
// בסופו של דבר ברצוננו להעביר מקרים אלה לשימוש בחיפוש שדונים, אך נצטרך לספק זאת ב-SDK וזה טרם נעשה.
//
// לפיכך אנו (והם) תקועים בצורך להשתמש בשיטה זו אשר גוררת צימוד הדוק עם ליבת הפוקסיה.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // אין לנו שום דרך לבדוק אם e_phoff ו-e_phnum תקפים.
    // libc צריכה להבטיח זאת עבורנו, אולם לכן ניתן ליצור פרוסה כאן.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr מייצג כותרת תוכנית ELF של 64 סיביות בסופו של דבר של ארכיטקטורת היעד.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr מייצג כותרת חוקית של תוכנית ELF ואת תוכנה.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // אין לנו דרך לבדוק אם p_addr או p_memsz תקפים.
    // ה-libc של פוקסיה מנתח את ההערות תחילה אולם מכוח היותם כאן הכותרות הללו חייבות להיות תקפות.
    //
    // הערה It אינו מחייב שהנתונים הבסיסיים יהיו תקפים אך הם דורשים שהגבולות יהיו תקפים.
    // אנו סומכים על כך ש libc הבטיחה שזה המקרה לגבינו כאן.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// סוג ההערה למזהי build.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr מייצג כותרת של פתק ELF בסיום המטרה.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// הערה מייצגת פתק ELF (כותרת + תוכן).
// השם נותר כפרוסת u8 מכיוון שהוא לא תמיד הופסק null ו-rust מקלה על הבדיקה שהבתים תואמים בכל מקרה.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter מאפשר לך לבצע איטרציה בטוחה מעל קטע פתק.
// זה מסתיים ברגע שמתרחשת שגיאה או שאין עוד הערות.
// אם אתה חוזר על נתונים לא חוקיים הוא יתפקד כאילו לא נמצאו הערות.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // זהו תפקוד משתנה שהמצביע והגודל שניתנו מציינים טווח בתים חוקי שניתן לקרוא את כולם.
    // התוכן של בתים אלה יכול להיות הכל אבל הטווח חייב להיות תקף כדי שזה יהיה בטוח.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to מיישר את 'x' ליישור 'to'-byte בהנחה ש-'to' הוא כוח של 2.
// זה עוקב אחר תבנית סטנדרטית בקוד ניתוח C/C ++ ELF שבו משתמשים ב-(x + to, 1) ו--to.
// Rust לא מאפשר לך לשלול את השימוש, אז אני משתמש
// המרה משלימה של 2 כדי ליצור מחדש את זה.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 צורכת מספר בתים מהפרוסה (אם קיימת) ומבטיחה בנוסף שהפרוסה הסופית מיושרת כהלכה.
// אם מספר הבתים המבוקש גדול מדי או שלא ניתן לבצע יישור מחדש של הנתח לאחר מכן מכיוון שלא קיימים מספיק בתים שנותרו, אף אחד אינו מוחזר והפרוסה לא שונתה.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// לפונקציה זו אין משתנים אמיתיים שהמתקשר צריך לשמור עליהם מלבד אולי ש-'bytes' צריך להיות מיושר לביצועים (ועל תקינות ארכיטקטורה מסוימת).
// הערכים בשדות Elf_Nhdr עשויים להיות שטויות אך פונקציה זו לא מבטיחה דבר כזה.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // זה בטוח כל עוד יש מספיק מקום ואנחנו רק אישרנו כי בהצהרת if למעלה אז זה לא אמור להיות לא בטוח.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // שים לב ש-sice_of: :<Elf_Nhdr>() מיושר תמיד עם 4 בתים.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // בדוק אם הגענו לסוף.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // אנו משדרים nhdr אך אנו שוקלים היטב את המבנה המתקבל.
        // אנחנו לא סומכים על namesz או descsz ואנחנו לא מקבלים שום החלטות לא בטוחות בהתבסס על הסוג.
        //
        // כך שגם אם נצא מאשפה מלאה עלינו עדיין להיות בטוחים.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// מציין שקטע ניתן להפעיל.
const PERM_X: u32 = 0b00000001;
/// מציין שקטע ניתן לכתוב.
const PERM_W: u32 = 0b00000010;
/// מציין שקטע ניתן לקריאה.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// מייצג קטע ELF בזמן הריצה.
struct Segment {
    /// נותן את הכתובת הווירטואלית בזמן ריצה של תוכן קטע זה.
    addr: usize,
    /// נותן את גודל הזיכרון של תוכן קטע זה.
    size: usize,
    /// נותן את הכתובת הווירטואלית של המודול של קטע זה עם קובץ ה-ELF.
    mod_rel_addr: usize,
    /// נותן את ההרשאות שנמצאו בקובץ ה-ELF.
    /// הרשאות אלה אינן בהכרח ההרשאות הקיימות בזמן הריצה.
    flags: Perm,
}

/// מאפשר אחד לחזור על פלחים מתוך DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// מייצג ELO DSO (Dynamic Shared Object).
/// סוג זה מתייחס לנתונים המאוחסנים ב-DSO בפועל ולא ליצור עותק משלו.
struct Dso<'a> {
    /// המקשר הדינמי תמיד נותן לנו שם, גם אם השם ריק.
    /// במקרה של ההפעלה הראשית השם הזה יהיה ריק.
    /// במקרה של אובייקט משותף זה יהיה שם הבן (ראה DT_SONAME).
    name: &'a str,
    /// בפוקסיה כמעט לכל הבינאריות יש מזהי בנייה אך זה לא דרישה קפדנית.
    /// אין שום דרך להתאים בין מידע DSO לקובץ ELF אמיתי לאחר מכן אם אין build_id ולכן אנו דורשים שלכל DSO יהיה כזה.
    ///
    /// DSO ללא build_id מתעלמים.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// מחזירה איטרטר על פלחים ב-DSO זה.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// שגיאות אלה מקודדות בעיות המתעוררות בזמן ניתוח מידע על כל DSO.
///
enum Error {
    /// פירוש NameError היא שהתרחשה שגיאה בעת המרת מחרוזת בסגנון C למחרוזת rust.
    ///
    NameError(core::str::Utf8Error),
    /// פירוש BuildIDError שלא מצאנו מזהה build.
    /// זה יכול להיות בגלל ש-DSO לא היה מזהה build או כי הקטע המכיל את מזהה build היה תקין.
    ///
    BuildIDError,
}

/// מתקשר ל-'dso' או 'error' עבור כל DSO המקושר לתהליך על ידי המקשר הדינמי.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter שתהיה לו אחת משיטות האכילה הנקראות foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr מבטיח ש-info.name יצביע על מיקום חוקי.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// פונקציה זו מדפיסה את סימון הסימונים של פוקסיה לכל המידע הכלול ב-DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}