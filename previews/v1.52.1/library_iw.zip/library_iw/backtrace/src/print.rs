#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// מעצב למעקב אחורי.
///
/// ניתן להשתמש בסוג זה להדפסת מעקב אחורי ללא קשר למקום ממנו מגיע המסלול האחורי עצמו.
/// אם יש לך סוג `Backtrace` אז הטמעת ה-`Debug` שלו כבר משתמשת בפורמט הדפסה זה.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// סגנונות ההדפסה שנוכל להדפיס
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// מדפיס מעקב אחורני של טרסר שמכיל באופן אידיאלי רק מידע רלוונטי
    Short,
    /// מדפיס מעקב אחורי המכיל את כל המידע האפשרי
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// צור `BacktraceFmt` חדש אשר יכתוב פלט ל-`fmt` שסופק.
    ///
    /// הארגומנט `format` ישלוט בסגנון בו מודפסת העקיבה האחורית, והארגומנט `print_path` ישמש להדפסת המופעים `BytesOrWideString` של שמות קבצים.
    /// סוג זה עצמו אינו מבצע הדפסה של שמות קבצים, אך נדרש להתקשרות חוזרת זו לשם כך.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// מדפיס הקדמה למסלול האחורי העומד להדפסה.
    ///
    /// זה נדרש בכמה פלטפורמות כדי לסמן באופן מלא אחר עקבות אחורה, אחרת זו צריכה להיות השיטה הראשונה שאתה קורא לה לאחר יצירת `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// מוסיף מסגרת לפלט העקיבה.
    ///
    /// התחייבות זו מחזירה מופע RAII של `BacktraceFrameFmt` שבאמצעותו ניתן להדפיס מסגרת בפועל, ובהרס זה יגדיל את מונה המסגרת.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// משלים את פלט העקיבה.
    ///
    /// כרגע זה אינו פעיל אך הוא מתווסף לתאימות future לפורמטים לאחור.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // נכון לעכשיו אין אפשרות-כולל hook זה כדי לאפשר תוספות של future.
        Ok(())
    }
}

/// מעצב למסגרת אחת בלבד של מעקב אחורי.
///
/// סוג זה נוצר על ידי פונקציית `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// מדפיס `BacktraceFrame` עם מעצב מסגרת זה.
    ///
    /// פעולה זו תדפיס רקורסיבית את כל המופעים של `BacktraceSymbol` בתוך ה-`BacktraceFrame`.
    ///
    /// # תכונות נדרשות
    ///
    /// פונקציה זו מחייבת את תכונת `std` של `backtrace` crate כדי להיות מופעלת, ותכונת `std` מופעלת כברירת מחדל.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// מדפיס `BacktraceSymbol` בתוך `BacktraceFrame`.
    ///
    /// # תכונות נדרשות
    ///
    /// פונקציה זו מחייבת את תכונת `std` של `backtrace` crate כדי להיות מופעלת, ותכונת `std` מופעלת כברירת מחדל.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: זה לא נהדר שבסופו של דבר לא נדפיס שום דבר
            // עם שמות קבצים שאינם utf8.
            // למרבה המזל כמעט הכל הוא utf8 ולכן זה לא צריך להיות חבל מדי.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// מדפיס `Frame` ו-`Symbol` גולמי, בדרך כלל מתוך הקורבקים הגולמיים של crate זה.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// מוסיף מסגרת גולמית לפלט העקיבה.
    ///
    /// שיטה זו, בניגוד לקודמת, לוקחת את הטיעונים הגולמיים למקרה שמקורם ממקומות שונים.
    /// שים לב שניתן לקרוא לזה מספר פעמים למסגרת אחת.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// מוסיף מסגרת גולמית לפלט העקיבה, כולל מידע על העמודות.
    ///
    /// שיטה זו, כמו הקודמת, לוקחת את הטיעונים הגולמיים למקרה שהם מקור ממקומות שונים.
    /// שים לב שניתן לקרוא לזה מספר פעמים למסגרת אחת.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // פוקסיה לא מצליחה לסמל בתהליך ולכן יש לה פורמט מיוחד שניתן להשתמש בו כדי לסמל מאוחר יותר.
        // הדפס את זה במקום להדפיס כתובות בפורמט שלנו כאן.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // אין צורך להדפיס מסגרות "null", זה בעצם רק אומר שהמעקב לאחור של המערכת היה קצת להוט להתחקות אחורה.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // כדי להקטין את גודל ה-TCB במובלעת Sgx, איננו רוצים ליישם פונקציונליות של רזולוציית סמלים.
        // במקום זאת, אנו יכולים להדפיס כאן את קיזוז הכתובת, שניתן יהיה למפות אחר כך לתפקוד נכון.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // הדפס את אינדקס המסגרת וכן את מצביע ההוראות האופציונלי של המסגרת.
        // אם אנחנו מעבר לסמל הראשון של מסגרת זו, אנחנו פשוט מדפיסים מרחב לבן מתאים.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // לאחר מכן כתוב את שם הסמל, בעזרת העיצוב החלופי לקבלת מידע נוסף אם אנו מעקב אחורי מלא.
        // כאן אנו מטפלים גם בסמלים שאין להם שם,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // ולבסוף, הדפיס את מספר filename/line אם הוא זמין.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line מודפסים על קווים תחת שם הסמל, אז הדפיסו מרחב לבן מתאים בכדי ליישר את עצמנו נכון.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // נצל להתקשרות החזרה הפנימית שלנו כדי להדפיס את שם הקובץ ואז להדפיס את מספר השורה.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // הוסף מספר עמודה, אם זמין.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // אכפת לנו רק מהסמל הראשון של מסגרת
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}