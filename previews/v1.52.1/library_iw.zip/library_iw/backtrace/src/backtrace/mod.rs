use core::ffi::c_void;
use core::fmt;

/// בודק את ערימת השיחה הנוכחית, ומעביר את כל המסגרות הפעילות לסגירה הניתנת לחישוב מעקב אחר מחסנית.
///
/// פונקציה זו היא סוס העבודה של ספרייה זו בחישוב עקבות הערימה לתוכנית.הסגירה `cb` הנתונה היא מופעים של `Frame` המייצגים מידע על אותה מסגרת שיחה בערימה.
/// הסגירה מוצגת מסגרות מלמעלה למטה (לאחרונה נקרא פונקציות ראשונות).
///
/// ערך ההחזר של הסגירה מהווה אינדיקציה לשאלה אם יש להמשיך במעקב האחורי.ערך החזר של `false` יפסיק את המסלול האחורי ויחזור מיד.
///
/// לאחר רכישת `Frame` סביר להניח שתרצה להתקשר ל-`backtrace::resolve` כדי להמיר את `ip` (מצביע הוראות) או כתובת הסמל ל-`Symbol` שדרכו ניתן ללמוד את השם ו/או שם הקובץ/מספר השורה.
///
///
/// שים לב שזו פונקציה ברמה נמוכה יחסית ואם תרצה, למשל, לתפוס מעקב אחורי כדי להיבדק מאוחר יותר, ייתכן שסוג ה-`Backtrace` יתאים יותר.
///
/// # תכונות נדרשות
///
/// פונקציה זו מחייבת את תכונת `std` של `backtrace` crate כדי להיות מופעלת, ותכונת `std` מופעלת כברירת מחדל.
///
/// # Panics
///
/// פונקציה זו שואפת לעולם לא panic, אך אם ה-`cb` סיפק panics אז יש פלטפורמות שיאלצו panic כפול לבטל את התהליך.
/// פלטפורמות מסוימות משתמשות בספריית C המשתמשת באופן פנימי בשיחות חוזרות שלא ניתן לפרק אותן, ולכן פאניקה מ-`cb` עשויה לגרום להפסקת תהליך.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // המשך במסלול האחורי
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// זהה ל-`trace`, רק לא בטוח מכיוון שהוא לא מסונכרן.
///
/// לפונקציה זו אין ערבי סינכרון, אך היא זמינה כאשר תכונת `std` של crate זו אינה מורכבת.
/// עיין בפונקציה `trace` לקבלת תיעוד ודוגמאות נוספות.
///
/// # Panics
///
/// ראה מידע על `trace` לקבלת אזהרות על `cb` בהלה.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait המייצג מסגרת אחת של מעקב אחורי, נכנע לפונקציה `trace` של crate זה.
///
/// סגירת פונקציית המעקב תוצג מסגרות, והמסגרת נשלחת כמעט מכיוון שהיישום הבסיסי לא תמיד ידוע עד זמן הריצה.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// מחזיר את מצביע ההוראות הנוכחי של מסגרת זו.
    ///
    /// זו בדרך כלל ההוראה הבאה לבצע במסגרת, אך לא כל היישומים מפרטים את זה בדיוק של 100% (אבל זה בדרך כלל די קרוב).
    ///
    ///
    /// מומלץ להעביר ערך זה ל-`backtrace::resolve` כדי להפוך אותו לשם סמל.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// מחזיר את מצביע הערימה הנוכחי של מסגרת זו.
    ///
    /// במקרה ש-backend לא יכול לשחזר את מצביע הערימה למסגרת זו, מחזירים מצביע null.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// מחזירה את כתובת הסמל ההתחלתי של המסגרת של פונקציה זו.
    ///
    /// זה ינסה לאחזר את מצביע ההוראות שהוחזר על ידי `ip` לתחילת הפונקציה, ולהחזיר ערך זה.
    ///
    /// עם זאת, במקרים מסוימים, גיבויים רק יחזירו את `ip` מהפונקציה הזו.
    ///
    /// לעתים ניתן להשתמש בערך המוחזר אם `backtrace::resolve` נכשל ב-`ip` שניתן לעיל.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// מחזירה את כתובת הבסיס של המודול אליו המסגרת שייכת.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // זה צריך לבוא במקום הראשון, כדי להבטיח שמירי תקבל עדיפות על פלטפורמת המארח
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // משמש רק ב-dbghelp מסמל
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}