`core::arch` - הפנימיות הספציפית לארכיטקטורה של Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

מודול `core::arch` מיישם פנימיות תלויי אדריכלות (למשל SIMD).

# Usage 

`core::arch` זמין כחלק מ-`libcore` והוא מיוצא מחדש על ידי `libstd`.העדיף להשתמש בו באמצעות `core::arch` או `std::arch` מאשר באמצעות crate זה.
תכונות לא יציבות זמינות לעיתים קרובות ב-Rust מדי לילה דרך ה-`feature(stdsimd)`.

שימוש ב-`core::arch` באמצעות crate זה דורש Rust לילי, והוא יכול (וגם עושה) להישבר לעיתים קרובות.המקרים היחידים שבהם כדאי לך לשקול להשתמש בו באמצעות crate הם:

* אם אתה צריך לאסוף מחדש את `core::arch` בעצמך, למשל, עם תכונות יעד מסוימות מופעלות שאינן מופעלות עבור `libcore`/`libstd`.
Note: אם אתה צריך לאסוף אותו מחדש למטרה לא סטנדרטית, אנא העדיף להשתמש ב-`xargo` ולהרכיב מחדש את ה-`libcore`/`libstd` לפי הצורך במקום להשתמש ב-crate.
  
* שימוש בתכונות מסוימות שאולי לא יהיו זמינות גם מאחורי תכונות Rust לא יציבות.אנו מנסים למזער אותם.
אם אתה צריך להשתמש בחלק מהתכונות הללו, אנא פתח בעיה בכדי שנוכל לחשוף אותן ב-Rust מדי לילה ותוכל להשתמש בהן משם.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` מופץ בעיקר תחת תנאי רישיון MIT ורישיון Apache (גרסה 2.0), כאשר חלקים מכוסים ברישיונות דמויי BSD שונים.

ראה LICENSE-APACHE ו-LICENSE-MIT לפרטים.

# Contribution

אלא אם כן אתה מצהיר אחרת במפורש, כל תרומה שהוגשה בכוונה להכללה ב-`core_arch` על ידך, כהגדרתה ברישיון Apache-2.0, תהיה ברישיון כפול כאמור לעיל, ללא תנאים או תנאים נוספים.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












