# תורם ל-stdarch

ה-`stdarch` crate מוכן לקבל תרומות!ראשית סביר להניח שתרצה לבדוק את המאגר ולוודא שהבדיקות עוברות עבורך:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

כאשר `<your-target-arch>` הוא משולש היעד המשמש את `rustup`, למשל `x86_x64-unknown-linux-gnu` (ללא כל `nightly-` קודם או דומה).
זכרו גם כי מאגר זה דורש את הערוץ הלילי של Rust!
הבדיקות שלעיל אכן מחייבות את rust הלילית להיות ברירת המחדל במערכת שלך, כדי להגדיר את השימוש ב-`rustup default nightly` (ו-`rustup default stable` כדי לחזור).

אם אחד מהשלבים שלעיל לא עובד, [please let us know][new]!

בשלב הבא תוכלו להיעזר ב-[find an issue][issues], בחרנו כמה מהם עם התגים [`help wanted`][help] ו-[`impl-period`][impl] שיכולים להשתמש במיוחד בעזרה. 
יתכן שאתה מעוניין ביותר ב-[#40][vendor], ומיישם את כל מהותי הספקים ב-x86.לסוגיה הזו יש כמה עצות טובות לגבי היכן להתחיל!

אם יש לך שאלות כלליות אל תהסס ל-[join us on gitter][gitter] ותשאל מסביב!אל תהסס לפינג עם@BurntSushi או@alexcrichton עם שאלות.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# כיצד לכתוב דוגמאות לפנימיות סטדארך

יש כמה תכונות שיש לאפשר כדי שהפנימיות הנתונה תפעל כראוי, והדוגמה חייבת להיות מופעלת רק על ידי `cargo test --doc` כאשר התכונה נתמכת על ידי המעבד.

כתוצאה מכך, ברירת המחדל של `fn main` שנוצרת על ידי `rustdoc` לא תפעל (ברוב המקרים).
שקול להשתמש במדריך הבא כדי להבטיח שהדוגמה שלך פועלת כצפוי.

```rust
/// # // אנחנו צריכים cfg_target_feature כדי להבטיח שהדוגמה תהיה בלבד
/// # // מופעל על ידי `cargo test --doc` כאשר המעבד תומך בתכונה
/// # #![feature(cfg_target_feature)]
/// # // אנו זקוקים למיקוד_התכונה כדי שהפנימיות תעבוד
/// # #![feature(target_feature)]
/// #
/// # // Rustdoc כברירת מחדל משתמש ב-`extern crate stdarch`, אך אנו זקוקים ל-
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // הפונקציה העיקרית האמיתית
/// # fn main() {
/// #     // הפעל זאת רק אם `<target feature>` נתמך
/// #     אם cfg_feature_enabled! ("<target feature>"){
/// #         // צור פונקציה `worker` שתופעל רק אם תכונת היעד
/// #         // נתמך וודא שה-`target_feature` מופעל עבור העובד שלך
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         לא בטוח ב-worker() {
/// // כתוב את הדוגמה שלך כאן.תכונות ספציפיות לתכונות יעבדו כאן!תתפרע!
///
/// #         }
///
/// #         { worker(); } לא בטוח
/// #     }
/// # }
```

אם חלק מהתחביר לעיל לא נראה מוכר, החלק [Documentation as tests] של ה-[Rust Book] מתאר את התחביר `rustdoc` די טוב.
כמו תמיד, אל תהסס להיכנס ל-[join us on gitter][gitter] ולשאול אותנו אם אתה מכה באיזה תפס, ותודה שעזרת בשיפור התיעוד של `stdarch`!

# הוראות בדיקה חלופיות

בדרך כלל מומלץ להשתמש ב-`ci/run.sh` להפעלת הבדיקות.
עם זאת, יתכן שזה לא יעבוד עבורך, למשל אם אתה נמצא ב-Windows.

במקרה כזה תוכל לחזור ולהפעיל את `cargo +nightly test` ו-`cargo +nightly test --release -p core_arch` לבדיקת יצירת הקוד.
שים לב כי אלה דורשים התקנת שרשרת הכלים הלילית וכדי ש-`rustc` ידע על משולש היעד שלך ועל המעבד שלו.
בפרט עליך להגדיר את משתנה הסביבה `TARGET` כפי שהיית עושה לגבי `ci/run.sh`.
בנוסף עליך להגדיר `RUSTCFLAGS` (זקוק ל-`C`) כדי לציין תכונות יעד, למשל `RUSTCFLAGS="-C -target-features=+avx2"`.
אתה יכול גם להגדיר `-C -target-cpu=native` אם אתה "just" מתפתח מול המעבד הנוכחי שלך.

היזהר כי כאשר אתה משתמש בהוראות חלופיות אלה, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], למשל
מבחני הפקת הוראות עשויים להיכשל מכיוון שהפרק שם אותם אחרת, למשל
זה עשוי ליצור `vaesenc` במקום הוראות `aesenc` למרות שהם מתנהגים כך.
כמו כן, הוראות אלה מבצעות פחות בדיקות ממה שבדרך כלל היה נעשה, לכן אל תתפלא שכאשר בסופו של דבר תבקש משיכה עלולות להופיע שגיאות בבדיקות שלא נכללו כאן.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






