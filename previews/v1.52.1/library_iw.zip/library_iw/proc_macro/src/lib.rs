//! ספריית תמיכה למחברי מאקרו בעת הגדרת פקודות מאקרו חדשות.
//!
//! ספרייה זו, המסופקת על ידי ההפצה הסטנדרטית, מספקת את הסוגים הנצרכים בממשקים של הגדרות מאקרו המוגדרות פרוצדוראלית כגון פקודות מאקרו דמויות פונקציה `#[proc_macro]`, מאפייני מאקרו `#[proc_macro_attribute]` ותכונות נגזרות מותאמות אישית '#[proc_macro_derive] `.
//!
//!
//! ראה [the book] לקבלת מידע נוסף.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// קובע אם proc_macro הונגש לתוכנית הפועלת כעת.
///
/// Proc_macro crate מיועד רק לשימוש ביישום של פקודות מאקרו פרוצדורליות.כל הפונקציות ב-crate panic אם מופעלות מחוץ למקרו פרוצדורלי, כמו למשל מתסריט build או מבחן יחידה או בינארי Rust רגיל.
///
/// תוך התחשבות בספריות Rust אשר נועדו לתמוך במקרי שימוש במקרו וגם במקרים שאינם מאקרו, `proc_macro::is_available()` מספק דרך שאינה נבהלת לזהות האם התשתית הנדרשת לשימוש בממשק ה-API של proc_macro זמינה כיום.
/// מחזיר נכון אם מופעל מבפנים ממקרו פרוצדורלי, שקר אם מופעל מכל סוג בינארי אחר.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// הסוג העיקרי המסופק על ידי crate זה, המייצג זרם מופשט של tokens, או ליתר דיוק, רצף של עצים token.
/// הסוג מספק ממשקים לאיתור מעל אותם עצי token, ולהיפך, איסוף מספר עצי token לזרם אחד.
///
///
/// זהו גם הקלט והפלט של הגדרות `#[proc_macro]`, `#[proc_macro_attribute]` ו-`#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// שגיאה שהוחזרה מ-`TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// מחזירה `TokenStream` ריק שאינו מכיל עצים token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// בודק אם `TokenStream` זה ריק.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// מנסה לפרוץ את המחרוזת ל-tokens ולנתח את ה-tokens לזרם token.
/// עלול להיכשל ממספר סיבות, למשל, אם המחרוזת מכילה תווים או איזון לא מאוזן שאינם קיימים בשפה.
///
/// כל tokens בזרם המנותח מקבלים טווחי `Span::call_site()`.
///
/// NOTE: שגיאות מסוימות עלולות לגרום panics במקום להחזיר `LexError`.אנו שומרים לעצמנו את הזכות לשנות שגיאות אלה ל-`LexError` מאוחר יותר.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// הערה, הגשר מספק רק `to_string`, מיישם את `fmt::Display` על בסיס זה (ההפך מהיחסים הרגילים בין השניים).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// מדפיס את זרם token כמחרוזת שאמורה להיות ניתנת להמרה ללא הפסד לאותו זרם token (משתרע על מודולו), למעט אולי 'TokenTree: : Group' עם מפרידי `Delimiter::None` ומילים ספרותיות שליליות.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// מדפיס את token בצורה נוחה לאיתור באגים.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// יוצר זרם token המכיל עץ token יחיד.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// אוסף מספר עצי token לזרם יחיד.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// פעולת "flattening" בזרמי token, אוספת עצים token ממספר זרמי token לזרם יחיד.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) השתמש בהטמעה אופטימלית if/when אפשרית.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// פרטי יישום ציבוריים מסוג `TokenStream`, כגון איטרורים.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// איטרטור על "TokenStream" של "TokenStream".
    /// האיטרציה היא "shallow", למשל, האיטרטור לא חוזר לקבוצות תוחמות ומחזיר קבוצות שלמות כעצי token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` מקבל tokens שרירותי ומתרחב ל-`TokenStream` המתאר את הקלט.
/// לדוגמה, `quote!(a + b)` ייצור ביטוי, שכאשר הוא מוערך, בונה את `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// ביטול הציטוט נעשה עם `$`, ועובד על ידי לקיחת המזהה הבא היחיד כמונח שאינו מצוטט.
/// לצטט את `$` עצמו, השתמש ב-`$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// אזור של קוד מקור, יחד עם מידע על הרחבת מאקרו.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// יוצר `Diagnostic` חדש עם ה-`message` הנתון בטווח `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// טווח שנפתר באתר הגדרת המאקרו.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// טווח ההפעלה של המאקרו הפרוצדורלי הנוכחי.
    /// מזהים שנוצרו עם טווח זה יפתרו כאילו נכתבו ישירות במיקום של שיחת מאקרו (היגיינת אתר שיחה) וקוד אחר באתר שיחת מאקרו יוכל להתייחס גם אליהם.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// טווח המייצג היגיינה של `macro_rules`, ולעיתים נפתר באתר הגדרת המאקרו (משתנים מקומיים, תוויות, `$crate`) ולעיתים באתר שיחת מאקרו (כל השאר).
    ///
    /// מיקום הטווח נלקח מאתר השיחה.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// קובץ המקור המקורי שאליו מכוון טווח זה.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// ה-`Span` עבור ה-tokens בהרחבת המאקרו הקודמת שממנה נוצר `self`, אם בכלל.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// טווח קוד המקור שממנו נוצר `self`.
    /// אם `Span` זה לא נוצר מהרחבות מאקרו אחרות, ערך ההחזר זהה ל-`*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// מקבל את line/column ההתחלתי בקובץ המקור לטווח זה.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// מקבל את הסיום line/column בקובץ המקור לטווח זה.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// יוצר טווח חדש המקיף את `self` ו-`other`.
    ///
    /// מחזירה `None` אם `self` ו-`other` הם מקבצים שונים.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// יוצר טווח חדש עם אותו מידע line/column כמו `self` אך פותר סמלים כאילו היה ב-`other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// יוצר טווח חדש עם אותה התנהגות ברזולוציית שם כמו `self` אך עם המידע line/column של `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// משווה לטווחים כדי לראות אם הם שווים.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// מחזיר את טקסט המקור מאחורי טווח.
    /// זה שומר על קוד המקור המקורי, כולל רווחים והערות.
    /// היא מחזירה תוצאה רק אם הטווח תואם לקוד המקור האמיתי.
    ///
    /// Note: התוצאה הנצפית של מאקרו צריכה להסתמך רק על tokens ולא על טקסט המקור הזה.
    ///
    /// התוצאה של פונקציה זו היא המאמץ הטוב ביותר לשמש לאבחון בלבד.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// מדפיס טווח טופס נוח לאיתור באגים.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// זוג עמודות קו המייצג את ההתחלה או הסוף של `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// השורה האינדקסית 1 בקובץ המקור עליו מתחילה או מסתיימת (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// העמודה 0 באינדקס (בתווי UTF-8) בקובץ המקור שעליו מתחיל או מסתיים ה-(inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// קובץ המקור של `Span` נתון.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// מקבל את הנתיב לקובץ המקור הזה.
    ///
    /// ### Note
    /// אם טווח הקודים המשויך ל-`SourceFile` זה נוצר על ידי מאקרו חיצוני, מאקרו זה, יתכן שזה אינו נתיב ממשי במערכת הקבצים.
    /// השתמש ב-[`is_real`] כדי לבדוק.
    ///
    /// כמו כן, שים לב שגם אם `is_real` מחזיר את `true`, אם `--remap-path-prefix` הועבר בשורת הפקודה, הנתיב כפי שניתן עשוי לא ממש תקף.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// מחזירה `true` אם קובץ מקור זה הוא קובץ מקור אמיתי, ולא נוצר על ידי הרחבת מאקרו חיצוני.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // זהו פריצה עד ליישומי טווחי בין-ערכיים ויכולים להיות לנו קבצי מקור אמיתיים לטווחים שנוצרו במקרואים חיצוניים.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// token יחיד או רצף תוחם של token עצים (למשל, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// זרם token המוקף במתחמי סוגריים.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// מזהה.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// תו פיסוק יחיד (`+`, `,`, `$` וכו ').
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// דמות מילולית (`'a'`), מחרוזת (`"hello"`), מספר (`2.3`) וכו '.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// מחזירה את טווח העץ הזה, מאצילה לשיטת `span` של ה-token הכלול או זרם מופרד.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// מגדיר את הטווח עבור *רק token* זה.
    ///
    /// שים לב שאם token זה `Group` אז שיטה זו לא תגדיר את הטווח של כל אחד מה-tokens הפנימיים, זה פשוט יועבר לשיטת `set_span` של כל גרסה.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// מדפיס עץ token בצורה נוחה לאיתור באגים.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // לכל אחד מאלה יש את השם בסוג ה-struct בבאגים הנגזרים, אז אל תטרחו עם שכבה נוספת של כיוון
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// הערה, הגשר מספק רק `to_string`, מיישם את `fmt::Display` על בסיס זה (ההפך מהיחסים הרגילים בין השניים).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// מדפיס את עץ token כמחרוזת שאמורה להיות ניתנת להמרה ללא הפסד לאותו עץ token (משתרע על מודולו), למעט אולי "TokenTree: : Group" עם תווי `Delimiter::None` ותווי ספרות שליליים.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// זרם token תוחם.
///
/// `Group` מכיל באופן פנימי `TokenStream` המוקף במפריד.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// מתאר כיצד תוחם רצף של עצי token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// תיחום מרומז, שעשוי, למשל, להופיע סביב tokens שמגיע מ-"macro variable" `$var`.
    /// חשוב לשמור על סדרי עדיפויות של מפעילים במקרים כמו `$var * 3` כאשר `$var` הוא `1 + 2`.
    /// תוחמים מרומזים עשויים שלא לשרוד הלוך ושוב של זרם token דרך מחרוזת.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// יוצר `Group` חדש עם המפריד הנתון וזרם token.
    ///
    /// קונסטרוקטור זה יגדיר את טווח הקבוצה `Span::call_site()`.
    /// כדי לשנות את הטווח תוכלו להשתמש בשיטת `set_span` להלן.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// מחזיר את התיחום של `Group` זה
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// מחזירה את ה-`TokenStream` של tokens שתוחמו ב-`Group` זה.
    ///
    /// שים לב שזרם ה-token שהוחזר אינו כולל את המפריד שהוחזר לעיל.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// מחזירה את טווח התיחומים של זרם token זה, המשתרע על כל `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// מחזיר את הטווח המצביע על תוחם הפתיחה של קבוצה זו.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// מחזירה את הטווח המצביע על תוחם הסגירה של קבוצה זו.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// מגדיר את טווח התיחומים של קבוצה זו, אך לא tokens הפנימי שלה.
    ///
    /// שיטה זו **לא** תקבע את הטווח של כל ה-tokens הפנימיים המשתרעת על ידי קבוצה זו, אלא היא תקבע את טווח ההפרדה של tokens רק ברמת ה-`Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// הערה, הגשר מספק רק `to_string`, מיישם את `fmt::Display` על בסיס זה (ההפך מהיחסים הרגילים בין השניים).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// מדפיס את הקבוצה כמחרוזת שאמורה להיות ניתנת להמרה חזרה לאובדן לאותה קבוצה (טווחי מודולו), למעט ייתכן ש-'TokenTree: : Group' עם מפרידי `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` הוא תו פיסוק יחיד כמו `+`, `-` או `#`.
///
/// אופרטורים מרובי תווים כמו `+=` מיוצגים כשני מופעים של `Punct` עם צורות שונות של `Spacing` שהוחזרו.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// בין אם אחרי `Punct` ואחריו `Punct` אחר או אחריו token אחר או רווח לבן.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// למשל, `+` הוא `Alone` ב-`+ =`, `+ident` או `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// למשל, `+` הוא `Joint` ב-`+=` או `'#`.
    /// בנוסף, הצעת מחיר יחידה `'` יכולה להצטרף למזהים כדי ליצור `'ident` לכל אורך החיים.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// יוצר `Punct` חדש מהתו והריווח הנתון.
    /// הטיעון `ch` חייב להיות תו פיסוק חוקי המותר על ידי השפה, אחרת הפונקציה תהיה panic.
    ///
    /// ל-`Punct` שהוחזר יהיה טווח ברירת המחדל של `Span::call_site()` שניתן להגדיר עוד יותר בעזרת שיטת `set_span` להלן.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// מחזירה את הערך של תו פיסוק זה כ-`char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// מחזיר את הריווח של תו פיסוק זה, ומציין אם אחריו מיד `Punct` אחר בזרם token, כך שניתן לשלב אותם למפעיל רב-תווים (`Joint`), או אחריו token אחר או רווח לבן (`Alone`) כך שלמפעיל יש בהחלט הסתיים.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// מחזירה את טווח התווים עבור פיסוק זה.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// הגדר את טווח התווים עבור פיסוק זה.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// הערה, הגשר מספק רק `to_string`, מיישם את `fmt::Display` על בסיס זה (ההפך מהיחסים הרגילים בין השניים).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// מדפיס את תו הפיסוק כמחרוזת שצריכה להיות ניתנת להמרה ללא הפסד לאותה תו.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// מזהה (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// יוצר `Ident` חדש עם ה-`string` הנתון וכן ה-`span` שצוין.
    /// הארגומנט `string` חייב להיות מזהה חוקי המותר על ידי השפה (כולל מילות מפתח, למשל `self` או `fn`).אחרת, הפונקציה תהיה panic.
    ///
    /// שים לב ש-`span`, הנמצא כעת ב-rustc, מגדיר את פרטי ההיגיינה עבור מזהה זה.
    ///
    /// נכון לשעה זו `Span::call_site()` מצטרף במפורש להיגיינה "call-site" כלומר, מזהים שנוצרו עם טווח זה ייפתרו כאילו נכתבו ישירות במיקום שיחת המאקרו, וקוד אחר באתר שיחת המאקרו יוכל להתייחס ל גם אותם.
    ///
    ///
    /// טווחים מאוחרים יותר כמו `Span::def_site()` יאפשרו להצטרף להיגיינה "definition-site" כלומר המזהים שנוצרו עם טווח זה ייפתרו במיקום הגדרת המאקרו וקוד אחר באתר שיחת המאקרו לא יוכל להתייחס אליהם.
    ///
    /// בשל החשיבות הנוכחית של היגיינה, קונסטרוקטור זה, בניגוד ל-tokens אחרים, דורש ציון `Span` בבנייה.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// זהה ל-`Ident::new`, אך יוצר מזהה גולמי (`r#ident`).
    /// הטיעון `string` הוא מזהה חוקי המותר על ידי השפה (כולל מילות מפתח, למשל `fn`).
    /// מילות מפתח הניתנות לשימוש בפלחי נתיב (למשל
    /// `self`, 'סופר') אינם נתמכים ויגרמו ל-panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// מחזירה את הטווח של `Ident` זה, המקיף את כל המחרוזת שהוחזרה על ידי [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// מגדיר את טווח ה-`Ident` הזה, ואולי משנה את הקשר ההיגיינה שלו.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// הערה, הגשר מספק רק `to_string`, מיישם את `fmt::Display` על בסיס זה (ההפך מהיחסים הרגילים בין השניים).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// מדפיס את המזהה כמחרוזת שאמורה להיות ניתנת להמרה ללא הפסד לאותו מזהה.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// מחרוזת מילולית (`"hello"`), מחרוזת בתים (`b"hello"`), תו (`'a'`), תו בתים (`b'a'`), מספר שלם או נקודה צפה עם או בלי סיומת ('1', `1u8`, `2.3`, `2.3f32`).
///
/// מילוליות בוליאניות כמו `true` ו-`false` אינן שייכות לכאן, הן `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// יוצר מילול שלם סיומת מילולי חדש עם הערך שצוין.
        ///
        /// פונקציה זו תיצור מספר שלם כמו `1u32` כאשר ערך המספר השלם שצוין הוא החלק הראשון של ה-token והאינטגרל גם הוא מסופק בסוף.
        /// ספרות שנוצרו ממספרים שליליים עשויות שלא לשרוד הלוך ושוב דרך `TokenStream` או מחרוזות והן עשויות להיות מחולקות לשני tokens (`-` ומילולי חיובי).
        ///
        ///
        /// לספרות שנוצרו באמצעות שיטה זו יש טווח `Span::call_site()` כברירת מחדל, שניתן להגדיר אותה בשיטת `set_span` להלן.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// יוצר מספר מילולי שלם חדש שאינו מתוקן עם הערך שצוין.
        ///
        /// פונקציה זו תיצור מספר שלם כמו `1` כאשר ערך המספר השלם שצוין הוא החלק הראשון של ה-token.
        /// לא מוגדר סיומת ב-token זה, כלומר קריאות כמו `Literal::i8_unsuffixed(1)` שוות ערך ל-`Literal::u32_unsuffixed(1)`.
        /// ספרות שנוצרו ממספרים שליליים עשויות שלא לשרוד ריבוטים דרך `TokenStream` או מחרוזות ועלולות להישבר לשני tokens (`-` ומילולי חיובי).
        ///
        ///
        /// לספרות שנוצרו באמצעות שיטה זו יש טווח `Span::call_site()` כברירת מחדל, שניתן להגדיר אותה בשיטת `set_span` להלן.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// יוצר מילולית נקודה צפה חדשה שלא נקבעה.
    ///
    /// קונסטרוקטור זה דומה לאלה כמו `Literal::i8_unsuffixed`, כאשר ערך הצף נפלט ישירות ל-token אך לא משתמשים בסיומת, כך שניתן להסיק שהוא `f64` מאוחר יותר במהדר.
    ///
    /// ספרות שנוצרו ממספרים שליליים עשויות שלא לשרוד ריבוטים דרך `TokenStream` או מחרוזות ועלולות להישבר לשני tokens (`-` ומילולי חיובי).
    ///
    /// # Panics
    ///
    /// פונקציה זו מחייבת כי המצוף שצוין יהיה סופי, למשל אם הוא אינסוף או NaN פונקציה זו תהיה panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// יוצר מילולית נקודה צפה סיומת חדשה.
    ///
    /// קונסטרוקטור זה ייצור מילולי כמו `1.0f32` כאשר הערך שצוין הוא החלק הקודם של token ו-`f32` הוא הסיומת של token.
    /// token זה תמיד יוסמך להיות `f32` במהדר.
    /// ספרות שנוצרו ממספרים שליליים עשויות שלא לשרוד ריבוטים דרך `TokenStream` או מחרוזות ועלולות להישבר לשני tokens (`-` ומילולי חיובי).
    ///
    ///
    /// # Panics
    ///
    /// פונקציה זו מחייבת כי המצוף שצוין יהיה סופי, למשל אם הוא אינסוף או NaN פונקציה זו תהיה panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// יוצר מילולית נקודה צפה חדשה שלא נקבעה.
    ///
    /// קונסטרוקטור זה דומה לאלה כמו `Literal::i8_unsuffixed`, כאשר ערך הצף נפלט ישירות ל-token אך לא משתמשים בסיומת, כך שניתן להסיק שהוא `f64` מאוחר יותר במהדר.
    ///
    /// ספרות שנוצרו ממספרים שליליים עשויות שלא לשרוד ריבוטים דרך `TokenStream` או מחרוזות ועלולות להישבר לשני tokens (`-` ומילולי חיובי).
    ///
    /// # Panics
    ///
    /// פונקציה זו מחייבת כי המצוף שצוין יהיה סופי, למשל אם הוא אינסוף או NaN פונקציה זו תהיה panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// יוצר מילולית נקודה צפה סיומת חדשה.
    ///
    /// קונסטרוקטור זה ייצור מילולי כמו `1.0f64` כאשר הערך שצוין הוא החלק הקודם של token ו-`f64` הוא הסיומת של token.
    /// token זה תמיד יוסמך להיות `f64` במהדר.
    /// ספרות שנוצרו ממספרים שליליים עשויות שלא לשרוד ריבוטים דרך `TokenStream` או מחרוזות ועלולות להישבר לשני tokens (`-` ומילולי חיובי).
    ///
    ///
    /// # Panics
    ///
    /// פונקציה זו מחייבת כי המצוף שצוין יהיה סופי, למשל אם הוא אינסוף או NaN פונקציה זו תהיה panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// מחרוזת מילולית.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// אופי מילולי.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// מחרוזת בתים מילולית.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// מחזיר את הטווח המקיף את המילולי הזה.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// מגדיר את הטווח המשויך למילולי זה.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// מחזירה `Span` שהיא קבוצת משנה של `self.span()` המכילה רק את בתים המקוריים בטווח `range`.
    /// מחזירה `None` אם תוחלת הגזירה תהיה מחוץ לתחום ה-`self`.
    ///
    // FIXME(SergioBenitez): בדוק שטווח הבתים מתחיל ומסתיים בגבול UTF-8 של המקור.
    // אחרת, סביר להניח ש-panic יתרחש במקומות אחרים כאשר טקסט המקור מודפס.
    // FIXME(SergioBenitez): אין שום דרך שהמשתמש יידע מה באמת `self.span()` ממפה, ולכן ניתן לקרוא לשיטה זו כרגע רק בעיוורון.
    // לדוגמא, `to_string()` עבור הדמות 'c' מחזיר "'\u{63}'";אין שום דרך שהמשתמש ידע אם טקסט המקור היה 'c' או שמדובר ב-'\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) משהו הדומה ל-`Option::cloned`, אבל ל-`Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// הערה, הגשר מספק רק `to_string`, מיישם את `fmt::Display` על בסיס זה (ההפך מהיחסים הרגילים בין השניים).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// מדפיס את המילולי כמחרוזת שאמורה להיות ניתנת להמרה ללא הפסד לאותו מילולי (למעט עיגול אפשרי עבור מילולי נקודה צפה).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// גישה במעקב למשתני סביבה.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// אחזר משתנה סביבה והוסף אותו לבניית מידע על תלות.
    /// מערכת בנייה שמבצעת את המהדר תדע כי הגישה למשתנה במהלך הקומפילציה ותוכל לבצע הפעלה מחדש כאשר הערך של המשתנה משתנה.
    ///
    /// מלבד מעקב התלות פונקציה זו צריכה להיות שווה ל-`env::var` מהספרייה הרגילה, אלא שהויכוח חייב להיות UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}