//! יישום panics באמצעות הרפיית מחסנית
//!
//! crate זה יישום של panics ב-Rust באמצעות מנגנון הסרת מחסנית "most native" של הפלטפורמה שלשמה נערך.
//! זה למעשה מסווג לשלושה דליים כרגע:
//!
//! 1. יעדי MSVC משתמשים ב-SEH בקובץ `seh.rs`.
//! 2. Emscripten משתמש בחריגות C++ בקובץ `emcc.rs`.
//! 3. כל היעדים האחרים משתמשים ב-libunwind/libgcc בקובץ `gcc.rs`.
//!
//! תיעוד נוסף אודות כל יישום ניתן למצוא במודול המתאים.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` אינו בשימוש עם מירי, אז שתיקי אזהרות.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // אובייקטי ההפעלה של זמן הריצה Rust תלויים בסמלים אלה, לכן הפכו אותם לציבוריים.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // יעדים שאינם תומכים בפירוק.
        // - arch=wasm32
        // - os=none (יעדי "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // השתמש בזמן הריצה של מירי.
        // עלינו עדיין לטעון את זמן הריצה הרגיל שלמעלה, מכיוון ש-rustc מצפה שמוגדרים פריטים מסוימים משם.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // השתמש בזמן הריצה האמיתי.
        use real_imp as imp;
    }
}

extern "C" {
    /// המטפל ב-libstd התקשר כאשר אובייקט panic מושלך מחוץ ל-`catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// המטפל בספרות חייג כאשר נתפס חריג זר.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// נקודת כניסה להעלאת חריג, רק נציגים ליישום הספציפי לפלטפורמה.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}