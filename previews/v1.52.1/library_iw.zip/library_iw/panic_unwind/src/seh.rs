//! Windows SEH
//!
//! ב-Windows (כרגע רק ב-MSVC), מנגנון הטיפול בחריגים המוגדר כברירת מחדל הוא טיפול בחריגים מובנים (SEH).
//! זה שונה לגמרי מטיפול חריג מבוסס גמדים (למשל, במה משתמשים בפלטפורמות unix אחרות) במונחים של פנימי מהדר, כך ש-LLVM נדרש לקבל תמיכה נוספת רבה ב-SEH.
//!
//! בקצרה, מה שקורה כאן הוא:
//!
//! 1. הפונקציה `panic` מכנה את הפונקציה Windows הרגילה `_CxxThrowException` כדי לזרוק חריג C++ -מה שמפעיל את תהליך הניתוק.
//! 2.
//! כל רפידות הנחיתה שנוצרות על ידי המהדר משתמשות בפונקציית האישיות `__CxxFrameHandler3`, פונקציה ב-CRT, והקוד המונע ב-Windows ישתמש בפונקציית אישיות זו כדי לבצע את כל קוד הניקוי בערימה.
//!
//! 3. בכל השיחות המיוצרות על ידי המהדר ל-`invoke` יש משטח נחיתה שהוגדר כהוראת `cleanuppad` LLVM, המציין את תחילת שגרת הניקוי.
//! האישיות (בשלב 2, המוגדר ב-CRT) אחראית להפעלת שגרות הניקוי.
//! 4. בסופו של דבר קוד ה-"catch" במבנה ה-`try` (שנוצר על ידי המהדר) מבוצע ומציין כי השליטה צריכה לחזור ל-Rust.
//! זה נעשה באמצעות `catchswitch` בתוספת הוראות `catchpad` במונחי LLVM IR, ולבסוף החזרת השליטה הרגילה לתוכנית עם הוראות `catchret`.
//!
//! כמה הבדלים ספציפיים מהטיפול בחריגים מבוססי gcc הם:
//!
//! * ל-Rust אין פונקציית אישיות מותאמת אישית, אלא במקום זאת *תמיד*`__CxxFrameHandler3`.בנוסף, לא מתבצע סינון נוסף, כך שבסופו של דבר אנו תופסים חריגים מסוג C++ שנראים כמו הסוג שאנו זורקים.
//! שים לב שזריקת חריג ל-Rust היא בכל מקרה התנהגות לא מוגדרת, כך שזה אמור להיות בסדר.
//! * יש לנו כמה נתונים להעביר מעבר לגבול הניתוק, במיוחד `Box<dyn Any + Send>`.כמו למעט חריגים מגמדים, שני המצביעים הללו מאוחסנים כמטען במעט עצמו.
//! ב-MSVC, לעומת זאת, אין צורך בהקצאת ערימה נוספת מכיוון שמחסנית השיחות נשמרת בזמן ביצוע פונקציות המסנן.
//! המשמעות היא שהמצביעים מועברים ישירות ל-`_CxxThrowException` אשר משוחזרים לאחר מכן בפונקציית המסנן כדי להיכתב למסגרת הערימה של ה-`try` הפנימי.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // זו צריכה להיות אופציה מכיוון שאנו תופסים את החריג על ידי התייחסות והמשמיד שלו מבוצע על ידי זמן הריצה C++ .
    // כאשר אנו מוציאים את התיבה מחוץ לחריג, עלינו להשאיר את החריג במצב תקף כדי שההרס שלו יפעל מבלי להפיל את התיבה.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// ראשית, חבורה שלמה של הגדרות סוג.יש כאן כמה מוזרויות ספציפיות לפלטפורמה, והרבה שהועתקו באופן בוטה מ-LLVM.המטרה של כל זה היא ליישם את הפונקציה `panic` למטה באמצעות שיחה ל-`_CxxThrowException`.
//
// פונקציה זו לוקחת שני טיעונים.הראשון הוא מצביע על הנתונים שאנו מעבירים אליהם, שבמקרה זה הוא אובייקט trait שלנו.די קל למצוא!אולם הבא הוא מסובך יותר.
// זהו מצביע למבנה `_ThrowInfo`, והוא בדרך כלל נועד רק לתאר את החריג שנזרק.
//
// נכון לעכשיו ההגדרה של סוג [1] זה מעט שעירה, והמוזרות העיקרית (וההבדל מהמאמר המקוון) היא שב-32 סיביות המצביעים הם מצביעים אך ב-64 סיביות המצביעים מתבטאים כקיזוז של 32 סיביות מה-סמל `__ImageBase`.
//
// המאקרו `ptr_t` ו-`ptr!` במודולים שלהלן משמשים לביטוי זה.
//
// מבוך הגדרות הסוג עוקב מקרוב אחר מה ש-LLVM פולט לפעולה מסוג זה.לדוגמה, אם אתה מרכיב קוד C++ זה ב-MSVC ופולט את ה-IR LLVM:
//
//      #include <stdint.h>
//
//      מבנה חלודה
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      בטל foo() { rust_panic a = {0, 1};
//          לזרוק a;}
//
// זה בעצם מה שאנחנו מנסים לחקות.רוב הערכים הקבועים למטה הועתקו רק מ-LLVM,
//
// בכל מקרה, כל המבנים האלה בנויים בצורה דומה, וזה רק מילולי מבחינתנו.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// שים לב שבכוונה אנו מתעלמים מכללי השמטת שמות כאן: אנו לא רוצים ש-C ++ יוכל לתפוס את Rust panics על ידי פשוט הכרזה על `struct rust_panic`.
//
//
// בעת שינוי, וודא שמחרוזת שם הסוג תואמת במדויק לזו המשמשת ב-`compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // בית `\x01` המוביל כאן הוא למעשה אות קסום ל-LLVM *לא* להחיל שום מנגול אחר כמו קידומת עם תו `_`.
    //
    //
    // סמל זה הוא הטבלה המשמשת את `std::type_info` של C++ .
    // לאובייקטים מסוג `std::type_info`, מתארי סוג, יש מצביע לטבלה זו.
    // מתארים של סוגים מתייחסים למבני C++ EH שהוגדרו לעיל וכי שנבנה בהמשך.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// מתאר סוג זה משמש רק כאשר משליכים חריג.
// חלק התפס מטופל על ידי הניסוי הפנימי, שמייצר את TypeDescriptor משלו.
//
// זה בסדר מכיוון שזמן הריצה של MSVC משתמש בהשוואת מחרוזות על שם הסוג כדי להתאים ל-TypeDescriptors ולא לשוויון המצביע.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor משמש אם קוד C++ מחליט לתפוס את החריג ולשחרר אותו מבלי להפיץ אותו.
// החלק הקאץ 'של הניסיון הפנימי יקבע את המילה הראשונה של אובייקט החריג ל-0 כך שהיא תדלג על ידי המשחית.
//
// שים לב ש-x86 Windows משתמש בוועידת השיחות "thiscall" לפונקציות חבר ++ C במקום בוועידת השיחות המוגדרת כברירת מחדל.
//
// הפונקציה exception_copy היא מעט מיוחדת כאן: היא מופעלת על ידי זמן הריצה של MSVC תחת גוש try/catch ו-panic שאנו מייצרים כאן ישמש כתוצאה מהעתק החריג.
//
// זה משמש את זמן הריצה C++ לתמיכה בכיבוש חריגים עם std::exception_ptr, שאיננו יכולים לתמוך בהם מכיוון Box<dyn Any>לא ניתן לשיבוט.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException מתבצע לחלוטין על גבי מסגרת הערימה הזו, כך שאין צורך להעביר את `data` אחרת לערימה.
    // אנו פשוט מעבירים מצביע ערימה לפונקציה זו.
    //
    // דרוש כאן ManuallyDrop מכיוון שאיננו רוצים שחריגה תיפטר בעת התרת.
    // במקום זאת הוא יושמט על ידי exception_cleanup אשר מופעל על ידי זמן הריצה C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // זה ... אולי נראה מפתיע, ובצדק.ב-MSVC של 32 סיביות, המצביעים בין מבנה זה הם בדיוק המצביעים.
    // ב-MSVC של 64 סיביות, עם זאת, המצביעים בין מבנים מתבטאים דווקא בקיזוזים של 32 סיביות מ-`__ImageBase`.
    //
    // כתוצאה מכך, ב-MSVC של 32 סיביות אנו יכולים להכריז על כל המצביעים ב'סטטי 'שלמעלה.
    // ב-MSVC של 64 סיביות, נצטרך להביע חיסור של מצביעים בסטטיקה, ש-Rust אינו מאפשר כרגע, ולכן איננו יכולים לעשות זאת.
    //
    // הדבר הבא הטוב ביותר הוא אם כן למלא את המבנים הללו בזמן ריצה (פאניקה היא גם ככה "slow path").
    // אז הנה אנו מפרשים מחדש את כל שדות המצביע הללו כמספרים שלמים של 32 סיביות ואז מאחסנים את הערך הרלוונטי לתוכו (באופן אטומי, מכיוון ש-panics במקביל עשוי להתרחש).
    //
    // מבחינה טכנית זמן הריצה כנראה יעשה קריאה לא-אטומית של שדות אלה, אך בתיאוריה הם אף פעם לא קוראים את הערך *השגוי* ולכן זה לא אמור להיות נורא ...
    //
    // בכל מקרה, אנחנו בעצם צריכים לעשות דבר כזה עד שנוכל לבטא פעולות נוספות בסטטיקה (ואולי לעולם לא נוכל).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // מטען NULL כאן פירושו שהגענו לכאן מהתפיסה (...) של __rust_try.
    // זה קורה כאשר נתפס חריג זר שאינו Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// מהדר זה דורש להתקיים (למשל, זה פריט לאנג), אך המהדר מעולם לא נקרא לכך מכיוון ש-__C_specific_handler או _except_handler3 הוא פונקציית האישיות שמשמשת תמיד.
//
// מכאן שמדובר רק בדל מפיל.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}