//! ביטול רגיעה ליעד *wasm32*.
//!
//! נכון לעכשיו אנחנו לא תומכים בזה, אז זה רק סתמים.

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    intrinsics::abort()
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    intrinsics::abort()
}