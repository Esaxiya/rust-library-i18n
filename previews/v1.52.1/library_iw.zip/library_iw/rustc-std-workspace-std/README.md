# ה-`rustc-std-workspace-std` crate

ראה תיעוד ל-`rustc-std-workspace-core` crate.