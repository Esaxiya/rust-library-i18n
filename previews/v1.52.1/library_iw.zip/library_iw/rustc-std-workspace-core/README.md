# ה-`rustc-std-workspace-core` crate

crate הוא crate פגום וריק אשר פשוט תלוי ב-`libcore` ומייצא מחדש את כל תכולתו.
crate הוא עיקר ההעצמה של הספרייה הסטנדרטית לתלות ב-crates מ-crates.io.

Crates ב-crates.io שהספרייה הסטנדרטית תלויה בכך צריך להיות תלוי ב-`rustc-std-workspace-core` crate מ-crates.io, שהוא ריק.

אנו משתמשים ב-`[patch]` כדי לעקוף אותו ל-crate במאגר זה.
כתוצאה מכך, crates ב-crates.io ימשוך תלות edge ל-`libcore`, הגרסה המוגדרת במאגר זה.
זה אמור לצייר את כל קצוות התלות כדי להבטיח ש-Cargo בונה את crates בהצלחה!

שים לב ש-crates ב-crates.io צריך להיות תלוי ב-crate עם השם `core` כדי שהכל יעבוד כראוי.לשם כך הם יכולים להשתמש:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

באמצעות מקש `package` שמו של crate שונה ל-`core`, כלומר ייראה כמו

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

כאשר Cargo מזמין את המהדר, ומספק את הוראות ה-`extern crate core` הגלומות שהוזרקו על ידי המהדר.




