#![feature(no_core)]
#![no_core]

// ראה rustc-std-core-core הליבה מדוע יש צורך ב-crate.

// שנה את שם ה-crate כדי למנוע התנגשות עם מודול ההקצאה ב-liballoc.
extern crate alloc as foo;

pub use foo::*;