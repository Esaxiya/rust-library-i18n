// rsbegin.o ו-rsend.o הם מה שמכונה "compiler runtime startup objects".
// הם מכילים קוד הדרוש לאתחול נכון של זמן הריצה של המהדר.
//
// כאשר מקושרים תמונת הפעלה או דיליב, כל קוד המשתמש והספריות הם "sandwiched" בין שני קבצי האובייקט הללו, כך שקוד או נתונים מ-rsbegin.o הופכים להיות הראשונים בחלקים המתאימים של התמונה, ואילו קוד ונתונים מ-rsend.o הופכים להיות האחרונים.
// ניתן להשתמש באפקט זה להצבת סמלים בתחילת או בסוף קטע, כמו גם להכנסת כותרות עליונות או תחתונות נדרשות.
//
// שים לב כי נקודת הכניסה של המודול בפועל ממוקמת באובייקט ההפעלה של זמן הריצה C (המכונה בדרך כלל `crtX.o`), ואז קורא להתקשרות חוזרות של אתחול של רכיבי זמן ריצה אחרים (נרשם באמצעות קטע תמונה מיוחד נוסף).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // מסמן את תחילת קטע מסגרת הערימה להירגע
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // שריטה מקום לניהול הספרים הפנימי של מנוחה.
    // זה מוגדר כ-`struct object` ב-$ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // הרגע את שגרות המידע registration/deregistration.
    // ראה את המסמכים של libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // רשום מידע להירגע בעת הפעלת המודול
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // בטל את הרישום בכיבוי
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // רישום שגרתי init/uninit ספציפי ל-MinGW
    pub mod mingw_init {
        // אובייקטי ההפעלה של MinGW (crt0.o/dllcrt0.o) יפעילו קונסטרוקציות גלובליות בסעיפי .ctors ו-.dtors בעת ההפעלה והיציאה.
        // במקרה של קבצי DLL, זה נעשה כאשר ה-DLL נטען ופורק.
        //
        // המקשר ימיין את הסעיפים, מה שמבטיח שהשיחות החוזרות שלנו נמצאות בסוף הרשימה.
        // מכיוון שבונים מנוהלים בסדר הפוך, הדבר מבטיח שהשיחות החוזרות שלנו הן הראשונות והאחרונות שבוצעו.
        //
        //

        #[link_section = ".ctors.65535"] // .קטורים. *: שיחות חזרה של אתחול C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: התקשרות חוזרת לסיום C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}