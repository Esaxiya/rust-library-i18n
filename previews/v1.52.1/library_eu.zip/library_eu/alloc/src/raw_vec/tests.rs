use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Hirugarrenen esleitzaileen eta `RawVec` ren arteko integrazio proba idaztea apur bat zaila da, `RawVec` APIak ez dituelako esleipen metodo faltsuak agerian uzten, beraz ezin dugu egiaztatu zer gertatzen den esleitzailea agortzen denean (panic bat hautemateaz harago).
    //
    //
    // Horren ordez, honek egiaztatzen du `RawVec` metodoek gutxienez Allocator APIa pasatzen dutela biltegiratzea gordetzen duenean.
    //
    //
    //
    //
    //

    // Esleipen mutu bat erregai kopuru finko bat kontsumitzen duena, esleipen saiakerak huts egiten hasi aurretik.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (birkokapen bat eragiten du eta, beraz, 50 + 150=200 erregai unitate erabiltzen ditu)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Lehenik eta behin, `reserve`-k `reserve_exact` bezala esleitzen du.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 7ren bikoitza baino gehiago da, beraz, `reserve`-k `reserve_exact` bezala funtzionatu beharko luke.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 12ren erdia baino gutxiago da, beraz `reserve` esponentzialki hazi behar da.
        // Proba hau idazterakoan hazkunde faktorea 2 da, beraz, gaitasun berria 24 da, hala ere, 1.5 hazkunde faktorea ere ondo dago.
        //
        // Horregatik `>= 18` baieztatzen da.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}