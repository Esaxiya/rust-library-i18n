//! Memoria esleitzeko APIak

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Hauek dira esleitzaile globalari deitzeko sinbolo magikoak.rustc-k `__rg_alloc` etab. Deitzeko sortzen ditu.
    // `#[global_allocator]` atributu bat baldin badago (atributu hori makroa zabaltzen duen kodeak funtzio horiek sortzen ditu) edo libstd-eko lehenetsitako inplementazioei deitzeko (`__rdl_alloc` etab.
    //
    // `library/std/src/alloc.rs`-n) bestela.
    // LLVM-ren rustc fork-k funtzioen izen bereziak ere kasu bereziak ditu, hurrenez hurren `malloc`, `realloc` eta `free` bezala optimizatu ahal izateko.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Memoria banatzaile globala.
///
/// Mota honek [`Allocator`] trait ezartzen du `#[global_allocator]` atributuarekin erregistratutako esleitzaileari deiak birbidaliz gero, baldin badago edo `std` crate lehenetsia.
///
///
/// Note: mota hau ezegonkorra den bitartean, eskaintzen duen funtzionaltasunera [free functions in `alloc`](self#functions) bidez sar daiteke.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Esleitu memoria esleitzaile globalarekin.
///
/// Funtzio honek `#[global_allocator]` atributuarekin erregistratutako esleitzailearen [`GlobalAlloc::alloc`] metodoari deiak birbidaltzen dizkio, baldin badago edo `std` crate-ren lehenetsia.
///
///
/// Funtzio hau [`Global`] motako `alloc` metodoaren alde zaharkituta egongo dela espero da, bera eta [`Allocator`] trait egonkor bihurtzen direnean.
///
/// # Safety
///
/// Ikus [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Banatu memoria esleitzaile globalarekin.
///
/// Funtzio honek `#[global_allocator]` atributuarekin erregistratutako esleitzailearen [`GlobalAlloc::dealloc`] metodoari deiak birbidaltzen dizkio, baldin badago edo `std` crate-ren lehenetsia.
///
///
/// Funtzio hau [`Global`] motako `dealloc` metodoaren alde zaharkituta geratuko dela espero da, bera eta [`Allocator`] trait egonkor bihurtzen direnean.
///
/// # Safety
///
/// Ikus [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Memoria berriro esleitu esleitzaile globalarekin.
///
/// Funtzio honek `#[global_allocator]` atributuarekin erregistratutako esleitzailearen [`GlobalAlloc::realloc`] metodoari deiak birbidaltzen dizkio, baldin badago edo `std` crate-ren lehenetsia.
///
///
/// Funtzio hau [`Global`] motako `realloc` metodoaren alde zaharkituta geratuko dela espero da, bera eta [`Allocator`] trait egonkor bihurtzen direnean.
///
/// # Safety
///
/// Ikus [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Esleitu zero hasieratutako memoria esleitzaile globalarekin.
///
/// Funtzio honek `#[global_allocator]` atributuarekin erregistratutako esleitzailearen [`GlobalAlloc::alloc_zeroed`] metodoari deiak birbidaltzen dizkio, baldin badago edo `std` crate-ren lehenetsia.
///
///
/// Funtzio hau [`Global`] motako `alloc_zeroed` metodoaren alde zaharkituta geratuko dela espero da, bera eta [`Allocator`] trait egonkor bihurtzen direnean.
///
/// # Safety
///
/// Ikus [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // SEGURTASUNA: `layout` zero ez da tamaina,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // SEGURTASUNA: `Allocator::grow` bezalakoa
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // SEGURTASUNA: `new_size` ez da zero, `old_size` `new_size` baino handiagoa edo berdina baita
            // segurtasun baldintzek eskatzen duten moduan.Deitzaileak beste baldintza batzuk bete beharko ditu
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` ziurrenik `new_size >= old_layout.size()` edo antzeko zerbait egiaztatzen du.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SEGURTASUNA: `new_layout.size()` `old_size` baino handiagoa edo berdina izan behar delako,
            // memoriaren esleipen zaharrak zein berriak baliozkoak dira `old_size` byteetarako irakurri eta idazteko.
            // Gainera, esleipen zaharra oraindik banatuta ez zegoenez, ezin da `new_ptr` gainjarri.
            // Horrela, `copy_nonoverlapping` rako deia segurua da.
            // `dealloc` ren segurtasun kontratua deitzaileak onartu beharko du.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // SEGURTASUNA: `layout` zero ez da tamaina,
            // deitzaileak beste baldintza batzuk bete beharko ditu
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURTASUNA: baldintza guztiak deitzaileak bete beharko ditu
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURTASUNA: baldintza guztiak deitzaileak bete beharko ditu
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // SEGURTASUNA: deitzaileak baldintzak bete beharko ditu
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // SEGURTASUNA: `new_size` zero ez da.Deitzaileak beste baldintza batzuk bete beharko ditu
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` ziurrenik `new_size <= old_layout.size()` edo antzeko zerbait egiaztatzen du.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SEGURTASUNA: `new_size` `old_layout.size()` baino txikiagoa edo berdina izan behar delako,
            // memoriaren esleipen zaharrak zein berriak baliozkoak dira `new_size` byteetarako irakurri eta idazteko.
            // Gainera, esleipen zaharra oraindik banatuta ez zegoenez, ezin da `new_ptr` gainjarri.
            // Horrela, `copy_nonoverlapping` rako deia segurua da.
            // `dealloc` ren segurtasun kontratua deitzaileak onartu beharko du.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Erakusle bakarren esleitzailea.
// Funtzio hau ez da desegin behar.Horrela bada, MIR kodegenak huts egingo du.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Sinadura honek `Box` ren berdina izan behar du, bestela ICE bat gertatuko da.
// `Box` parametro gehigarri bat gehitzen denean (`A: Allocator` bezala), hemen ere gehitu behar da.
// Adibidez `Box` `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` era aldatzen bada, funtzio hau `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` era ere aldatu behar da.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Esleipen erroreen kudeatzailea

extern "Rust" {
    // Hau da sinbolo magikoa esleitzeko errore orokorren kudeatzaileari deitzeko.
    // rustc-k sortzen du `__rg_oom` deitzeko `#[alloc_error_handler]` bat baldin badago edo bestela (`__rdl_oom`) azpiko inplementazio lehenetsiei deitzeko.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Utzi memoria esleitzearen errore edo huts egitean.
///
/// Memoria esleitzeko APIak deitzen dituztenei esleipena akats baten aurrean konputazioa abortatu nahi dutenek funtzio honetara deitzea gomendatzen dute, `panic!` edo antzekoa zuzenean deitu beharrean.
///
///
/// Funtzio honen portaera lehenetsia errore estandarrari mezu bat inprimatzea eta prozesua bertan behera uztea da.
/// Ordezka daiteke [`set_alloc_error_hook`] eta [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Alokatzeko probarako `std::alloc::handle_alloc_error` zuzenean erabil daiteke.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // sortutako `__rust_alloc_error_handler` bidez deitzen da

    // `#[alloc_error_handler]` ez badago
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // `#[alloc_error_handler]` badago
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Espezializatu klonak aurrez esleitutako eta hasierarik gabeko memorian.
/// `Box::clone` eta `Rc`/`Arc::make_mut`-k erabiltzen dute.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // *Lehenengoa* esleituta, optimizatzaileak klonatutako balioa bere lekuan sortzea baimendu dezake, tokikoa saltatuz eta mugituz.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Beti toki berean kopiatu dezakegu, tokian tokiko balio bat ere sartu gabe.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}