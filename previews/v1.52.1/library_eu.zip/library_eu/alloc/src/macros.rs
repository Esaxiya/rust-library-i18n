/// Argumentuak biltzen dituen [`Vec`] bat sortzen du.
///
/// `vec!` aukera ematen du `Vec` array adierazpenen sintaxi berdinarekin definitzeko.
/// Makro honen bi forma daude:
///
/// - Sortu [`Vec`] bat elementu zerrenda jakin batekin:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Sortu [`Vec`] bat elementu eta tamaina jakin batetik abiatuta:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Kontuan izan array adierazpenak ez bezala sintaxi honek [`Clone`] inplementatzen duten elementu guztiak onartzen dituela eta elementu kopuruak ez duela zertan konstantea izan behar.
///
/// Honek `clone` erabiliko du adierazpen bat bikoizteko, beraz, kontuz ibili beharko litzateke hau erabiliz `Clone` inplementazio estandarra ez duten motekin.
/// Adibidez, `vec![Rc::new(1);5] `k vector sortuko du kaxako zenbaki oso beraren erreferentziako bost erreferentziaz, ez bost erreferentzia modu independentean boxeatutako zenbaki osoetara.
///
///
/// Gainera, kontuan izan `vec![expr; 0]` onartzen dela eta vector huts bat sortzen duela.
/// Hala ere, `expr` ebaluatuko da eta, ondorioz, berehala jaitsiko da lortutako balioa, beraz, kontuan izan bigarren mailako efektuak.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): cfg(test)-rekin berezko `[T]::into_vec` metodoa, makro definizio honetarako beharrezkoa dena, ez dago erabilgarri.
// Horren ordez, erabili `slice::into_vec` funtzioa, hau da, cfg(test)-rekin soilik eskuragarri dago. Ikusi slice::hack modulua slice.rs-n informazio gehiago lortzeko
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// `String` bat sortzen du exekuzio garaiko adierazpenen interpolazioa erabiliz.
///
/// `format!` ek jasotzen duen lehen argumentua formatu katea da.Kate literal bat izan behar du.Formateatzeko katearen indarra jasotako `{}` en dago.
///
/// `format!`-ri pasatutako parametro osagarriek formateatzeko katearen barruan `{}` s ordezkatzen dute emandako ordenan, parametro izendatuak edo posizionalak erabiltzen ez badira;ikusi [`std::fmt`] informazio gehiago lortzeko.
///
///
/// `format!` rako ohiko erabilera kateak kateatzea eta interpolatzea da.
/// Hitzarmena bera erabiltzen da [`print!`] eta [`write!`] makroekin, katearen xedearen arabera.
///
/// Balio bakarra kate bihurtzeko, erabili [`to_string`] metodoa.Honek [`Display`] formatua erabiliko du trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics formateatutako trait inplementazioak errore bat ematen badu.
/// Horrek inplementazio okerra dela adierazten du, `fmt::Write for String`-k inoiz ez baitu errore bat ematen.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Behartu AST nodoak adierazpen batera eredua posizioan diagnostikoak hobetzeko.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}