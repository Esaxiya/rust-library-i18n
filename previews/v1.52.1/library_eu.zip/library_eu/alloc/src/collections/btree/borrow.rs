use core::marker::PhantomData;
use core::ptr::NonNull;

/// Erreferentzia bakar batzuen berrabiarazten duten ereduak ereduak, berrabiatzea eta haren ondorengo guztiak (hau da, bertatik eratorritako erakusleak eta erreferentziak) ez direla noizbait gehiago erabiliko jakiten duzunean, ondoren jatorrizko erreferentzia bakarra berriro erabili nahi duzula .
///
///
/// Mailegu-zuzentzaileak normalean mailegu-pilatze hau kudeatzen du zuretzat, baina pilaketa hori egiten duten kontrol-fluxu batzuk konplikatuak dira konpiladoreak jarraitu ahal izateko.
/// `DormantMutRef` telefonoak maileguak egiaztatzea ahalbidetzen du, oraindik ere pilatutako izaera adierazten baduzu eta horretarako zehaztu gabeko portaerarik gabe horretarako behar den erakusle kodea gordina kapsulatzen.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Hartu mailegu berezia, eta berehala itzuli.
    /// Konpilatzailearentzat erreferentzia berriaren iraupena jatorrizko erreferentziaren iraupen berdina da, baina zuk promise epe laburragoan erabiltzeko.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SEGURTASUNA: maileguari eusten diogu 'a `_marker` bidez eta agerian uzten dugu
        // erreferentzia hau bakarrik, beraz, bakarra da.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Itzuli hasieran harrapatutako mailegu bakarrera.
    ///
    /// # Safety
    ///
    /// Berriro ere amaitu behar da, hau da, `new`-k itzultzen duen erreferentzia eta hortik eratorritako erakusle eta erreferentzia guztiak ez dira gehiago erabili behar.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SEGURTASUNA: gure segurtasun baldintzek esan nahi dute erreferentzia hau berriro ere bakarra dela.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;