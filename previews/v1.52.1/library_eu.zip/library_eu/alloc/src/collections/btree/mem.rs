use core::intrinsics;
use core::mem;
use core::ptr;

/// Honek `v` erreferentzia bereziaren atzean dagoen balioa ordezkatzen du dagokion funtzioari deituz.
///
///
/// `change` itxieran panic gertatzen bada, prozesu guztia bertan behera geratuko da.
#[allow(dead_code)] // gorde ilustrazio gisa eta future erabiltzeko
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Honek `v` erreferentzia bakarraren atzean dagoen balioa ordezkatzen du dagokion funtzioari deituz eta bidean lortutako emaitza itzultzen du.
///
///
/// `change` itxieran panic gertatzen bada, prozesu guztia bertan behera geratuko da.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}