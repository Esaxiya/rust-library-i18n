use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Gertakari partikularrak kontrolatzen dituzten istripu proben manikeriaren planoa.
/// Instantzia batzuk panic-ra konfiguratu daitezke noizbait.
/// Ekitaldiak `clone`, `drop` edo `query` anonimo batzuk dira.
///
/// Crash test manikiak ID baten bidez identifikatzen eta ordenatzen dira, beraz BTreeMap batean gako gisa erabil daitezke.
/// Nahita erabiltzen duen inplementazioak ez du crate-n zehaztutako ezer oinarritzen, `Debug` trait ez ezik.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Kraskadura-proben dummy diseinua sortzen du.`id`-k instantzien ordena eta berdintasuna zehazten ditu.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Zein gertakari bizi dituen eta aukeran panics erregistratzen dituen crash test dummy baten instantzia sortzen du.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Gezurraren kasuak zenbat aldiz klonatu diren itzultzen du.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Dummy-ren kasuak zenbat aldiz bota diren itzultzen du.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Dummy-ren kasuei `query` kidea zenbat aldiz deitu izan zaien itzultzen du.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Zenbait kontsulta anonimo, eta emaitza dagoeneko eman da.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}