use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Bi iteratzaile gorakorren batasunetik gako-balio bikote guztiak gehitzen ditu, bidean `length` aldagai bat gehituz.Azken honi esker, deitzaileari ihesak ekiditea errazten zaio erorketa kudeatzailea izutzen denean.
    ///
    /// Bi iteratzaileek gako bera sortzen badute, metodo honek bikotea ezkerreko iteratzailetik jaisten du eta bikotea eskuineko iteratzailetik gehitzen du.
    ///
    /// Zuhaitzak goranzko hurrenkeran amaitzea nahi baduzu, `BTreeMap`-en kasuan bezala, bi errepikatzaileek gakoak goranzko ordenan ekoitzi beharko lituzkete, bakoitza zuhaitzaren tekla guztiak baino handiagoak, sarreran dagoeneko zuhaitzean dauden teklak barne.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // `left` eta `right` denbora linealean ordenatutako sekuentzia batean bateratzeko prestatzen gara.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Bitartean, ordenatutako sekuentziatik zuhaitz bat eraikitzen dugu denbora linealean.
        self.bulk_push(iter, length)
    }

    /// Gako-balio bikote guztiak zuhaitzaren amaierara bultzatzen ditu, `length` aldagai bat gehituz bidean.
    /// Azken horri esker, deitzaileari iturriak izutzen denean ihesik ez egitea errazten dio.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Errepikatu gako-balio bikote guztiak, maila egokian dauden nodoetara bultzatuz.
        for (key, value) in iter {
            // Saiatu tekla-balioa bikotea uneko hosto nodoan sartzen.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Ez dago lekurik, igo eta bultzatu.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Ezkerreko lekua duen nodo bat aurkitu, sakatu hemen.
                                open_node = parent;
                                break;
                            } else {
                                // Igo berriro.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Goian gaude, erro nodo berri bat sortu eta hara bultzatu.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Sakatu tekla-balioa bikotea eta eskuineko azpiarboleta berria.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Jaitsi berriro eskuineko hostora.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Gehitu luzera errepikapen guztietan, mapak erantsitako elementuak jaisten dituela ziurtatzeko, nahiz eta iteratzaileak aurrera egiten duen.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Ordenatutako bi sekuentzia bakarrean bateratzeko errepikatzailea
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Bi gako berdinak badira, iturri egokitik gako-balioa bikotea itzultzen du.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}