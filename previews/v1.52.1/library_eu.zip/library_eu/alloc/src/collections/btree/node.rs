// Hau idealaren ondorengo inplementazio saiakera bat da
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust-k menpekotasun motak eta errekurtsibitate polimorfoak ez dituenez, segurtasunik eza egiten dugu.
//

// Modulu honen helburu nagusia konplexutasuna saihestea da, zuhaitza edukiontzi generiko gisa (itxura arraroa badu) eta B-Zuhaitz aldaezin gehienekin tratatzea saihestuz.
//
// Horregatik, modulu honi ez zaio axola sarrerak ordenatuta dauden, zein nodo azpigainekoak izan daitezkeen edo zer esan nahi ez duen.Hala ere, aldaezin batzuengan oinarritzen gara:
//
// - Zuhaitzek depth/height uniformea izan behar dute.Horrek esan nahi du nodo jakin batetik hosto batera doan bide bakoitzak luzera bera duela.
// - `n` luzerako nodo batek `n` gakoak, `n` balioak eta `n + 1` ertzak ditu.
//   Horrek esan nahi du nodo huts batek ere edge bat duela gutxienez.
//   Hosto-nodo batentzat, "having an edge"-k nodoko posizio bat identifikatu dezakegula esan nahi du, hosto-ertzak hutsik daudelako eta ez dutela datuen irudikapenik behar.
// Barruko nodo batean, edge batek posizio bat identifikatzen du eta haurren nodo baterako erakuslea dauka.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Hosto-nodoen azpiko irudikapena eta barne-nodoen irudikapenaren zati bat.
struct LeafNode<K, V> {
    /// `K` eta `V` bertsioetan kobarianteak izan nahi dugu.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Nodo honen indizea nodo nagusiaren `edges` matrizean.
    /// `*node.parent.edges[node.parent_idx]` `node`-ren gauza bera izan beharko luke.
    /// Hau hasierakoa izango dela ziurtatzen da `parent` nulua ez denean.
    parent_idx: MaybeUninit<u16>,

    /// Nodo honek gordetzen dituen gako eta balio kopurua.
    len: u16,

    /// Nodoaren benetako datuak gordetzen dituzten matrizeak.
    /// Matrize bakoitzaren lehen `len` elementuak soilik hasieratu eta baliozkoak dira.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// `LeafNode` berria lekuan hasten du.
    unsafe fn init(this: *mut Self) {
        // Politika orokor gisa, eremuak hasierarik gabe uzten ditugu ahal bada, Valgrind-en zertxobait azkarrago eta errazago jarrai daitekeelako.
        //
        unsafe {
            // guraso_idx, gakoak eta balioak agianUnUnit dira
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// `LeafNode` kutxa berria sortzen du.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Barne nodoen azpiko irudikapena.`LeafNode`-rekin gertatzen den moduan, hauek`BoxedNode`-ren atzean ezkutatu beharko lirateke hasierarik gabeko gakoak eta balioak erortzea ekiditeko.
/// `InternalNode` baterako edozein erakusle zuzenean nodoaren azpiko `LeafNode` zatira erakuslea biltegiratu daiteke, kodeak hosto eta barne nodoen gainean modu orokorrean jarduteko erakuslea bi horietatik zein seinalatzen duen ere egiaztatu beharrik izan gabe.
///
/// Propietate hau `repr(C)` erabilita gaitzen da.
///
#[repr(C)]
// gdb_providers.py mota izen hau barneratze-lanetarako erabiltzen du.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Nodo honetako haurren erakusleak.
    /// `len + 1` Horietatik hasieratzat eta baliozkotzat jotzen dira, izan ere, amaiera aldera, zuhaitza `Dying` maileguaren bidez mantentzen den bitartean, erakusle horietako batzuk zintzilik daude.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// `InternalNode` kutxa berria sortzen du.
    ///
    /// # Safety
    /// Barne nodoen aldaezina da gutxienez hasierako eta baliozko edge bat dutela.
    /// Funtzio honek ez du edge hori konfiguratzen.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Datuak hasieratzea baino ez dugu behar;ertzak MaybeUninit dira.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Nodo baterako erakusle kudeatua eta nulua.Hau da `LeafNode<K, V>`-ra jarritako erakuslea edo `InternalNode<K, V>`-ra dagoen erakuslea.
///
/// Hala ere, `BoxedNode`-k ez du inolako informaziorik zein dituen bi nodo moten artean, eta, informazio partzial hori dela eta, ez da aparteko mota eta ez du suntsitzailerik.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Jabedun zuhaitz baten erro nodo.
///
/// Kontuan izan horrek ez duela suntsitzailerik, eta eskuz garbitu behar dela.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Jabedun zuhaitz berria itzultzen du, hasieran hutsik dagoen erro-nodo propioarekin.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` ez du zero izan behar.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Jabetzako erro-nodoak maileguan hartu.
    /// `reborrow_mut` ez bezala, hau segurua da, itzulerako balioa ezin baita erroa suntsitzeko erabili, eta zuhaitzari buruzko beste erreferentzia batzuk ere ezin dira egon.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Jabetzako erro-nodoa maileguz hartzen du.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Alderantzik gabe zeharkatzea ahalbidetzen duen eta metodo suntsitzaileak eskaintzen dituen erreferentzia batera igarotzen da eta beste ezer gutxi.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Barruko nodo berri bat gehitzen du aurreko erro nodora seinalatzen duen edge bakar batekin, bihurtu nodo berri hori erro nodoa eta itzuli.
    /// Honek altuera 1 handitzen du eta `pop_internal_level` ren aurkakoa da.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, orain barnekoak garela ahaztu dugula izan ezik:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Barruko erro-nodoa kentzen du, bere lehen semea erro-nodo berri gisa erabiliz.
    /// Nodo erroak seme bakarra duenean soilik deitzeko pentsatuta dagoenez, ez da garbiketarik egiten gako, balio eta beste seme-alaben batean.
    ///
    /// Honek altuera 1 gutxitzen du eta `push_internal_level`-ren aurkakoa da.
    ///
    /// Sarbide esklusiboa eskatzen du `Root` objektuarentzat, baina ez root nodoan;
    /// ez ditu erro nodoko beste helduleku edo erreferentziak baliogabetuko.
    ///
    /// Panics barne mailarik ez badago, hau da, erro-nodoa hosto bat bada.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SEGURTASUNA: barnekoak direla aldarrikatu genuen.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SEGURTASUNA: `self` maileguan hartu dugu soilik eta bere mailegu mota esklusiboa da.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SEGURTASUNA: lehenengo edge beti hasieratzen da.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` beti da aldakorra `K` eta `V`, `BorrowType` `Mut` denean ere.
// Teknikoki okerra da hau, baina ezin du segurtasunik sortu `NodeRef`-ren barne erabileraren ondorioz, `K` eta `V`-en guztiz generikoak izaten jarraitzen baitugu.
//
// Hala ere, mota publiko batek `NodeRef` biltzen duen bakoitzean, ziurtatu bariantza zuzena duela.
//
/// Nodo baten erreferentzia.
///
/// Mota honek nola funtzionatzen duen kontrolatzen duten zenbait parametro ditu:
/// - `BorrowType`: Mailegu mota deskribatzen duen eta bizitza osoa daraman mota faltsua.
///    - Hau `Immut<'a>` denean, `NodeRef`-k gutxi gora behera `&'a Node` bezala jokatzen du.
///    - Hau `ValMut<'a>` denean, `NodeRef`-k `&'a Node`-ek bezala jokatzen du gakoen eta zuhaitzaren egituraren inguruan, baina zuhaitz osoko balioen erreferentzia aldakor asko elkarrekin egoteko aukera ere ematen du.
///    - Hau `Mut<'a>` denean, `NodeRef`-k `&'a mut Node` ren antzera jokatzen du, nahiz eta txertatze metodoek balio baterako erakusle aldagarri bat elkarrekin egotea ahalbidetzen duten.
///    - Hau `Owned` denean, `NodeRef`-k `Box<Node>`-en antzera jokatzen du, baina ez du suntsitzailerik eta eskuz garbitu behar da.
///    - Hau `Dying` denean, `NodeRef`-k `Box<Node>`-en antzera jokatzen du gutxi gorabehera, baina zuhaitza bitaz bit suntsitzeko metodoak ditu eta metodo arruntek, deitzeko seguru gisa markatuta ez dauden arren, UB dei dezakete gaizki deituz gero.
///
///   `NodeRef` edozein zuhaitzean zehar nabigatzea baimentzen denez, `BorrowType` modu eraginkorrean zuhaitz osoari aplikatzen zaio, ez bakarrik nodoari berari.
/// - `K` eta `V`: nodoetan gordetako gako eta balio motak dira.
/// - `Type`: Hau `Leaf`, `Internal` edo `LeafOrInternal` izan daiteke.
/// Hau `Leaf` denean, `NodeRef`-k hosto nodo bat seinalatzen du, hau `Internal` denean `NodeRef`-k barne nodo bat seinalatzen du eta hau `LeafOrInternal` denean `NodeRef`-k nodo mota edozein seinalatu dezake.
///   `Type` `NodeType` izena du `NodeRef` kanpo erabiltzen denean.
///
/// `BorrowType` eta `NodeType`-k mugatzen dituzte zein metodo ezartzen ditugun, mota estatikoa segurtasuna aprobetxatzeko.Murrizketak daude muga horiek aplikatzeko moduan:
/// - Mota parametro bakoitzerako, metodo bat modu orokorrean edo mota jakin baterako soilik defini dezakegu.
/// Adibidez, ezin dugu `into_kv` bezalako metodo bat definitu generikoki `BorrowType` guztientzat, edo behin bizitza osoko mota guztietarako, `&'a` erreferentziak itzultzea nahi dugulako.
///   Hori dela eta, `Immut<'a>` motarik indartsuenarentzako bakarrik definitzen dugu.
/// - Ezin dugu derrigortasun inplizitua lortu `Mut<'a>`-tik `Immut<'a>`-ra.
///   Hori dela eta, `reborrow` deitu behar diogu `NodeRef` indartsuago bati `into_kv` bezalako metodo batera iristeko.
///
/// Zenbait erreferentzia itzultzen dituzten `NodeRef`-ko metodo guztiak:
/// - Hartu `self` balioaren arabera, eta itzuli `BorrowType`-k daraman bizitza.
///   Batzuetan, horrelako metodo bat deitzeko, `reborrow_mut` deitu behar dugu.
/// - Hartu erreferentzia gisa `self`, eta (implicitly) ek erreferentzia horren bizitza itzultzen du, `BorrowType`-k daraman bizitza ordez.
/// Horrela, mailegu-egiaztatzaileak bermatzen du `NodeRef` maileguan mantentzen dela, itzulitako erreferentzia erabiltzen den bitartean.
///   Txertatzeko euskarri diren metodoek arau hau okertzen dute erakusle gordin bat itzuliz, hau da, bizitza osorik gabeko erreferentzia bat.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Nodoak eta hostoen mailak bereizten dituzten mailak, nodoaren konstantea, `Type`-k guztiz deskribatu ezin duena eta nodoak berak gordetzen ez duena.
    /// Sustraiaren nodoko altuera gorde besterik ez dugu behar, eta bertatik atera beste nodoaren altuera.
    /// Zeroa izan behar du `Type` `Leaf` bada eta ez-zeroa `Type` `Internal` bada.
    ///
    ///
    height: usize,
    /// Hosto edo barne nodoaren erakuslea.
    /// `InternalNode` definizioak erakuslea biak ala biak balio duela ziurtatzen du.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Deskonprimitu `NodeRef::parent` gisa paketatutako nodoko erreferentzia.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Barruko nodo baten datuak azaltzen ditu.
    ///
    /// Nodo honi beste erreferentzia baliogabetzea ekiditeko ptr gordin bat ematen du.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SEGURTASUNA: nodo mota estatikoa `Internal` da.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Barne nodo bateko datuetarako sarbide esklusiboa mailegatzen du.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Nodoaren luzera aurkitzen du.Hau da gako edo balio kopurua.
    /// Ertz kopurua `len() + 1` da.
    /// Kontuan izan, segurua izan arren, funtzio horri deitzeak kode ez seguruak sortu dituen erreferentzia aldagarriak baliogabetzearen alboan eragina izan dezakeela.
    ///
    pub fn len(&self) -> usize {
        // Ezinbestekoa da `len` eremura soilik sartzea hemen.
        // BorrowType marker::ValMut bada, baliteke baliogabetu behar ez ditugun balioen erreferentzia aldaezinak izatea.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Nodoak eta hostoak bereizten dituzten maila kopurua itzultzen du.
    /// Zero altuerak nodoa hosto bat bera dela esan nahi du.
    /// Erroa goian duten zuhaitzak irudikatzen badituzu, zenbakiak nodoaren zein altitudetan agertzen den adierazten du.
    /// Hostoak goian dituzten zuhaitzak irudikatzen badituzu, zenbakiak zuhaitza nodoaren gainetik nola hedatzen den dio.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Aldi baterako nodo beraren beste erreferentzia aldaezina ateratzen du.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Edozein hosto edo barruko nodoen hosto zatia azaleratzen du.
    ///
    /// Nodo honi beste erreferentzia baliogabetzea ekiditeko ptr gordin bat ematen du.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Nodoak gutxienez LeafNode zatirako balio behar du.
        // Hau ez da NodeRef motako erreferentzia, ez dakigulako bakarra edo partekatua izan behar duen.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Uneko nodoko gurasoak aurkitzen ditu.
    /// `Ok(handle)` itzultzen du uneko nodoak benetan guraso bat badu, non `handle`-k uneko nodora seinalatzen duen gurasoaren edge seinalatzen duen.
    ///
    /// `Err(self)` ematen du uneko nodoak gurasoik ez badu, jatorrizko `NodeRef` itzuliz.
    ///
    /// Metodoaren izenak goiko erro nodoarekin zuhaitzak irudikatzen dituela suposatzen du.
    ///
    /// `edge.descend().ascend().unwrap()` eta `node.ascend().unwrap().descend()`-k biek, arrakastaren ondoren, ez dute ezer egin behar.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Erakusle gordinak erabili behar ditugu nodoetarako, BorrowType marker::ValMut bada, baliogabetu behar ez ditugun balioen erreferentzia aldakor aipagarriak egon baitaitezke.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Kontuan izan `self` hutsik egon behar duela.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Kontuan izan `self` hutsik egon behar duela.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Zuhaitz aldaezin bateko edozein hostoren edo barne-nodoaren hosto-zatia azaltzen du.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SEGURTASUNA: ezin da erreferentzia aldakorrik egon `Immut` gisa mailegatutako zuhaitz honetan.
        unsafe { &*ptr }
    }

    /// Nodoan gordetako gakoen ikuspegi bat mailegatzen du.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend`-ren antzera, nodo baten nodo nagusiaren erreferentzia lortzen du, baina prozesuan uneko nodoa ere banatzen du.
    /// Hori ez da segurua, uneko nodoa eskuragarria izango delako oraindik banatu arren.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Nodo hori `Leaf` bat dela dioen informazio estatikoa segurtasun osoz konpilatzaileari esaten dio.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Nodo hori `Internal` bat dela dioen informazio estatikoa segurtasun osoz konpilatzaileari esaten dio.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Aldi baterako nodo beraren beste erreferentzia aldakor bat ateratzen du.Kontuz, metodo hau oso arriskutsua denez, bikoitza, agian ez baita berehala arriskutsua agertuko.
    ///
    /// Erakusle aldagarriak zuhaitzaren inguruan edozein lekutan ibil daitezkeenez, itzulitako erakuslea erraz erabil daiteke jatorrizko erakuslea zintzilik, mugetatik kanpo edo baliogabea pilatutako mailegu arauen arabera.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) pentsa ezazu `NodeRef`-ri beste motako parametro bat gehitzea, nabigazio metodoen erabilera berreskuratutako erakusleetan mugatzen duena, segurtasun hori saihestuz.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Edozein hosto edo barruko nodoaren hosto zatirako sarbide esklusiboa mailegatzen du.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SEGURTASUNA: sarbide esklusiboa dugu nodo osora.
        unsafe { &mut *ptr }
    }

    /// Sarbide esklusiboa eskaintzen du edozein hosto edo barruko nodoaren hosto zatira.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SEGURTASUNA: sarbide esklusiboa dugu nodo osora.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Gakoen biltegiratze eremuko elementu baterako sarbide esklusiboa maileguan hartzen du.
    ///
    /// # Safety
    /// `index` 0. .MUGARRITASUNA da
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SEGURTASUNA: deitzaileak ezin izango du beste metodo batzuetara deitu
        // gakoaren zatiaren erreferentzia erori arte, maileguaren bizitza osorako sarbide berezia baitugu.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Nodoaren balioa biltegiratzeko eremuko elementu edo zati baterako sarbide esklusiboa maileguan hartzen du.
    ///
    /// # Safety
    /// `index` 0. .MUGARRITASUNA da
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SEGURTASUNA: deitzaileak ezin izango du beste metodo batzuetara deitu
        // balioaren zatiaren erreferentzia jaitsi arte, maileguaren bizitza osorako sarbide berezia baitugu.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Nodoaren biltegiratze eremuko elementu edo zati baterako sarbide esklusiboa maileguan hartzen du edge edukietarako.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY + 1 mugetan dago
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SEGURTASUNA: deitzaileak ezin izango du beste metodo batzuetara deitu
        // edge zatiaren erreferentzia jaitsi arte, maileguaren bizitza osorako sarbide berezia baitugu.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Nodoak hasierako `idx` elementu baino gehiago ditu.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Interesatzen zaigun elementu horren erreferentzia soilik sortzen dugu, beste elementu batzuen aipamen aipagarriak ez jartzea saihesteko, batez ere, aurreko iterazioetan deitzaileari itzulitakoak.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust #74679 arazoa dela eta tamaina gabeko array erakusleei behartu behar diegu.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Nodoaren luzerarako sarbide esklusiboa mailegatzen du.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Nodoaren esteka ezartzen du edge gurasoarekin, nodoko beste erreferentzia baliogabetu gabe.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Erroaren lotura garbitzen du edge gurasoarekin.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Gako-balio bikotea gehitzen du nodoaren amaieran.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range`-ek itzultzen dituen elementu guztiak nodoko edge indize baliozkoa da.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Gako-balio bikotea gehitzen du eta edge bat bikote horren eskuinera joateko, nodoaren amaierara.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Nodo bat `Internal` nodo bat edo `Leaf` nodo bat den egiaztatzen du.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Gako-balio bikote jakin bati edo edge nodo bateko erreferentzia.
/// `Node` parametroak `NodeRef` izan behar du, `Type` `KV` (heldulekua gako-balio bikotean adierazten duena) edo `Edge` (edge batean heldulekua adierazten duena) izan daiteke.
///
/// Kontuan izan `Leaf` nodoek ere `Edge` heldulekuak izan ditzaketela.
/// Haur nodo bati erakuslea irudikatu beharrean, hauek erakusleek gako-balio bikoteen artean joango liratekeen espazioak adierazten dituzte.
/// Adibidez, 2. luzera duen nodo batean, edge 3 kokapen posible egongo lirateke, bat nodoaren ezkerretara, bata bi bikoteen artean eta beste bat nodoaren eskuinean.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Ez dugu `#[derive(Clone)]`-ren orokortasun osoa behar, `Node` "Klonatzeko" izango den une bakarra erreferentzia aldaezina denean eta beraz `Copy` denean izango baita.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Helduleku honek adierazten duen edge edo gako-balio bikotea duen nodoa berreskuratzen du.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Helduleku honek nodoan duen kokapena itzultzen du.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Helduleku berria sortzen du gako-balio bikoteari `node`-n.
    /// Ez da segurua deitzaileak `idx < node.len()` hori ziurtatu behar duelako.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// PartialEq-ren inplementazio publikoa izan liteke, baina modulu honetan bakarrik erabiltzen da.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Aldi baterako beste helduleku aldaezina ateratzen du kokapen berean.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Ezin dugu Handle::new_kv edo Handle::new_edge erabili, gure mota ez dakigulako
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Segurtasunik gabe konpilatzaileari heltzen dio heldulekuaren nodoak `Leaf` dela dioen informazio estatikoa.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Aldi baterako beste helduleku aldakorra ateratzen du kokapen berean.
    /// Kontuz, metodo hau oso arriskutsua denez, bikoitza, agian ez baita berehala arriskutsua agertuko.
    ///
    ///
    /// Xehetasunak lortzeko, ikus `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Ezin dugu Handle::new_kv edo Handle::new_edge erabili, gure mota ez dakigulako
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Helduleku berria sortzen du edge bateri batean `node`-n.
    /// Ez da segurua deitzaileak `idx <= node.len()` hori ziurtatu behar duelako.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// edge indizea emanda, ahal den neurrian betetako nodo batean txertatu nahi dugunez, puntu zatitu baten KV indize zentzuduna kalkulatzen da eta txertaketa non egin.
///
/// Zatiketa puntuaren helburua gakoa eta balioa guraso nodo batean amaitzea da;
/// zatitu puntuaren ezkerreko teklak, balioak eta ertzak ezkerreko haur bihurtzen dira;
/// puntu zatituaren eskuinean dauden gakoak, balioak eta ertzak seme-alaba egokiak bihurtzen dira.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust zenbakia #74834 arau simetriko hauek azaltzen saiatzen da.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Gako-balio bikote berri bat txertatzen du gako-balio bikoteen artean edge honen eskuinean eta ezkerrean.
    /// Metodo honek suposatzen du nodoan nahikoa leku dagoela bikote berria egokitzeko.
    ///
    /// Itzulitako erakusleak sartutako balioa seinalatzen du.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Gako-balio bikote berri bat txertatzen du gako-balio bikoteen artean edge honen eskuinean eta ezkerrean.
    /// Metodo honek nodoa zatitzen du nahikoa tokirik ez badago.
    ///
    /// Itzulitako erakusleak sartutako balioa seinalatzen du.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// edge honek estekatzen duen nodoko haurraren erakuslea eta aurkibidea konpontzen ditu.
    /// Hau erabilgarria da ertzak ordenatzea aldatu denean,
    fn correct_parent_link(self) {
        // Sortu backpointerra nodoko beste erreferentzia batzuk baliogabetu gabe.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Gako-balio bikote berria eta edge honen eta edge honen eskuinean dagoen bikote berri horren eskuinera joango diren edge pare bat txertatzen ditu.
    /// Metodo honek suposatzen du nodoan nahikoa leku dagoela bikote berria egokitzeko.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Gako-balio bikote berria eta edge honen eta edge honen eskuinean dagoen bikote berri horren eskuinera joango diren edge pare bat txertatzen ditu.
    /// Metodo honek nodoa zatitzen du nahikoa tokirik ez badago.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Gako-balio bikote berri bat txertatzen du gako-balio bikoteen artean edge honen eskuinean eta ezkerrean.
    /// Metodo honek nodoa zatitzen du behar adina leku ez badago, eta zatitutako zatiak nodo nagusian errekurtsiboki txertatzen saiatzen da, erroa lortu arte.
    ///
    ///
    /// Itzulitako emaitza `Fit` bada, bere heldulekuaren nodoa edge ren nodoa edo arbaso bat izan daiteke.
    /// Itzulitako emaitza `Split` bada, `left` eremua izango da erro nodoa.
    /// Itzulitako erakusleak sartutako balioa seinalatzen du.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// edge honek seinalatzen duen nodoa aurkitzen du.
    ///
    /// Metodoaren izenak goiko erro nodoarekin zuhaitzak irudikatzen dituela suposatzen du.
    ///
    /// `edge.descend().ascend().unwrap()` eta `node.ascend().unwrap().descend()`-k biek, arrakastaren ondoren, ez dute ezer egin behar.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Erakusle gordinak erabili behar ditugu nodoetarako, BorrowType marker::ValMut bada, baliogabetu behar ez ditugun balioen erreferentzia aldakor aipagarriak egon baitaitezke.
        // Ez dago altuera eremura sartzeko kezkarik, balio hori kopiatu delako.
        // Kontuz, behin nodoaren erakusleari erreferentzia egiten zaionean, ertzak array batera sartzen garela erreferentzia batekin (Rust #73987 alea) eta arrayaren barruan edo beste edozein erreferentzia baliogabetzen badugu.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Ezin diegu gako eta balio metodo bereiziei deitu, bigarrenari deitzeak lehenengoak itzultzen duen erreferentzia baliogabetzen baitu.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Ordeztu KV heldulekuak aipatzen duen gakoa eta balioa.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// `split` inplementatzen laguntzen du `NodeType` jakin baterako, hostoen datuak zainduz.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Azpiko nodoa hiru zatitan banatzen du:
    ///
    /// - Nodoa moztua dago helduleku honen ezkerraldean dauden gako-balio bikoteak bakarrik edukitzeko.
    /// - Helduleku honek adierazten duen gakoa eta balioa ateratzen dira.
    /// - Helduleku honen eskuinean dauden gako-balio bikote guztiak esleitu berri den nodo batean sartzen dira.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Helduleku honek adierazten duen gako-balio bikotea kentzen du eta itzultzen du, gako-balio bikotea erori zen edge batera.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Azpiko nodoa hiru zatitan banatzen du:
    ///
    /// - Nodoa moztua dago helduleku honen ezkerreko ertzak eta gako-balio bikoteak soilik edukitzeko.
    /// - Helduleku honek adierazten duen gakoa eta balioa ateratzen dira.
    /// - Helduleku honen eskuinean dauden ertz eta gako-balio bikote guztiak esleitu berri den nodo batean sartzen dira.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Gako-balio pare baten inguruan oreka eragiketa ebaluatzeko eta burutzeko saioa adierazten du.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Nodoarekin lotzen duen testuinguru orekatzailea aukeratzen du txikitan, beraz, KVren artean berehala ezkerrera edo eskuinera nodo nagusian.
    /// `Err` bat itzultzen du gurasoik ez badago.
    /// Panics guraso hutsik badago.
    ///
    /// Ezkerreko aldea nahiago du, optimoa izan dadin emandako nodoa nolabait gutxi betetzen bada, hemen ezkerreko neba-arrebak eta eskuineko anai-arrebak baino elementu gutxiago dituela esan nahi du, baldin badago.
    /// Kasu horretan, ezkerreko anai-arrebarekin bat egitea azkarragoa da, nodoaren N elementuak soilik mugitu behar baititugu, eskuinera aldatu eta aurrean N elementuak baino gehiago mugitu beharrean.
    /// Ezker anai-arrebari lapurtzea ere azkarragoa da normalean, nodoko N elementuak eskuinera soilik aldatu behar baititugu, gutxienez anai-arrebaren N elementuak ezkerrera eraman beharrean.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Bateratzea posible den edo ez adierazten du, hau da, nodo batean nahikoa leku dagoen KV zentrala ondoko bi nodoekin konbinatzeko.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Bateratze bat egiten du eta itxierari zer itzuli behar duen erabakitzen uzten dio.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SEGURTASUNA: bateratzen ari diren nodoen altuera altueraren azpitik dago
                // edge honen nodoaren, beraz, zero gainetik, beraz, barnekoak dira.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Gurasoaren gako-balio bikotea eta ondoko bi seme-nodoak ezkerreko nodoan bateratzen ditu eta txikitutako guraso nodoak itzultzen ditu.
    ///
    ///
    /// Panics `.can_merge()` ezean.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Gurasoaren gako-balio bikotea eta ondoko bi haur nodoak bateratzen ditu ezkerreko haur nodoan eta ume nodo hori itzultzen du.
    ///
    ///
    /// Panics `.can_merge()` ezean.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Gurasoaren gako-balio bikotea eta aldameneko bi haur nodoak ezkerreko nodoan bateratzen ditu eta edge heldulekua itzultzen du jarraitutako edge haurrak amaitutako nodo horretan.
    ///
    ///
    /// Panics `.can_merge()` ezean.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Gako-balio bikotea ezkerreko haurrari kentzen dio eta gurasoaren gako-balioaren biltegian kokatzen du, guraso gako-balio bikotea eskuineko haurrera bultzatzen duen bitartean.
    ///
    /// Helduleku bat itzultzen du edge-ri eskuineko seme-alaban `track_right_edge_idx`-k zehaztutako jatorrizko edge-k amaitu zuen tokiari dagokionean.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Gako-balio bikotea eskuineko haurrari kentzen dio eta gurasoaren gako-balioaren biltegian kokatzen du, guraso gako-balio bikotea zaharra ezkerreko haurrera bultzatzen duen bitartean.
    ///
    /// `track_left_edge_idx`-k zehaztutako ezkerreko haurraren helduleku bat itzultzen du edge-ra, mugitu ez dena.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Honek `steal_left` ren antzeko lapurreta egiten du baina hainbat elementu lapurtzen ditu aldi berean.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Ziurtatu segurtasunez lapurtzen dugula.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Mugitu hostoen datuak.
            {
                // Egin lapurtutako elementuei lekua haur egokian.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Mugitu elementuak ezkerreko haurretik eskuinera.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Eraman ezker gehien lapurtutako bikotea gurasoarenera.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Eraman gurasoaren gako-balio bikotea eskuineko seme-alabara.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Egin lekua lapurtutako ertzei.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Lapurtu ertzak.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` klon simetrikoa.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Ziurtatu segurtasunez lapurtzen dugula.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Mugitu hostoen datuak.
            {
                // Eraman eskuineko lapurtu duten bikotea gurasoarengana.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Eraman gurasoaren gako-balio bikotea ezkerreko haurrera.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Mugitu elementuak eskuineko haurretik ezkerrera.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Bete lapurtutako elementuak zeuden lekua.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Lapurtu ertzak.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Bete lapurtutako ertzak zeuden lekua.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Nodo hau `Leaf` nodo bat dela baieztatzen duen informazio estatikoa kentzen du.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Nodo hau `Internal` nodo bat dela baieztatzen duen informazio estatikoa kentzen du.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Azpiko nodoa `Internal` nodo bat edo `Leaf` nodo bat den egiaztatzen du.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Mugitu atzizkia `self` ondoren nodo batetik bestera.`right` hutsik egon behar du.
    /// `right` ren lehen edge aldatu gabe dago.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Txertatzearen emaitza, nodo batek bere ahalmena gainditu behar zuenean.
pub struct SplitResult<'a, K, V, NodeType> {
    // Nodo aldatua lehendik zegoen zuhaitzean `kv`-ren ezkerreko elementuak eta ertzak dituena.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Zenbait gako eta balio banandu dira, beste nonbait txertatzeko.
    pub kv: (K, V),
    // Jabea, lotu gabeko nodo berria, `kv`-ren eskuinean dauden elementuak eta ertzak dituena.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Mailegu mota honetako nodo erreferentziek zuhaitzaren beste nodo batzuetara igarotzea baimentzen duten ala ez.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal ez da beharrezkoa, `borrow_mut`-ren emaitza erabiliz gertatzen da.
        // Zeharkapena desgaituz eta erroei buruzko erreferentzia berriak sortuz, badakigu `Owned` motako erreferentzia bakoitza erro-nodo bat dela.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Balio bat txertatzen du hasieratutako elementuen zatian eta ondoren hasierarik gabeko elementu bat.
///
/// # Safety
/// Xerra `idx` elementu baino gehiago ditu.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Hasierako elementu guztien zatitik balio bat kentzen eta itzultzen du, hasierako elementu gabeko amaierako elementu bat atzean utzita.
///
///
/// # Safety
/// Xerra `idx` elementu baino gehiago ditu.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// `distance` posizio zatitan dauden elementuak ezkerrera aldatzen ditu.
///
/// # Safety
/// Xerra gutxienez `distance` elementu ditu.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// `distance` posizio zatitan dauden elementuak eskuinera aldatzen ditu.
///
/// # Safety
/// Xerra gutxienez `distance` elementu ditu.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Balio guztiak mugitzen ditu hasierako elementuen zatitik hasierarik gabeko elementuen zatira, `src` atzean utziz hasierarik gabeko guztiak bezala.
///
/// `dst.copy_from_slice(src)` bezalako funtzionamendua du, baina ez du `T` behar `Copy` izateko.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;