//! Eraztun buffer hazgarri batekin inplementatutako mutur bikoitzeko ilara.
//!
//! Ilara honek *O*(1) edukiontziaren bi muturretatik txertatutako amortizazioak eta ateratzeak ditu.
//! vector bezalako *O*(1) indexazioa ere badu.
//! Ez dago jasotako elementuak kopiagarriak izateko, eta ilara bidaliko da jasotako mota bidal badaiteke.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Ahalik eta biren ahalmen handiena

/// Eraztun buffer hazgarri batekin inplementatutako mutur bikoitzeko ilara.
///
/// Mota honetako "default" ilara gisa erabiltzea [`push_back`] erabiltzea da ilaran gehitzeko eta [`pop_front`] ilaran kentzeko.
///
/// [`extend`] eta [`append`]-ek modu honetara atzeko aldera bultzatzen dute eta `VecDeque` baino gehiagoko errepikapena aurrez aurre doa.
///
/// `VecDeque` eraztun buffer bat denez, bere elementuak ez dira nahitaez memorian atxikiak.
/// Elementuak xerra bakar gisa sartu nahi badituzu, adibidez, sailkapen eraginkorrerako, [`make_contiguous`] erabil dezakezu.
/// `VecDeque` biratzen du bere elementuak bildu ez daitezen, eta zati aldakor bat itzultzen du orain ondoko elementu sekuentziara.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // isatsa eta burua bufferrean erakusleak dira.
    // Buztan beti irakur daitekeen lehen elementua seinalatzen da, Buruak beti datuak non idatzi behar diren seinalatzen du.
    //
    // Buztana==burua bufferra hutsik badago.Ringbufferraren luzera bien arteko distantzia gisa definitzen da.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Xerran dauden elementu guztien suntsitzailea exekutatzen du erortzen denean (normalean edo desegiten denean).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // erabili jaregin [T] rako
            ptr::drop_in_place(front);
        }
        // RawVec-ek deslokalizazioa kudeatzen du
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// `VecDeque<T>` huts bat sortzen du.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Marjinalki erosoagoa
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Marjinalki erosoagoa
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Zero tamainako motetarako, beti edukiera maximoa dugu
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Bihurtu ptr xerra
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Bihurtu ptr mut xerra
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Elementu bat bufferretik ateratzen du
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Elementu bat bufferrean idazten du, mugituz.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// `true` itzultzen du bufferrak ahalmen osoa badu.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Elementu logikoen indize jakin baten azpiko bufferreko indizea itzultzen du.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Elementu logikoaren aurkibidea + gehigarriaren azpiko bufferraren indizea ematen du.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Elementu logikoaren aurkibidearen azpiko bufferraren indizea ematen du, azpirautatu.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// src-tik dst-ra memoriaren bloke ondoko bat kopiatzen du
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src-tik dst-ra memoriaren bloke ondoko bat kopiatzen du
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src-tik dest.-Era luzerako memoria bloke potentzial bat kopiatzen du.
    /// (abs(dst - src) + len) ez da cap() baino handiagoa izan behar (src eta dest artean etengabe gainjarritako eskualde bat egon behar da gehienez).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src-k ez du biltzen, dst-ek ez du biltzen
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // src baino lehen, src ez da biltzen, dst biltzen da
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src dst aurretik, src ez da biltzen, dst biltzen da
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst src aurretik, src biltzeko, dst ez da biltzeko
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src dst aurretik, src biltzeko, dst ez da biltzeko
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst src aurretik, src wraps, dst wraps
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src dst aurretik, src biltzeko, dst biltzeko
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Burua eta buztana atalak birkokatu besterik ez ditugula zuzendu kudeatzeko.
    /// Ez da segurua gaitasun_zaharrarekin fidatzen delako.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Eraman TH eraztun bufferreko atalik laburrena
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // A Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// `VecDeque` huts bat sortzen du.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// `VecDeque` huts bat sortzen du gutxienez `capacity` elementuentzako espazioarekin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1, ringbuffer-ek beti hutsune bat uzten baitu
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Emandako indizearen elementuaren erreferentzia eskaintzen du.
    ///
    /// 0 indizeko elementua ilararen aurrealdea da.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Emandako indizearen elementuaren erreferentzia aldakorra eskaintzen du.
    ///
    /// 0 indizeko elementua ilararen aurrealdea da.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// `i` eta `j` indizeetan elementuak trukatzen ditu.
    ///
    /// `i` eta `j` berdina izan daiteke.
    ///
    /// 0 indizeko elementua ilararen aurrealdea da.
    ///
    /// # Panics
    ///
    /// Panics indize bat mugetatik kanpo badago.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// `VecDeque`-k birkokatu gabe eduki ditzakeen elementu kopurua itzultzen du.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Emandako `VecDeque`-an zehazki `additional` elementu gehiago sartzeko gutxieneko edukiera gordetzen du.
    /// Ez du ezer egiten dagoeneko edukiera nahikoa bada.
    ///
    /// Kontuan izan esleitzaileak bildumari eskatzen diona baino leku gehiago eman diezaiokeela bildumari.
    /// Hori dela eta, ezin da gaitasuna hain txikia izan.
    /// Nahiago [`reserve`] future txertatzeak espero badira.
    ///
    /// # Panics
    ///
    /// Panics edukiera berriak `usize` gainezka egiten badu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Emandako `VecDeque`-an txertatzeko gutxienez `additional` elementu gehiagorako edukiera gordetzen du.
    /// Bildumak leku gehiago gorde dezake maiz birkokapenik ez izateko.
    ///
    /// # Panics
    ///
    /// Panics edukiera berriak `usize` gainezka egiten badu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Emandako `VecDeque<T>`-an zehazki `additional` elementu gehiago sartzeko gutxieneko edukiera gordetzen saiatzen da.
    ///
    /// `try_reserve_exact` deitu ondoren, edukiera `self.len() + additional` baino handiagoa edo berdina izango da.
    /// Ez du ezer egiten dagoeneko edukiera nahikoa bada.
    ///
    /// Kontuan izan esleitzaileak bildumari eskatzen diona baino leku gehiago eman diezaiokeela bildumari.
    /// Hori dela eta, ezin da ahalmena zehatz-mehatz fidatu.
    /// Nahiago `reserve` future txertatzeak espero badira.
    ///
    /// # Errors
    ///
    /// Gaitasunak `usize` gainezka egiten badu edo esleitzaileak huts egin duela jakinarazten badu, errore bat itzuliko da.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Aurretik erreserbatu memoria, ezin badugu irten
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Orain badakigu hau ezin dela OOM(Out-Of-Memory) gure lan konplexuaren erdian
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // oso konplikatua
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Emandako `VecDeque<T>`-an txertatzeko gutxienez `additional` elementu gehiagorako edukiera erreserbatzen saiatzen da.
    /// Bildumak leku gehiago gorde dezake maiz birkokapenik ez izateko.
    /// `try_reserve` deitu ondoren, edukiera `self.len() + additional` baino handiagoa edo berdina izango da.
    /// Ez du ezer egiten ahalmena nahikoa bada.
    ///
    /// # Errors
    ///
    /// Gaitasunak `usize` gainezka egiten badu edo esleitzaileak huts egin duela jakinarazten badu, errore bat itzuliko da.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Aurretik erreserbatu memoria, ezin badugu irten
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Orain badakigu hau ezin dela OOM gure lan konplexuaren erdian
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // oso konplikatua
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Ahalik eta gehien murrizten du `VecDeque` ren edukiera.
    ///
    /// Luzerara ahalik eta gehien gerturatuko da baina esleitzaileak oraindik `VecDeque`-ri jakinaraz diezaioke elementu batzuk gehiagorako lekua dagoela.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// `VecDeque` ren edukiera txikiagoa da beheko mugarekin.
    ///
    /// Edukiera gutxienez luzera eta hornitutako balioa bezain handia izango da.
    ///
    ///
    /// Uneko ahalmena beheko muga baino txikiagoa bada, hau ez da op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Ez dugu gainezkatzerik kezkatu behar, `self.len()` eta `self.capacity()` ezin baitira inoiz `usize::MAX` izan.
        // +1 gisa, ringbufferrak beti hutsune bat uzten baitu.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Hiru interes kasu daude:
            //   Elementu guztiak nahi diren mugetatik kanpo daude Elementuak aldamenean daude, eta burua nahi diren mugetatik kanpo Elementuak ez dira jarraitzaileak, eta isatsa nahi diren mugetatik kanpo daude.
            //
            //
            // Beste une guztietan, elementuen posizioek ez dute eraginik.
            //
            // Buruan dauden elementuak mugitu behar direla adierazten du.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Mugitu elementuak nahi dituzun mugetatik (posizioak target_cap-en ondoren)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// `VecDeque` laburtu egiten du, lehen `len` elementuak mantenduz eta gainerakoa jareginez.
    ///
    ///
    /// `len` `VecDeque`-ren uneko luzera baino handiagoa bada, horrek ez du eraginik.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Xerran dauden elementu guztien suntsitzailea exekutatzen du erortzen denean (normalean edo desegiten denean).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Segurua delako:
        //
        // * `drop_in_place`-ra pasatutako edozein zatiak balio du;bigarren kasuak `len <= front.len()` du eta `len > self.len()` itzultzeak `begin <= back.len()` ziurtatzen du lehen kasuan
        //
        // * VecDeque-ren burua `drop_in_place` deitu aurretik mugitzen da, beraz, ez da baliorik jaisten bi aldiz `drop_in_place` panics bada
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Ziurtatu bigarren erdia erortzen dela lehenengo panics suntsitzailea denean ere.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Aurrez aurreko iteratzailea itzultzen du.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Erreferentzia aldakorrak itzultzen dituen aurrez aurreko iteratzailea itzultzen du.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // SEGURTASUNA: barneko `IterMut` segurtasun aldaezina ezartzen da
        // `ring` sortzen dugun bizitza osorako xerra ezezaguna da '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// `VecDeque` edukia ordenan duten xerra pare bat itzultzen du.
    ///
    /// Aurretik [`make_contiguous`] deitu izan balitz, `VecDeque` ren elementu guztiak lehenengo zatian egongo dira eta bigarren zatian hutsik egongo dira.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// `VecDeque` edukia ordenan duten xerra pare bat itzultzen du.
    ///
    /// Aurretik [`make_contiguous`] deitu izan balitz, `VecDeque` ren elementu guztiak lehenengo zatian egongo dira eta bigarren zatian hutsik egongo dira.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// `VecDeque` elementu kopurua itzultzen du.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// `true` itzultzen du `VecDeque` hutsik badago.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// `VecDeque`-n zehaztutako barrutia estaltzen duen iteratzailea sortzen du.
    ///
    /// # Panics
    ///
    /// Panics abiapuntua amaiera puntua baino handiagoa bada edo amaiera puntua bektorea ren luzera baino handiagoa bada.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Eskaintza osoak eduki guztiak estaltzen ditu
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // &self-en dugun erreferentzia partekatua Iter-en '_-n mantentzen da.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// `VecDeque`-n zehaztutako barruti aldakorra estaltzen duen iteratzailea sortzen du.
    ///
    /// # Panics
    ///
    /// Panics abiapuntua amaiera puntua baino handiagoa bada edo amaiera puntua bektorea ren luzera baino handiagoa bada.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Eskaintza osoak eduki guztiak estaltzen ditu
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // SEGURTASUNA: barneko `IterMut` segurtasun aldaezina ezartzen da
        // `ring` sortzen dugun bizitza osorako xerra ezezaguna da '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// `VecDeque`-n zehaztutako barrutia kentzen duen eta kendutako elementuak ematen dituen iteratzaile drainatzailea sortzen du.
    ///
    /// 1. oharra: Elementuen barrutia kentzen da, nahiz eta iteratzailea azkenera arte kontsumitzen ez den.
    ///
    /// 2. oharra: zehaztu gabe dago zenbat elementu kentzen diren deque-tik, `Drain` balioa jaisten ez bada, baina duen mailegua iraungi egiten da (adibidez, `mem::forget` dela eta).
    ///
    ///
    /// # Panics
    ///
    /// Panics abiapuntua amaiera puntua baino handiagoa bada edo amaiera puntua bektorea ren luzera baino handiagoa bada.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Barruti oso batek eduki guztiak garbitzen ditu
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Memoriaren segurtasuna
        //
        // Drain lehen aldiz sortzen denean, iturburuko deque laburtu egiten da hasierako elementurik edo mugitu gabeko elementurik ez dela eskuragarria ziurtatzeko, Drain suntsitzailea inoiz exekutatzen ez bada.
        //
        //
        // Drain-k ptr::read-k kenduko dituen balioak aterako ditu.
        // Amaitutakoan, gainerako datuak berriro kopiatuko dira zuloa estaltzeko eta head/tail balioak behar bezala berreskuratuko dira.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Deque-ren elementuak hiru segmentutan banatuta daude:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=hustu_buztana;h=drain_head
        //
        // drain_tail self.head gisa gordetzen ditugu, eta drain_head eta self.head after_tail eta after_head gisa hurrenez hurren Drain-n.
        // Horrek array eraginkorra mozten du, beraz, Drain filtratzen bada, drain hasi ondoren mugitu daitezkeen balioak ahaztu ditugu.
        //
        //
        //        H garren
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" drain hasi ondorengo balioei buruz, drain amaitu eta Drain suntsitzailea exekutatu arte.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Ezinbestekoa da `self`-etik erreferentzia partekatuak sortzea eta bertatik irakurtzea.
                // Ez dugu `self`-ri idazten ezta erreferentzia aldaezin bati itzuliko ere.
                // Horregatik, goian sortu dugun erakusle gordinak, `deque` rentzat, balio du.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// `VecDeque` garbitzen du, balio guztiak kenduz.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// `true` ematen du `VecDeque`-k emandako balioaren berdina den elementua badu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Aurreko elementuaren erreferentzia ematen du edo `None` `VecDeque` hutsik badago.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Aurreko elementuaren erreferentzia alda daiteke edo `None` `VecDeque` hutsik badago.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Atzeko elementuari erreferentzia ematen dio edo `None` `VecDeque` hutsik badago.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Atzeko elementuaren erreferentzia alda daiteke edo `None` `VecDeque` hutsik badago.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Lehenengo elementua kendu eta itzultzen du, edo `None` `VecDeque` hutsik badago.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Azken elementua `VecDeque` etik kentzen du eta itzultzen du, edo `None` hutsik badago.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Elementu bat `VecDeque` rako aurrezten du.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Elementu bat gehitzen du `VecDeque` ren atzealdean.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: `head == 0` esan beharko genuke
        // `self` aldamenean dagoela?
        self.tail <= self.head
    }

    /// Elementu bat `VecDeque` edozein lekutatik kentzen du eta itzultzen du, lehen elementuarekin ordezkatuz.
    ///
    ///
    /// Honek ez du ordenamendua gordetzen, baina *O*(1) da.
    ///
    /// `None` ematen du `index` mugetatik kanpo badago.
    ///
    /// 0 indizeko elementua ilararen aurrealdea da.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Elementu bat `VecDeque` edozein lekutatik kentzen du eta itzultzen du, azken elementuarekin ordezkatuz.
    ///
    ///
    /// Honek ez du ordenamendua gordetzen, baina *O*(1) da.
    ///
    /// `None` ematen du `index` mugetatik kanpo badago.
    ///
    /// 0 indizeko elementua ilararen aurrealdea da.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Elementu bat txertatzen du `index`-n `VecDeque` barruan, eta `index`-ren berdina edo berdina duten indize guztiak atzera aldatzen ditu.
    ///
    ///
    /// 0 indizeko elementua ilararen aurrealdea da.
    ///
    /// # Panics
    ///
    /// Panics `index` `VecDeque`-ren luzera baino handiagoa bada
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Mugitu eraztun bufferreko elementu kopuru txikiena eta sartu emandako objektua
        //
        // Gehienez len/2, 1 elementu mugituko dira. O(min(n, n-i))
        //
        // Hiru kasu nagusi daude:
        //  Elementuak aldamenean daude
        //      - kasu berezia buztana 0 denean Elementuak etengabeak dira eta txertaketa buztana atalean dago Elementuak ez dira berdinak eta txertaketa buruaren atalean dago
        //
        //
        // Horietako bakoitzerako beste bi kasu daude:
        //  Txertatu isatsetik gertuago Txertatu burutik gertuago dago
        //
        // Gakoa: H, self.head
        //      T, self.tail o, Baliozko I elementua, A txertatzeko elementua, M txertatze-puntuaren ondoren egon beharko litzatekeen elementua, Elementua mugitu dela adierazten du
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [A oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // aldamenean, txertatu isatsetik gertu:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // aldamenean, txertatu isatsetik gertuago eta isatsa 0 da:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Dagoeneko isatsa mugitu dugu, beraz `index - 1` elementuak bakarrik kopiatzen ditugu.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // mugakideak, burutik gertuago sartu:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // desegokia, txertatu isatsetik gertuago, isatsaren sekzioa:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // desegokia, txertatu burutik gertuago, isatsaren atala:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // kopiatu elementuak buru berrira arte
                    self.copy(1, 0, self.head);

                    // kopiatu azken elementua bufferraren behealdeko leku hutsean
                    self.copy(0, self.cap() - 1, 1);

                    // eraman elementuak idx-etik aurrera amaitzeko ^ elementua barne
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // desegokia, txertatu isatsetik, buruaren ataletik gertuago dago, eta zero indizean dago barne bufferrean:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // kopiatu elementuak buztana berrira arte
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kopiatu azken elementua bufferraren behealdeko leku hutsean
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // desegokia, txertatu isatsetik gertuago, buruaren sekzioa:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // kopiatu elementuak buztana berrira arte
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kopiatu azken elementua bufferraren behealdeko leku hutsean
                    self.copy(self.cap() - 1, 0, 1);

                    // mugitu elementuak idx-1 tik aurrera amaitzeko ^ elementua barne
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // desegokia, txertatu burutik gertuago, burua atalean:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // buztana aldatu egin zitekeen, beraz, berriro kalkulatu behar dugu
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// `index` elementua `VecDeque`-tik kentzen eta itzultzen du.
    /// Kentzeko puntutik gertuago dagoen muturra lekua egiteko mugituko da eta kaltetutako elementu guztiak posizio berrietara eramango dira.
    ///
    /// `None` ematen du `index` mugetatik kanpo badago.
    ///
    /// 0 indizeko elementua ilararen aurrealdea da.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Hiru kasu nagusi daude:
        //  Elementuak elkarren ondoan daude Elementuak ez dira bereizi eta kentzea buztan atalean dago Elementuak ez dira bereizi eta kentzea buruko atalean dago.
        //
        //      - kasu berezia elementuak teknikoki aldamenean daudenean, baina self.head =0
        //
        // Horietako bakoitzerako beste bi kasu daude:
        //  Txertatu isatsetik gertuago Txertatu burutik gertuago dago
        //
        // Gakoa: H, self.head
        //      T, self.tail o, X balio duen elementua, R kentzeko markatutako elementua, M kentzen ari den elementua adierazten du, Elementua mugitu dela adierazten du
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // aldamenean, kendu isatsetik gertu:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // aldamenean, burutik hurbilago kendu:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // desegokia, kendu isatsetik gertuago, isatsaren atala:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // desegokia, kendu burutik gertuago, buruaren atala:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // desegokia, kendu burutik gertuago, isatsaren atala:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // edo ia deskontinua, kendu buruaren ondoan, buztana atalean:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // marraztu isats atalean elementuak
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Azpiegitura eragozten du.
                    if self.head != 0 {
                        // kopiatu lehen elementua leku hutsera
                        self.copy(self.cap() - 1, 0, 1);

                        // buruko ataleko elementuak atzera mugitu
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // desegokia, kendu isatsetik gertu, buruaren sekzioa:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // marraztu elementuak idx arte
                    self.copy(1, 0, idx);

                    // kopiatu azken elementua leku hutsera
                    self.copy(0, self.cap() - 1, 1);

                    // mugitu elementuak isatsetik aurrera amaitzeko, azkena kenduta
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// `VecDeque` bitan zatitzen du emandako indizean.
    ///
    /// Esleitu berri den `VecDeque` itzultzen du.
    /// `self` `[0, at)` elementuak ditu eta itzulitako `VecDeque` ak `[at, len)` elementuak ditu.
    ///
    /// Kontuan izan `self` ren edukiera ez dela aldatzen.
    ///
    /// 0 indizeko elementua ilararen aurrealdea da.
    ///
    /// # Panics
    ///
    /// Panics `at > len` bada.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` lehen zatian dago.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // bigarren zati guztia hartu besterik ez duzu.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` bigarren zatian dago, lehen zatian saltatu ditugun elementuak hartu behar ditugu kontuan.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Garbitu bufferren muturrak dauden tokian
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// `other`-ren elementu guztiak `self`-ra mugitzen ditu, `other` hutsik utziz.
    ///
    /// # Panics
    ///
    /// Panics norberaren elementu kopuru berriak `usize` gainezka egiten badu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // inozo impl
        self.extend(other.drain(..));
    }

    /// Predikatuak zehaztutako elementuak soilik gordetzen ditu.
    ///
    /// Beste modu batera esanda, ezabatu `e` elementu guztiak, `f(&e)`-ek faltsua itzultzeko moduan.
    /// Metodo honek bere tokian funtzionatzen du, elementu bakoitza jatorrizko ordenan behin bisitatzen du eta atxikitako elementuen ordena gordetzen du.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Ordena zehatza erabilgarria izan daiteke kanpoko egoeraren jarraipena egiteko, aurkibide bat bezala.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Honek panic edo abortatu dezake
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Bufferraren tamaina bikoiztu.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// `VecDeque` tokian aldatzen du `len()` `new_len` berdina izan dadin, atzeko gehiegizko elementuak kenduz edo `generator` atzeko aldean sortutako elementuak gehituz.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Deque honen barneko biltegia berrantolatzen du, beraz, ondoko xerra bat da, gero itzultzeko.
    ///
    /// Metodo honek ez du esleitzen eta ez du txertatutako elementuen ordena aldatzen.Alda daitekeen xerra itzultzen duenez, deque bat ordenatzeko erabil daiteke.
    ///
    /// Barruko biltegiratzea aldamenean dagoenean, [`as_slices`] eta [`as_mut_slices`] metodoek `VecDeque` ren eduki osoa zati bakarrean itzuliko dute.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Deque baten edukia ordenatzea.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // deque-a ordenatzen
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // alderantzizko ordenan ordenatuz
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Ondoko zatira sarbide aldaezina lortzen.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // orain ziurtatu dezakegu `slice`-k deque-ren elementu guztiak dituela, `buf`-era sarbide aldaezina duela.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // isatsa aldi berean kopiatzeko nahikoa leku libre dago, horrek esan nahi du burua atzerantz mugitzen dugula, eta ondoren isatsa kokatzen dugula.
            //
            //
            // igorlea: DEFGH .... ABC
            // nori: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Gaur egun ez dugu kontuan hartzen .... ABCDEFGH
            // mugakide izatea, kasu honetan `head` `0` izango litzatekeelako.
            // Ziurrenik hau aldatu nahi dugun arren, ez da hutsala, zenbait lekutan `is_contiguous`-k `buf[tail..head]` erabiliz xerra dezakegula esan nahi baitu.
            //
            //

            // nahikoa leku libre dago burua aldi berean kopiatzeko, horrek esan nahi du lehenik isatsa aurrera mugitzen dugula, eta gero burua posizio egokira kopiatzen dugula.
            //
            //
            // igorlea: FGH .... ABCDE
            // nori: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // librea burua eta isatsa baino txikiagoa da, horrek esan nahi du isatsa eta burua "swap" poliki-poliki egin behar ditugula.
            //
            //
            // nondik: EFGHI ... ABCD edo HIJK.ABCDEFG
            // nori: ABCDEFGHI ... edo ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Arazo orokorrak GHIJKLM ... ABCDEF honen itxura du, edozein truke egin aurretik ABCDEFM ... GHIJKL, truke 1 pasatu ondoren ABCDEFGHIJM ... KL, trukatu ezkerreko edge tenperatura dendara iritsi arte.
                //                  - ondoren, berrabiarazi algoritmoa (smaller) biltegi berri batekin. Batzuetan tenperatura biltegira iristen da edge egokia bufferraren amaieran dagoenean, horrek esan nahi du truke gutxiagorekin lortu dugula ordena egokia!
                //
                // E.g
                // EF..ABCD ABCDEF .., amaitu ditugun lau truke bakarrik egin ondoren
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Bikoitza den `mid` ilarak ezkerrera biratzen ditu.
    ///
    /// Equivalently,
    /// - `mid` elementua lehen posiziora biratzen du.
    /// - `mid` lehen elementuak atera eta amaierara bultzatzen ditu.
    /// - `len() - mid` lekuak biratzen ditu eskuinera.
    ///
    /// # Panics
    ///
    /// `mid` `len()` baino handiagoa bada.
    /// Kontuan izan `mid == len()`-k _not_ panic egiten duela eta operazio gabeko biraketa dela.
    ///
    /// # Complexity
    ///
    /// `*O*(min(mid, len() - mid))` denbora behar du eta ez du aparteko lekurik.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// `k` kokapen bikoitzeko ilara eskuinera biratzen du.
    ///
    /// Equivalently,
    /// - Lehenengo elementua `k` posiziora biratzen du.
    /// - `k` azken elementuak atera eta aurrealdera bultzatzen ditu.
    /// - `len() - k` lekuak biratzen ditu ezkerrera.
    ///
    /// # Panics
    ///
    /// `k` `len()` baino handiagoa bada.
    /// Kontuan izan `k == len()`-k _not_ panic egiten duela eta operazio gabeko biraketa dela.
    ///
    /// # Complexity
    ///
    /// `*O*(min(k, len() - k))` denbora behar du eta ez du aparteko lekurik.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // SEGURTASUNA: bi metodo hauek biraketa zenbatekoa izatea eskatzen dute
    // deque-aren luzeraren erdia baino txikiagoa izan.
    //
    // `wrap_copy` `min(x, cap() - x) + copy_len <= cap()` hori eskatzen du, baina `min` baino inoiz ez da edukiera erdia baino gehiago, x edozein dela ere, beraz, deitzea soinua da hemen luzeraren erdia baino zerbait gutxiagorekin deitzen ari garelako, inoiz ez baita edukiera erdiaren gainetik.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Bitarrek `VecDeque` ordenatutako elementu honen bila egiten du.
    ///
    /// Balioa aurkitzen bada [`Result::Ok`] itzuliko da, bat datorren elementuaren aurkibidearekin.
    /// Partida bat baino gehiago badaude, partidaren bat itzul daiteke.
    /// Balioa aurkitzen ez bada [`Result::Err`] itzultzen da, ordenatutako ordenari eutsiz bat datorren elementua txerta daitekeen indizea duena.
    ///
    ///
    /// # Examples
    ///
    /// Lau elementuz osatutako multzoa bilatzen du.
    /// Lehenengoa aurkitzen da, zehazki zehaztutako posizioarekin;bigarrena eta hirugarrena ez dira aurkitzen;laugarrena `[1, 4]`-ko edozein posiziorekin bat etor daiteke.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Elementu bat `VecDeque` ordenatu batean txertatu nahi baduzu, ordenatzeko ordena mantenduz:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Bitarrek `VecDeque` ordenatu honetan bilatzen du konparazio funtzioarekin.
    ///
    /// Konparazio funtzioak azpiko `VecDeque` ordenatzeko ordenarekin bat datorren ordena ezarri beharko luke, bere argumentua nahi den xedea baino `Less`, `Equal` edo `Greater` den adierazten duen eskaera kodea itzultzeko.
    ///
    ///
    /// Balioa aurkitzen bada [`Result::Ok`] itzuliko da, bat datorren elementuaren aurkibidearekin.Partida bat baino gehiago badaude, partidaren bat itzul daiteke.
    /// Balioa aurkitzen ez bada [`Result::Err`] itzultzen da, ordenatutako ordenari eutsiz bat datorren elementua txerta daitekeen indizea duena.
    ///
    /// # Examples
    ///
    /// Lau elementuz osatutako multzoa bilatzen du.Lehenengoa aurkitzen da, zehazki zehaztutako posizioarekin;bigarrena eta hirugarrena ez dira aurkitzen;laugarrena `[1, 4]`-ko edozein posiziorekin bat etor daiteke.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Bitarrek `VecDeque` ordenatu honetan bilatzen du tekla erauzteko funtzio batekin.
    ///
    /// `VecDeque` teklaren arabera ordenatuta dagoela suposatzen du, adibidez [`make_contiguous().sort_by_key()`](#method.make_contiguous)-rekin tekla erauzketa funtzio bera erabiliz.
    ///
    ///
    /// Balioa aurkitzen bada [`Result::Ok`] itzuliko da, bat datorren elementuaren aurkibidearekin.
    /// Partida bat baino gehiago badaude, partidaren bat itzul daiteke.
    /// Balioa aurkitzen ez bada [`Result::Err`] itzultzen da, ordenatutako ordenari eutsiz bat datorren elementua txerta daitekeen indizea duena.
    ///
    /// # Examples
    ///
    /// Lau elementuren multzoa bilatzen du bigarren elementuen arabera sailkatutako bikote zatitan.
    /// Lehenengoa aurkitzen da, zehazki zehaztutako posizioarekin;bigarrena eta hirugarrena ez dira aurkitzen;laugarrena `[1, 4]`-ko edozein posiziorekin bat etor daiteke.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// `VecDeque` tokian aldatzen du `len()` new_len berdina izan dadin, gehiegizko elementuak atzeko aldetik kenduz edo `value` klonak atzeko aldean erantsiz.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Elementu logikoen indize jakin baten azpiko bufferreko indizea itzultzen du.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // tamaina 2ko potentzia da beti
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Kalkulatu bufferrean irakurri beharreko elementu kopurua
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // tamaina 2ko potentzia da beti
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Beti hiru ataletan zatigarria, adibidez: norbera: [a b c|d e f] beste: [0 1 2 3|4 5] aurrealdea=3, erdikoa=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Ezin da Hash::hash_slice erabili as_slices metodoaren bidez itzultzen diren zatietan, haien luzera bestela berdinak diren dekeetan alda baitaiteke.
        //
        //
        // Hasher-ek deien multzo berdinaren baliokidetasuna soilik bermatzen du bere metodoekin.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// `VecDeque` aurrez aurreko iteratzaile gisa kontsumitzen du, elementuak balioaren arabera emanez.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Funtzio honen baliokide morala izan beharko luke:
        //
        //      iter.into_iter() {} elementurako
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Bihurtu [`Vec<T>`] [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Horrek ahal den neurrian birkokatzea saihesten du, baina horretarako baldintzak zorrotzak dira eta aldatu egin daitezke, eta, beraz, ez dira fidagarriak izan behar `Vec<T>` `From<VecDeque<T>>`-etik etorri eta birkokatu ez bada behintzat.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Ez dago egiazko esleipenik ZSTek edukieraz kezkatzeko, baina `VecDeque`-k ezin du `Vec` bezainbeste luzera kudeatu.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Neurriaren tamaina aldatu behar dugu edukiera ez bada bi potentzia, txikiegia edo gutxienez espazio libre bat ez badu.
            // `Vec`-en dagoen bitartean egiten dugu, beraz, elementuak panic-n jaitsi egingo dira.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Bihurtu [`VecDeque<T>`] [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Honek ez du berriro esleitu beharrik, baina datuen mugimendua *O*(*n*) egin behar du buffer zirkularra esleipenaren hasieran gertatzen ez bada.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Hau *O*(1) da.
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Honek datuak berrantolatu behar ditu.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}