//! Lehentasunezko ilara bitar metarekin inplementatuta.
//!
//! Elementu handiena txertatzeak eta ateratzeak *O*(log(*n*)) denbora konplexutasuna dute.
//! Elementu handiena egiaztatzea *O*(1) da.vector pila bitar bihurtzea lekuan bertan egin daiteke, eta *O*(*n*) konplexutasuna du.
//! Pila bitar bat vector sailkatuta bihur daiteke lekuan,*O*(*n*\*log(* n*)) lekuan dagoen pisu handian erabiltzeko aukera ematen du.
//!
//! # Examples
//!
//! Hau [Dijkstra's algorithm][dijkstra] inplementatzen duen adibide handiagoa da [shortest path problem][sssp] [directed graph][dir_graph] batean ebazteko.
//!
//! [`BinaryHeap`] mota pertsonalizatuekin nola erabili erakusten du.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Lehentasunezko ilara `Ord` ren araberakoa da.
//! // Ezarri trait esplizituki, beraz, ilara max-heap ordez min-metaketa bihurtuko da.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Kontuan izan eskaerak kostuei buelta ematen diegula.
//!         // Berdinketaren kasuan posizioak alderatzen ditugu, urrats hau beharrezkoa da `PartialEq` eta `Ord` inplementazioak bateragarriak izan daitezen.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` inplementatu behar da.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Nodo bakoitza `usize` gisa irudikatzen da, inplementazio laburragoa lortzeko.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dijkstra-ren bide algoritmo laburrena.
//!
//! // Hasi `start`-n eta erabili `dist` nodo bakoitzerako uneko distantzia motzena jarraitzeko.Inplementazio hau ez da memoria eraginkorra, bikoiztutako nodoak ilaran utz ditzakeelako.
//! //
//! // `usize::MAX` ere erabiltzen du sentinela balio gisa, inplementazio errazagoa lortzeko.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [nodo]= `start`-tik `node`-ra dagoen distantziarik txikiena
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // `start`-n gaude, zero kostuarekin
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Aztertu muga kostu txikiagoko nodoekin lehenik (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Bestela, bide motzenak aurkitzen jarrai genezake
//!         if position == goal { return Some(cost); }
//!
//!         // Garrantzitsua da dagoeneko modu hobea aurkitu dugulako
//!         if cost > dist[position] { continue; }
//!
//!         // Lortu dezakegun nodo bakoitzeko, ikusi nodo honetatik kostu txikiagoa duen modurik aurkitzen dugun
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Hala bada, gehitu mugan eta jarraitu
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Erlaxazioa, orain modu hobea aurkitu dugu
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Helburua ezin da iritsi
//!     None
//! }
//!
//! fn main() {
//!     // Hau da erabiliko dugun grafiko zuzena.
//!     // Nodoen zenbakiak egoera desberdinei dagozkie, eta edge pisuek nodo batetik bestera mugitzearen kostua sinbolizatzen dute.
//!     //
//!     // Kontuan izan ertzak noranzko bakarrekoa direla.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Grafikoa aldameneko zerrenda gisa adierazten da, non indize bakoitzak, nodo balio bati dagokiona, irteerako ertz zerrenda bat duen.
//!     // Eraginkortasunagatik aukeratua.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // 0 nodoa
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // 1. nodoa
//!         vec![Edge { node: 3, cost: 2 }],
//!         // 2. nodoa
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // 3. nodoa
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // 4. nodoa
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Lehentasunezko ilara bitar metarekin inplementatuta.
///
/// Hau max-pila izango da.
///
/// Elementu baten logika-akatsa da, horrela, `Ord` trait-k zehazten duen moduan, elementua beste edozein elementurekin alderatuta ordenatzea aldatzen da, pilan dagoen bitartean.
///
/// Hau normalean `Cell`, `RefCell`, egoera globala, I/O edo kode ez seguruen bidez soilik posible da.
/// Akats logiko horren ondorioz sortutako portaera ez da zehazten, baina ez du definitu gabeko jokabiderik sortuko.
/// Honek panics, emaitza okerrak, abortuak, memoria ihesak eta ez amaitzea izan ditzake.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Mota ondorioztatzeak mota sinadura esplizitua alde batera uzten digu (adibide honetan `BinaryHeap<i32>` izango litzateke).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Peek erabil dezakegu pilako hurrengo elementua ikusteko.
/// // Kasu honetan, oraindik ez dago elementurik, beraz, bat ere ez dugu lortuko.
/// assert_eq!(heap.peek(), None);
///
/// // Gehi ditzagun partitura batzuk ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Orain begiratzeak pilako elementurik garrantzitsuena erakusten du.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Pila baten luzera egiaztatu dezakegu.
/// assert_eq!(heap.len(), 3);
///
/// // Pilako elementuen gainean errepika dezakegu, nahiz eta ausazko ordenan itzultzen diren.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Partitura hauek ateratzen baditugu, ordenan itzuli beharko lirateke.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Gainerako elementuen pila garbitu dezakegu.
/// heap.clear();
///
/// // Pilak hutsik egon beharko luke.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// `std::cmp::Reverse` edo `Ord` inplementazio pertsonalizatua erabil daiteke `BinaryHeap` min-metaketa bihurtzeko.
/// Horrek `heap.pop()`-k balio txikiena itzultzen du handienaren ordez.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Itzulbiratu balioak `Reverse`-n
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Puntuazio hauek orain ateratzen baditugu, alderantzizko ordenan itzuli beharko lirateke.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Denboraren konplexutasuna
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// `push` ren balioa espero den kostua da;metodoaren dokumentazioak azterketa zehatzagoa ematen du.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Egiturak `BinaryHeap` bateko elementu handienaren erreferentzia aldakorra biltzen du.
///
///
/// `struct` hau X002 X 02X metodoaren bidez sortzen da.
/// Ikusi bere dokumentazioa gehiago lortzeko.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // SEGURTASUNA: PeekMut hutsik ez dauden piletarako bakarrik sortzen da.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SEGURUA: PeekMut hutsik ez dauden piletarako bakarrik sortzen da
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SEGURUA: PeekMut hutsik ez dauden piletarako bakarrik sortzen da
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Aztertutako balioa pilatik kentzen du eta itzultzen du.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// `BinaryHeap<T>` huts bat sortzen du.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// `BinaryHeap` huts bat sortzen du max-pila gisa.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// `BinaryHeap` huts bat sortzen du edukiera zehatz batekin.
    /// Honek `capacity` elementuetarako memoria nahikoa esleitzen du, beraz, `BinaryHeap` ez da birkokatu beharrik gutxienez balio asko eduki arte.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Bitariko metakako elementurik handienaren erreferentzia aldakorra edo `None` hutsik badago ematen du.
    ///
    /// Note: `PeekMut` balioa filtratzen bada, baliteke bateria egoera koherentean egotea.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Denboraren konplexutasuna
    ///
    /// Elementua aldatzen bada, kasuetan okerrena konplexutasuna *O*(log(*n*)) da, bestela *O*(1) da.
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Elementu handiena bitar metatik kentzen du eta itzultzen du, edo `None` hutsik badago.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Denboraren konplexutasuna
    ///
    /// `pop` ren kosturik okerrena *n* elementuak dituen pila batean *O*(log(*n*)) da.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // SEGURTASUNA: !self.is_empty()-k self.len()> 0 dela esan nahi du
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Elementu bat pila bitarrean sartzen du.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Denboraren konplexutasuna
    ///
    /// `push` ren aurreikusitako kostua, bultzatzen ari diren elementuen ordenaketa posible guztien batez bestekoa eta bultzada kopuru nahikoa handia izanda,*O*(1) da.
    ///
    /// Hau da kostu-metrikarik esanguratsuena lehendik inolako ordenatutako eredutan *ez* dauden elementuak bultzatzerakoan.
    ///
    /// Denboraren konplexutasuna degradatzen da elementuak goranzko ordenan bultzatzen badira.
    /// Kasurik okerrenean, elementuak orden ordenatu goranzkoan bultzatzen dira eta bultzada bakoitzeko kostu amortizatua *O*(log(*n*)) da *n* elementuak dituen pila baten aurka.
    ///
    /// `push`-era dei bakar baten *kasurik okerrena* O *(* n *) da.Kasurik okerrena edukiera agortu eta tamaina aldatu behar denean gertatzen da.
    /// Aldaketaren kostua aurreko irudietan amortizatu da.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // SEGURTASUNA: Elementu berri bat bultzatu genuenez, horrek esan nahi du
        //  zahar_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// `BinaryHeap` kontsumitzen du eta vector itzultzen du (ascending) ordenan ordenatuta.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SEGURTASUNA: `end` `self.len() - 1`-tik 1-era doa (biak barne),
            //  beraz, beti sartzeko balio duen indizea da.
            //  0 indizea (hau da, `ptr`) atzitzea segurua da, izan ere
            //  1 <=end <self.len(), hau da, self.len()>=2 esan nahi du.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SEGURTASUNA: `end` `self.len() - 1`-tik 1-ra doa (biak barne) beraz:
            //  0 <1 <=amaiera <= self.len(), 1 <self.len() Horrek esan nahi du 0 <amaiera eta amaiera <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Sift_up eta sift_down inplementazioek bloke ez-seguruak erabiltzen dituzte elementu bat vector-etik kanpora ateratzeko (zulo bat atzean utzita), besteekin batera aldatzeko eta kendutako elementua berriro vector-ra zuloaren azken kokapenera eramateko.
    //
    // Hau irudikatzeko `Hole` mota erabiltzen da eta ziurtatu zuloa bere esparruaren amaieran betetzen dela, baita panic-n ere.
    // Zulo bat erabiltzeak faktore konstantea murrizten du trukeak erabiltzearekin alderatuta, horrek mugimendu bikoitza suposatzen du.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Deitzaileak `pos < self.len()` hori bermatu behar du.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Atera balioa `pos`-n eta sortu zulo bat.
        // SEGURTASUNA: Deitzaileak pos <self.len() bermatzen duela
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // SEGURTASUNA: hole.pos()> start>=0, hau da, hole.pos()> 0 esan nahi du
            //  eta, beraz, hole.pos(), 1 ezin da gainezka egin.
            //  Honek guraso <hole.pos() hori bermatzen du, beraz, baliozko indizea da eta gainera!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SEGURTASUNA: Aurrekoaren berdina
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Hartu elementu bat `pos`-n eta mugitu pilatik behera, bere seme-alabak handiagoak diren bitartean.
    ///
    ///
    /// # Safety
    ///
    /// Deitzaileak `pos < end <= self.len()` hori bermatu behar du.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // SEGURTASUNA: Deitzaileak pos <end <= self.len() bermatzen du.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop aldaezina: child==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // alderatu bi haurren artean SEGURTASUN handienarekin: child <end, 1 <self.len() eta child + 1 <end <= self.len(), beraz, baliozko indizeak dira.
            //
            //  umea==2 *hole.pos() + 1!= hole.pos() eta umea + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 edo 2* hole.pos() + 2 gainezka egin dezake T ZST bada
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // dagoeneko ordenatuta bagaude, gelditu.
            // SEGURTASUNA: orain haurra haur zaharra edo haur zaharra + 1 da
            //  Dagoeneko frogatu dugu biak <self.len() eta!= hole.pos() direla
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SEGURTASUNA: aurrekoaren berdina.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SEGURTASUNA: &&zirkuitulaburra, horrek esan nahi du
        //  bigarren baldintza dagoeneko egia da==end, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SEGURTASUNA: dagoeneko frogatuta dago haurra baliozko indizea dela eta
            //  umea==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Deitzaileak `pos < self.len()` hori bermatu behar du.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SEGURTASUNA: pos <len deitzaileak eta
        //  jakina len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Hartu elementu bat `pos`-n eta mugitu zulotik behera, eta, ondoren, baheta ezazu bere posiziora.
    ///
    ///
    /// Note: Hau azkarragoa da elementua handia dela jakiten denean/behetik gertuago egon behar du.
    ///
    /// # Safety
    ///
    /// Deitzaileak `pos < self.len()` hori bermatu behar du.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SEGURTASUNA: Deitzaileak pos <self.len() bermatzen duela.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop aldaezina: child==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // SEGURTASUNA: child <end, 1 <self.len() and
            //  child + 1 <end <= self.len(), beraz baliozko indizeak dira.
            //  umea==2 *hole.pos() + 1!= hole.pos() eta umea + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 edo 2* hole.pos() + 2 gainezka egin dezake T ZST bada
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SEGURTASUNA: Aurrekoaren berdina
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SEGURTASUNA: child==end, 1 <self.len(), beraz baliozko indizea da
            //  eta haurra==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // SEGURTASUNA: pos zuloan dagoen posizioa da eta dagoeneko frogatuta zegoen
        //  baliozko indizea izateko.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SEGURTASUNA: n self.len()/2-tik hasi eta 0ra jaisten da.
            //  Kasu bakarra! (N <self.len()) denean self.len() ==0 bada, baina begizta baldintzak baztertzen du.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// `other`-ren elementu guztiak `self`-ra mugitzen ditu, `other` hutsik utziz.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` O(len1 + len2) eragiketak eta 2 *(len1 + len2) inguru konparazioak hartzen ditu kasurik txarrenean `extend` ek O(len2* log(len1)) eragiketak eta 1 *len2* log_2(len1) konparazioak kasurik txarrenean, len1>= len2 suposatuz.
        // Pilak handiagoak direnean, gurutzaketa puntuak ez du arrazoiketa hau jarraitzen eta enpirikoki zehaztu da.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Elementuak metaketa ordenan berreskuratzen dituen iteratzailea itzultzen du.
    /// Berreskuratutako elementuak jatorrizko pilatik kentzen dira.
    /// Gainerako elementuak jaregiten direnean kendu egingo dira, ordenan.
    ///
    /// Note:
    /// * `.drain_sorted()` *O* da (*n*\*log(* n*)); `.drain()` baino askoz motelagoa da.
    ///   Azken hau kasu gehienetan erabili beharko zenuke.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // elementu guztiak zatikako ordenan kentzen ditu
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Predikatuak zehaztutako elementuak soilik gordetzen ditu.
    ///
    /// Beste era batera esanda, kendu `e` elementu guztiak, `f(&e)`-ek `false` itzultzeko moduan.
    /// Elementuak ordenatu gabeko (eta zehaztu gabe) ordenan bisitatzen dira.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // zenbaki bikoitiak soilik gorde
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Itzultzaile bat itzultzen du azpiko vector balio guztiak bisitatzen, orden arbitrarioan.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Inprimatu 1, 2, 3, 4 orden arbitrarioan
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Elementuak metaketa ordenan berreskuratzen dituen iteratzailea itzultzen du.
    /// Metodo honek jatorrizko metaketa kontsumitzen du.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Multzo bitarreko elementurik handiena itzultzen du edo `None` hutsik badago.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Denboraren konplexutasuna
    ///
    /// Kostua *O*(1) da kasurik okerrenean.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Bitar metak birkokatu gabe eduki ditzakeen elementu kopurua itzultzen du.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Emandako `BinaryHeap`-an zehazki `additional` elementu gehiago sartzeko gutxieneko edukiera gordetzen du.
    /// Ez du ezer egiten dagoeneko edukiera nahikoa bada.
    ///
    /// Kontuan izan esleitzaileak bildumari eskatzen diona baino leku gehiago eman diezaiokeela bildumari.
    /// Hori dela eta, ezin da gaitasuna hain txikia izan.
    /// Nahiago [`reserve`] future txertatzeak espero badira.
    ///
    /// # Panics
    ///
    /// Panics edukiera berriak `usize` gainezka egiten badu.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// `BinaryHeap`-n txertatzeko gutxienez `additional` elementu gehiagorako edukiera gordetzen du.
    /// Bildumak leku gehiago gorde dezake maiz birkokapenik ez izateko.
    ///
    /// # Panics
    ///
    /// Panics edukiera berriak `usize` gainezka egiten badu.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Ahalik eta ahalmen gehigarri gehiena baztertzen du.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Beheko mugarekin edukiera baztertzen du.
    ///
    /// Edukiera gutxienez luzera eta hornitutako balioa bezain handia izango da.
    ///
    ///
    /// Uneko ahalmena beheko muga baino txikiagoa bada, hau ez da op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// `BinaryHeap` kontsumitzen du eta azpian dagoen vector ordena arbitrarioan itzultzen du.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Ordena batzuk inprimatuko ditu
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Mila bitarraren luzera itzultzen du.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Mila bitarra hutsik dagoen egiaztatzen du.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Metodo bitarra garbitu, iteratzailea kendutako elementuen gainean itzuliz.
    ///
    /// Elementuak modu arbitrarioan kentzen dira.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Elementu guztiak bitar-metatik uzten ditu.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Zuloak xerra bateko zuloa adierazten du, hau da, baliozko balio gabeko indizea (mugitu edo bikoiztu egin delako).
///
/// Jaitsieran, `Hole`-k xerra leheneratuko du zuloaren posizioa jatorriz kendutako balioarekin betez.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Sortu `Hole` berria `pos` indizean.
    ///
    /// Ez da segurua pos posizioak datu zatian egon behar delako.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SEGURUA: posak xerra barruan egon behar du
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Kendutako elementuaren erreferentzia ematen du.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Elementuaren erreferentzia `index`-n ematen du.
    ///
    /// Ez da segurua, indizeak datu zatiaren barruan egon behar du eta ez du pos berdina.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Eraman zuloa kokapen berrira
    ///
    /// Ez da segurua, indizeak datu zatiaren barruan egon behar du eta ez du pos berdina.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // bete berriro zuloa
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// `BinaryHeap` baten elementuen gaineko iteratzailea.
///
/// `struct` hau [`BinaryHeap::iter()`]-k sortu du.
/// Ikusi bere dokumentazioa gehiago lortzeko.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Kendu `#[derive(Clone)]` ren alde
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// `BinaryHeap` baten elementuen gaineko iteratzaile jabea.
///
/// `struct` hau [`BinaryHeap::into_iter()`]-k sortu du (`IntoIterator` trait-k eskaintzen du).
/// Ikusi bere dokumentazioa gehiago lortzeko.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// `BinaryHeap` baten elementuen gaineko drainatze iteratzailea.
///
/// `struct` hau [`BinaryHeap::drain()`]-k sortu du.
/// Ikusi bere dokumentazioa gehiago lortzeko.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// `BinaryHeap` baten elementuen gaineko drainatze iteratzailea.
///
/// `struct` hau [`BinaryHeap::drain_sorted()`]-k sortu du.
/// Ikusi bere dokumentazioa gehiago lortzeko.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Pilatze elementuak pilatzen ditu ordenan.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// `Vec<T>` `BinaryHeap<T>` bihurtzen du.
    ///
    /// Bihurketa hau lekuan bertan gertatzen da eta *O*(*n*) denbora konplexutasuna du.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// `BinaryHeap<T>` `Vec<T>` bihurtzen du.
    ///
    /// Bihurketa honek ez du datuen mugimendurik edo esleipenik behar, eta denbora konplexutasun konstantea du.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Errepikatzaile kontsumitzaile bat sortzen du, hau da, balio bakoitza pilaketa bitarretik ordena arbitrarioan ateratzen duena.
    /// Pila bitarra ezin da erabili deitu ondoren.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Inprimatu 1, 2, 3, 4 orden arbitrarioan
    /// for x in heap.into_iter() {
    ///     // x-k i32 mota du, ez &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}