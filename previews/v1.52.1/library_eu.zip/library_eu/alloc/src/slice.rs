//! Dinamikoki tamaina duen ikuspegi bat sekuentzia jarraian, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Xerra erakusle eta luzera gisa irudikatutako memoria bloke baten ikuspegia da.
//!
//! ```
//! // Vec bat zatitzea
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // array bat xerra batera behartzea
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Xerra alda daitezke edo partekatzen dira.
//! Partekatutako xerra mota `&[T]` da, eta aldakorra den xerra mota `&mut [T]` da, non `T` elementu mota adierazten duen.
//! Adibidez, zati aldakor batek seinalatzen duen memoria blokea mutatu dezakezu:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Hemen daude modulu honek dituen zenbait gauza:
//!
//! ## Structs
//!
//! Xerretarako erabilgarria diren hainbat egitura daude, esate baterako [`Iter`], xerra baten gainean errepikapena adierazten duena.
//!
//! ## Trait Inplementazioak
//!
//! X0traits0Z arrunten inplementazioak daude zatietan.Adibide batzuk honakoak dira:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], elementu mota [`Eq`] edo [`Ord`] duten zatiei dagokienez.
//! * [`Hash`] - elementu mota [`Hash`] duten zatiei dagokienez.
//!
//! ## Iteration
//!
//! Xerra `IntoIterator` inplementatzen dute.Iteratzaileak xerrako elementuen erreferentziak ematen ditu.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Xerra aldakorrak elementuen erreferentzia aldakorrak ematen ditu:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Iteratzaile honek xaflaren elementuei erreferentzia aldakorrak ematen dizkie, beraz, zatiaren elementu mota `i32` bada ere, iteratzailearen elementu mota `&mut i32` da.
//!
//!
//! * [`.iter`] eta [`.iter_mut`] dira iteratzaile lehenetsiak itzultzeko metodo esplizituak.
//! * Iteratzaileak itzultzen dituzten metodo gehiago [`.split`], [`.splitn`], [`.chunks`], [`.windows`] eta gehiago dira.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Modulu honetako erabilera asko probaren konfigurazioan bakarrik erabiltzen dira.
// Unused_imports abisua konpontzea baino garbiagoa da.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Xerra luzatzeko oinarrizko metodoak
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) beharrezkoa da NB probatzean `vec!` makroa ezartzeko, ikusi fitxategi honetako `hack` modulua xehetasun gehiagorako.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) NB probatzerakoan `Vec::clone` ezartzeko beharrezkoa, ikusi fitxategi honetako `hack` modulua xehetasun gehiagorako.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` erabilgarri ez dagoenez, hiru funtzio hauek `impl [T]` n baina `core::slice::SliceExt` n dauden metodoak dira. Funtzio hauek `test_permutations` probarako hornitu behar ditugu.
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Ez diogu inline atributurik gehitu behar honi `vec!` makroan erabiltzen baita gehienetan eta erregresio perfektua eragiten baitu.
    // Ikus #71204 eztabaida eta emaitza hobeak lortzeko.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // elementuak hasierako moduan markatu ziren beheko begizta
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) beharrezkoa da LLVM-k mugen kontrolak kentzeko eta zip baino kodeketa hobea du.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec-a goian esleitu eta hasieratu zen gutxienez luzera honetara.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // goian `s` gaitasunarekin esleituta, eta `s.len()` hasierara ptr::copy_to_non_overlapping behean.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Xerra ordenatzen du.
    ///
    /// Ordenatze hau egonkorra da (hau da, ez ditu berdin ordenatzen elementu berdinak) eta *O*(*n*\*log(* n*)) kasurik txarrena.
    ///
    /// Hala badagokio, sailkapen ezegonkorra hobesten da, orokorrean sailkapen egonkorra baino azkarragoa delako eta ez baitu memoria osagarririk esleitzen.
    /// Ikus [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Egungo ezarpena
    ///
    /// Uneko algoritmoa [timsort](https://en.wikipedia.org/wiki/Timsort)-en inspiratutako bateratze moldaketa iteratiboa da.
    /// Xerra ia ordenatuta dagoen kasuetan edo bata bestearen atzetik kateatutako bi sekuentzia edo gehiago ordenatuta dauden kasuetan oso azkarra izateko diseinatuta dago.
    ///
    ///
    /// Gainera, aldi baterako biltegiratzea `self` ren tamaina erdia esleitzen du, baina zati laburretarako esleitu gabeko txertatze-mota erabiltzen da horren ordez.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Xerra ordenatzen du konparazio funtzio batekin.
    ///
    /// Ordenatze hau egonkorra da (hau da, ez ditu berdin ordenatzen elementu berdinak) eta *O*(*n*\*log(* n*)) kasurik txarrena.
    ///
    /// Konparazio funtzioak zatiko elementuen ordenamendu osoa zehaztu behar du.Ordena osoa ez bada, elementuen ordena zehaztu gabe dago.
    /// Ordena ordena osoa da (`a`, `b` eta `c` guztientzat):
    ///
    /// * totala eta antisimetrikoa: `a < b`, `a == b` edo `a > b` bat zehazki egia da, eta
    /// * iragankorrak, `a < b` eta `b < c`-k `a < c` dakar.Gauza bera gertatu behar da `==` eta `>` kasuan.
    ///
    /// Adibidez, [`f64`]-k [`Ord`] inplementatzen ez duen bitartean `NaN != NaN` delako, `partial_cmp` erabil dezakegu gure ordenatzeko funtzio gisa zatiak `NaN` bat ez duela dakigunean.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Hala badagokio, sailkapen ezegonkorra hobesten da, orokorrean sailkapen egonkorra baino azkarragoa delako eta ez baitu memoria osagarririk esleitzen.
    /// Ikus [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Egungo ezarpena
    ///
    /// Uneko algoritmoa [timsort](https://en.wikipedia.org/wiki/Timsort)-en inspiratutako bateratze moldaketa iteratiboa da.
    /// Xerra ia ordenatuta dagoen kasuetan edo bata bestearen atzetik kateatutako bi sekuentzia edo gehiago ordenatuta dauden kasuetan oso azkarra izateko diseinatuta dago.
    ///
    /// Gainera, aldi baterako biltegiratzea `self` ren tamaina erdia esleitzen du, baina zati laburretarako esleitu gabeko txertatze-mota erabiltzen da horren ordez.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // alderantzizko sailkapena
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Xerra ordenatzen du tekla ateratzeko funtzio batekin.
    ///
    /// Ordena hau egonkorra da (hau da, ez ditu berdin ordenatzen elementu berdinak) eta *O*(*m*\* * n *\* log(*n*)) kasurik txarrenean, tekla funtzioa *O*(*m*) denean.
    ///
    /// Tekla funtzio garestietarako (adibidez
    /// jabetza sarbide soilak edo oinarrizko eragiketak ez diren funtzioak), [`sort_by_cached_key`](slice::sort_by_cached_key) litekeena da askoz ere azkarragoa izatea, ez baititu elementu teklak berriro kalkulatzen.
    ///
    ///
    /// Hala badagokio, sailkapen ezegonkorra hobesten da, orokorrean sailkapen egonkorra baino azkarragoa delako eta ez baitu memoria osagarririk esleitzen.
    /// Ikus [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Egungo ezarpena
    ///
    /// Uneko algoritmoa [timsort](https://en.wikipedia.org/wiki/Timsort)-en inspiratutako bateratze moldaketa iteratiboa da.
    /// Xerra ia ordenatuta dagoen kasuetan edo bata bestearen atzetik kateatutako bi sekuentzia edo gehiago ordenatuta dauden kasuetan oso azkarra izateko diseinatuta dago.
    ///
    /// Gainera, aldi baterako biltegiratzea `self` ren tamaina erdia esleitzen du, baina zati laburretarako esleitu gabeko txertatze-mota erabiltzen da horren ordez.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Xerra ordenatzen du tekla ateratzeko funtzio batekin.
    ///
    /// Ordenatzean, teklaren funtzioari behin bakarrik deitzen zaio elementu bakoitzeko.
    ///
    /// Ordena hau egonkorra da (hau da, ez ditu berdin ordenatzen elementu berdinak) eta *O*(*m*\* * n *+* n *\* log(*n*)) kasurik txarrenean, tekla funtzioa *O*(*m*) denean .
    ///
    /// Tekla-funtzio sinpleetarako (adibidez, jabetzako sarbide edo oinarrizko eragiketak diren funtzioak), [`sort_by_key`](slice::sort_by_key) azkarragoa izango da litekeena.
    ///
    /// # Egungo ezarpena
    ///
    /// Uneko algoritmoa Orson Peters-en [pattern-defeating quicksort][pdqsort]-n oinarritzen da, ausazko bizkortasunaren batez besteko kasu azkarra eta pisu handieneko kasurik azkarrena konbinatzen dituena, zenbait eredu dituzten zatietan denbora lineala lortuz.
    /// Zenbait ausazko erabilera erabiltzen du endekatutako kasuak ekiditeko, baina seed finkoarekin beti portaera determinista eskaintzeko.
    ///
    /// Kasurik okerrenean, algoritmoak `Vec<(K, usize)>` batean aldi baterako biltegiratzea banatzen du zatiaren luzera.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Laguntza makroa gure vector ahalik eta motarik txikienaren arabera indexatzeko, esleipena murrizteko.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices`-ren elementuak bakarrak dira, indexatuta daudenez, beraz, edozein motatako egonkorra izango da jatorrizko zatiari dagokionez.
                // Hemen `sort_unstable` erabiltzen dugu memoria esleipen gutxiago behar duelako.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self` kopiatzen du `Vec` berri batean.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Hemen, `s` eta `x` modu independentean alda daitezke.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// `self` `Vec` berri batean kopiatzen du esleitzaile batekin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Hemen, `s` eta `x` modu independentean alda daitezke.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // OHARRA, ikusi `hack` modulua fitxategi honetan xehetasun gehiagorako.
        hack::to_vec(self, alloc)
    }

    /// `self` vector bihurtzen du klonarik edo esleipenik gabe.
    ///
    /// Lortutako vector kutxa bihur daiteke `Vec bidez<T>`into_boxed_slice` metodoa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ezin da gehiago erabili `x` bihurtu delako.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // OHARRA, ikusi `hack` modulua fitxategi honetan xehetasun gehiagorako.
        hack::into_vec(self)
    }

    /// vector bat sortzen du `n` aldiz xerra bat errepikatuz.
    ///
    /// # Panics
    ///
    /// Funtzio hau panic izango da edukiera gainezka egingo balu.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic gainezkatzean:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // `n` zero baino handiagoa bada, `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` gisa zatitu daiteke.
        // `2^expn` `n`-ren ezkerreko '1' bitak adierazten duen zenbakia da, eta `rem` `n`-ren gainerako zatia da.
        //
        //

        // `Vec` erabiliz `set_len()` sartzeko.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` errepikapena `buf` `expn` aldiz bikoiztuz egiten da.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // `m > 0` bada, ezkerreko '1' bitarte bitak geratzen dira.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` edukiera du.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) errepikapena `buf` beraren lehen `rem` errepikapenak kopiatuz egiten da.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Hau ez da gainjarria `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` berdina `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T` zati bat berdintzen du `Self::Output` balio bakarrean.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// `T` zati bat berdintzen du `Self::Output` balio bakarrean, bakoitzaren banatzaile jakin bat jarriz.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// `T` zati bat berdintzen du `Self::Output` balio bakarrean, bakoitzaren banatzaile jakin bat jarriz.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Xerra horren kopia bat duen vector bat ematen du, non byte bakoitza ASCII maiuskulen baliokidearekin mapatuta dagoen.
    ///
    ///
    /// ASCII 'a'-tik 'z' letrak 'A'-tik 'Z'-ra mapatzen dira, baina ASCII ez diren letrak ez dira aldatu.
    ///
    /// Lekuan dagoen balioa maiuskulaz idazteko, erabili [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Xerra horren kopia duen vector bat ematen du, non byte bakoitza ASCII minuskulen baliokidearekin mapatuta dagoen.
    ///
    ///
    /// ASCII 'A'-tik 'Z' letrak 'a'-tik 'z'-ra mapatzen dira, baina ASCII ez diren letrak ez dira aldatu.
    ///
    /// Lekuan dagoen balioa minuskulatzeko, erabili [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// traits luzapena datu mota zehatz batzuen zatietan
////////////////////////////////////////////////////////////////////////////////

/// Helper trait for [`[T]: : concat`](slice::concat).
///
/// Note: `Item` motako parametroa ez da erabiltzen trait honetan, baina inplikazioak generikoagoak izatea ahalbidetzen du.
/// Hori gabe, errore hau lortuko dugu:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// `Borrow<[_]>` inplikazio anitzekin `V` motak egon daitezkeelako gertatzen da, hala nola `T` mota anitz aplikatuko lirateke:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Katean jarri ondoren sortzen den mota
    type Output;

    /// [`[T]: : concat`](xerra::concat) ezartzea
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Helper trait for [`[T]: : join`](xerra::batu)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Katean jarri ondoren sortzen den mota
    type Output;

    /// [`[T]: : join`] inplementazioa (xerra::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// X0trait0Z inplementazio estandarrak xerretarako
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // jaregin gainidatziko ez den helburuan
        target.truncate(self.len());

        // target.len <= self.len goiko mozketa dela eta, beraz, hemen dauden zatiak beti mugatuta daude.
        //
        let (init, tail) = self.split_at(target.len());

        // berrerabili jasotako balioak allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]` aurrez ordenatutako `v[1..]` sekuentzian txertatzen du `v[..]` osoa ordenatuta egon dadin.
///
/// Hau da txertatze ordenaren azpiprograma integrala.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Hemen txertatzeko hiru modu daude:
            //
            // 1. Aldatu ondoko elementuak lehenengoa azken helmugara iritsi arte.
            //    Hala ere, modu honetan datuak behar baino gehiago kopiatzen ditugu.
            //    Elementuak egitura handiak badira (kopiatzea garestia), metodo hau motela izango da.
            //
            // 2. Errepikatu lehen elementurako leku egokia aurkitu arte.
            // Ondoren, aldatu ondoko elementuak lekua egiteko eta, azkenean, jarri gainerako zuloan.
            // Hau metodo ona da.
            //
            // 3. Kopiatu lehen elementua aldi baterako aldagai batean.Iteratu horretarako leku egokia aurkitu arte.
            // Aurrera goazela, kopiatu zeharkatutako elementu guztiak aurreko zirrikituan.
            // Azkenean, kopiatu aldi baterako aldagaiaren datuak gainerako zuloan.
            // Metodo hau oso ona da.
            // Oinarrizko erreferentziek 2. metodoarekin baino errendimendu zertxobait hobea erakutsi zuten.
            //
            // Metodo guztiak erreferentzia egin ziren, eta hirugarrenak emaitza onenak erakutsi zituen.Beraz, hori aukeratu genuen.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Txertatze prozesuaren bitarteko egoeraren jarraipena egiten du beti `hole`-k, eta horrek bi helburu ditu:
            // 1. `v`-ren osotasuna babesten du panics-tik `is_less`-n.
            // 2. Azkenean `v`-n geratzen den zuloa betetzen du.
            //
            // Panic segurtasuna:
            //
            // `is_less` panics prozesuaren edozein unetan bada, `hole` jaitsi egingo da eta `v`-ko zuloa `tmp`-rekin beteko du, horrela `v`-k hasiera batean zituen objektu guztiak behin zehatz gordetzen dituela ziurtatuko da.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` erortzen da eta horrela `tmp` kopiatzen du `v`-ko gainerako zuloan.
        }
    }

    // Erortzen denean, `src`-tik `dest`-ra kopiatzen dira.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// `v[..mid]` eta `v[mid..]` lasterketa bateragarriak bateratzen ditu `buf` erabiliz aldi baterako biltegiratze gisa, eta emaitza `v[..]` n gordetzen du.
///
/// # Safety
///
/// Bi zatiek hutsik egon behar dute eta `mid` ek mugak izan behar dituzte.
/// `buf` bufferrak xerra laburraren kopia edukitzeko adina luzera izan behar du.
/// Gainera, `T`-k ez du zero tamainakoa izan behar.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Bateratze prozesuak lasterketa laburrena `buf` ra kopiatzen du.
    // Ondoren, kopiatu berri den ibilbidea eta luzeagoa aurrerantz (edo atzerantz) azaltzen ditu, kontsumitu gabeko hurrengo elementuak alderatuz eta txikiena (edo handiagoa) `v`-en kopiatuz.
    //
    // Epe laburragoa guztiz kontsumitu bezain laster, prozesua amaitu da.Lasterketa luzea lehenbailehen kontsumitzen bada, lasterketa laburraren geratzen dena `v`-n geratzen den zuloan kopiatu beharko dugu.
    //
    // Prozesuaren bitarteko egoeraren jarraipena egiten du beti `hole`-k, eta horrek bi helburu ditu:
    // 1. `v`-ren osotasuna babesten du panics-tik `is_less`-n.
    // 2. `v`-en geratzen den zuloa betetzen du lasterketa luzeagoa lehen kontsumitzen bada.
    //
    // Panic segurtasuna:
    //
    // `is_less` panics prozesuaren edozein unetan bada, `hole` jaitsi egingo da eta `v`-ko zuloa `buf` kontsumitu gabeko barrutiarekin beteko du, horrela `v`-ek hasieran zituen objektu guztiak behin behin gordetzen dituela ziurtatuz.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Ezkerreko lasterketa laburragoa da.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Hasieran, erakusle hauek beren arrayen hastapenak seinalatzen dituzte.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Alde txikiena kontsumitu.
            // Berdin bada, ezkerreko lasterketa nahiago egonkortasuna mantentzeko.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Korrika egokia laburragoa da.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Hasieran, erakusle hauek beren arrayen muturrak gainditzen dituzte.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Alde handiena kontsumitu.
            // Berdin bada, lasterketa egokia nahiago egonkortasuna mantentzeko.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Azkenean, `hole` erortzen da.
    // Iraupen laburrena guztiz kontsumitzen ez bada, geratzen zaion guztia `v` zuloan kopiatuko da.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Erortzen denean, `start..end` barrutia `dest..` kopiatzen du.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ez da zero tamainako mota, beraz, ondo dago bere tamainaz banatzea.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Bateratze sort honek TimSort-en ideia batzuk hartzen ditu (baina ez guztiak), [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) zehatz-mehatz deskribatzen dena.
///
///
/// Algoritmoak beheranzko eta beheranzkoak ez diren azpi-sekuentziak identifikatzen ditu, ibilbide natural deitzen direnak.Oraindik bateratu gabeko exekuzio pila dago.
/// Aurkitu berri den lasterketa bakoitza pilara bultzatzen da eta, ondoren, aldameneko lasterketa pare batzuk batu egiten dira, bi aldaera hauek bete arte:
///
/// 1. `1..runs.len()`-ko `i` bakoitzeko: `runs[i - 1].len > runs[i].len`
/// 2. `2..runs.len()`-ko `i` bakoitzeko: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Aldaezinek ziurtatzen dute denbora guztian *O* dela (*n*\*log(* n*)) kasurik txarrenean.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Luzera horretako zatiak txertatzeko ordenaren bidez ordenatuko dira.
    const MAX_INSERTION: usize = 20;
    // Oso lasterketa laburrak luzatu egiten dira txertatze-ordenaren bidez, elementu hau gutxienez hedatzeko.
    const MIN_RUN: usize = 10;

    // Ordenatzeak ez du portaera esanguratsurik zero tamainako motetan.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Matrize laburrak txertatze ordenaren bidez ordenatzen dira lekuan, esleipenak ekiditeko.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Esleitu buffer bat scratch memoria gisa erabiltzeko.0 luzera mantentzen dugu `v` edukiaren kopia sakonak gorde ahal izateko `is_less` panics bada kopietan exekutatzen diren medikuak arriskuan jarri gabe.
    //
    // Bi ordenatutako lasterketak bateratzean, buffer honek lasterketa laburrarenaren kopia gordetzen du, gehienez ere `len / 2` luzera izango duena.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v`-n ibilbide naturalak identifikatzeko, atzerantz zeharkatuko dugu.
    // Hori erabaki bitxia dela dirudi, baina kontuan hartu ohi da bateratzeak (forwards) kontrako norabidean doazela.
    // Oinarrien arabera, aurrerantz bat egitea atzerantz batzea baino zertxobait azkarragoa da.
    // Amaitzeko, lasterketak atzeraka zeharkatuz identifikatzeak errendimendua hobetzen du.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Bilatu hurrengo lasterketa naturala eta alderantzikatu zorrozki beherakorra bada.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Txertatu elementu gehiago lasterketan laburregia bada.
        // Txertatze-ordena sekuentzia laburreko bateratze-ordenaketa baino azkarragoa da, beraz, horrek errendimendua nabarmen hobetzen du.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Push run hau pilaren gainean.
        runs.push(Run { start, len: end - start });
        end = start;

        // Elkartu aldameneko lasterketa pare batzuk aldaezinak asetzeko.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Azkenean, zehazki exekuzio batek pilan egon behar du.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Lasterketa pila aztertzen du eta bateratu beharreko hurrengo lasterketa bikotea identifikatzen du.
    // Zehatzago esanda, `Some(r)` itzultzen bada, horrek esan nahi du `runs[r]` eta `runs[r + 1]` batu behar direla ondoren.
    // Algoritmoak exekuzio berri bat eraikitzen jarraitu behar badu, `None` itzuliko da.
    //
    // TimSort ezaguna da bere buggy inplementazioengatik, hemen deskribatzen den moduan:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Istorioaren funtsa honako hau da: inbarianteak betearazi behar ditugu pilako lau lasterketetan.
    // Goiko hiru horietan betearaztea ez da nahikoa inbarianteak pilako *guztiak* exekutatzen jarraituko dutela ziurtatzeko.
    //
    // Funtzio honek zuzeneko egiaztatzen ditu aldaezinak lehen lau lasterketetarako.
    // Gainera, goiko exekuzioa 0 indizean hasten bada, beti bateratze eragiketa eskatuko du pila guztiz erori arte, ordenaketa osatzeko.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}