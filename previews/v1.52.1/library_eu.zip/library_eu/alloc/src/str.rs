//! Unicode kate zatiak.
//!
//! *[See also the `str` primitive type](str).*
//!
//! `&str` mota bi kate mota nagusietako bat da, bestea `String`.
//! `String` alderdiak ez bezala, bere edukia maileguan hartzen da.
//!
//! # Oinarrizko erabilera
//!
//! `&str` motako oinarrizko kateen adierazpena:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Hemen kate literala izendatu dugu, kate zati gisa ere ezagutzen dena.
//! Kate literalek bizitza estatikoa dute, hau da, `hello_world` kateak programa osoak irauten duela balio duela ziurtatzen da.
//!
//! Esplizituki zehaztu dezakegu `hello_world`-ren bizitza ere:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Modulu honetako erabilera asko probaren konfigurazioan bakarrik erabiltzen dira.
// Unused_imports abisua konpontzea baino garbiagoa da.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` `Concat<str>`-n hemen ez da esanguratsua.
/// trait-ren parametro mota hau beste inplementazio bat gaitzeko bakarrik dago.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // kodeketa gogorreko tamainak dituzten begiztak askoz azkarrago exekutatzen dira bereizgailuen luzera txikiko kasuak espezializatzen dituzte
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // zero ez den tamaina atzerakoi arbitrarioa
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Bi Vec-entzat funtzionatzen duen bateratze-inplementazio optimizatua<T>(T: Kopiatu) eta String-en barruko vec Une honetan (2018-05-13) akats bat dago mota inferentziarekin eta espezializazioarekin (ikus #36262 alea) Horregatik SliceConcat<T>ez dago espezializatuta T: Copy eta SliceConcat-entzat<str>da funtzio honen erabiltzaile bakarra.
// Lekuan uzten da hori konpontzen den momenturako.
//
// String-join-aren mugak S dira: maileguan hartu<str>eta Vec-join maileguan <[T]> [T] eta str biak AsRef <[T]> inplikatzen dute T batzuentzat
// => s.borrow().as_ref() eta beti ditugu xerra
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // lehen xerra da aurretik bereizgailurik ez duen bakarra
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // kalkulatu elkartutako Vec-en luzera osoa, `len` kalkuluak gainezka egiten badu, panic memoriarik gabe geratuko ginateke eta gainerako funtzioak segurtasunerako aurrez esleitutako Vec osoa behar du.
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // hasierarik gabeko buffer bat prestatu
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // kopiatu bereizlea eta zatiak mugarik gabe egiaztapenek sortutako kodeketekin konpultsazio gogorrak sortzen dituzte bereizle txikientzako hobekuntza masiboak egiteko (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Maileguaren ezarpen bitxi batek zati desberdinak itzul ditzake luzera kalkulatzeko eta benetako kopiarako.
        //
        // Ziurtatu hasierarik gabeko byteei ez diegula deitzailearen aurrean jartzen.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Kate-zatien metodoak.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// `Box<str>` `Box<[u8]>` bihurtzen du kopiatu edo esleitu gabe.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Eredu baten partida guztiak beste kate batekin ordezkatzen ditu.
    ///
    /// `replace` [`String`] berria sortzen du, eta kate zati horretako datuak bertan kopiatzen ditu.
    /// Hori egiten ari den bitartean, eredu baten parekoak aurkitzen saiatzen da.
    /// Baten bat aurkitzen badu, ordezko kate zatiekin ordezkatuko ditu.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Eredua bat ez datorrenean:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Ereduaren lehen N partida beste kate batekin ordezkatzen ditu.
    ///
    /// `replacen` [`String`] berria sortzen du, eta kate zati horretako datuak bertan kopiatzen ditu.
    /// Hori egiten ari den bitartean, eredu baten parekoak aurkitzen saiatzen da.
    /// Edozein aurkitzen badu, gehienez `count` aldiz ordezkatzen duen ordezko kate zatiekin ordezkatzen ditu.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Eredua bat ez datorrenean:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Esleitzeko denborak murriztea espero dugu
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Kate zati horren minuskulen baliokidea itzultzen du, [`String`] berri gisa.
    ///
    /// 'Lowercase' Unicode Derived Core `Lowercase` propietatearen baldintzen arabera definitzen da.
    ///
    /// Maiuskulak maiuskulak karaktere anitzetan hedatu daitezkeenez maiuskulak eta minuskulak aldatzean, funtzio honek [`String`] itzultzen du parametroa bere lekuan aldatu ordez.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Adibide zail bat, sigma-rekin:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // baina hitzaren amaieran ς da, ez σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Kasurik gabeko hizkuntzak ez dira aldatzen:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ σ-ra mapatzen da, ς-ra mapatzen den hitz baten amaieran izan ezik.
                // Hau da (contextual) baldintzazko (contextual) baina hizkuntza independentea den `SpecialCasing.txt`-eko mapaketa bakarra, beraz, gogor kodetu "condition" mekanismo generikoa izan beharrean.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // `Final_Sigma` definitzeko.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Kate zati horren maiuskulen baliokidea itzultzen du, [`String`] berri gisa.
    ///
    /// 'Uppercase' Unicode Derived Core `Uppercase` propietatearen baldintzen arabera definitzen da.
    ///
    /// Maiuskulak maiuskulak karaktere anitzetan hedatu daitezkeenez maiuskulak eta minuskulak aldatzean, funtzio honek [`String`] itzultzen du parametroa bere lekuan aldatu ordez.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Maiuskulak eta minuskulak ez dira aldatzen:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Pertsonaia bat anitz bihur daiteke:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// [`Box<str>`] [`String`] bihurtzen du kopiatu edo esleitu gabe.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// [`String`] berria sortzen du kate bat `n` aldiz errepikatuz.
    ///
    /// # Panics
    ///
    /// Funtzio hau panic izango da edukiera gainezka egingo balu.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// panic gainezkatzean:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Kate honen kopia itzultzen du, non karaktere bakoitza bere ASCII maiuskularen baliokidearekin mapatuta dagoen.
    ///
    ///
    /// ASCII 'a'-tik 'z' letrak 'A'-tik 'Z'-ra mapatzen dira, baina ASCII ez diren letrak ez dira aldatu.
    ///
    /// Lekuan dagoen balioa maiuskulaz idazteko, erabili [`make_ascii_uppercase`].
    ///
    /// ASCII ez diren ASCII karaktereez maiuskulaz idazteko, erabili [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() UTF-8 aldaezina gordetzen du.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Kate honen kopia bat itzultzen du, non karaktere bakoitza ASCII minuskulen baliokidearekin mapatuta dagoen.
    ///
    ///
    /// ASCII 'A'-tik 'Z' letrak 'a'-tik 'z'-ra mapatzen dira, baina ASCII ez diren letrak ez dira aldatu.
    ///
    /// Lekuan dagoen balioa minuskulatzeko, erabili [`make_ascii_lowercase`].
    ///
    /// ASCII karaktere minuskulak ASCII ez diren karaktereez gain, erabili [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() UTF-8 aldaezina gordetzen du.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Byte kaxako xerra katea kaxa xerra bihurtzen du kateak baliozko UTF-8 duela egiaztatu gabe.
///
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}