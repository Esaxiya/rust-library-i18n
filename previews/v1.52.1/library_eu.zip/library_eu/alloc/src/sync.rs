#![stable(feature = "rust1", since = "1.0.0")]

//! Haririk gabeko erreferentziak zenbatzeko erakusleak.
//!
//! Ikusi [`Arc<T>`][Arc] dokumentazioa xehetasun gehiagorako.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// `Arc` bati egin dakiokeen erreferentzia kopuruaren muga arina.
///
/// Muga hori gaindituz gero, zure programa bertan behera utziko da (nahitaez ez bada ere) _exactly_ `MAX_REFCOUNT + 1` erreferentzietan.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer-ek ez ditu memoria hesiak onartzen.
// Arc/Ahula inplementazioan txosten positibo faltsuak ekiditeko karga atomikoak erabili sinkronizatzeko.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Haririk gabeko erreferentzia-zenbaketa erakuslea.'Arc' "Atomically Reference Counted" izendatzen du.
///
/// `Arc<T>` motak `T` motako balio baten jabetza partekatua eskaintzen du, pilan esleituta.[`clone`][clone] `Arc`-ra deitzeak `Arc` instantzia berri bat sortzen du, `Arc` iturburuko muntaketaren esleipen bera seinalatzen duena, erreferentzia kopurua handitzen den bitartean.
/// Esleipen jakin baterako azken `Arc` erakuslea suntsitzen denean, esleipen horretan gordetako balioa (maiz "inner value" izenarekin ezagutzen dena) ere jaitsi egiten da.
///
/// Rust-n partekatutako erreferentziek mutazioa lehenespenez uzten dute eta `Arc` ez da salbuespena: normalean ezin duzu `Arc` baten barruan dagoen erreferentzia aldakorrik lortu.`Arc` baten bidez mutatu behar baduzu, erabili [`Mutex`][mutex], [`RwLock`][rwlock] edo [`Atomic`][atomic] motetako bat.
///
/// ## Hariaren Segurtasuna
///
/// [`Rc<T>`]-k ez bezala, `Arc<T>`-k eragiketa atomikoak erabiltzen ditu erreferentzia kontatzeko.Horrek haririk gabeko segurtasuna duela esan nahi du.Desabantaila da eragiketa atomikoak memoriako sarbide arruntak baino garestiagoak direla.Harien artean erreferentzia-zenbatutako esleipenak partekatzen ez badituzu, pentsa ezazu [`Rc<T>`] erabiltzea gastu txikiagoetarako.
/// [`Rc<T>`] lehenespen segurua da, konpiladoreak [`Rc<T>`] hari artean bidaltzeko edozein saiakera harrapatuko baitu.
/// Hala ere, liburutegi batek `Arc<T>` aukera dezake liburutegiei kontsumitzaileei malgutasun handiagoa emateko.
///
/// `Arc<T>` [`Send`] eta [`Sync`] ezarriko ditu `T`-k [`Send`] eta [`Sync`] inplementatzen dituen bitartean.
/// Zergatik ezin duzu hari segurua ez den `T` mota `Arc<T>` batean jarri hari segurua izan dadin?Baliteke hasieran kontra-intuitiboa izatea: azken finean, ez al da `Arc<T>` hariaren segurtasuna?Gakoa hau da: `Arc<T>`-k hari seguru bihurtzen du datu beraren jabetza anitza edukitzea, baina ez dio hari segurtasuna gehitzen bere datuei.
///
/// Demagun `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] ez da [`Sync`], eta `Arc<T>` beti [`Send`] bada, `Arc <` [`RefCell<T>`]`>`ere ondo egongo litzateke.
/// Baina orduan arazo bat izango genuke:
/// [`RefCell<T>`] ez da haria segurua;mailegu kopuruaren jarraipena egiten du atomikoak ez diren eragiketak erabiliz.
///
/// Azkenean, horrek esan nahi du agian `Arc<T>` [`std::sync`] motaren batekin lotu beharko duzula, normalean [`Mutex<T>`][mutex].
///
/// ## Zikloak haustea `Weak`-rekin
///
/// [`downgrade`][downgrade] metodoa jabea ez den [`Weak`] erakuslea sortzeko erabil daiteke.[`Weak`] erakuslea [`upgrade`][upgrade] d `Arc` batera bidal daiteke, baina honek [`None`] itzuliko du esleipenean gordetako balioa dagoeneko jaitsi bada.
/// Beste modu batera esanda, `Weak` erakusleek ez dute esleipenaren barruko balioa bizirik mantentzen;hala ere,*egiten dute* esleipena (balioaren babes-denda) bizirik mantentzen dute.
///
/// `Arc` erakusleen arteko zikloa ez da inoiz banatuko.
/// Hori dela eta, [`Weak`] zikloak hausteko erabiltzen da.Adibidez, zuhaitz batek `Arc` erakusle sendoak izan ditzake gurasoen nodoetatik haurrentzat eta [`Weak`] erakusleak haurren gurasoak berriro.
///
/// # Klonazio erreferentziak
///
/// Lehendik dagoen erreferentzia-zenbatutako erakusle batetik erreferentzia berri bat sortzeko [`Arc<T>`][Arc] eta [`Weak<T>`][Weak]-rekin inplementatutako `Clone` trait erabiliz egiten da.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Beheko bi sintaxiak baliokideak dira.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b eta foo memoria-kokapen bera duten arkuak dira
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` automatikoki `T`-ra desferentziak ([`Deref`][deref] trait bidez), beraz, `T` metodoei dei diezaiekezu `Arc<T>` motako balioari.`T` metodoekin izenen arteko liskarrak ekiditeko, `Arc<T>` metodoak berez funtzio elkartuak dira, [fully qualified syntax] erabiliz deituak:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arkua<T>`Clone` bezalako traits-ren inplementazioak sintaxi guztiz kualifikatua erabiliz ere dei daitezke.
/// Batzuek nahiago dute sintaxi guztiz kualifikatua erabili, beste batzuek, berriz, metodo-deien sintaxia erabiltzea.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Metodo-deien sintaxia
/// let arc2 = arc.clone();
/// // Erabat kualifikatutako sintaxia
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] ez du `T`-era automatikoki erreferentzia egiten, barruko balioa dagoeneko jaitsi egin delako.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Datu aldaezin batzuk harien artean partekatzea:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Kontuan izan **ez ditugula** proba hauek egiten hemen.
// windows eraikitzaileak oso pozik geratzen dira hari batek hari nagusia gainditzen badu eta aldi berean irteten bada (zerbait blokeatuta dago), beraz, guztiz saihestuko dugu proba hauek ez egiteagatik.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// [`AtomicUsize`] aldakorra partekatzen:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Ikusi [`rc` documentation][rc_examples] erreferentzia orokorraren zenbaketa adibide gehiago lortzeko.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` kudeatutako esleipenaren jabea ez den erreferentzia duen [`Arc`] bertsioa da.
/// Esleipenera `Weak` erakusleari [`upgrade`] deituz sartzen da, eta horrek [`Aukera`] itzultzen du <<[`Arkua]]`<T>> `.
///
/// `Weak` erreferentziak jabetza kontuan hartzen ez duenez, ez du esleipenean gordetako balioa jaistea eragotziko eta `Weak`-k berak ez du bermerik ematen oraindik ere dagoen balioari buruz.
///
/// Beraz, [`None`] itzul dezake [`upgrade`] d.
/// Kontuan izan, ordea, `Weak` erreferentziak * ez duela esleipena bera (babes-denda) banatzea eragozten.
///
/// `Weak` erakuslea erabilgarria da [`Arc`]-k kudeatzen duen esleipenaren behin-behineko erreferentzia gordetzeko, bere barne balioa jaistea eragotzi gabe.
/// [`Arc`] erakusleen arteko erreferentzia zirkularrak saihesteko ere erabiltzen da, elkarrekiko erreferentziak izateak ez baitu inoiz [`Arc`] biak botatzea onartuko.
/// Adibidez, zuhaitz batek [`Arc`] erakusle indartsuak izan ditzake gurasoen nodoetatik haurrentzat, eta `Weak` erakusleak haurretatik gurasoetara.
///
/// `Weak` erakuslea lortzeko modu tipikoa [`Arc::downgrade`] deitzea da.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Hau `NonNull` da mota honetako tamaina optimizatzeko baimenetan, baina ez du zertan baliozko erakuslea izan.
    //
    // `Weak::new` hau `usize::MAX` gisa ezartzen du, tartean espazioa esleitu behar ez izateko.
    // Hori ez da benetako erakusleak inoiz izango duen balioa, RcBox-ek gutxienez 2 lerrokatzea duelako.
    // Hau soilik posible da `T: Sized` denean;tamaina gabeko `T` inoiz ez da zintzilik.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Hau repr(C)-tik future-ren froga da landa-berrordenaketa posible baten aurrean, horrek bestela seguruak diren barruko mota transkutagarrien [into|from]_raw() oztopatuko lukeena.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // usize::MAX balioa zentinela gisa jokatzen du aldi baterako "locking" erakusle ahulak berritzeko edo sendoak jaisteko gaitasuna lortzeko;hau `make_mut` eta `get_mut` lasterketak saihesteko erabiltzen da.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// `Arc<T>` berria eraikitzen du.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Hasi erakusle ahula zenbatzen 1, hau da, (kinda) erakusle indartsu guztiek duten erakusle ahula. Ikusi std/rc.rs informazio gehiago lortzeko
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// `Arc<T>` berria eraikitzen du bere buruari erreferentzia ahula erabiliz.
    /// Funtzio hau itzuli aurretik erreferentzia ahula eguneratzen saiatzeak `None` balioa izango du.
    /// Hala ere, erreferentzia ahula askatasunez klonatu eta gorde daiteke geroago erabiltzeko.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Eraiki barrualdea "uninitialized" egoeran erreferentzia ahula bakar batekin.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Garrantzitsua da erakusle ahularen jabetzari uko egitea, edo bestela memoria `data_fn` itzultzen denean libratuko da.
        // Jabetza benetan gainditu nahiko bagenu, erakusle ahul gehigarri bat sor genezake guretzat, baina horrek bestela beharrezkoak ez liratekeen erreferentzia kopuru ahularen eguneratze osagarriak ekarriko lituzke.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Orain barruko balioa behar bezala has dezakegu eta gure erreferentzia ahula erreferentzia sendo bihur dezakegu.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Aurreko datuak datu-eremuan idazteko zero ez den zenbaketa sendoa ikusten duten hari guztiek ikusi behar dute.
            // Hori dela eta, gutxienez "Release" ordenatzea behar dugu X002 X 02X-rekin sinkronizatzeko.
            //
            // "Acquire" eskatzea ez da beharrezkoa.
            // `data_fn`-ren portaera posibleak aztertzerakoan, bertsio-berritu ezin den `Weak` erreferentzia batekin zer egin dezakeen aztertu behar dugu:
            //
            // - `Weak` * klona dezake, erreferentzia kopuru ahula handituz.
            // - Klon horiek jaitsi ditzake, erreferentzia kopuru ahula txikituz (baina inoiz ez zero izatera).
            //
            // Bigarren mailako efektu horiek ez digute inolaz ere eragiten, eta kode seguruak bakarrik ez ditu beste bigarren mailako efektuak posible.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Erreferentzia sendoek kolektiboki partekatutako erreferentzia ahula izan beharko lukete, beraz ez ezazu gure erreferentzia ahul zaharraren suntsitzailea exekutatu.
        //
        mem::forget(weak);
        strong
    }

    /// `Arc` berria eraikitzen du hasierarik gabeko edukiekin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Hasierako atzerapena:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `Arc` berria eraikitzen du hasierarik gabeko edukiekin, memoria `0` bytez beteta.
    ///
    ///
    /// Ikusi [`MaybeUninit::zeroed`][zeroed] metodo honen erabilera zuzena eta okerra egiteko adibideak.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `Pin<Arc<T>>` berria eraikitzen du.
    /// `T`-k `Unpin` inplementatzen ez badu, `data` memorian ainguratuko da eta ezin da mugitu.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// `Arc<T>` berria sortzen du, esleipena huts egiten badu errorea itzuliz.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Hasi erakusle ahula zenbatzen 1, hau da, (kinda) erakusle indartsu guztiek duten erakusle ahula. Ikusi std/rc.rs informazio gehiago lortzeko
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// `Arc` berria sortzen du hasierarik gabeko edukiekin, errore bat itzuliz esleipenak huts egiten badu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Hasierako atzerapena:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// `Arc` berria eraikitzen du hasierarik gabeko edukiekin, memoria `0` bytez beteta, errorea itzuliz esleipenak huts egiten badu.
    ///
    ///
    /// Ikusi [`MaybeUninit::zeroed`][zeroed] metodo honen erabilera zuzena eta okerra egiteko adibideak.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Barruko balioa itzultzen du, `Arc`-k erreferentzia sendo bat baldin badu.
    ///
    /// Bestela, [`Err`] bat itzuliko da pasatutako `Arc` berarekin.
    ///
    ///
    /// Honek arrakasta izango du erreferentzia ahul nabarmenak badaude ere.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Egin erakusle ahula erreferentzia sendo-ahula inplizitua garbitzeko
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Erreferentzia atomikoki kontatutako xerra berri bat eraikitzen du hasierarik gabeko edukiekin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Hasierako atzerapena:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Erreferentzia atomikoki kontatutako xerra berri bat eraikitzen du hasierarik gabeko edukiekin, memoria `0` bytez beteta.
    ///
    ///
    /// Ikusi [`MaybeUninit::zeroed`][zeroed] metodo honen erabilera zuzena eta okerra egiteko adibideak.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` bihurtzen da.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`]-rekin gertatzen den moduan, deitzailearen esku dago barneko balioa benetan hasierako egoeran dagoela bermatzea.
    ///
    /// Edukia oraindik guztiz hasieratu ez denean deitzeak berehala zehaztu gabeko portaera eragiten du.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Hasierako atzerapena:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` bihurtzen da.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`]-rekin gertatzen den moduan, deitzailearen esku dago barneko balioa benetan hasierako egoeran dagoela bermatzea.
    ///
    /// Edukia oraindik guztiz hasieratu ez denean deitzeak berehala zehaztu gabeko portaera eragiten du.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Hasierako atzerapena:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// `Arc` kontsumitzen du, bildutako erakuslea itzuliz.
    ///
    /// Memoria ihesik ez izateko erakuslea `Arc` batera bihurtu behar da [`Arc::from_raw`] erabiliz.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Erakusle gordin bat eskaintzen die datuei.
    ///
    /// Zenbaketek ez dute inolaz ere eragiten eta `Arc` ez da kontsumitzen.
    /// Erakusleak `Arc`-en zenbaketa sendoak dauden bitartean balio du.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SEGURTASUNA: honek ezin du Deref::deref edo RcBoxPtr::inner bidez igaro
        // hau beharrezkoa da raw/mut jatorria gordetzeko, adibidez
        // `get_mut` erakuslearen bidez idatz dezake Rc `from_raw` bidez berreskuratu ondoren.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Erakusle gordin batetik `Arc<T>` bat eraikitzen du.
    ///
    /// Erakusle gordina aurretik [`Arc<U>::into_raw`][into_raw]-ra deituta itzuli behar da, `U`-ek `T` ren tamaina eta lerrokadura bera izan behar du.
    /// Hori hutsala da `U` `T` bada.
    /// Kontuan izan `U` ez bada `T` baina tamaina eta lerrokadura berdinak badituela, funtsean mota desberdinetako erreferentziak transmutatzea bezalakoa da.
    /// Ikus [`mem::transmute`][transmute] kasu honetan zer murriztapen aplikatzen diren jakiteko.
    ///
    /// `from_raw` erabiltzaileak `T` ren balio espezifikoa behin bakarrik jaisten dela ziurtatu behar du.
    ///
    /// Funtzio hau ez da segurua, erabilera desegokiak memorian segurtasunik eza ekar dezakeelako, itzulitako `Arc<T>`-ra inoiz sartzen ez bada ere.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Bihurtu berriro `Arc` batera, ihesik ez izateko.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)` ra deitzeak memoria ez du segurua izango.
    /// }
    ///
    /// // Memoria askatu zen `x` goiko eremutik atera zenean, beraz, `x_ptr` zintzilik dago!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Alderantzikatu desplazamendua jatorrizko ArcInner aurkitzeko.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// [`Weak`] erakusle berria sortzen du esleipen honetarako.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Lasai hau ondo dago beheko CASean balioa egiaztatzen ari garelako.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // egiaztatu kontagailu ahula gaur egun "locked" den;bada, biratu.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: kode honek une honetan gainezka egiteko aukera alde batera uzten du
            // usize::MAX sartu;orokorrean bai Rc bai Arc egokitu behar dira gainezkapenari aurre egiteko.
            //

            // Clone()-rekin ez bezala, eskuratzeko irakurketa bat izan behar dugu `is_unique`-etik datorren idazketarekin sinkronizatzeko, idazketa horren aurreko gertakariak irakurketa honen aurretik gerta daitezen.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Ziurtatu ez dugula ahula zintzilik sortzen
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// [`Weak`] erakusle kopurua lortzen du esleipen honetarako.
    ///
    /// # Safety
    ///
    /// Metodo hau berez segurua da, baina behar bezala erabiltzeak arreta berezia eskatzen du.
    /// Beste hari batek zenbaketa ahula alda dezake noiznahi, metodo honi deitu eta emaitzari eragitearen artean.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Baieztapen hau determinista da, ez baitugu `Arc` edo `Weak` harien artean partekatu.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Zenbaki ahula blokeatuta badago, zenbaketaren balioa 0 zen blokeoa hartu aurretik.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// (`Arc`) erakusle indartsuen kopurua lortzen du esleipen honetarako.
    ///
    /// # Safety
    ///
    /// Metodo hau berez segurua da, baina behar bezala erabiltzeak arreta berezia eskatzen du.
    /// Beste hari batek zenbaketa indartsua alda dezake noiznahi, metodo honi deitu eta emaitzari eragitearen artean.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Baieztapen hau determinista da, ez baitugu `Arc` harien artean partekatu.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Emandako erakuslearekin lotutako `Arc<T>` erreferentzia indartsua handitzen du.
    ///
    /// # Safety
    ///
    /// Erakusleak `Arc::into_raw` bidez lortu behar du eta lotutako `Arc` instantziak baliozkoa izan behar du (hots
    /// zenbaketa indartsuak gutxienez 1) izan behar du metodo honek irauten duen bitartean.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Baieztapen hau determinista da, ez baitugu `Arc` harien artean partekatu.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Mantendu Arkua, baina ez ukitu refcount ManuallyDrop bilduta
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Orain handitu errefrekzioa, baina ez bota errefrekzio berria ere
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Emandako erakuslearekin lotutako `Arc<T>` erreferentzia indartsua gutxitzen du.
    ///
    /// # Safety
    ///
    /// Erakusleak `Arc::into_raw` bidez lortu behar du eta lotutako `Arc` instantziak baliozkoa izan behar du (hots
    /// zenbaketa indartsuak gutxienez 1) izan behar du metodo hau deitzerakoan.
    /// Metodo hau erabil daiteke azken `Arc` eta babeskopia gordetzeko, baina **ez da** deitu behar azken `Arc` kaleratu ondoren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Baieztapen horiek deterministak dira, ez baitugu `Arc` harien artean partekatu.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Segurtasun hori ondo dago arku hau bizirik dagoen bitartean barneko erakuslea baliozkoa dela ziurtatuta dugulako.
        // Gainera, badakigu `ArcInner` egitura bera `Sync` dela, barne datuak `Sync` direlako eta, beraz, ondo gaude eduki horiei erakusle aldaezina maileguan emateko.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` ren zati ez lerrokatua.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Suntsitu datuak momentu honetan, nahiz eta koadroaren esleipena bera ere ez askatuko dugun (inguruan erakusle ahulak egon daitezke).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Jaregin erreferentzia sendo guztiek biltzen duten erreferentzia ahula
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// `true` itzultzen du `Arc-ek bi esleipen berera zuzentzen baditu ([`ptr::eq`] ren antzeko ildoan).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// `ArcInner<T>` bat esleitzen du, behar adina tamaina ez duen barruko balio baterako, balioak diseinua duenean.
    ///
    /// `mem_to_arcinner` funtzioari datu erakuslearekin deitzen zaio eta `ArcInner<T>` rako (potentzialki koipe) erakuslea itzuli behar du.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Kalkulatu diseinua emandako balioaren diseinua erabiliz.
        // Aurretik, diseinua `&*(ptr as* const ArcInner<T>)` adierazpenean kalkulatzen zen, baina horrek gaizki lerrokatutako erreferentzia sortu zuen (ikus #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// `ArcInner<T>` bat esleitzen du tamainarik gabeko barne-balio baterako espazio nahikoa duen tokian, balioa diseinuak eskaintzen duen lekuan, errorea itzuliz esleipenak huts egiten badu.
    ///
    ///
    /// `mem_to_arcinner` funtzioari datu erakuslearekin deitzen zaio eta `ArcInner<T>` rako (potentzialki koipe) erakuslea itzuli behar du.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Kalkulatu diseinua emandako balioaren diseinua erabiliz.
        // Aurretik, diseinua `&*(ptr as* const ArcInner<T>)` adierazpenean kalkulatzen zen, baina horrek gaizki lerrokatutako erreferentzia sortu zuen (ikus #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Hasieratu ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// `ArcInner<T>` bat esleitzen du tamaina gabeko barruko balio baterako espazio nahikoa duena.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // `ArcInner<T>` esleitu emandako balioa erabiliz.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopiatu balioa byte gisa
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Doako esleipena edukia bota gabe
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Emandako luzera duen `ArcInner<[T]>` bat esleitzen du.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopiatu zatitik elementuak esleitutako arku berrira <\[T\]>
    ///
    /// Ez da segurua, deitzaileak jabetza hartu edo `T: Copy` lotu behar duelako.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// `Arc<[T]>` bat eraikitzen du tamaina jakin bateko iteratzaile batetik abiatuta.
    ///
    /// Portaera zehaztu gabe dago tamaina okerra izanez gero.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic guardia T elementuak klonatzean.
        // panic gertatuz gero, ArcInner berrian idatzitako elementuak jaitsi egingo dira eta gero memoria libratuko da.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Erakuslea lehen elementura
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Guztia argi.Ahaztu guardia ArcInner berria askatu ez dezan.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` rako erabiltzen den trait espezializazioa.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` erakuslearen klona egiten du.
    ///
    /// Honek esleipen bererako beste erakusle bat sortzen du, erreferentzia kopuru sendoa handituz.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Ordena lasaia erabiltzea ondo dago hemen, jatorrizko erreferentzia ezagutzeak beste hari batzuek objektua oker ezabatzea eragozten baitute.
        //
        // [Boost documentation][1]-n azaltzen den moduan, erreferentzia kontagailua handitzea memoria_orden_relaxed-ekin egin daiteke beti: objektu baten erreferentzia berriak lehendik dagoen erreferentzia batetik soilik osa daitezke, eta lehendik dagoen erreferentzia bat hari batetik bestera pasatzeak beharrezko sinkronizazioa eman behar du dagoeneko.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Hala ere, norbaitek `mem: : ahazteko` arkuak egiten baditu, zenbaketa masiboen aurrean zaindu behar dugu.
        // Hori egiten ez badugu, zenbaketa gainezka daiteke eta erabiltzaileek dohainik erabiliko dute.
        // `isize::MAX`-ra arte asetzen dugu erreferentzia-kopurua aldi berean gehitzen duten ~2 mila milioi hari ez daudela suposatuz.
        //
        // branch hau ez da inoiz programa errealistetan hartuko.
        //
        // Abortu egiten dugu horrelako programa izugarri endekatuta dagoelako eta ez zaigu axola berari laguntzea.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Emandako `Arc` erreferentzia aldakorra egiten du.
    ///
    /// Esleipen berarekin beste `Arc` edo [`Weak`] erakusle batzuk badaude, orduan `make_mut` ek esleipen berri bat sortuko du eta [`clone`][clone] deituko du barneko balioari jabetza bakarra bermatzeko.
    /// Klonatze-idazketan ere esaten zaio horri.
    ///
    /// Kontuan izan hau [`Rc::make_mut`] ren portaerarekin desberdina dela, gainerako `Weak` erakusleak desegiten dituela.
    ///
    /// Ikusi [`get_mut`][get_mut] ere, klonatzeak baino huts egingo baitu.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Ez dut ezer klonatuko
    /// let mut other_data = Arc::clone(&data); // Ez ditu barruko datuak klonatuko
    /// *Arc::make_mut(&mut data) += 1;         // Barruko datuak klonatzen ditu
    /// *Arc::make_mut(&mut data) += 1;         // Ez dut ezer klonatuko
    /// *Arc::make_mut(&mut other_data) *= 2;   // Ez dut ezer klonatuko
    ///
    /// // Orain `data`-k eta `other_data`-ek esleipen desberdinak dituzte.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Kontuan izan erreferentzia sendoa eta erreferentzia ahula dugula.
        // Horrela, gure erreferentzia sendoa kaleratzeak ez du, berez, memoria banatzea eragingo.
        //
        // Erabili Eskuratu eskuratzeko `weak`-n idatzitakoa `strong`-n idatzi aurretik (hau da, murrizketak) gertatu aurretik gertatzen dela ziurtatzeko.
        // Zenbaketa ahula dugulako, ez dago ArcInner bera banatzeko aukerarik.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Beste erakusle indartsu bat dago, beraz, klonatu egin behar dugu.
            // Aurrez esleitu memoria klonatutako balioa zuzenean idazteko.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Aurrekoetan lasai egotea nahikoa da hau funtsean optimizazio bat delako: beti ari gara lasterketetan erakusle ahulak jaisten.
            // Okerrena, azkenean Arku berria alferrik esleitu dugu.
            //

            // Azken erreflexio indartsua kendu dugu, baina geratzen dira erreferentzia ahulak.
            // Edukia Arku berri batera eramango dugu eta gainerako erreferentzia ahulak baliogabetuko ditugu.
            //

            // Kontuan izan ezinezkoa dela `weak` irakurtzeak usize::MAX ematea (hau da, blokeatuta), zenbaketa ahula erreferentzia sendoa duen hari batek soilik blokea baitezake.
            //
            //

            // Materializatu gure erakusle ahul inplizitua, ArcInner behar den moduan garbitu dezan.
            //
            let _weak = Weak { ptr: this.ptr };

            // Datuak lapurtu ditzakezu, ahulak besterik ez dira falta
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Bi motatako erreferentzia bakarra ginen;berreskuratu erref zenbaketa indartsua.
            //
            this.inner().strong.store(1, Release);
        }

        // `get_mut()`-rekin gertatzen den moduan, segurtasuna ez da egokia, gure erreferentzia bakarra izan delako, hasiera batean edo edukia klonatzerakoan bihurtu delako.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Erreferentzia aldakor bat ematen du emandako `Arc`-ra, esleipen berean beste `Arc` edo [`Weak`] erakuslerik ez badago.
    ///
    ///
    /// [`None`] itzultzen du bestela, partekatutako balioa mutatzea ez delako segurua.
    ///
    /// Ikus [`make_mut`][make_mut] ere, barneko balioa [`clone`][clone] izango duena beste erakusleak daudenean.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Segurtasun hori ondo dago, ziurtatuta baitugu itzulitako erakuslea T-ra itzuliko den *bakarra* erakuslea dela.
            // Une honetan gure erreferentzia kopurua 1 dela ziurtatuta dago, eta Arc bera `mut` izatea eskatzen dugu, beraz, barne datuen erreferentzia posible bakarra itzuliko dugu.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Erreferentzia aldakor bat ematen du emandako `Arc`-ra, inolako egiaztapenik egin gabe.
    ///
    /// Ikusi [`get_mut`] ere, segurua eta egiaztapen egokiak egiten dituena.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Esleipen bereko beste edozein `Arc` edo [`Weak`] erakusle ez dira desbideratu behar itzulitako maileguak irauten duen bitartean.
    ///
    /// Hau hutsalki gertatzen da horrelako erakuslerik ez badago, adibidez `Arc::new` ondoren.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Kontu handiz *ez* sortzen dugu "count" eremuak estaltzen dituen erreferentziarik, honek erreferentzia zenbakietarako sarbide aldiberekoa izango lukeelako (adib.
        // by `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Zehaztu ea hori den azpiko datuen erreferentzia bakarra (erreferentzia ahulak barne).
    ///
    ///
    /// Kontuan izan horrek erreferentzia ahula blokeatzea eskatzen duela.
    fn is_unique(&mut self) -> bool {
        // blokeatu erakusle ahula zenbatzea erakusle ahulen titular bakarra agertzen bagara.
        //
        // Hemen eskuratzeko etiketak `strong`-ra (batez ere `Weak::upgrade`-rekin) `weak` zenbaketa murriztu aurretik (`Weak::drop` bidez, oharra erabiltzen duena) aurretik gertatzen den harremana ziurtatzen du.
        // Berritutako erreflexio ahula inoiz jaitsi ez bada, CASak huts egingo du, beraz, ez zaigu axola sinkronizatzea.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Honek `Acquire` bat izan behar du `drop` kontagailuaren beherakadarekin sinkronizatzeko-azken erreferentzia uzten denean gertatzen den sarbide bakarra.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Hemen argitaratutako oharra `downgrade`-eko irakurketarekin sinkronizatzen da, `strong`-ren aurreko irakurketa idazketaren ondoren gerta ez dadin.
            //
            //
            self.inner().weak.store(1, Release); // askatu sarraila
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` uzten du.
    ///
    /// Honek erreferentzia kopuru sendoa gutxituko du.
    /// Erreferentzia kopuru indartsua zero izatera iristen bada, beste erreferentzia bakarrak (badaude) [`Weak`] dira, beraz `drop` barne balioa dugu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Ez du ezer inprimatzen
    /// drop(foo2);   // "dropped!" inprimatzen du
    /// ```
    #[inline]
    fn drop(&mut self) {
        // `fetch_sub` dagoeneko atomikoa denez, ez dugu beste hari batzuekin sinkronizatu behar objektua ezabatuko ez badugu behintzat.
        // Logika hori bera beheko `fetch_sub`-ri aplikatzen zaio `weak` zenbaketari.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Hesi hori beharrezkoa da datuen erabilera berriro ordenatzea eta datuak ezabatzea saihesteko.
        // `Release` markatuta dagoenez, erreferentzia kontuaren beherakada `Acquire` hesi honekin sinkronizatzen da.
        // Horrek esan nahi du datuen erabilera erreferentzia kopurua gutxitu aurretik gertatzen dela, hesi honen aurretik gertatzen dena, datuak ezabatu aurretik gertatzen dena.
        //
        // [Boost documentation][1]-n azaldu bezala,
        //
        // > Garrantzitsua da objektuan sarbide posible bat indarrean jartzea
        // > haria (dagoen erreferentzia baten bidez)*ezabatu aurretik* gertatzeko
        // > objektua beste hari batean.Hori "release" batek lortzen du
        // > eragiketa erreferentzia bat bota ondoren (objekturako edozein sarbide
        // > erreferentzia honen bidez, jakina, aurretik gertatu behar da), eta an
        // > "acquire" eragiketa objektua ezabatu aurretik.
        //
        // Bereziki, arku baten edukia aldaezina izan arren, posible da barruko Mutex antzeko zerbaitetan idaztea<T>.
        // Ezabatzen denean Mutex bat eskuratzen ez denez, ezin gara bere sinkronizazio logikan oinarritu A harian idatzitakoak B harian exekutatzen ari den suntsitzaile batek ikusgai bihurtzeko.
        //
        //
        // Kontuan izan ere Eskuratu hesia seguruenik Eskuratu karga batekin ordezkatu daitekeela, eta horrek errendimendua hobe dezakeela oso egoera larrietan.Ikus [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>` mota konkretu batera jaisten saiatu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// `Weak<T>` berria eraikitzen du, memoriarik esleitu gabe.
    /// Itzulitako balioari [`upgrade`] deitzeak [`None`] ematen du beti.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Laguntza mota, datu-eremuari buruzko baieztapenik egin gabe erreferentzia-zenbakietara sarbidea ahalbidetzeko.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Erakusle gordina itzultzen du `Weak<T>` honek adierazten duen `T` objektuari.
    ///
    /// Erakusleak erreferentzia sendo batzuk badaude soilik balio du.
    /// Erakuslea zintzilik, lerrokatu gabe edo [`null`] izan daiteke bestela.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Biek objektu bera seinalatzen dute
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Hemengo indartsuak bizirik mantentzen du, beraz, oraindik objektuan sar gaitezke.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Baina ez gehiago.
    /// // weak.as_ptr() egin dezakegu, baina erakuslera sartzeak zehaztu gabeko portaera ekarriko luke.
    /// // assert_eq! ("kaixo", ez da segurua {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Erakuslea zintzilik badago, sentinela zuzenean itzuliko dugu.
            // Hau ezin da baliozko karga-helbidea izan, karga ArcInner (usize) bezain lerrokatuta baitago gutxienez.
            ptr as *const T
        } else {
            // SEGURTASUNA: is_dangling gezurra itzultzen bada, orduan erakuslea ez da erreferentziarik.
            // Une honetan karga jaitsi egin daiteke, eta jatorria mantendu behar dugu, beraz, erabili erakuslearen manipulazio gordina.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` kontsumitzen du eta erakusle gordin bihurtzen du.
    ///
    /// Honek erakusle ahula erakusle gordin bihurtzen du, erreferentzia ahula baten jabetza mantenduz (eragiketa honen bidez zenbaketa ahula ez da aldatzen).
    /// `Weak<T>`-rekin bihur daiteke [`from_raw`]-rekin.
    ///
    /// Erakuslearen helburura sartzeko murrizketa berdinak [`as_ptr`]-rekin aplikatzen dira.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Aurretik [`into_raw`]-k sortutako erakusle gordina `Weak<T>` bihurtzen du.
    ///
    /// Honekin erreferentzia sendoa segurtasunez lortzeko (gero [`upgrade`] deituz) edo zenbaki ahula `Weak<T>` jareginez kokatzeko erabil daiteke.
    ///
    /// Erreferentzia ahul baten jabetza hartzen du ([`new`]-ek sortutako erakusleak izan ezik, hauek ez baitute ezer; metodoa oraindik ere funtzionatzen du).
    ///
    /// # Safety
    ///
    /// Erakusleak [`into_raw`]-tik sortu behar du eta oraindik ere izan dezake bere erreferentzia ahul potentziala.
    ///
    /// Zenbaki indartsua 0 izatea onartzen da deitzeko unean.
    /// Hala ere, honek erakusle gordin gisa irudikatzen den erreferentzia ahul baten jabe egiten da (zenbaketa ahula ez da eragiketa honekin aldatzen) eta, beraz, aurreko [`into_raw`]-ra egindako deiarekin parekatu behar da.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Gutxitu azken zenbaketa ahula.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Ikusi Weak::as_ptr sarrerako erakuslea nola eratortzen den ikusteko testuingurua.

        let ptr = if is_dangling(ptr as *mut T) {
            // Hau ahul zintzilikarioa da.
            ptr as *mut ArcInner<T>
        } else {
            // Bestela, ziurtatuta dugu erakuslea ahul ez dagoenetik datorrela.
            // SEGURTASUNA: data_offset segurua da deitzeko, ptr-ek T. erreala (potentzialki jaitsi dena) aipatzen baitu.
            let offset = unsafe { data_offset(ptr) };
            // Horrela, desplazamendua alderantzikatzen dugu RcBox osoa lortzeko.
            // SEGURTASUNA: erakuslea Ahula da, beraz desplazamendu hau segurua da.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SEGURTASUNA: orain jatorrizko erakusle ahula berreskuratu dugu, beraz ahula sor dezakegu.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` erakuslea [`Arc`] batera berritzen saiatzen da, arrakasta izanez gero barne balioa jaistea atzeratzen.
    ///
    ///
    /// [`None`] ematen du barruko balioa geroztik jaitsi bada.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Erakusle indartsu guztiak suntsitu.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // CAS begizta erabiltzen dugu fetch_add-en ordez zenbaketa indartsua handitzeko, funtzio honek ez baitu inoiz erreferentzia-zenbakia zero izatetik hartu behar.
        //
        //
        let inner = self.inner()?;

        // Karga lasaia, behatu dezakegun 0-ren edozein idazketak eremua behin betiko zero egoeran uzten baitu (beraz, 0-ren "stale" irakurketa ondo dago), eta beste edozein balio beheko CAS bidez baieztatzen da.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Ikusi `Arc::clone`-en iruzkinak zergatik egiten dugun jakiteko (`mem::forget`-rako).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Lasai dago porrotaren kasuan, egoera berriari buruz ez dugulako itxaropenik.
            // Eskuratzea beharrezkoa da arrakasta duen kasua `Arc::new_cyclic`-rekin sinkronizatzeko, barruko balioa has daitekeenean `Weak` erreferentziak sortu ondoren.
            // Kasu horretan, hasierako balioa guztiz behatzea espero dugu.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // nulua goian egiaztatu da
                Err(old) => n = old,
            }
        }
    }

    /// Esleipen honetara apuntatzen diren (`Arc`) erakusle indartsuen kopurua lortzen du.
    ///
    /// `self` [`Weak::new`] erabiliz sortu bada, honek 0 itzuliko du.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Esleipen honetara apuntatzen diren `Weak` erakusleen kopurua gutxi gorabehera lortzen du.
    ///
    /// `self` [`Weak::new`] erabiliz sortu bada edo erakusle indartsurik geratzen ez bada, honek 0 itzuliko du.
    ///
    /// # Accuracy
    ///
    /// Ezarpenaren xehetasunak direla eta, itzulitako balioa 1 desaktibatu daiteke norabide bietan, beste hariek esleipen berbera seinalatzen duten edozein "Arc" edo "Ahul" manipulatzen ari direnean.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Zenbaki ahula irakurri ondoren gutxienez erakusle indartsu bat zegoela ikusi genuenez, badakigu erreferentzia ahul inplizitua (presente dagoen edozein erreferentzia indartsu bizirik dagoenean) oraindik ere ahula zegoela ikusi genuenean eta, beraz, segurtasunez ken dezakegula.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// `None` ematen du erakuslea zintzilik dagoenean eta `ArcInner` esleiturik ez dagoenean (hau da, `Weak` hau `Weak::new`-k sortu zuenean).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Kontu handiz *ez* sortzen dugu "data" eremua estaltzen duen erreferentziarik, eremua aldi berean mutatu baitaiteke (adibidez, azken `Arc` erortzen bada, datu eremua bere lekuan eroriko da).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// `true` itzultzen du bi `Ahulak esleipen berera zuzentzen badira ([`ptr::eq`] ren antzekoa), edo biek ez badute inolako esleipenik adierazten (`Weak::new()`)-rekin sortu direlako.
    ///
    ///
    /// # Notes
    ///
    /// Honek erakusleak alderatzen dituenez, `Weak::new()` elkarren artean berdinduko dela esan nahi du, inolako esleipenik adierazi ez arren.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` alderatuz.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Esleipen bera seinalatzen duen `Weak` erakuslearen klona egiten du.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Ikusi Arc::clone()-n iruzkinak zergatik lasaitzen den jakiteko.
        // Honek fetch_add bat erabil dezake (blokeatzeari jaramonik egin gabe), zenbaketa ahula blokeatuta dagoelako * dauden beste erakuslerik ez dagoenean bakarrik blokeatuta dagoelako.
        //
        // (Beraz, kasu horretan ezin dugu kode hau exekutatu).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Ikusi Arc::clone()-en iruzkinak zergatik egiten dugun jakiteko (mem::forget-rako).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// `Weak<T>` berria eraikitzen du, memoriarik esleitu gabe.
    /// Itzulitako balioari [`upgrade`] deitzeak [`None`] ematen du beti.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` erakuslea uzten du.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ez du ezer inprimatzen
    /// drop(foo);        // "dropped!" inprimatzen du
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Azken erakusle ahula izan ginela jakiten badugu, orduan garaia da datuak erabat banatzeko.Ikusi Arc::drop()-en eztabaida memoriaren ordenen inguruan
        //
        // Ez da beharrezkoa blokeatutako egoera hemen ikustea, zenbaketa ahula blokeatu daitekeelako, hain zuzen ere, erreflexio ahula bakarra egon badaiteke. Horrek esan nahi du jaitsiera gerorako erreflexio ahula ON soilik exekutatu daitekeela, blokeoa askatu ondoren bakarrik gerta daitekeena.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Espezializazio hau egiten ari gara hemen, eta ez `&T`-en optimizazio orokorrago gisa, bestela erreferentziako berdintasun kontrol guztiei kostua gehituko litzaiekeelako.
/// Suposatzen dugu `Arc`-ak balio handiak gordetzeko erabiltzen direla, klonatzeko motelak direnak, baina berdintasuna egiaztatzeko ere astunak direla eta kostu hori errazago ordaintzea eragiten du.
///
/// Gainera, litekeena da bi `Arc` klon izatea, balio bera duten bi `&T` baino.
///
/// `T: Eq` `PartialEq` gisa nahita erreflexiboa izan daitekeenean bakarrik egin dezakegu.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Berdintasuna bi `Arc`-entzat.
    ///
    /// Bi `Arku` berdinak dira beren barne-balioak berdinak badira, nahiz eta esleipen desberdinean gorde.
    ///
    /// `T`-k `Eq` ere inplementatzen badu (berdintasunaren erreflexibitatea suposatzen du), esleipen berbera seinalatzen duten bi `Arku 'beti berdinak dira.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Bi `Arc`-en desberdintasuna.
    ///
    /// Bi `Arku` ez dira berdinak haien barruko balioak desberdintasunak badira.
    ///
    /// `T`-k `Eq` ere inplementatzen badu (berdintasunaren erreflexibitatea esan nahi du), balio bera adierazten duten bi `Arku 'ez dira inoiz desorekatuak.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Bi `Arc`-en alderaketa partziala.
    ///
    /// Biak `partial_cmp()` deituz beren barne balioei konparatuz.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Bi `Arc`-en alderaketa baino gutxiago.
    ///
    /// Biak `<` deituz beren barne balioei konparatuz.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Bi "Arc" ren konparazio "txikiagoa edo berdina".
    ///
    /// Biak `<=` deituz beren barne balioei konparatuz.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Bi `Arc`-en konparazio baino handiagoa.
    ///
    /// Biak `>` deituz beren barne balioei konparatuz.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Bi "arku" ren konparazio "handiagoa edo berdina".
    ///
    /// Biak `>=` deituz beren barne balioei konparatuz.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Bi `Arc`-en konparazioa.
    ///
    /// Biak `cmp()` deituz beren barne balioei konparatuz.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `Arc<T>` berria sortzen du, X002rako `Default` balioa duena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Esleitu erreferentziarekin kontatutako xerra eta bete `v` elementuak klonatuz.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Esleitu erreferentziarekin kontatutako `str` eta kopiatu `v` bertan.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Esleitu erreferentziarekin kontatutako `str` eta kopiatu `v` bertan.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Mugitu kutxako objektu bat erreferentziazko zenbaketa banaketa berri batera.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Esleitu erreferentziarekin kontatutako xerra eta eraman `v` elementuak bertara.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Baimendu Vec-i memoria libratzea, baina ez edukia suntsitzea
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// `Iterator`-ko elementu bakoitza hartu eta `Arc<[T]>` batean biltzen du.
    ///
    /// # Errendimendu ezaugarriak
    ///
    /// ## Kasu orokorra
    ///
    /// Orokorrean, `Arc<[T]>`-ra biltzeko lehen `Vec<T>`-ra biltzea egiten da.Hau da, honako hau idazterakoan:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// hau idatziko bagenu bezala jokatzen du:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Lehenengo esleipen multzoa hemen gertatzen da.
    ///     .into(); // Hemen `Arc<[T]>` rako bigarren esleipena gertatzen da.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Honek `Vec<T>` eraikitzeko behar adina bider esleituko du eta, ondoren, behin `Vec<T>` `Arc<[T]>` bihurtzeko esleituko du.
    ///
    ///
    /// ## Luzera ezaguneko iteratzaileak
    ///
    /// Zure `Iterator`-k `TrustedLen` inplementatzen duenean eta tamaina zehatza duenean, `Arc<[T]>`-rako esleipen bakarra egingo da.Adibidez:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Esleipen bakarra gertatzen da hemen.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// `Arc<[T]>`-ra biltzeko erabiltzen den trait espezializazioa.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Hau da `TrustedLen` iteratzaile baten kasua.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SEGURTASUNA: ziurtatu behar dugu errepikatzaileak luzera zehatza duela eta daukagula.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Itzuli ezarpen normalera.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Lortu desplazamendua `ArcInner` baten barruan erakuslearen atzean dagoen karga lortzeko.
///
/// # Safety
///
/// Erakusleak aurretik baliozko T instantzia bat seinalatu behar du (eta horretarako baliozko metadatuak izan behar ditu), baina T hori uzteko baimena dago.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Lerrokatu tamaina gabeko balioa ArcInner-en amaieran.
    // RcBox repr(C) denez, beti izango da memorian azken eremua.
    // SEGURTASUNA: tamaina gabeko tamainako mota bakarra xerra denez, trait objektuak,
    // eta kanpoko motekin, sarrerako segurtasun eskakizuna nahikoa da gaur egun align_of_val_raw baldintzak betetzeko;hau da, agian, std-tik kanpo fidagarria ez den hizkuntzaren inplementazio xehetasuna da.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}