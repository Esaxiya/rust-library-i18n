#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Memoria berriaren edukia hasierarik gabe dago.
    Uninitialized,
    /// Memoria berria ezarrita dagoela ziurtatuta dago.
    Zeroed,
}

/// Maila baxuko erabilgarritasuna memoria buffer bat ergonomikoki esleitu, birkokatu eta banatu pilan pilatzeko, tartean dauden txoko guztiez kezkatu beharrik izan gabe.
///
/// Mota hau bikaina da Vec eta VecDeque bezalako zure datu egiturak eraikitzeko.
/// Zehazki:
///
/// * `Unique::dangling()` ekoizten du zero tamainako motetan.
/// * `Unique::dangling()` sortzen du zero luzerako esleipenetan.
/// * `Unique::dangling()` askatzea saihesten du.
/// * Ahalmenaren kalkuluetan gainezka guztiak harrapatzen ditu ("capacity overflow" panics raino sustatzen ditu).
/// * 32 bit-eko sistemen aurka babesten du isize::MAX byte baino gehiago esleitzen dituzten sistemen aurka.
/// * Guardia zure luzera gainezka egitearen aurka.
/// * `handle_alloc_error` deitzen du esleipen faltsuak lortzeko.
/// * `ptr::Unique` du eta, beraz, erabiltzaileari erlazionatutako abantaila guztiak eskaintzen dizkio.
/// * Esleitzailetik itzultzen den gehiegizkoa erabilgarri dagoen ahalmen handiena erabiltzeko erabiltzen du.
///
/// Mota honek ez du kudeatzen duen memoria ikuskatzen.Erortzen denean *memoria askatuko du, baina ez da* edukia askatzen saiatuko.
/// `RawVec` erabiltzailearen esku dago `RawVec` baten barruan *gordetako* benetako gauzak kudeatzea.
///
/// Kontuan izan zero tamainako moten gehiegikeria infinitua dela, beraz, `capacity()`-k `usize::MAX` beti itzultzen du.
/// Horrek esan nahi du kontuz ibili behar duzula mota hau `Box<[T]>` batekin biribiltzean, `capacity()`-k ez baitu luzera emango.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Hori gertatzen da `#[unstable]` `const fn`-k `min_const_fn`-rekin bat etorri behar ez duelako eta, beraz, ezin zaie`min_const_fn`s-en ere deitu.
    ///
    /// `RawVec<T>::new` edo mendekotasunak aldatzen badituzu, zaindu `min_const_fn` benetan urratuko lukeen ezer ez sartzea.
    ///
    /// NOTE: Hack hau saihestu eta `#[rustc_force_min_const_fn]` atributu batzuekin bat datorren egiaztatu dezakegu. Horrek `min_const_fn`-rekin bat etortzea eskatzen du, baina ez du zertan baimendu `stable(...) const fn`/erabiltzailearen kodean `foo` gaitzen ez duena `#[rustc_const_unstable(feature = "foo", issue = "01234")]` dagoenean.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Ahalik eta `RawVec` handiena sortzen du (sistemaren pilan) esleitu gabe.
    /// `T`-k tamaina positiboa badu, X002 edukiera duen `RawVec` bihurtzen da.
    /// `T` zero tamaina badu, X002 edukiera duen `RawVec` bat egiten du.
    /// Erabilgarria atzeratutako esleipena ezartzeko.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `RawVec` bat sortzen du (sistemaren pilan) `[T; capacity]` baterako gaitasun eta lerrokatze baldintzak zehazki.
    /// Hau `RawVec::new` deitzearen baliokidea da `capacity` `0` denean edo `T` zero tamaina duenean.
    /// Kontuan izan `T` zero tamaina badu horrek esan nahi duela ez duzula * lortuko eskatutako edukierarekin `RawVec`.
    ///
    /// # Panics
    ///
    /// Panics eskatutako edukiera `isize::MAX` byte baino handiagoa bada.
    ///
    /// # Aborts
    ///
    /// OOM-en bertan behera uzten du.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity` bezala, baina bufferra zeroan jartzen duela bermatzen du.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// `RawVec` bat ordezkatzen du erakusle eta edukiera batetik.
    ///
    /// # Safety
    ///
    /// `ptr` esleitu behar da (sistemaren pilan), eta emandako `capacity` arekin.
    /// `capacity`-k ezin du `isize::MAX` baino handiagoa tamaina motakoetan.(32 bit-eko sistemetan kezka bakarrik).
    /// ZST vectors-k `usize::MAX` arteko edukiera izan dezake.
    /// `ptr` eta `capacity` `RawVec` batetik badatoz, hori bermatuta dago.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Txiki Vecs mutuak dira.Hona jo:
    // - 8 elementuaren tamaina 1 bada, edozein muntatzaileren esleitzaileek 8 byte baino gutxiagoko eskaera 8 byteko gutxienez biribilduko baitute.
    //
    // - 4 elementuak neurri ertainekoak badira (<=1 KiB).
    // - 1 bestela, Vecs oso laburrei leku gehiegi alferrik galtzea ekiditeko.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` bezala, baina itzulitako `RawVec` aren esleitzailearen aukeran parametrizatua.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` "unallocated" esan nahi du.zero tamainako motak ez dira kontuan hartzen.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` bezala, baina itzulitako `RawVec` aren esleitzailearen aukeran parametrizatua.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` bezala, baina itzulitako `RawVec` aren esleitzailearen aukeran parametrizatua.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` `RawVec<T>` bihurtzen du.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Buffer osoa `Box<[MaybeUninit<T>]>` bihurtzen du zehaztutako `len`-rekin.
    ///
    /// Kontuan izan horrek egin ditzakeen `cap` aldaketak behar bezala berreraikiko dituela.(Ikusi motaren deskribapena xehetasunetarako.)
    ///
    /// # Safety
    ///
    /// * `len` eskatutako azken edukiera baino handiagoa edo berdina izan behar du eta
    /// * `len` `self.capacity()` baino txikiagoa edo berdina izan behar du.
    ///
    /// Kontuan izan, eskatutako edukiera eta `self.capacity()` desberdinak izan daitezkeela, esleitzaile batek orokorrean eskatutako memoria bloke handiagoa koka eta itzul dezakeelako.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Egiaztatu segurtasun baldintzaren erdia (ezin dugu beste erdia egiaztatu).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Hemen `unwrap_or_else` saihesten dugu sortutako LLVM IR kopurua puzten duelako.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// `RawVec` bat ordezkatzen du erakusle, edukiera eta esleitzaile batetik.
    ///
    /// # Safety
    ///
    /// `ptr` esleitu behar da (emandako `alloc` esleitzailearen bidez), eta emandako `capacity` arekin.
    /// `capacity`-k ezin du `isize::MAX` baino handiagoa tamaina motakoetan.
    /// (32 bit-eko sistemetan kezka bakarrik).
    /// ZST vectors-k `usize::MAX` arteko edukiera izan dezake.
    /// `ptr` eta `capacity` `alloc` bidez sortutako `RawVec` batetik badatoz, hori bermatuta dago.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Erakusle gordina lortzen du esleipenaren hasierara arte.
    /// Kontuan izan hau `Unique::dangling()` dela `capacity == 0` edo `T` zero tamainakoa bada.
    /// Lehenengo kasuan, kontuz ibili behar duzu.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Esleipenaren edukiera lortzen du.
    ///
    /// Hau beti izango da `usize::MAX` `T` zero tamainakoa bada.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// `RawVec` honen babes-banatzaileari partekatutako erreferentzia bat ematen dio.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Esleitutako memoria zati bat dugu, beraz, uneko diseinua lortzeko exekuzio garaiko kontrolak saihestu ditzakegu.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Bermatzen du bufferrak gutxienez espazio nahikoa duela `len + additional` elementuak edukitzeko.
    /// Jadanik ez badu behar adinako edukiera, nahikoa leku birkokatuko du eta espazio lasai erosoa *O*(1) portaera amortizatua izateko.
    ///
    /// Jokabide hori mugatuko du panic beharrik gabe eragingo balu.
    ///
    /// `len` `self.capacity()` baino handiagoa bada, baliteke horrek eskatutako espazioa benetan banatzea.
    /// Hau ez da oso segurua, baina funtzio honen portaeran oinarritzen den *idazten duzun* kodea ez segurua apur daiteke.
    ///
    /// Hau ezin hobea da `extend` bezalako bulk-push eragiketa ezartzeko.
    ///
    /// # Panics
    ///
    /// Panics edukiera berriak `isize::MAX` byte baino handiagoa bada.
    ///
    /// # Aborts
    ///
    /// OOM-en bertan behera uzten du.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // erreserba bertan behera utzi edo izutu egingo litzateke len-ek `isize::MAX` gaindituko balu, beraz segurua da orain kontrolik gabe egitea.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve`-ren berdina da, baina izuak edo abortatu ordez akatsak itzultzen ditu.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Bermatzen du bufferrak gutxienez espazio nahikoa duela `len + additional` elementuak edukitzeko.
    /// Dagoeneko ez bada, beharrezkoa den gutxieneko memoria kopuratuko da.
    /// Oro har, beharrezkoa den memoria kopurua izango da, baina printzipioz esleitzaileak askatasun osoz eskatzen du baino gehiago eman dezake.
    ///
    ///
    /// `len` `self.capacity()` baino handiagoa bada, baliteke horrek eskatutako espazioa benetan banatzea.
    /// Hau ez da oso segurua, baina funtzio honen portaeran oinarritzen den *idazten duzun* kodea ez segurua apur daiteke.
    ///
    /// # Panics
    ///
    /// Panics edukiera berriak `isize::MAX` byte baino handiagoa bada.
    ///
    /// # Aborts
    ///
    /// OOM-en bertan behera uzten du.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact`-ren berdina da, baina izuak edo abortatu ordez akatsak itzultzen ditu.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Esleipena zehaztutako kopurura murrizten du.
    /// Emandako zenbatekoa 0 bada, benetan guztiz banatzen da.
    ///
    /// # Panics
    ///
    /// Panics emandako zenbatekoa uneko edukiera baino * handiagoa bada.
    ///
    /// # Aborts
    ///
    /// OOM-en bertan behera uzten du.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Beharrezkoa den gaitasun gehigarria betetzeko bufferra handitu behar bada itzultzen da.
    /// Batez ere, `grow` lerrokatu gabe erreserbako deiak egiteko aukera ematen du.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Metodo hau askotan instantziatu ohi da.Beraz, ahalik eta txikiena izatea nahi dugu, konpilazio denborak hobetzeko.
    // Baina bere edukia ahalik eta modu estatikoan konputagarria izatea nahi dugu, sortutako kodea azkarrago exekutatzeko.
    // Hori dela eta, metodo hau arretaz idazten da `T`-ren mende dagoen kode guztia bere baitan egon dadin, `T`-ren menpe ez dagoen kodearen ahalik eta `T`-ren gainean generikoak ez diren funtzioetan egon dadin.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Hori deitzen duten testuinguruek ziurtatzen dute.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // `usize::MAX`-ren edukiera itzultzen dugunez `elem_size` denean
            // 0, hona iristeak nahitaez esan nahi du `RawVec` gehiegizkoa dela.
            return Err(CapacityOverflow);
        }

        // Egia esan, ezin dugu ezer egin egiaztapen horiei buruz, zoritxarrez.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Horrek hazkunde esponentziala bermatzen du.
        // Bikoizketak ezin du gainezka egin, `cap <= isize::MAX` eta `cap` mota `usize` delako.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ez da generikoa `T` baino gehiago.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Metodo honen murriztapenak `grow_amortized`-en bezalakoak dira, baina metodo hau gutxiagotan ezartzen da, beraz, ez da hain kritikoa.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // `usize::MAX` edukiera itzultzen dugunez motaren tamaina denean
            // 0, hona iristeak nahitaez esan nahi du `RawVec` gehiegizkoa dela.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ez da generikoa `T` baino gehiago.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Funtzio hau `RawVec` kanpo dago konpilazio denborak minimizatzeko.Ikusi `RawVec::grow_amortized` goiko iruzkina xehetasunetarako.
// (`A` parametroa ez da esanguratsua, praktikan ikusitako `A` mota desberdinen kopurua `T` mota baino askoz txikiagoa delako).
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Hemen egiaztatu errorea `RawVec::grow_*` ren tamaina minimizatzeko.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Esleitzaileak lerrokaduraren berdintasuna egiaztatzen du
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec`*k duen memoria askatzen du* edukia askatzen saiatu gabe.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Erreserbako erroreak kudeatzeko funtzio nagusia.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Honako hau bermatu behar dugu:
// * Ez ditugu inoiz `> isize::MAX` byte tamainako objektuak esleitzen.
// * Ez dugu `usize::MAX` gainezka egiten eta benetan gutxi esleitzen dugu.
//
// 64 bit-etan gainezkatzea egiaztatu behar dugu, `> isize::MAX` byte-ak esleitzen saiatzeak huts egingo baitu.
// 32 biteko eta 16 biteko bideoetan guardia gehigarri bat gehitu behar dugu 4GB guztiak erabiltzailearen espazioan erabil ditzakeen plataforma batean ari garen kasuan, adibidez, PAE edo x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Gaitasunaren gainezkatzeen berri emateko ardura duen funtzio nagusia.
// Horrek ziurtatuko du panics horiekin erlazionatutako kodeen sorrera gutxienekoa dela, modulu osoan sorta bat baino panics baino kokapen bakarra dagoelako.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}