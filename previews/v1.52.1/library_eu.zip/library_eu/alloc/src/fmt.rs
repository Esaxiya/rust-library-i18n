//! `String`s formateatzeko eta inprimatzeko utilitateak.
//!
//! Modulu honek [`format!`] sintaxiaren luzapenaren exekuzio-euskarria du.
//! Makro hau konpiladorean inplementatzen da modulu honetara deiak igortzeko, exekuzio garaian argumentuak kateetan formateatzeko.
//!
//! # Usage
//!
//! [`format!`] makroa C's `printf`/`fprintf` funtzioetatik edo Python-ren `str.format` funtziotik datozenentzat ezaguna izan nahi du.
//!
//! [`format!`] luzapenaren adibide batzuk hauek dira:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" puntako zeroekin
//! ```
//!
//! Hauetatik, lehen argumentua formatu katea dela ikus dezakezu.Konpilatzaileak eskatzen du kate literala izan dadin;ezin da gainditutako aldagaia izan (baliozkotasuna egiaztatzeko).
//! Konpiladoreak formatu-katea aztertuko du eta emandako argudioen zerrenda formatu-kate honetara pasatzeko egokia den zehaztuko du.
//!
//! Balio bakarra kate bihurtzeko, erabili [`to_string`] metodoa.Honek [`Display`] formatua erabiliko du trait.
//!
//! ## Posizio parametroak
//!
//! Formateatzeko argumentu bakoitzari zein balio-argumentu aipatzen den zehazteko baimena ematen zaio eta kentzen bada "the next argument" dela suposatzen da.
//! Adibidez, `{} {} {}` formatu kateak hiru parametro hartuko lituzke, eta ematen den ordena berean formateatuko lirateke.
//! `{2} {1} {0}` kate formatuak, ordea, argumentuak alderantziz ordenatuko lituzke.
//!
//! Gauzak pixka bat korapilatsuak izan daitezke posizio zehaztapen mota biak nahasten hasten zarenean."next argument" zehaztzailea argumentuaren gaineko iteratzaile gisa har daiteke.
//! "next argument" zehaztzailea ikusten den bakoitzean, iteratzaileak aurrera egiten du.Honek honelako jokabidea dakar:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Argudioaren barneko iteratzailea ez da aurreratu lehen `{}` ikusten denerako, beraz, lehenengo argumentua inprimatzen du.Gero, `{}` bigarrenera iristean, iteratzaileak bigarren argumentura aurreratu du.
//! Funtsean, beren argumentua esplizituki izendatzen duten parametroek ez dute eragiten argumentu bat izendatzen ez duten parametroetan posizio zehaztapenen arabera.
//!
//! Formatu katea beharrezkoa da bere argumentu guztiak erabiltzeko, bestela, konpilazio-denbora akatsa da.Argumentu bera behin baino gehiagotan aipa dezakezu formatu katean.
//!
//! ## Parametro izendatuak
//!
//! Rust-k berak ez du izendatutako parametroen funtzio baten Python antzeko baliokiderik, baina [`format!`] makroa izendatutako parametroak baliatzea ahalbidetzen duen sintaxi luzapena da.
//! Izeneko parametroak argumentuen zerrendaren amaieran zerrendatuta daude eta sintaxia dute:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Adibidez, honako [`format!`] adierazpen hauek izendatutako argumentua erabiltzen dute:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Ez du balio posizio parametroak (izenik gabekoak) jartzea izenak dituzten argumentuen ondoren.Posizio parametroekin gertatzen den moduan, ez du balio formatu kateak erabiltzen ez dituen izendatutako parametroak emateak.
//!
//! # Formatuaren parametroak
//!
//! Formateatzen ari den argumentu bakoitza formateatzeko parametro batzuen bidez eraldatu daiteke (X001 X 01X-i dagozkionak. Parametro horiek formateatzen ari diren kateen irudikapenean eragina dute.
//!
//! ## Width
//!
//! ```
//! // Hauek guztiak inprimatu "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Formatuak hartu beharko lukeen "minimum width" parametroa da.
//! Balioaren kateak karaktere asko betetzen ez baditu, fill/alignment-k zehaztutako betegarria erabiliko da beharrezko lekua hartzeko (ikus beherago).
//!
//! Zabaleraren balioa [`usize`] gisa ere eman daiteke parametroen zerrendan `$` postfix bat gehituz, bigarren argumentua zabalera zehazten duen [`usize`] dela adieraziz.
//!
//! Dolarreko sintaxia duen argumentu bat aipatzeak ez du "next argument" kontagailuan eragiten, beraz, ideia ona izan ohi da argumentuen posizioaren arabera aipatzea edo izendatutako argumentuak erabiltzea.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Aukerako betegarria eta lerrokadura normalean [`width`](#width) parametroarekin batera ematen dira.`width` aurretik definitu behar da, `:` ondoren.
//! Horrek adierazten du formateatzen ari den balioa `width` baino txikiagoa bada, karaktere gehigarri batzuk inprimatuko direla inguruan.
//! Betetzea honako aldaera hauetan dator lerrokatze desberdinetarako:
//!
//! * `[fill]<` - argumentua ezkerretara lerrokatuta dago `width` zutabeetan
//! * `[fill]^` - argumentua erdian lerrokatuta dago `width` zutabeetan
//! * `[fill]>` - argumentua eskuinera lerrokatuta dago `width` zutabeetan
//!
//! Zenbakizkoak ez diren [fill/alignment](#fillalignment) lehenetsia zuriunea da eta ezkerrean lerrokatuta dago.Zenbakizko formatuen lehenetsia espazio karakterea ere bada, baina eskuinera lerrokatuta dago.
//! Zenbakietan `0` bandera (ikus beherago) zehazten bada, betetze karaktere inplizitua `0` da.
//!
//! Kontuan izan lerrokatzea litekeena dela zenbait motak ezartzea.Bereziki, normalean ez da `Debug` trait-rako inplementatzen.
//! Betegarria aplikatzen dela ziurtatzeko modu ona zure sarrera formateatzea da, eta ondoren lortutako kate hau pad zure irteera lortzeko:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Kaixo Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Horiek guztiak formateatzailearen portaera aldatzen duten banderak dira.
//!
//! * `+` - Zenbaki motetarako pentsatuta dago eta ikurra beti inprimatu behar dela adierazten du.Zeinu positiboak ez dira sekula lehenespenez inprimatzen, eta ezezkoak `Signed` trait-erako soilik inprimatzen dira lehenespenez.
//! Bandera honek adierazten du zeinu zuzena (`+` edo `-`) beti inprimatu behar dela.
//! * `-` - Une honetan ez da erabiltzen
//! * `#` - Bandera honek "alternate" inprimatzeko modua erabili behar dela adierazten du.Ordezko formak hauek dira:
//!     * `#?` - nahiko inprimatu [`Debug`] formatua
//!     * `#x` - argumentua `0x` batekin aurretik doa
//!     * `#X` - argumentua `0x` batekin aurretik doa
//!     * `#b` - argumentua `0b` batekin aurretik doa
//!     * `#o` - argumentua `0o` batekin aurretik doa
//! * `0` - Zenbaki osoentzako formatuetarako `width`-rako betegarria `0` karaktere batekin egin behar dela adierazteko eta zeinuen berri izan behar dela adierazteko erabiltzen da.
//! `{:08}` bezalako formatu batek `00000001` emango luke `1` zenbaki osoarentzat, eta formatu berdinak `-0000001` emango luke `-1` zenbaki osoarentzat.
//! Ohartu bertsio negatiboak bertsio positiboak baino zero bat gutxiago duela.
//!         Kontuan izan betegarri zeroak zeinuaren ondoren (baldin badago) eta digituen aurretik jartzen direla.`#` bandarekin batera erabiltzen denean, antzeko arau bat aplikatzen da: betegarriaren zeroak aurrizkiaren ondoren sartzen dira baina digituen aurretik.
//!         Aurrizkia zabalera osoaren barne dago.
//!
//! ## Precision
//!
//! Zenbakizkoak ez diren motetarako, hau "maximum width" gisa har daiteke.
//! Lortutako katea zabalera hori baino luzeagoa bada, orduan karaktere ugari mozten da eta balio moztu hori `fill`, `alignment` eta `width` egokiekin igortzen da parametro horiek ezarrita badaude.
//!
//! Mota integraletarako, hori ez da kontuan hartzen.
//!
//! Puntu mugikorreko motetan, puntu hamartarraren ondoren zenbat zenbaki inprimatu behar diren adierazten du.
//!
//! Nahi duzun `precision` zehazteko hiru modu daude:
//!
//! 1. `.N` zenbaki oso bat:
//!
//!    `N` zenbaki osoa bera da zehaztasuna.
//!
//! 2. Zenbaki oso bat edo izen bat eta ondoren `.N$` dolarraren ikurra:
//!
//!    erabili formatua *argumentua*`N` (`usize` izan behar du) zehaztasun gisa.
//!
//! 3. `.*` izartxo bat:
//!
//!    `.*` esan nahi du `{...}` hau *bi* formatuko sarrerekin lotu behar dela bat baino gehiago: lehenengo sarrerak `usize` zehaztasuna du eta bigarrenak inprimatzeko balioa dauka.
//!    Kontuan izan kasu honetan, `{<arg>:<spec>.*}` formatu katea erabiltzen baduzu, `<arg>` zatiak inprimatzeko* balioa * aipatzen duela eta `precision` `<arg>` aurreko sarreran sartu behar dela.
//!
//! Adibidez, hurrengo deiek `Hello x is 0.01000` gauza bera inprimatzen dute:
//!
//! ```
//! // Kaixo {arg 0 ("x")} {arg 1 (0.01) with precision specified inline (5)} da
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Kaixo {arg 1 ("x")} {arg 2 (0.01) with precision specified in arg 0 (5)} da
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Kaixo {arg 0 ("x")} {arg 2 (0.01) with precision specified in arg 1 (5)} da
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Kaixo {next arg ("x")} {second of next two args (0.01) with precision specified in first of next two args (5)} da
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Kaixo {next arg ("x")} {arg 2 (0.01) with precision specified in its predecessor (5)} da
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Kaixo {next arg ("x")} {arg "number" (0.01) with precision specified in arg "prec" (5)} da
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Hauek bitartean:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! inprimatu hiru gauza nabarmen desberdin:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Programazio lengoaia batzuetan, katea formateatzeko funtzioen portaera sistema eragilearen ezarpen lokalaren araberakoa da.
//! Rust-ren liburutegi estandarrak eskaintzen dituen formatu funtzioek ez dute tokiko kontzepturik eta emaitza berdinak sortuko dituzte sistema guztietan erabiltzailearen konfigurazioa edozein dela ere.
//!
//! Adibidez, honako kode honek `1.5` inprimatuko du beti sistemaren lokalak puntu bat ez den bereizle hamartarra erabiltzen badu ere.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! `{` eta `}` karaktere literalak kate batean sar daitezke karaktere berarekin aurretik jarriz.Adibidez, `{` karakterea `{{`-rekin ihes egiten da eta `}` karakterea `}}`-rekin ihes egiten da.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Laburbilduz, hemen formatu-kateen gramatika osoa aurki dezakezu.
//! Erabilitako formatu-hizkuntzaren sintaxia beste hizkuntza batzuetatik ateratakoa da, beraz ez luke arrotzegia izan behar.Argumentuak Python moduko sintaxiarekin formateatuta daude, hau da, argumentuak C-moduko `%` aren ordez `{}` inguratuta daude.
//! Formatuaren sintaxiaren benetako gramatika hau da:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Goiko gramatikan, `text`-k ezin du `'{'` edo `'}'` karaktererik eduki.
//!
//! # traits formateatzea
//!
//! Argumentu bat mota jakin batekin formateatzea eskatzerakoan, benetan argumentu bat trait jakin bati esleitzea eskatzen ari zara.
//! Horri esker, benetako mota ugari `{:x}` bidez formateatu daitezke ([`i8`] eta [`isize`] bezala).traits motako uneko mapaketa hau da:
//!
//! * *ezer ez* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] minuskulako zenbaki oso hamaseitarrekin
//! * `X?` ⇒ [`Debug`] maiuskulak zenbaki oso hamaseitarrekin
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Horrek esan nahi duena da [`fmt::Binary`][`Binary`] trait inplementatzen duen edozein argumentu mota `{:b}`-rekin formateatu daitekeela.Liburutegi estandarrak ere ematen ditu traits horientzako inplementazioak mota primitibo batzuetarako.
//!
//! Formaturik zehazten ez bada (`{}` edo `{:6}`-en bezala), orduan erabilitako trait formatua [`Display`] trait da.
//!
//! Zure motako trait formatua ezartzerakoan, sinaduraren metodoa ezarri beharko duzu:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // gure pertsonalizatutako mota
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Zure mota `self` erreferentzia gisa pasatuko da eta, ondoren, funtzioak `f.buf` korrontera irteera igorri beharko luke.trait inplementazioaren formatu bakoitzari dagokio eskatutako formatu parametroei behar bezala atxikitzea.
//! Parametro horien balioak [`Formatter`] egitaren eremuetan zerrendatuko dira.Horretan laguntzeko, [`Formatter`] egiturak laguntza-metodo batzuk ere eskaintzen ditu.
//!
//! Gainera, funtzio honen itzulera-balioa [`fmt::Result`] da, hau da, [`Emaitza`]`<(),`[`std: : fmt::Error`] `>` `alias mota da.
//! Formateatzeko inplementazioek [`Formatter`]-etik (adibidez, [`write!`] deitzerakoan) akatsak hedatzen dituztela ziurtatu behar dute.
//! Hala ere, ez dituzte inoiz akatsak gezurrez itzuli behar.
//! Hau da, formateatze inplementazio batek errore bat itzuli behar du eta soilik pasatutako [`Formatter`]-k errore bat itzultzen badu.
//! Funtzioaren sinadurak iradoki dezakeenaren aurka, kateen formatua eragiketa hutsezina delako gertatzen da.
//! Funtzio honek emaitza bakarrik ematen du azpiko korrontean idazteak huts egin dezakeelako eta akatsen bat pilaren babeskopia gertatu dela hedatzeko modua eman behar du.
//!
//! traits formatua ezartzeko adibide bat honakoa izango litzateke:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // `f` balioa `Write` trait inplementatzen du, hori da idazten duena!makroa espero da.
//!         // Kontuan izan formatu honek kateak formateatzeko emandako banderak ez dituela kontuan hartzen.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // traits ezberdinek mota bateko irteera mota desberdinak onartzen dituzte.
//! // Formatu honen esanahia vector baten magnitudea inprimatzea da.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Errespetatu formateatzeko banderak `pad_integral` laguntza-metodoa erabiliz Formatter objektuan.
//!         // Ikusi metodoaren dokumentazioa xehetasunetarako, eta `pad` funtzioa kateak kuxinatzeko erabil daiteke.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Bi formatu traits hauek helburu desberdinak dituzte:
//!
//! - [`fmt::Display`][`Display`] inplementazioek baieztatzen dute mota hau uneoro UTF-8 kate gisa fidelki irudika daitekeela.Ez da **espero** mota guztiek [`Display`] trait ezartzea.
//! - [`fmt::Debug`][`Debug`] inplementazioak **mota publiko guztietarako** inplementatu beharko lirateke.
//!   Irteerak normalean barne egoera ahalik eta fidelen irudikatuko du.
//!   [`Debug`] trait-ren xedea Rust kodea arazteko erraztea da.Kasu gehienetan, nahikoa eta gomendagarria da `#[derive(Debug)]` erabiltzea.
//!
//! Bi traits-ren irteeraren adibide batzuk:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Lotutako makroak
//!
//! Lotutako makro ugari daude [`format!`] familian.Gaur egun ezartzen direnak hauek dira:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Hau eta [`writeln!`] formatu-katea zehaztutako korronte batera igortzeko erabiltzen diren bi makro dira.Hau formatu-kateen bitarteko esleipenak ekiditeko eta horren ordez irteera zuzenean idazteko erabiltzen da.
//! Kanpaiaren azpian, funtzio honek [`std::io::Write`] trait-n definitutako [`write_fmt`] funtzioa deitzen du.
//! Adibide erabilera hau da:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Honek eta [`println!`]-k irteera stdout-ra igortzen dute.[`write!`] makroaren antzera, makro horien helburua irteera inprimatzean tarteko esleipenak ekiditea da.Adibide erabilera hau da:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! [`eprint!`] eta [`eprintln!`] makroak [`print!`] eta [`println!`] berdinak dira, hurrenez hurren, beren irteera stderr ra igortzen ez badute izan ezik.
//!
//! ### `format_args!`
//!
//! Formatu katea deskribatzen duen objektu opako baten inguruan segurtasunez pasatzeko erabiltzen den makro bitxia da.Objektu honek ez du inolako muntaketa-esleipenik behar sortzeko, eta pilako informazioa soilik aipatzen du.
//! Kanpainaren azpian, horri lotutako makro guztiak inplementatzen dira.
//! Lehenik eta behin, adibide batzuk hauek dira:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! [`format_args!`] makroaren emaitza [`fmt::Arguments`] motako balioa da.
//! Ondoren egitura hau modulu honetako [`write`] eta [`format`] funtzioetara pasa daiteke formatu katea prozesatzeko.
//! Makro honen helburua are gehiago esleitzea bitarteko esleipenak saihestea da kateak formateatzerakoan.
//!
//! Adibidez, erregistro liburutegi batek formateatzeko sintaxi estandarra erabil lezake, baina barrutik egitura horren inguruan pasatuko litzateke irteera nora joan behar den zehaztu arte.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// `format` funtzioak [`Arguments`] egitura hartzen du eta ondorioz formateatutako katea itzultzen du.
///
///
/// [`Arguments`] instantzia [`format_args!`] makroarekin sor daiteke.
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Kontuan izan [`format!`] erabiltzea hobe daitekeela.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}