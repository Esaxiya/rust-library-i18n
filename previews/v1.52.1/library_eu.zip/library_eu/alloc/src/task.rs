#![stable(feature = "wake_trait", since = "1.51.0")]
//! Zeregin asinkronoekin lan egiteko motak eta Traits.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Betearazle bati zeregin bat esnatzearen inplementazioa.
///
/// trait hau [`Waker`] bat sortzeko erabil daiteke.
/// Exekutore batek trait honen inplementazioa defini dezake, eta hori Waker bat eraikitzeko erabil dezake exekutore horretan exekutatzen diren zereginetara pasatzeko.
///
/// trait hau memoria seguru eta ergonomikoa da [`RawWaker`] bat eraikitzeko.
/// Zeregin bat esnatzeko erabilitako datuak [`Arc`] batean gordetzen diren exekutore komunaren diseinua onartzen du.
/// Exekutore batzuek (batez ere sistema txertatuetakoek) ezin dute API hau erabili, horregatik [`RawWaker`] existitzen da sistema horien alternatiba gisa.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Oinarrizko `block_on` funtzioa, future hartzen duena eta uneko harian amaitzen duen arte exekutatzen duena.
///
/// **Note:** Adibide honek zuzentasuna zuzentzen du sinpletasunagatik.
/// Blokeoak saihesteko, produkzio mailako ezarpenek `thread::unpark` ra bitarteko deiak eta habiaratutako deiak kudeatu beharko dituzte.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Deitutakoan uneko haria esnatzen duen waker bat.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Exekutatu future uneko harian amaitu arte.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Ainguratu future galdeketa egin ahal izateko.
///     let mut fut = Box::pin(fut);
///
///     // Sortu testuinguru berria future-ra pasatzeko.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Exekutatu future amaitu arte.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Esnatu zeregin hau.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Esnatu zeregin hau waker kontsumitu gabe.
    ///
    /// Exekutore batek waker kontsumitu gabe esnatzeko modu merkeagoa onartzen badu, metodo hau gainidatzi beharko luke.
    /// Berez, [`Arc`] klonatzen du eta [`wake`] deitzen du klonean.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SEGURTASUNA: segurua da raw_waker segurtasunez eraikitzen delako
        // Arc-eko RawWaker bat<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: RawWaker bat eraikitzeko funtzio pribatu hau erabiltzen da baino
// hau `From<Arc<W>> for RawWaker` impl-en txertatuz, `From<Arc<W>> for Waker`-ren segurtasuna trait bidalketa zuzenaren mende ez dagoela ziurtatzeko, bi inplikazioek funtzio horri zuzenean eta esplizituki deitzen diote.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Gehitu arkuaren erreferentzia kopurua klonatzeko.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Esnatu balioaren arabera, Arkua Wake::wake funtziora mugituz
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Esnatu erreferentzia gisa, bildu waker-a ManuallyDrop-en, erortzen uzteko
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Jaitsi Arc-en erreferentzia kopurua gutxitu
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}