use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter rako erabiltzen den trait espezializazioa
///
/// ## Ordezkaritzaren grafikoa:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Ohiko kasua da vector pasatzea berehala berriro biltzen den vector funtzio batera.
        // Zirkuitu laburra egin dezakegu IntoIter batere aurreratu ez bada.
        // Aurreratu denean memoria ere berrerabili eta datuak aurrealdera eraman ditzakegu.
        // Baina hori lortzen dugun Vec-ek FromIterator inplementazio generikoaren bidez sortzeak baino erabili gabeko ahalmena izango ez lukeenean bakarrik egiten dugu.
        //
        // Muga hori ez da guztiz beharrezkoa, Vec-en esleipen portaera nahita zehaztu gabe baitago.
        // Baina aukera kontserbadorea da.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // spec_extend()-en esku utzi behar du, extend()-k berez spec_from-era delegatzen baitu Vecs hutsetarako
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Honek `iterator.as_slice().to_vec()` erabiltzen du spec_extend-ek urrats gehiago eman behar baititu azken edukiera + luzera arrazoitzeko eta horrela lan gehiago egiteko.
// `to_vec()` zuzenean zenbateko zuzena esleitzen du eta zehazki betetzen du.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test)-rekin berezko `[T]::to_vec` metodoa, hau da, metodoa definitzeko beharrezkoa ez dena, ez dago erabilgarri.
    // Horren ordez, erabili `slice::to_vec` funtzioa, hau da, cfg(test)-rekin soilik eskuragarri dago. Ikusi slice::hack modulua slice.rs-n informazio gehiago lortzeko
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}