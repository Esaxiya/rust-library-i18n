use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Espezializazio-markatzailea iturri-kanalizazioa Vec batean biltzeko iturburuko esleipena berrerabiliz, hau da
/// kanalizazioa bere lekuan exekutatzen.
///
/// SourceIter guraso trait beharrezkoa da funtzio espezializatzailea berrerabili nahi den esleipenera sartzeko.
/// Baina ez da nahikoa espezializazioa baliozkoa izateko.
/// Ikus mugan osagarriak aplikazioan.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-barneko SourceIter/InPlaceIterable traits egokitzailearen kateek soilik ezartzen dituzte <Adapter<Adapter<IntoIter>>> (guztiak core/std ren jabetzakoak).
// Egokitzaileen inplementazioen muga osagarriak (`impl<I: Trait> Trait for Adapter<I>` baino haratago) dagoeneko traits espezializazio gisa markatutako beste traits (Kopiatu, TrustedRandomAccess, FusedIterator) soilik daude.
//
// I.e. markatzailea ez dago erabiltzaileak emandako moten bizitzaren araberakoa.Modulatu Kopiatu zuloa, dagoeneko beste hainbat espezializazioaren mende baitago.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // trait bidez bounds bidez adierazi ezin diren baldintza osagarriak.Horren ordez, const eval-en oinarritzen gara:
        // a) ez da ZSTrik berrerabiltzeko esleipenik egongo ez balitz eta erakuslearen aritmetika izango litzateke panic b) tamaina bat dator Alloc kontratuak eskatzen duen moduan c) lerrokadurak bat datoz Alloc kontratuak eskatzen duen moduan
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // inplementazio generikoagoen atzera egitea
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // erabili try-fold geroztik
        // - hobeto moldatzen da iteratzaile egokitzaile batzuentzat
        // - barneko iterazio metodo gehienek ez bezala, &mut auto bat bakarrik hartzen du
        // - idazteko erakuslea bere barnealdetik hari eta azkenean berreskuratzeko aukera ematen digu
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iterazioak arrakasta izan du, ez jaitsi burua
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // egiaztatu SourceIter kontratua berretsi ote zen: ez balira, agian ez gara honaino iritsiko
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // egiaztatu InPlaceIterable kontratua.Hori posible da iteratzaileak iturburuko erakuslea aurreratu badu.
        // TrustedRandomAccess bidez kontrolik gabeko sarbidea erabiltzen badu iturburuko erakuslea hasierako posizioan mantenduko da eta ezin dugu erreferentzia gisa erabili.
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // jaregin gainerako balioak iturburuaren buztanean, baina saihestu esleipena bera jaistea IntoIter eremutik kanpora ateratzen bada panics jaregiten bada, orduan dst_buf-en bildutako elementuak ere isurtzen ditugu.
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable kontratua ezin da zehatz-mehatz egiaztatu hemen try_fold-ek iturburu erakusleari buruzko erreferentzia esklusiboa baitu. Egin dezakeguna da oraindik barrutian dagoen egiaztatzea.
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}