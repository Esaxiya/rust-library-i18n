// rsbegin.o eta rsend.o "compiler runtime startup objects" deiturikoak dira.
// Konpiladorearen exekuzio-denbora behar bezala abiarazteko beharrezko kodea dute.
//
// Irudi exekutagarri edo dylib bat estekatuta dagoenean, erabiltzaileen kode eta liburutegi guztiak "sandwiched" daude bi objektu fitxategi horien artean, beraz, rsbegin.o ren kodea edo datuak irudiaren atal bakoitzean lehenak dira, eta rsend.o ren kodea eta datuak azkenak dira.
// Efektu hau sinboloak atal baten hasieran edo amaieran jartzeko erabil daiteke, baita beharrezko goiburuak edo orri-oinak txertatzeko ere.
//
// Kontuan izan moduluaren sarrera puntua C exekuzio-denbora abiarazteko objektuan kokatzen dela (normalean `crtX.o` izenekoa), orduan exekuzioko beste osagai batzuen hasierako deiak deitzen ditu (beste irudi atal berezi baten bidez erregistratuta).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Pila markoaren hasierako markak deskonektatzen du informazio atala
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Desblokeatzailearen barneko liburuak gordetzeko marratu tartea.
    // Hau `struct object` gisa definitzen da $ GCC/unwind-dw2-fde.h-n.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Desblokeatu informazioa registration/deregistration errutinak.
    // Ikusi libpanic_unwind dokumentuko dokumentuak.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // erregistratu desblokeatu informazioa modulua abiaraztean
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // baja eman itzaltzean
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW espezifikoa init/uninit ohiko erregistroa
    pub mod mingw_init {
        // MinGWren hasierako objektuek (crt0.o/dllcrt0.o) eraikitzaile globalak deituko dituzte .ctors eta .dtors ataletan abiaraztean eta irteeran.
        // DLLen kasuan, DLLa kargatzen eta deskargatzen denean egiten da.
        //
        // Lokailuak atalak ordenatuko ditu, eta horrek bermatuko du deiak itzultzea zerrendaren amaieran kokatuko direla.
        // Eraikitzaileak alderantzizko ordenan exekutatzen direnez, horrek ziurtatzen du gure dei itzultzea lehenengo eta azken exekutatuak direla.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C hasierako deiak itzultzea
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .medikuak. *: C amaierako deiak
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}