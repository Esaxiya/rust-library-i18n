use backtrace::Backtrace;

// Proba hau sinbolo baten hasierako helbidea jakinarazten duten fotogrametarako `symbol_address` funtzioa duten plataformetan bakarrik funtzionatzen du.
// Ondorioz, plataforma batzuetan bakarrik gaituta dago.
//
const ENABLED: bool = cfg!(all(
    // Windows ez da benetan probatu, eta OSX-k ez du onartzen itxitura markoa aurkitzea, beraz desgaitu hau
    //
    target_os = "linux",
    // ARM-n topaketa funtzioa aurkitzean ip bera itzultzea besterik ez da.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}