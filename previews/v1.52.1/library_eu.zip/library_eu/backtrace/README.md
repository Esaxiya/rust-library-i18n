# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Rust rako exekuzio garaian atzerakarrak eskuratzeko liburutegia.
Liburutegi honek liburutegi estandarraren laguntza hobetzea du helburu, lan egiteko interfaze programatikoa eskainiz, baina libstd-ren panics bezalako uneko atzerako arrastoa erraz inprimatzea ere onartzen du.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Atzera traza harrapatzeko eta horri aurre egiteko gerora arte atzeratzeko, goi mailako `Backtrace` mota erabil dezakezu.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Hala ere, benetako trazaduraren funtziorako sarbide gordinagoa nahi baduzu, `trace` eta `resolve` funtzioak zuzenean erabil ditzakezu.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Ebatzi argibide erakuslea sinbolo izen batera
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // jarraitu hurrengo fotogramara
    });
}
```

# License

Proiektu hau lizentziapean dago

 * Apache lizentzia, 2.0, ([LICENSE-APACHE](LICENSE-APACHE) edo http://www.apache.org/licenses/LICENSE-2.0 bertsioa)
 * MIT lizentzia ([LICENSE-MIT](LICENSE-MIT) edo http://opensource.org/licenses/MIT)

zure aukeran.

### Contribution

Espresuki kontrakoa adierazi ezean, zuk nahita aurkeztutako ekarpenek zuk egindako backtrace-rs-ra sartzeko, Apache-2.0 lizentzian zehaztutako moduan, goiko lizentzia bikoitza izango da, inolako baldintza edo baldintza gehigarririk gabe.







