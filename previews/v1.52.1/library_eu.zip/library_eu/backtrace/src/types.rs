//! Plataformaren menpeko motak.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// Kate baten irudikapen plataforma independentea.
/// `std` gaituta lan egiten duzunean `std` motetarako bihurketak emateko metodo egokiak gomendatzen dira.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// Xerra bat, normalean Unix plataformetan ematen dena.
    Bytes(&'a [u8]),
    /// Kate zabalak normalean Windows-tik.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Lossy `Cow<str>` bihurtzen da, `Bytes` baliozkoa ez bada UTF-8 edo `BytesOrWideString` `Wide` bada esleituko da.
    ///
    /// # Beharrezko ezaugarriak
    ///
    /// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// `BytesOrWideString`-ren `Path` irudikapena eskaintzen du.
    ///
    /// # Beharrezko ezaugarriak
    ///
    /// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}