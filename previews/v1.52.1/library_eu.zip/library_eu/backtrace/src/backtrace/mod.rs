use core::ffi::c_void;
use core::fmt;

/// Uneko dei-pila ikuskatzen du, fotograma aktibo guztiak emandako itxierara pasatuz pila traza kalkulatzeko.
///
/// Funtzio hau liburutegi honen programa da programa baten pila aztarnak kalkulatzeko.Emandako itxiera `cb`-k `Frame`-ren kasuak ematen ditu, deian marko horri buruzko informazioa adierazten dutenak.
/// Itxiera markoak goitik beherako moduan ematen dira (azkenean funtzioak deitzen dira lehenik).
///
/// Itxieraren itzulera balioa atzerako trazatuak jarraitu behar duen ala ez adierazten du.`false`-ren itzulketa-balioa atzerako traza amaitu eta berehala itzuliko da.
///
/// `Frame` eskuratzen duzunean `backtrace::resolve` deitu nahi izango duzu `ip` (instrukzio erakuslea) edo sinboloaren helbidea `Symbol` bihurtzeko eta horren bidez izena eta/edo fitxategi izena/lerro zenbakia ikas daiteke.
///
///
/// Kontuan izan maila nahiko baxuko funtzioa dela eta, adibidez, atzera arrasto bat geroago ikuskatu nahi baduzu, `Backtrace` mota egokiagoa izan daitekeela.
///
/// # Beharrezko ezaugarriak
///
/// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
///
/// # Panics
///
/// Funtzio hau ez da inoiz panic izaten saiatzen, baina `cb`-k panics ematen badu plataforma batzuek panic bikoitza behartuko dute prozesua bertan behera uzteko.
/// Plataforma batzuek C liburutegia erabiltzen dute, barrutik desblokeatu ezin diren deiak itzultzen dituztenak, beraz, `cb`-en izua izateak prozesua bertan behera uztea eragin dezake.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // jarraitu traza atzean
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// `trace` bezalakoa, ez da segurua sinkronizatuta ez dagoenez.
///
/// Funtzio honek ez du sinkronizazio bermerik, baina eskuragarri dago crate honen `std` eginbidea konpilatzen ez denean.
/// Ikusi `trace` funtzioa dokumentazio eta adibide gehiagorako.
///
/// # Panics
///
/// Ikusi `trace`-ri buruzko informazioa `cb` izutzeko ohartarazpenetarako.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Atzera arrasto baten marko bat irudikatzen duen trait bat crate honen `trace` funtzioari eman zaio.
///
/// Trazatze funtzioaren itxierak fotogramak emango ditu, eta fotograma ia bidaltzen da, azpiko inplementazioa ez baita beti exekuziora arte ezagutzen.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Marko honen uneko instrukzio erakuslea ematen du.
    ///
    /// Hau normalean markoan exekutatzen den hurrengo instrukzioa da, baina inplementazio guztiek ez dute hori% 100eko zehaztasunarekin zerrendatzen (baina orokorrean nahiko gertu dago).
    ///
    ///
    /// Balio hau `backtrace::resolve`-era pasatzea gomendatzen da sinbolo izen bihurtzeko.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Marko honen uneko pila erakuslea itzultzen du.
    ///
    /// Backend batek ezin du marko horretako pila erakuslea berreskuratu, erakusle nulua itzuliko da.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Funtzio honen markoaren hasierako sinboloaren helbidea ematen du.
    ///
    /// Honek `ip`-ek funtzioaren hasierara itzultzen duen instrukzio erakuslea atzeratzen saiatuko da, balio hori itzuliz.
    ///
    /// Zenbait kasutan, ordea, backend-ek `ip` itzuliko dute funtzio honetatik.
    ///
    /// Itzulitako balioa batzuetan erabil daiteke `backtrace::resolve`-ek goian emandako `ip` ean huts egin badu.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Markoa dagokion moduluko oinarrizko helbidea itzultzen du.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Hau lehenbailehen etorri behar da, Miri ostalari plataformaren aurrean lehentasuna izan dadin
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // dbghelp-en soilik erabiltzen da sinbolizatzen
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}