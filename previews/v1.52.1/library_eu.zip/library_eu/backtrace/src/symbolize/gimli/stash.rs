// Linux-n soilik erabiltzen da oraintxe, beraz, baimendu hildako kodea beste leku batzuetan
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Byte bufferretarako arena banatzaile erraza.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Zehaztutako tamainako buffer bat esleitzen du eta erreferentzia aldakorra ematen dio.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SEGURTASUNA: aldagarri bat eraikitzen duen funtzio bakarra da
        // `self.buffers` erreferentzia.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SEGURTASUNA: inoiz ez ditugu elementuak `self.buffers`-etik kentzen, beraz erreferentzia
        // edozein bufferreko datuetara `self`-k bizi duen bitartean biziko da.
        &mut buffers[i]
    }
}