//! Sinbolizaziorako laguntza `gimli` crate erabiliz crates.io-n
//!
//! Hau da Rust-ren sinbolizazio inplementazio lehenetsia.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'Bizitza estatikoa egitura autoerreferentzialen laguntza ezaren inguruan hackeatzeko gezurra da.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Bihurtu bizitza estatikoetara, sinboloek `map` eta `stash` bakarrik maileguan hartu behar baitituzte eta jarraian gordeko ditugu.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Windows-en jatorrizko liburutegiak kargatzeko, ikusi rust-lang/rust#71060-ri buruzko eztabaida hemen dauden estrategia desberdinetarako.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW liburutegiek gaur egun ez dute ASLR (rust-lang/rust#16514) onartzen, baina DLLak helbide-espazioan lekuz aldatu daitezke.
            // Badirudi arazketa-informazioan helbideak liburutegi hau "image base" gailuan kargatu izan balitz bezala, hau da, COFF fitxategien goiburuetako eremua dela.
            // Badirudi hau debuginfo-k zerrendatzen duela sinboloen taula aztertu eta helbideak gordetzen ditugu liburutegia "image base"-n ere kargatuta egongo balitz bezala.
            //
            // Baliteke liburutegia "image base" telefonoan ez kargatzea.
            // (ustez beste zerbait kargatu daiteke bertan?) Hortxe sartzen da jokoan `bias` eremua, eta `bias`-ren balioa irudikatu behar dugu hemen.Zoritxarrez baina ez dago argi nola eskuratu kargatutako modulu batetik.
            // Badugu, ordea, benetako kargaren helbidea (`modBaseAddr`).
            //
            // Oraingoz kopiatze modura fitxategia mapatzen dugu, fitxategiaren goiburuko informazioa irakurtzen dugu eta gero mmap-a askatzen dugu.Hau xahutzailea da, seguruenik mmap berriro irekiko dugulako, baina oraingoz nahikoa ondo funtzionatu beharko luke.
            //
            // `image_base` (nahi dugun kargaren kokapena) eta `base_addr` (benetako kargaren kokapena) ditugunean `bias` bete dezakegu (benetakoaren eta nahi denaren arteko aldea) eta, ondoren, segmentu bakoitzaren helbidea `image_base` da, fitxategiak dioena baita.
            //
            //
            // Oraingoz badirudi ELF/MachO ez bezala liburutegi bakoitzeko segmentu batekin moldatu gaitezkeela, `modBaseSize` tamaina osoz erabiliz.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS Mach-O fitxategi formatua erabiltzen du eta DYLD berariazko APIak erabiltzen ditu aplikazioaren parte diren jatorrizko liburutegien zerrenda kargatzeko.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Eskuratu liburutegi honen izena ere kargatzeko lekuaren bideari dagokiona.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Kargatu liburutegi honen irudiaren goiburua eta delegatu `object`-ra karga komando guztiak aztertzeko, hemen parte hartzen duten segmentu guztiak irudikatu ahal izateko.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Iteratu segmentuen gainean eta erregistratu ezagutzen ditugun eskualdeetarako eskualde ezagunak.
            // Gainera, testu-segmentuen informazioa erregistratu geroago prozesatzeko, ikusi beheko iruzkinak.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Zehaztu liburutegi honen "slide", azkenean memoriako objektuak non kargatzen diren jakiteko erabiltzen dugun alborapena izanik.
            // Hau konputazio bitxi samarra da eta basatian gauza batzuk probatzearen eta zer makila ikustearen ondorioa da.
            //
            // Ideia orokorra da `bias` gehi segmentu baten `stated_virtual_memory_address` izango dela segmentua benetako helbide-espazioan.
            // Fidatzen garen beste gauza bat da benetako helbidea ken `bias` ikur-taulan eta debuginfo-an bilatzeko indizea dela.
            //
            // Gertatzen da, ordea, sistemaz kargatutako liburutegietan kalkulu horiek okerrak direla.Jatorrizko exekutagarrientzat, ordea, zuzena dirudi.
            // LLDB-ren iturritik logika batzuk altxatuz gero, `__TEXT` ataleko 0 fitxategiaren offset-etik tamaina zero ez den karkasa berezi batzuk ditu.
            // Arrazoia edozein dela ere, badirudi sinboloen taula liburutegiko vmaddr diapositibarekin erlatiboa dela esan nahi duela.
            // *Ez* badago sinbolo-taula vmaddr diapositibarekin eta segmentuaren adierazitako helbidearekiko erlatiboa da.
            //
            // Egoera honi aurre egiteko fitxategiaren zero konpentsazioan testu atalik aurkitzen ez badugu, orduan alborapena handitzen dugu lehen testu atalen adierazitako helbidearen arabera eta adierazitako helbide guztiak ere kopuru horretatik murrizten ditugu.
            //
            // Horrela, ikur-taula liburutegiaren alborapen kopuruaren aldean agertzen da.
            // Badirudi emaitza egokiak dituela sinbolo taularen bidez sinbolizatzeko.
            //
            // Egia esanda, ez nago guztiz ziur hori zuzena den edo hori nola egin behar duen adierazi behar duen beste zerbait dagoen.
            // Oraingoz badirudi honek nahikoa ondo funtzionatzen duela (?) eta behar izanez gero beti moldatu beharko genuke hori denborarekin.
            //
            // Informazio gehiago nahi izanez gero, ikus #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Beste Unix batzuk (adibidez
        // Linux) plataformek ELF erabiltzen dute objektu fitxategi formatu gisa eta normalean `dl_iterate_phdr` izeneko APIa ezartzen dute bertako liburutegiak kargatzeko.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` baliozko erakusleak izan beharko luke.
        // `vec` baliozko erakuslea izan beharko luke `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ez du natiboki arazketa informazioa onartzen, baina eraikuntza sistemak arazketa informazioa `romfs:/debug_info.elf` bidean jarriko du.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Beste guztiek ELF erabili beharko lukete, baina ez daki jatorrizko liburutegiak nola kargatu.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Kargatu diren liburutegi partekatu ezagun guztiak.
    libraries: Vec<Library>,

    /// Mappings cache-a analizatutako nano informazioa gordetzen dugu.
    ///
    /// Zerrenda honek ez du sekula handitzen bere iraupen osorako edukiera finkoa.
    /// Bikote bakoitzaren `usize` elementua goiko `libraries`-ren aurkibidea da eta bertan `usize::max_value()` uneko exekutagarria irudikatzen du.
    ///
    /// `Mapping` dagokion analizatutako nano informazioa da.
    ///
    /// Kontuan izan hau LRU cache bat dela funtsean eta hemen gauzak aldatuko ditugu helbideak sinbolizatzen ditugun heinean.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Liburutegi honen segmentuak memorian kargatuta eta non kargatuta dauden.
    segments: Vec<LibrarySegment>,
    /// Liburutegi honetako "bias" a, normalean memorian kargatzen den lekuan.
    /// Balio hori segmentu bakoitzaren adierazitako helbidera gehitzen da, segmentuak kargatzen duen memoria birtualeko helbide erreala lortzeko.
    /// Gainera, alborapen hau benetako memoria helbide birtualetatik kentzen da debuginfo eta sinbolo taulan indexatzeko.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Objektu fitxategian segmentu honen adierazitako helbidea.
    /// Hau ez da segmentua kargatzen den lekua, helbide hau gehi liburutegiaren `bias` da non aurkitu.
    ///
    stated_virtual_memory_address: usize,
    /// Memoriako segmentuaren tamaina.
    len: usize,
}

// ez da segurua, kanpotik sinkronizatuta egon behar delako
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // ez da segurua, kanpotik sinkronizatuta egon behar delako
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // LRU cache oso txikia eta oso erraza, arazketa-informazioaren mapak egiteko.
        //
        // Kolpe tasak oso altua izan behar du, izan ere, pila tipikoa ez da partekatutako liburutegi askoren artean gurutzatzen.
        //
        // `addr2line::Context` egiturak sortzea nahiko garestia da.
        // Bere kostua amortizatzea espero da ondorengo `locate` kontsulten bidez, `addr2line: : Context`s eraikitzerakoan eraikitako egiturak aprobetxatzen baitituzte azkartasun politak lortzeko.
        //
        // Caché hori izango ez bagenu, amortizazio hori ez litzateke inoiz gertatuko eta atzeko aztarna sinbolizatzaileak ssssllllooooowwww izango lirateke.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Lehenik eta behin, probatu `lib` honek `addr` (lekualdatzea kudeatzea) duen segmenturen bat duen.Egiaztapen hau gainditzen badu, jarraian jarrai dezakegu eta helbidea itzul dezakegu.
                //
                // Kontuan izan `wrapping_add` erabiltzen ari garela hemen gainezkatze kontrolak ekiditeko.Basatian ikusi da SVMA + alderdiaren konputazioak gainezka egiten duela.
                // Gertatuko litzatekeen bitxi bat dirudi, baina seguru asko segmentu horiek alde batera uztea baino ez dugu egin dezakegun kopuru handirik, litekeena baita espaziora apuntatzea.
                //
                // Hau jatorriz rust-lang/backtrace-rs#329-en sortu zen.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Orain, `lib`-k `addr`-a duela jakinda, alborapenarekin konpentsa dezakegu adierazitako memoria birusaren helbidea aurkitzeko.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Aldaezina: baldintzapen hau ondoren itzuli gabe amaitu da
        // errore baten ondorioz, bide honen cache sarrera 0 indizean dago.

        if let Some(idx) = idx {
            // Kartografia cachean dagoenean, eraman aurrealdera.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Kartografia katxean ez dagoenean, sortu mapaketa berria, sartu katxearen aurrealdean eta kanporatu cache sarrerarik zaharrena behar izanez gero.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // ez ezazu `'static` bizitza iraungo, ziurtatu guk bakarrik dugula
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Zabaldu `sym`-ren bizitza `'static`-ra, zoritxarrez hemen eskatzen zaigulako, baina beti erreferentzia gisa ateratzen da, beraz, erreferentziarik ez da marko honetatik harago jarraitu behar.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Azkenean, lortu cacheko mapaketa edo sortu fitxategi honetarako mapaketa berria, eta ebaluatu DWARF informazioa helbide honetako file/line/name aurkitzeko.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Sinbolo honen markoaren informazioa kokatu ahal izan dugu eta `addr2line` ren markoak barnean ditu xehetasun bitxi guztiak.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Ezin izan da arazketa informazioa aurkitu, baina iratxo exekutagarriaren sinbolo taulan aurkitu dugu.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}