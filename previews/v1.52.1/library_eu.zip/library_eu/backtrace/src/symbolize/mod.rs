use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Ebatzi helbide bat sinbolo gisa, sinboloa zehaztutako itxierara pasatuz.
///
/// Funtzio honek emandako helbidea bilatuko du, esate baterako, tokiko sinboloen taula, sinboloen taula dinamikoa edo DWARF arazketa informazioa (aktibatutako inplementazioaren arabera) eman beharreko sinboloak aurkitzeko.
///
///
/// Itxiera ezin da deitu ebazpena ezin bada egin, eta lerrokatutako funtzioen kasuan behin baino gehiagotan ere deitu daiteke.
///
/// Emandako sinboloek zehaztutako `addr` exekuzioa adierazten dute, helbide horretarako file/line bikoteak itzuliz (eskuragarri badago).
///
/// Kontuan izan `Frame` bat baduzu, honen ordez `resolve_frame` funtzioa erabiltzea gomendatzen dela.
///
/// # Beharrezko ezaugarriak
///
/// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
///
/// # Panics
///
/// Funtzio hau ez da inoiz panic izaten saiatzen, baina `cb`-k panics ematen badu plataforma batzuek panic bikoitza behartuko dute prozesua bertan behera uzteko.
/// Plataforma batzuek C liburutegia erabiltzen dute, barrutik desblokeatu ezin diren deiak itzultzen dituztenak, beraz, `cb`-en izua izateak prozesua bertan behera uztea eragin dezake.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // goiko markoari soilik begiratu
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Ebatzi aurrez ateratako markoa ikur batera, sinboloa zehaztutako itxierara pasatuz.
///
/// Funtzio honek `resolve` ren funtzio bera betetzen du, salbu `Frame` bat hartzen duela argumentu gisa helbide baten ordez.
/// Horrek atzera-trazatuaren zenbait plataformaren inplementazioen bidez sinboloen informazio zehatzagoa edo lineako markoei buruzko informazioa eman dezake adibidez.
///
/// Ahal baduzu, erabiltzea gomendatzen da.
///
/// # Beharrezko ezaugarriak
///
/// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
///
/// # Panics
///
/// Funtzio hau ez da inoiz panic izaten saiatzen, baina `cb`-k panics ematen badu plataforma batzuek panic bikoitza behartuko dute prozesua bertan behera uzteko.
/// Plataforma batzuek C liburutegia erabiltzen dute, barrutik desblokeatu ezin diren deiak itzultzen dituztenak, beraz, `cb`-en izua izateak prozesua bertan behera uztea eragin dezake.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // goiko markoari soilik begiratu
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Pila fotogrametako IP balioak normalean (always?) instrukzioa dira *pila benetako arrastoa den* deiaren ondoren.
// Aktibatuta hau sinbolizatzeak filename/line zenbakia aurretik egotea eragiten du eta agian hutsunea funtzioaren amaiera gertu badago.
//
// Plataforma guztietan gertatzen dela ematen du funtsean, beraz, beti ebazitako ip batetik kentzen dugu bat aurreko deiaren instrukzioari ebazteko instrukzioa itzuli beharrean.
//
//
// Egokiena ez genuke hori egingo.
// Egokiena, `resolve` APIen deitzaileek hemen eskatuko genieke -1 eskuz egin dezaten eta kontuan izan dezatela *aurreko* instrukziorako kokapen informazioa nahi dutela, ez unekoa.
// Egokiena `Frame`-ra ere agertuko ginateke hurrengo instrukzioaren edo oraingoaren helbidea bagara.
//
// Oraingoz kezka nahiko hobea denez, barnetik beti kentzen dugu.
// Kontsumitzaileek lanean jarraitu beharko lukete eta emaitza nahiko onak lortu beharko genituzke, beraz, nahikoa ona izan beharko genuke.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` bezalakoa, ez da segurua sinkronizatuta ez dagoenez.
///
/// Funtzio honek ez du sinkronizazio bermerik, baina eskuragarri dago crate honen `std` eginbidea konpilatzen ez denean.
/// Ikusi `resolve` funtzioa dokumentazio eta adibide gehiagorako.
///
/// # Panics
///
/// Ikusi `resolve`-ri buruzko informazioa `cb` izutzeko ohartarazpenetarako.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` bezalakoa, ez da segurua sinkronizatuta ez dagoenez.
///
/// Funtzio honek ez du sinkronizazio bermerik, baina eskuragarri dago crate honen `std` eginbidea konpilatzen ez denean.
/// Ikusi `resolve_frame` funtzioa dokumentazio eta adibide gehiagorako.
///
/// # Panics
///
/// Ikusi `resolve_frame`-ri buruzko informazioa `cb` izutzeko ohartarazpenetarako.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Fitxategi bateko sinboloaren bereizmena adierazten duen trait.
///
/// trait hau trait objektu gisa ematen da `backtrace::resolve` funtzioari emandako itxierari, eta ia bidaltzen da ez dakigunez zein inplementazio dagoen atzean.
///
///
/// Sinbolo batek funtzio bati buruzko testuinguruaren informazioa eman dezake, adibidez izena, fitxategi izena, lerro zenbakia, helbide zehatza, etab.
/// Informazio guztia ez dago beti ikur batean eskuragarri, hala ere, metodo guztiek `Option` itzultzen dute.
///
///
pub struct Symbol {
    // TODO: bizitza osorako lotura hau azkenean `Symbol` ra arte mantendu behar da,
    // baina hori gaur egun aldaketa haustea da.
    // Oraingoz hau segurua da, `Symbol` erreferentzia bidez banatzen baita eta ezin da klonatu.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Funtzio honen izena itzultzen du.
    ///
    /// Itzulitako egitura sinboloaren izenaren inguruko hainbat propietate kontsultatzeko erabil daiteke:
    ///
    ///
    /// * `Display` inplementazioak desmangulatutako ikurra inprimatuko du.
    /// * Sinboloaren `str` balio gordina sar daiteke (baliozko utf-8 bada).
    /// * Sinboloaren izenaren byte gordinak sar daitezke.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Funtzio honen hasierako helbidea ematen du.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Fitxategiaren izen gordina zati gisa itzultzen du.
    /// Hau batez ere erabilgarria da `no_std` inguruneetarako.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Sinbolo hau une honetan exekutatzen ari den zutabearen zenbakia ematen du.
    ///
    /// Gaur egun gimli-k soilik ematen du balioa hemen eta orduan `filename`-k `Some` itzultzen badu soilik, eta, beraz, antzeko ohartarazpenak jasaten ditu.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Sinbolo hau exekutatzen ari den tokiaren lerroaren zenbakia ematen du.
    ///
    /// Itzultzeko balio hau normalean `Some` da `filename`-k `Some` itzultzen badu eta, ondorioz, antzeko ohartarazpenak jasan behar ditu.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Funtzio hau definitu den fitxategiaren izena itzultzen du.
    ///
    /// Une honetan libbacktrace edo gimli erabiltzen ari direnean bakarrik dago erabilgarri (adibidez
    /// unix plataformak beste) eta bitar bat debuginfo-rekin konpilatzen denean.
    /// Baldintza horietako bat ere ez bada betetzen, seguruenik `None` itzuliko da.
    ///
    /// # Beharrezko ezaugarriak
    ///
    /// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Agian C++ sinbolo analizatu bat, Rust gisa mangled ikurra analizatzeak huts egin badu.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Ziurtatu zero tamaina mantentzen duzula, `cpp_demangle` funtzioak desgaituta dagoenean kosturik izan ez dezan.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Sinbolo baten izenaren inguruan bilgarria, desmangatutako izenari, byte gordinari, kate gordinari eta abarri sarbide ergonomikoak eskaintzeko.
///
// Baimendu hildako kodea `cpp_demangle` funtzioa gaituta ez dagoenean.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Sinbolo izen berria sortzen du azpiko byte gordinetatik abiatuta.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// (mangled) ikurraren izen gordina `str` gisa itzultzen du ikurrak utf-8 balio badu.
    ///
    /// Erabili `Display` inplementazioa bertsio desegokia nahi baduzu.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Sinbolo gordinaren izena itzultzen du byteen zerrenda gisa
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Hau inprimatzeko desmangulatutako sinboloa benetan baliagarria ez bada, maneiatu errorea hemen modu bikainean kanpora ez hedatuz.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Helbideak sinbolizatzeko erabilitako memorian gordetako memoria hori berreskuratzen saiatu.
///
/// Metodo hau, bestela, orokorrean orokorrean cache edo harian gordetako DWARF informazioa edo antzekoa adierazten duten datu orokorren egiturak askatzen saiatuko da.
///
///
/// # Caveats
///
/// Funtzio hau beti erabilgarri badago ere ez du ezer egiten inplementazio gehienetan.
/// Dbghelp edo libbacktrace bezalako liburutegiek ez dute egoerarik banatu eta esleitutako memoria kudeatzeko erraztasunik eskaintzen.
/// Oraingoz crate honen `gimli-symbolize` funtzioa da funtzio horrek eragina duen ezaugarri bakarra.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}