//! Sinbolizazio estrategia libbacktrace-n DWARF-parsing kodea erabiliz.
//!
//! Libbacktrace C liburutegiak, normalean gcc-rekin banatuta, atzeko traza sortzeaz gain (benetan erabiltzen ez duguna) ere onartzen du atzeko trazatua sinbolizatzea eta lineako markoak bezalako gauzei buruzko arazketa nanoa tratatzea.
//!
//!
//! Hau nahiko korapilatsua da hemen hainbat kezka direla eta, baina oinarrizko ideia hau da:
//!
//! * Lehenik `backtrace_syminfo` deitzen diogu.Ahal izanez gero, sinboloen informazioa lortzen du sinbolo taula dinamikotik.
//! * Jarraian `backtrace_pcinfo` deitzen diogu.Honek debuginfo taulak aztertuko ditu erabilgarri badaude eta lineako markoei, fitxategi izenei, lerro zenbakiei eta abarri buruzko informazioa berreskuratzeko aukera emango digu.
//!
//! Nanoen taulak libbacktrace-n sartzeko iruzur ugari dago, baina, zorionez, ez da munduaren amaiera eta argi geratzen da behean irakurtzean.
//!
//! Hau da MSVC eta OSX ez diren plataformen sinbolizazio estrategia lehenetsia.Libstd-en OSX estrategia lehenetsia da.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Ahal izanez gero, nahiago du debuginfo-tik datorren `function` izena eta, adibidez, lineako markoetarako zehatzagoa izan daiteke.
                // Hori ez badago, ordea, itzuli `symname`-n zehaztutako sinbolo taulako izenera.
                //
                // Kontuan izan batzuetan `function` zertxobait hain zehatzak ez direla sentitzen, adibidez `try<i32,closure>` gisa zerrendatuta egoteak `std::panicking::try::do_call` ez du irakurtzen.
                //
                // Ez dago oso argi zergatik, baina orokorrean `function` izena zehatzagoa dirudi.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // ez egin ezer oraingoz
}

/// `data` erakuslearen mota `syminfo_cb` era pasatu da
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Behin dei hau `backtrace_syminfo`-tik deitzen denean ebazten hasten garenean `backtrace_pcinfo` deitzera joaten gara.
    // `backtrace_pcinfo` funtzioak arazketako informazioa kontsultatuko du eta file/line informazioa berreskuratzea bezalako gauzak egiteko aukera emango du, baita marko lerrokatuak ere.
    // Kontuan izan `backtrace_pcinfo`-k huts egin dezakeela edo ez duela gauza handirik arazketako informaziorik ez badago, beraz, hori gertatuz gero, ziur gaude deitzera deituko dugula gutxienez `syminfo_cb`-ren ikur batekin.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `data` erakuslearen mota `pcinfo_cb` era pasatu da
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace APIak egoera sortzea onartzen du, baina ez du egoera suntsitzea onartzen.
// Nik, pertsonalki, estatu bat sortu eta gero betirako bizitzeko esan nahi dela esan nahi dut.
//
// Egoera hau garbitzen duen at_exit() kudeatzailea erregistratzea gustatuko litzaidake, baina libbacktrace-k ez du horretarako modurik eskaintzen.
//
// Murrizketa hauekin, funtzio honek estatikoki gordetako cache egoera du, hau eskatzen den lehen aldian kalkulatzen dena.
//
// Gogoratu atzeko trazatua seriez gertatzen dela (blokeo global bat).
//
// Kontuan izan sinkronizazio falta hemen `resolve` kanpotik sinkronizatuta egotearen baldintzagatik dela.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Ez erabili libbacktrace-ren haririk gabeko gaitasunak, beti modu sinkronizatuan deitzen baitugu.
        //
        0,
        error_cb,
        ptr::null_mut(), // ez da aparteko daturik
    );

    return STATE;

    // Kontuan izan, libbacktrace-k funtzionatzeko DWARF arazteko informazioa aurkitu behar duela uneko exekutagarriaren.Normalean mekanismo batzuen bidez egiten du, besteak beste:
    //
    // * /proc/self/exe onartutako plataformetan
    // * Fitxategi-izena esplizituki pasatu zen egoera sortzerakoan
    //
    // Libbacktrace liburutegia C kodearen multzo handi bat da.Horrek modu naturalean esan nahi du memoriaren segurtasun ahultasunak dituela, batez ere gaizki eratutako debuginfoak kudeatzean.
    // Libstd-ek horietako askorekin egin du topo historikoki.
    //
    // /proc/self/exe erabiltzen bada, normalean hauek baztertu ditzakegu, libbacktrace "mostly correct" dela suposatzen baitugu eta, bestela, ez dituela gauza arrarorik egiten "attempted to be correct" arazte arazketa informazioarekin.
    //
    //
    // Hala ere, fitxategi izen bat pasatzen badugu, posible da zenbait plataformatan (BSDetan adibidez), non aktore maltzur batek fitxategi arbitrarioa kokapen horretan koka dezakeen.
    // Horrek esan nahi du libbacktrace fitxategi izen bati buruz esaten badiogu agian fitxategi arbitrarioa erabiltzen ari dela, baliteke segfaults-ak sortzea.
    // Libbacktrace ezer esaten ez badugu, ordea, ez du ezer egingo /proc/self/exe bezalako bideak onartzen ez dituzten plataformetan!
    //
    // Hori guztia kontuan hartuta, fitxategi izen batean *ez* pasatzen saiatzen gara, baina /proc/self/exe batere onartzen ez duten plataformetan egin behar dugu.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Kontuan izan, egokiena `std::env::current_exe` erabiliko genukeela, baina hemen ezin dugu `std` behar.
            //
            // Erabili `_NSGetExecutablePath` uneko bide exekutagarria eremu estatiko batean kargatzeko (txikiegia bada amore eman besterik ez duzu).
            //
            //
            // Kontuan izan libbacktrace-rekin oso fidatzen garela hemen exekutagarri hondatuetan ez hiltzeko, baina ziur asko ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows fitxategiak irekitzeko modua du; ireki ondoren ezin da ezabatu.
            // Hori da, oro har, hemen nahi duguna, gure exekutagarria gure azpitik aldatzen ez dela ziurtatu nahi dugulako libbacktrace-ri eman ondoren, zorionez, datu arbitrarioak libbacktrace-ra pasatzeko gaitasuna murriztuz (gaizki kudeatuta egon daiteke).
            //
            //
            // Hemen dantza pixka bat egiten dugula kontuan hartuta, gure irudiari sarraila moduko bat lortzen saiatzeko:
            //
            // * Lortu uneko prozesuaren heldulekua, kargatu bere fitxategi izena.
            // * Ireki fitxategi izen horri fitxategi bat eskuineko banderekin.
            // * Berriro kargatu uneko prozesuaren fitxategi izena, berdina dela ziurtatuz
            //
            // Hori guztia gainditzen badugu teorian, gure prozesuaren fitxategia ireki dugu eta ez dela aldatuko bermatuta gaude.Historikoki, mordo bat libstd-etik kopiatuta dago, beraz, hau da gertatzen ari zenaren interpretaziorik onena.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Hau memoria estatikoan bizi da, itzuli ahal izateko ..
                static mut BUF: [i8; N] = [0; N];
                // ... eta hau pilan bizi da aldi baterako denez
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // `handle` nahita isuri hemen, irekita edukitzeak fitxategi izen honen blokeoa gorde behar baitu.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Deusez amaitutako xerra itzuli nahi dugu, beraz, dena bete bada eta luzera osoa berdina bada, berdindu porrotarekin.
                //
                //
                // Bestela arrakasta itzultzerakoan ziurtatu nul byte zatian sartuta dagoela.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // atzealdeko akatsak alfonbra azpian daude
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Deitu `backtrace_syminfo` APIri (kodea irakurtzetik) `syminfo_cb`-ri deitu beharko lioke zehazki behin (edo akatsen batekin huts egin daiteke, ustez).
    // Gero `syminfo_cb` barruan gehiago maneiatzen dugu.
    //
    // Kontuan izan hori egiten dugula `syminfo`-k sinboloen taula kontsultatuko baitu, sinboloen izenak topatuz bitarrean arazketa-informaziorik ez badago ere.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}