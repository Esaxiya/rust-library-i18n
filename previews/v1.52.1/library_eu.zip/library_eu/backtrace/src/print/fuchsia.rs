use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr-k prozesuan estekatutako DSO bakoitzeko dl_phdr_info erakuslea jasoko duen dei-dei bat hartuko du.
    // dl_iterate_phdr-ek lokailu dinamikoa iterazioaren hasieratik amaierara blokeatuta dagoela ere ziurtatzen du.
    // Itzultzeak zero ez den balioa itzultzen badu iterazioa goiz amaitzen da.
    // 'data' dei bakoitzerako dei itzultzeko hirugarren argumentu gisa pasatuko da.
    // 'size' dl_phdr_info-ren tamaina ematen du.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Eraikuntza IDa eta oinarrizko programa batzuen goiburuko datuak aztertu behar ditugu eta horrek esan nahi du ELF espezifikazioko gauza batzuk ere behar ditugula.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Orain erreproduzitu beharko dugu, bitaz bit, fuksiaren egungo lokailu dinamikoak erabiltzen duen dl_phdr_info motaren egitura.
// Chromium-ek ABI muga hau eta crashpad-a ere baditu.
// Azkenean kasu hauek mugitu nahi genituzke iratxo bilaketa erabiltzeko, baina SDKn eman beharko genuke eta hori oraindik ez da egin.
//
// Horrela, gu (eta beraiek) itsatsita gaude libc fuksiarekin lotura estua izaten duen metodo hau erabili beharrean.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Ez dugu e_phoff eta e_phnum baliozkoak diren ala ez egiaztatzeko modurik.
    // libc-ek hori ziurtatu beharko luke guretzat, beraz segurua da hemen zati bat osatzea.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr-k 64 biteko ELF programa goiburua adierazten du xede-arkitekturaren amaieran.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr-k baliozko ELF programaren goiburua eta bere edukia adierazten ditu.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Ez dugu p_addr edo p_memsz baliozkoak diren egiaztatzeko modurik.
    // Fuksiaren libc-ek oharrak aztertzen ditu lehenik, beraz, hemen egoteagatik goiburu hauek baliozkoak izan behar dute.
    //
    // NoteIter-ek ez du azpiko datuak baliozkoak izatea eskatzen, baina mugak baliozkoak izatea eskatzen du.
    // Libc-ek hemen gure kasua dela ziurtatu duela ziurtatzen dugu.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Eraikuntza IDen ohar mota.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr-ek ELF oharren goiburua adierazten du helburuaren amaieran.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Oharrak ELF oharra adierazten du (goiburua + edukia).
// Izena u8 xerra gisa uzten da, ez baita beti amaierarik nulua eta rust-k nahikoa erraza da byteek ala biek bat egiten dutela egiaztatzea.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter-ek ohar segmentu batean zehar errepikatzeko aukera ematen dizu.
// Akats bat gertatu bezain laster amaitzen da edo ohar gehiago ez dago.
// Datu baliogabeak errepikatzen badituzu oharrik aurkitu ez balitz bezala funtzionatuko du.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Funtzio aldaezina da, emandako erakusleak eta tamainak irakurtzeko moduko byte sorta baliozkoa adierazten dutela.
    // Byte hauen edukia edozein izan daiteke, baina barrutiak balio izan behar du segurua izan dadin.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to lerrokatzen du 'x' 'to' byteko lerrokadurara 'to' 2ko potentzia dela suposatuz.
// Honek eredu estandar bat jarraitzen du C/C ++ ELF analizatzeko kodean, non (x + to, 1) eta -to erabiltzen diren.
// Rust-k ez du uzten usize ukatzen, beraz nik erabiltzen dut
// 2ren osagarria bihurketa hori birsortzeko.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4-k zatiaren zenbateko byte kontsumitzen ditu (badago) eta gainera azken xerra ondo lerrokatuta dagoela ziurtatzen du.
// Eskatutako byte kopurua handiegia bada edo gerora xerra birjarri ezin bada, geratzen diren byte nahikoak ez daudelako, Bat ere ez da itzuliko eta zati hori ez da aldatuko.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Funtzio honek ez du deitzaileak benetako aldaerarik izan behar, agian 'bytes' errendimendua lortzeko (eta arkitektura batzuen zuzentasunean) lerrokatuta egon behar izatea baino.
// Baliteke Elf_Nhdr eremuetako balioak zentzugabeak izatea, baina funtzio horrek ez du horrelakorik ziurtatzen.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Hau segurua da, nahikoa leku badago eta goiko if adierazpenean baieztatu besterik ez dugu egin behar.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Kontuan izan sice_of: :<Elf_Nhdr>() beti 4 byteko lerrokatuta dago.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Egiaztatu amaierara iritsi garen.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Transmititzen dugu nhdr bat, baina arretaz aztertzen dugu lortutako egitura.
        // Ez dugu namesz edo descsz fidatzen eta motaren arabera ez dugu segurtasunik gabeko erabakirik hartzen.
        //
        // Beraz, zabor osoa ateratzen badugu ere seguru egon beharko genuke.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Segmentu bat exekutagarria dela adierazten du.
const PERM_X: u32 = 0b00000001;
/// Segmentu bat idazteko modukoa dela adierazten du.
const PERM_W: u32 = 0b00000010;
/// Segmentu bat irakurgarria dela adierazten du.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Exekuzio garaian ELF segmentu bat adierazten du.
struct Segment {
    /// Segmentu honetako edukien iraupeneko helbide birtuala ematen du.
    addr: usize,
    /// Segmentu honen edukiaren memoria tamaina ematen du.
    size: usize,
    /// Moduluaren segmentu honen helbide birtuala ematen du ELF fitxategiarekin.
    mod_rel_addr: usize,
    /// ELF fitxategian aurkitutako baimenak ematen ditu.
    /// Baimen hauek ez dira zertan exekuzio garaian dauden baimenak izan.
    flags: Perm,
}

/// DSO batetik segmentuak errepikatzen uzten du.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ELF DSO (Dynamic Shared Object) adierazten du.
/// Mota honek benetako DSOn gordetako datuak aipatzen ditu bere kopia egin beharrean.
struct Dso<'a> {
    /// Lokailu dinamikoak beti ematen digu izena, nahiz eta izena hutsik egon.
    /// Exekutagarri nagusiaren kasuan izen hau hutsik egongo da.
    /// Partekatutako objektuaren kasuan soname izango da (ikus DT_SONAME).
    name: &'a str,
    /// Fuchsia-n ia binario guztiek eraikuntza IDak dituzte, baina ez da beharrezkoa.
    /// Ez dago DSO informazioa benetako ELF fitxategiarekin parekatzeko modurik build_id bat ez badago, beraz, DSO guztiek hemen edukitzea eskatzen dugu.
    ///
    /// Build_id gabeko DSOak ez dira kontuan hartzen.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// DSO honetako segmentuen gaineko iteratzailea itzultzen du.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Akats horiek DSO bakoitzari buruzko informazioa analizatzean sortzen diren arazoak kodetzen dituzte.
///
enum Error {
    /// NameError esan nahi du errore bat gertatu dela C estiloko katea rust kate bihurtzean.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError-ek esan nahi du ez dugula eraikitze IDrik aurkitu.
    /// Hau gerta liteke DSOk eraikuntza IDrik ez zuelako edo eraikuntza IDa duen segmentua gaizki eratuta dagoelako.
    ///
    BuildIDError,
}

/// Lotzaile dinamikoak prozesuan estekatutako DSO bakoitzeko 'dso' edo 'error' deitzen ditu.
///
///
/// # Arguments
///
/// * `visitor` - DSO bakoitzeko izeneko metodoetako bat izango duen DsoPrinter.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr-k info.name-k baliozko kokapena seinalatuko duela ziurtatzen du.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Funtzio honek Fuksia sinbolizatzailearen marka inprimatzen du DSO batean dagoen informazio guztian.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}