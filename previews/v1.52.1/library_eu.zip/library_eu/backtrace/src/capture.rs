use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Jabetzako eta berezko atzeko aztarnaren irudikapena.
///
/// Egitura hau programa bateko hainbat puntutan atzerako aztarna bat atzemateko erabil daiteke eta gero garai hartako atzerako azala zer zen ikuskatzeko erabil daiteke.
///
///
/// `Backtrace` atzeko aztarnak nahiko inprimatzea onartzen du `Debug` inplementazioaren bidez.
///
/// # Beharrezko ezaugarriak
///
/// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Hemen dauden markoak pilaren goitik behera zerrendatuta daude
    frames: Vec<BacktraceFrame>,
    // Gure ustez aurkibidea atzealdearen benetako hasiera da, `Backtrace::new` eta `backtrace::trace` bezalako fotogramak alde batera utzita.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Atzeko aztarnako marko baten bertsioa.
///
/// Mota hau `Backtrace::frames`-ren zerrenda gisa itzultzen da eta harrapatutako atzerako arrasto batean pila marko bat adierazten du.
///
/// # Beharrezko ezaugarriak
///
/// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Atzeko arrastoko sinboloaren bertsio harrapatua.
///
/// Mota hau `BacktraceFrame::symbols`-ren zerrenda gisa itzultzen da eta atzeko aztarnako ikur baten metadatuak adierazten ditu.
///
/// # Beharrezko ezaugarriak
///
/// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Funtzio honen deiaren atzealdeko aztarna atzematen du, jabetzako ordezkaritza itzuliz.
    ///
    /// Funtzio hau erabilgarria da atzeko aztarna objektu gisa Rust-n irudikatzeko.Itzulitako balio hau harietatik bidali eta inprimatu daiteke beste nonbait, eta balio honen xedea guztiz bere burua izatea da.
    ///
    /// Kontuan izan zenbait plataformatan atzerako traza osoa eskuratzea eta konpontzea oso garestia izan daitekeela.
    /// Zure aplikazioarentzako kostua gehiegi bada, `Backtrace::new_unresolved()` erabiltzea gomendatzen da, horrek sinboloaren bereizmen urratsa saihesten du (normalean luzeena izaten da) eta hori geroago atzeratzea ahalbidetzen du.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Beharrezko ezaugarriak
    ///
    /// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // Hemen kendu beharreko markoa dagoela ziurtatu nahi duzu
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// `new`-ren antzekoa da, baina horrek ez du inolako ikurrik konpontzen, honek atzeko aztarna helbide zerrenda gisa harrapatzen du.
    ///
    /// Geroxeago `resolve` funtzioa deitu daiteke atzerako trazatuaren sinboloak izen irakurgarrietan ebazteko.
    /// Funtzio hau badago, bereizmen prozesuak zenbaitetan denbora asko har dezakeelako, atzeko aztarna bakarra oso gutxitan inprimatu daitekeelako.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // ikur izenik ez
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // gaur egun dauden sinbolo izenak
    /// ```
    ///
    /// # Beharrezko ezaugarriak
    ///
    /// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
    ///
    ///
    ///
    #[inline(never)] // Hemen kendu beharreko markoa dagoela ziurtatu nahi duzu
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Atzera arrasto hau harrapatu zeneko fotogramak itzultzen ditu.
    ///
    /// Xerra honen lehen sarrera Litekeena `Backtrace::new` funtzioa da, eta azken markoa litekeena da hari hau edo funtzio nagusia nola hasi zen jakitea.
    ///
    ///
    /// # Beharrezko ezaugarriak
    ///
    /// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Atzeko aztarna hau `new_unresolved`-etik sortu bada, funtzio honek atzera-aztarnategiko izen sinbolikoen helbide guztiak ebatziko ditu.
    ///
    ///
    /// Atzeko aztarna hau aurretik konpondu bada edo `new` bidez sortu bada, funtzio honek ez du ezer egiten.
    ///
    /// # Beharrezko ezaugarriak
    ///
    /// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// `Frame::ip` bezalakoa
    ///
    /// # Beharrezko ezaugarriak
    ///
    /// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// `Frame::symbol_address` bezalakoa
    ///
    /// # Beharrezko ezaugarriak
    ///
    /// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// `Frame::module_base_address` bezalakoa
    ///
    /// # Beharrezko ezaugarriak
    ///
    /// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Marko horri dagozkion ikurren zerrenda itzultzen du.
    ///
    /// Normalean sinbolo bakarra dago fotograma bakoitzeko, baina batzuetan funtzio batzuk fotograma batean txertatuta badaude, sinbolo ugari itzuliko dira.
    /// Zerrendako lehen sinboloa "innermost function" da, azken ikurra kanpokoena (azken deitzailea).
    ///
    /// Kontuan izan marko hau konpondu gabeko atzerako aztarna batetik etorri bada, horrek zerrenda huts bat itzuliko duela.
    ///
    /// # Beharrezko ezaugarriak
    ///
    /// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// `Symbol::name` bezalakoa
    ///
    /// # Beharrezko ezaugarriak
    ///
    /// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// `Symbol::addr` bezalakoa
    ///
    /// # Beharrezko ezaugarriak
    ///
    /// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// `Symbol::filename` bezalakoa
    ///
    /// # Beharrezko ezaugarriak
    ///
    /// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// `Symbol::lineno` bezalakoa
    ///
    /// # Beharrezko ezaugarriak
    ///
    /// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// `Symbol::colno` bezalakoa
    ///
    /// # Beharrezko ezaugarriak
    ///
    /// Funtzio honek `backtrace` crate-ren `std` funtzioa gaituta egotea eskatzen du eta lehenespenez `std` funtzioa gaituta dago.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Bideak inprimatzerakoan cwd biluzten saiatzen gara existitzen bada, bestela bidea dagoen bezala inprimatzen dugu.
        // Kontuan izan hau ere formatu laburrean bakarrik egiten dugula, beteta badago, ustez, dena inprimatu nahi dugulako.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}