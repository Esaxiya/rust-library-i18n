//! *Emscripten* helbururako desegiten.
//!
//! Rust-k Unix plataformetarako ohiko desblokeatze inplementazioak libunwind APIetara zuzenean deitzen duen bitartean, Emscripten-en C++ API desblokeatzaileetara deitzen dugu.
//! Hau komenigarria da, izan ere, Emscripten-en exekuzioak beti API horiek inplementatzen ditu eta ez du libunwind inplementatzen.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Hau C00-en std::type_info-ren diseinuarekin bat dator
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // Hemen dagoen `\x01` byte nagusia benetan seinale magikoa da LLVM-ri `_` karaktere batekin aurrizkia bezalako beste manglarik ez aplikatzeko.
    //
    //
    // Sinbolo hau C++ -en `std::type_info`-k erabiltzen duen vtable da.
    // `std::type_info` motako objektuek, mota deskribatzaileek, erakusle bat dute taula honetara.
    // Mota deskribatzaileek goian definitu eta jarraian eraikitzen ditugun C++ EH egituren erreferentzia egiten dute.
    //
    // Kontuan izan tamaina erreala 3 erabilera baino handiagoa dela, baina gure vtable-a soilik behar dugu hirugarren elementua seinalatzeko.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info herdoila_paniko klaserako
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Normalean .as_ptr().add(2) erabiliko genuke baina honek ez du funtzionatzen testuinguru konstantean.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Honek nahita ez du izen arrunten eskema erabiltzen, ez dugulako nahi C++ -ek Rust panics ekoizteko edo harrapatzeko gai izatea.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Hau beharrezkoa da, C++ kodeak gure exekuzioa har dezakeelako std::exception_ptr-rekin eta hainbat aldiz atzera bota dezake, agian beste hari batean ere bai.
    //
    //
    caught: AtomicBool,

    // Aukera bat izan behar du objektuaren bizitzak C++ semantika jarraitzen duelako: catch_unwind Box salbuespenetik ateratzen duenean salbuespeneko objektua baliozko egoeran utzi behar du, bere suntsitzailea oraindik __cxa_end_catch-ek deituko duelako.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try egitura horri erakuslea ematen digu.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // cleanup() panic baimentzen ez denez, bertan behera uzten dugu.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}