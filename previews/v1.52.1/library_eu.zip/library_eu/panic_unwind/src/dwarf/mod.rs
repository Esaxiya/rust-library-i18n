//! DWARF kodetutako datu korronteak analizatzeko utilitateak.
//! Ikus <http://www.dwarfstd.org>, DWARF-4 estandarra, 7. atala, "Data Representation"
//!

// Modulu hau x86_64-pc-windows-gnu-k soilik erabiltzen du oraingoz, baina leku guztietan ari gara biltzen atzerakadak ekiditeko.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF korronteak paketatuta daude, beraz, adibidez, u32 bat ez litzateke zertan lerrokatuta egongo 4 byteko mugan.
    // Horrek arazoak sor ditzake lerrokatze-eskakizun zorrotzak dituzten plataformetan.
    // Datuak "packed" egitura batean bilduta, motorrari "misalignment-safe" kodea sortzeko esaten diogu.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 eta SLEB128 kodeketak 7.6, "Variable Length Data" atalean definitzen dira.
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}