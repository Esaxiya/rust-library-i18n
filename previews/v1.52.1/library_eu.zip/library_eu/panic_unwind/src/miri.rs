//! Mirirentzako panics desblokeatzea.
use alloc::boxed::Box;
use core::any::Any;

// Miri motorrak guretzako desblokeatzearen bidez hedatzen duen karga mota.
// Erakuslearen tamaina izan behar du.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Mirik emandako kanpoko funtzioa desegiten hasteko.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // `miri_start_panic`-era pasatzen dugun karga zehazki `cleanup`-en lortzen dugun argumentua izango da.
    // Beraz, behin kutxatu besterik ez dugu egiten, erakuslearen tamaina lortzeko.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Berreskuratu azpiko `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}