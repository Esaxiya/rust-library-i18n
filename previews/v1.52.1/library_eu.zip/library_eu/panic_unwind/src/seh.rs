//! Windows SEH
//!
//! Windows-n (oraingoz MSVC-n soilik), salbuespenak kudeatzeko mekanismo lehenetsia Structured Exception Handling (SEH) da.
//! Ipotxetan oinarritutako salbuespenen tratamendua baino oso desberdina da (adibidez, beste unix plataformek erabiltzen dutena) konpiladorearen barnealdeei dagokienez, beraz, LLVM-k SEHrako laguntza gehigarria izan behar du.
//!
//! Laburbilduz, hemen gertatzen dena da:
//!
//! 1. `panic` funtzioak Windows funtzio estandarrari `_CxxThrowException` deitzen dio C++ bezalako salbuespena botatzeko, desegiteko prozesua abiaraziz.
//! 2.
//! Konpiladoreak sortutako lurreratze-orri guztiek `__CxxFrameHandler3` nortasun funtzioa erabiltzen dute, CRT funtzioa, eta Windows-ko desblokeatze kodeak nortasun funtzio hau erabiliko dute pilako garbiketa kode guztiak exekutatzeko.
//!
//! 3. Konpiladoreak sortutako `invoke`-era egindako deialdi guztiek `cleanuppad` LLVM instrukzio gisa ezarri dute, garbiketa errutinaren hasiera adierazten duena.
//! Nortasuna (2. urratsean, CRT-n definitua) arduratzen da garbiketa errutinak exekutatzeaz.
//! 4. Azkenean `try` berezko "catch" kodea (konpiladoreak sortua) exekutatzen da eta kontrolak Rust-ra itzuli behar duela adierazten du.
//! Hau `catchswitch` gehi `catchpad` instrukzio baten bidez egiten da LLVM IR terminoetan, azkenean `catchret` instrukzioarekin kontrol normala itzuliz programari.
//!
//! gcc oinarritutako salbuespenen tratamenduarekiko desberdintasun zehatz batzuk hauek dira:
//!
//! * Rust-k ez du pertsonalitate funtzio pertsonalizaturik,*beti*`__CxxFrameHandler3` da.Gainera, ez da aparteko iragazkirik egiten, beraz, botatzen ari garenaren itxura duten C++ salbuespenak harrapatzen ditugu.
//! Kontuan izan salbuespena Rust ra botatzea zehaztu gabeko portaera dela, hala ere, ondo egon beharko litzateke.
//! * Desblokeatzeko mugan zehar transmititzeko zenbait datu ditugu, zehazki `Box<dyn Any + Send>` bat.Ipotx salbuespenekin gertatzen den moduan, bi erakusle hauek karga gisa gordetzen dira salbuespenean bertan.
//! MSVC-n, ordea, ez da aparteko muntaketa beharrik, dei pilak gordetzen baitira iragazki funtzioak exekutatzen diren bitartean.
//! Horrek esan nahi du erakusleak zuzenean `_CxxThrowException`-era pasatzen direla eta gero `try` berezko pila markoan idatzi beharreko iragazki funtzioan berreskuratzen direla.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Aukera bat izan behar da, salbuespena erreferentzia bidez harrapatzen baitugu eta bere suntsitzailea C++ exekuzio denboran exekutatzen delako.
    // Kaxa salbuespenetik ateratzen dugunean, salbuespena baliozko egoeran utzi behar dugu bere suntsitzailea Kaxa bikoitza bota gabe exekutatzeko.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Lehenik eta behin, motako definizio mordoa.Plataformen espezifiko bitxikeria batzuk daude hemen, eta LLVM-tik kopiatutako kopia asko daude.Honen guztiaren helburua beheko `panic` funtzioa `_CxxThrowException`-era deituz ezartzea da.
//
// Funtzio honek bi argudio hartzen ditu.Lehenengoa pasatzen ari garen datuen erakuslea da, kasu honetan gure trait objektua baita.Aurkitzeko nahiko erraza!Hurrengoa, ordea, zailagoa da.
// Hau `_ThrowInfo` egituraren erakuslea da eta, orokorrean, botatzen ari den salbuespena deskribatzeko besterik ez dago.
//
// Gaur egun [1] mota honen definizioa iletsu samarra da, eta bitxikeria nagusia (eta lineako artikuluarekiko desberdintasuna) da 32 biteko erakusleak erakusleak direla, baina 64 biteko erakusleak 32 biteko konpentsazio gisa adierazten dira `__ImageBase` ikurra.
//
// Hori adierazteko beheko moduluen `ptr_t` eta `ptr!` makroak erabiltzen dira.
//
// Mota definizioen labirintoak LLVM-k eragiketa honetarako igortzen duena gertutik jarraitzen du.Adibidez, C++ kode hau MSVCn konpilatzen baduzu eta LLVM IR igortzen baduzu:
//
//      #include <stdint.h>
//
//      egitura rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      hutsunea foo() { rust_panic a = {0, 1};
//          bota bat;}
//
// Hori da funtsean imitatzen saiatzen ari garena.Beheko balio konstante gehienak LLVM-tik kopiatu berri dira,
//
// Nolanahi ere, egitura horiek antzera eraikitzen dira, eta guretzat zorrotz samarra da.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Kontuan izan hemen nahita ez dugula jaramonik egiten izen izenen arauekin: ez dugu nahi C++ -ek Rust panics harrapatzeko gai izatea `struct rust_panic` bat soilik deklaratuta.
//
//
// Aldatzerakoan, ziurtatu izenaren katea `compiler/rustc_codegen_llvm/src/intrinsic.rs`-n erabilitakoarekin bat datorrela.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Hemen dagoen `\x01` byte nagusia benetan seinale magikoa da LLVM-ri `_` karaktere batekin aurrizkia bezalako beste manglarik ez aplikatzeko.
    //
    //
    // Sinbolo hau C++ -en `std::type_info`-k erabiltzen duen vtable da.
    // `std::type_info` motako objektuek, mota deskribatzaileek, erakusle bat dute taula honetara.
    // Mota deskribatzaileek goian definitu eta jarraian eraikitzen ditugun C++ EH egituren erreferentzia egiten dute.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Mota deskribatzaile hau salbuespen bat botatzean bakarrik erabiltzen da.
// Harrapaketa zatiak try intrinsic-ek kudeatzen du eta horrek bere TypeDescriptor propioa sortzen du.
//
// Ondo dago MSVC exekuzio-denborak kateen konparazioa erabiltzen baitu motaren izenean TypeDescriptors-ekin batzeko, erakuslearen berdintasuna baino.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Suntsitzailea erabiltzen da C++ kodeak salbuespena harrapatzea eta hedatu gabe uztea erabakitzen badu.
// Saiakuntzaren berezko zatiaren harrapaketak salbuespen objektuaren lehen hitza 0 gisa ezarriko du, suntsitzaileak saltatu dezan.
//
// Kontuan izan x86 Windows-k "thiscall" deitzeko konbentzioa erabiltzen duela C++ kide funtzioetarako "C" deitzeko konbentzio lehenetsiaren ordez.
//
// Salbuespen_kopia funtzioa berezia da hemen: MSVC exekuzioak deitzen du try/catch bloke baten azpian eta hemen sortzen dugun panic salbuespen kopiaren emaitza gisa erabiliko da.
//
// Hau C++ exekuzio-denborak std::exception_ptr-rekin salbuespenak harrapatzeko erabiltzen du, Box-ekin ezin baitugu onartu<dyn Any>ez da klonagarria.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException erabat exekutatzen da pila marko honetan, beraz, ez dago bestela `data` pilara transferitzeko beharrik.
    // Pila erakuslea pasatzen dugu funtzio honetara.
    //
    // ManuallyDrop beharrezkoa da hemen, desblokeatzerakoan salbuespena ez dadin nahi.
    // Horren ordez, C++ exekuzioak deitzen duen exception_cleanup-ek utziko du.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Honek ... harrigarria dirudi, eta arrazoiz.32 biteko MSVCn egitura horien arteko erakusleak besterik ez dira, erakusleak.
    // 64 biteko MSVC-n, ordea, egituren arteko erakusleak `__ImageBase`-ren 32 biteko konpentsazio gisa adierazten dira.
    //
    // Ondorioz, 32 biteko MSVC-n erakusle horiek guztiak goiko `estatikoan` deklaratu ditzakegu.
    // 64 biteko MSVC-n, estatikoetan erakusleen kenketa adierazi beharko genuke, gaur egun Rust-k onartzen ez duena, beraz ezin dugu hori egin.
    //
    // Hurrengo gauzarik onena egitura horiek exekuzioan betetzea da (izua "slow path" da dagoeneko).
    // Beraz, hemen erakuslearen eremu horiek guztiak 32 biteko zenbaki oso gisa berrinterpretatuko ditugu eta ondoren dagokion balioa gordeko dugu bertan (atomikoki, aldi berean panics gerta liteke).
    //
    // Teknikoki exekuzio-denborak eremu horien irakurketa ez anatomikoa egingo du ziurrenik, baina teorian ez dute inoiz *oker* balioa irakurtzen, beraz ez luke oso txarra izan behar ...
    //
    // Nolanahi ere, funtsean horrelako zerbait egin behar dugu estatistiketan eragiketa gehiago adierazi arte (eta agian ez dugu inoiz gai izango).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Hemen karga NULL batek __rust_try-ren (...) harrapaketatik iritsi garela esan nahi du.
    // Hau gertatzen da Rust ez den atzerriko salbuespen bat atzematen denean.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Konpiladoreak hori existitzeko eskatzen du (adibidez, lang elementua da), baina inoiz ez du konpiladoreak deitzen, __C_specific_handler edo_except_handler3 delako beti erabiltzen den nortasun funtzioa delako.
//
// Horregatik, abortu bat moztea besterik ez da.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}