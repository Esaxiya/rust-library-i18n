//! panics ezartzea pila deskonektatzearen bidez
//!
//! crate hau panics-ren inplementazioa da Rust-n "most native" pila hau biltzeko ari den plataformaren mekanismo desblokeatzailea erabiliz.
//! Hau, funtsean, hiru ontzitan sailkatzen da:
//!
//! 1. MSVC helburuek SEH erabiltzen dute `seh.rs` fitxategian.
//! 2. Emscripten-ek C++ salbuespenak erabiltzen ditu `emcc.rs` fitxategian.
//! 3. Beste helburu guztiek libunwind/libgcc erabiltzen dute `gcc.rs` fitxategian.
//!
//! Ezarpen bakoitzari buruzko dokumentazio gehiago dagokion moduluan aurki daiteke.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` Miri-rekin erabiltzen ez denez, isiltasun oharrak.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust exekuzio-denboraren hasierako objektuak sinbolo horien mende daude, beraz egin itzazu publiko.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Desblokeatzea onartzen ez duten helburuak.
        // - arch=wasm32
        // - os=none ("bare metal" helburuak)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Erabili Miri exekuzio-denbora.
        // Oraindik ere exekuzio normala gainetik kargatu behar dugu, rustc-k handik zenbait hizkuntza elementu definitzea espero baitu.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Erabili benetako exekuzioa.
        use real_imp as imp;
    }
}

extern "C" {
    /// Libstd-eko kudeatzaileari deitzen zaio panic objektu bat `catch_unwind` kanpo uzten denean.
    ///
    fn __rust_drop_panic() -> !;

    /// Libstd-eko kudeatzailea atzerriko salbuespen bat atzematen denean deitzen da.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Salbuespen bat sortzeko sarrera puntua, plataforma berariazko inplementaziora delegatu besterik ez da egin behar.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}