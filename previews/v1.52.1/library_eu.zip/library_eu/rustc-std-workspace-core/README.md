# `rustc-std-workspace-core` crate

crate hau crate txikia eta hutsa da, `libcore`-ren mende dagoena eta bere eduki guztia berriro esportatzen duena.
crate liburutegi estandarra crates.io-tik crates-ren mende egoteko gaitasuna da.

Liburutegi estandarraren araberako crates.io Crates-k crates.io-ren `rustc-std-workspace-core` crate-ren araberakoa izan behar du, hutsik dagoelarik.

`[patch]` erabiltzen dugu biltegi honetako crate honetarako gainidazteko.
Ondorioz, crates.io-en crates-k edge-ren mendekotasuna marraztuko du `libcore`-ra, biltegi honetan definitutako bertsioa.
Horrek mendekotasun ertz guztiak marraztu beharko lituzke Cargo-k crates ongi eraikitzen duela ziurtatzeko!

Kontuan izan crates.io-eko crates-k `core` izenarekin crate honen mende egon behar duela, dena ondo funtziona dezan.Horretarako erabil ditzakete:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

`package` teklaren erabileraren bidez, crate `core` izena aldatzen da, itxura izango du

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

Cargo konpilatzailea deitzen duenean, konpiladoreak injektatutako `extern crate core` zuzentarau inplizitua betetzen du.




