//! Rust panics ezartzea prozesuaren abortuen bidez
//!
//! Desblokeatze bidezko inplementazioarekin alderatuta, crate hau askoz ere sinpleagoa da!Hori esanda, ez da hain polifazetikoa, baina hemen doa!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" dagokion plataformako dagokion abortuaren karga eta karga.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // deitu std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Windows-n, erabili prozesadorearen berariazko __fastfail mekanismoa.Windows 8 eta berriagoetan, prozesua berehala amaituko da prozesuko salbuespen-kudeatzailerik exekutatu gabe.
            // Windows-ren aurreko bertsioetan, argibide sekuentzia hau sarbide urratze gisa tratatuko da, prozesua amaitutzat emanez baina salbuespeneko kudeatzaile guztiak nahitaez saihestu gabe.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: hau libstd-ren `abort_internal`-ren inplementazio bera da
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Hau ... bitxikeria da.Tl; dr;hau behar bezala lotzeko beharrezkoa da, azalpen luzeagoa behean dago.
//
// Oraintxe bertan bidaltzen ditugun libcore/libstd bitarrak `-C panic=unwind`-rekin konpilatuta daude.Hori egiten da binarioak ahalik eta egoera gehienekin bateragarriak izan daitezen.
// Konpiladoreak, ordea, "personality function" bat behar du `-C panic=unwind`-rekin konpilatutako funtzio guztietarako.Nortasun funtzio hau `rust_eh_personality` ikurrarekin gogor kodifikatuta dago eta `eh_personality` lang elementuak definitzen du.
//
// So...
// zergatik ez definitu hemen lang elementu hori?Galdera ona!panic exekuzio denborak estekatzeko modua apur bat sotila da, "sort of" konpilatzailearen crate dendan daudelako, baina benetan lotuta dago beste bat benetan lotuta ez badago.
//
// Horrek crate hau eta panic_unwind crate konpiladorearen crate biltegian ager daitezkeela esan nahi du, eta biek `eh_personality` lang elementua definitzen badute, horrek akats bat izango du.
//
// Hori kudeatzeko konpiladoreak `eh_personality` bakarrik behar du zehazten bada lotuta dagoen panic exekuzio-denbora desblokeatzeko exekuzio-denbora bada, eta, bestela, ez da definitu behar (behar bezala).
// Kasu honetan, ordea, liburutegi honek sinbolo hau besterik ez du definitzen, beraz, gutxienez nortasun bat dago nonbait.
//
// Funtsean, sinbolo hau libcore/libstd bitarra kableatzeko definitzen da, baina ez da inoiz deitu behar, ez baitugu batere lotzen exekuzio garaian lotzen.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // X86_64-pc-windows-gnu-n `ExceptionContinueSearch` itzuli behar duen nortasun funtzioa erabiltzen dugu gure fotograma guztiak pasatzen ari garenean.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Aurrekoaren antzera, hau gaur egun Emscripten-en soilik erabiltzen den `eh_catch_typeinfo` lang itemari dagokio.
    //
    // panics-k salbuespenak sortzen ez dituenez eta atzerriko salbuespenak U00 direnez, -C-rekin panic=abortatu daiteke (nahiz eta aldaketak izan ditzakeen), catch_unwind deiek ez dute sekula informazio mota hori erabiliko.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Bi horiei i686-pc-windows-gnu izeneko startup objektuek deitzen diete, baina ez dute ezer egin beharrik, beraz, gorputzak nops dira.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}