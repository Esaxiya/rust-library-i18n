use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Hau ez da azalera egonkorra, baina `?` bien artean merkea izaten laguntzen du, LLVM-k oraintxe beti aprobetxatu ezin badu ere.
    //
    // (Zoritxarrez Emaitza eta Aukera ez datoz bat, beraz ControlFlow ezin da biekin bat etorri.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}