use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri geldoegia da
fn exact_sanity_test() {
    // Proba honek amaitzen du `exp2` liburutegiaren funtzioaren izkinako kasua dela suposatzen dudana, erabiltzen ari garen edozein C exekuzioan definitua.
    // 2013ko VS-n funtzio honek akats bat izan zuen itxuraz proba honek huts egitean lotzen denean, baina 2015eko VS-rekin akatsa konponduta agertzen da, testak ondo funtzionatzen baitu.
    //
    // Badirudi akatsa `exp2(-1057)`-ren itzulketaren balioan dagoela, non VS 2013an bikoitza ematen duen 0x2 bit ereduarekin eta VS 2015-en 0x20000 itzultzen duen.
    //
    //
    // Oraingoz, ez ikusi MSVC-n proba hau, beste nonbait probatzen baita eta ez zaigu interesatzen plataforma bakoitzaren exp2 inplementazioa probatzea.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}