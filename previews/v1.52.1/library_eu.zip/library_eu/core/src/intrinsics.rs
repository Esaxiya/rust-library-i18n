//! Konpilatzailearen berezko ezaugarriak.
//!
//! Dagozkien definizioak `compiler/rustc_codegen_llvm/src/intrinsic.rs`-n daude.
//! Dagozkion konst inplementazioak `compiler/rustc_mir/src/interpret/intrinsics.rs`-n daude
//!
//! # Const berezkoak
//!
//! Note: intrintsekoen konstantitatearen aldaketak hizkuntza taldearekin eztabaidatu beharko lirateke.
//! Horrek konstantearen egonkortasunaren aldaketak barne hartzen ditu.
//!
//! Konpilazio garaian berezko ezaugarri bat erabilgarri izan dadin, inplementazioa <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs>-tik `compiler/rustc_mir/src/interpret/intrinsics.rs`-ra kopiatu eta `#[rustc_const_unstable(feature = "foo", issue = "01234")]` bat gehitu behar zaio berezkoari.
//!
//!
//! Berezko bat `rustc_const_stable` atributua duen `const fn` batetik erabiltzen dela suposatzen bada, berezkoaren atributuak `rustc_const_stable` ere izan behar du.
//! Aldaketa hori ez da T-lang kontsultarik egin behar, konpiladorearen euskarririk gabe erabiltzaile kodean errepika ezin daitekeen hizkuntzan ezaugarri bat hornitzen baitu.
//!
//! # Volatiles
//!
//! Intrintseko lurrunkorrek I/O memorian jarduteko eragiketak eskaintzen dituzte. Konpiladoreak beste intrintseko lurrunkor batzuen artean berriro antolatuko ez dituela ziurtatzen dute.Ikusi LLVM dokumentazioa [[volatile]]-n.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Intrintseko atomikoek eragiketa atomiko arruntak ematen dituzte hitz makinetan, memoria ordenazio posible anitzekin.C ++ 11ren semantika bera betetzen dute.Ikusi LLVM dokumentazioa [[atomics]]-n.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Memoria ordenatzeko eguneratze azkarra:
//!
//! * Eskuratu, sarraila eskuratzeko hesia.Ondorengo irakurketa eta idazketak langaren ondoren gertatzen dira.
//! * Askatu, sarraila askatzeko hesia.Irakurketa eta idazketa aurrekoak hesiaren aurretik egiten dira.
//! * Sekuentzialki koherenteak, sekuentzialki koherenteak diren eragiketak ordenan gertatzen direla bermatzen da.Mota atomikoekin lan egiteko modu estandarra da eta Java-ren `volatile`-ren baliokidea da.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Inportazio hauek doc barruko estekak sinplifikatzeko erabiltzen dira
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SEGURTASUNA: ikusi `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // Oharra, berezko hauek erakusle gordinak hartzen dituzte, memoria aliatua aldatzen dutelako, eta hori ez da baliozkoa `&` edo `&mut`.
    //

    /// Balio bat gordetzen du uneko balioa `old` balioaren berdina bada.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `compare_exchange` metodoaren bidez [`Ordering::SeqCst`] pasatuz `success` eta `failure` parametro gisa.
    ///
    /// Adibidez, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Balio bat gordetzen du uneko balioa `old` balioaren berdina bada.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `compare_exchange` metodoaren bidez [`Ordering::Acquire`] pasatuz `success` eta `failure` parametro gisa.
    ///
    /// Adibidez, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Balio bat gordetzen du uneko balioa `old` balioaren berdina bada.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan `compare_exchange` metodoaren bidez eskuragarri dago [`Ordering::Release`] `success` gisa eta [`Ordering::Relaxed`] `failure` parametro gisa pasatuz.
    /// Adibidez, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Balio bat gordetzen du uneko balioa `old` balioaren berdina bada.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan `compare_exchange` metodoaren bidez eskuragarri dago [`Ordering::AcqRel`] `success` gisa eta [`Ordering::Acquire`] `failure` parametro gisa pasatuz.
    /// Adibidez, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Balio bat gordetzen du uneko balioa `old` balioaren berdina bada.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `compare_exchange` metodoaren bidez [`Ordering::Relaxed`] pasatuz `success` eta `failure` parametro gisa.
    ///
    /// Adibidez, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Balio bat gordetzen du uneko balioa `old` balioaren berdina bada.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan `compare_exchange` metodoaren bidez eskuragarri dago [`Ordering::SeqCst`] `success` gisa eta [`Ordering::Relaxed`] `failure` parametro gisa pasatuz.
    /// Adibidez, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Balio bat gordetzen du uneko balioa `old` balioaren berdina bada.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan `compare_exchange` metodoaren bidez eskuragarri dago [`Ordering::SeqCst`] `success` gisa eta [`Ordering::Acquire`] `failure` parametro gisa pasatuz.
    /// Adibidez, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Balio bat gordetzen du uneko balioa `old` balioaren berdina bada.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan `compare_exchange` metodoaren bidez eskuragarri dago [`Ordering::Acquire`] `success` gisa eta [`Ordering::Relaxed`] `failure` parametro gisa pasatuz.
    /// Adibidez, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Balio bat gordetzen du uneko balioa `old` balioaren berdina bada.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan `compare_exchange` metodoaren bidez eskuragarri dago [`Ordering::AcqRel`] `success` gisa eta [`Ordering::Relaxed`] `failure` parametro gisa pasatuz.
    /// Adibidez, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Balio bat gordetzen du uneko balioa `old` balioaren berdina bada.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `compare_exchange_weak` metodoaren bidez [`Ordering::SeqCst`] pasatuz `success` eta `failure` parametro gisa.
    ///
    /// Adibidez, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Balio bat gordetzen du uneko balioa `old` balioaren berdina bada.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `compare_exchange_weak` metodoaren bidez [`Ordering::Acquire`] pasatuz `success` eta `failure` parametro gisa.
    ///
    /// Adibidez, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Balio bat gordetzen du uneko balioa `old` balioaren berdina bada.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan `compare_exchange_weak` metodoaren bidez eskuragarri dago [`Ordering::Release`] `success` gisa eta [`Ordering::Relaxed`] `failure` parametro gisa pasatuz.
    /// Adibidez, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Balio bat gordetzen du uneko balioa `old` balioaren berdina bada.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan `compare_exchange_weak` metodoaren bidez eskuragarri dago [`Ordering::AcqRel`] `success` gisa eta [`Ordering::Acquire`] `failure` parametro gisa pasatuz.
    /// Adibidez, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Balio bat gordetzen du uneko balioa `old` balioaren berdina bada.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `compare_exchange_weak` metodoaren bidez [`Ordering::Relaxed`] pasatuz `success` eta `failure` parametro gisa.
    ///
    /// Adibidez, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Balio bat gordetzen du uneko balioa `old` balioaren berdina bada.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan `compare_exchange_weak` metodoaren bidez eskuragarri dago [`Ordering::SeqCst`] `success` gisa eta [`Ordering::Relaxed`] `failure` parametro gisa pasatuz.
    /// Adibidez, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Balio bat gordetzen du uneko balioa `old` balioaren berdina bada.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan `compare_exchange_weak` metodoaren bidez eskuragarri dago [`Ordering::SeqCst`] `success` gisa eta [`Ordering::Acquire`] `failure` parametro gisa pasatuz.
    /// Adibidez, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Balio bat gordetzen du uneko balioa `old` balioaren berdina bada.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan `compare_exchange_weak` metodoaren bidez eskuragarri dago [`Ordering::Acquire`] `success` gisa eta [`Ordering::Relaxed`] `failure` parametro gisa pasatuz.
    /// Adibidez, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Balio bat gordetzen du uneko balioa `old` balioaren berdina bada.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan `compare_exchange_weak` metodoaren bidez eskuragarri dago [`Ordering::AcqRel`] `success` gisa eta [`Ordering::Relaxed`] `failure` parametro gisa pasatuz.
    /// Adibidez, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Erakuslearen uneko balioa kargatzen du.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `load` metodoaren bidez [`Ordering::SeqCst`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Erakuslearen uneko balioa kargatzen du.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `load` metodoaren bidez [`Ordering::Acquire`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Erakuslearen uneko balioa kargatzen du.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `load` metodoaren bidez [`Ordering::Relaxed`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Balioa zehaztutako memoriaren kokapenean gordetzen du.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `store` metodoaren bidez [`Ordering::SeqCst`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Balioa zehaztutako memoriaren kokapenean gordetzen du.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `store` metodoaren bidez [`Ordering::Release`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Balioa zehaztutako memoriaren kokapenean gordetzen du.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `store` metodoaren bidez [`Ordering::Relaxed`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Balioa zehaztutako memoriaren kokapenean gordetzen du, balio zaharra itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `swap` metodoaren bidez [`Ordering::SeqCst`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Balioa zehaztutako memoriaren kokapenean gordetzen du, balio zaharra itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `swap` metodoaren bidez [`Ordering::Acquire`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Balioa zehaztutako memoriaren kokapenean gordetzen du, balio zaharra itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `swap` metodoaren bidez [`Ordering::Release`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Balioa zehaztutako memoriaren kokapenean gordetzen du, balio zaharra itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `swap` metodoaren bidez [`Ordering::AcqRel`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Balioa zehaztutako memoriaren kokapenean gordetzen du, balio zaharra itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `swap` metodoaren bidez [`Ordering::Relaxed`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Uneko balioa gehitzen du, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_add` metodoaren bidez [`Ordering::SeqCst`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uneko balioa gehitzen du, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_add` metodoaren bidez [`Ordering::Acquire`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uneko balioa gehitzen du, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_add` metodoaren bidez [`Ordering::Release`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uneko balioa gehitzen du, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_add` metodoaren bidez [`Ordering::AcqRel`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uneko balioa gehitzen du, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_add` metodoaren bidez [`Ordering::Relaxed`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kendu uneko balioa, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_sub` metodoaren bidez [`Ordering::SeqCst`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kendu uneko balioa, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_sub` metodoaren bidez [`Ordering::Acquire`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kendu uneko balioa, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_sub` metodoaren bidez [`Ordering::Release`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kendu uneko balioa, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_sub` metodoaren bidez [`Ordering::AcqRel`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kendu uneko balioa, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_sub` metodoaren bidez [`Ordering::Relaxed`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bit aldetik eta uneko balioarekin, aurreko balioa itzultzen du.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_and` metodoaren bidez [`Ordering::SeqCst`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit aldetik eta uneko balioarekin, aurreko balioa itzultzen du.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_and` metodoaren bidez [`Ordering::Acquire`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit aldetik eta uneko balioarekin, aurreko balioa itzultzen du.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_and` metodoaren bidez [`Ordering::Release`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit aldetik eta uneko balioarekin, aurreko balioa itzultzen du.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_and` metodoaren bidez [`Ordering::AcqRel`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit aldetik eta uneko balioarekin, aurreko balioa itzultzen du.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_and` metodoaren bidez [`Ordering::Relaxed`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bit aldetik nand uneko balioarekin, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`AtomicBool`] motan eskuragarri dago `fetch_nand` metodoaren bidez [`Ordering::SeqCst`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit aldetik nand uneko balioarekin, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`AtomicBool`] motan eskuragarri dago `fetch_nand` metodoaren bidez [`Ordering::Acquire`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit aldetik nand uneko balioarekin, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`AtomicBool`] motan eskuragarri dago `fetch_nand` metodoaren bidez [`Ordering::Release`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit aldetik nand uneko balioarekin, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`AtomicBool`] motan eskuragarri dago `fetch_nand` metodoaren bidez [`Ordering::AcqRel`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit aldetik nand uneko balioarekin, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`AtomicBool`] motan eskuragarri dago `fetch_nand` metodoaren bidez [`Ordering::Relaxed`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bit aldetik edo uneko balioarekin, aurreko balioa itzultzen du.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_or` metodoaren bidez [`Ordering::SeqCst`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit aldetik edo uneko balioarekin, aurreko balioa itzultzen du.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_or` metodoaren bidez [`Ordering::Acquire`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit aldetik edo uneko balioarekin, aurreko balioa itzultzen du.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_or` metodoaren bidez [`Ordering::Release`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit aldetik edo uneko balioarekin, aurreko balioa itzultzen du.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_or` metodoaren bidez [`Ordering::AcqRel`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit aldetik edo uneko balioarekin, aurreko balioa itzultzen du.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_or` metodoaren bidez [`Ordering::Relaxed`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bit bit xor uneko balioarekin, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_xor` metodoaren bidez [`Ordering::SeqCst`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit bit xor uneko balioarekin, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_xor` metodoaren bidez [`Ordering::Acquire`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit bit xor uneko balioarekin, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_xor` metodoaren bidez [`Ordering::Release`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit bit xor uneko balioarekin, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_xor` metodoaren bidez [`Ordering::AcqRel`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit bit xor uneko balioarekin, aurreko balioa itzuliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] motetan eskuragarri dago `fetch_xor` metodoaren bidez [`Ordering::Relaxed`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Gehienekoa uneko balioarekin sinatutako konparazio bat erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatutako zenbaki oso motetan eskuragarri dago `fetch_max` metodoaren bidez [`Ordering::SeqCst`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gehienekoa uneko balioarekin sinatutako konparazio bat erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatutako zenbaki oso motetan eskuragarri dago `fetch_max` metodoaren bidez [`Ordering::Acquire`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gehienekoa uneko balioarekin sinatutako konparazio bat erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatutako zenbaki oso motetan eskuragarri dago `fetch_max` metodoaren bidez [`Ordering::Release`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gehienekoa uneko balioarekin sinatutako konparazio bat erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatutako zenbaki oso motetan eskuragarri dago `fetch_max` metodoaren bidez [`Ordering::AcqRel`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gehiena uneko balioarekin.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatutako zenbaki oso motetan eskuragarri dago `fetch_max` metodoaren bidez [`Ordering::Relaxed`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Gutxienekoa uneko balioarekin sinatutako alderaketa erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatutako zenbaki oso motetan eskuragarri dago `fetch_min` metodoaren bidez [`Ordering::SeqCst`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gutxienekoa uneko balioarekin sinatutako alderaketa erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatutako zenbaki oso motetan eskuragarri dago `fetch_min` metodoaren bidez [`Ordering::Acquire`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gutxienekoa uneko balioarekin sinatutako alderaketa erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatutako zenbaki oso motetan eskuragarri dago `fetch_min` metodoaren bidez [`Ordering::Release`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gutxienekoa uneko balioarekin sinatutako alderaketa erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatutako zenbaki oso motetan eskuragarri dago `fetch_min` metodoaren bidez [`Ordering::AcqRel`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gutxienekoa uneko balioarekin sinatutako alderaketa erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatutako zenbaki oso motetan eskuragarri dago `fetch_min` metodoaren bidez [`Ordering::Relaxed`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimo uneko balioarekin sinatu gabeko konparazio bat erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatu gabeko zenbaki oso motetan eskuragarri dago `fetch_min` metodoaren bidez [`Ordering::SeqCst`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimo uneko balioarekin sinatu gabeko konparazio bat erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatu gabeko zenbaki oso motetan eskuragarri dago `fetch_min` metodoaren bidez [`Ordering::Acquire`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimo uneko balioarekin sinatu gabeko konparazio bat erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatu gabeko zenbaki oso motetan eskuragarri dago `fetch_min` metodoaren bidez [`Ordering::Release`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimo uneko balioarekin sinatu gabeko konparazio bat erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatu gabeko zenbaki osoetan eskuragarri dago `fetch_min` metodoaren bidez [`Ordering::AcqRel`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimo uneko balioarekin sinatu gabeko konparazio bat erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatu gabeko zenbaki oso motetan eskuragarri dago `fetch_min` metodoaren bidez [`Ordering::Relaxed`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Gehienekoa uneko balioarekin sinatu gabeko konparazio bat erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatu gabeko zenbaki oso motetan eskuragarri dago `fetch_max` metodoaren bidez [`Ordering::SeqCst`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gehienekoa uneko balioarekin sinatu gabeko konparazio bat erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatu gabeko zenbaki oso motetan eskuragarri dago `fetch_max` metodoaren bidez [`Ordering::Acquire`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gehienekoa uneko balioarekin sinatu gabeko konparazio bat erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatu gabeko zenbaki oso motetan eskuragarri dago `fetch_max` metodoaren bidez [`Ordering::Release`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gehienekoa uneko balioarekin sinatu gabeko konparazio bat erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatu gabeko zenbaki oso motetan eskuragarri dago `fetch_max` metodoaren bidez [`Ordering::AcqRel`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gehienekoa uneko balioarekin sinatu gabeko konparazio bat erabiliz.
    ///
    /// Berezko bertsio egonkortua [`atomic`] sinatu gabeko zenbaki oso motetan eskuragarri dago `fetch_max` metodoaren bidez [`Ordering::Relaxed`] `order` gisa pasatuz.
    /// Adibidez, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` intrintsekoa kode sortzailearentzako aholku bat da aurrez eskuratutako instrukzioa txertatzeko onartzen bada;bestela, no-op da.
    /// Prefetchek ez dute inolako eraginik programaren portaeran, baina bere errendimendu ezaugarriak alda ditzakete.
    ///
    /// `locality` argumentuak zenbaki oso konstantea izan behar du eta (0)-tik, tokirik ez, (3)-ra arteko kokapen denborazko zehaztzailea da.
    ///
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` intrintsekoa kode sortzailearentzako aholku bat da aurrez eskuratutako instrukzioa txertatzeko onartzen bada;bestela, no-op da.
    /// Prefetchek ez dute inolako eraginik programaren portaeran, baina bere errendimendu ezaugarriak alda ditzakete.
    ///
    /// `locality` argumentuak zenbaki oso konstantea izan behar du eta (0)-tik, tokirik ez, (3)-ra arteko kokapen denborazko zehaztzailea da.
    ///
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` intrintsekoa kode sortzailearentzako aholku bat da aurrez eskuratutako instrukzioa txertatzeko onartzen bada;bestela, no-op da.
    /// Prefetchek ez dute inolako eraginik programaren portaeran, baina bere errendimendu ezaugarriak alda ditzakete.
    ///
    /// `locality` argumentuak zenbaki oso konstantea izan behar du eta (0)-tik, tokirik ez, (3)-ra arteko kokapen denborazko zehaztzailea da.
    ///
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` intrintsekoa kode sortzailearentzako aholku bat da aurrez eskuratutako instrukzioa txertatzeko onartzen bada;bestela, no-op da.
    /// Prefetchek ez dute inolako eraginik programaren portaeran, baina bere errendimendu ezaugarriak alda ditzakete.
    ///
    /// `locality` argumentuak zenbaki oso konstantea izan behar du eta (0)-tik, tokirik ez, (3)-ra arteko kokapen denborazko zehaztzailea da.
    ///
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Hesi atomikoa.
    ///
    /// Berezko bertsio egonkortua [`atomic::fence`]-n eskuragarri dago [`Ordering::SeqCst`] `order` gisa pasatuta.
    ///
    ///
    pub fn atomic_fence();
    /// Hesi atomikoa.
    ///
    /// Berezko bertsio egonkortua [`atomic::fence`]-n eskuragarri dago [`Ordering::Acquire`] `order` gisa pasatuta.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Hesi atomikoa.
    ///
    /// Berezko bertsio egonkortua [`atomic::fence`]-n eskuragarri dago [`Ordering::Release`] `order` gisa pasatuta.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Hesi atomikoa.
    ///
    /// Berezko bertsio egonkortua [`atomic::fence`]-n eskuragarri dago [`Ordering::AcqRel`] `order` gisa pasatuta.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Konpilatzailea soilik duen memoria-hesia.
    ///
    /// Memorako sarbideak ez ditu inoiz konpilatzaileak oztopo horretan berriro ordenatuko, baina ez da horretarako argibiderik igorriko.
    /// Hori egokia izan daiteke aurrez har daitezkeen hari beraren gaineko eragiketetarako, adibidez, seinaleen manipulatzaileekin elkarreraginean aritzeko.
    ///
    /// Berezko bertsio egonkortua [`atomic::compiler_fence`]-n eskuragarri dago [`Ordering::SeqCst`] `order` gisa pasatuta.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Konpilatzailea soilik duen memoria-hesia.
    ///
    /// Memorako sarbideak ez ditu inoiz konpilatzaileak oztopo horretan berriro ordenatuko, baina ez da horretarako argibiderik igorriko.
    /// Hori egokia izan daiteke aurrez har daitezkeen hari beraren gaineko eragiketetarako, adibidez, seinaleen manipulatzaileekin elkarreraginean aritzeko.
    ///
    /// Berezko bertsio egonkortua [`atomic::compiler_fence`]-n eskuragarri dago [`Ordering::Acquire`] `order` gisa pasatuta.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Konpilatzailea soilik duen memoria-hesia.
    ///
    /// Memorako sarbideak ez ditu inoiz konpilatzaileak oztopo horretan berriro ordenatuko, baina ez da horretarako argibiderik igorriko.
    /// Hori egokia izan daiteke aurrez har daitezkeen hari beraren gaineko eragiketetarako, adibidez, seinaleen manipulatzaileekin elkarreraginean aritzeko.
    ///
    /// Berezko bertsio egonkortua [`atomic::compiler_fence`]-n eskuragarri dago [`Ordering::Release`] `order` gisa pasatuta.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Konpilatzailea soilik duen memoria-hesia.
    ///
    /// Memorako sarbideak ez ditu inoiz konpilatzaileak oztopo horretan berriro ordenatuko, baina ez da horretarako argibiderik igorriko.
    /// Hori egokia izan daiteke aurrez har daitezkeen hari beraren gaineko eragiketetarako, adibidez, seinaleen manipulatzaileekin elkarreraginean aritzeko.
    ///
    /// Berezko bertsio egonkortua [`atomic::compiler_fence`]-n eskuragarri dago [`Ordering::AcqRel`] `order` gisa pasatuta.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Funtzioari lotutako atributuetatik bere esanahia eratortzen duen berezko magia.
    ///
    /// Adibidez, datu-fluxuak baieztapen estatikoak injektatzeko erabiltzen du, `rustc_peek(potentially_uninitialized)`-k egiaztapen bikoitza egin dezan datu-fluxuak kontrol-fluxuko puntu horretan hasierarik gabe dagoela kalkulatu duela.
    ///
    ///
    /// Berezko hau ez da konpilatzailetik kanpo erabili behar.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Prozesuaren exekuzioa bertan behera uzten du.
    ///
    /// Eragiketa honen bertsio erabilerrazagoa eta egonkorragoa [`std::process::abort`](../../std/process/fn.abort.html) da.
    ///
    pub fn abort() -> !;

    /// Optimizatzaileari jakinarazten dio kodeko puntu hau ezin dela iritsi, optimizazio gehiago ahalbidetuz.
    ///
    /// Oharra, hau `unreachable!()` makroaren oso desberdina da: panics exekutatzerakoan makroa ez bezala,*zehaztu gabeko portaera* da funtzio honekin markatutako kodea lortzea.
    ///
    ///
    /// Berezko bertsio egonkortua [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) da.
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Baldintza bat beti egia dela jakinarazten dio optimizatzaileari.
    /// Baldintza faltsua bada, portaera zehaztu gabe dago.
    ///
    /// Ez da kode berez sortzen horretarako, baina optimizatzailea saiatuko da pasatzen den bitartean (eta haren egoera) mantentzen, eta horrek inguruko kodea optimizatzea oztopatu eta errendimendua murriztu dezake.
    /// Ez da erabili behar aldaezina optimizatzaileak bere kabuz aurki dezakeenean edo optimizazio garrantzitsurik gaitzen ez badu.
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Konpilatzaileari aholkuak ematen dizkio branch baldintza egia dela.
    /// Pasatutako balioa itzultzen du.
    ///
    /// `if` adierazpenekin ez den beste edozein erabilerak ez du eraginik izango seguruenik.
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Konpilatzaileari aholkuak ematen dizkio branch baldintza faltsua dela.
    /// Pasatutako balioa itzultzen du.
    ///
    /// `if` adierazpenekin ez den beste edozein erabilerak ez du eraginik izango seguruenik.
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Atseden-puntu tranpa bat exekutatzen du, arazketa batek ikuskatzeko.
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    pub fn breakpoint();

    /// Mota baten tamaina byteetan.
    ///
    /// Zehazkiago esanda, mota bereko ondoz ondoko elementuen arteko byteen konpentsazioa da, lerrokatze betegarria barne.
    ///
    ///
    /// Berezko bertsio egonkortua [`core::mem::size_of`](crate::mem::size_of) da.
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Mota baten gutxieneko lerrokadura.
    ///
    /// Berezko bertsio egonkortua [`core::mem::align_of`](crate::mem::align_of) da.
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Mota baten lerrokatze hobetsia.
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Erreferentziatutako balioaren tamaina byteetan.
    ///
    /// Berezko bertsio egonkortua [`mem::size_of_val`] da.
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Erreferentziatutako balioaren beharrezko lerrokadura.
    ///
    /// Berezko bertsio egonkortua [`core::mem::align_of_val`](crate::mem::align_of_val) da.
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Mota baten izena duen kate estatiko xerra lortzen du.
    ///
    /// Berezko bertsio egonkortua [`core::any::type_name`](crate::any::type_name) da.
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Zehaztutako motarako orokorrean bakarra den identifikatzailea lortzen du.
    /// Funtzio honek balio bera itzuliko du mota baterako, edozein crate deitzen den kontuan hartu gabe.
    ///
    ///
    /// Berezko bertsio egonkortua [`core::any::TypeId::of`](crate::any::TypeId::of) da.
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// `T` biztanlerik ez badago inoiz exekutatu ezin diren funtzio seguruentzako babes bat:
    /// Honek estatikoki egingo du panic edo ez du ezer egingo.
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Inoiz exekutatu ezin diren funtzio seguruentzako babes bat, `T`-ek zero hasieratzea onartzen ez badu: Honek panic estatikoki egingo du edo ez du ezer egingo.
    ///
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    pub fn assert_zero_valid<T>();

    /// `T`-k bit eredu baliogabeak baldin baditu inoiz exekutatu ezin diren funtzio seguruentzako babes bat: honek panic estatikoki egingo du edo ez du ezer egingo.
    ///
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    pub fn assert_uninit_valid<T>();

    /// Non deitu zen adierazten duen `Location` estatiko baten erreferentzia lortzen du.
    ///
    /// Demagun [`core::panic::Location::caller`](crate::panic::Location::caller) erabiltzea horren ordez.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Balioa irismenetik kanpo mugitzen du kola erantsi gabe.
    ///
    /// Hau [`mem::forget_unsized`]-rako bakarrik dago;`forget` normalak `ManuallyDrop` erabiltzen du horren ordez.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Mota bateko balio baten bitak beste mota gisa berrinterpretatzen ditu.
    ///
    /// Bi motek tamaina bera izan behar dute.
    /// Ez jatorrizkoak ez emaitzak ezingo dute [invalid value](../../nomicon/what-unsafe-does.html) izan.
    ///
    /// `transmute` semantikoki mota bateko bit-mugimenduen beste baten baliokidea da.Iturriaren balioaren bitak helmugako balioan kopiatzen ditu eta, ondoren, jatorrizkoa ahazten du.
    /// C's `memcpy` kanpaiaren azpian baliokidea da, `transmute_copy` bezala.
    ///
    /// `transmute` balio osoko eragiketa denez,*transmititutako balioen* lerrokatzea ez da kezka.
    /// Beste edozein funtzioren moduan, konpiladoreak `T` eta `U` biak lerrokatuta daudela ziurtatzen du dagoeneko.
    /// Hala ere,*beste norabait* duten balioak transmutatzerakoan (hala nola, erakusleak, erreferentziak, laukiak ...), deitzaileak balio puntualen lerrokatze egokia ziurtatu behar du.
    ///
    /// `transmute` **izugarri** ez da segurua.Funtzio honekin [undefined behavior][ub] eragiteko modu ugari dago.`transmute` azken baliabide absolutua izan beharko litzateke.
    ///
    /// [nomicon](../../nomicon/transmutes.html)-k dokumentazio osagarria du.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// `transmute` oso erabilgarria den gauza batzuk daude.
    ///
    /// Erakuslea funtzio erakusle bihurtzea.Hau ez da * eramangarria funtzio erakusleek eta datu erakusleek tamaina desberdinak dituzten makinetarako.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Bizitza luzatzea edo bizitza aldaezina laburtzea.Hau aurreratua da, oso segurua Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Ez etsi: `transmute`-ren erabilera asko beste bide batzuen bidez lor daitezke.
    /// Jarraian `transmute`-ren aplikazio arruntak eraikuntza seguruagoekin ordezka daitezke.
    ///
    /// bytes(`&[u8]`) gordina `u32`, `f64` eta abar bihurtzea:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // erabili ordez `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // edo erabili `u32::from_le_bytes` edo `u32::from_be_bytes` amaierakoa zehazteko
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Erakuslea `usize` bihurtzea:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Erabili `as` cast bat
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T` `&mut T` bihurtzea:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Erabili berriro mailegua
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T` `&mut U` bihurtzea:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Orain, bildu `as` eta berriro konpondu, kontutan izan `as` `as` kateatzea ez dela iragankorra.
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str` `&[u8]` bihurtzea:
    ///
    /// ```
    /// // hau ez da hori egiteko modu ona.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // `str::as_bytes` erabil dezakezu
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Edo, besterik gabe, erabili byte katea, katea literalaren gaineko kontrola baduzu
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>` `Vec<Option<&T>>` bihurtzea.
    ///
    /// Edukiontzi bateko edukiaren barruko mota transmutatzeko, ziurtatu behar duzu edukiontziaren aldaera bat ere ez urratzen duela.
    /// `Vec` rentzat, horrek esan nahi du barruko moten tamaina *eta lerrokatzea* bat etorri behar direla.
    /// Beste edukiontzi batzuk motaren tamainan, lerrokaduran edo `TypeId` n oinarrituta egon daitezke; kasu horretan, transmutazioa ez litzateke batere posible edukiontzien aldaerak urratu gabe.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // klonatu vector geroago berrerabiliko ditugun moduan
    /// let v_clone = v_orig.clone();
    ///
    /// // Transmutazioa erabiltzea: zehaztu gabeko `Vec` datuen diseinuan oinarritzen da, ideia txarra da eta zehaztu gabeko portaera sor dezake.
    /////
    /// // Hala ere, kopiarik gabea da.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Hau da iradokitako modu segurua.
    /// // vector osoa kopiatzen du, ordea, array berri batean.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Hau da kopiatzerik gabeko eta "transmuting" eta `Vec` modu seguruan, datuen diseinuan oinarritu gabe.
    /// // Literalki `transmute` deitu beharrean, erakusle cast bat egiten dugu, baina jatorrizko barne mota (`&i32`) (`Option<&i32>`) berrira bihurtzeari dagokionez, oharpen guztiak ditu.
    /////
    /// // Goian emandako informazioaz gain, kontsultatu [`from_raw_parts`] dokumentazioa ere.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Eguneratu hau vec_into_raw_parts egonkortzen denean.
    ///     // Ziurtatu jatorrizko vector ez dela erortzen.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` ezartzea:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Horretarako modu anitz daude eta arazo ugari daude (transmute) modu honekin.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // lehenengoa: transmutazioa ez da mota segurua;egiaztatzen duen guztia T eta
    ///         // U tamaina berekoak dira.
    ///         // Bigarrenik, hementxe, bi erreferentzia alda daitezke memoria bera seinalatzen dutenak.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Honek motako segurtasun arazoak kentzen ditu;`&mut *`-k `&mut T` edo `* mut T`-tik `&mut T`-k emango dizu *soilik*.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // hala ere, oraindik memoria berera seinalatzen duten bi erreferentzia alda ditzakezu.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Horrela egiten du liburutegi estandarrak.
    /// // Hau da metodorik onena, horrelako zerbait egin behar baduzu
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Honek orain hiru erreferentzia aldaezinak ditu memoria bera seinalatzen dutenak.`slice`, ret.0 balioa eta ret.1 balioa.
    ///         // `slice` ez da inoiz erabiltzen `let ptr = ...` ondoren, beraz, "dead" gisa tratatu daiteke eta, beraz, bi zati aldaezinak besterik ez dituzu.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Horrek berezko konst konstantea egonkorra bihurtzen duen arren, kode pertsonalizatu batzuk ditugu const fn
    // `const fn` barruan erabiltzea eragozten duten egiaztapenak.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// `true` ematen du `T` gisa ematen den benetako motak kola erortzea eskatzen badu;`false` itzultzen du `T`-entzat emandako motak `Copy` inplementatzen badu.
    ///
    ///
    /// Benetako motak ez badu kola erortzerik behar eta `Copy` inplementatzen ez badu, funtzio horren itzulerako balioa zehaztu gabe dago.
    ///
    /// Berezko bertsio egonkortua [`mem::needs_drop`](crate::mem::needs_drop) da.
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Erakusle batetik desplazamendua kalkulatzen du.
    ///
    /// Hau berezko gisa inplementatzen da zenbaki oso batera eta honetatik bihurtzea ekiditeko, bihurketak aliasing informazioa botako lukeelako.
    ///
    /// # Safety
    ///
    /// Hasierako erakusleak eta ondorioz lortutako erakusleak mugatutako mugak edo esleitutako objektuaren amaierako byte bat izan behar dute.
    /// Erakuslea mugetatik kanpo badago edo gainezkatze aritmetikoa gertatzen bada, itzultzen den balioa berriro erabiltzeak zehaztu gabeko portaera eragingo du.
    ///
    ///
    /// Berezko bertsio egonkortua [`pointer::offset`] da.
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Erakusle baten desplazamendua kalkulatzen du, potentzialki bilduta.
    ///
    /// Hau berezko gisa inplementatzen da zenbaki oso batera eta honetatik bihurtzea ekiditeko, bihurketak optimizazio batzuk inhibitzen baititu.
    ///
    /// # Safety
    ///
    /// `offset` berezkoak ez bezala, berezko honek ez du mugatutako emaitza erakuslea esleitutako objektu baten amaierara edo byte bat gainditzera mugatzen, eta bi osagarrien aritmetika batekin biltzen da.
    /// Lortutako balioa ez da derrigorrez baliagarria memorian sartzeko erabiltzeko.
    ///
    /// Berezko bertsio egonkortua [`pointer::wrapping_offset`] da.
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Berezko `llvm.memcpy.p0i8.0i8.*` berezkoaren baliokidea, `count`*`size_of::<T>()` tamaina eta lerrokadura
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parametro lurrunkorra `true` gisa ezarrita dago, beraz, ez da optimizatuko tamaina zero berdina izan ezean.
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Berezko `llvm.memmove.p0i8.0i8.*` berezkoaren baliokidea, `count* size_of::<T>()` tamaina eta lerrokadura
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parametro lurrunkorra `true` gisa ezarrita dago, beraz, ez da optimizatuko tamaina zero berdina izan ezean.
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Berezko `llvm.memset.p0i8.*` berezkoaren baliokidea, `count* size_of::<T>()` tamainarekin eta `min_align_of::<T>()` lerrokadurarekin.
    ///
    ///
    /// Parametro lurrunkorra `true` gisa ezarrita dago, beraz, ez da optimizatuko tamaina zero berdina izan ezean.
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// `src` erakuslearen karga lurrunkorra egiten du.
    ///
    /// Berezko bertsio egonkortua [`core::ptr::read_volatile`](crate::ptr::read_volatile) da.
    pub fn volatile_load<T>(src: *const T) -> T;
    /// `dst` erakuslearen biltegi lurrunkorra egiten du.
    ///
    /// Berezko bertsio egonkortua [`core::ptr::write_volatile`](crate::ptr::write_volatile) da.
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// `src` erakuslearen karga lurrunkorra egiten du Erakuslea ez da lerrokatu behar.
    ///
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// `dst` erakuslearen biltegi lurrunkorra egiten du.
    /// Erakuslea ez da lerrokatuta egon behar.
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// `f32` baten erro karratua ematen du
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// `f64` baten erro karratua ematen du
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// `f32` bat osotzen du potentzia osora.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// `f64` bat osotzen du potentzia osora.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// `f32` baten sinua ematen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// `f64` baten sinua ematen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// `f32` baten kosinua itzultzen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// `f64` baten kosinua itzultzen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32` bat `f32` potentziara igotzen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// `f64` bat igotzen du `f64` potentziara.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// `f32` baten esponentziala ematen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// `f64` baten esponentziala ematen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// 2 itzultzen du `f32` baten potentziara igota.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// 2 itzultzen du `f64` baten potentziara igota.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// `f32` baten logaritmo naturala itzultzen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// `f64` baten logaritmo naturala itzultzen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// `f32` baten oinarrizko 10 logaritmoa ematen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// `f64` baten oinarrizko 10 logaritmoa ematen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// `f32` baten oinarrizko 2 logaritmoa ematen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// `f64` baten oinarrizko 2 logaritmoa ematen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `a * b + c` ematen du `f32` balioetarako.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `a * b + c` ematen du `f64` balioetarako.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// `f32` baten balio absolutua ematen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// `f64` baten balio absolutua ematen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Bi gutxieneko `f32` balio ematen ditu.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Bi gutxieneko `f64` balio ematen ditu.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Bi gehieneko `f32` balio ematen ditu.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Bi gehieneko `f64` balio ematen ditu.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// `y`-tik `x`-ra seinale kopiatzen du `f32` balioetarako.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// `y`-tik `x`-ra seinale kopiatzen du `f64` balioetarako.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// `f32` baino txikiagoa edo berdina den zenbaki oso handiena ematen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// `f64` baino txikiagoa edo berdina den zenbaki oso handiena ematen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// `f32` bat baino handiagoa edo berdina den zenbaki oso txikiena ematen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// `f64` bat baino handiagoa edo berdina den zenbaki oso txikiena ematen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// `f32` baten zati osoa ematen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// `f64` baten zati osoa ematen du.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Zenbaki oso hurbilena `f32` batera itzultzen du.
    /// Puntu mugikorreko zehaztugabeko salbuespena sor dezake argumentua zenbaki oso bat ez bada.
    pub fn rintf32(x: f32) -> f32;
    /// Zenbaki oso hurbilena `f64` batera itzultzen du.
    /// Puntu mugikorreko zehaztugabeko salbuespena sor dezake argumentua zenbaki oso bat ez bada.
    pub fn rintf64(x: f64) -> f64;

    /// Zenbaki oso hurbilena `f32` batera itzultzen du.
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Zenbaki oso hurbilena `f64` batera itzultzen du.
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Zenbaki oso hurbilena `f32` batera itzultzen du.Bide erdiko kasuak zerotik urrun biribiltzen ditu.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Zenbaki oso hurbilena `f64` batera itzultzen du.Bide erdiko kasuak zerotik urrun biribiltzen ditu.
    ///
    /// Berezko bertsio egonkortua da
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Arau aljebraikoetan oinarritutako optimizazioak ahalbidetzen dituen Float gehigarria.
    /// Baliteke sarrerak finituak direla.
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Arau aljebraikoetan oinarritutako optimizazioak ahalbidetzen dituen karroza kenketa.
    /// Baliteke sarrerak finituak direla.
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Arau aljebraikoetan oinarritutako optimizazioak ahalbidetzen dituen karroza biderkatzea.
    /// Baliteke sarrerak finituak direla.
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Arau aljebraikoetan oinarritutako optimizazioak ahalbidetzen dituen karroza banaketa.
    /// Baliteke sarrerak finituak direla.
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Arau aljebraikoetan oinarritutako optimizazioak ahalbidetzen dituen Float hondarra.
    /// Baliteke sarrerak finituak direla.
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Bihurtu LLVM-ren fptoui/fptosi-rekin, baliteke barrutitik kanpoko balioetarako undef itzul daitekeela
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// [`f32::to_int_unchecked`] eta [`f64::to_int_unchecked`] gisa egonkortuta.
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// `T` zenbaki oso batean ezarritako bit kopurua ematen du
    ///
    /// Berezko bertsio egonkortuak zenbaki oso primitiboetan eskuragarri daude `count_ones` metodoaren bidez.
    /// Adibidez,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// `T` zenbaki osoko (zeroes) lehenetsi gabeko bit kopurua ematen du.
    ///
    /// Berezko bertsio egonkortuak zenbaki oso primitiboetan eskuragarri daude `leading_zeros` metodoaren bidez.
    /// Adibidez,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `0` balioa duen `x` batek `T`-ren bit zabalera itzuliko du.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// `ctlz` bezala, baina ez da oso segurua `undef` itzultzen baitu X003 balioa duen `x` bat ematean.
    ///
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// (zeroes) zenbaki oso bateko (zeroes) amaierako multzoen bit kopurua ematen du.
    ///
    /// Berezko bertsio egonkortuak zenbaki oso primitiboetan eskuragarri daude `trailing_zeros` metodoaren bidez.
    /// Adibidez,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `0` balioa duen `x` batek `T`-ren bit zabalera itzuliko du:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// `cttz` bezala, baina ez da oso segurua `undef` itzultzen baitu X003 balioa duen `x` bat ematean.
    ///
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// `T` zenbaki oso bateko byte-ak alderantzikatzen ditu.
    ///
    /// Berezko bertsio egonkortuak zenbaki oso primitiboetan eskuragarri daude `swap_bytes` metodoaren bidez.
    /// Adibidez,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// `T` zenbaki oso bateko bitak alderantzikatzen ditu.
    ///
    /// Berezko bertsio egonkortuak zenbaki oso primitiboetan eskuragarri daude `reverse_bits` metodoaren bidez.
    /// Adibidez,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Egiaztatutako zenbaki osoen gehikuntza egiten du.
    ///
    /// Berezko bertsio egonkortuak zenbaki oso primitiboetan eskuragarri daude `overflowing_add` metodoaren bidez.
    /// Adibidez,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Egiaztatutako zenbaki osoen kenketa egiten du
    ///
    /// Berezko bertsio egonkortuak zenbaki oso primitiboetan eskuragarri daude `overflowing_sub` metodoaren bidez.
    /// Adibidez,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Egiaztatutako zenbaki osoen biderketa egiten du
    ///
    /// Berezko bertsio egonkortuak zenbaki oso primitiboetan eskuragarri daude `overflowing_mul` metodoaren bidez.
    /// Adibidez,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Zatiketa zehatza egiten du, `x % y != 0` edo `y == 0` edo `x == T::MIN && y == -1` non definitu gabeko portaera lortuz
    ///
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Egiaztatu gabeko zatiketa egiten du, `y == 0` edo `x == T::MIN && y == -1` non jokaera zehaztu gabe
    ///
    ///
    /// Berezko honen bilgarri seguruak oso-osoko primitiboetan eskuragarri daude `checked_div` metodoaren bidez.
    /// Adibidez,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Egiaztatu gabeko zatiketa baten hondarra itzultzen du, `y == 0` edo `x == T::MIN && y == -1` denean portaera zehaztu gabea lortuz
    ///
    ///
    /// Berezko honen bilgarri seguruak oso-osoko primitiboetan eskuragarri daude `checked_rem` metodoaren bidez.
    /// Adibidez,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Ezkerreko desplazamendu desegokia egiten du, portaera zehaztu gabea lortuz `y < 0` edo `y >= N` denean, non N bit-en zabalera den.
    ///
    ///
    /// Berezko honen bilgarri seguruak osagai primitiboetan eskuragarri daude `checked_shl` metodoaren bidez.
    /// Adibidez,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Kontrolatu gabeko eskuineko desplazamendua egiten du, eta zehaztu gabeko portaera eragiten du `y < 0` edo `y >= N` denean, N bit-en zabalera den aldetik.
    ///
    ///
    /// Berezko honen bilgarri seguruak osagai primitiboetan eskuragarri daude `checked_shr` metodoaren bidez.
    /// Adibidez,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Egiaztatu gabeko gehikuntzaren emaitza ematen du, `x + y > T::MAX` edo `x + y < T::MIN` denean portaera zehaztu gabea lortuz.
    ///
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Egiaztatu gabeko kenketaren emaitza ematen du, `x - y > T::MAX` edo `x - y < T::MIN` denean portaera zehaztu gabea lortuz.
    ///
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Egiaztatu gabeko biderketaren emaitza ematen du, `x *y > T::MAX` edo `x* y < T::MIN` denean portaera zehaztu gabea lortuz.
    ///
    ///
    /// Berezko honek ez du parekorik egonkorrik.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Biratu ezkerrera egiten du.
    ///
    /// Berezko bertsio egonkortuak zenbaki oso primitiboetan eskuragarri daude `rotate_left` metodoaren bidez.
    /// Adibidez,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Biratu eskuinera egiten du.
    ///
    /// Berezko bertsio egonkortuak zenbaki oso primitiboetan eskuragarri daude `rotate_right` metodoaren bidez.
    /// Adibidez,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// (A + b) mod 2 <sup>N ematen du</sup>, non N bit-en zabalera den.
    ///
    /// Berezko bertsio egonkortuak zenbaki oso primitiboetan eskuragarri daude `wrapping_add` metodoaren bidez.
    /// Adibidez,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// (A, b) mod 2 <sup>N ematen du</sup>, non N bit-en zabalera den.
    ///
    /// Berezko bertsio egonkortuak zenbaki oso primitiboetan eskuragarri daude `wrapping_sub` metodoaren bidez.
    /// Adibidez,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// (A * b) mod 2 <sup>N ematen du</sup>, non N bit-en zabalera den.
    ///
    /// Berezko bertsio egonkortuak zenbaki oso primitiboetan eskuragarri daude `wrapping_mul` metodoaren bidez.
    /// Adibidez,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// `a + b` kalkulatzen du, zenbakizko mugetan saturatuz.
    ///
    /// Berezko bertsio egonkortuak zenbaki oso primitiboetan eskuragarri daude `saturating_add` metodoaren bidez.
    /// Adibidez,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// `a - b` kalkulatzen du, zenbakizko mugetan saturatuz.
    ///
    /// Berezko bertsio egonkortuak zenbaki oso primitiboetan eskuragarri daude `saturating_sub` metodoaren bidez.
    /// Adibidez,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 'v'-n aldaeraren diskriminatzailearen balioa ematen du;
    /// `T`-k diskriminatzailerik ez badu, `0` itzultzen du.
    ///
    /// Berezko bertsio egonkortua [`core::mem::discriminant`](crate::mem::discriminant) da.
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// `T` motako aldaera kopurua `usize` ra itzultzen du;
    /// `T`-k aldaerarik ez badu, `0` itzultzen du.Bizirik gabeko aldaerak zenbatuko dira.
    ///
    /// Berezko egonkortzeko dagoen bertsioa [`mem::variant_count`] da.
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust-ren "try catch" eraikuntza, `try_fn` funtzio erakuslea `data` datu erakuslearekin deitzen duena.
    ///
    /// Hirugarren argumentua panic bat gertatzen bada deitutako funtzioa da.
    /// Funtzio honek datuen erakuslea eta erakuslea harrapatutako xede-salbuespeneko objektura eramaten ditu.
    ///
    /// Informazio gehiagorako ikusi konpilatzailearen iturria eta baita std-ren harrapaketa inplementazioa.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// LLVMren arabera `!nontemporal` denda igortzen du (ikusi haien dokumentuak).
    /// Ziurrenik ez da inoiz egonkor bihurtuko.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// `<*const T>::offset_from`-ren dokumentazioa xehetasunetarako.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// `<*const T>::guaranteed_eq`-ren dokumentazioa xehetasunetarako.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// `<*const T>::guaranteed_ne`-ren dokumentazioa xehetasunetarako.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Esleitu konpilazio garaian.Ez da deitu behar exekuzio garaian.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Funtzio batzuk hemen definitzen dira ustekabean modulu honetan egonkorrean eskuragarri jarri direlako.
// Ikus <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` ere kategoria honetan sartzen da, baina ezin da bildu `T` eta `U` tamaina bera dutela egiaztatuta dagoelako).
//

/// `ptr` `align_of::<T>()` rekiko ondo lerrokatuta dagoen egiaztatzen du.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `count *size_of::<T>()` byte-ak `src`-tik `dst`-ra kopiatzen ditu.Iturria eta helmuga* ez * gainjarri behar dira.
///
/// Gainjarri daitezkeen memoria eskualdeetarako, erabili [`copy`] horren ordez.
///
/// `copy_nonoverlapping` semantikoki C's [`memcpy`] ren baliokidea da, baina argumentu ordena trukatuta.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Portaera zehaztu gabe dago baldintza hauetakoren bat urratzen bada:
///
/// * `src` [valid] izan behar du `count * size_of::<T>()` byteen irakurketetarako.
///
/// * `dst` [valid] izan behar du `count * size_of::<T>()` byteen idazketetarako.
///
/// * `src` eta `dst` biak behar bezala lerrokatuta egon behar dute.
///
/// * `src`-n hasten den memoriaren eskualdea `count tamaina batekin *
///   tamaina_ren: :<T>() `byteek *ez dute* gainjarri behar tamaina bereko `dst`-tik hasitako memoriaren eskualdearekin.
///
/// [`read`]-k bezala, `copy_nonoverlapping`-k `T`-ren kopia bit bat sortzen du, `T` [`Copy`] den ala ez kontuan hartu gabe.
/// `T` ez bada [`Copy`],*biak* erabiliz `*src`-tik hasitako eskualdeko balioak eta `* dst`-tik hasitako eskualdeak [violate memory safety][read-ownership]-koa izan daiteke.
///
///
/// Kontuan izan modu eraginkorrean kopiatutako tamaina (`count * size_of: :<T>()`) `0` da, erakusleek NULL ez direnak eta behar bezala lerrokatuta egon behar dute.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] eskuz inplementatu:
///
/// ```
/// use std::ptr;
///
/// /// `src`-ren elementu guztiak `dst`-ra mugitzen ditu, `src` hutsik utziz.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Ziurtatu `dst`-k `src` guztia edukitzeko adina gaitasun duela.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Desplazatzeko deia beti da segurua, `Vec`-k ez baitu inoiz `isize::MAX` byte baino gehiago esleituko.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Moztu `src` edukia bota gabe.
///         // Hori egiten dugu lehenik, arazoak ekiditeko panics beherago dagoen zerbait.
///         src.set_len(0);
///
///         // Bi eskualdeek ezin dute gainjarri erreferentzia aldaezinak ez direlako ezizenak, eta bi vectors desberdinek ezin dute memoria beraren jabe izan.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Jakinarazi `dst` ri orain `src` ren edukia duela.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Egiaztapen hauek exekutatzeko unean bakarrik egin
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Ez izutzen kodegen inpaktua txikiagoa izan dadin.
        abort();
    }*/

    // SEGURTASUNA: `copy_nonoverlapping` ren segurtasun kontratuak izan behar du
    // deitzaileak onartzen du.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `count * size_of::<T>()` byte-ak `src`-tik `dst`-ra kopiatzen ditu.Iturburua eta helmuga gainjarri daitezke.
///
/// Iturria eta helmuga *inoiz* gainjarriko ez balira, [`copy_nonoverlapping`] erabil daiteke horren ordez.
///
/// `copy` semantikoki C's [`memmove`] ren baliokidea da, baina argumentu ordena trukatuta.
/// Kopiatzea byte-ak `src`-tik aldi baterako array batera kopiatu eta gero array-tik `dst`-era kopiatuko balira bezala egiten da.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Portaera zehaztu gabe dago baldintza hauetakoren bat urratzen bada:
///
/// * `src` [valid] izan behar du `count * size_of::<T>()` byteen irakurketetarako.
///
/// * `dst` [valid] izan behar du `count * size_of::<T>()` byteen idazketetarako.
///
/// * `src` eta `dst` biak behar bezala lerrokatuta egon behar dute.
///
/// [`read`]-k bezala, `copy`-k `T`-ren kopia bit bat sortzen du, `T` [`Copy`] den ala ez kontuan hartu gabe.
/// `T` ez bada [`Copy`], `*src`-tik hasitako eskualdeko balioak eta `* dst`-tik hasitako eskualdeak [violate memory safety][read-ownership]-ek erabil ditzakete.
///
///
/// Kontuan izan modu eraginkorrean kopiatutako tamaina (`count * size_of: :<T>()`) `0` da, erakusleek NULL ez direnak eta behar bezala lerrokatuta egon behar dute.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Sortu modu eraginkorrean Rust vector segurtasun gabeko buffer batetik:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` behar bezala lerrokatuta egon behar du bere motarako eta zero ez dena.
/// /// * `ptr` baliozkoak izan behar dira X001 motako `elts` elementu ondokoen irakurketetarako.
/// /// * Elementu horiek ez dira erabili behar funtzio honi deitu ondoren `T: Copy` izan ezik.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SEGURTASUNA: gure aurrebaldintzak iturria lerrokatuta eta baliozkoa dela ziurtatzen du.
///     // eta `Vec::with_capacity`-k haiek idazteko espazio erabilgarria dugula ziurtatzen du.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SEGURTASUNA: askoz gaitasun honekin sortu genuen lehenago,
///     // eta aurreko `copy`-k elementu horiek hasieratu ditu.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Egiaztapen hauek exekutatzeko unean bakarrik egin
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Ez izutzen kodegen inpaktua txikiagoa izan dadin.
        abort();
    }*/

    // SEGURTASUNA: deitzaileak `copy` ren segurtasun kontratua onartu beharko du.
    unsafe { copy(src, dst, count) }
}

/// `count * size_of::<T>()` memoria byte ezartzen du `dst`-tik `val`-ra hasita.
///
/// `write_bytes` C-ren [`memset`]-ren antzekoa da, baina `count * size_of::<T>()` byte-ak `val`-ra ezartzen ditu.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Portaera zehaztu gabe dago baldintza hauetakoren bat urratzen bada:
///
/// * `dst` [valid] izan behar du `count * size_of::<T>()` byteen idazketetarako.
///
/// * `dst` behar bezala lerrokatuta egon behar du.
///
/// Gainera, deitzaileak ziurtatu behar du `count * size_of::<T>()` byteek emandako memoria eskualdean idazteak `T` balio balioa lortzen duela.
/// `T` balio baliogabea duen `T` gisa idatzitako memoria eskualde bat erabiltzeak zehaztu gabeko portaera da.
///
/// Kontuan izan modu eraginkorrean kopiatutako tamaina (`count * size_of: :<T>()`) `0` da, erakusleak NULL ez den eta behar bezala lerrokatuta egon behar du.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Balio baliogabea sortzea:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Aurretik mantendutako balioa ihes egiten du `Box<T>` erakuslea nulua gainidatziz.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Une honetan, `v` erabiltzeak edo uzteak zehaztu gabeko portaera eragiten du.
/// // drop(v); // ERROR
///
/// // Nahiz eta `v` "uses" filtratu, eta, beraz, zehaztu gabeko portaera da.
/// // mem::forget(v); // ERROR
///
/// // Izan ere, `v` baliogabea da oinarrizko motako diseinu aldaezinen arabera, beraz, ukitzen duen * edozein eragiketa definitu gabeko portaera da.
/////
/// // utzi v2 =v;//ERROREA
///
/// unsafe {
///     // Jar dezagun balio baliotsua
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Orain kutxa ondo dago
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SEGURTASUNA: deitzaileak `write_bytes` ren segurtasun kontratua onartu beharko du.
    unsafe { write_bytes(dst, val, count) }
}