use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T` ren hasierarik gabeko instantziak eraikitzeko bilgarri mota.
///
/// # Hasieraketa aldaezina
///
/// Konpiladoreak, orokorrean, aldagai bat aldagai motaren eskakizunen arabera ondo hasita dagoela suposatzen du.Adibidez, erreferentzia motako aldagai batek lerrokatuta eta NULL ez izan behar du.
/// Hau *beti* mantendu behar den aldaezina da, kode ez seguruan ere.
/// Ondorioz, erreferentzia motako aldagai zero hasieratzeak berehalako [undefined behavior][ub] eragiten du, erreferentzia hori inoiz memorian sartzeko erabiltzen den ala ez:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // portaera definitu gabea!⚠️
/// // `MaybeUninit<&i32>`-rekin baliokidea den kodea:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // portaera definitu gabea!⚠️
/// ```
///
/// Konpiladoreak hainbat optimizazioetarako baliatzen du, hala nola, exekuzio-denborako egiaztapenak eta `enum` diseinua optimizatzeko.
///
/// Era berean, hasierarik gabeko memoria osoak eduki dezake, eta `bool` batek `true` edo `false` izan behar du beti.Hori dela eta, hasierarik gabeko `bool` sortzea definitu gabeko portaera da:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // portaera definitu gabea!⚠️
/// // `MaybeUninit<bool>`-rekin baliokidea den kodea:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // portaera definitu gabea!⚠️
/// ```
///
/// Gainera, hasierarik gabeko memoria berezia da, balio finkorik ez duelako ("fixed" "it won't change without being written to" esan nahi du).Inizializatu gabeko byte bera hainbat aldiz irakurtzeak emaitza desberdinak eman ditzake.
/// Horrek portaera definitu gabea bihurtzen du hasierarik gabeko datuak aldagai batean edukitzea, nahiz eta aldagai horrek zenbaki oso bat izan, bestela edozein *finko* bit eredua eduki dezake:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // portaera definitu gabea!⚠️
/// // `MaybeUninit<i32>`-rekin baliokidea den kodea:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // portaera definitu gabea!⚠️
/// ```
/// (Kontuan izan hasierarik gabeko zenbaki osoen inguruko arauak oraindik ez direla amaituta, baina hala izan arte, komenigarria da horiek ekiditea.)
///
/// Horretaz gain, gogoratu mota gehienek aldaera osagarriak dituztela mota mailan hasieratuta egoteaz gain.
/// Adibidez, `1` hasieratutako [`Vec<T>`] hasieratzat jotzen da (uneko inplementazioaren arabera; horrek ez du berme egonkorrik osatzen), konpiladoreak horretaz ezagutzen duen baldintza bakarra datu erakusleak nulua izan behar duelako da.
/// `Vec<T>` hori sortzeak ez du definitu gabeko * berehalako jokabiderik eragiten, baina zehaztu gabeko portaera eragingo du eragiketa seguru gehienekin (jaregitea barne).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` hasierarik gabeko datuei aurre egiteko kode ez segurua gaitzeko balio du.
/// Hemen biltzen diren datuak *ez* hasieratu daitezkeela adierazten duen seinalea da konpilatzailearentzat.
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Sortu hasierarik gabeko erreferentzia esplizitu bat.
/// // Konpiladoreak badaki `MaybeUninit<T>` baten barruan datuak baliogabeak izan daitezkeela eta, beraz, hau ez da UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Ezarri baliozko balioa.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Atera hasieratutako datuak-hau bakarrik onartzen da * `x` behar bezala hasita egon ondoren!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Konpiladoreak badaki kode honen gaineko hipotesi edo optimizazio okerrik ez duela egiten.
///
/// `MaybeUninit<T>` pentsa dezakezu `Option<T>` bezalakoa dela, baina exekuzioaren jarraipena egin gabe eta segurtasun kontrolik gabe.
///
/// ## out-pointers
///
/// `MaybeUninit<T>` erabil dezakezu "out-pointers" ezartzeko: funtzio batetik datuak itzuli beharrean, pasatu erakuslea (uninitialized) memoria batzuetara emaitza jartzeko.
/// Hau baliagarria izan daiteke, deitzaileak emaitza gordetzen duen memoria nola esleitzen den kontrolatzea garrantzitsua denean eta beharrezkoak ez diren mugimenduak ekidin nahi dituzunean.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ez du eduki zaharra askatzen, eta hori garrantzitsua da.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Orain badakigu `v` hasieratuta dagoela!Horrek ziurtatzen du vector behar bezala jaisten dela ere.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Matrize bat elementuz elementu hasieratzea
///
/// `MaybeUninit<T>` elementu handiz elementu handi bat hasieratzeko erabil daiteke:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Sortu hasierarik gabeko `MaybeUninit` array bat.
///     // `assume_init` segurua da, hemen hasieratu dugula esaten duguna "MaybeUninit"-en sorta bat delako, hasierarik behar ez dutenak.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit` bat jartzeak ez du ezer egiten.
///     // Beraz, `ptr::write`-ren ordez erakusle gordinak erabiltzeak ez du hasieratu gabeko balio zaharra erortzea eragiten.
/////
///     // Gainera, begizta horretan panic badago, memoria isuri bat dugu, baina ez dago memoria segurtasun arazorik.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Dena hasieratuta dago.
///     // Transmutatu array hasieratutako motara.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Partzialki hasieratutako arrayekin ere lan egin dezakezu, maila baxuko datu egituretan aurki daitezkeenak.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Sortu hasierarik gabeko `MaybeUninit` array bat.
/// // `assume_init` segurua da, hemen hasieratu dugula esaten duguna "MaybeUninit"-en sorta bat delako, hasierarik behar ez dutenak.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Zenbatu ditugun elementu kopurua.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Matrizeko elementu bakoitzerako, jaregin esleitzen badugu.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Oinarrizko egitura hasieratzea
///
/// `MaybeUninit<T>` eta [`std::ptr::addr_of_mut`] makroa erabil ditzakezu egiturak eremuz eremu hasieratzeko:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` eremua hasieratzen
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` eremua hasieratzea Hemen panic badago, `name` eremuan `String` ihes egiten da.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Eremu guztiak hasieratuta daude, beraz `assume_init` deitzen diogu hasieratutako Foo bat lortzeko.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` ren tamaina, lerrokadura eta ABI berdina izango duela ziurtatuta dago:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Hala ere, gogoratu `MaybeUninit<T>`*duen* motak ez duela zertan diseinu bera izan;Rust-k ez du orokorrean bermatzen `Foo<T>` baten eremuak `Foo<U>` ren ordena bera dutenik, nahiz eta `T` eta `U` tamaina eta lerrokadura berdina izan.
///
/// Gainera, edozein bit balio `MaybeUninit<T>` batentzat baliagarria denez, konpiladoreak ezin ditu non-zero/niche-filling optimizazioak aplikatu, baliteke tamaina handiagoa izatea:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// `T` FFI segurua bada, `MaybeUninit<T>` ere bai.
///
/// `MaybeUninit` `#[repr(transparent)]` bada ere (`T` ren tamaina, lerrokadura eta ABI berdinak bermatzen dituela adierazten du), horrek ez du aurreko * ohartarazpenik aldatzen.
/// `Option<T>` eta `Option<MaybeUninit<T>>` ek tamaina desberdinak izan ditzakete oraindik, eta `T` motako eremua duten motak eremu hori `MaybeUninit<T>` balitz baino modu desberdinean banatu (eta neurtu) daitezke.
/// `MaybeUninit` sindikatu mota da, eta sindikatuetan `#[repr(transparent)]` ezegonkorra da (ikus [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Denborarekin, `#[repr(transparent)]` ren berme zehatzak sindikatuetan eboluzionatu daitezke, eta `MaybeUninit` `#[repr(transparent)]` izaten jarrai dezake edo ez.
/// Hori bai, `MaybeUninit<T>` ek *beti* bermatuko du `T` ren tamaina, lerrokadura eta ABI berdinak dituela;berme hori `MaybeUninit` ezartzeko moduak bilaka dezake.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang elementua, beste motak bertan biltzeko.Hau erabilgarria da sorgailuentzat.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()` ri deitu gabe, ezin dugu jakin horretarako nahikoa hasierarik dugun.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Emandako balioarekin hasieratutako `MaybeUninit<T>` berria sortzen du.
    /// Seguru da [`assume_init`] deitzea funtzio horren bueltan.
    ///
    /// Kontuan izan `MaybeUninit<T>` bat jartzeak ez duela sekula deituko `T` ren jaregite kodea.
    /// Zure erantzukizuna da hasieratu bada `T` jaisten dela ziurtatzea.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// `MaybeUninit<T>` berria sortzen du hasierarik gabeko egoeran.
    ///
    /// Kontuan izan `MaybeUninit<T>` bat jartzeak ez duela sekula deituko `T` ren jaregite kodea.
    /// Zure erantzukizuna da hasieratu bada `T` jaisten dela ziurtatzea.
    ///
    /// Ikusi [type-level documentation][MaybeUninit] adibide batzuk.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Sortu `MaybeUninit<T>` elementuen array berria, hasierarik gabeko egoeran.
    ///
    /// Note: future Rust bertsioan metodo hau alferrikakoa izan daiteke array sintaxi literalak [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) ahalbidetzen duenean.
    ///
    /// Beheko adibideak `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` erabil dezake.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Benetan irakurritako datu zati bat (agian txikiagoa) ematen du
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SEGURTASUNA: hasierarik gabeko `[MaybeUninit<_>; LEN]` balio du.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// `MaybeUninit<T>` berria sortzen du hasierarik gabeko egoeran, memoria `0` bytez betetzen delarik.`T` ren araberakoa da dagoeneko hasieraketa egokia egiten duen ala ez.
    ///
    /// Adibidez, `MaybeUninit<usize>::zeroed()` hasieratzen da, baina `MaybeUninit<&'static i32>::zeroed()` ez da erreferentziak nuluak izan behar ez direlako.
    ///
    /// Kontuan izan `MaybeUninit<T>` bat jartzeak ez duela sekula deituko `T` ren jaregite kodea.
    /// Zure erantzukizuna da hasieratu bada `T` jaisten dela ziurtatzea.
    ///
    /// # Example
    ///
    /// Funtzio honen erabilera zuzena: egitura zeroarekin hasieratzea, egituraren eremu guztiek 0 bit-eredua baliozko balio gisa eduki dezakete.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// Funtzio honen erabilera *okerra*: `x.zeroed().assume_init()` ri deitzea `0` motarako balio ez duen bit-eredua denean:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Bikote baten barruan, baliozko diskriminatzailea ez duen `NotZero` bat sortzen dugu.
    /// // Hau zehaztu gabeko portaera da.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SEGURTASUNA: `u.as_mut_ptr()` puntuak esleitutako memoriara.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` ren balioa ezartzen du.
    /// Honek aurreko edozein balio gainidatzi egiten du jaregin gabe, beraz, kontuz ez erabili birritan suntsitzailea exekutatzen utzi nahi ez baduzu.
    ///
    /// Zure erosotasunerako, honek `self`-ren (orain hasierako segurtasunez hasitako) erreferentzia aldakorra ere itzultzen du.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SEGURTASUNA: balio hau hasieratu berri dugu.
        unsafe { self.assume_init_mut() }
    }

    /// Erakuslea lortutako balioaraino lortzen du.
    /// Erakusle honetatik irakurtzea edo erreferentzia bihurtzea zehaztu gabeko portaera da, `MaybeUninit<T>` hasieratu ezean.
    /// (non-transitively) erakusle honek adierazten duen memorian idaztea zehaztu gabeko portaera da (`UnsafeCell<T>` baten barruan izan ezik).
    ///
    /// # Examples
    ///
    /// Metodo honen erabilera zuzena:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Sortu erreferentzia bat `MaybeUninit<T>`-n.Ondo dago hasieratu dugulako.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// Metodo honen erabilera *okerra*:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Hasierarik gabeko vector erreferentzia sortu dugu!Hau zehaztu gabeko portaera da.⚠️
    /// ```
    ///
    /// (Kontuan izan hasierarik gabeko datuen erreferentzien inguruko arauak oraindik ez direla amaituta, baina horiek izan arte, komenigarria da horiek ekiditea.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` eta `ManuallyDrop` biak `repr(transparent)` dira, beraz erakuslea bota dezakegu.
        self as *const _ as *const T
    }

    /// Erakusle aldakorra lortzen du jasotako balioaraino.
    /// Erakusle honetatik irakurtzea edo erreferentzia bihurtzea zehaztu gabeko portaera da, `MaybeUninit<T>` hasieratu ezean.
    ///
    /// # Examples
    ///
    /// Metodo honen erabilera zuzena:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Sortu erreferentzia bat `MaybeUninit<Vec<u32>>`-n.
    /// // Ondo dago hasieratu dugulako.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// Metodo honen erabilera *okerra*:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Hasierarik gabeko vector erreferentzia sortu dugu!Hau zehaztu gabeko portaera da.⚠️
    /// ```
    ///
    /// (Kontuan izan hasierarik gabeko datuen erreferentzien inguruko arauak oraindik ez direla amaituta, baina horiek izan arte, komenigarria da horiek ekiditea.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` eta `ManuallyDrop` biak `repr(transparent)` dira, beraz erakuslea bota dezakegu.
        self as *mut _ as *mut T
    }

    /// Balioa `MaybeUninit<T>` edukiontzitik ateratzen du.Datuak jaitsi egingo direla ziurtatzeko modu bikaina da, ondorioz `T`-a ohiko jaitsieraren menpe dagoelako.
    ///
    /// # Safety
    ///
    /// Deitzailearen esku dago `MaybeUninit<T>` benetan hasierako egoeran dagoela bermatzea.Edukia oraindik guztiz hasieratu ez denean deitzeak berehala zehaztu gabeko portaera eragiten du.
    /// [type-level documentation][inv]-k hasierako aldaera honi buruzko informazio gehiago dauka.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Horretaz gain, gogoratu mota gehienek aldaera osagarriak dituztela mota mailan hasieratuta egoteaz gain.
    /// Adibidez, `1` hasieratutako [`Vec<T>`] hasieratzat jotzen da (uneko inplementazioaren arabera; horrek ez du berme egonkorrik osatzen), konpiladoreak horretaz ezagutzen duen baldintza bakarra datu erakusleak nulua izan behar duelako da.
    ///
    /// `Vec<T>` hori sortzeak ez du definitu gabeko * berehalako jokabiderik eragiten, baina zehaztu gabeko portaera eragingo du eragiketa seguru gehienekin (jaregitea barne).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Metodo honen erabilera zuzena:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// Metodo honen erabilera *okerra*:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` oraindik ez zen hasieratu, beraz, azken lerro honek zehaztu gabeko portaera eragin zuen.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SEGURTASUNA: deitzaileak `self` hasierakoa dela bermatu behar du.
        // Horrek `self` `value` aldaera izan behar duela ere esan nahi du.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` edukiontziaren balioa irakurtzen du.Lortutako `T` ohiko jaitsieraren menpe dago.
    ///
    /// Ahal den guztietan, hobe da horren ordez [`assume_init`] erabiltzea, eta horrek `MaybeUninit<T>` ren edukia bikoiztea eragozten du.
    ///
    /// # Safety
    ///
    /// Deitzailearen esku dago `MaybeUninit<T>` benetan hasierako egoeran dagoela bermatzea.Edukia oraindik guztiz hasieratu ez denean deitzeak zehaztu gabeko portaera eragiten du.
    /// [type-level documentation][inv]-k hasierako aldaera honi buruzko informazio gehiago dauka.
    ///
    /// Gainera, honek datu berdinen kopia uzten du `MaybeUninit<T>`-n.
    /// Datuen kopia bat baino gehiago erabiltzerakoan (`assume_init_read` behin baino gehiagotan deituz edo lehenik `assume_init_read` eta gero [`assume_init`] deituz), zure erantzukizuna da datu horiek bikoiztu egin daitezkeela ziurtatzea.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Metodo honen erabilera zuzena:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` da, beraz, hainbat aldiz irakur dezakegu.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` balioa bikoiztea ondo dago, beraz, hainbat aldiz irakur dezakegu.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// Metodo honen erabilera *okerra*:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Orain vector beraren bi kopia sortu ditugu, bikoitza doan lortuz both️ biak erortzen direnean!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SEGURTASUNA: deitzaileak `self` hasierakoa dela bermatu behar du.
        // `self.as_ptr()`-tik irakurtzea segurua da, `self` hasieratu behar baita.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Edukitako balioa bere lekuan uzten du.
    ///
    /// `MaybeUninit` aren jabetza baduzu, horren ordez [`assume_init`] erabil dezakezu.
    ///
    /// # Safety
    ///
    /// Deitzailearen esku dago `MaybeUninit<T>` benetan hasierako egoeran dagoela bermatzea.Edukia oraindik guztiz hasieratu ez denean deitzeak zehaztu gabeko portaera eragiten du.
    ///
    /// Gainera, `T` motako aldaera osagarri guztiak bete behar dira, `T`-ren `Drop` inplementazioa (edo bere kideak) horretan oinarritu baitaiteke.
    /// Adibidez, `1` hasieratutako [`Vec<T>`] hasieratzat jotzen da (uneko inplementazioaren arabera; horrek ez du berme egonkorrik osatzen), konpiladoreak horretaz ezagutzen duen baldintza bakarra datu erakusleak nulua izan behar duelako da.
    ///
    /// Halako `Vec<T>` bat botatzeak zehaztu gabeko portaera eragingo du.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SEGURTASUNA: deitzaileak `self` hasieratzen dela eta
        // `T`-ren aldaera guztiak asetzen ditu.
        // Balioa lekuan jartzea segurua da hori horrela bada.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Balio partekatuaren erreferentzia partekatua lortzen du.
    ///
    /// Hau erabilgarria izan daiteke hasierako baina `MaybeUninit` jabetzakoa ez den `MaybeUninit` batera sartu nahi dugunean (`.assume_init()`) erabiltzea eragotziz.
    ///
    /// # Safety
    ///
    /// Edukia oraindik guztiz hasieratu gabe dagoenean deitzeak zehaztu gabeko portaera eragiten du: deitzailearen esku dago `MaybeUninit<T>` benetan hasierako egoeran dagoela bermatzea.
    ///
    ///
    /// # Examples
    ///
    /// ### Metodo honen erabilera zuzena:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Hasieratu `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Orain gure `MaybeUninit<_>` hasieratuta dagoela jakinda, ondo dago erreferentzia partekatu bat sortzea:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SEGURTASUNA: `x` hasieratu da.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Metodo honen * erabilera okerrak:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Hasierarik gabeko vector erreferentzia sortu dugu!Hau zehaztu gabeko portaera da.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Hasieratu `MaybeUninit` `Cell::set` erabiliz:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Hasierarik gabeko `Cell<bool>` erreferentzia: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SEGURTASUNA: deitzaileak `self` hasierakoa dela bermatu behar du.
        // Horrek `self` `value` aldaera izan behar duela ere esan nahi du.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// (unique) aldakorreko erreferentzia lortzen du jasotako balioari.
    ///
    /// Hau erabilgarria izan daiteke hasierako baina `MaybeUninit` jabetzakoa ez den `MaybeUninit` batera sartu nahi dugunean (`.assume_init()`) erabiltzea eragotziz.
    ///
    /// # Safety
    ///
    /// Edukia oraindik guztiz hasieratu gabe dagoenean deitzeak zehaztu gabeko portaera eragiten du: deitzailearen esku dago `MaybeUninit<T>` benetan hasierako egoeran dagoela bermatzea.
    /// Adibidez, `.assume_init_mut()` ezin da erabili `MaybeUninit` bat hasieratzeko.
    ///
    /// # Examples
    ///
    /// ### Metodo honen erabilera zuzena:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Sarrerako bufferraren byte guztiak * hasten ditu.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Hasieratu `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Orain badakigu `buf` hasieratu dela, beraz `.assume_init()` izan genezake.
    /// // Hala ere, `.assume_init()` erabiltzeak 2048 byteko `memcpy` bat eragin dezake.
    /// // Gure bufferra kopiatu gabe hasieratu dela baieztatzeko, `&mut MaybeUninit<[u8; 2048]>` `&mut [u8; 2048]` bertsio batera berritzen dugu:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SEGURTASUNA: `buf` hasieratu da.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Orain `buf` xerra normal gisa erabil dezakegu:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Metodo honen * erabilera okerrak:
    ///
    /// Ezin duzu `.assume_init_mut()` erabili balio bat hasieratzeko:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Hasierarik gabeko `bool` erreferentzia bat sortu dugu (mutable)!
    ///     // Hau zehaztu gabeko portaera da.⚠️
    /// }
    /// ```
    ///
    /// Adibidez, ezin duzu [`Read`] hasierarik gabeko buffer batean sartu:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) hasierarik gabeko memoriaren erreferentzia!
    ///                             // Hau zehaztu gabeko portaera da.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Ezin duzu eremuko sarbide zuzena erabili eremuz eremuko mailakako hasieraketa egiteko:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) hasierarik gabeko memoriaren erreferentzia!
    ///                  // Hau zehaztu gabeko portaera da.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) hasierarik gabeko memoriaren erreferentzia!
    ///                  // Hau zehaztu gabeko portaera da.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Une honetan aipatutakoak okerrak direla uste dugu, hau da, hasierarik gabeko datuen erreferentziak ditugu (adibidez, `libcore/fmt/float.rs`-n).
    // Egonkortze aurretik arauen inguruko azken erabakia hartu beharko genuke.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SEGURTASUNA: deitzaileak `self` hasierakoa dela bermatu behar du.
        // Horrek `self` `value` aldaera izan behar duela ere esan nahi du.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Balioak `MaybeUninit` edukiontzi array batetik ateratzen ditu.
    ///
    /// # Safety
    ///
    /// Deitzailearen esku dago arrayko elementu guztiak hasierako egoeran daudela bermatzea.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SEGURTASUNA: orain segurua da elementu guztiak hasieratu genituela
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Deitzaileak arrayaren elementu guztiak hasieratzen direla bermatzen du
        // * `MaybeUninit<T>` eta T-k diseinu bera dutela ziurtatuta dago
        // * Agian Unint ez da jaisten, beraz, ez dago doako bikoitzik eta, beraz, bihurketa segurua da
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Elementu guztiak hasieratuta daudela suposatuz, lortu zati bat.
    ///
    /// # Safety
    ///
    /// Deitzailearen esku dago `MaybeUninit<T>` elementuak benetan hasierako egoeran daudela bermatzea.
    ///
    /// Edukia oraindik guztiz hasieratu ez denean deitzeak zehaztu gabeko portaera eragiten du.
    ///
    /// Ikus [`assume_init_ref`] xehetasun eta adibide gehiagorako.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SEGURTASUNA: `*const [T]` gailura igortzea segurua da, deitzaileak hori bermatzen baitu
        // `slice` hasieratuta dago, eta `Agian Uninit`-ek `T`-ren diseinu bera izango duela ziurtatzen da.
        // Lortutako erakuslea baliozkoa da, erreferentzia den eta, beraz, irakurketetarako balio duela ziurtatzen duen `slice` ren memoria aipatzen baita.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Elementu guztiak hasieratuta daudela suposatuz, lortu alda daitekeen zati bat.
    ///
    /// # Safety
    ///
    /// Deitzailearen esku dago `MaybeUninit<T>` elementuak benetan hasierako egoeran daudela bermatzea.
    ///
    /// Edukia oraindik guztiz hasieratu ez denean deitzeak zehaztu gabeko portaera eragiten du.
    ///
    /// Ikus [`assume_init_mut`] xehetasun eta adibide gehiagorako.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SEGURTASUNA: `slice_get_ref` segurtasun oharren antzekoa, baina badugu
        // erreferentzia aldakorra, hau da, idazketetarako ere balio duela.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Erakuslea lortzen du arrayaren lehen elementura.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Erakusle aldakorra lortzen du matrizeko lehen elementura.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Elementuak `src`-tik `this`-ra kopiatzen ditu, orain aldaketarik gabeko erreferentzia itzuliz `this`-ren edukia.
    ///
    /// `T`-k `Copy` inplementatzen ez badu, erabili [`write_slice_cloned`]
    ///
    /// Hau [`slice::copy_from_slice`] ren antzekoa da.
    ///
    /// # Panics
    ///
    /// Funtzio hau panic izango da bi zatiek luzera desberdinak badituzte.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SEGURTASUNA: len elementu guztiak ordezko edukierara kopiatu berri ditugu
    /// // vec-en lehen src.len() elementuak orain baliogarriak dira.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SEGURTASUNA: &[T] eta&[MaybeUninit<T>] diseinu bera dute
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SEGURTASUNA: Baliozko elementuak `this`-en kopiatu berri dira, beraz, hasierako moduan daude
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Elementuak klonatzen ditu `src`-tik `this`-ra, orain erreferentzia aldakorra itzuliz `this`-ren orain initalizatutako edukiei.
    /// Jadanik initalizatutako elementurik ez da botako.
    ///
    /// `T`-k `Copy` inplementatzen badu, erabili [`write_slice`]
    ///
    /// Hau [`slice::clone_from_slice`] ren antzekoa da baina ez ditu lehendik dauden elementuak botatzen.
    ///
    /// # Panics
    ///
    /// Funtzio hau panic izango da bi zatiek luzera desberdinak badituzte edo `Clone` panics ezarpena bada.
    ///
    /// panic badago, dagoeneko klonatutako elementuak jaitsi egingo dira.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SEGURTASUNA: klenatu berri ditugu len elementu guztiak ordezko edukiera
    /// // vec-en lehen src.len() elementuak orain baliogarriak dira.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // copy_from_slice-k ez bezala honek ez dio clone_from_slice zatian deitzen `MaybeUninit<T: Clone>`-k ez duelako Klonatzen inplementatzen.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SEGURTASUNA: xerra gordin honek hasieratutako objektuak bakarrik izango ditu
                // horregatik, uztea baimentzen da.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Luzera berdinean zatitu behar ditugu esplizituki
        // mugen egiaztapena ezabatzeko, eta optimizatzaileak memcpy sortuko du kasu sinpleetarako (adibidez T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // zainketa beharrezkoa da b/c panic klonazio batean gerta liteke
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SEGURTASUNA: Baliozko elementuak `this`-n idatzi berri dira, beraz, hasierako letra da
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}