use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Konpiladoreak `T` suntsitzaileari automatikoki deitzea galarazteko bilgailua.
/// Bilgarri hau 0 kostu da.
///
/// `ManuallyDrop<T>` `T` ren diseinuaren optimizazio berberen menpe dago.
/// Ondorioz, ez du *inolako eraginik* konpiladoreak bere edukiari buruz egiten dituen suposizioetan.
/// Adibidez, `ManuallyDrop<&mut T>` [`mem::zeroed`]-rekin hastea zehaztu gabeko portaera da.
/// Hasierarik gabeko datuak kudeatu behar badituzu, erabili [`MaybeUninit<T>`] horren ordez.
///
/// Kontuan izan `ManuallyDrop<T>` baten barruan sartzea segurua dela.
/// Horrek esan nahi du edukia bertan behera utzi duen `ManuallyDrop<T>` bat ezin dela API publiko seguru baten bidez erakutsi.
/// Ondorioz, `ManuallyDrop::drop` ez da segurua.
///
/// # `ManuallyDrop` eta jaregiteko agindua.
///
/// Rust-k ondo definitutako [drop order] balio ditu.
/// Eremuak edo bertako jendeak ordena zehatz batean jaregiten direla ziurtatzeko, berriro ordenatu aitorpenak, esate baterako, jaregite inplizitua zuzena dela.
///
/// Posible da `ManuallyDrop` erabiltzea jaitsiera ordena kontrolatzeko, baina horretarako kodea ez da segurua eta zaila da zuzen egitea desegiten denean.
///
///
/// Adibidez, eremu zehatz bat besteen ondoren erortzen dela ziurtatu nahi baduzu, jarri egituraren azken eremua:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` ondoren jaitsiko da.
///     // Rust-k ziurtatzen du eremuak deklarazioaren ordenan jaregiten direla.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Itzuli eskuz bota beharreko balio bat.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Oraindik ere segurtasunez balio dezakezu
    /// assert_eq!(*x, "Hello");
    /// // `Drop` ez da hemen exekutatuko
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Balioa `ManuallyDrop` edukiontzitik ateratzen du.
    ///
    /// Horrek balioa berriro jaistea ahalbidetzen du.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Honek `Box` jaisten du.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` edukiontziaren balioa ateratzen du.
    ///
    /// Metodo hau batez ere jaitsierako balioak mugitzeko pentsatuta dago.
    /// [`ManuallyDrop::drop`] balioa eskuz jaisteko erabili beharrean, metodoa erabil dezakezu balioa hartu eta nahi duzun moduan erabiltzeko.
    ///
    /// Ahal den guztietan, hobe da horren ordez [`into_inner`][`ManuallyDrop::into_inner`] erabiltzea, eta horrek `ManuallyDrop<T>` ren edukia bikoiztea eragozten du.
    ///
    ///
    /// # Safety
    ///
    /// Funtzio honek balio semantikoa mugitzen du gehiago erabiltzea eragotzi gabe, edukiontzi horren egoera aldatu gabe.
    /// Zure erantzukizuna da `ManuallyDrop` hau berriro erabiltzen ez dela ziurtatzea.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SEGURTASUNA: erreferentzia batetik irakurtzen ari gara, hori bermatuta dago
        // irakurketetarako balio du.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Edukitako balioa eskuz jaisten du.Hau da, zehazki, [`ptr::drop_in_place`] deitzeak balio duen erakuslearekin deitzea.
    /// Horrenbestez, jasotako balioa paketatutako egitura izan ezean, suntsitzaileari lekua deituko zaio balioa mugitu gabe eta, beraz, [pinned] datuak segurtasunez uzteko erabil daiteke.
    ///
    /// Balioaren jabetza baduzu, horren ordez [`ManuallyDrop::into_inner`] erabil dezakezu.
    ///
    /// # Safety
    ///
    /// Funtzio honek jasotako balioaren suntsitzailea exekutatzen du.
    /// Suntsitzaileak berak egindako aldaketez gain, memoria aldatu gabe geratzen da eta, beraz, konpiladoreari dagokionez, `T` motarako balio duen bit-eredua mantentzen da.
    ///
    ///
    /// Hala ere, "zombie" balio hau ez da kode seguruaren menpe egon behar eta funtzio horri ez zaio behin baino gehiagotan deitu behar.
    /// Kendu ondoren balio bat erabiltzeak edo balio bat behin baino gehiagotan uzteak zehaztu gabeko portaera sor dezake (`drop`-k egiten duenaren arabera).
    /// Mota sistemak hori normalean galarazten du, baina `ManuallyDrop`-ren erabiltzaileek berme horiek mantendu behar dituzte konpilatzailearen laguntzarik gabe.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SEGURTASUNA: erreferentzia aldaezinak adierazten duen balioa jaisten ari gara
        // idazketetarako balio duela bermatuta dagoena.
        // Deitzailearen esku dago `slot` berriro erortzen ez dela ziurtatzea.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}