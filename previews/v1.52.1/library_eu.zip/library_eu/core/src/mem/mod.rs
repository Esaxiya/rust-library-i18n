//! Memoriari aurre egiteko oinarrizko funtzioak.
//!
//! Modulu honek moten tamaina eta lerrokatzea kontsultatzeko, memoria hasieratzeko eta manipulatzeko funtzioak ditu.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// **jabetza eta "forgets" balioari buruz hartzen ditu** suntsitzailea exekutatu gabe **.
///
/// Balioak kudeatzen dituen edozein baliabide, hala nola memoria memoria edo fitxategi-heldulekua, betirako irauten ez duten egoeran geratuko dira.Hala ere, ez du ziurtatzen memoria honetarako erakusleak baliozkoak izango direnik.
///
/// * Memoria isuri nahi baduzu, ikusi [`Box::leak`].
/// * Memorian erakusle gordina lortu nahi baduzu, ikusi [`Box::into_raw`].
/// * Balio bat behar bezala bota nahi baduzu, bere suntsitzailea exekutatuz, ikusi [`mem::drop`].
///
/// # Safety
///
/// `forget` ez dago `unsafe` gisa markatuta, Rust ren segurtasun bermeek ez baitute suntsitzaileek beti exekutatuko duten bermerik jasotzen.
/// Adibidez, programa batek erreferentzia ziklo bat sor dezake [`Rc`][rc] erabiliz, edo [`process::exit`][exit] deitu destructoreak exekutatu gabe irteteko.
/// Horrela, `mem::forget` kode segurutik onartzeak ez du Rust ren segurtasun bermeak aldatzen funtsean.
///
/// Hori bai, memoria edo I/O objektuak bezalako baliabideak isurtzea ez da normalean desiragarria.
/// FFI edo kode ez seguruen erabilera kasu espezializatu batzuetan sortzen da beharra, baina orduan ere [`ManuallyDrop`] nahiago izaten da.
///
/// Balio bat ahaztea onartzen denez, idazten duzun `unsafe` kodek aukera hori baimendu behar du.Ezin duzu balio bat itzuli eta deitzaileak nahitaez balioaren suntsitzailea exekutatuko duela espero duzu.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget`-ren erabilera segurua kanonikoa `Drop` trait-k inplementatutako balio baten suntsitzailea saihestea da.Adibidez, honek `File` bat isuriko du, hau da
/// aldagaiak hartutako espazioa berreskuratu baina ez itxi azpiko sistemaren baliabidea:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Hau erabilgarria da azpiko baliabidearen jabetza aldez aurretik Rust-tik kanpoko kodera transferitzen zenean, adibidez fitxategi gordinaren deskribatzailea C kodera transmitituz.
///
/// # `ManuallyDrop`-rekin harremana
///
/// `mem::forget`*memoria* jabetza transferitzeko ere erabil daitekeen arren, hori egiteak akatsak ditu.
/// [`ManuallyDrop`] erabili beharrean.Demagun, adibidez, kode hau:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Eraiki `String` bat `v` ren edukia erabiliz
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // `v` leak, bere memoria orain `s`-k kudeatzen duelako
/// mem::forget(v);  // ERROREA, v baliogabea da eta ez da funtzio batera pasa behar
/// assert_eq!(s, "Az");
/// // `s` inplizituki bota eta memoria banatu egiten da.
/// ```
///
/// Goiko adibidearekin bi arazo daude:
///
/// * `String`-ren eraikuntzaren eta `mem::forget()`-ren deitzearen artean kode gehiago gehituko balitz, panic horren barruan doako bikoitza sortuko litzateke memoria bera `v`-k eta `s`-k kudeatzen dutelako.
/// * `v.as_mut_ptr()` deitu eta datuen jabetza `s` ra bidali ondoren, `v` balioa baliogabea da.
/// Balio bat `mem::forget`-ra mugitzen denean ere (horrek ez du ikuskatuko), mota batzuek baldintza zorrotzak dituzte beren balioetan, zintzilik daudenean edo jada jabetzan ez direnean baliogabeak bihurtzen dituztenak.
/// Balio baliogabeak edozein modutan erabiltzeak, funtzioei igarotzea edo itzultzea barne, portaera definitu gabea da eta konpiladoreak egindako hipotesiak apur ditzake.
///
/// `ManuallyDrop` ra aldatzeak bi arazoak ekiditen ditu:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // `v` bere zati gordinetan desmuntatu aurretik, ziurtatu ez dela erortzen!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Orain desmuntatu `v`.Eragiketa hauek ezin dute panic, beraz ezin da ihesik egon.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Azkenean, eraiki `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` inplizituki bota eta memoria banatu egiten da.
/// ```
///
/// `ManuallyDrop` doako doako bikoitza eragozten du, beste ezer egin aurretik `v` suntsitzailea desgaitzen dugulako.
/// `mem::forget()` ez du hori onartzen bere argumentua kontsumitzen duelako, behartzen gaitu `v`-etik behar dugun guztia atera ondoren soilik deitzera.
/// `ManuallyDrop` eraikitzearen eta katea eraikitzearen artean panic bat sartuko balitz ere (hori ezin da erakutsi kodean gertatu bezala), ihesa eragingo luke eta ez doako bikoitza.
/// Beste era batera esanda, `ManuallyDrop`-ek huts egiten du (bikoitza) erortzearen ordez erredukzioaren alde egiten du.
///
/// Era berean, `ManuallyDrop`-k jabetza `s`-era transferitu ondoren "touch" `v` izatea eragozten digu-`v`-rekin elkarreraginaren azken pausoa guztiz suntsitzen da suntsitzailea exekutatu gabe botatzeko.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`] bezala, baina tamaina gabeko balioak ere onartzen ditu.
///
/// Funtzio hau `unsized_locals` funtzioa egonkortzen denean kentzeko pentsatutako koskorra besterik ez da.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Mota baten tamaina byteetan ematen du.
///
/// Zehatzago esateko, elementu mota horretako matrize bateko ondoz ondoko elementuen arteko desplazamendua da, lerrokatze betegarria barne.
///
/// Horrela, edozein motatako `T` eta `n` luzerako, `[T; n]`-k `n * size_of::<T>()` tamaina du.
///
/// Oro har, mota baten tamaina ez da egonkorra konpilazioen artean, baina primitiboak bezalako mota zehatzak bai.
///
/// Hurrengo taulan primitiboen tamaina ematen da.
///
/// Mota |tamaina_ren: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 karaktere |4
///
/// Gainera, `usize` eta `isize` tamaina bera dute.
///
/// `*const T`, `&T`, `Box<T>`, `Option<&T>` eta `Option<Box<T>>` motek tamaina bera dute.
/// `T` Tamaina bada, mota horiek guztiek `usize` ren tamaina bera dute.
///
/// Erakuslearen aldakortasunak ez du tamaina aldatzen.Horrela, `&T` eta `&mut T` tamaina bera dute.
/// Era berean, `*const T` eta `* mut T`.
///
/// # `#[repr(C)]` elementuen tamaina
///
/// Elementuen `C` irudikapenak zehaztutako diseinua du.
/// Diseinu honekin, elementuen tamaina ere egonkorra da, betiere eremu guztiek tamaina egonkorra badute.
///
/// ## Egituren tamaina
///
/// `structs` kasuan, honako algoritmoak zehazten du tamaina.
///
/// Adierazpen aginduaren arabera ordenatutako egiturako eremu bakoitzeko:
///
/// 1. Gehitu eremuaren tamaina.
/// 2. Biribildu uneko tamaina hurrengo eremuko [alignment]-ren multiplo hurbilenera.
///
/// Azkenean, biribildu egituraren tamaina [alignment] ren multiplo hurbilenera.
/// Egituraren lerrokatzea normalean bere eremu guztien arteko lerrokadurarik handiena da;hau alda daiteke `repr(align(N))`-ren erabilerarekin.
///
/// `C` ez bezala, zero tamainako egiturak ez dira byte bateko tamainara biribildu.
///
/// ## Zenbakien tamaina
///
/// Diskriminatzailea ez den daturik ez duten enumek konpilatutako plataformako C enumen tamaina bera dute.
///
/// ## Sindikatuen tamaina
///
/// Batasunaren tamaina bere eremurik handienaren tamaina da.
///
/// `C`-k ez bezala, zero tamainako batasunak ez dira byte bateko tamainara biribildu.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Zenbait primitibo
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Zenbait array
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Erakuslearen tamaina berdintasuna
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` erabiliz.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Lehenengo eremuaren tamaina 1 da, beraz, gehitu tamaina.Tamaina 1 da.
/// // Bigarren eremuko lerrokadura 2 da, beraz 1 gehitu tamaina betegarria izateko.Neurria 2 da.
/// // Bigarren eremuaren tamaina 2 da, beraz, gehitu 2 tamainari.Neurria 4 da.
/// // Hirugarren eremuaren lerrokadura 1 da, beraz 0 gehitu tamaina betegarria izateko.Neurria 4 da.
/// // Hirugarren eremuaren tamaina 1 da, beraz, gehitu tamaina.Tamaina 5 da.
/// // Azkenean, egituraren lerrokadura 2 da (bere eremuen arteko lerrokadura handiena 2 delako), beraz, gehitu 1 betegarriaren tamainari.
/// // Neurria 6 da.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple egiturak arau berdinak jarraitzen dituzte.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Kontuan izan eremuak berriz antolatzeak tamaina jaitsi dezakeela.
/// // Bi betegarri byte kendu ditzakegu `third` `second` aurretik jarriz.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Batasunaren tamaina zelai handienaren tamaina da.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Puntuko balioaren tamaina itzultzen du byteetan.
///
/// Hau normalean `size_of::<T>()` bezalakoa da.
/// Hala ere, `T` *-k tamaina estatikoki ezagutzen ez duenean (adibidez, [`[T]`][slice] xerra edo [trait object] xerra), `size_of_val` erabil daiteke dinamikoki ezaguna den tamaina lortzeko.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SEGURTASUNA: `val` erreferentzia da, beraz, baliozko erakusle gordina da
    unsafe { intrinsics::size_of_val(val) }
}

/// Puntuko balioaren tamaina itzultzen du byteetan.
///
/// Hau normalean `size_of::<T>()` bezalakoa da.Hala ere, `T` *-ek tamaina estatikoki ezaguna ez duenean (adibidez, [`[T]`][slice] xerra edo [trait object] xerra), `size_of_val_raw` erabil daiteke dinamikoki ezaguna den tamaina lortzeko.
///
/// # Safety
///
/// Funtzio hau deitzeko segurua da baldintza hauek betetzen badira:
///
/// - `T` `Sized` bada, funtzio hau deitzeko segurua da beti.
/// - `T` tamaina gabeko buztana hau bada:
///     - [slice] bat, xerra buztanaren luzerak hasierako zenbaki oso bat izan behar du eta * balio osoaren tamaina (buztana luzera dinamikoa + tamaina estatikoaren aurrizkia) `isize`-n sartu behar da.
///     - [trait object] bat, orduan erakuslearen vtable zatiak tamainaz kanpoko hertsapen batek eskuratutako baliozko vtable bat seinalatu behar du eta * balio osoaren tamaina (buztan luzera dinamikoa + tamaina estatikoa aurrizkia) `isize`-n sartu behar da.
///
///     - (unstable) [extern type] bat, orduan funtzio hau deitzeko segurua da beti, baina panic edo bestela okerreko balioa itzul dezake, kanpoko motaren diseinua ez baita ezagutzen.
///     [`size_of_val`]-ren portaera bera da kanpoko motako buztana duen mota bati erreferentzia egitean.
///     - bestela, modu kontserbadorean ez da onartzen funtzio horri deitzea.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SEGURTASUNA: deitzaileak baliozko erakusle gordin bat eman behar du
    unsafe { intrinsics::size_of_val(val) }
}

/// Mota baten [ABI] behar den gutxieneko lerrokadura ematen du.
///
/// `T` motako balioari buruzko erreferentzia bakoitzak zenbaki horren multiploa izan behar du.
///
/// Hau da egitura-eremuetarako erabilitako lerrokadura.Nahiago den lerrokadura baino txikiagoa izan daiteke.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val`-k seinalatzen duen balio motaren [ABI] gutxieneko lerrokadura ematen du.
///
/// `T` motako balioari buruzko erreferentzia bakoitzak zenbaki horren multiploa izan behar du.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SEGURTASUNA: val erreferentzia da, beraz baliozko erakusle gordina da
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Mota baten [ABI] behar den gutxieneko lerrokadura ematen du.
///
/// `T` motako balioari buruzko erreferentzia bakoitzak zenbaki horren multiploa izan behar du.
///
/// Hau da egitura-eremuetarako erabilitako lerrokadura.Nahiago den lerrokadura baino txikiagoa izan daiteke.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val`-k seinalatzen duen balio motaren [ABI] gutxieneko lerrokadura ematen du.
///
/// `T` motako balioari buruzko erreferentzia bakoitzak zenbaki horren multiploa izan behar du.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SEGURTASUNA: val erreferentzia da, beraz baliozko erakusle gordina da
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `val`-k seinalatzen duen balio motaren [ABI] gutxieneko lerrokadura ematen du.
///
/// `T` motako balioari buruzko erreferentzia bakoitzak zenbaki horren multiploa izan behar du.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Funtzio hau deitzeko segurua da baldintza hauek betetzen badira:
///
/// - `T` `Sized` bada, funtzio hau deitzeko segurua da beti.
/// - `T` tamaina gabeko buztana hau bada:
///     - [slice] bat, xerra buztanaren luzerak hasierako zenbaki oso bat izan behar du eta * balio osoaren tamaina (buztana luzera dinamikoa + tamaina estatikoaren aurrizkia) `isize`-n sartu behar da.
///     - [trait object] bat, orduan erakuslearen vtable zatiak tamainaz kanpoko hertsapen batek eskuratutako baliozko vtable bat seinalatu behar du eta * balio osoaren tamaina (buztan luzera dinamikoa + tamaina estatikoa aurrizkia) `isize`-n sartu behar da.
///
///     - (unstable) [extern type] bat, orduan funtzio hau deitzeko segurua da beti, baina panic edo bestela okerreko balioa itzul dezake, kanpoko motaren diseinua ez baita ezagutzen.
///     [`align_of_val`]-ren portaera bera da kanpoko motako buztana duen mota bati erreferentzia egitean.
///     - bestela, modu kontserbadorean ez da onartzen funtzio horri deitzea.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SEGURTASUNA: deitzaileak baliozko erakusle gordin bat eman behar du
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `true` itzultzen du `T` motako balioak botatzeak garrantzia badu.
///
/// Hau optimizazio aholku hutsa da eta modu kontserbadorean ezar daiteke:
/// baliteke `true` itzultzea benetan jaitsi behar ez diren motetarako.
/// Horrela, beti `true` itzultzea funtzio honen baliozko inplementazioa izango litzateke.Hala ere, funtzio honek `false` itzultzen badu, ziur egon zaitezke `T` jaisteak ez duela bigarren mailako efekturik.
///
/// Bildumak bezalako gauzen maila baxuko inplementazioak, beren datuak eskuz jaitsi behar dituztenak, funtzio hau erabili beharko lukete suntsitzen dutenean eduki guztia jaregiten saiatzea saihesteko.
///
/// Honek agian ez du aldaketarik izango bertsioen eraikuntzan (non bigarren mailako efektuak ez dituen begizta bat erraz antzeman eta ezabatzen den), baina sarritan irabazle handia izaten da arazketetarako.
///
/// Kontuan izan [`drop_in_place`]-k dagoeneko egiten duela egiaztapen hau, beraz, zure lan-karga [`drop_in_place`] dei kopuru txikira murriztu badaiteke, ez da beharrezkoa hau erabiltzea.
/// Bereziki kontutan [`drop_in_place`] zati bat egin dezakezu, eta horrek balio guztiak ikusteko behar-beheko egiaztapen bakarra egingo du.
///
/// Vec bezalako motek, beraz, `drop_in_place(&mut self[..])` besterik ez dute `needs_drop` esplizituki erabili gabe.
/// [`HashMap`] bezalako motek, aldiz, balioak banan-banan jaitsi behar dituzte eta API hau erabili beharko lukete.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Hemen duzu bilduma batek `needs_drop` nola erabil dezakeen erakusten duen adibidea:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // datuak jaregin
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Zero guztizko byte-ereduak adierazten duen `T` motaren balioa ematen du.
///
/// Horrek esan nahi du, adibidez, `(u8, u16)`-en betegarri-byta ez dela zertan zeroan jarri.
///
/// Ez dago bermerik zero guztiko byte eredu batek `T` motako balio baliodun bat adierazten duenik.
/// Adibidez, zero guztiz byte eredua ez da baliozko erreferentzia motetarako (`&T`, `&mut T`) eta funtzio erakusleetarako.
/// Mota horietan `zeroed` erabiltzeak berehalako [undefined behavior][ub] eragiten du, [the Rust compiler assumes][inv] k hasieratutako ustez aldagai batean beti balio baliorik baitu.
///
///
/// Honek [`MaybeUninit::zeroed().assume_init()`][zeroed] ren efektu bera du.
/// FFIrako erabilgarria da batzuetan, baina orokorrean saihestu behar da.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Funtzio honen erabilera zuzena: zenbaki oso bat zeroarekin hasieratzea.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// Funtzio honen erabilera *okerra*: erreferentzia zeroarekin hasieratzea.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Portaera zehaztu gabea!
/// let _y: fn() = unsafe { mem::zeroed() }; // Eta berriro!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SEGURTASUNA: deitzaileak zero guztiak balio bat `T` rako balio duela bermatu behar du.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Rust memoria normalaren hasierako egiaztapenak saihesten ditu `T` motako balioa ekoizten duela itxuratuz, ezer egiten ez duen bitartean.
///
/// **Funtzio hau zaharkituta dago.** Erabili [`MaybeUninit<T>`] horren ordez.
///
/// Zahartzearen arrazoia da funtzioa funtsean ezin dela zuzen erabili: [`MaybeUninit::uninit().assume_init()`][uninit] ren efektu bera du.
///
/// [`assume_init` documentation][assume_init]-k azaltzen duen moduan, [the Rust compiler assumes][inv] balioak behar bezala hasieratuta daudela.
/// Ondorioz, adibidez deitzea
/// `mem::uninitialized::<bool>()` definitu gabeko berehalako portaera eragiten du behin betiko `true` edo `false` ez den `bool` bat itzultzerakoan.
/// Hemen itzultzen dena bezalako hasierarik gabeko memoria okerragoa da, izan ere, konpiladoreak badaki ez duela balio finkorik.
/// Horrek portaera definitu gabea bihurtzen du hasierarik gabeko datuak aldagai batean edukitzea, nahiz eta aldagai horrek zenbaki oso bat izan.
/// (Kontuan izan hasierarik gabeko zenbaki osoen inguruko arauak oraindik ez direla amaituta, baina hala izan arte, komenigarria da horiek ekiditea.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SEGURTASUNA: deitzaileak `T` rako balio unitario bat baliozkoa dela bermatu behar du.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Balioak aldatu daitezkeen bi kokapen aldagarritan, biak desinizializatu gabe.
///
/// * Balio lehenetsi edo faltsu batekin trukatu nahi baduzu, ikusi [`take`].
/// * Pasatutako balioarekin trukatu nahi baduzu, balio zaharra itzuliz, ikusi [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SEGURTASUNA: erakusle gordinak guztiak betetzen dituzten erreferentzia aldakor seguruetatik sortu dira
    // mugak `ptr::swap_nonoverlapping_one`-n
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest` ordezkatzen du `T` lehenetsitako balioarekin, aurreko `dest` balioa itzuliz.
///
/// * Bi aldagaien balioak ordezkatu nahi badituzu, ikusi [`swap`].
/// * Lehenetsitako balioaren ordez gainditutako balioarekin ordezkatu nahi baduzu, ikusi [`replace`].
///
/// # Examples
///
/// Adibide sinple bat:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` egiturazko eremu baten jabe egitea ahalbidetzen du "empty" balioarekin ordezkatuz.
/// `take` gabe horrelako gaiak sor ditzakezu:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Kontuan izan `T`-k ez duela derrigorrez [`Clone`] inplementatzen, beraz ezin du `self.buf` klonatu eta berrezarri ere egin.
/// Baina `take` erabil daiteke `self.buf`-ren jatorrizko balioa `self`-tik bereizteko, itzultzea ahalbidetuz:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src` erreferentziazko `dest` era eramaten du, aurreko `dest` balioa itzuliz.
///
/// Ez da balio bat ere ez jaisten.
///
/// * Bi aldagaien balioak ordezkatu nahi badituzu, ikusi [`swap`].
/// * Lehenetsitako balio batekin ordezkatu nahi baduzu, ikusi [`take`].
///
/// # Examples
///
/// Adibide sinple bat:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` egiturako eremua kontsumitzea ahalbidetzen du beste balio batekin ordezkatuz.
/// `replace` gabe horrelako gaiak sor ditzakezu:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Kontuan izan `T`-k ez duela derrigorrez [`Clone`] inplementatzen, beraz ezin dugu `self.buf[i]` klonatu mugimendua ekiditeko.
/// Baina `replace` erabil daiteke indize horretako jatorrizko balioa `self`-tik bereizteko, itzul dadin ahalbidetuz:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SEGURTASUNA: `dest`-etik irakurtzen dugu, baina zuzenean `src` bertan idazten dugu,
    // esaterako, balio zaharra bikoiztu ez dadin.
    // Ez da ezer botatzen eta hemen ezin da ezer panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Balio bat botatzen du.
///
/// Horretarako argumentua [`Drop`][drop]-ren ezarpenari deitzen zaio.
///
/// Horrek ez du ezer egiten `Copy` ezartzen duten motetarako, adibidez
/// integers.
/// Balio horiek kopiatu eta _then_ funtziora mugitzen dira, beraz, funtzioak dei honen ondoren balioa jarraitzen du.
///
///
/// Funtzio hau ez da magia;literalki honela definitzen da
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// `_x` funtziora mugitzen denez, automatikoki jaisten da funtzioa itzuli aurretik.
///
/// [drop]: Drop
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // bota esplizituki vector
/// ```
///
/// [`RefCell`]-k mailegu-arauak exekutatzean betearazten dituenez gero, `drop`-k [`RefCell`] mailegu bat askatu dezake:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // utzi zirrikitu honetako mailegu aldakorra
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Zenbaki osoak eta [`Copy`] inplementatzen duten beste mota batzuek ez dute `drop` ren eraginik.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` ren kopia mugitu eta erortzen da
/// drop(y); // `y` ren kopia mugitu eta erortzen da
///
/// println!("x: {}, y: {}", x, y.0); // oraindik eskuragarri
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src` `&U` mota duela interpretatzen du, eta ondoren `src` irakurtzen du jasotako balioa mugitu gabe.
///
/// Funtzio honek segurtasunez suposatuko du `src` erakuslea [`size_of::<U>`][size_of] byteetarako baliozkoa dela `&T`-ra `&U`-ra transmutatuz eta ondoren `&U` irakurrita (izan ezik `&U`-k `&T` baino lerrokatze-eskakizun zorrotzagoak egiten dituenean zuzena den moduan egiten da).
/// Era berean, `src`-etik atera beharrean dagoen balioaren kopia segurtasunez sortuko du.
///
/// Ez da konpilazio garaiko akatsa `T` eta `U` tamaina desberdinak badituzte, baina oso gomendagarria da funtzio hau soilik deitzea, `T` eta `U` tamaina bera dutenean.Funtzio honek [undefined behavior][ub] abiarazten du `U` `T` baino handiagoa bada.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopiatu datuak 'foo_array'-tik eta tratatu 'Foo' gisa
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Kopiatu datuak aldatu
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' ren edukia ez zen aldatu behar
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // U-k lerrokatze-eskakizun handiagoa badu, baliteke src ez egotea behar bezala lerrokatuta.
    if align_of::<U>() > align_of::<T>() {
        // SEGURTASUNA: `src` irakurketetarako balio duen erreferentzia da.
        // Deitzaileak benetako transmutazioa segurua dela bermatu behar du.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SEGURTASUNA: `src` irakurketetarako balio duen erreferentzia da.
        // `src as *const U` behar bezala lerrokatuta zegoela egiaztatu genuen.
        // Deitzaileak benetako transmutazioa segurua dela bermatu behar du.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Enum baten diskriminatzailea adierazten duen mota opakoa.
///
/// Informazio gehiagorako, ikusi moduluko [`discriminant`] funtzioa.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. trait inplementazio hauek ezin dira eratorri, T.-rako mugarik nahi ez dugulako.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// `v`-n enum aldaera modu bakarrean identifikatzen duen balioa ematen du.
///
/// `T` ez bada enum bat, funtzio horri deitzeak ez du zehaztu gabeko portaera eragingo, baina itzulerako balioa zehaztu gabe dago.
///
///
/// # Stability
///
/// Enum aldaera baten diskriminatzailea alda daiteke enum definizioa aldatzen bada.
/// Aldaera batzuen diskriminatzailea ez da aldatuko konpilatzaile berarekin egindako konpilazioen artean.
///
/// # Examples
///
/// Datuak daramatzaten kopuruak alderatzeko erabil daiteke, benetako datuak alde batera utzita:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// `T` enum motako aldaera kopurua ematen du.
///
/// `T` ez bada enum bat, funtzio horri deitzeak ez du zehaztu gabeko portaera eragingo, baina itzulerako balioa zehaztu gabe dago.
/// Era berean, `T` `usize::MAX` baino aldaera gehiago dituen enum bat bada, itzulerako balioa zehaztu gabe dago.
/// Bizirik gabeko aldaerak zenbatuko dira.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}