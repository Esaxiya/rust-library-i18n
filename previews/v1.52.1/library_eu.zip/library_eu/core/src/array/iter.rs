//! `IntoIter` jabetzako iteratzailea definitzen du matrizeetarako.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// [array] iteratzaile balioduna.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Hau da iteratzen ari garen matrizea.
    ///
    /// `i` indizea duten elementuak, `alive.start <= i < alive.end` oraindik eman ez direnak eta baliozko array sarrerak diren elementuak.
    /// `i < alive.start` edo `i >= alive.end` indizeak dituzten elementuak eman dira dagoeneko eta ezin dira gehiago sartu!Hildako elementu horiek hasierarik gabeko egoera batean egon litezke!
    ///
    ///
    /// Beraz, aldaezinak dira:
    /// - `data[alive]` bizirik dago (hau da, baliozko elementuak ditu)
    /// - `data[..alive.start]` eta `data[alive.end..]` hilda daude (hau da, elementuak dagoeneko irakurri ziren eta ez dira gehiago ukitu behar!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data`-n oraindik eman ez diren elementuak.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Iteratzaile berria sortzen du emandako `array`-en gainean.
    ///
    /// *Oharra*: metodo hau zaharkituta egon daiteke future n, [`IntoIterator` is implemented for arrays][array-into-iter] ondoren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` mota `i32` da hemen, `&i32` ordez
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SEGURTASUNA: Hemen transmutatua segurua da.`MaybeUninit` dokumentuak
        // promise:
        //
        // > `MaybeUninit<T>` tamaina eta lerrokatze berdina izango duela ziurtatuta dago
        // > `T` gisa.
        //
        // Dokumentuek `MaybeUninit<T>` array batetik `T` array batera transmititzen dute.
        //
        //
        // Horrekin, hasieraketa honek aldaezinak asetzen ditu.

        // FIXME(LukasKalbertodt): benetan erabili `mem::transmute` hemen, const generikoekin funtzionatzen duenean:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Ordura arte, `mem::transmute_copy` erabil dezakegu bit moduko kopia bat sortzeko beste mota gisa, eta gero ahaztu `array`, eror ez dadin.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Oraindik eman ez diren elementu guztien zatitxo aldaezina ematen du.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SEGURTASUNA: Badakigu `alive` barruko elementu guztiak ondo hasieratuta daudela.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Oraindik eman ez diren elementu guztien zati aldakorra ematen du.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SEGURTASUNA: Badakigu `alive` barruko elementu guztiak ondo hasieratuta daudela.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Lortu hurrengo indizea aurrealdetik.
        //
        // `alive.start` 1 handitzeak `alive`-ri dagokionez aldaezina mantentzen du.
        // Hala ere, aldaketa hori dela eta, denbora gutxian, bizirik dagoen eremua ez da `data[alive]` gehiago, `data[idx..alive.end]` baizik.
        //
        self.alive.next().map(|idx| {
            // Irakurri elementua array-tik.
            // SEGURTASUNA: `idx` lehengo "alive" eskualdearen aurkibidea da
            // array.Elementu hau irakurtzeak `data[idx]` orain hilda dagoela esan nahi du (hau da, ez ukitu).
            // `idx` zona biziaren hasiera izan zenez, zona bizia `data[alive]` da orain berriro, aldaezin guztiak berreskuratuz.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Lortu hurrengo indizea atzeko aldetik.
        //
        // `alive.end` 1 murrizteak `alive`-ri dagokionez aldaezina mantentzen du.
        // Hala ere, aldaketa hori dela eta, denbora gutxian, bizirik dagoen eremua ez da `data[alive]` gehiago, `data[alive.start..=idx]` baizik.
        //
        self.alive.next_back().map(|idx| {
            // Irakurri elementua array-tik.
            // SEGURTASUNA: `idx` lehengo "alive" eskualdearen aurkibidea da
            // array.Elementu hau irakurtzeak `data[idx]` orain hilda dagoela esan nahi du (hau da, ez ukitu).
            // `idx` zona biziaren amaiera zenez, zona bizia `data[alive]` da berriro, aldaezin guztiak berreskuratuz.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SEGURTASUNA: hau segurua da: `as_mut_slice`-k azpi-xerra itzultzen du
        // oraindik mugitu ez diren eta botatzeko geratzen diren elementuen artean.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Ez da inoiz gainezka egingo `bizirik.start <=aldaezina dela eta
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iteratzaileak, hain zuzen ere, luzera zuzena ematen du.
// "alive" elementu kopurua (oraindik emango direnak) `alive` barrutiaren luzera da.
// Barruti hori luzera gutxituta dago `next` edo `next_back`.
// Beti 1 gutxitzen da metodo horietan, baina `Some(_)` itzultzen bada bakarrik.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Oharra, ez dugu zertan bizirik dagoen berdina berdindu behar, beraz, 0 desplazamenduan klonatu dezakegu `self` non dagoen kontuan hartu gabe.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Bizirik dauden elementu guztiak klonatu.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Idatzi klona array berrian eta, ondoren, eguneratu bizirik dagoen barrutia.
            // panics klonatuz gero, aurreko elementuak zuzen botako ditugu.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Inprimatu oraindik eman ez ziren elementuak: ezin ditugu jada emandako elementuak atzitu.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}