//! Ordenatzeko eta alderatzeko funtzionaltasuna.
//!
//! Modulu honek balioak ordenatzeko eta alderatzeko hainbat tresna ditu.Laburbilduz:
//!
//! * [`Eq`] eta [`PartialEq`] balioen arteko berdintasun totala eta partziala zehazteko aukera ematen duten traits dira, hurrenez hurren.
//! Horiek ezartzeak `==` eta `!=` operadoreak gainkargatzen ditu.
//! * [`Ord`] eta [`PartialOrd`] balioen arteko ordenamendu osoak eta partzialak zehazteko aukera ematen duten traits dira, hurrenez hurren.
//!
//! Horiek ezartzeak `<`, `<=`, `>` eta `>=` operadoreak gainkargatzen ditu.
//! * [`Ordering`] [`Ord`] eta [`PartialOrd`] funtzio nagusiek itzulitako enum bat da, eta ordenazio bat deskribatzen du.
//! * [`Reverse`] ordenazioa erraz alderantzikatzeko aukera ematen duen egitura da.
//! * [`max`] eta [`min`] [`Ord`]-rekin sortzen diren funtzioak dira eta bi balio gehienez edo gutxienez aurkitzeko aukera ematen dute.
//!
//! Xehetasun gehiago lortzeko, ikusi zerrendako elementu bakoitzari dagokion dokumentazioa.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) diren berdintasun konparazioetarako.
///
/// trait honek berdintasun partziala ahalbidetzen du, baliokidetasun erlazio osoa ez duten motetarako.
/// Adibidez, `NaN != NaN` zenbaki mugikorreko zenbakietan, beraz, puntu mugikorreko motek `PartialEq` inplementatzen dute baina ez [`trait@Eq`].
///
/// Formalki, berdintasunak hau izan behar du (`A`, `B`, `C` motako `a`, `b`, `c` guztientzat):
///
/// - **Simetrikoa**: `A: PartialEq<B>` eta `B: PartialEq<A>` bada,**`a==b`-k`b==a`** dakar;eta
///
/// - **Iragankorra**: `A: PartialEq<B>` eta `B: PartialEq<C>` eta `A bada:
///   PartialEq<C>`, orduan **` a==b`eta `b == c`-k`a==c`** dakar.
///
/// Kontuan izan `B: PartialEq<A>` (symmetric) eta `A: PartialEq<C>` (transitive) inplikazioak ez daudela behartuta, baina betekizun hauek daudenean aplikatzen dira.
///
/// ## Derivable
///
/// trait hau `#[derive]`-rekin erabil daiteke.`Derive`d egituretan, bi instantzia berdinak dira eremu guztiak berdinak badira, eta ez dira berdinak edozein eremu berdinak ez badira.Enm-etatik `der` ateratzerakoan, aldaera bakoitza beraren berdina da eta ez beste aldaeren berdina.
///
/// ## Nola ezar dezaket `PartialEq`?
///
/// `PartialEq` [`eq`] metodoa soilik ezartzea eskatzen du;[`ne`] horren arabera definitzen da lehenespenez.[`ne`]*eskuz ezartzeak* errespetatu behar du [`eq`] [`ne`] ren alderantzizko zorrotza dela dioen araua;hau da, `!(a == b)` bada eta soilik `a != b` bada.
///
/// `PartialEq`, [`PartialOrd`] eta [`Ord`]*inplementazioek* ados egon behar dute.Erraza da nahigabe desadostasuna eragitea traits batzuk eratorrita eta beste batzuk eskuz ezarriz.
///
/// Bi liburu liburu bera jotzen diren domeinuaren inplementazio adibidea, haien ISBNarekin bat badator, formatuak desberdinak badira ere:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Nola konparatu ditzaket bi mota desberdin?
///
/// Konparatu dezakezun mota `PartialEq` motako parametroak kontrolatzen du.
/// Adibidez, goazen aurreko kodea pixka bat moldatzen:
///
/// ```
/// // Eratorritako tresnak<BookFormat>==<BookFormat>konparazioak
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Ezarri<Book>==<BookFormat>konparazioak
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Ezarri<BookFormat>==<Book>konparazioak
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq for Book` `impl PartialEq<BookFormat> for Book`-ra aldatuz gero, `BookFormat`s`Book`s-ekin alderatzea baimentzen dugu.
///
/// Goikoarekin alderatuz gero, egituraren eremu batzuk alde batera uzten dituena, arriskutsua izan daiteke.Erraz ekar dezake baliokidetasun partzialeko erlazio baterako baldintzak nahi gabe urratzea.
/// Adibidez, `PartialEq<Book>`-ren aurreko inplementazioa `BookFormat`-erako mantenduko bagenu eta `PartialEq<Book>`-ren inplementazio bat `Book`-erako gehituko bagenu (`#[derive]` baten bidez edo lehen adibideko eskuzko ezarpenaren bidez) orduan emaitzak transitivitatea urratuko luke:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Metodo honek `self` eta `other` balioak berdinak direla egiaztatzen du, eta `==`-k erabiltzen du.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Metodo honek `!=` probatzen du.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Eraman makroa trait `PartialEq` ren inplikazioa sortzen.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) diren berdintasun konparazioetarako.
///
/// Horrek esan nahi du `a == b` eta `a != b` alderantzizko zorrotzak izateaz gain, berdintasunak izan behar duela (`a`, `b` eta `c` guztientzat):
///
/// - reflexive: `a == a`;
/// - simetrikoa: `a == b`-k `b == a` dakar;eta
/// - iragankorra: `a == b` eta `b == c`-k `a == c` dakar.
///
/// Propietate hau ezin du konpiladoreak egiaztatu eta, beraz, `Eq`-k [`PartialEq`] dakar, eta ez du aparteko metodorik.
///
/// ## Derivable
///
/// trait hau `#[derive]`-rekin erabil daiteke.
/// `Derive`d denean, `Eq`-k metodo gehigarririk ez duenez, konpilatzaileari baliokidetasun erlazio partziala baino gehiago baliokidetasun erlazioa dela jakinarazten dio.
///
/// Kontuan izan `derive` estrategiak eremu guztiak `Eq` izatea eskatzen duela, beti nahi ez dena.
///
/// ## Nola ezar dezaket `Eq`?
///
/// Ezin baduzu `derive` estrategia erabili, zehaztu zure motak inolako metodorik ez duen `Eq` inplementatzen duela:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // metodo hau#[deriving]-ek soilik erabiltzen du mota bateko osagai bakoitzak#[deriving] bera inplementatzen duela baieztatzeko, egungo deribatutako azpiegiturak esan nahi du baieztapen hau egitea trait honetan metodo bat erabili gabe ia ezinezkoa dela.
    //
    //
    // Hori ez da inoiz eskuz ezarri behar.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Eraman makroa trait `Eq` ren inplikazioa sortzen.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: egitura hau#[derive] to-k soilik erabiltzen du
// baieztatu mota bateko osagai guztiek ekuazioa ezartzen dutela.
//
// Egitura hau ez da inoiz erabiltzailearen kodean agertu behar.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering` bi balioen arteko konparazioaren emaitza da.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Konparatutako balioa beste bat baino txikiagoa den ordenaketa bat.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Konparatutako balioa beste baten berdina den ordenamendua.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Konparatutako balioa beste bat baino handiagoa den ordenaketa bat.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// `true` itzultzen du agindua `Equal` aldaera bada.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// `true` itzultzen du agindua `Equal` aldaera ez bada.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// `true` itzultzen du agindua `Less` aldaera bada.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// `true` itzultzen du agindua `Greater` aldaera bada.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// `true` itzultzen du agindua `Less` edo `Equal` aldaera bada.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// `true` itzultzen du agindua `Greater` edo `Equal` aldaera bada.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// `Ordering` alderantzikatzen du.
    ///
    /// * `Less` `Greater` bihurtzen da.
    /// * `Greater` `Less` bihurtzen da.
    /// * `Equal` `Equal` bihurtzen da.
    ///
    /// # Examples
    ///
    /// Oinarrizko portaera:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Metodo hau alderaketa alderantzikatzeko erabil daiteke:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // ordenatu array handienetik txikienera.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Kateak bi ordenamendu.
    ///
    /// `self` itzultzen du `Equal` ez denean.Bestela `other` itzultzen du.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Emandako funtzioarekin ordenamendua kateatzen du.
    ///
    /// `self` itzultzen du `Equal` ez denean.
    /// Bestela `f` deitzen du eta emaitza itzultzen du.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Alderantzizko ordenamendurako laguntzailea.
///
/// Egitura hau [`Vec::sort_by_key`] bezalako funtzioekin erabiltzeko laguntzailea da eta tekla baten zati bat ordena alderantzikatzeko erabil daiteke.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait [total order](https://en.wikipedia.org/wiki/Total_order) bat osatzen duten motetarako.
///
/// Ordena ordena osoa da (`a`, `b` eta `c` guztientzat):
///
/// - guztira eta asimetrikoa: zehazki `a < b`, `a == b` edo `a > b` bat egia da;eta
/// - iragankorrak, `a < b` eta `b < c`-k `a < c` dakar.Gauza bera gertatu behar da `==` eta `>` kasuan.
///
/// ## Derivable
///
/// trait hau `#[derive]`-rekin erabil daiteke.
/// Egituretan `derive`d denean, [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) ordenamendua sortuko du egiturako kideen goitik beherako deklarazio ordenan oinarrituta.
///
/// Baterietan `derive`d denean, aldaerak goitik beherako ordena diskriminatzailearen arabera ordenatzen dira.
///
/// ## Konparazio lexikografikoa
///
/// Konparazio lexikografikoa propietate hauek dituen eragiketa da:
///  - Bi sekuentzia elementuz elementu alderatzen dira.
///  - Lehenengo desadostasuneko elementuak definitzen du zein sekuentzia den lexikografikoki bestea baino txikiagoa edo handiagoa.
///  - Sekuentzia bat beste baten aurrizkia bada, sekuentzia laburrena bestea baino lexikografikoki txikiagoa da.
///  - Bi sekuentziek elementu baliokideak badituzte eta luzera berekoak badira, sekuentziak lexikografikoki berdinak dira.
///  - Sekuentzia huts bat lexikografikoki hutsik ez dagoen edozein sekuentzia baino txikiagoa da.
///  - Bi sekuentzia huts lexikografikoki berdinak dira.
///
/// ## Nola ezar dezaket `Ord`?
///
/// `Ord` eskatzen du mota [`PartialOrd`] eta [`Eq`] ere izatea (horrek eskatzen du [`PartialEq`]).
///
/// Ondoren, [`cmp`]-en inplementazioa definitu behar duzu.Baliteke zure motako eremuetan [`cmp`] erabiltzea erabilgarria dela.
///
/// [`PartialEq`], [`PartialOrd`] eta `Ord`*inplementazioek* ados egon behar dute.
/// Hau da, `a.cmp(b) == Ordering::Equal` baldin bada eta soilik `a == b` eta `Some(a.cmp(b)) == a.partial_cmp(b)` bada `a` eta `b` guztientzat.
/// Erraza da nahigabe desadostasuna eragitea traits batzuk eratorrita eta beste batzuk eskuz ezarriz.
///
/// Hona hemen jendea altueraren arabera soilik ordenatu nahi duzun adibidea, `id` eta `name` kontuan hartu gabe:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Metodo honek [`Ordering`] bat itzultzen du `self` eta `other` artean.
    ///
    /// Hitzarmenez, `self.cmp(&other)`-k `self <operator> other` esamoldearekin bat datorren agindua itzultzen du egia bada.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Bi balio gehienez alderatzen eta itzultzen ditu.
    ///
    /// Bigarren argumentua itzultzen du konparazioak berdinak direla zehazten badu.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Bi balio gutxieneko alderatu eta itzultzen ditu.
    ///
    /// Lehenengo argumentua itzultzen du konparazioak berdinak direla zehazten badu.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Balio bat tarte jakin batera mugatu.
    ///
    /// `max` ematen du `self` `max` baino handiagoa bada eta `min` `self` `min` baino txikiagoa bada.
    /// Bestela, honek `self` itzultzen du.
    ///
    /// # Panics
    ///
    /// Panics `min > max` bada.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Eraman makroa trait `Ord` ren inplikazioa sortzen.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait ordenatze ordenarekin alderatu daitezkeen balioetarako.
///
/// Konparazioak `a`, `b` eta `c` guztientzat bete behar du:
///
/// - asimetria: `a < b` bada `!(a > b)`, baita `a > b` `!(a < b)` dakarrena;eta
/// - iragankortasuna: `a < b` eta `b < c`-k `a < c` dakar.Gauza bera gertatu behar da `==` eta `>` kasuan.
///
/// Kontuan izan eskakizun horiek esan nahi dutela trait bera simetrikoki eta iragankortasunez ezarri behar dela: `T: PartialOrd<U>` eta `U: PartialOrd<V>` bada `U: PartialOrd<T>` eta `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// trait hau `#[derive]`-rekin erabil daiteke.Egituretan `derive`d denean, ordenazio lexikografikoa sortuko du egiturako kideen goitik beherako deklarazio ordenan oinarrituta.
/// Baterietan `derive`d denean, aldaerak goitik beherako ordena diskriminatzailearen arabera ordenatzen dira.
///
/// ## Nola ezar dezaket `PartialOrd`?
///
/// `PartialOrd` [`partial_cmp`] metodoa ezartzea soilik eskatzen du, lehenetsitako inplementazioetatik sortutako beste batzuekin.
///
/// Hala ere, posible da gainerakoak bereiz ezartzea eskaera osoa ez duten motetarako.
/// Adibidez, zenbaki mugikorreko zenbakientzat, `NaN < 0 == false` eta `NaN >= 0 == false` (cf.
/// IEEE 754-2008 atala 5.11).
///
/// `PartialOrd` zure motak [`PartialEq`] izatea eskatzen du.
///
/// [`PartialEq`], `PartialOrd` eta [`Ord`]*inplementazioek* ados egon behar dute.
/// Erraza da nahigabe desadostasuna eragitea traits batzuk eratorrita eta beste batzuk eskuz ezarriz.
///
/// Zure mota [`Ord`] bada, [`partial_cmp`] ezar dezakezu [`cmp`] erabiliz:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Zure motako eremuetan [`partial_cmp`] erabiltzea ere erabilgarria izan daiteke.
/// Hemen duzue puntu mugikorreko `height` eremua duten `Person` moten adibidea, hau da, ordenatzeko erabili beharreko eremu bakarra:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Metodo honek `self` eta `other` balioen arteko ordenazioa itzultzen du, baldin badago.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Konparazioa ezinezkoa denean:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Metodo honek (`self` eta `other`) baino gutxiago probatzen du eta `<` operadoreak erabiltzen du.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Metodo honek (`self` eta `other`) baino txikiagoak edo berdinak probatzen ditu eta `<=` operadoreak erabiltzen du.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Metodo hau (`self` eta `other`) baino handiagoa da eta `>` operadoreak erabiltzen du.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Metodo hau (`self` eta `other`) baino handiagoa edo berdina da eta `>=` operadoreak erabiltzen du.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Eraman makroa trait `PartialOrd` ren inplikazioa sortzen.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Bi balio gutxieneko alderatu eta itzultzen ditu.
///
/// Lehenengo argumentua itzultzen du konparazioak berdinak direla zehazten badu.
///
/// Barnean alias bat erabiltzen du [`Ord::min`]-ra.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Zehaztutako konparazio funtzioarekiko bi balio ematen ditu gutxienez.
///
/// Lehenengo argumentua itzultzen du konparazioak berdinak direla zehazten badu.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Zehaztutako funtziotik gutxieneko balioa ematen duen elementua itzultzen du.
///
/// Lehenengo argumentua itzultzen du konparazioak berdinak direla zehazten badu.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Bi balio gehienez alderatzen eta itzultzen ditu.
///
/// Bigarren argumentua itzultzen du konparazioak berdinak direla zehazten badu.
///
/// Barnean alias bat erabiltzen du [`Ord::max`]-ra.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Zehaztutako konparazio funtzioarekiko bi balio ematen ditu gehienez.
///
/// Bigarren argumentua itzultzen du konparazioak berdinak direla zehazten badu.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Zehaztutako funtziotik gehienezko balioa ematen duen elementua itzultzen du.
///
/// Bigarren argumentua itzultzen du konparazioak berdinak direla zehazten badu.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// PartialEq, Eq, PartialOrd eta Ord-en ezarpena mota primitiboetarako
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Hemengo ordena garrantzitsua da muntaketa optimoa sortzeko.
                    // Informazio gehiagorako ikusi <https://github.com/rust-lang/rust/issues/63758>.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // I8-ra igotzeak eta aldea Ordenetara bihurtzeak muntaketa optimoa sortzen du.
            //
            // Informazio gehiagorako ikusi <https://github.com/rust-lang/rust/issues/66780>.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // SEGURTASUNA: bool i8-k 0 edo 1 itzultzen du, beraz, aldea ezin da beste ezer izan
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &erakusleak

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}