//! Libcore prelude
//!
//! Modulu hau libstd-era ere lotzen ez duten libcore-ren erabiltzaileentzat pentsatuta dago.
//! Modulu hau lehenespenez inportatzen da `#![no_std]` liburutegi estandarraren prelude modu berean erabiltzen denean.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// prelude muinaren 2015eko bertsioa.
///
/// Ikusi [module-level documentation](self) gehiago.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// prelude core bertsioaren 2018 bertsioa.
///
/// Ikusi [module-level documentation](self) gehiago.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// prelude muinaren 2021eko bertsioa.
///
/// Ikusi [module-level documentation](self) gehiago.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Gehitu gauza gehiago.
}