//! Mailegatutako datuekin lan egiteko modulua.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait datuak maileguan hartzeko.
///
/// Rust-n, ohikoa da mota bateko irudikapen desberdinak eskaintzea erabilera kasu desberdinetarako.
/// Adibidez, balio baten biltegiratze kokapena eta kudeaketa berariaz aukeratu daitezke erabilera jakin baterako egoki diren erakusle moten bidez, hala nola [`Box<T>`] edo [`Rc<T>`].
/// Edozein motarekin erabil daitezkeen bilgarri generiko horietatik harago, mota batzuek aukerako alderdiak eskaintzen dituzte potentzialki garestiak diren funtzionaltasunak eskainiz.
/// Mota horretako adibide bat [`String`] da, oinarrizko [`str`] katea luzatzeko gaitasuna gehitzen duena.
/// Horretarako beharrezkoa da informazio osagarria alferrikakoa izatea kate sinple eta aldaezin baterako.
///
/// Mota hauek azpiko datuetarako sarbidea ematen dute datu horien motaren erreferentzien bidez.Mota horretako "maileguan" omen daude.
/// Adibidez, [`Box<T>`] bat `T` moduan mailegu daiteke [`String`] bat `str` moduan maileguan.
///
/// Motek `T` mota gisa mailegatu daitezkeela adierazten dute `Borrow<T>` ezarriz, trait-ren [`borrow`] metodoan `T` erreferentzia bat emanez.Mota bat hainbat mailegu maileguan hartzeko doakoa da.
/// Azpiko datuak aldatzea ahalbidetuz mota gisa maileguan hartu nahi badu, [`BorrowMut<T>`] ere inplementa dezake.
///
/// Gainera, traits osagarrietarako inplementazioak ematerakoan, kontuan hartu behar da azpiko motakoen berdin jokatu behar duten ala ez, azpiko mota horren irudikapen gisa jokatzearen ondorioz.
/// Kode generikoak normalean `Borrow<T>` erabiltzen du trait inplementazio osagarri horien portaera berdinean oinarritzen denean.
/// traits hauek ziurrenik trait bounds osagarri gisa agertuko dira.
///
/// Bereziki `Eq`, `Ord` eta `Hash` baliokideak izan behar dira mailegatutako eta jabetzako balioetarako: `x.borrow() == y.borrow()` ek `x == y` ren emaitza bera eman beharko luke.
///
/// Kode generikoak erlazionatutako `T` motari erreferentzia eman diezaioketen mota guztietarako lan egin behar badu, askotan hobe da [`AsRef<T>`] erabiltzea, mota gehiagok segurtasunez ezar dezaketelako.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Datu bilketa gisa, [`HashMap<K, V>`]-k gakoak eta balioak ditu.Gakoaren benetako datuak nolabaiteko kudeaketa mota batean bilduta badaude, hala ere, balio bat bilatu beharko litzateke gakoaren datuen erreferentzia erabiliz.
/// Adibidez, gakoa katea bada, baliteke hash maparekin [`String`] gisa gordetzea, [`&str`][`str`] erabiliz bilaketa egitea posible izan beharko litzatekeen bitartean.
/// Horrela, `insert`-k `String`-rekin funtzionatu behar du `get`-k `&str`-a erabili ahal izateko.
///
/// Zertxobait sinplifikatuta, `HashMap<K, V>` ren zati garrantzitsuek itxura hau dute:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // eremuak kenduta
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Hash mapa osoa generikoa da `K` gako motaren gainean.Gako hauek hash maparekin gordetzen direnez, mota honek gakoaren datuak izan behar ditu.
/// Gako-balio bikotea txertatzerakoan, mapari `K` ematen zaio eta hash ontzi zuzena aurkitu behar du eta egiaztatu gakoa dagoeneko badagoen `K` horretan oinarrituta.Beraz, `K: Hash + Eq` eskatzen du.
///
/// Mapan balio bat bilatzerakoan, ordea, `K` erreferentzia bat eman behar izateak bilatu behar duen gakoa, beti jabetzako balio hori sortu beharko litzateke.
/// Kate-gakoei dagokienez, horrek esan nahi du `String` balio bat sortu behar dela `str` soilik erabilgarri dagoen kasuak bilatzeko.
///
/// Horren ordez, `get` metodoa orokorra da azpiko gako datu motaren gainean, goiko metodoaren sinaduran `Q` izenekoa.`K`-k `Q` gisa mailegatzen duela adierazten du `K: Borrow<Q>` hori eskatuta.
/// `Q: Hash + Eq` behar izanez gero, `K` eta `Q` `Hash` eta `Eq` traits-ren inplementazioak emaitza berdinak izan ditzaten eskatzen da.
///
/// `get`-ren inplementazioa `Hash`-ren inplementazio berdinetan oinarritzen da batez ere, gakoaren hash ontzia zehaztean `Hash::hash` deituz `Q` balioarekin, nahiz eta gakoa `K` balioaren arabera kalkulatutako hash balioan oinarrituta sartu.
///
///
/// Ondorioz, hash mapa hausten da `Q` balioa biltzen duen `K` batek `Q` baino beste hash bat sortzen badu.Adibidez, imajina ezazu kate bat biltzen duen mota bat duzula, baina ASCII hizkiak konparatzen ditu haien kasua alde batera utzita:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Bi balio berdinek hash balio bera sortu behar dutenez, `Hash` ren inplementazioak ASCII kasua ere ez du kontuan hartu behar:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// `CaseInsensitiveString`-k `Borrow<str>` ezar dezake?Zalantzarik gabe, kate zati bati erreferentzia eman diezaioke bere jabetzako katearen bidez.
/// Baina `Hash` inplementazioa desberdina denez, `str` ekiko portaera ezberdina du eta, beraz, ez du `Borrow<str>` inplementatu behar.
/// Besteei azpiko `str` sarbidea baimendu nahi badie, `AsRef<str>` bidez egin dezake, aparteko eskakizunik ez duena.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Propietatezko balio batetik mailegatu ezin daitekeena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait datuak elkarrekin mailegatzeko.
///
/// [`Borrow<T>`]-ren laguntzaile gisa, trait-k mota batek azpiko mota gisa mailegatzea ahalbidetzen du erreferentzia aldagarri bat emanez.
/// Ikusi [`Borrow<T>`] maileguari buruzko informazio gehiago beste mota gisa.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Jabetzako balio batetik bestera mailegatu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}