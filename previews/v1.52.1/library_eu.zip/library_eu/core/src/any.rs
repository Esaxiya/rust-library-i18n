//! Modulu honek `Any` trait inplementatzen du, hau da, edozein `'static` motako idazketa dinamikoa exekuzio garaiko hausnarketaren bidez.
//!
//! `Any` bera `TypeId` lortzeko erabil daiteke, eta ezaugarri gehiago ditu trait objektu gisa erabiltzen denean.
//! `&dyn Any` gisa (maileguan hartutako trait objektu bat), `is` eta `downcast_ref` metodoak ditu, jasotako balioa mota jakin batekoa den egiaztatzeko eta barne balioaren erreferentzia mota gisa lortzeko.
//! `&mut dyn Any` bezala, `downcast_mut` metodoa ere badago, barneko balioaren erreferentzia aldakorra lortzeko.
//! `Box<dyn Any>` `downcast` metodoa gehitzen du, `Box<T>` bihurtzen saiatzen dena.
//! [`Box`] dokumentazioa xehetasun guztiak ikusteko.
//!
//! Kontuan izan `&dyn Any` balioa zehaztutako hormigoizko mota den ala ez probatzera mugatuta dagoela, eta ezin dela erabili mota batek trait bat ezartzen duen ala ez egiaztatzeko.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Erakusle adimendunak eta `dyn Any`
//!
//! Kontuan hartu beharreko portaera bat `Any` trait objektu gisa erabiltzerakoan, batez ere `Box<dyn Any>` edo `Arc<dyn Any>` bezalako motekin, hau da, `.type_id()` balioari deitzeak *edukiontziaren*`TypeId` sortuko du, ez azpiko trait objektuak.
//!
//! Hori ekidin daiteke erakusle adimenduna `&dyn Any` bihurtuz, objektuaren `TypeId` itzuliko baitu.
//! Adibidez:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Litekeena da hau nahi izatea:
//! let actual_id = (&*boxed).type_id();
//! // ... hau baino:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Demagun funtzio bati pasatutako balioa saioa amaitu nahi dugun egoera.
//! Badakigu lantzen ari garen balioa arazketa gauzatzen, baina ez dakigu horren mota konkretua.Mota jakin batzuei tratamendu berezia eman nahi diegu: kasu honetan String balioen luzera inprimatu haien balioa baino lehen.
//! Konpilazio garaian ez dakigu gure balioaren mota zehatza, beraz, exekuzio garaian hausnarketa erabili behar dugu.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Depuratzailea inplementatzen duen edozein motatako erregistro funtzioa.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Saiatu gure balioa `String` bihurtzen.
//!     // Arrakastatsua bada, String-en luzera eta balioa eman nahi ditugu.
//!     // Bestela, beste mota bat da: inprimatu apaindurarik gabe.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Funtzio honek bere parametroa amaitu nahi du berarekin lana egin aurretik.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... beste lan bat egin
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Edozein trait
///////////////////////////////////////////////////////////////////////////////

/// trait idazketa dinamikoa imitatzeko.
///
/// Mota gehienek `Any` ezartzen dute.Hala ere, "estatikoa" ez den erreferentzia duen edozein motak ez du.
/// Ikusi [module-level documentation][mod] xehetasun gehiago lortzeko.
///
/// [mod]: crate::any
// trait hau ez da segurua, nahiz eta bere inplikazioaren `type_id` funtzioaren berezitasunetan oinarritzen garen kode ez seguruan (adibidez, `downcast`).Normalean, arazoa izango litzateke, baina `Any`-ren inplementazio bakarra manta inplementazio bat denez, beste kodek ezin du `Any` inplementatu.
//
// trait hau seguru bihurtu genezake-ez luke haustura eragingo, inplementazio guztiak kontrolatzen baititugu-baina ez dugu aukeratzen, hori bai ez baita beharrezkoa eta erabiltzaileak nahastu ditzake traits ez seguruak eta metodo ez seguruak (hau da, `type_id` deitzeko segurua litzateke oraindik, baina litekeena da dokumentazioan hala adierazi nahi izatea).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self`-ren `TypeId` lortzen du.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Edozein trait objektuen luzapen metodoak.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Ziurtatu, adibidez, hari bat elkartzearen emaitza inprimatu eta, beraz, `unwrap`-rekin erabil daitekeela.
// Azkenean ezingo da beharrezkoa bidalketa igoerarekin funtzionatzen badu.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// `true` ematen du kutxako mota `T` bezalakoa bada.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Lortu funtzio honekin instantzia den motako `TypeId`.
        let t = TypeId::of::<T>();

        // Lortu `TypeId` motako trait (`self`) objektuan.
        let concrete = self.type_id();

        // Alderatu berdintasunaren `TypeId` biak.
        t == concrete
    }

    /// Kutxako balioari erreferentzia batzuk ematen dizkio `T` motakoa bada edo `None` ez bada.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SEGURTASUNA: mota zuzena seinalatzen ari garen ala ez egiaztatu eta fidatu gaitezke
            // memoriaren segurtasuna egiaztatzen duten mota guztietarako Edozein gauzatu dugulako;ezin da beste inplikaziorik existitu gure inplikazioarekin gatazkatuko litzatekeen bezala.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Kutxako balioari erreferentzia aldakor batzuk ematen dizkio `T` motakoa bada edo `None` ez bada.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SEGURTASUNA: mota zuzena seinalatzen ari garen ala ez egiaztatu eta fidatu gaitezke
            // memoriaren segurtasuna egiaztatzen duten mota guztietarako Edozein gauzatu dugulako;ezin da beste inplikaziorik existitu gure inplikazioarekin gatazkatuko litzatekeen bezala.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Aurrera `Any` motan definitutako metodora.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Aurrera `Any` motan definitutako metodora.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Aurrera `Any` motan definitutako metodora.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Aurrera `Any` motan definitutako metodora.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Aurrera `Any` motan definitutako metodora.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Aurrera `Any` motan definitutako metodora.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID eta bere metodoak
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` mota orokorreko identifikatzaile bakarra da.
///
/// `TypeId` bakoitza objektu opako bat da, barnean dagoena ikuskatzea baimentzen duena baina oinarrizko eragiketak onartzen ditu, hala nola klonazioa, alderaketa, inprimaketa eta erakustaldia.
///
///
/// Gaur egun `TypeId` A eskuragarri dago `'static`-i egozten zaizkion motetarako, baina muga hori future-n kendu daiteke.
///
/// `TypeId`-k `Hash`, `PartialOrd` eta `Ord` inplementatzen dituen bitartean, aipagarria da hash-ak eta ordena Rust bertsioen artean aldatuko direla.
/// Kontuz zure kodearen barruan konfiantzaz!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Funtzio generiko honekin hasitako motako `TypeId` itzultzen du.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Mota baten izena kate zati gisa itzultzen du.
///
/// # Note
///
/// Erabilera diagnostikorako pentsatuta dago.
/// Itzulitako katearen eduki eta formatu zehatzak ez daude zehaztuta, motaren ahalegin onena deskribatzea baino.
/// Adibidez, `type_name::<Option<String>>()` k itzul ditzakeen kateen artean `"Option<String>"` eta `"std::option::Option<std::string::String>"` daude.
///
///
/// Itzulitako katea ez da mota bateko identifikatzaile bakartzat hartu behar, mota anitzek izen berarekin mapatu baitezakete.
/// Era berean, ez dago bermatuta mota bateko zati guztiak itzuliko diren katean agertuko direnik: adibidez, bizitza osoko zehaztatzaileak ez daude sartuta.
/// Gainera, irteera konpiladorearen bertsioen artean alda daiteke.
///
/// Uneko inplementazioak konpiladorearen diagnostikoen eta debuginfo-ren azpiegitura bera erabiltzen du, baina hori ez dago bermatuta.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Puntatutako balioaren motaren izena kate zati gisa itzultzen du.
/// Hau `type_name::<T>()` bezalakoa da, baina aldagai mota erraz eskuragarri ez dagoenean erabil daiteke.
///
/// # Note
///
/// Erabilera diagnostikorako pentsatuta dago.Katearen eduki eta formatu zehatzak ez daude zehaztuta, motaren ahalegin onenaren deskribapena izateaz gain.
/// Adibidez, `type_name_of_val::<Option<String>>(None)`-k `"Option<String>"` edo `"std::option::Option<std::string::String>"` itzul dezake, baina ez `"foobar"`.
///
/// Gainera, irteera konpiladorearen bertsioen artean alda daiteke.
///
/// Funtzio honek ez ditu trait objektuak konpontzen, hau da, `type_name_of_val(&7u32 as &dyn Debug)`-k `"dyn Debug"` itzul dezake, baina ez `"u32"`.
///
/// Motaren izena ez da mota bateko identifikatzaile bakartzat hartu behar;
/// mota anitzek izen bera partekatu dezakete.
///
/// Uneko inplementazioak konpiladorearen diagnostikoen eta debuginfo-ren azpiegitura bera erabiltzen du, baina hori ez dago bermatuta.
///
/// # Examples
///
/// Zenbaki oso eta mugikor lehenetsiak inprimatzen ditu.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}