//! Traits moten arteko bihurketetarako.
//!
//! Modulu honetako traits-k mota batetik bestera bihurtzeko modua eskaintzen du.
//! trait bakoitzak helburu ezberdina du:
//!
//! - Ezarri [`AsRef`] trait erreferentzia-erreferentziako bihurketa merkeak lortzeko
//! - Ezarri [`AsMut`] trait aldakorra eta aldagarria den bihurketa merkeak lortzeko
//! - Ezar ezazu [`From`] trait balio-balio bihurketak kontsumitzeko
//! - Ezarri [`Into`] trait uneko crate kanpoko motetarako balio-balio bihurketak kontsumitzeko.
//! - [`TryFrom`] eta [`TryInto`] traits-k [`From`] eta [`Into`] bezala jokatzen dute, baina bihurketak huts egin dezakeenean ezarri beharko lirateke.
//!
//! Modulu honetako traits trait bounds gisa erabili ohi dira funtzio generikoetarako, mota askotako argumentuak onartzen baitira.Ikus trait bakoitzaren dokumentazioa adibideetarako.
//!
//! Liburutegiaren egile gisa, beti nahiago duzu [`From<T>`][`From`] edo [`TryFrom<T>`][`TryFrom`] ezartzea baino [`Into<U>`][`Into`] edo [`TryInto<U>`][`TryInto`] baino, [`From`] eta [`TryFrom`] malgutasun handiagoa eskaintzen baitute eta [`Into`] edo [`TryInto`] inplementazio baliokideak doan eskaintzen baitituzte liburutegi estandarraren inplementazio mantari esker.
//! Rust 1.41 aurretik bertsio bat bideratzean, beharrezkoa izan daiteke [`Into`] edo [`TryInto`] zuzenean ezartzea uneko crate kanpoko mota batera bihurtzean.
//!
//! # Ezarpen generikoak
//!
//! - [`AsRef`] eta [`AsMut`] autoreferentzia, barne mota erreferentzia bada
//! - [`From`]`<U>T`-</u> rentzat [`Into`]`<U>dakar</u><T><U>U`-rentzat</u>
//! - [`TryFrom`]`<U>T`-</u> rentzat [`TryInto`]`<U>dakar</u><T><U>U`-rentzat</u>
//! - [`From`] eta [`Into`] erreflexiboak dira, hau da, mota guztiek beraiek `into` eta `from` beraiek egin dezakete
//!
//! Ikusi trait bakoitza erabilera adibideetarako.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Nortasun funtzioa.
///
/// Bi gauza garrantzitsuak dira funtzio honi buruz ohartzeko:
///
/// - Ez da beti `|x| x` bezalako itxiera baten baliokidea, itxierak `x` beste mota batera behartzen baitu.
///
/// - Funtziora pasatutako `x` sarrera mugitzen du.
///
/// Sarrera itzultzen duen funtzioa izatea arraroa dirudien arren, badira erabilera interesgarriak.
///
///
/// # Examples
///
/// `identity` erabiltzea beste funtzio interesgarri batzuen segidan ezer egiteko:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Eman dezagun bat gehitzea funtzio interesgarria dela.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// `identity` "do nothing" oinarrizko kasu gisa erabiltzea baldintzapean:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Egin gauza interesgarriagoak ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `identity` erabiltzea `Option<T>` iteratzaile baten `Some` aldaerak mantentzeko:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Erreferentzia-erreferentzia bihurketa merkea egiteko erabiltzen da.
///
/// trait hau erreferentzia aldagarrien artean bihurtzeko erabiltzen den [`AsMut`] ren antzekoa da.
/// Bihurketa garestia egin behar baduzu, hobe [`From`] `&T` motarekin ezartzea edo funtzio pertsonalizatua idaztea.
///
/// `AsRef` [`Borrow`] ren sinadura bera du, baina [`Borrow`] desberdina da alderdi gutxitan:
///
/// - `AsRef`-k ez bezala, [`Borrow`]-k edozein manta-tresna du `T`-rako, eta erreferentzia edo balioa onartzeko erabil daiteke.
/// - [`Borrow`] maileguaren balioaren [`Hash`], [`Eq`] eta [`Ord`] ere jabetzako balioaren baliokideak izatea eskatzen du.
/// Hori dela eta, egitura baten eremu bakarra maileguan hartu nahi baduzu `AsRef` ezar dezakezu, baina ez [`Borrow`].
///
/// **Note: trait honek ez du huts egin behar **.Bihurketak huts egin badu, erabili metodo dedikatu bat, [`Option<T>`] edo [`Result<T, E>`] bat itzultzen duena.
///
/// # Ezarpen generikoak
///
/// - `AsRef` auto-erreferentziak barne mota erreferentzia edo alda daitekeen erreferentzia bada (adibidez: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds erabiliz mota desberdinetako argumentuak onar ditzakegu, betiere zehaztutako `T` motara bihur daitezkeen bitartean.
///
/// Adibidez: `AsRef<str>` bat hartzen duen funtzio generikoa sortuz [`&str`] bihur daitezkeen erreferentzia guztiak argumentu gisa onartu nahi ditugula adierazten dugu.
/// [`String`] eta [`&str`]-k `AsRef<str>` inplementatzen dutenez, biak sarrera argumentu gisa onar ditzakegu.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Bihurketa egiten du.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Aldagarri-aldakorreko erreferentzia bihurketa merkea egiteko erabiltzen da.
///
/// trait hau [`AsRef`] ren antzekoa da baina erreferentzia aldagarrien artean bihurtzeko erabiltzen da.
/// Bihurketa garestia egin behar baduzu, hobe [`From`] `&mut T` motarekin ezartzea edo funtzio pertsonalizatua idaztea.
///
/// **Note: trait honek ez du huts egin behar **.Bihurketak huts egin badu, erabili metodo dedikatu bat, [`Option<T>`] edo [`Result<T, E>`] bat itzultzen duena.
///
/// # Ezarpen generikoak
///
/// - `AsMut` auto-erreferentziak barne mota erreferentzia aldaezina bada (adibidez: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// `AsMut` erabiliz trait bound gisa funtzio generiko baterako `&mut T` motara bihur daitezkeen erreferentzia aldagarri guztiak onar ditzakegu.
/// [`Box<T>`]-k `AsMut<T>` inplementatzen duenez, `add_one`-ra bihur daitezkeen argumentu guztiak hartzen dituen `add_one` funtzioa idatz dezakegu.
/// [`Box<T>`]-k `AsMut<T>` inplementatzen duenez, `add_one`-k `&mut Box<u64>` motako argumentuak ere onartzen ditu:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Bihurketa egiten du.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Sarrerako balioa kontsumitzen duen balio-balio bihurketa.[`From`]-ren aurkakoa.
///
/// [`Into`] ezartzea saihestu beharko litzateke eta horren ordez [`From`] ezarri.
/// [`From`] ezartzeak automatikoki [`Into`] inplementazio bat eskaintzen du liburutegi estandarreko mantaren ezarpenari esker.
///
/// Nahiago duzu [`Into`] [`From`] baino gehiago erabili trait bounds funtzio generiko batean zehaztean [`Into`] bakarrik inplementatzen duten motak ere erabil daitezkeela ziurtatzeko.
///
/// **Note: trait honek ez du huts egin behar **.Bihurketak huts egin badu, erabili [`TryInto`].
///
/// # Ezarpen generikoak
///
/// - [`From`]`<T>izan ere, U`-k `Into<U> for T` dakar
/// - [`Into`] erreflexiboa da, hau da, `Into<T> for T` ezarrita dago
///
/// # [`Into`] ezartzea kanpoko motetarako bihurketetarako Rust bertsio zaharretan
///
/// Rust 1.41 aurretik, helmuga mota uneko crate-ren parte ez balitz, ezin zenuke [`From`] zuzenean inplementatu.
/// Adibidez, hartu kode hau:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Honek ez du hizkuntzaren bertsio zaharragoetan konpilatuko, Rust ren arau umezurtzak zorrotzagoak izaten baitziren.
/// Hori ekiditeko, [`Into`] zuzenean inplementa dezakezu:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Garrantzitsua da ulertzea [`Into`]-k ez duela [`From`] inplementaziorik ematen ([`From`]-ek [`Into`]-rekin egiten duen bezala).
/// Hori dela eta, beti saiatu beharko zenuke [`From`] ezartzen eta, ondoren, [`Into`]-ra itzuli behar da [`From`] inplementatu ezin bada.
///
/// # Examples
///
/// [`String`] implements [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Funtzio generiko batek zehaztutako `T` motara bihur daitezkeen argumentu guztiak har ditzan nahi dugula adierazteko, [`Into`]`ren trait bound erabil dezakegu.<T>`.
///
/// Adibidez: `is_hello` funtzioak [`Vec`]`<`[`u8`] `>` bihur daitezkeen argumentu guztiak hartzen ditu.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Bihurketa egiten du.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Sarrerako balioa kontsumitzen duzun bitartean balio-balio bihurketak egiteko erabiltzen da.[`Into`]-ren elkarrekikoa da.
///
/// Beti nahiago da `From` ezartzea [`Into`] baino, `From` ezartzeak automatikoki [`Into`] inplementazio bat eskaintzen baitu liburutegi estandarreko mantaren ezarpenari esker.
///
///
/// Ezarri [`Into`] soilik Rust 1.41 aurreko bertsio bat bideratzean eta uneko crate kanpoko mota batera bihurtzean.
/// `From` ezin izan du aurreko bertsioetan bihurketa mota horiek egin Rust ren arau umezurtzak direla eta.
/// Ikus [`Into`] xehetasun gehiagorako.
///
/// Nahiago duzu [`Into`] erabiltzea `From` erabiltzea baino trait bounds funtzio generiko batean zehaztean.
/// Horrela, [`Into`] zuzenean inplementatzen duten motak argumentu gisa ere erabil daitezke.
///
/// `From` ere oso erabilgarria da akatsak tratatzeko orduan.Hutsegiteko gai den funtzio bat eraikitzerakoan, itzulera mota orokorrean `Result<T, E>` formakoa izango da.
/// `From` trait-k erroreen kudeaketa errazten du funtzio batek errore mota anitz biltzen dituen errore mota bakarra itzultzea ahalbidetuz.Xehetasun gehiagorako ikusi "Examples" atala eta [the book][book].
///
/// **Note: trait honek ez du huts egin behar **.Bihurketak huts egin badu, erabili [`TryFrom`].
///
/// # Ezarpen generikoak
///
/// - `From<T> for U` T-rako [`Into`]` <U>dakar</u>
/// - `From` erreflexiboa da, hau da, `From<T> for T` ezarrita dago
///
/// # Examples
///
/// [`String`] `From<&str>` inplementatzen du:
///
/// `&str`-tik Kate-ra bihurtzeko modu esplizitua honela egiten da:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Akatsen tratamendua egiten ari zaren bitartean, askotan erabilgarria da `From` zure errore motarako ezartzea.
/// Azpiko errore motak azpiko errore mota kapsulatzen duen gure errore pertsonalizatuko motara bihurtuz, errore mota bakarra itzul dezakegu azpiko kausaren inguruko informazioa galdu gabe.
/// '?' operadoreak azpiko errore mota automatikoki bihurtzen du gure errore mota pertsonalizaturara X002 ezartzean automatikoki ematen den `Into<CliError>::into` deituz.
/// Konpiladoreak `Into` ren zein inplementazio erabili behar den ondorioztatzen du.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Bihurketa egiten du.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// `self` kontsumitzen duen bihurketa saiakera bat, garestia izan daiteke edo ez.
///
/// Liburutegiaren egileek normalean ez lukete zuzenean trait hau inplementatu behar, baina nahiago dute [`TryFrom`] trait ezartzea, malgutasun handiagoa eskaintzen baitu eta `TryInto` inplementazio baliokidea doan eskaintzen du, liburutegi estandarraren inplementazio mantalari esker.
/// Horri buruzko informazio gehiago lortzeko, ikusi [`Into`] dokumentazioa.
///
/// # `TryInto` ezartzea
///
/// Honek [`Into`] inplementatzearen murrizketa eta arrazoibide berak ditu. Ikusi han xehetasunak.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Bihurketa-errore bat gertatuz gero mota itzultzen da.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Bihurketa egiten du.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Zenbait kasutan modu kontrolatuan huts egin dezaketen mota bihurketa sinple eta seguruak.[`TryInto`]-ren elkarrekikoa da.
///
/// Hau baliagarria da arrakasta izan dezakeen baina manipulazio berezia behar duen motako bihurketa egiten ari zarenean.
/// Adibidez, ez dago [`i64`] [`i32`] bihurtzeko modurik [`From`] trait erabiliz, [`i64`] batek [`i32`] batek ordezkatu ezin duen balioa izan dezakeelako eta, beraz, bihurketak datuak galduko lituzkeelako.
///
/// Hau [`i64`] [`i32`] batera moztuz (funtsean [`i64`] balioa [`i32::MAX`] modulua emanez) edo [`i32::MAX`] itzuliz edo beste metodo baten bidez kudeatu daiteke.
/// [`From`] trait bihurketa ezin hobeak egiteko pentsatuta dago, beraz, `TryFrom` trait programari jakinarazten dio motako bihurketa txarra izan daitekeenean eta nola kudeatu erabakitzen uzten dio.
///
/// # Ezarpen generikoak
///
/// - `TryFrom<T> for U` T-rako [`TryInto`]` <U>dakar</u>
/// - [`try_from`] erreflexiboa da, hau da, `TryFrom<T> for T` ezarrita dago eta ezin du huts egin. `T` motako `T` motako balioari `Error` deitzeko lotutako [`Infallible`] da.
/// [`!`] mota egonkortzen denean [`Infallible`] eta [`!`] baliokideak izango dira.
///
/// `TryFrom<T>` honela ezar daiteke:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Deskribatu bezala, [`i32`]-k `TryFrom <` [`i64`]`>`inplementatzen du:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // `big_number` mozten du isilean, mozketa detektatu eta maneiatzea eskatzen du gertaeraren ondoren.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Errore bat ematen du `big_number` handiegia delako `i32` batean sartzeko.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` itzultzen du.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Bihurketa-errore bat gertatuz gero mota itzultzen da.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Bihurketa egiten du.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS GENERIKOAK
////////////////////////////////////////////////////////////////////////////////

// Igogailu gisa
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// &mut baino gehiago igogailu gisa
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): ordezkatu goiko inplementazioak&/&mut-en ondorengo orokorragoarekin:
// // Deref gaineko igogailu gisa
// inpl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Tamaina> AsRef <U>for D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut-ek &mut baino gehiago altxatzen du
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): ordezkatu goiko inplementazioa &mut-rako hau orokorragoarekin:
// // AsMut DerefMut gainetik altxatzen da
// inpl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Tamaina> AsMut <U>for D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// From-ek Into dakar
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (eta beraz Into) erreflexiboa da
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Egonkortasun oharra:** Aplikazio hau oraindik ez da existitzen, baina "reserving space" gara future-n gehitzeko.
/// [rust-lang/rust#64715][#64715] xehetasunetarako ikusi.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): egin ordez printzipio konponketa bat.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom-ek TryInto dakar
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Konbertsio hutsezinak biztanle gabeko errore mota duten bihurketa falibleen parekoak dira semantikoki.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// HORMIGORREKO IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// ERRORIK EZ AKASI MOTA
////////////////////////////////////////////////////////////////////////////////

/// Inoiz gerta ez daitezkeen akatsen errore mota.
///
/// Enum honek aldaerarik ez duenez, mota honetako balioa ezin da inoiz existitu.
/// Hau erabilgarria izan daiteke [`Result`] erabiltzen duten eta errore mota parametrizatzen duten API generikoetarako, emaitza beti [`Ok`] dela adierazteko.
///
/// Adibidez, [`TryFrom`] trait ([`Result`] itzultzen duen bihurketa) inplementazio manta bat du alderantzizko [`Into`] inplementazioa dagoen mota guztietarako.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future bateragarritasuna
///
/// Enum honek [the `!`“never”type][never]-ren eginkizun bera du, Rust bertsio honetan ezegonkorra baita.
/// `!` egonkortzen denean, `Infallible` horren alias mota bihurtzea aurreikusten dugu:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Eta azkenean `Infallible` zaharkitu.
///
/// Hala ere, bada kasu bat `!` sintaxia erabil daitekeena `!` mota oso gisa egonkortu aurretik: funtzioaren itzulera motaren posizioan.
/// Zehazki, bi funtzio erakusle mota desberdinetarako inplementazioak posible dira:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` enum bat izanik, kode honek balio du.
/// Hala ere, `Infallible` never type rentzako alias bihurtzen denean, bi `impl`s gainjartzen hasiko dira eta, beraz, hizkuntzaren trait koherentzia arauek ez dituzte onartuko.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}