#![stable(feature = "futures_api", since = "1.36.0")]

//! Balio asinkronoak.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Mota hau beharrezkoa da:
///
/// a) Sorgailuek ezin dute `for<'a, 'b> Generator<&'a mut Context<'b>>` inplementatu, beraz, erakusle gordina pasatu behar dugu (ikus <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Erakusle gordinak eta `NonNull` ez dira `Send` edo `Sync`, beraz future non-Send/Sync bakoitza ere bihurtuko litzateke eta ez dugu hori nahi.
///
/// `.await` ren HIR jaistea ere errazten du.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Itzuli sorgailu bat future batean.
///
/// Funtzio honek `GenFuture` bat itzultzen du azpian, baina `impl Trait`-n ezkutatzen du errore mezu hobeak emateko (`impl Future` baino `GenFuture<[closure.....]>`).
///
// Hau `const` da `const async fn`-etik berreskuratu ondoren akats gehigarriak ekiditeko
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // async/await futures mugiezinak direla oinarritzen gara, azpiko sorgailuan auto-erreferentziazko maileguak sortzeko.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SEGURTASUNA: segurua !Unpin + !Drop garelako, eta hau eremuaren proiekzioa besterik ez da.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Berrekin sorgailua, `&mut Context` `NonNull` erakusle gordin bihurtuz.
            // `.await` jaisteak segurtasunez itzuliko du `&mut Context` batera.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SEGURTASUNA: deitzaileak `cx.0` erakusle baliozkoa dela bermatu behar du
    // erreferentzia aldagarri bat izateko baldintza guztiak betetzen dituena.
    unsafe { &mut *cx.0.as_ptr().cast() }
}