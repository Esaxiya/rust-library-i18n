use crate::future::Future;

/// `Future` bihurtzea.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// future-k amaitzean sortuko duen irteera.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Zein future mota bihurtzen ari gara hau?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// future bat sortzen du balio batetik abiatuta.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}