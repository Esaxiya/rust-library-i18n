#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future-k kalkulu asinkronoa adierazten du.
///
/// future baliteke oraindik ordenagailua amaitu ez duen balioa da.
/// "asynchronous value" mota honi esker, hari batek lan erabilgarria egiten jarraitzea ahalbidetzen du balioa eskuragarri egongo den bitartean.
///
///
/// # `poll` metodoa
///
/// future-ren oinarrizko metodoa, `poll`,*saiatzen da* future azken balio batean ebazten.
/// Metodo honek ez du blokeatzen balioa prest ez badago.
/// Horren ordez, uneko zeregina esnatzea aurreikusten da `poll polling berriro eginez gero aurrerapauso gehiago eman daitezkeenean.
/// `poll` metodoari igarotako `context`-k [`Waker`] bat eman dezake, hau da, uneko zeregina esnatzeko heldulekua.
///
/// future erabiltzerakoan, normalean ez diozu `poll` zuzenean deituko, `.await` balioa baizik.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Amaitzean sortutako balio mota.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Saiatu future azken balio batera ebazten, uneko zeregina erregistratzeko esnatzeko, balioa oraindik erabilgarri ez badago.
    ///
    /// # Itzuli balioa
    ///
    /// Funtzio honek itzultzen du:
    ///
    /// - [`Poll::Pending`] future oraindik prest ez badago
    /// - [`Poll::Ready(val)`] future honen `val` emaitzarekin ondo amaitu bada.
    ///
    /// future amaitutakoan, bezeroek ez lukete `poll` berriro egin behar.
    ///
    /// future oraindik prest ez dagoenean, `poll`-k `Poll::Pending` itzultzen du eta uneko [`Context`]-etik kopiatutako [`Waker`]-ren klona gordetzen du.
    /// [`Waker`] hau gero esnatuko da future-k aurrerapena lortzen duenean.
    /// Adibidez, socket bat irakurgarri izateko zain dagoen future batek `.clone()` deitu eta [`Waker`] telefonoan gorde egingo luke.
    /// Socket bat irakurgarria dela adierazten duen beste seinale bat iristen denean, [`Waker::wake`] deitzen da eta future socketaren zeregina esnatzen da.
    /// Zeregin bat esnatu ondoren, `poll` future berriro saiatu beharko litzateke, horrek azken balioa sor dezakeen edo ez.
    ///
    /// Kontuan izan `poll`-era egindako deia anitzetan, azken deira pasatutako [`Waker`]-tik [`Waker`]-k soilik antolatu behar duela iratzargailua jasotzeko.
    ///
    /// # Iraupenaren ezaugarriak
    ///
    /// Futures bakarrik *inerte* dira;*aktiboki* galdekatu behar dira aurrera egiteko, hau da, uneko zeregina esnatzen den bakoitzean aktiboki berriro poltsatu beharko luke oraindik interesa duen futures zain.
    ///
    /// `poll` funtzioari ez zaio behin eta berriz deitzen begizta estuan-horren ordez, future-k aurrerapausoak emateko prest dagoela adierazten duenean bakarrik deitu beharko litzateke (`wake()`) deituz.
    /// Unix-en `poll(2)` edo `select(2)` sistemen ezagupenak ezagutzen badituzu, azpimarratzekoa da futures-k normalean *ez* dituela "all wakeups must poll all events"-ren arazo berdinak izaten;gehiago dira `epoll(4)` bezalakoak.
    ///
    /// `poll` inplementazio batek azkar itzultzen ahalegindu beharko luke eta ez du blokeatu behar.Azkar itzultzeak hari edo gertaera-begiztak alferrik galtzea ekiditen du.
    /// Aurretik jakiten bada `poll`-ra dei batek denbora pixka bat iraun dezakeela, lana hari-multzo batera deskargatu beharko litzateke (edo antzeko zerbait) `poll` azkar itzul daitekeela ziurtatzeko.
    ///
    /// # Panics
    ///
    /// future bat amaitu ondoren (`Ready` `poll`-tik itzuli da), berriro `poll` metodoari deitzeak panic, betirako blokeatu edo beste mota bateko arazoak sor ditzake;`Future` trait-k ez du inolako baldintzarik jartzen dei horren efektuetan.
    /// Hala ere, `poll` metodoa `unsafe` markatuta ez dagoenez, Rust-ren ohiko arauak aplikatzen dira: deiek ez dute inoiz eragin gabeko portaera eragin behar (memoria ustelkeria, `unsafe` funtzioen erabilera okerra edo antzekoak), future-ren egoera edozein dela ere.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}