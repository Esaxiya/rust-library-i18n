use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Iteratzaile asinkronoei aurre egiteko interfazea.
///
/// Hau da trait korronte nagusia.
/// Orokorrean korronteen kontzeptuari buruzko informazio gehiago nahi izanez gero, ikusi [module-level documentation].
/// Bereziki, [implement `Stream`][impl] nola jakin jakin nahi duzu.
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Korronteak emandako elementu mota.
    type Item;

    /// Saiatu korronte honen hurrengo balioa ateratzen, uneko ataza erregistratzeko balioa oraindik erabilgarri ez badago, eta `None` itzuliz korrontea agortzen bada.
    ///
    /// # Itzuli balioa
    ///
    /// Itzultzeko hainbat balio posible daude, bakoitzak korronte egoera desberdin bat adierazten du:
    ///
    /// - `Poll::Pending` korronte honen hurrengo balioa oraindik ez dagoela prest esan nahi du.Inplementazioek ziurtatuko dute uneko ataza hurrengo balioa prest dagoenean jakinaraziko dela.
    ///
    /// - `Poll::Ready(Some(val))` esan nahi du korronteak `val` balio bat arrakastaz sortu duela eta ondorengo `poll_next` deietan balore gehiago sor ditzakeela.
    ///
    /// - `Poll::Ready(None)` korrontea amaitu dela esan nahi du eta `poll_next` berriro ez dela deitu behar.
    ///
    /// # Panics
    ///
    /// Korronte bat amaitutakoan (`Ready(None)` from `poll_next`) itzulita, berriro `poll_next` metodoari deitzeak panic blokea dezake, betiko blokeatu edo beste mota bateko arazoak sor ditzake; `Stream` trait-k ez du eskakizunik deialdi horren efektuetan.
    ///
    /// Hala ere, `poll_next` metodoa `unsafe` markatuta ez dagoenez, Rust ren ohiko arauak aplikatuko dira: deiek ez dute inoiz eragin gabeko portaera eragin behar (memoria ustelkeria, `unsafe` funtzioen erabilera okerra edo antzekoak), korrontearen egoera edozein dela ere.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Korrontearen gainerako luzeraren mugak ematen ditu.
    ///
    /// Zehazki, `size_hint()`-k tupla itzultzen du, non lehenengo elementua beheko muga den eta bigarren elementua goiko muga den.
    ///
    /// Itzultzen den tuplaren bigarren erdia [`Aukera`]`<`[`usize`] `>` da.
    /// Hemen [`None`] batek esan nahi du ez dagoela goiko muga ezagutzen, edo goiko muga [`usize`] baino handiagoa dela.
    ///
    /// # Ezartzeko oharrak
    ///
    /// Ez da aplikatzen korronte inplementazio batek adierazitako elementu kopurua ematen duenik.Buggy korronte batek elementuen beheko muga baino gutxiago edo gehiago sor dezake.
    ///
    /// `size_hint()` batez ere korrontearen elementuetarako lekua gordetzea bezalako optimizazioetarako erabili nahi da, baina ez da fidagarria, adibidez, kode ez seguruan mugen egiaztapenak kentzea.
    /// `size_hint()` ezartzeak ez luke memoria segurtasun urraketarik ekarri behar.
    ///
    /// Hori bai, inplementazioak zenbatespen zuzena eman beharko luke, bestela trait protokoloaren urraketa litzateke.
    ///
    /// Inplementazio lehenetsiak `(0,` [`Bat ere ez]]`) itzultzen du, hau da, edozein korronteetarako zuzena.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}