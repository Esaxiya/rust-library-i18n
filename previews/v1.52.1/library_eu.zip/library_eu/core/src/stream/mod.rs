//! Iterazio asinkrono konposagarria.
//!
//! futures balio asinkronoak badira, korronteak iteratzaile asinkronoak dira.
//! Nolabaiteko bilduma asinkrono batekin aurkitu bazara eta aipatutako bildumako elementuekin eragiketa egin behar baduzu, azkar topatuko duzu 'streams'.
//! Stream-ak asko erabiltzen dira Rust kode asinkrono idiomatikoan, beraz, merezi du haiekin ohitzea.
//!
//! Gehiago azaldu aurretik, hitz egin dezagun nola egituratzen den modulu hau:
//!
//! # Organization
//!
//! Modulu hau motaren arabera antolatzen da neurri handi batean:
//!
//! * [Traits] dira funtsezko zatia: traits hauek zer korronte mota dauden eta horiekin zer egin dezakezun definitzen dute.traits horien metodoek merezi dute azterketa denbora gehiago jartzea.
//! * Funtzioek oinarrizko korronte batzuk sortzeko modu lagungarriak eskaintzen dituzte.
//! * Egiturak modulu honetako traits-ko metodo desberdinen itzulera motak izan ohi dira.Normalean `struct` sortzen duen metodoa aztertu nahi duzu, `struct` bera baino.
//! Zergatik xehetasun gehiago nahi izanez gero, ikus '[Inplementazio korrontea](#ezarpen-korronte)'.
//!
//! [Traits]: #traits
//!
//! Hori da!Erreka sakon dezagun.
//!
//! # Stream
//!
//! Modulu honen bihotza eta arima [`Stream`] trait da.[`Stream`]-ren muina itxura hau du:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! `Iterator`-k ez bezala, `Stream`-ek [`poll_next`] metodoa `Stream` bat ezartzean erabiltzen den eta korronte bat kontsumitzerakoan erabiltzen den (to-be-implemented) `next` metodoa bereizten ditu.
//!
//! `Stream` kontsumitzaileek `next` bakarrik hartu behar dute kontuan, deitzen zaionean `Option<Stream::Item>` ematen duen future bat itzultzen baitu.
//!
//! `next`-k itzultzen duen future-k `Some(Item)` emango du elementuak dauden bitartean, eta behin agortuta daudenean, `None` emango du iterazioa amaitu dela adierazteko.
//! Konpondu ahal izateko zerbait asinkronoaren zain bagaude, future-k korrontea berriro errenditzeko prest egon arte itxarongo du.
//!
//! Korronte indibidualek iterazioari berrekiteko aukera egin dezakete eta, beraz, `next` berriro deitzeak agian `Some(Item)` berriro eman dezake edo ez noizbait.
//!
//! [`Stream`] definizio osoak beste zenbait metodo ere biltzen ditu, baina lehenetsitako metodoak dira, [`poll_next`]-ren gainean eraikiak, eta, beraz, doan lortuko dituzu.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Stream ezartzen
//!
//! Zeure korrontea sortzeak bi urrats dakartza: `struct` sortzea korrontearen egoerari eusteko eta, ondoren, [`Stream`] ezartzea `struct` horretarako.
//!
//! Egin dezagun `Counter` izeneko korrontea, `1`-tik `5`-ra zenbatzen dena:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Lehenik eta behin, egitura:
//!
//! /// Batetik bostera bitarteko korrontea
//! struct Counter {
//!     count: usize,
//! }
//!
//! // gure zenbaketa bat hastea nahi dugu, beraz, gehitu dezagun new() metodo bat laguntzeko.
//! // Ez da guztiz beharrezkoa, baina komenigarria da.
//! // Kontuan izan `count` zeroan hasten dugula, ikusiko dugu zergatik `poll_next()`'s inplementazioan behean.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ondoren, `Stream` inplementatzen dugu gure `Counter` erako:
//!
//! impl Stream for Counter {
//!     // erabilerarekin zenbatuko dugu
//!     type Item = usize;
//!
//!     // poll_next() beharrezkoa den metodo bakarra da
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Handitu gure kontua.Horregatik zeroan hasi ginen.
//!         self.count += 1;
//!
//!         // Begiratu zenbatzea amaitu dugun edo ez.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Korronteak *alferrak* dira.Horrek esan nahi du korronte bat sortzeak ez duela _do_ asko.Ez da ezer gertatzen `next` deitu arte.
//! Batzuetan nahasmendu iturri bat da bigarren mailako efektuetarako soilik korrontea sortzerakoan.
//! Konpiladoreak jokabide mota honen inguruan ohartaraziko digu:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;