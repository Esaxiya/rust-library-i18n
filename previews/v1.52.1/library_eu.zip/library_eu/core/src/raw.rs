#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Konpilagailu integratutako moten diseinurako egituraren definizioak ditu.
//!
//! Kode seguruetan transmutatuen xede gisa erabil daitezke irudikapen gordinak zuzenean manipulatzeko.
//!
//!
//! Haien definizioak `rustc_middle::ty::layout`-n definitutako ABIrekin bat etorri behar du beti.
//!

/// `&dyn SomeTrait` bezalako trait objektu baten irudikapena.
///
/// Egitura honek `&dyn SomeTrait` eta `Box<dyn AnotherTrait>` bezalako moten diseinu bera du.
///
/// `TraitObject` diseinuekin bat datorren ziurtatuta dago, baina ez da trait objektu mota (adibidez, eremuak ez dira zuzenean eskuragarriak `&dyn SomeTrait` batean) eta ez du diseinua kontrolatzen (definizioa aldatzeak ez du `&dyn SomeTrait` baten diseinua aldatuko).
///
/// Maila baxuko xehetasunak manipulatu behar dituen kode ez seguruak soilik erabiltzeko diseinatuta dago.
///
/// Ez dago trait objektu guztiak modu orokorrean aipatzeko modurik, beraz, mota honetako balioak sortzeko modu bakarra [`std::mem::transmute`][transmute] bezalako funtzioekin dago.
/// Era berean, `TraitObject` balio batetik egiazko trait objektu bat sortzeko modu bakarra `transmute` da.
///
/// [transmute]: crate::intrinsics::transmute
///
/// trait objektu bat ez datoz bat motekin sintetizatzeak -table bat datu-erakusleak seinalatzen duen balioaren motarekin bat ez badago- litekeena da zehaztu gabeko portaera izatea.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // adibide bat trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // utzi konpiladoreak trait objektu bat egiten
/// let object: &dyn Foo = &value;
///
/// // begiratu irudikapen gordinari
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // datuen erakuslea `value` ren helbidea da
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // Objektu berri bat eraiki, `i32` desberdina seinalatuz, kontuz `i32` Vtable `object`-tik erabiltzeko
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // X0X-etik zuzenean trait objektu bat eraiki izan bagenu bezala funtzionatu beharko luke
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}