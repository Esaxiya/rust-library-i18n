/// Agortzen denean beti `None` ematen jarraitzen duen iteratzailea.
///
/// `None` behin itzuli duen fusionatutako iteragailu bati deituz gero, [`None`] berriro itzuliko dela ziurtatuta dago.
/// trait hau horrela jokatzen duten iteratzaile guztiek ezarri beharko lukete [`Iterator::fuse()`] optimizatzea ahalbidetzen duelako.
///
///
/// Note: Oro har, ez zenuke `FusedIterator` muga generikoetan erabili behar bateratutako iteratzailea behar baduzu.
/// Horren ordez, [`Iterator::fuse()`] deitu beharko zenuke iteratzailean.
/// Iteratzailea dagoeneko fusionatuta badago, [`Fuse`] bilgarri gehigarria errendimendu zigorrik gabeko operazioa izango da.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Size_hint erabiliz luzera zehatza jakinarazten duen errepikatzailea.
///
/// Iteratzaileak tamaina aholku baten berri ematen du, non zehatza den (beheko muga goiko muga berdina da), edo goiko muga [`None`] da.
///
/// Goiko mugak [`None`] izan behar du benetako iteratzailearen luzera [`usize::MAX`] baino handiagoa bada.
/// Kasu horretan, beheko mugak [`usize::MAX`] izan behar du, eta ondorioz X002 X 02X.
///
/// Iteratzaileak jakinarazi behar du edo alderantziz ematen dituen elementu kopurua zehazki bukaerara iritsi aurretik.
///
/// # Safety
///
/// trait hau kontratua betetzen denean bakarrik ezarri behar da.
/// trait honen kontsumitzaileek [`Iterator::size_hint()`]’s goiko muga ikuskatu behar dute.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Elementu bat ematean gutxienez elementu bat bere azpiko [`SourceIter`]-etik hartu duen iteratzailea.
///
/// Iteratzailea aurreratzen duen edozein metodo deitzea, adibidez
/// [`next()`] edo [`try_fold()`], bermatzen du urrats bakoitzerako iteratzailearen azpiko iturriaren balio bat gutxienez kanpora atera dela eta iteratzaile-katearen emaitza bere lekuan txerta litekeela, iturriaren egiturazko mugek txertatze hori ahalbidetuko dutela suposatuz.
///
/// Beste modu batera esanda, trait honek iteratzaile hoditeria bere lekuan bil daitekeela adierazten du.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}