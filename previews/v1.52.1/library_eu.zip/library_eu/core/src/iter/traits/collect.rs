/// [`Iterator`] baten bihurketa.
///
/// Mota baterako `FromIterator` ezarrita, iteratzaile batetik nola sortuko den definituko duzu.
/// Hau ohikoa da nolabaiteko bilduma deskribatzen duten motetan.
///
/// [`FromIterator::from_iter()`] oso gutxitan deitzen zaio esplizituki, eta horren ordez [`Iterator::collect()`] metodoaren bidez erabiltzen da.
///
/// Ikusi [`Iterator::collect()`]'s dokumentazioa adibide gehiago lortzeko.
///
/// Ikusi ere: [`IntoIterator`].
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// [`Iterator::collect()`] erabiltzea `FromIterator` inplizituki erabiltzeko:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Zure motarako `FromIterator` ezartzea:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Lagin bilduma bat, Vec-en bilgarria besterik ez da<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Eman ditzagun metodo batzuk, bat sortu eta gauzak gehitzeko.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // eta FromIterator ezarriko dugu
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Orain iteratzaile berria egin dezakegu ...
/// let iter = (0..5).into_iter();
///
/// // ... eta egin MyCollection bat
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // bildu lanak ere!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Balio bat sortzen du iteratzaile batetik abiatuta.
    ///
    /// Ikusi [module-level documentation] gehiago.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// [`Iterator`] bihurtzea.
///
/// Mota baterako `IntoIterator` ezarrita, iteratzaile bihurtzeko modua zehaztuko duzu.
/// Hau ohikoa da nolabaiteko bilduma deskribatzen duten motetan.
///
/// `IntoIterator` ezartzearen abantaila bat zure motak [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) izango duela da.
///
///
/// Ikusi ere: [`FromIterator`].
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Zure motarako `IntoIterator` ezartzea:
///
/// ```
/// // Lagin bilduma bat, Vec-en bilgarria besterik ez da<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Eman ditzagun metodo batzuk, bat sortu eta gauzak gehitzeko.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // eta IntoIterator ezarriko dugu
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Orain bilduma berria egin dezakegu ...
/// let mut c = MyCollection::new();
///
/// // ... gehitu gauza batzuk ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... eta gero iteratzaile bihurtu:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Ohikoa da `IntoIterator` trait bound gisa erabiltzea.Horrek sarrera bilketa mota aldatzea ahalbidetzen du, oraindik iteratzailea bada.
/// Muga gehigarriak zehaztu daitezke aktibatuta
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Errepikatzen diren elementuen mota.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Zein iteratzaile mota bihurtzen ari gara hau?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Balio batetik iteratzailea sortzen du.
    ///
    /// Ikusi [module-level documentation] gehiago.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Zabaldu bilduma bat iteratzaile baten edukiarekin.
///
/// Iteratzaileek hainbat balio sortzen dituzte, eta bildumak ere balio multzo gisa har daitezke.
/// `Extend` trait-k hutsune hori gainditzen du, bilduma bat luzatzeko aukera ematen duena, iteratzaile horren edukia sartuz.
/// Bilduma bat lehendik existitzen den gako batekin hedatzean, sarrera hori eguneratzen da edo, gako berdinak dituzten sarrera bat baino gehiago baimentzen duten bildumetan, sarrera hori txertatzen da.
///
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// // Kate bat karaktere batzuekin luzatu dezakezu:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` ezartzea:
///
/// ```
/// // Lagin bilduma bat, Vec-en bilgarria besterik ez da<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Eman ditzagun metodo batzuk, bat sortu eta gauzak gehitzeko.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // MyCollection-ek i32s zerrenda duenez, Extend i32-era inplementatzen dugu
/// impl Extend<i32> for MyCollection {
///
///     // Hori sinpleagoa da hormigoizko sinadurarekin: i32ak ematen dizkigun Iteratzaile bihur daitekeen edozerri deitu diezaiokegu.
///     // MyCollection-en jartzeko i32ak behar ditugulako.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Inplementazioa oso erraza da: begiztatu iteratzailearen bidez, eta add() elementu bakoitza geure buruari.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // zabaldu dezagun gure bilduma beste hiru zenbaki gehiagorekin
/// c.extend(vec![1, 2, 3]);
///
/// // elementu hauek bukaeran gehitu ditugu
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Bilduma bat iteratzaile baten edukiekin zabaltzen du.
    ///
    /// trait honetarako beharrezkoa den metodo bakarra denez, [trait-level] dokumentuek xehetasun gehiago dituzte.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// // Kate bat karaktere batzuekin luzatu dezakezu:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Bilduma bat zehazki elementu batekin hedatzen du.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Bildumako edukiera gordetzen du emandako elementu osagarri kopuruarentzako.
    ///
    /// Inplementazio lehenetsiak ez du ezer egiten.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}