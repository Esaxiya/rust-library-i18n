use crate::ops::{ControlFlow, Try};

/// Bi muturretatik elementuak emateko gai den iteratzailea.
///
/// `DoubleEndedIterator` inplementatzen duen zerbaitek [`Iterator`] inplementatzen duenaren gaineko aparteko gaitasuna du: `Item`s atzeko aldetik, baita aurrealdetik ere eramateko gaitasuna du.
///
///
/// Garrantzitsua da kontuan hartzea atzera eta aurrera biak lan egiten dutela eta ez dutela zeharkatzen: iterazioa amaitzen da erdian elkartzen direnean.
///
/// [`Iterator`] protokoloaren antzera, `DoubleEndedIterator` batek [`None`] [`next_back()`] batetik itzultzen duenean, berriro deitzeak [`Some`] berriro itzul dezake edo ez du berriro itzuliko.
/// [`next()`] eta [`next_back()`] trukagarriak dira horretarako.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Elementu bat iteratzailearen amaieratik kentzen eta itzultzen du.
    ///
    /// `None` itzultzen du elementu gehiago ez dagoenean.
    ///
    /// [trait-level] dokumentuek xehetasun gehiago dituzte.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// `DoubleEndedIterator` en metodoek emandako elementuak [`Iterator`]-en metodoek emandakoekin alderatuta egon daitezke:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Aurreratzen du iteratzailea atzeko aldetik `n` elementuekin.
    ///
    /// `advance_back_by` [`advance_by`]-ren alderantzizko bertsioa da.Metodo honek gogotik saltatuko ditu `n` elementuak atzeko aldetik hasita [`next_back`] deituz `n` bider [`None`] topatu arte.
    ///
    /// `advance_back_by(n)` [`Ok(())`] itzuliko du errepikagailuak `n` elementuekin aurrera egiten badu, edo [`Err(k)`] [`None`] aurkitzen bada, non `k` elementuak agortu baino lehen errepikatzen duen elementu kopurua den (hau da, `k`)
    /// iteratzailearen luzera).
    /// Kontuan izan `k` beti `n` baino txikiagoa dela.
    ///
    /// `advance_back_by(0)` deitzeak ez du elementurik kontsumitzen eta beti [`Ok(())`] itzultzen du.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // `&3` bakarrik saltatu zen
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Iteratzailearen amaierako `n`th elementua itzultzen du.
    ///
    /// Hau da, funtsean, [`Iterator::nth()`] ren alderantzizko bertsioa.
    /// Indexazio eragiketa gehienak bezala, zenbaketa zerotik hasten da, beraz, `nth_back(0)`-k amaierako lehen balioa itzultzen du, `nth_back(1)` bigarrenak eta abar.
    ///
    ///
    /// Kontuan izan amaieraren eta itzultzen den elementuaren arteko elementu guztiak kontsumituko direla, itzulitako elementua barne.
    /// Horrek esan nahi du `nth_back(0)` errepikatzaile berean hainbat aldiz deitzeak elementu desberdinak itzuliko dituela.
    ///
    /// `nth_back()` [`None`] itzuliko du `n` iteratzailearen luzera baino handiagoa edo berdina bada.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` behin baino gehiagotan deitzeak ez du iteratzailea atzera botatzen:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `None` itzultzea `n + 1` elementuak baino gutxiago badaude:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Hau [`Iterator::try_fold()`] ren alderantzizko bertsioa da: iteratzailearen atzealdetik hasitako elementuak hartzen ditu.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Zirkuitulaburra egin duelako, gainerako elementuak iteratzailearen bidez eskuragarri daude oraindik.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Iteratzailearen elementuak iteratzailearen elementuak azken balio bakar batera murrizten ditu, atzeko aldetik hasita.
    ///
    /// Hau [`Iterator::fold()`] ren alderantzizko bertsioa da: iteratzailearen atzealdetik hasitako elementuak hartzen ditu.
    ///
    /// `rfold()` bi argumentu hartzen ditu: hasierako balioa eta itxiera bi argumenturekin: 'accumulator' bat eta elementu bat.
    /// Itxierak metagailuak hurrengo iteraziorako izan beharko lukeen balioa itzultzen du.
    ///
    /// Hasierako balioa metagailuak lehen deian izango duen balioa da.
    ///
    /// Itxigailuaren elementu guztiei itxiera hori aplikatu ondoren, `rfold()`-k metagailua itzultzen du.
    ///
    /// Eragiketa horri batzuetan 'reduce' edo 'inject' deitzen zaio.
    ///
    /// Tolestea erabilgarria da zerbaiten bilduma duzunean eta hortik balio bakarra sortu nahi baduzu.
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a-ren elementu guztien batura
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Adibide honek kate bat sortzen du, hasierako balioarekin hasi eta elementu bakoitzarekin atzealdetik aurrealdera arte jarraituz:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Atzetik predikatzaile bat asetzen duen iteratzaile baten elementua bilatzen du.
    ///
    /// `rfind()` `true` edo `false` itzultzen duen itxiera hartzen du.
    /// Itxigailuaren elementu bakoitzari itxiera hori aplikatzen dio, amaieran hasita, eta horietako batek `true` itzultzen badu, `rfind()`-k [`Some(element)`] itzultzen du.
    /// Denek `false` itzultzen badute, [`None`] itzultzen du.
    ///
    /// `rfind()` zirkuitulaburra da;beste era batera esanda, itxierak `true` itzultzen duen bezain laster prozesatzeari utziko dio.
    ///
    /// `rfind()`-k erreferentzia bat hartzen baitu, eta iteratzaile askok erreferentzien gainetik errepikatzen dutenez, egoera nahasgarria izan daiteke, argumentua erreferentzia bikoitza baita.
    ///
    /// Efektu hau beheko adibideetan ikus dezakezu, `&&x`-rekin.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Lehenengo `true` an gelditzea:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // oraindik `iter` erabil dezakegu, elementu gehiago baitaude.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}