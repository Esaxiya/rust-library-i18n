/// Bere luzera zehatza dakien iteratzailea.
///
/// [Iterator`] askok ez dakite zenbat aldiz errepikatuko duten, baina batzuek bai.
/// Errepikatzaile batek badaki zenbat aldiz errepika dezakeen, informazio hori eskuratzeko aukera erabilgarria izan daiteke.
/// Adibidez, atzeraka errepikatu nahi baduzu, hasiera ona da amaiera non dagoen jakitea.
///
/// `ExactSizeIterator` bat ezartzerakoan, [`Iterator`] ere ezarri behar duzu.
/// Hori egitean, [`Iterator::size_hint`]*ezartzeak* iteratzailearen tamaina zehatza itzuli behar du.
///
/// [`len`] metodoak ezarpen lehenetsia du, beraz normalean ez zenuke inplementatu behar.
/// Hala ere, baliteke lehenetsitakoa baino inplementazio errendimendu handiago bat eskaintzea, beraz, kasu honetan gainidatzeak zentzua du.
///
///
/// Kontuan izan trait hau trait segurua dela eta, hala,*ez* eta *ezin du* itzultzen duen luzera zuzena dela ziurtatzen.
/// Horrek esan nahi du `unsafe` kodeak **ez duela**[`Iterator::size_hint`] ren zuzentasunean oinarritu behar.
/// [`TrustedLen`](super::marker::TrustedLen) trait ezegonkorrak eta seguruak berme gehigarri hau ematen dute.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Oinarrizko erabilera:
///
/// ```
/// // barruti finitu batek badaki zehazki zenbat aldiz errepikatuko duen
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs]-n [`Iterator`] bat ezarri dugu, `Counter`.
/// Ezar dezagun `ExactSizeIterator` horretarako ere:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Gainerako errepikapen kopurua erraz kalkula dezakegu.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Eta orain erabil dezakegu!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Iteratzailearen luzera zehatza ematen du.
    ///
    /// Inplementazioak ziurtatzen du errepikatzaileak `len()`-rekin [`Some(T)`] balioa baino gehiago itzuliko duela [`None`] itzuli aurretik.
    ///
    /// Metodo honek ezarpen lehenetsia du, beraz normalean ez zenuke zuzenean inplementatu behar.
    /// Hala ere, inplementazio eraginkorragoa emanez gero, egin dezakezu.
    /// Ikus adibide bat lortzeko [trait-level] dokumentuak.
    ///
    /// Funtzio honek [`Iterator::size_hint`] funtzioaren segurtasun berme berdinak ditu.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// // barruti finitu batek badaki zehazki zenbat aldiz errepikatuko duen
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Baieztapen hau defentsa handiegia da, baina aldaezina egiaztatzen du
        // trait-k bermatuta.
        // trait hau rust-barnekoa balitz, debug_assert erabil genezake !;baieztatu_eq!Rust erabiltzaileen inplementazio guztiak ere egiaztatuko ditu.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// `true` itzultzen du errepikatzailea hutsik badago.
    ///
    /// Metodo honek lehenetsitako inplementazioa du [`ExactSizeIterator::len()`] erabiliz, beraz, ez duzu zuk zeuk inplementatu beharrik.
    ///
    ///
    /// # Examples
    ///
    /// Oinarrizko erabilera:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}